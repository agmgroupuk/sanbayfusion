package com.iamai.global;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
