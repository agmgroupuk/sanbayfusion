# 🔧 EC2 Server SSH Configuration Commands

## Connect to your EC2 server first:

```bash
ssh -i iamai-global.pem ubuntu@54.251.89.171
```

## Then run these commands on the EC2 server:

### 1. Generate SSH key on EC2

```bash
ssh-keygen -t ed25519 -C "aidigitalfriend@outlook.com" -f ~/.ssh/id_ed25519 -N ""
```

### 2. Display the public key

```bash
cat ~/.ssh/id_ed25519.pub
```

### 3. Copy the output and add it to GitHub

- Go to GitHub → Settings → SSH and GPG keys
- Click "New SSH key"
- Title: "EC2 Production Server"
- Paste the public key from step 2

### 4. Test SSH connection on EC2

```bash
ssh -T git@github.com
```

### 5. Navigate to project directory and update git remote

```bash
cd /var/www/iamai-global
git remote set-url origin git@github.com:aidigitalfriend/iamai-global.git
```

### 6. Test git pull

```bash
git pull origin main
```

### 7. Verify configuration

```bash
git remote -v
# Should show: origin	git@github.com:aidigitalfriend/iamai-global.git
```

## After completing these steps, run the deployment script again:

```bash
./deploy-to-production.sh
```

The deployment should now work without authentication errors! 🎉
