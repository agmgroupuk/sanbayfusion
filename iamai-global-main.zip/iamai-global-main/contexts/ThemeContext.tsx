import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { authService } from '../services/authService';
import { settingsService } from '../services/user/settingsService';
import { profileService } from '../services/profileService';
import { notificationService } from '../services/notificationService';

export type Theme = 'dark' | 'light' | 'midnight' | 'ocean' | 'forest' | 'sunset' | 'cyberpunk';

interface ThemeColors {
  name: Theme;
  displayName: string;
  primary: string;
  secondary: string;
  accent: string;
  background: string;
  surface: string;
  text: string;
  textSecondary: string;
  border: string;
}

const themeColors: Record<Theme, ThemeColors> = {
  dark: {
    name: 'dark',
    displayName: 'Dark Mode',
    primary: '#06b6d4',
    secondary: '#3b82f6',
    accent: '#8b5cf6',
    background: '#000000',
    surface: '#111827',
    text: '#ffffff',
    textSecondary: '#9ca3af',
    border: '#1f2937',
  },
  light: {
    name: 'light',
    displayName: 'Light Mode',
    primary: '#0891b2',
    secondary: '#2563eb',
    accent: '#7c3aed',
    background: '#ffffff',
    surface: '#f9fafb',
    text: '#111827',
    textSecondary: '#6b7280',
    border: '#e5e7eb',
  },
  midnight: {
    name: 'midnight',
    displayName: 'Midnight Blue',
    primary: '#3b82f6',
    secondary: '#6366f1',
    accent: '#8b5cf6',
    background: '#0f172a',
    surface: '#1e293b',
    text: '#f1f5f9',
    textSecondary: '#94a3b8',
    border: '#334155',
  },
  ocean: {
    name: 'ocean',
    displayName: 'Ocean Breeze',
    primary: '#06b6d4',
    secondary: '#14b8a6',
    accent: '#0ea5e9',
    background: '#082f49',
    surface: '#0c4a6e',
    text: '#f0f9ff',
    textSecondary: '#7dd3fc',
    border: '#075985',
  },
  forest: {
    name: 'forest',
    displayName: 'Forest Green',
    primary: '#22c55e',
    secondary: '#10b981',
    accent: '#84cc16',
    background: '#14532d',
    surface: '#166534',
    text: '#f0fdf4',
    textSecondary: '#86efac',
    border: '#15803d',
  },
  sunset: {
    name: 'sunset',
    displayName: 'Sunset Orange',
    primary: '#f97316',
    secondary: '#f59e0b',
    accent: '#ef4444',
    background: '#7c2d12',
    surface: '#9a3412',
    text: '#fff7ed',
    textSecondary: '#fed7aa',
    border: '#c2410c',
  },
  cyberpunk: {
    name: 'cyberpunk',
    displayName: 'Cyberpunk',
    primary: '#ec4899',
    secondary: '#a855f7',
    accent: '#06b6d4',
    background: '#1a0033',
    surface: '#2d0052',
    text: '#fdf4ff',
    textSecondary: '#e879f9',
    border: '#581c87',
  },
};

interface ThemeContextType {
  theme: Theme;
  themeColors: ThemeColors;
  toggleTheme: () => void;
  setTheme: (theme: Theme) => void;
  availableThemes: ThemeColors[];
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};

interface ThemeProviderProps {
  children: ReactNode;
}

export const ThemeProvider: React.FC<ThemeProviderProps> = ({ children }) => {
  const [theme, setThemeState] = useState<Theme>('dark');
  const [themeLoaded, setThemeLoaded] = useState(false);

  // Load theme from localStorage immediately (App.tsx already loads from API)
  useEffect(() => {
    const loadTheme = () => {
      try {
        // Load from localStorage immediately - no API call needed
        // App.tsx already handles loading theme from API on mount
        const localTheme = localStorage.getItem('iamai_theme') as Theme;
        if (localTheme && themeColors[localTheme]) {
          setThemeState(localTheme);
          console.log('✅ Theme loaded from localStorage:', localTheme);
        } else {
          setThemeState('dark');
          console.log('Using default theme: dark');
        }
      } catch (error) {
        console.error('Error loading theme:', error);
        setThemeState('dark');
      } finally {
        setThemeLoaded(true);
      }
    };

    loadTheme();
  }, []);

  const currentThemeColors = themeColors[theme];
  const availableThemes = Object.values(themeColors);

  useEffect(() => {
    const root = document.documentElement;

    // Apply CSS classes
    root.className = theme;

    // Apply CSS variables for dynamic theming
    root.style.setProperty('--color-primary', currentThemeColors.primary);
    root.style.setProperty('--color-secondary', currentThemeColors.secondary);
    root.style.setProperty('--color-accent', currentThemeColors.accent);
    root.style.setProperty('--color-background', currentThemeColors.background);
    root.style.setProperty('--color-surface', currentThemeColors.surface);
    root.style.setProperty('--color-text', currentThemeColors.text);
    root.style.setProperty('--color-text-secondary', currentThemeColors.textSecondary);
    root.style.setProperty('--color-border', currentThemeColors.border);

    // Theme persisted via settingsService.updateSettings()
  }, [theme, currentThemeColors]);

  const toggleTheme = () => {
    setThemeState(prev => (prev === 'dark' ? 'light' : 'dark'));
  };

  const setTheme = (newTheme: Theme) => {
    setThemeState(newTheme);

    // Save to localStorage immediately for instant feedback
    localStorage.setItem('iamai_theme', newTheme);

    // Show saving notification
    const savingToastId = notificationService.themeSaving();

    // Sync with backend user preferences
    syncThemeToBackend(newTheme, savingToastId);
  };

  // Debounce theme sync to prevent rate limiting
  const syncTimeoutRef = React.useRef<NodeJS.Timeout | null>(null);

  const syncThemeToBackend = async (theme: Theme, savingToastId?: string) => {
    // Clear existing timeout
    if (syncTimeoutRef.current) {
      clearTimeout(syncTimeoutRef.current);
    }

    // Debounce API call by 1 second
    syncTimeoutRef.current = setTimeout(async () => {
      try {
        // Use the new profile service for theme updates
        const success = await profileService.updateTheme(theme);

        // Remove saving toast
        if (savingToastId) {
          notificationService.removeToast(savingToastId);
        }

        if (success) {
          notificationService.themeSaved();
        } else {
          // Partial success (saved locally but not to database)
          notificationService.themeOffline();
        }
      } catch (error) {
        // Remove saving toast
        if (savingToastId) {
          notificationService.removeToast(savingToastId);
        }

        console.error('Error syncing theme to backend:', error);

        if (error instanceof Error && error.message.includes('log in')) {
          notificationService.authRequired();
        } else {
          notificationService.themeOffline();
        }

        // Ensure localStorage fallback
        localStorage.setItem('iamai_theme', theme);
      }
    }, 1000); // Wait 1 second before syncing
  };

  // Method to sync theme from database (called when user logs in)
  const syncThemeFromBackend = async () => {
    try {
      const profile = await profileService.syncOnLogin();

      if (profile?.preferences?.theme) {
        const dbTheme = profile.preferences.theme as Theme;
        if (themeColors[dbTheme] && dbTheme !== theme) {
          console.log('🔄 Syncing theme from database:', dbTheme);
          setThemeState(dbTheme);
          localStorage.setItem('iamai_theme', dbTheme);
          notificationService.success(
            'Welcome back!',
            `Your ${themeColors[dbTheme].displayName} theme has been restored`
          );
        }
      }
    } catch (error) {
      console.error('Error syncing theme from backend:', error);
    }
  };

  // Expose sync method globally for App.tsx to call after login
  React.useEffect(() => {
    window.syncThemeFromBackend = syncThemeFromBackend;
  }, [theme]);

  return (
    <ThemeContext.Provider
      value={{ theme, themeColors: currentThemeColors, toggleTheme, setTheme, availableThemes }}
    >
      {children}
    </ThemeContext.Provider>
  );
};

export { themeColors };
export type { ThemeColors };
