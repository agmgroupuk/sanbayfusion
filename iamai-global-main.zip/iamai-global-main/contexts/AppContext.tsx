import React, { createContext, useContext } from 'react';
import type { AppState, Page } from '../App';
import { Agent, BlogPost, SubscriptionPlanSlug } from '../constants';

interface AppContextType {
  state: AppState;
  setState: React.Dispatch<React.SetStateAction<AppState>>;
  navigate: (page: Page) => void;
  login: () => void;
  logout: () => void;
  selectAgent: (agent: Agent) => void;
  selectAgentForSubscription: (agent: Agent, plan?: SubscriptionPlanSlug) => void;
  subscribe: (agent: Agent, plan?: SubscriptionPlanSlug | null) => void;
  selectBlogPost: (post: BlogPost) => void;
  openSettings: () => void;
  closeSettings: () => void;
  setApiKey: (provider: 'gemini' | 'openai' | 'anthropic') => (key: string) => void;
  setAgents: (agents: Agent[] | ((prev: Agent[]) => Agent[])) => void;
  authLoading: boolean;
  refreshAppData: () => Promise<void>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ value: AppContextType; children: React.ReactNode }> = ({
  value,
  children,
}) => {
  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
