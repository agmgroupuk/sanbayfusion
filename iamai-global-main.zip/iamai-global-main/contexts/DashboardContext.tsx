/**
 * Dashboard Context
 * Manages real-time dashboard state, WebSocket connection, and live data updates
 */

import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { useWebSocket } from '../hooks/useWebSocket';

interface DashboardContextType {
  // Connection state
  connected: boolean;
  connecting: boolean;
  error: string | null;

  // Real-time metrics
  onlineUsers: number;
  activeAgents: number;
  totalMessages: number;
  activeChats: number;
  apiCalls: number;
  responseTime: number;
  cpuUsage: number;
  memoryUsage: number;

  // Activity feed
  recentActivity: Activity[];

  // Notifications
  notifications: Notification[];
  unreadCount: number;
  markNotificationRead: (id: string) => void;
  clearNotifications: () => void;

  // Actions
  refreshData: () => void;
  connect: () => void;
  disconnect: () => void;
}

interface Activity {
  id: string;
  userId: string;
  userName: string;
  agentId: string;
  agentName: string;
  action: 'chat' | 'subscribe' | 'upload' | 'export';
  timestamp: string;
  metadata?: any;
}

interface Notification {
  id: string;
  type: 'success' | 'info' | 'warning' | 'error';
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
}

const DashboardContext = createContext<DashboardContextType | undefined>(undefined);

interface DashboardProviderProps {
  children: ReactNode;
  token: string | null;
}

export const DashboardProvider: React.FC<DashboardProviderProps> = ({ children, token }) => {
  const {
    connected,
    connecting,
    error,
    onlineUsers,
    activeAgents,
    recentActivity,
    systemMetrics,
    notifications,
    connect,
    disconnect,
    markNotificationRead,
    clearNotifications,
    emit,
  } = useWebSocket(token, {
    autoConnect: false, // Disable auto-connect to prevent connection errors
    reconnection: false, // Disable reconnection to prevent connection spam
    reconnectionAttempts: 0,
    reconnectionDelay: 2000,
  });

  const [unreadCount, setUnreadCount] = useState(0);

  // Update unread notification count
  useEffect(() => {
    const unread = (notifications || []).filter(n => !n.read).length;
    setUnreadCount(unread);
  }, [notifications]);

  // Request fresh dashboard data
  const refreshData = () => {
    if (connected) {
      emit('dashboard:refresh');
    }
  };

  // Request data on connection
  useEffect(() => {
    if (connected) {
      refreshData();
    }
  }, [connected]);

  const value: DashboardContextType = {
    // Connection state
    connected,
    connecting,
    error,

    // Real-time metrics
    onlineUsers,
    activeAgents,
    totalMessages: systemMetrics?.totalMessages || 0,
    activeChats: systemMetrics?.activeChats || 0,
    apiCalls: systemMetrics?.apiCalls || 0,
    responseTime: Math.round(systemMetrics?.responseTime || 0),
    cpuUsage: systemMetrics?.cpuUsage || 0,
    memoryUsage: systemMetrics?.memoryUsage || 0,

    // Activity feed
    recentActivity,

    // Notifications
    notifications,
    unreadCount,
    markNotificationRead,
    clearNotifications,

    // Actions
    refreshData,
    connect,
    disconnect,
  };

  return <DashboardContext.Provider value={value}>{children}</DashboardContext.Provider>;
};

export const useDashboard = (): DashboardContextType => {
  const context = useContext(DashboardContext);
  if (context === undefined) {
    throw new Error('useDashboard must be used within a DashboardProvider');
  }
  return context;
};

export default DashboardContext;
