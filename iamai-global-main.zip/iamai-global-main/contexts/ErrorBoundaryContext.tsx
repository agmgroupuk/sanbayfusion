/**
 * 🚨 Error Boundary Context
 * Global error handling and recovery
 */

import React, { createContext, useContext, useState, useCallback, ReactNode } from 'react';

interface ErrorInfo {
  id: string;
  message: string;
  stack?: string;
  timestamp: Date;
  severity: 'low' | 'medium' | 'high' | 'critical';
  userId?: string;
  context?: Record<string, any>;
}

interface ErrorBoundaryContextType {
  errors: ErrorInfo[];
  addError: (error: Partial<ErrorInfo>) => void;
  removeError: (id: string) => void;
  clearErrors: () => void;
  reportError: (error: Error, context?: Record<string, any>) => void;
  hasErrors: boolean;
  criticalErrors: ErrorInfo[];
}

const ErrorBoundaryContext = createContext<ErrorBoundaryContextType | undefined>(undefined);

export const useErrorBoundary = () => {
  const context = useContext(ErrorBoundaryContext);
  if (!context) {
    throw new Error('useErrorBoundary must be used within ErrorBoundaryProvider');
  }
  return context;
};

interface ErrorBoundaryProviderProps {
  children: ReactNode;
  onError?: (error: ErrorInfo) => void;
  maxErrors?: number;
}

export const ErrorBoundaryProvider: React.FC<ErrorBoundaryProviderProps> = ({
  children,
  onError,
  maxErrors = 50,
}) => {
  const [errors, setErrors] = useState<ErrorInfo[]>([]);

  const addError = useCallback(
    (errorData: Partial<ErrorInfo>) => {
      const error: ErrorInfo = {
        id: Date.now().toString(),
        message: errorData.message || 'Unknown error',
        timestamp: new Date(),
        severity: errorData.severity || 'medium',
        ...errorData,
      };

      setErrors(prev => {
        const newErrors = [error, ...prev].slice(0, maxErrors);
        return newErrors;
      });

      // Call external error handler
      onError?.(error);

      // Report to external services in production
      if (import.meta.env.NODE_ENV === 'production') {
        reportToExternalService(error);
      }
    },
    [onError, maxErrors]
  );

  const removeError = useCallback((id: string) => {
    setErrors(prev => prev.filter(error => error.id !== id));
  }, []);

  const clearErrors = useCallback(() => {
    setErrors([]);
  }, []);

  const reportError = useCallback(
    (error: Error, context?: Record<string, any>) => {
      addError({
        message: error.message,
        stack: error.stack,
        severity: 'high',
        context: {
          ...context,
          url: window.location.href,
          userAgent: navigator.userAgent,
          timestamp: new Date().toISOString(),
        },
      });
    },
    [addError]
  );

  const hasErrors = errors.length > 0;
  const criticalErrors = errors.filter(error => error.severity === 'critical');

  const value: ErrorBoundaryContextType = {
    errors,
    addError,
    removeError,
    clearErrors,
    reportError,
    hasErrors,
    criticalErrors,
  };

  return <ErrorBoundaryContext.Provider value={value}>{children}</ErrorBoundaryContext.Provider>;
};

// External error reporting service
const reportToExternalService = async (error: ErrorInfo) => {
  try {
    // Report to backend error tracking
    await fetch('/api/errors', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(error),
    });
  } catch (reportingError) {
    console.error('Failed to report error:', reportingError);
  }
};

export default ErrorBoundaryContext;
