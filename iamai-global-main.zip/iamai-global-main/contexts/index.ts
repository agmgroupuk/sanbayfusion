/**
 * 🔄 Contexts Index
 * Centralized export for all React contexts
 */

// Core Contexts
export { default as AuthContext, AuthProvider, useAuth } from './AuthContext';
export { default as ThemeContext, ThemeProvider, useTheme } from './ThemeContext';
export { default as NotificationContext, NotificationProvider, useNotification } from './NotificationContext';

// Feature Contexts  
export { default as ModalContext, ModalProvider, useModal } from './ModalContext';
export { default as ErrorBoundaryContext, ErrorBoundaryProvider, useErrorBoundary } from './ErrorBoundaryContext';
export { default as WebSocketContext, WebSocketProvider, useWebSocket } from './WebSocketContext';
export { default as AnalyticsContext, AnalyticsProvider, useAnalytics } from './AnalyticsContext';
export { default as ApiContext, ApiProvider, useApi } from './ApiContext';

// Types
export type { User, AuthState } from './AuthContext';
export type { Theme, ThemeMode } from './ThemeContext';
export type { NotificationOptions, NotificationType } from './NotificationContext';
export type { ModalOptions } from './ModalContext';
export type { ErrorInfo } from './ErrorBoundaryContext';
export type { AnalyticsEvent } from './AnalyticsContext';
export type { ApiConfig, ApiRequest, ApiResponse, ApiError } from './ApiContext';

// Context Composition Helper
import React from 'react';

interface ContextComposerProps {
  contexts: Array<React.ComponentType<any>>;
  children: React.ReactNode;
}

export const ContextComposer: React.FC<ContextComposerProps> = ({ contexts, children }) => {
  return contexts.reduceRight(
    (acc, Context) => React.createElement(Context, null, acc),
    children as React.ReactElement
  );
};

// Main App Provider - combines all contexts
export const AppProviders: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return React.createElement(ContextComposer, {
    contexts: [
      ErrorBoundaryProvider,
      ApiProvider,
      AuthProvider,
      ThemeProvider,
      NotificationProvider,
      ModalProvider,
      WebSocketProvider,
      AnalyticsProvider,
    ]
  }, children);
};