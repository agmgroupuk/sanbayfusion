/**
 * 🌐 API Context
 * Centralized API management and request handling
 */

import React, { createContext, useContext, useState, useCallback, ReactNode } from 'react';

export interface ApiConfig {
  baseURL: string;
  timeout: number;
  retries: number;
  retryDelay: number;
  headers: Record<string, string>;
}

export interface ApiRequest {
  url: string;
  method: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';
  data?: any;
  headers?: Record<string, string>;
  timeout?: number;
  retries?: number;
  cache?: boolean;
}

export interface ApiResponse<T = any> {
  data: T;
  status: number;
  statusText: string;
  headers: Record<string, string>;
  config: ApiRequest;
}

export interface ApiError {
  message: string;
  status?: number;
  statusText?: string;
  data?: any;
  config?: ApiRequest;
}

interface ApiContextType {
  config: ApiConfig;
  updateConfig: (newConfig: Partial<ApiConfig>) => void;
  request: <T = any>(config: ApiRequest) => Promise<ApiResponse<T>>;
  get: <T = any>(url: string, config?: Partial<ApiRequest>) => Promise<ApiResponse<T>>;
  post: <T = any>(url: string, data?: any, config?: Partial<ApiRequest>) => Promise<ApiResponse<T>>;
  put: <T = any>(url: string, data?: any, config?: Partial<ApiRequest>) => Promise<ApiResponse<T>>;
  delete: <T = any>(url: string, config?: Partial<ApiRequest>) => Promise<ApiResponse<T>>;
  patch: <T = any>(
    url: string,
    data?: any,
    config?: Partial<ApiRequest>
  ) => Promise<ApiResponse<T>>;
  isLoading: boolean;
  pendingRequests: number;
}

const ApiContext = createContext<ApiContextType | undefined>(undefined);

export const useApi = () => {
  const context = useContext(ApiContext);
  if (!context) {
    throw new Error('useApi must be used within ApiProvider');
  }
  return context;
};

interface ApiProviderProps {
  children: ReactNode;
  config?: Partial<ApiConfig>;
}

const defaultConfig: ApiConfig = {
  baseURL: '/api',
  timeout: 30000,
  retries: 3,
  retryDelay: 1000,
  headers: {
    'Content-Type': 'application/json',
  },
};

export const ApiProvider: React.FC<ApiProviderProps> = ({
  children,
  config: initialConfig = {},
}) => {
  const [config, setConfig] = useState<ApiConfig>({
    ...defaultConfig,
    ...initialConfig,
  });

  const [pendingRequests, setPendingRequests] = useState(0);
  const cache = new Map<string, { data: any; timestamp: number; ttl: number }>();

  const updateConfig = useCallback((newConfig: Partial<ApiConfig>) => {
    setConfig(prev => ({ ...prev, ...newConfig }));
  }, []);

  const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

  const getCacheKey = (config: ApiRequest): string => {
    return `${config.method}:${config.url}:${JSON.stringify(config.data)}`;
  };

  const isValidCacheEntry = (entry: any, ttl: number = 300000): boolean => {
    return Date.now() - entry.timestamp < ttl;
  };

  const request = useCallback(
    async <T = any,>(requestConfig: ApiRequest): Promise<ApiResponse<T>> => {
      const fullConfig = {
        ...config,
        ...requestConfig,
        headers: {
          ...config.headers,
          ...requestConfig.headers,
        },
      };

      // Check cache for GET requests
      if (requestConfig.method === 'GET' && requestConfig.cache !== false) {
        const cacheKey = getCacheKey(fullConfig);
        const cachedEntry = cache.get(cacheKey);

        if (cachedEntry && isValidCacheEntry(cachedEntry)) {
          return cachedEntry.data;
        }
      }

      let attempt = 0;
      const maxRetries = fullConfig.retries || 0;

      const executeRequest = async (): Promise<ApiResponse<T>> => {
        setPendingRequests(prev => prev + 1);

        try {
          const controller = new AbortController();
          const timeoutId = setTimeout(() => controller.abort(), fullConfig.timeout);

          const url = fullConfig.url.startsWith('http')
            ? fullConfig.url
            : `${fullConfig.baseURL}${fullConfig.url}`;

          const fetchOptions: RequestInit = {
            method: fullConfig.method,
            headers: fullConfig.headers,
            signal: controller.signal,
          };

          if (fullConfig.data && fullConfig.method !== 'GET') {
            fetchOptions.body = JSON.stringify(fullConfig.data);
          }

          const response = await fetch(url, fetchOptions);
          clearTimeout(timeoutId);

          let responseData: T;
          const contentType = response.headers.get('content-type');

          if (contentType && contentType.includes('application/json')) {
            responseData = await response.json();
          } else {
            responseData = (await response.text()) as any;
          }

          const apiResponse: ApiResponse<T> = {
            data: responseData,
            status: response.status,
            statusText: response.statusText,
            headers: Object.fromEntries(response.headers.entries()),
            config: fullConfig,
          };

          if (!response.ok) {
            throw {
              message: `Request failed with status ${response.status}`,
              status: response.status,
              statusText: response.statusText,
              data: responseData,
              config: fullConfig,
            } as ApiError;
          }

          // Cache successful GET requests
          if (fullConfig.method === 'GET' && requestConfig.cache !== false) {
            const cacheKey = getCacheKey(fullConfig);
            cache.set(cacheKey, {
              data: apiResponse,
              timestamp: Date.now(),
              ttl: 300000, // 5 minutes default TTL
            });
          }

          return apiResponse;
        } catch (error) {
          if (error.name === 'AbortError') {
            throw {
              message: 'Request timeout',
              config: fullConfig,
            } as ApiError;
          }

          if (attempt < maxRetries) {
            attempt++;
            await sleep(fullConfig.retryDelay * Math.pow(2, attempt - 1));
            return executeRequest();
          }

          if (error instanceof Error) {
            throw {
              message: error.message,
              config: fullConfig,
            } as ApiError;
          }

          throw error;
        } finally {
          setPendingRequests(prev => prev - 1);
        }
      };

      return executeRequest();
    },
    [config]
  );

  const get = useCallback(
    <T = any,>(url: string, requestConfig?: Partial<ApiRequest>) => {
      return request<T>({ url, method: 'GET', ...requestConfig });
    },
    [request]
  );

  const post = useCallback(
    <T = any,>(url: string, data?: any, requestConfig?: Partial<ApiRequest>) => {
      return request<T>({ url, method: 'POST', data, ...requestConfig });
    },
    [request]
  );

  const put = useCallback(
    <T = any,>(url: string, data?: any, requestConfig?: Partial<ApiRequest>) => {
      return request<T>({ url, method: 'PUT', data, ...requestConfig });
    },
    [request]
  );

  const del = useCallback(
    <T = any,>(url: string, requestConfig?: Partial<ApiRequest>) => {
      return request<T>({ url, method: 'DELETE', ...requestConfig });
    },
    [request]
  );

  const patch = useCallback(
    <T = any,>(url: string, data?: any, requestConfig?: Partial<ApiRequest>) => {
      return request<T>({ url, method: 'PATCH', data, ...requestConfig });
    },
    [request]
  );

  const value: ApiContextType = {
    config,
    updateConfig,
    request,
    get,
    post,
    put,
    delete: del,
    patch,
    isLoading: pendingRequests > 0,
    pendingRequests,
  };

  return <ApiContext.Provider value={value}>{children}</ApiContext.Provider>;
};

export default ApiContext;
