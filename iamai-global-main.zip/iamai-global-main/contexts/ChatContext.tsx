import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import { ChatContextService, ChatState, AttachedFile } from './ChatContext';
import { Agent } from '../constants';

interface ChatContextType extends ChatState {
  sendMessage: (content: string, attachedFile?: AttachedFile | null) => Promise<void>;
  clearChat: () => void;
  setSelectedModel: (modelId: string) => void;
}

const ChatContext = createContext<ChatContextType | undefined>(undefined);

export { AttachedFile };

interface ChatProviderProps {
  children: React.ReactNode;
  agent: Agent;
  geminiApiKey: string;
  theme: any;
}

export const ChatProvider: React.FC<ChatProviderProps> = ({
  children,
  agent,
  geminiApiKey,
  theme,
}) => {
  const serviceRef = useRef<ChatContextService | null>(null);
  const [chatState, setChatState] = useState<ChatState | null>(null);

  useEffect(() => {
    // Initialize chat service
    serviceRef.current = new ChatContextService(agent, geminiApiKey, theme);

    // Subscribe to state changes
    const unsubscribe = serviceRef.current.subscribe(setChatState);

    // Set initial state
    setChatState(serviceRef.current.getState());

    return () => {
      unsubscribe();
      serviceRef.current?.destroy();
    };
  }, [agent, geminiApiKey, theme]);

  if (!chatState || !serviceRef.current) {
    return <ChatContext.Provider value={undefined}>{children}</ChatContext.Provider>;
  }

  return (
    <ChatContext.Provider
      value={{
        ...chatState,
        sendMessage: serviceRef.current.sendMessage.bind(serviceRef.current),
        clearChat: serviceRef.current.clearChat.bind(serviceRef.current),
        setSelectedModel: serviceRef.current.setSelectedModel.bind(serviceRef.current),
      }}
    >
      {children}
    </ChatContext.Provider>
  );
};

export const useChat = () => {
  const context = useContext(ChatContext);
  if (!context) {
    throw new Error('useChat must be used within a ChatProvider');
  }
  return context;
};
