/**
 * 🔌 WebSocket Context
 * Real-time communication and live updates
 */

import React, { createContext, useContext, useEffect, useState, useRef, ReactNode } from 'react';

interface WebSocketMessage {
  id: string;
  type: string;
  data: any;
  timestamp: Date;
}

interface WebSocketContextType {
  isConnected: boolean;
  isConnecting: boolean;
  error: string | null;
  send: (type: string, data: any) => void;
  subscribe: (type: string, handler: (data: any) => void) => () => void;
  lastMessage: WebSocketMessage | null;
  connectionCount: number;
}

const WebSocketContext = createContext<WebSocketContextType | undefined>(undefined);

export const useWebSocket = () => {
  const context = useContext(WebSocketContext);
  if (!context) {
    throw new Error('useWebSocket must be used within WebSocketProvider');
  }
  return context;
};

interface WebSocketProviderProps {
  children: ReactNode;
  url?: string;
  autoReconnect?: boolean;
  reconnectInterval?: number;
  maxReconnectAttempts?: number;
}

export const WebSocketProvider: React.FC<WebSocketProviderProps> = ({
  children,
  url = '/ws',
  autoReconnect = true,
  reconnectInterval = 3000,
  maxReconnectAttempts = 5,
}) => {
  const [isConnected, setIsConnected] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lastMessage, setLastMessage] = useState<WebSocketMessage | null>(null);
  const [connectionCount, setConnectionCount] = useState(0);

  const wsRef = useRef<WebSocket | null>(null);
  const reconnectAttemptsRef = useRef(0);
  const subscriptionsRef = useRef<Map<string, Set<(data: any) => void>>>(new Map());
  const reconnectTimeoutRef = useRef<NodeJS.Timeout>();

  const getWebSocketUrl = () => {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const host = window.location.host;
    return `${protocol}//${host}${url}`;
  };

  const connect = () => {
    if (isConnecting || isConnected) return;

    setIsConnecting(true);
    setError(null);

    try {
      const wsUrl = getWebSocketUrl();
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onopen = () => {
        setIsConnected(true);
        setIsConnecting(false);
        setError(null);
        reconnectAttemptsRef.current = 0;
        setConnectionCount(prev => prev + 1);

        console.log('WebSocket connected');
      };

      ws.onmessage = event => {
        try {
          const message: WebSocketMessage = {
            id: Date.now().toString(),
            ...JSON.parse(event.data),
            timestamp: new Date(),
          };

          setLastMessage(message);

          // Notify subscribers
          const handlers = subscriptionsRef.current.get(message.type);
          if (handlers) {
            handlers.forEach(handler => handler(message.data));
          }
        } catch (error) {
          console.error('Failed to parse WebSocket message:', error);
        }
      };

      ws.onclose = event => {
        setIsConnected(false);
        setIsConnecting(false);
        wsRef.current = null;

        if (
          !event.wasClean &&
          autoReconnect &&
          reconnectAttemptsRef.current < maxReconnectAttempts
        ) {
          const delay = reconnectInterval * Math.pow(2, reconnectAttemptsRef.current);
          reconnectAttemptsRef.current++;

          setError(
            `Connection lost. Reconnecting in ${delay / 1000}s... (${reconnectAttemptsRef.current}/${maxReconnectAttempts})`
          );

          reconnectTimeoutRef.current = setTimeout(() => {
            connect();
          }, delay);
        } else if (reconnectAttemptsRef.current >= maxReconnectAttempts) {
          setError('Connection failed. Maximum reconnection attempts reached.');
        }
      };

      ws.onerror = error => {
        console.error('WebSocket error:', error);
        setError('Connection error occurred');
      };
    } catch (error) {
      setIsConnecting(false);
      setError('Failed to establish WebSocket connection');
      console.error('WebSocket connection error:', error);
    }
  };

  const disconnect = () => {
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
    }

    if (wsRef.current) {
      wsRef.current.close(1000, 'User disconnected');
      wsRef.current = null;
    }

    setIsConnected(false);
    setIsConnecting(false);
  };

  const send = (type: string, data: any) => {
    if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) {
      console.warn('WebSocket not connected. Cannot send message:', { type, data });
      return;
    }

    try {
      wsRef.current.send(JSON.stringify({ type, data }));
    } catch (error) {
      console.error('Failed to send WebSocket message:', error);
    }
  };

  const subscribe = (type: string, handler: (data: any) => void) => {
    if (!subscriptionsRef.current.has(type)) {
      subscriptionsRef.current.set(type, new Set());
    }

    subscriptionsRef.current.get(type)!.add(handler);

    // Return unsubscribe function
    return () => {
      const handlers = subscriptionsRef.current.get(type);
      if (handlers) {
        handlers.delete(handler);
        if (handlers.size === 0) {
          subscriptionsRef.current.delete(type);
        }
      }
    };
  };

  useEffect(() => {
    connect();

    return () => {
      disconnect();
    };
  }, []);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
      disconnect();
    };
  }, []);

  const value: WebSocketContextType = {
    isConnected,
    isConnecting,
    error,
    send,
    subscribe,
    lastMessage,
    connectionCount,
  };

  return <WebSocketContext.Provider value={value}>{children}</WebSocketContext.Provider>;
};

export default WebSocketContext;
