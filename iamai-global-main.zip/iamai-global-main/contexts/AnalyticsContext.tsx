/**
 * 📊 Analytics Context
 * Event tracking and user behavior analytics
 */

import React, { createContext, useContext, useEffect, useRef, ReactNode } from 'react';

export interface AnalyticsEvent {
  name: string;
  properties?: Record<string, any>;
  userId?: string;
  sessionId?: string;
  timestamp?: Date;
}

interface AnalyticsContextType {
  track: (event: string, properties?: Record<string, any>) => void;
  identify: (userId: string, traits?: Record<string, any>) => void;
  page: (name?: string, properties?: Record<string, any>) => void;
  group: (groupId: string, traits?: Record<string, any>) => void;
  alias: (userId: string, previousId?: string) => void;
  reset: () => void;
  isReady: boolean;
}

const AnalyticsContext = createContext<AnalyticsContextType | undefined>(undefined);

export const useAnalytics = () => {
  const context = useContext(AnalyticsContext);
  if (!context) {
    throw new Error('useAnalytics must be used within AnalyticsProvider');
  }
  return context;
};

interface AnalyticsProviderProps {
  children: ReactNode;
  writeKey?: string;
  debug?: boolean;
  flushAt?: number;
  flushInterval?: number;
}

export const AnalyticsProvider: React.FC<AnalyticsProviderProps> = ({
  children,
  writeKey,
  debug = false,
  flushAt = 20,
  flushInterval = 10000,
}) => {
  const sessionId = useRef<string>(generateSessionId());
  const userId = useRef<string | null>(null);
  const eventQueue = useRef<AnalyticsEvent[]>([]);
  const isReady = useRef<boolean>(false);
  const flushTimer = useRef<NodeJS.Timeout>();

  // Generate unique session ID
  function generateSessionId(): string {
    return `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  // Queue event for batch processing
  const queueEvent = (event: AnalyticsEvent) => {
    event.sessionId = sessionId.current;
    event.userId = userId.current || undefined;
    event.timestamp = new Date();

    eventQueue.current.push(event);

    if (debug) {
      console.log('Analytics Event:', event);
    }

    // Flush if queue is full
    if (eventQueue.current.length >= flushAt) {
      flushEvents();
    }
  };

  // Send events to analytics endpoint
  const flushEvents = async () => {
    if (eventQueue.current.length === 0) return;

    const events = [...eventQueue.current];
    eventQueue.current = [];

    try {
      const response = await fetch('/api/analytics/events', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ events }),
      });

      if (!response.ok) {
        throw new Error(`Analytics flush failed: ${response.statusText}`);
      }

      if (debug) {
        console.log(`Analytics: Flushed ${events.length} events`);
      }
    } catch (error) {
      console.error('Analytics flush error:', error);
      // Re-queue events on failure
      eventQueue.current.unshift(...events);
    }
  };

  // Track custom events
  const track = (event: string, properties?: Record<string, any>) => {
    queueEvent({
      name: event,
      properties: {
        ...properties,
        page: window.location.pathname,
        referrer: document.referrer,
        userAgent: navigator.userAgent,
      },
    });
  };

  // Identify user
  const identify = (newUserId: string, traits?: Record<string, any>) => {
    userId.current = newUserId;

    queueEvent({
      name: 'identify',
      properties: {
        userId: newUserId,
        traits,
      },
    });
  };

  // Track page views
  const page = (name?: string, properties?: Record<string, any>) => {
    const pageName = name || document.title || window.location.pathname;

    queueEvent({
      name: 'page_view',
      properties: {
        page: pageName,
        path: window.location.pathname,
        search: window.location.search,
        hash: window.location.hash,
        title: document.title,
        ...properties,
      },
    });
  };

  // Group user
  const group = (groupId: string, traits?: Record<string, any>) => {
    queueEvent({
      name: 'group',
      properties: {
        groupId,
        traits,
      },
    });
  };

  // Alias user
  const alias = (newUserId: string, previousId?: string) => {
    queueEvent({
      name: 'alias',
      properties: {
        userId: newUserId,
        previousId: previousId || userId.current,
      },
    });

    userId.current = newUserId;
  };

  // Reset analytics state
  const reset = () => {
    userId.current = null;
    sessionId.current = generateSessionId();
    eventQueue.current = [];

    queueEvent({
      name: 'reset',
      properties: {},
    });
  };

  // Initialize analytics
  useEffect(() => {
    isReady.current = true;

    // Track initial page view
    page();

    // Set up periodic flush
    flushTimer.current = setInterval(flushEvents, flushInterval);

    // Track page visibility changes
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'hidden') {
        flushEvents();
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);

    // Track beforeunload to flush remaining events
    const handleBeforeUnload = () => {
      flushEvents();
    };

    window.addEventListener('beforeunload', handleBeforeUnload);

    return () => {
      if (flushTimer.current) {
        clearInterval(flushTimer.current);
      }

      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('beforeunload', handleBeforeUnload);

      // Final flush
      flushEvents();
    };
  }, []);

  // Auto-track route changes
  useEffect(() => {
    const originalPushState = window.history.pushState;
    const originalReplaceState = window.history.replaceState;

    window.history.pushState = function (...args) {
      originalPushState.apply(window.history, args);
      page();
    };

    window.history.replaceState = function (...args) {
      originalReplaceState.apply(window.history, args);
      page();
    };

    window.addEventListener('popstate', () => page());

    return () => {
      window.history.pushState = originalPushState;
      window.history.replaceState = originalReplaceState;
      window.removeEventListener('popstate', () => page());
    };
  }, []);

  const value: AnalyticsContextType = {
    track,
    identify,
    page,
    group,
    alias,
    reset,
    isReady: isReady.current,
  };

  return <AnalyticsContext.Provider value={value}>{children}</AnalyticsContext.Provider>;
};

export default AnalyticsContext;
