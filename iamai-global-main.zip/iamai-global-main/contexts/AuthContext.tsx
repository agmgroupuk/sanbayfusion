import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { authService as authContextService } from '../services/authService';

// Define types locally
interface User {
  id: string;
  email: string;
  name: string;
}

interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
}

interface AuthContextType extends AuthState {
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  register: (email: string, password: string, name: string) => Promise<void>;
  updateUser: (updates: Partial<User>) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [authState, setAuthState] = useState<AuthState>(authContextService.getState());

  useEffect(() => {
    // Subscribe to auth state changes
    const unsubscribe = authContextService.subscribe(setAuthState);
    return unsubscribe;
  }, []);

  return (
    <AuthContext.Provider
      value={{
        ...authState,
        login: authContextService.login.bind(authContextService),
        logout: authContextService.logout.bind(authContextService),
        register: authContextService.register.bind(authContextService),
        updateUser: authContextService.updateUser.bind(authContextService),
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};
