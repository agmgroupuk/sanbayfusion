import React, { createContext, useContext, ReactNode } from 'react';
import { Agent } from '../constants';
import { agentService } from '../services/agentService';
import { useApp } from './AppContext';

interface AgentContextType {
  agents: Agent[];
  selectedAgent: Agent | null;
  selectAgent: (agent: Agent) => void;
  addAgent: (agent: Agent) => void;
  updateAgent: (agent: Agent) => void;
  deleteAgent: (agentId: string) => void;
  subscriptions: Record<string, string>;
  subscribe: (agentName: string, tier: string) => void;
  unsubscribe: (agentName: string) => void;
}

const AgentContext = createContext<AgentContextType | undefined>(undefined);

export const useAgents = () => {
  const context = useContext(AgentContext);
  if (!context) {
    throw new Error('useAgents must be used within an AgentProvider');
  }
  return context;
};

interface AgentProviderProps {
  children: ReactNode;
}

export const AgentProvider: React.FC<AgentProviderProps> = ({ children }) => {
  const { state, setState } = useApp();

  const agents = agentService.getAgents(state);
  const selectedAgent = agentService.getSelectedAgent(state);
  const subscriptions = agentService.getSubscriptions(state);

  const selectAgent = (agent: Agent) => {
    agentService.setSelectedAgent(setState, agent);
  };

  const addAgent = (agent: Agent) => {
    agentService.addAgent(setState, agent);
  };

  const updateAgent = (agent: Agent) => {
    agentService.updateAgent(setState, agent);
  };

  const deleteAgent = (agentId: string) => {
    agentService.deleteAgent(setState, agentId);
  };

  const subscribe = (agentName: string, tier: string) => {
    agentService.subscribe(setState, agentName, tier);
  };

  const unsubscribe = (agentName: string) => {
    agentService.unsubscribe(setState, agentName);
  };

  return (
    <AgentContext.Provider
      value={{
        agents,
        selectedAgent,
        selectAgent,
        addAgent,
        updateAgent,
        deleteAgent,
        subscriptions,
        subscribe,
        unsubscribe,
      }}
    >
      {children}
    </AgentContext.Provider>
  );
};
