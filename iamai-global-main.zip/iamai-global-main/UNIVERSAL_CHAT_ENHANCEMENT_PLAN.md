# Universal Chat System - Complete Architecture & Enhancement Plan

> **Document Created:** January 3, 2026  
> **Last Updated:** January 3, 2026  
> **Purpose:** Complete END-TO-END architecture covering Frontend, Backend, Database, and Data Flow

---

# PART 1: FULL SYSTEM ARCHITECTURE

---

## 🔄 Complete Data Flow Diagram

```
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│                                    USER BROWSER                                          │
│  ┌─────────────────────────────────────────────────────────────────────────────────┐    │
│  │                         FRONTEND (React + Vite)                                  │    │
│  │                                                                                  │    │
│  │  ┌──────────────────────┐     ┌──────────────────────┐     ┌────────────────┐   │    │
│  │  │  UniversalAgentChat  │────▶│  realtimeChatService │────▶│   fetch()      │   │    │
│  │  │  (React Component)   │     │  (API Client)        │     │   API calls    │   │    │
│  │  └──────────────────────┘     └──────────────────────┘     └───────┬────────┘   │    │
│  │           │                            │                           │            │    │
│  │           ▼                            ▼                           │            │    │
│  │  ┌──────────────────────┐     ┌──────────────────────┐             │            │    │
│  │  │  CanvasMode          │     │  localStorage        │             │            │    │
│  │  │  (Code Editor)       │     │  (Theme, Settings)   │             │            │    │
│  │  └──────────────────────┘     └──────────────────────┘             │            │    │
│  └────────────────────────────────────────────────────────────────────┼────────────┘    │
└───────────────────────────────────────────────────────────────────────┼─────────────────┘
                                                                        │
                                    HTTPS / API                         │
                                                                        ▼
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│                              BACKEND (Node.js + Express)                                 │
│                              EC2: 47.130.177.218:3001                                   │
│  ┌─────────────────────────────────────────────────────────────────────────────────┐    │
│  │                              production-server.js                                │    │
│  │                                                                                  │    │
│  │  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐                  │    │
│  │  │ /api/ai/chat    │  │ /api/chat/*     │  │ /api/canvas/*   │                  │    │
│  │  │ (AI responses)  │  │ (Sessions)      │  │ (Code gen)      │                  │    │
│  │  └────────┬────────┘  └────────┬────────┘  └────────┬────────┘                  │    │
│  │           │                    │                    │                           │    │
│  │           ▼                    ▼                    ▼                           │    │
│  │  ┌─────────────────────────────────────────────────────────────────────────┐   │    │
│  │  │                        ai-service.js                                     │   │    │
│  │  │   ┌───────────┐ ┌───────────┐ ┌───────────┐ ┌───────────┐ ┌───────────┐ │   │    │
│  │  │   │  Mistral  │ │  Gemini   │ │  OpenAI   │ │ Anthropic │ │   Groq    │ │   │    │
│  │  │   └───────────┘ └───────────┘ └───────────┘ └───────────┘ └───────────┘ │   │    │
│  │  └─────────────────────────────────────────────────────────────────────────┘   │    │
│  │                                      │                                          │    │
│  │                                      ▼                                          │    │
│  │  ┌─────────────────────────────────────────────────────────────────────────┐   │    │
│  │  │                          Mongoose Models                                 │   │    │
│  │  │   User │ ChatSession │ ChatMessage │ FileUpload │ CanvasProject         │   │    │
│  │  └────────────────────────────────────────────────────────────────────────┬┘   │    │
│  └───────────────────────────────────────────────────────────────────────────┼────┘    │
└──────────────────────────────────────────────────────────────────────────────┼─────────┘
                                                                               │
                                    MongoDB Atlas                              │
                                                                               ▼
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│                              DATABASE (MongoDB Atlas)                                    │
│                              Database: iamai-global                                      │
│  ┌─────────────────────────────────────────────────────────────────────────────────┐    │
│  │                                Collections                                       │    │
│  │                                                                                  │    │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────────┐ │    │
│  │  │   users     │  │   agents    │  │   chats     │  │   chat_sessions         │ │    │
│  │  └─────────────┘  └─────────────┘  └─────────────┘  └─────────────────────────┘ │    │
│  │                                                                                  │    │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────────┐ │    │
│  │  │chat_messages│  │file_uploads │  │canvas_proj  │  │   activity_logs         │ │    │
│  │  └─────────────┘  └─────────────┘  └─────────────┘  └─────────────────────────┘ │    │
│  └─────────────────────────────────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## 📁 Frontend Architecture

```
components/universal-chat/
├── UniversalAgentChat.tsx      # Main chat component (748 lines)
├── EnhancedChatLayout.tsx      # Layout wrapper with sidebars (357 lines)
├── ChatSessionSidebar.tsx      # Left sidebar - session management
├── ChatSettingsPanel.tsx       # Settings panel - AI configuration
├── ChatRightPanel.tsx          # Right panel - Canvas trigger
├── QuickActionsPanel.tsx       # Quick action buttons
├── CanvasMode.tsx              # Full-screen code editor (622 lines)
├── realtimeChatService.ts      # API service for AI chat (218 lines)
├── aiProviders.ts              # AI provider configurations
├── types.ts                    # TypeScript definitions
└── index.ts                    # Clean exports
```

---

# PART 2: BACKEND ARCHITECTURE

---

## 📂 Backend File Structure

```
backend/
├── production-server.js         # Main Express server (Entry point)
├── database.js                  # MongoDB connection (Mongoose)
├── ai-service.js                # Multi-provider AI service
├── models.cjs                   # Main Mongoose models (2704 lines)
├── content-models.js            # Content-related schemas
│
├── routes/                      # API Endpoints
│   ├── chat-sessions.js         # Chat session CRUD (496 lines)
│   ├── canvas.js                # Canvas project APIs (479 lines)
│   ├── aiRoutes.js              # AI chat endpoints
│   ├── authRoutes.js            # Authentication
│   ├── purchaseRoutes.js        # Stripe purchases
│   ├── stripeRoutes.js          # Stripe webhooks
│   └── ...
│
├── middleware/                  # Express middleware
│   ├── auth.js                  # JWT authentication
│   └── ...
│
└── uploads/                     # File upload storage
```

---

## 🌐 API Endpoints Reference

### Chat Session APIs (`/api/chat/sessions`)

| Method | Endpoint                                        | Description               | Auth Required |
| ------ | ----------------------------------------------- | ------------------------- | ------------- |
| GET    | `/api/chat/sessions/:userId`                    | Get all sessions for user | Yes           |
| POST   | `/api/chat/sessions`                            | Create new session        | Yes           |
| PUT    | `/api/chat/sessions/:sessionId`                 | Update session (rename)   | Yes           |
| DELETE | `/api/chat/sessions/:sessionId`                 | Delete session            | Yes           |
| GET    | `/api/chat/sessions/:sessionId/messages`        | Get messages in session   | Yes           |
| POST   | `/api/chat/sessions/:sessionId/messages`        | Add message to session    | Yes           |
| DELETE | `/api/chat/sessions/:sessionId/messages/:msgId` | Delete message            | Yes           |

### File Upload APIs (`/api/chat/upload`)

| Method | Endpoint                  | Description                | Auth Required |
| ------ | ------------------------- | -------------------------- | ------------- |
| POST   | `/api/chat/upload`        | Upload file to chat        | Yes           |
| GET    | `/api/chat/files/:userId` | List user's uploaded files | Yes           |
| DELETE | `/api/chat/files/:fileId` | Delete uploaded file       | Yes           |

### Canvas APIs (`/api/canvas`)

| Method | Endpoint                         | Description           | Auth Required |
| ------ | -------------------------------- | --------------------- | ------------- |
| POST   | `/api/canvas/generate`           | AI code generation    | Yes           |
| POST   | `/api/canvas/save`               | Save canvas project   | Yes           |
| GET    | `/api/canvas/projects/:userId`   | Get user's projects   | Yes           |
| GET    | `/api/canvas/project/:projectId` | Get single project    | Yes           |
| DELETE | `/api/canvas/project/:projectId` | Delete project        | Yes           |
| GET    | `/api/canvas/templates`          | Get project templates | No            |

### AI Chat APIs (`/api/ai`)

| Method | Endpoint              | Description                   | Auth Required |
| ------ | --------------------- | ----------------------------- | ------------- |
| POST   | `/api/ai/chat`        | Send message, get AI response | Yes           |
| POST   | `/api/ai/chat/stream` | Streaming AI response (SSE)   | Yes           |
| GET    | `/api/ai/models`      | Get available AI models       | No            |

---

## 🔄 Backend Data Flow Diagrams

### Chat Message Flow

```
┌──────────────────────────────────────────────────────────────────────────────────┐
│                           CHAT MESSAGE DATA FLOW                                  │
└──────────────────────────────────────────────────────────────────────────────────┘

User types message
       │
       ▼
┌─────────────────────┐
│ UniversalAgentChat  │
│ handleSubmit()      │
└─────────┬───────────┘
          │
          ▼
┌─────────────────────┐
│ realtimeChatService │
│ sendMessage()       │
└─────────┬───────────┘
          │
          │ POST /api/ai/chat
          │ Body: { message, agentId, conversationHistory, settings }
          ▼
┌──────────────────────────────────────────────────────────────────┐
│                        BACKEND                                    │
│  ┌────────────────────────────────────────────────────────────┐  │
│  │  production-server.js → aiRoutes.js → ai-service.js        │  │
│  │                                                             │  │
│  │  1. Validate request                                        │  │
│  │  2. Get agent system prompt from database                   │  │
│  │  3. Select AI provider (Mistral, Gemini, OpenAI, etc.)     │  │
│  │  4. Send to AI API with context                            │  │
│  │  5. Receive response                                        │  │
│  │  6. Return { message: "AI response text" }                 │  │
│  └────────────────────────────────────────────────────────────┘  │
└────────────────────────┬─────────────────────────────────────────┘
                         │
                         │ Response: { message, tokens_used, model }
                         ▼
┌─────────────────────┐
│ UniversalAgentChat  │
│ Update messages[]   │
│ Auto-scroll         │
└─────────────────────┘
```

### Session Persistence Flow

```
┌──────────────────────────────────────────────────────────────────────────────────┐
│                        SESSION PERSISTENCE DATA FLOW                              │
└──────────────────────────────────────────────────────────────────────────────────┘

User clicks "New Chat"
       │
       ▼
┌─────────────────────┐        POST /api/chat/sessions
│ ChatSessionSidebar  │ ─────────────────────────────────────────────▶
│ createSession()     │        Body: { userId, title, agentId }
└─────────────────────┘                                               │
                                                                      ▼
                               ┌────────────────────────────────────────────────────┐
                               │                     BACKEND                         │
                               │  chat-sessions.js → ChatSession.create()           │
                               │                                                     │
                               │  Creates in MongoDB:                                │
                               │  {                                                  │
                               │    _id: ObjectId("..."),                           │
                               │    userId: ObjectId("..."),                        │
                               │    title: "New Conversation",                      │
                               │    agentId: "agent-123",                           │
                               │    messages: [],                                   │
                               │    createdAt: Date,                                │
                               │    updatedAt: Date                                 │
                               │  }                                                  │
                               └────────────────────────────────────────────────────┘
                                                                      │
                               Response: { sessionId, title, createdAt }
                                                                      │
       ◀──────────────────────────────────────────────────────────────┘
       │
       ▼
┌─────────────────────┐
│ Update sessions[]   │
│ Switch to new chat  │
└─────────────────────┘
```

### File Upload Flow

```
┌──────────────────────────────────────────────────────────────────────────────────┐
│                           FILE UPLOAD DATA FLOW                                   │
└──────────────────────────────────────────────────────────────────────────────────┘

User clicks 📎 attachment button
       │
       ▼
┌─────────────────────┐
│ <input type="file"> │
│ onChange handler    │
└─────────┬───────────┘
          │
          │  File selected (image, PDF, etc.)
          ▼
┌─────────────────────┐
│ FormData created    │
│ file + userId       │
└─────────┬───────────┘
          │
          │  POST /api/chat/upload
          │  Content-Type: multipart/form-data
          ▼
┌──────────────────────────────────────────────────────────────────┐
│                        BACKEND                                    │
│  ┌────────────────────────────────────────────────────────────┐  │
│  │  chat-sessions.js                                           │  │
│  │                                                             │  │
│  │  1. multer middleware processes file                        │  │
│  │  2. Save to /backend/uploads/{timestamp}_{filename}        │  │
│  │  3. Create FileUpload document in MongoDB:                  │  │
│  │     {                                                       │  │
│  │       userId: ObjectId,                                     │  │
│  │       filename: "timestamp_file.png",                       │  │
│  │       originalName: "my-image.png",                         │  │
│  │       mimeType: "image/png",                                │  │
│  │       size: 102400,                                         │  │
│  │       path: "/uploads/timestamp_file.png",                  │  │
│  │       url: "https://api.iamai.global/uploads/..."           │  │
│  │     }                                                       │  │
│  │  4. Return { fileId, url, filename }                        │  │
│  └────────────────────────────────────────────────────────────┘  │
└────────────────────────┬─────────────────────────────────────────┘
                         │
                         │ Response: { fileId, url, filename }
                         ▼
┌─────────────────────────────────────────────────┐
│ Frontend displays preview                        │
│ Includes file URL in next message to AI         │
│ "Analyze this image: [uploaded image URL]"      │
└─────────────────────────────────────────────────┘
```

### Canvas Project Save Flow

```
┌──────────────────────────────────────────────────────────────────────────────────┐
│                        CANVAS PROJECT SAVE DATA FLOW                              │
└──────────────────────────────────────────────────────────────────────────────────┘

User clicks "Save Project" in Canvas
       │
       ▼
┌─────────────────────┐
│ CanvasMode.tsx      │
│ saveProject()       │
└─────────┬───────────┘
          │
          │  Collect all tabs/files
          │  { name: "app.js", content: "...", language: "javascript" }
          ▼
┌─────────────────────┐
│ Prepare payload     │
│ {                   │
│   userId,           │
│   projectName,      │
│   files: [...]      │
│ }                   │
└─────────┬───────────┘
          │
          │  POST /api/canvas/save
          ▼
┌──────────────────────────────────────────────────────────────────┐
│                        BACKEND                                    │
│  ┌────────────────────────────────────────────────────────────┐  │
│  │  canvas.js                                                  │  │
│  │                                                             │  │
│  │  1. Validate project data                                   │  │
│  │  2. Create/Update CanvasProject in MongoDB:                │  │
│  │     {                                                       │  │
│  │       _id: ObjectId,                                        │  │
│  │       userId: ObjectId,                                     │  │
│  │       name: "My Project",                                   │  │
│  │       files: [                                              │  │
│  │         { name: "index.html", content: "...", lang: "html" }│  │
│  │         { name: "app.js", content: "...", lang: "js" }      │  │
│  │       ],                                                    │  │
│  │       chatHistory: [...],                                   │  │
│  │       createdAt: Date,                                      │  │
│  │       updatedAt: Date                                       │  │
│  │     }                                                       │  │
│  │  3. Return { projectId, savedAt }                           │  │
│  └────────────────────────────────────────────────────────────┘  │
└────────────────────────┬─────────────────────────────────────────┘
                         │
                         │ Response: { projectId, savedAt }
                         ▼
┌─────────────────────────────────────────────────┐
│ Show success notification                        │
│ Update project list if visible                   │
└─────────────────────────────────────────────────┘
```

---

# PART 3: DATABASE ARCHITECTURE

---

## 🗄️ MongoDB Collections Overview

```
Database: iamai-global
├── users                    # User accounts & profiles
├── agents                   # AI agent configurations
├── agent_purchases          # User purchases of agents
├── chats                    # Legacy chat storage
├── chat_sessions            # Chat session metadata
├── chat_messages            # Individual messages
├── file_uploads             # Uploaded file metadata
├── canvas_projects          # Saved Canvas projects
├── activity_logs            # User activity tracking
├── transactions             # Payment records
├── webhook_events           # Stripe webhooks
├── visitors                 # Analytics data
└── rewards                  # User rewards system
```

---

## 📋 Collection Schemas (Detailed)

### users Collection

```javascript
{
  _id: ObjectId,
  email: String,                    // Required, unique
  password: String,                 // Hashed with bcrypt
  name: String,
  username: String,
  avatar: String,                   // URL to avatar image

  // Authentication
  googleId: String,                 // For Google OAuth
  appleId: String,                  // For Apple OAuth
  emailVerified: Boolean,
  verificationToken: String,
  resetPasswordToken: String,
  resetPasswordExpires: Date,

  // Profile
  bio: String,
  location: String,
  website: String,
  timezone: String,
  language: String,                 // Default: "en"

  // Preferences
  preferences: {
    theme: String,                  // "light" | "dark" | "neural"
    notifications: {
      email: Boolean,
      push: Boolean,
      marketing: Boolean
    },
    defaultAgent: ObjectId,
    chatSettings: {
      temperature: Number,          // 0.0 - 2.0
      maxTokens: Number,           // 100 - 8000
      defaultProvider: String
    }
  },

  // Stripe Integration
  stripeCustomerId: String,
  stripeSubscriptionId: String,
  subscriptionStatus: String,       // "active" | "canceled" | "past_due"
  subscriptionPlan: String,

  // Timestamps
  createdAt: Date,
  updatedAt: Date,
  lastLoginAt: Date,

  // Security
  twoFactorEnabled: Boolean,
  twoFactorSecret: String
}
```

### chat_sessions Collection

```javascript
{
  _id: ObjectId,
  userId: ObjectId,                 // Reference to users collection
  agentId: String,                  // Agent identifier

  // Session Info
  title: String,                    // Default: "New Conversation"
  description: String,

  // Status
  status: String,                   // "active" | "archived" | "deleted"
  isPinned: Boolean,

  // Settings (per-session)
  settings: {
    temperature: Number,
    maxTokens: Number,
    provider: String,
    model: String,
    systemPrompt: String
  },

  // Metadata
  messageCount: Number,
  lastMessageAt: Date,

  // Timestamps
  createdAt: Date,
  updatedAt: Date
}

// Indexes
{ userId: 1, createdAt: -1 }        // Query user sessions
{ userId: 1, status: 1 }            // Filter active sessions
```

### chat_messages Collection

```javascript
{
  _id: ObjectId,
  sessionId: ObjectId,              // Reference to chat_sessions
  userId: ObjectId,                 // Who sent this message

  // Message Content
  role: String,                     // "user" | "assistant" | "system"
  content: String,                  // The message text

  // Attachments
  attachments: [{
    type: String,                   // "image" | "file" | "code"
    url: String,
    filename: String,
    mimeType: String,
    size: Number
  }],

  // Code Blocks (extracted)
  codeBlocks: [{
    language: String,
    code: String,
    filename: String
  }],

  // AI Response Metadata
  metadata: {
    model: String,                  // "mistral-large" etc.
    provider: String,               // "mistral" | "openai" etc.
    tokensUsed: Number,
    responseTime: Number,           // milliseconds
    finishReason: String           // "stop" | "length" | "error"
  },

  // User Feedback
  feedback: {
    rating: String,                 // "positive" | "negative"
    comment: String,
    reportedAt: Date
  },

  // Timestamps
  createdAt: Date,
  editedAt: Date,
  deletedAt: Date                   // Soft delete
}

// Indexes
{ sessionId: 1, createdAt: 1 }      // Load messages in order
{ userId: 1, createdAt: -1 }        // User's recent messages
```

### file_uploads Collection

```javascript
{
  _id: ObjectId,
  userId: ObjectId,
  sessionId: ObjectId,              // Optional: which chat session

  // File Info
  filename: String,                 // Stored filename (with timestamp)
  originalName: String,             // User's original filename
  mimeType: String,                 // "image/png", "application/pdf"
  size: Number,                     // Bytes

  // Storage
  path: String,                     // Local path: "/uploads/..."
  url: String,                      // Public URL

  // Processing
  processed: Boolean,               // If image was resized, etc.
  thumbnailUrl: String,             // For images
  extractedText: String,            // For PDFs/documents (OCR)

  // Status
  status: String,                   // "active" | "deleted"

  // Timestamps
  createdAt: Date,
  expiresAt: Date                   // Auto-cleanup after X days
}

// Indexes
{ userId: 1, createdAt: -1 }
{ sessionId: 1 }
{ expiresAt: 1 }                    // TTL index for cleanup
```

### canvas_projects Collection

```javascript
{
  _id: ObjectId,
  userId: ObjectId,

  // Project Info
  name: String,                     // "My React App"
  description: String,
  template: String,                 // "react" | "vanilla" | "vue"

  // Files
  files: [{
    id: String,                     // UUID for tab identification
    name: String,                   // "index.html"
    content: String,                // File contents
    language: String,               // "html" | "javascript" | "css"
    isEntry: Boolean,               // Is this the main file?
    order: Number                   // Tab order
  }],

  // Chat History (Canvas AI assistance)
  chatHistory: [{
    role: String,
    content: String,
    timestamp: Date
  }],

  // Collaboration (Future)
  isPublic: Boolean,
  sharedWith: [ObjectId],
  shareLink: String,

  // Status
  status: String,                   // "draft" | "published" | "archived"

  // Timestamps
  createdAt: Date,
  updatedAt: Date,
  lastOpenedAt: Date
}

// Indexes
{ userId: 1, updatedAt: -1 }
{ shareLink: 1 }                    // For shared project lookup
```

### agents Collection

```javascript
{
  _id: ObjectId,
  agentId: String,                  // Unique identifier like "agent-001"

  // Display Info
  name: String,                     // "Code Assistant"
  displayName: String,
  description: String,
  shortDescription: String,
  avatar: String,                   // URL
  coverImage: String,

  // Categorization
  category: String,                 // "coding" | "creative" | "assistant"
  tags: [String],

  // AI Configuration
  aiConfig: {
    provider: String,               // Default provider
    model: String,                  // Default model
    systemPrompt: String,           // Base personality/instructions
    temperature: Number,
    maxTokens: Number,

    // Advanced
    topP: Number,
    frequencyPenalty: Number,
    presencePenalty: Number
  },

  // Capabilities
  capabilities: {
    codeGeneration: Boolean,
    imageGeneration: Boolean,
    webSearch: Boolean,
    fileAnalysis: Boolean,
    voiceInput: Boolean,
    voiceOutput: Boolean
  },

  // Quick Actions
  quickActions: [{
    label: String,
    prompt: String,
    icon: String
  }],

  // Pricing
  pricing: {
    type: String,                   // "free" | "premium" | "subscription"
    price: Number,
    currency: String,
    stripePriceId: String
  },

  // Status
  status: String,                   // "active" | "beta" | "deprecated"
  isPublic: Boolean,
  isFeatured: Boolean,

  // Stats
  stats: {
    totalChats: Number,
    totalMessages: Number,
    averageRating: Number,
    totalUsers: Number
  },

  // Timestamps
  createdAt: Date,
  updatedAt: Date
}
```

---

## 🔗 Collection Relationships Diagram

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                        DATABASE RELATIONSHIPS                                    │
└─────────────────────────────────────────────────────────────────────────────────┘

                         ┌──────────────┐
                         │    users     │
                         │              │
                         │ _id ─────────┼─────────────────┐
                         │ email        │                 │
                         │ stripeId     │                 │
                         └──────┬───────┘                 │
                                │                         │
            ┌───────────────────┼───────────────────┬─────┴────────┐
            │                   │                   │              │
            ▼                   ▼                   ▼              ▼
     ┌──────────────┐   ┌──────────────┐   ┌──────────────┐ ┌──────────────┐
     │chat_sessions │   │canvas_projects│   │ file_uploads │ │agent_purchases│
     │              │   │              │   │              │ │              │
     │ userId ──────│   │ userId ──────│   │ userId ──────│ │ userId ──────│
     │ agentId      │   │ files[]      │   │ sessionId    │ │ agentId      │
     │ _id ─────────│   │ chatHistory  │   │ url          │ │ status       │
     └──────┬───────┘   └──────────────┘   └──────────────┘ └──────────────┘
            │
            │ sessionId
            ▼
     ┌──────────────┐
     │chat_messages │
     │              │
     │ sessionId ───│──▶ References chat_sessions._id
     │ userId ──────│──▶ References users._id
     │ attachments  │──▶ URLs from file_uploads
     │ codeBlocks   │
     │ feedback     │
     └──────────────┘

                         ┌──────────────┐
                         │   agents     │
                         │              │
                         │ agentId ─────┼─────────┐
                         │ aiConfig     │         │
                         │ pricing      │         │
                         └──────────────┘         │
                                                  │
                                                  ▼
                                        Referenced by:
                                        • chat_sessions.agentId
                                        • agent_purchases.agentId
```

---

# PART 4: FRONTEND COMPONENT ARCHITECTURE

---

## 🏗️ Component Relationship Diagram

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                           UniversalAgentChat (Main)                              │
│  ┌──────────────────────────────────────────────────────────────────────────┐   │
│  │                        EnhancedChatLayout                                 │   │
│  │  ┌─────────────┐  ┌──────────────────────────┐  ┌─────────────────────┐  │   │
│  │  │ Left Panel  │  │      Center (Chat)       │  │    Right Panel      │  │   │
│  │  │             │  │                          │  │                     │  │   │
│  │  │ ┌─────────┐ │  │  ┌──────────────────┐   │  │  ┌───────────────┐  │  │   │
│  │  │ │Sessions │ │  │  │  Message List    │   │  │  │ Canvas Btn    │  │  │   │
│  │  │ │Sidebar  │ │  │  │                  │   │  │  │               │  │  │   │
│  │  │ └─────────┘ │  │  │  - User msgs     │   │  │  │ Opens:        │  │  │   │
│  │  │             │  │  │  - AI responses  │   │  │  │ CanvasMode    │  │  │   │
│  │  │ ┌─────────┐ │  │  │  - Code blocks   │   │  │  │ (Full Screen) │  │  │   │
│  │  │ │Settings │ │  │  │  - Streaming     │   │  │  └───────────────┘  │  │   │
│  │  │ │Panel    │ │  │  └──────────────────┘   │  │                     │  │   │
│  │  │ └─────────┘ │  │                          │  │                     │  │   │
│  │  │             │  │  ┌──────────────────┐   │  │                     │  │   │
│  │  └─────────────┘  │  │  Quick Actions   │   │  └─────────────────────┘  │   │
│  │                   │  └──────────────────┘   │                            │   │
│  │                   │                          │                            │   │
│  │                   │  ┌──────────────────┐   │                            │   │
│  │                   │  │  Input Area      │   │                            │   │
│  │                   │  │  📎 🎤 ✉️        │   │                            │   │
│  │                   │  └──────────────────┘   │                            │   │
│  └───────────────────┴──────────────────────────┴────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────────────┘
```

---

## ✅ Existing Features (Already Built)

### 1. Chat Interface (UniversalAgentChat.tsx)

| Feature                | Status     | Description                           |
| ---------------------- | ---------- | ------------------------------------- |
| Multi-session chat     | ✅ Working | Create multiple conversation sessions |
| Message history        | ✅ Working | Messages stored in session state      |
| Real-time AI responses | ✅ Working | Connects to `/api/ai/chat`            |
| Code block detection   | ✅ Working | Extracts code from AI responses       |
| Message feedback       | ✅ Working | Thumbs up/down on messages            |
| Copy message           | ✅ Working | Copy message to clipboard             |
| Share message          | ✅ Working | Share functionality                   |
| Text-to-speech         | ✅ Working | Listen to AI responses                |
| Auto-scroll            | ✅ Working | Scrolls to new messages               |
| Loading states         | ✅ Working | Shows loading animation               |

### 2. Session Management (ChatSessionSidebar.tsx)

| Feature                  | Status     | Description                      |
| ------------------------ | ---------- | -------------------------------- |
| Create new session       | ✅ Working | "New Chat" button                |
| Rename session           | ✅ Working | Double-click to rename           |
| Delete session           | ✅ Working | Delete with confirmation         |
| Export session           | ✅ Working | Export as .txt file              |
| Session list             | ✅ Working | Shows all conversations          |
| Active session highlight | ✅ Working | Visual indicator                 |
| Message count            | ✅ Working | Shows message count per session  |
| Last updated time        | ✅ Working | Shows when last message was sent |

### 3. Settings Panel (ChatSettingsPanel.tsx)

| Feature            | Status     | Description                                 |
| ------------------ | ---------- | ------------------------------------------- |
| Temperature slider | ✅ Working | 0.0 to 2.0 range                            |
| Max tokens slider  | ✅ Working | 100 to 8000 range                           |
| AI Mode presets    | ✅ Working | Educational, Professional, Creative, Coding |
| Provider selection | ✅ Working | Mistral, Gemini, OpenAI, etc.               |
| Model selection    | ✅ Working | Model options per provider                  |
| System prompt      | ✅ Working | Custom system prompt input                  |
| Reset to defaults  | ✅ Working | Reset all settings                          |

### 4. Theme System (EnhancedChatLayout.tsx)

| Feature             | Status     | Description                      |
| ------------------- | ---------- | -------------------------------- |
| Default theme       | ✅ Working | Light, clean design              |
| Neural theme        | ✅ Working | Dark cyber theme with animations |
| Theme persistence   | ✅ Working | Saves to localStorage            |
| Theme toggle button | ✅ Working | Sun/Sparkles icon                |
| Mobile responsive   | ✅ Working | Adapts to screen size            |

### 5. Canvas Mode (CanvasMode.tsx) - 622 Lines!

| Feature             | Status     | Description                  |
| ------------------- | ---------- | ---------------------------- |
| Full-screen overlay | ✅ Working | Fixed position, z-50         |
| Code editor         | ✅ Working | Textarea with line numbers   |
| Multi-file tabs     | ✅ Working | Add, close, switch tabs      |
| Live preview        | ✅ Working | iframe for HTML/JS execution |
| Split view          | ✅ Working | Code + Preview side by side  |
| Run code            | ✅ Working | Execute JS/HTML in preview   |
| Copy code           | ✅ Working | Copy to clipboard            |
| Download code       | ✅ Working | Download as file             |
| AI chat panel       | ✅ Working | Collapsible left panel       |
| Language detection  | ✅ Working | Icon per file type           |
| Modified indicator  | ✅ Working | Shows unsaved changes        |
| Status bar          | ✅ Working | Language, line count         |

### 6. Quick Actions (QuickActionsPanel.tsx)

| Feature                | Status     | Description                |
| ---------------------- | ---------- | -------------------------- |
| Pre-built prompts      | ✅ Working | Quick action buttons       |
| Collapsible panel      | ✅ Working | Hide/show toggle           |
| Agent-specific actions | ✅ Working | Based on agent specialties |

### 7. AI Service (realtimeChatService.ts)

| Feature              | Status     | Description                                      |
| -------------------- | ---------- | ------------------------------------------------ |
| API integration      | ✅ Working | Connects to `/api/ai/chat`                       |
| Multiple providers   | ✅ Working | Mistral, Gemini, OpenAI, Anthropic, Cohere, Groq |
| Request cancellation | ✅ Working | AbortController support                          |
| Error handling       | ✅ Working | Try-catch with callbacks                         |
| Conversation history | ✅ Working | Sends last 10 messages                           |

---

## 🔧 UI Elements Status

### Input Area Buttons

| Button                 | UI Present | Functionality          |
| ---------------------- | ---------- | ---------------------- |
| Send (Paper airplane)  | ✅         | ✅ Working             |
| Microphone (Voice)     | ✅         | ⚠️ UI only - not wired |
| Attachment (Paperclip) | ✅         | ⚠️ UI only - not wired |
| Phone (Call)           | ✅         | ⚠️ UI only - not wired |

---

## 🚀 Enhancement Roadmap

### Phase 1: Wire Up Existing UI (Quick Wins)

```
Priority: HIGH | Effort: LOW | Impact: HIGH
```

#### 1.1 Voice Input (Microphone Button)

- **Current:** Button exists, not functional
- **Enhancement:** Add Web Speech API
- **Files to modify:** `UniversalAgentChat.tsx`
- **Implementation:**
  ```typescript
  const startVoiceRecording = () => {
    const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
    recognition.lang = 'en-US';
    recognition.onresult = event => {
      setInputValue(event.results[0][0].transcript);
    };
    recognition.start();
  };
  ```

#### 1.2 File Attachment

- **Current:** Button exists, not functional
- **Enhancement:** Allow image/file uploads
- **Files to modify:** `UniversalAgentChat.tsx`, Backend API
- **Implementation:**
  - Add file input ref (already exists)
  - Handle file selection
  - Upload to `/api/upload`
  - Include file URL in message

#### 1.3 Canvas AI Chat → Real API

- **Current:** Simulated responses in CanvasMode
- **Enhancement:** Connect to actual `/api/ai/chat`
- **Files to modify:** `CanvasMode.tsx`
- **Implementation:**
  - Import `realtimeChatService`
  - Replace setTimeout with actual API call
  - Add code generation prompts

---

### Phase 2: Feature Enhancements (Medium Effort)

```
Priority: MEDIUM | Effort: MEDIUM | Impact: HIGH
```

#### 2.1 Chat History Persistence

- **Current:** Sessions lost on refresh
- **Enhancement:** Save to MongoDB/localStorage
- **Files to create:** `chatHistoryService.ts`
- **Backend:** `/api/chat/sessions` CRUD endpoints

#### 2.2 True Streaming Responses

- **Current:** Full response returned at once
- **Enhancement:** Token-by-token streaming
- **Backend:** Use Server-Sent Events (SSE)
- **Frontend:** EventSource or fetch with reader

#### 2.3 Syntax Highlighting in Canvas

- **Current:** Plain textarea, no colors
- **Enhancement:** Code highlighting
- **Options:**
  - Option A: Use CSS for basic highlighting (no library)
  - Option B: Use existing Prism.js if already in project
- **Implementation:** Overlay div with highlighted code

#### 2.4 Message Search

- **Current:** No search functionality
- **Enhancement:** Search across all sessions
- **Files to modify:** `ChatSessionSidebar.tsx`
- **Implementation:** Filter messages by keyword

---

### Phase 3: Advanced Features (Higher Effort)

```
Priority: LOW | Effort: HIGH | Impact: MEDIUM
```

#### 3.1 File Tree in Canvas

- **Current:** Only tabs, no folder structure
- **Enhancement:** Full file tree sidebar
- **Implementation:** Nested folder component

#### 3.2 Project Save/Load

- **Current:** Code lost on close
- **Enhancement:** Save projects to backend
- **Backend:** `/api/canvas/projects` endpoints

#### 3.3 Share Project Link

- **Current:** No sharing
- **Enhancement:** Generate shareable URL
- **Implementation:** Save project, generate short link

#### 3.4 Multi-Agent Conversation

- **Current:** One agent per chat
- **Enhancement:** Switch agents mid-chat
- **Implementation:** Agent selector in chat header

#### 3.5 Image Generation

- **Current:** Text responses only
- **Enhancement:** AI image generation
- **Backend:** DALL-E/Stable Diffusion integration

---

## 📊 Feature Priority Matrix

```
                    LOW EFFORT          HIGH EFFORT
                ┌─────────────────┬─────────────────┐
    HIGH        │  ⭐ QUICK WINS  │  🎯 MAJOR       │
    IMPACT      │                 │     FEATURES    │
                │  • Voice Input  │  • Streaming    │
                │  • File Upload  │  • Persistence  │
                │  • Canvas API   │  • Syntax HL    │
                ├─────────────────┼─────────────────┤
    LOW         │  ✓ NICE TO      │  ⚠️ CONSIDER    │
    IMPACT      │    HAVE         │     LATER       │
                │                 │                 │
                │  • Search       │  • Multi-agent  │
                │  • Pin message  │  • File tree    │
                │                 │  • Sharing      │
                └─────────────────┴─────────────────┘
```

---

## 🛠️ Implementation Order (Recommended)

### Sprint 1: Quick Wins (1-2 days)

1. ✅ Wire voice input (Web Speech API)
2. ✅ Wire file attachment
3. ✅ Connect Canvas chat to real API

### Sprint 2: Core Enhancements (3-5 days)

4. ⬜ Add chat history persistence
5. ⬜ Implement true streaming
6. ⬜ Add basic syntax highlighting

### Sprint 3: Advanced Features (1-2 weeks)

7. ⬜ Message search
8. ⬜ Project save/load in Canvas
9. ⬜ File tree sidebar

### Sprint 4: Premium Features (Future)

10. ⬜ Multi-agent conversations
11. ⬜ Image generation
12. ⬜ Collaborative editing

---

## 🔌 Dependencies

### Current Stack (No Changes Needed)

- React 18.3.1
- TypeScript
- Tailwind CSS
- @heroicons/react
- Vite

### Optional Additions (If Needed)

- `prismjs` - Syntax highlighting (optional)
- No other libraries required

---

# PART 5: IMPLEMENTATION REFERENCE

---

## 📍 File Locations Quick Reference

### Frontend Files to Modify

| Feature         | File Path                                          | Lines      |
| --------------- | -------------------------------------------------- | ---------- |
| Chat UI         | `components/universal-chat/UniversalAgentChat.tsx` | 748 lines  |
| Canvas Editor   | `components/universal-chat/CanvasMode.tsx`         | 622 lines  |
| Layout Wrapper  | `components/universal-chat/EnhancedChatLayout.tsx` | 357 lines  |
| API Service     | `components/universal-chat/realtimeChatService.ts` | 218 lines  |
| Session Sidebar | `components/universal-chat/ChatSessionSidebar.tsx` | ~200 lines |
| Settings Panel  | `components/universal-chat/ChatSettingsPanel.tsx`  | ~150 lines |

### Backend Files to Modify

| Feature           | File Path                         | Lines      |
| ----------------- | --------------------------------- | ---------- |
| Chat Sessions API | `backend/routes/chat-sessions.js` | 496 lines  |
| Canvas API        | `backend/routes/canvas.js`        | 479 lines  |
| AI Service        | `backend/ai-service.js`           | ~600 lines |
| Main Models       | `backend/models.cjs`              | 2704 lines |
| Content Models    | `backend/content-models.js`       | ~900 lines |
| Main Server       | `backend/production-server.js`    | ~800 lines |

### Database Schema Files

| Purpose         | File Path                                                              |
| --------------- | ---------------------------------------------------------------------- |
| DB Schema Setup | `mongo_db_collection_sceme_files/iamai-global-schema-setup.mongodb.js` |
| Content Schemas | `backend/content-models.js`                                            |
| Main Schemas    | `backend/models.cjs`                                                   |

---

## 🔧 Implementation Checklist for Each Feature

### Voice Input Implementation

```
Frontend:
  ├── UniversalAgentChat.tsx
  │   ├── Add: startVoiceRecording()
  │   ├── Add: stopVoiceRecording()
  │   └── Wire: Microphone button onClick
  │
Backend:
  └── None required (uses browser Web Speech API)

Database:
  └── None required
```

### File Upload Implementation

```
Frontend:
  ├── UniversalAgentChat.tsx
  │   ├── Add: handleFileUpload()
  │   ├── Add: displayFilePreview()
  │   └── Wire: Attachment button onClick
  │
Backend:
  ├── routes/chat-sessions.js
  │   ├── Already has: POST /api/chat/upload
  │   └── Already has: multer middleware
  │
Database:
  └── file_uploads collection (already exists)
```

### Session Persistence Implementation

```
Frontend:
  ├── UniversalAgentChat.tsx
  │   ├── Add: loadSessionFromDB()
  │   ├── Add: saveSessionToDB()
  │   └── Wire: useEffect on session change
  │
  ├── ChatSessionSidebar.tsx
  │   ├── Modify: fetchSessions() to call API
  │   └── Modify: createSession() to call API
  │
Backend:
  └── routes/chat-sessions.js
      └── All endpoints already exist!

Database:
  ├── chat_sessions collection
  └── chat_messages collection
```

### Canvas Save/Load Implementation

```
Frontend:
  ├── CanvasMode.tsx
  │   ├── Add: saveProject() → POST /api/canvas/save
  │   ├── Add: loadProject() → GET /api/canvas/project/:id
  │   └── Add: Project list dropdown
  │
Backend:
  └── routes/canvas.js
      └── All endpoints already exist!

Database:
  └── canvas_projects collection
```

---

## 📝 Important Notes

1. **No shadcn/ui** - Caused React version conflicts, removed
2. **All enhancements use existing stack** - Tailwind + Heroicons
3. **Backend ready** - Most API endpoints already exist
4. **Mobile responsive** - Already implemented
5. **Theme system** - Already has light/dark modes

---

## 🎯 Next Steps

1. Review this document
2. Confirm priority of features
3. Start with Sprint 1 (Quick Wins)
4. Test each feature before moving to next
5. Deploy incrementally to production

---

# SUMMARY

This document provides **complete end-to-end architecture** for the Universal Chat System:

| Part   | Content                                                         |
| ------ | --------------------------------------------------------------- |
| Part 1 | Full System Architecture - Data flow from frontend to database  |
| Part 2 | Backend Architecture - API endpoints, routes, services          |
| Part 3 | Database Architecture - All collections, schemas, relationships |
| Part 4 | Frontend Architecture - Components, features, UI elements       |
| Part 5 | Implementation Reference - File locations, checklists           |

**Key Insight:** The system is **90% complete**. Most backend APIs and database collections already exist. Enhancements are primarily about **wiring existing UI to existing APIs**.

---

_Last Updated: January 3, 2026_
_Document Version: 2.0 - Full End-to-End Architecture_
