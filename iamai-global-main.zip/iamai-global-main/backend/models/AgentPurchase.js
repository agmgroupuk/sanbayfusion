/**
 * Agent Purchase Model
 * Tracks one-time purchases of agent access (not subscriptions!)
 */

const mongoose = require('mongoose');

const agentPurchaseSchema = new mongoose.Schema(
  {
    // User who made the purchase
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },

    // Agent purchased (aigirlfriend, agentx, etc.)
    agentId: {
      type: String,
      required: true,
      lowercase: true,
      trim: true,
    },

    // Plan type (daily, weekly, monthly)
    planType: {
      type: String,
      required: true,
      enum: ['daily', 'weekly', 'monthly'],
      lowercase: true,
    },

    // Purchase details
    purchaseDate: {
      type: Date,
      required: true,
      default: Date.now,
    },

    expirationDate: {
      type: Date,
      required: true,
    },

    // Status: active, expired, cancelled
    status: {
      type: String,
      required: true,
      enum: ['active', 'expired', 'cancelled'],
      default: 'active',
    },

    // Payment info
    stripePaymentIntentId: {
      type: String,
      required: true,
      unique: true,
    },

    stripeCheckoutSessionId: {
      type: String,
      required: true,
    },

    amount: {
      type: Number,
      required: true,
    },

    currency: {
      type: String,
      required: true,
      default: 'usd',
    },

    // Metadata
    cancelledAt: Date,
    cancelReason: String,

    metadata: mongoose.Schema.Types.Mixed,
  },
  {
    timestamps: true,
    collection: 'agent_purchases',
  }
);

// Compound index: one active purchase per user per agent
agentPurchaseSchema.index({ userId: 1, agentId: 1, status: 1 });

// Auto-expire purchases (run daily)
agentPurchaseSchema.index({ expirationDate: 1, status: 1 });

// Methods
agentPurchaseSchema.methods.isActive = function () {
  return this.status === 'active' && new Date() < this.expirationDate;
};

agentPurchaseSchema.methods.cancel = function () {
  this.status = 'cancelled';
  this.cancelledAt = new Date();
  this.expirationDate = new Date(); // Expire immediately
  return this.save();
};

// Statics
agentPurchaseSchema.statics.hasActiveAccess = async function (userId, agentId) {
  const purchase = await this.findOne({
    userId,
    agentId: agentId.toLowerCase(),
    status: 'active',
    expirationDate: { $gt: new Date() },
  });

  return purchase !== null;
};

agentPurchaseSchema.statics.getActivePurchase = async function (userId, agentId) {
  return this.findOne({
    userId,
    agentId: agentId.toLowerCase(),
    status: 'active',
    expirationDate: { $gt: new Date() },
  });
};

// Get all active purchases for a user (compat shim for agent-purchase-api)
agentPurchaseSchema.statics.getUserActivePurchases = async function (userId) {
  return this.find({
    userId,
    status: 'active',
    expirationDate: { $gt: new Date() },
  }).sort({ expirationDate: 1 });
};

// Calculate expiration date based on plan type
agentPurchaseSchema.statics.calculateExpiration = function (planType) {
  const now = new Date();
  const durations = {
    daily: 1,
    weekly: 7,
    monthly: 30,
  };

  const days = durations[planType] || 30;
  return new Date(now.getTime() + days * 24 * 60 * 60 * 1000);
};

module.exports = mongoose.model('AgentPurchase', agentPurchaseSchema);
