/**
 * 📊 Analytics Model
 * Track user events and behavior analytics
 */

const mongoose = require('mongoose');

const analyticsSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    eventName: {
      type: String,
      required: true,
    },
    properties: {
      type: mongoose.Schema.Types.Mixed,
      default: {},
    },
    sessionId: {
      type: String,
    },
    ipAddress: String,
    userAgent: String,
    referrer: String,
    page: String,
    createdAt: {
      type: Date,
      default: Date.now,
    },
  },
  {
    timestamps: true,
    collection: 'analytics',
  }
);

// Indexes for performance
analyticsSchema.index({ userId: 1, createdAt: -1 });
analyticsSchema.index({ eventName: 1, createdAt: -1 });
analyticsSchema.index({ sessionId: 1, createdAt: -1 });
analyticsSchema.index({ createdAt: -1 });

// TTL index to automatically delete old analytics data (older than 2 years)
analyticsSchema.index({ createdAt: 1 }, { expireAfterSeconds: 63072000 }); // 2 years

module.exports = mongoose.model('Analytics', analyticsSchema);
