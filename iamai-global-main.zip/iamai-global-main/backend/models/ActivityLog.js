/**
 * 📋 Activity Log Model
 * Comprehensive user activity tracking
 */

const mongoose = require('mongoose');

const activityLogSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: false, // Allow null for anonymous users
    },
    sessionId: {
      type: String,
      index: true,
    },
    isAnonymous: {
      type: Boolean,
      default: false,
      index: true,
    },
    action: {
      type: String,
      required: true,
      // No enum - allows any action string including PAGE_UNLOAD, PAGE_VIEW, etc.
    },
    category: {
      type: String,
      enum: ['auth', 'agent', 'profile', 'subscription', 'file', 'system', 'security', 'analytics'],
      required: false, // Made optional to allow flexible logging
      default: 'system',
    },
    resource: String, // What was acted upon (e.g., 'agent:chatgpt', 'file:123')
    details: {
      type: mongoose.Schema.Types.Mixed,
      default: {},
    },
    result: {
      type: String,
      enum: ['success', 'failure', 'partial'],
      default: 'success',
    },
    errorMessage: String,
    ipAddress: String,
    userAgent: String,
    referrer: String,
    metadata: {
      type: mongoose.Schema.Types.Mixed,
      default: {},
    },
    severity: {
      type: String,
      enum: ['low', 'medium', 'high', 'critical'],
      default: 'low',
    },
    createdAt: {
      type: Date,
      default: Date.now,
    },
  },
  {
    timestamps: false, // Using createdAt only
    collection: 'activity_logs',
  }
);

// Indexes for performance and querying
activityLogSchema.index({ userId: 1, createdAt: -1 });
activityLogSchema.index({ userId: 1, category: 1, createdAt: -1 });
activityLogSchema.index({ userId: 1, action: 1, createdAt: -1 });
activityLogSchema.index({ category: 1, action: 1, createdAt: -1 });
activityLogSchema.index({ result: 1, createdAt: -1 });
activityLogSchema.index({ severity: 1, createdAt: -1 });

// TTL index to automatically delete old logs (older than 1 year)
activityLogSchema.index({ createdAt: 1 }, { expireAfterSeconds: 31536000 }); // 1 year

// Static methods
activityLogSchema.statics.logActivity = function (userId, action, category, details = {}) {
  return this.create({
    userId,
    action,
    category,
    details,
    createdAt: new Date(),
  });
};

activityLogSchema.statics.logAuthActivity = function (userId, action, details = {}) {
  return this.logActivity(userId, action, 'auth', details);
};

activityLogSchema.statics.logAgentActivity = function (userId, action, agentType, details = {}) {
  return this.logActivity(userId, action, 'agent', {
    agentType,
    ...details,
  });
};

activityLogSchema.statics.logSecurityEvent = function (
  userId,
  action,
  severity = 'medium',
  details = {}
) {
  return this.create({
    userId,
    action,
    category: 'security',
    severity,
    details,
    createdAt: new Date(),
  });
};

// Instance methods
activityLogSchema.methods.markAsFailure = function (errorMessage) {
  this.result = 'failure';
  this.errorMessage = errorMessage;
  return this.save();
};

activityLogSchema.methods.addMetadata = function (metadata) {
  this.metadata = { ...this.metadata, ...metadata };
  return this.save();
};

module.exports = mongoose.model('ActivityLog', activityLogSchema);
