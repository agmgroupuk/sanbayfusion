const models = require('../models.cjs');

module.exports = models;