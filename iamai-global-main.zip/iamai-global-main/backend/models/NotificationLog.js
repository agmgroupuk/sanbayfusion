/**
 * 📄 Notification Log Model
 * Track notification delivery and status
 */

const mongoose = require('mongoose');

const notificationLogSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    type: [
      {
        type: String,
        enum: ['email', 'push', 'app'],
      },
    ],
    templateId: {
      type: String,
      required: true,
    },
    data: mongoose.Schema.Types.Mixed,
    results: {
      email: {
        success: Boolean,
        messageId: String,
        error: String,
      },
      push: {
        success: Boolean,
        notification: mongoose.Schema.Types.Mixed,
        error: String,
      },
      app: {
        success: Boolean,
        notificationId: mongoose.Schema.Types.ObjectId,
        error: String,
      },
    },
    createdAt: {
      type: Date,
      default: Date.now,
    },
  },
  {
    timestamps: true,
    collection: 'notification_logs',
  }
);

// Indexes
notificationLogSchema.index({ userId: 1, createdAt: -1 });
notificationLogSchema.index({ templateId: 1, createdAt: -1 });

// TTL index to automatically delete old logs (older than 90 days)
notificationLogSchema.index({ createdAt: 1 }, { expireAfterSeconds: 7776000 }); // 90 days

module.exports = mongoose.model('NotificationLog', notificationLogSchema);
