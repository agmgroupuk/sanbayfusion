/**
 * Agent Model - Production MongoDB Schema
 * Stores all agent definitions in the database
 *
 * This is the single source of truth for all agents in the system.
 * Frontend fetches agent data from API, not hardcoded files.
 */

const mongoose = require('mongoose');

// ==========================================
// SUB-SCHEMAS
// ==========================================

const AgentCapabilitiesSchema = new mongoose.Schema(
  {
    canAttachFiles: { type: Boolean, default: false },
    canUseVoice: { type: Boolean, default: true },
    canAccessWeb: { type: Boolean, default: false },
    multilingual: { type: Boolean, default: false },
    proactiveEngagement: { type: Boolean, default: false },
    canAnalyzeMoodData: { type: Boolean, default: false },
    canGeneratePoetry: { type: Boolean, default: false },
    canCreatePlaylists: { type: Boolean, default: false },
    canPlanEvents: { type: Boolean, default: false },
    canRunCode: { type: Boolean, default: false },
    canGenerateDiagrams: { type: Boolean, default: false },
    canMonitorSystems: { type: Boolean, default: false },
    canTriggerAPIs: { type: Boolean, default: false },
    canScheduleJobs: { type: Boolean, default: false },
  },
  { _id: false }
);

const VoicePreferencesSchema = new mongoose.Schema(
  {
    defaultGender: { type: String, enum: ['female', 'male'], default: 'female' },
    allowGenderToggle: { type: Boolean, default: true },
  },
  { _id: false }
);

const CognitionSchema = new mongoose.Schema(
  {
    contextualAwareness: { type: Boolean, default: true },
    longTermMemory: { type: Boolean, default: true },
    goalTracking: { type: Boolean, default: false },
    adaptiveLearning: { type: Boolean, default: true },
    ethicalReasoning: { type: Boolean, default: true },
    episodicMemory: { type: Boolean, default: false },
    conflictResolution: { type: Boolean, default: false },
    emotionalForecasting: { type: Boolean, default: false },
    memoryAnchoring: { type: Boolean, default: false },
    errorRecovery: { type: Boolean, default: false },
    anomalyDetection: { type: Boolean, default: false },
    optimizationHeuristics: { type: Boolean, default: false },
    dependencyMapping: { type: Boolean, default: false },
  },
  { _id: false }
);

const SkillsSchema = new mongoose.Schema(
  {
    enabled: [{ type: String }],
    marketplaceIntegration: { type: Boolean, default: false },
    autoSkillDiscovery: { type: Boolean, default: false },
  },
  { _id: false }
);

const WebOpsSchema = new mongoose.Schema(
  {
    realTimeSearch: { type: Boolean, default: false },
    citationBuilder: { type: Boolean, default: false },
    sourceValidation: { type: Boolean, default: false },
    multiSourceSynthesis: { type: Boolean, default: false },
  },
  { _id: false }
);

const PersonalityMatrixSchema = new mongoose.Schema(
  {
    formality: { type: Number, min: 0, max: 100, default: 50 },
    humor: { type: Number, min: 0, max: 100, default: 50 },
    enthusiasm: { type: Number, min: 0, max: 100, default: 50 },
    leadership: { type: Number, min: 0, max: 100 },
    diplomacy: { type: Number, min: 0, max: 100 },
    humorStyle: {
      type: String,
      enum: ['dry wit', 'puns', 'playful', 'sarcastic', 'none', 'warm and flirty', 'minimal'],
      default: 'playful',
    },
    storytelling: { type: Number, min: 0, max: 100 },
    resilience: { type: Number, min: 0, max: 100 },
    empathy: { type: Number, min: 0, max: 100 },
    precision: { type: Number, min: 0, max: 100 },
    creativity: { type: Number, min: 0, max: 100 },
    loveLanguage: [{ type: String }],
    attachmentStyle: { type: String },
    emotionalDepth: { type: Number, min: 0, max: 100 },
    romanticFlair: { type: Number, min: 0, max: 100 },
    toneAdaptability: { type: Boolean, default: true },
  },
  { _id: false }
);

const DeveloperToolsSchema = new mongoose.Schema(
  {
    codeSandbox: { type: Boolean, default: false },
    APIBuilder: { type: Boolean, default: false },
    regexWizard: { type: Boolean, default: false },
    CLICompanion: { type: Boolean, default: false },
    logAnalyzer: { type: Boolean, default: false },
    webhookTester: { type: Boolean, default: false },
    flowDebugger: { type: Boolean, default: false },
    schemaValidator: { type: Boolean, default: false },
  },
  { _id: false }
);

const MultimodalSchema = new mongoose.Schema(
  {
    imageRecognition: { type: Boolean, default: false },
    videoAnalysis: { type: Boolean, default: false },
    voiceToneAnalysis: { type: Boolean, default: false },
    diagramGeneration: { type: Boolean, default: false },
    musicMoodDetection: { type: Boolean, default: false },
    selfieCompanionMode: { type: Boolean, default: false },
    memoryGallerySupport: { type: Boolean, default: false },
  },
  { _id: false }
);

const InteractionSchema = new mongoose.Schema(
  {
    defaultTone: { type: String },
    conversationPacing: { type: String, default: 'adaptive' },
    preferredLanguage: { type: String, default: 'en' },
    safeMode: { type: Boolean, default: true },
    intimacyCalibration: { type: String },
    checkInFrequency: { type: String },
    emotionalMirroring: { type: Boolean, default: false },
    flowVisualization: { type: Boolean, default: false },
    autoEscalation: { type: Boolean, default: false },
    auditTrailSupport: { type: Boolean, default: false },
    multiTenantSupport: { type: Boolean, default: false },
  },
  { _id: false }
);

const ExamplesSchema = new mongoose.Schema(
  {
    prompts: [{ type: String }],
    responses: [{ type: String }],
  },
  { _id: false }
);

const VoiceConfigSchema = new mongoose.Schema(
  {
    profile: { type: String, default: 'female-soft' },
    speed: { type: Number, min: 0.5, max: 2.0, default: 1.0 },
    pitch: { type: Number, min: -20, max: 20, default: 0 },
    language: { type: String, default: 'en-US' },
  },
  { _id: false }
);

const AIConfigSchema = new mongoose.Schema(
  {
    chatModel: { type: String, enum: ['fast', 'balanced', 'advanced'], default: 'balanced' },
    preferredProvider: {
      type: String,
      enum: ['gemini', 'openai', 'anthropic', 'groq'],
      default: 'gemini',
    },
    temperature: { type: Number, min: 0, max: 2, default: 0.7 },
    maxTokens: { type: Number, default: 2048 },
    systemPrompt: { type: String },
    personalityTraits: [{ type: String }],
  },
  { _id: false }
);

const PricingSchema = new mongoose.Schema(
  {
    daily: { type: Number, default: 1 },
    weekly: { type: Number, default: 5 },
    monthly: { type: Number, default: 15 },
    currency: { type: String, default: 'USD' },
    stripePriceIds: {
      daily: { type: String },
      weekly: { type: String },
      monthly: { type: String },
    },
  },
  { _id: false }
);

// ==========================================
// MAIN AGENT SCHEMA
// ==========================================

const AgentSchema = new mongoose.Schema(
  {
    // Core Identity
    agentId: {
      type: String,
      required: true,
      trim: true,
      lowercase: true,
    },
    name: {
      type: String,
      required: true,
      trim: true,
    },
    role: {
      type: String,
      required: true,
    },
    description: {
      type: String,
      required: true,
    },
    icon: {
      type: String,
      required: true,
      default: 'fa-solid fa-robot',
    },
    version: {
      type: String,
      default: '1.0.0',
    },

    // Categorization
    category: {
      type: String,
      required: true,
      enum: [
        'companion',
        'productivity',
        'creative',
        'technical',
        'education',
        'lifestyle',
        'entertainment',
        'business',
      ],
    },
    tags: [{ type: String }],

    // Feature Flags
    capabilities: AgentCapabilitiesSchema,
    voicePreferences: VoicePreferencesSchema,
    cognition: CognitionSchema,
    skills: SkillsSchema,
    webOps: WebOpsSchema,
    personalityMatrix: PersonalityMatrixSchema,
    developerTools: DeveloperToolsSchema,
    multimodal: MultimodalSchema,
    interaction: InteractionSchema,
    examples: ExamplesSchema,

    // AI Configuration (for backend processing)
    aiConfig: AIConfigSchema,
    voiceConfig: VoiceConfigSchema,

    // Pricing
    pricing: PricingSchema,

    // Status
    isActive: {
      type: Boolean,
      default: true,
    },
    isFeatured: {
      type: Boolean,
      default: false,
    },
    isNew: {
      type: Boolean,
      default: false,
    },
    sortOrder: {
      type: Number,
      default: 0,
    },

    // Analytics
    stats: {
      totalUsers: { type: Number, default: 0 },
      totalMessages: { type: Number, default: 0 },
      avgRating: { type: Number, default: 0 },
      totalRatings: { type: Number, default: 0 },
    },

    // Metadata
    metadata: {
      createdAt: { type: Date, default: Date.now },
      updatedAt: { type: Date, default: Date.now },
      createdBy: { type: String },
      lastModifiedBy: { type: String },
    },
  },
  {
    timestamps: true,
    collection: 'agents',
  }
);

// ==========================================
// INDEXES
// ==========================================

AgentSchema.index({ agentId: 1 }, { unique: true });
AgentSchema.index({ isActive: 1, sortOrder: 1 });
AgentSchema.index({ category: 1, isActive: 1 });
AgentSchema.index({ tags: 1 });
AgentSchema.index({ isFeatured: 1, isActive: 1 });

// ==========================================
// METHODS
// ==========================================

// Get public-facing agent data (for frontend)
AgentSchema.methods.toPublicJSON = function () {
  return {
    id: this.agentId,
    name: this.name,
    role: this.role,
    description: this.description,
    icon: this.icon,
    version: this.version,
    tags: this.tags,
    category: this.category,
    capabilities: this.capabilities,
    voicePreferences: this.voicePreferences,
    cognition: this.cognition,
    skills: this.skills,
    webOps: this.webOps,
    personalityMatrix: this.personalityMatrix,
    developerTools: this.developerTools,
    multimodal: this.multimodal,
    interaction: this.interaction,
    examples: this.examples,
    pricing: {
      daily: this.pricing?.daily || 1,
      weekly: this.pricing?.weekly || 5,
      monthly: this.pricing?.monthly || 15,
    },
    isNew: this.isNew,
    isFeatured: this.isFeatured,
    stats: {
      totalUsers: this.stats?.totalUsers || 0,
      avgRating: this.stats?.avgRating || 0,
    },
  };
};

// Get backend config (for AI processing)
AgentSchema.methods.getBackendConfig = function () {
  return {
    agentId: this.agentId,
    name: this.name,
    chatModel: this.aiConfig?.chatModel || 'balanced',
    preferredProvider: this.aiConfig?.preferredProvider || 'gemini',
    temperature: this.aiConfig?.temperature || 0.7,
    maxTokens: this.aiConfig?.maxTokens || 2048,
    systemPrompt: this.aiConfig?.systemPrompt || '',
    personalityTraits: this.aiConfig?.personalityTraits || [],
    voice: this.voiceConfig || { profile: 'female-soft', speed: 1.0, pitch: 0, language: 'en-US' },
    features: {
      streaming: true,
      voiceResponse: this.capabilities?.canUseVoice || true,
      imageGeneration: this.multimodal?.imageRecognition || false,
      webSearch: this.capabilities?.canAccessWeb || false,
      functionCalling: this.developerTools?.APIBuilder || false,
    },
  };
};

// ==========================================
// STATICS
// ==========================================

// Get all active agents
AgentSchema.statics.getAllActive = function () {
  return this.find({ isActive: true }).sort({ sortOrder: 1, name: 1 });
};

// Get agent by agentId
AgentSchema.statics.getByAgentId = function (agentId) {
  return this.findOne({ agentId: agentId.toLowerCase(), isActive: true });
};

// Get featured agents
AgentSchema.statics.getFeatured = function () {
  return this.find({ isActive: true, isFeatured: true }).sort({ sortOrder: 1 });
};

// Get agents by category
AgentSchema.statics.getByCategory = function (category) {
  return this.find({ isActive: true, category }).sort({ sortOrder: 1, name: 1 });
};

// Search agents
AgentSchema.statics.search = function (query) {
  const regex = new RegExp(query, 'i');
  return this.find({
    isActive: true,
    $or: [{ name: regex }, { description: regex }, { tags: regex }, { role: regex }],
  }).sort({ sortOrder: 1 });
};

// Increment stats
AgentSchema.statics.incrementStats = async function (agentId, field, value = 1) {
  const update = {};
  update[`stats.${field}`] = value;
  return this.updateOne({ agentId }, { $inc: update });
};

// ==========================================
// MIDDLEWARE
// ==========================================

AgentSchema.pre('save', function (next) {
  this.metadata.updatedAt = new Date();
  next();
});

// ==========================================
// EXPORT
// ==========================================

const Agent = mongoose.model('Agent', AgentSchema);

module.exports = Agent;
