/**
 * 📁 File Upload Model
 * Track uploaded files and metadata
 */

const mongoose = require('mongoose');

const fileUploadSchema = new mongoose.Schema(
  {
    id: {
      type: String,
      required: true,
      unique: true,
    },
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    originalName: {
      type: String,
      required: true,
    },
    filename: {
      type: String,
      required: true,
    },
    mimetype: {
      type: String,
      required: true,
    },
    size: {
      type: Number,
      required: true,
    },
    category: {
      type: String,
      enum: ['image', 'document', 'audio', 'video', 'other'],
      required: true,
    },
    path: String, // Local file path (if not using cloud)
    url: {
      type: String,
      required: true,
    },
    cloudUrl: String, // Cloud storage URL
    cloudProvider: {
      type: String,
      enum: ['cloudinary', 's3', 'gcs'],
    },
    processed: {
      type: Boolean,
      default: false,
    },
    metadata: {
      type: mongoose.Schema.Types.Mixed,
      default: {},
    },
    tags: [String],
    description: String,
    isPublic: {
      type: Boolean,
      default: false,
    },
    downloadCount: {
      type: Number,
      default: 0,
    },
    lastAccessed: Date,
    expiresAt: Date,
    createdAt: {
      type: Date,
      default: Date.now,
    },
  },
  {
    timestamps: true,
    collection: 'file_uploads',
  }
);

// Indexes for performance
fileUploadSchema.index({ userId: 1, category: 1, createdAt: -1 });
fileUploadSchema.index({ userId: 1, createdAt: -1 });
fileUploadSchema.index({ category: 1, createdAt: -1 });
fileUploadSchema.index({ mimetype: 1 });
fileUploadSchema.index({ size: 1 });
fileUploadSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 });

// Virtual for formatted file size
fileUploadSchema.virtual('formattedSize').get(function () {
  const bytes = this.size;
  if (bytes === 0) return '0 Bytes';

  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));

  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
});

// Virtual for file extension
fileUploadSchema.virtual('extension').get(function () {
  const lastDot = this.originalName.lastIndexOf('.');
  return lastDot !== -1 ? this.originalName.substring(lastDot + 1).toLowerCase() : '';
});

// Method to update access tracking
fileUploadSchema.methods.trackAccess = function () {
  this.downloadCount += 1;
  this.lastAccessed = new Date();
  return this.save();
};

module.exports = mongoose.model('FileUpload', fileUploadSchema);
