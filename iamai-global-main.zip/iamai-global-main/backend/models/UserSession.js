/**
 * 👤 User Session Model
 * Track user sessions and activity
 */

const mongoose = require('mongoose');

const userSessionSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    sessionId: {
      type: String,
      required: true,
    },
    ipAddress: String,
    userAgent: String,
    device: {
      type: String,
      enum: ['desktop', 'mobile', 'tablet', 'unknown'],
      default: 'unknown',
    },
    browser: String,
    os: String,
    location: {
      country: String,
      region: String,
      city: String,
      latitude: Number,
      longitude: Number,
    },
    isActive: {
      type: Boolean,
      default: true,
    },
    lastActivity: {
      type: Date,
      default: Date.now,
    },
    startedAt: {
      type: Date,
      default: Date.now,
    },
    endedAt: Date,
    duration: Number, // in milliseconds
    pageViews: {
      type: Number,
      default: 0,
    },
    interactions: {
      type: Number,
      default: 0,
    },
    referrer: String,
    landingPage: String,
    exitPage: String,
    createdAt: {
      type: Date,
      default: Date.now,
    },
  },
  {
    timestamps: true,
    collection: 'user_sessions',
  }
);

// Indexes for performance
userSessionSchema.index({ userId: 1, isActive: 1, lastActivity: -1 });
userSessionSchema.index({ sessionId: 1, isActive: 1 });
userSessionSchema.index({ lastActivity: -1 });
userSessionSchema.index({ startedAt: -1 });

// TTL index to automatically delete old sessions (older than 90 days)
userSessionSchema.index({ createdAt: 1 }, { expireAfterSeconds: 7776000 }); // 90 days

// Methods
userSessionSchema.methods.updateActivity = function () {
  this.lastActivity = new Date();
  this.interactions += 1;
  return this.save();
};

userSessionSchema.methods.endSession = function () {
  this.isActive = false;
  this.endedAt = new Date();
  this.duration = this.endedAt.getTime() - this.startedAt.getTime();
  return this.save();
};

// Virtuals
userSessionSchema.virtual('durationFormatted').get(function () {
  if (!this.duration) return 'Active';

  const seconds = Math.floor(this.duration / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);

  if (hours > 0) {
    return `${hours}h ${minutes % 60}m`;
  } else if (minutes > 0) {
    return `${minutes}m ${seconds % 60}s`;
  } else {
    return `${seconds}s`;
  }
});

module.exports = mongoose.model('UserSession', userSessionSchema);
