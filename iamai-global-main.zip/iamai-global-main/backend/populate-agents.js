const mongoose = require('mongoose');
const models = require('./models');
const { IndividualAgentConfiguration } = models;

// Agent data - simplified version based on the frontend constants
const AGENT_CONFIGURATIONS = [
  {
    agentId: 'ai-girlfriend',
    info: {
      displayName: 'AI Girlfriend',
      category: 'Relationship',
      description: 'Your perfect AI companion for emotional support and romantic conversations',
      role: 'AI Girlfriend',
      isActive: true,
      version: '2.0.0',
      tags: ['relationship', 'emotional', 'romantic'],
    },
    personality: {
      behavioralTraits: {
        assertiveness: 3,
        creativity: 8,
        empathy: 9,
        enthusiasm: 7,
        formality: 2,
        humor: 6,
        patience: 8,
        verbosity: 7,
      },
      communicationStyle: 'warm and engaging',
      expertise: ['relationships', 'emotional support', 'conversation'],
    },
    capabilities: {
      canAttachFiles: true,
      canUseVoice: true,
      maxFileSize: 10,
      supportedFormats: ['jpg', 'png', 'gif', 'mp3', 'wav'],
    },
    limits: {
      daily: { messages: 100, tokens: 10000, sessions: 10 },
      weekly: { messages: 500, tokens: 50000, sessions: 50 },
      monthly: { messages: 2000, tokens: 200000, sessions: 200 },
    },
    pricing: { daily: 1, weekly: 5, monthly: 19 },
  },
  {
    agentId: 'emo-ai',
    info: {
      displayName: 'Emo AI',
      category: 'Emotional Support',
      description: 'Specialized in emotional intelligence and mood analysis',
      role: 'Emotional Support AI',
      isActive: true,
      version: '2.0.0',
      tags: ['emotional', 'support', 'mood'],
    },
    personality: {
      behavioralTraits: {
        assertiveness: 4,
        creativity: 6,
        empathy: 10,
        enthusiasm: 5,
        formality: 3,
        humor: 4,
        patience: 9,
        verbosity: 6,
      },
      communicationStyle: 'empathetic and understanding',
      expertise: ['emotional intelligence', 'mood analysis', 'support'],
    },
    capabilities: {
      canAttachFiles: true,
      canUseVoice: true,
      maxFileSize: 10,
      supportedFormats: ['jpg', 'png', 'gif', 'mp3', 'wav'],
    },
    limits: {
      daily: { messages: 100, tokens: 10000, sessions: 10 },
      weekly: { messages: 500, tokens: 50000, sessions: 50 },
      monthly: { messages: 2000, tokens: 200000, sessions: 200 },
    },
    pricing: { daily: 1, weekly: 5, monthly: 19 },
  },
  // Add more agents as needed...
  {
    agentId: 'pdf-mind',
    info: {
      displayName: 'PDF Mind',
      category: 'Document Analysis',
      description: 'AI specialized in analyzing and understanding PDF documents',
      role: 'Document Analysis AI',
      isActive: true,
      version: '2.0.0',
      tags: ['pdf', 'documents', 'analysis'],
    },
    personality: {
      behavioralTraits: {
        assertiveness: 6,
        creativity: 5,
        empathy: 4,
        enthusiasm: 6,
        formality: 7,
        humor: 3,
        patience: 8,
        verbosity: 8,
      },
      communicationStyle: 'analytical and precise',
      expertise: ['document analysis', 'PDF processing', 'information extraction'],
    },
    capabilities: {
      canAttachFiles: true,
      canUseVoice: false,
      maxFileSize: 50,
      supportedFormats: ['pdf', 'doc', 'docx', 'txt'],
    },
    limits: {
      daily: { messages: 100, tokens: 10000, sessions: 10 },
      weekly: { messages: 500, tokens: 50000, sessions: 50 },
      monthly: { messages: 2000, tokens: 200000, sessions: 200 },
    },
    pricing: { daily: 1, weekly: 5, monthly: 19 },
  },
  // Add remaining agents...
];

async function populateAgentConfigurations() {
  try {
    // Connect to MongoDB
    await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/iamai');

    console.log('Connected to MongoDB');

    for (const config of AGENT_CONFIGURATIONS) {
      await IndividualAgentConfiguration.findOneAndUpdate({ agentId: config.agentId }, config, {
        upsert: true,
        new: true,
      });
      console.log(`✅ Updated configuration for ${config.info.displayName}`);
    }

    console.log('🎉 All agent configurations populated successfully!');
  } catch (error) {
    console.error('Error populating agent configurations:', error);
  } finally {
    await mongoose.disconnect();
    console.log('Disconnected from MongoDB');
  }
}

// Run the script
populateAgentConfigurations();
