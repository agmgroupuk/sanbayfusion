/**
 * Reports API Specification
 * Backend endpoints for handling user-submitted reports of suspicious activity
 * 
 * This document outlines the API contracts for the reporting system.
 * All endpoints require proper authentication and rate limiting.
 */

// ============================================================================
// REPORT SUBMISSION ENDPOINT
// ============================================================================

/**
 * POST /api/reports/submit
 * Submit a new report for suspicious activity
 * 
 * Authentication: Optional (can be anonymous or authenticated)
 * Rate Limit: 10 requests per hour per IP
 * Timeout: 30 seconds
 */

interface SubmitReportRequest {
  reporterEmail: string; // Required, validated email
  reporterName?: string; // Optional, user's name
  category: string; // Required, one of predefined categories
  severity: 'low' | 'medium' | 'high' | 'critical'; // Required
  description: string; // Required, 20-5000 characters
  affectedUser?: string; // Optional, username or email of affected user
  evidenceUrl?: string; // Optional, URL to uploaded evidence
  ipAddress?: string; // Auto-captured from request
  userAgent?: string; // Auto-captured from request
}

interface SubmitReportResponse {
  success: boolean;
  reportId: string; // Format: RPT-{timestamp}-{random}
  message: string;
  timestamp: string; // ISO 8601
  data?: {
    report: {
      id: string;
      status: 'submitted';
      createdAt: string;
      estimatedReviewTime: string; // e.g., "24-48 hours"
    };
  };
}

/**
 * Example Request:
 * {
 *   "reporterEmail": "user@example.com",
 *   "reporterName": "John Doe",
 *   "category": "fraud",
 *   "severity": "high",
 *   "description": "I noticed suspicious transaction activity on my account...",
 *   "affectedUser": "victim@example.com",
 *   "evidenceUrl": "s3://evidence-bucket/report-123.png"
 * }
 * 
 * Example Response (Success):
 * {
 *   "success": true,
 *   "reportId": "RPT-1703085600000-abc12345",
 *   "message": "Report submitted successfully",
 *   "timestamp": "2024-12-21T10:00:00Z",
 *   "data": {
 *     "report": {
 *       "id": "RPT-1703085600000-abc12345",
 *       "status": "submitted",
 *       "createdAt": "2024-12-21T10:00:00Z",
 *       "estimatedReviewTime": "24-48 hours"
 *     }
 *   }
 * }
 * 
 * Example Response (Error):
 * {
 *   "success": false,
 *   "message": "Validation failed: Description must be at least 20 characters",
 *   "timestamp": "2024-12-21T10:00:00Z"
 * }
 */

// ============================================================================
// REPORT STATUS ENDPOINT
// ============================================================================

/**
 * GET /api/reports/status/:reportId
 * Get the current status of a submitted report
 * 
 * Authentication: None required (public endpoint)
 * Rate Limit: 60 requests per hour per IP
 * Parameters:
 *   - reportId: string (path parameter, format: RPT-*)
 */

interface GetReportStatusResponse {
  success: boolean;
  data?: {
    report: {
      id: string;
      status: 'submitted' | 'reviewing' | 'investigated' | 'resolved' | 'dismissed';
      category: string;
      severity: string;
      createdAt: string;
      updatedAt: string;
      summary?: string; // Resolution summary, visible after investigation
    };
  };
  message: string;
  timestamp: string;
}

/**
 * Example Response (Submitted):
 * {
 *   "success": true,
 *   "data": {
 *     "report": {
 *       "id": "RPT-1703085600000-abc12345",
 *       "status": "submitted",
 *       "category": "fraud",
 *       "severity": "high",
 *       "createdAt": "2024-12-21T10:00:00Z",
 *       "updatedAt": "2024-12-21T10:00:00Z"
 *     }
 *   },
 *   "message": "Report is queued for review",
 *   "timestamp": "2024-12-21T10:05:00Z"
 * }
 * 
 * Example Response (Resolved):
 * {
 *   "success": true,
 *   "data": {
 *     "report": {
 *       "id": "RPT-1703085600000-abc12345",
 *       "status": "resolved",
 *       "category": "fraud",
 *       "severity": "high",
 *       "createdAt": "2024-12-21T10:00:00Z",
 *       "updatedAt": "2024-12-22T14:30:00Z",
 *       "summary": "The reported account has been suspended and the fraudulent activity has been reversed."
 *     }
 *   },
 *   "message": "Report has been resolved",
 *   "timestamp": "2024-12-22T14:30:00Z"
 * }
 */

// ============================================================================
// ADMIN ENDPOINTS
// ============================================================================

/**
 * GET /api/reports/list
 * Get all reports (Admin only)
 * 
 * Authentication: Required, Admin role
 * Rate Limit: 30 requests per minute
 * Query Parameters:
 *   - status: string (optional) - Filter by status
 *   - category: string (optional) - Filter by category
 *   - severity: string (optional) - Filter by severity
 *   - dateFrom: ISO 8601 string (optional)
 *   - dateTo: ISO 8601 string (optional)
 *   - page: number (default: 1)
 *   - limit: number (default: 20, max: 100)
 */

interface ListReportsResponse {
  success: boolean;
  data?: {
    reports: Array<{
      id: string;
      reporterEmail: string;
      category: string;
      severity: string;
      status: string;
      description: string;
      affectedUser?: string;
      ipAddress: string;
      createdAt: string;
      updatedAt: string;
    }>;
    pagination: {
      page: number;
      limit: number;
      total: number;
      pages: number;
    };
  };
  message: string;
  timestamp: string;
}

/**
 * PATCH /api/reports/:reportId/status
 * Update report status (Admin only)
 * 
 * Authentication: Required, Admin role
 * Rate Limit: 60 requests per minute
 */

interface UpdateReportStatusRequest {
  status: 'reviewing' | 'investigated' | 'resolved' | 'dismissed';
  summary?: string; // Required if resolving/dismissing
  notes?: string; // Internal notes for admin
}

interface UpdateReportStatusResponse {
  success: boolean;
  data?: {
    report: {
      id: string;
      status: string;
      updatedAt: string;
    };
  };
  message: string;
  timestamp: string;
}

/**
 * GET /api/reports/analytics
 * Get reporting analytics (Admin only)
 * 
 * Authentication: Required, Admin role
 * Rate Limit: 5 requests per minute
 */

interface AnalyticsResponse {
  success: boolean;
  data?: {
    analytics: {
      totalReports: number;
      reportsByStatus: {
        submitted: number;
        reviewing: number;
        investigated: number;
        resolved: number;
        dismissed: number;
      };
      reportsByCategory: {
        [key: string]: number;
      };
      reportsBySeverity: {
        low: number;
        medium: number;
        high: number;
        critical: number;
      };
      averageResolutionTime: string; // e.g., "2.5 days"
      reportsLast24Hours: number;
      reportsLast7Days: number;
      reportsLast30Days: number;
    };
  };
  message: string;
  timestamp: string;
}

// ============================================================================
// FILE UPLOAD ENDPOINT
// ============================================================================

/**
 * POST /api/reports/upload-evidence
 * Upload evidence file for a report
 * 
 * Authentication: Optional
 * Rate Limit: 5 requests per hour per IP
 * Content-Type: multipart/form-data
 * Max File Size: 10MB
 * Allowed Types: image/jpeg, image/png, image/gif, application/pdf, text/plain
 */

interface UploadEvidenceResponse {
  success: boolean;
  data?: {
    url: string; // URL to uploaded file
    filename: string;
    size: number; // bytes
    mimeType: string;
  };
  message: string;
  timestamp: string;
}

/**
 * Example Request:
 * Content-Type: multipart/form-data
 * Form Data:
 *   - file: <binary file data>
 * 
 * Example Response:
 * {
 *   "success": true,
 *   "data": {
 *     "url": "https://cdn.example.com/evidence/report-123.png",
 *     "filename": "screenshot.png",
 *     "size": 245000,
 *     "mimeType": "image/png"
 *   },
 *   "message": "File uploaded successfully",
 *   "timestamp": "2024-12-21T10:00:00Z"
 * }
 */

// ============================================================================
// ERROR RESPONSES
// ============================================================================

/**
 * All error responses follow this format:
 * 
 * HTTP 400 - Bad Request
 * {
 *   "success": false,
 *   "message": "Validation failed: [specific error]",
 *   "timestamp": "2024-12-21T10:00:00Z"
 * }
 * 
 * HTTP 401 - Unauthorized
 * {
 *   "success": false,
 *   "message": "Authentication required",
 *   "timestamp": "2024-12-21T10:00:00Z"
 * }
 * 
 * HTTP 403 - Forbidden
 * {
 *   "success": false,
 *   "message": "Access denied - Admin role required",
 *   "timestamp": "2024-12-21T10:00:00Z"
 * }
 * 
 * HTTP 404 - Not Found
 * {
 *   "success": false,
 *   "message": "Report not found",
 *   "timestamp": "2024-12-21T10:00:00Z"
 * }
 * 
 * HTTP 429 - Too Many Requests
 * {
 *   "success": false,
 *   "message": "Rate limit exceeded. Please try again later.",
 *   "timestamp": "2024-12-21T10:00:00Z",
 *   "data": {
 *     "retryAfter": 300 // seconds
 *   }
 * }
 * 
 * HTTP 500 - Internal Server Error
 * {
 *   "success": false,
 *   "message": "An unexpected error occurred. Please try again later.",
 *   "timestamp": "2024-12-21T10:00:00Z"
 * }
 */

// ============================================================================
// IMPLEMENTATION NOTES
// ============================================================================

/**
 * Database Schema (Recommended):
 * 
 * Reports Table:
 * - id (PRIMARY KEY)
 * - reporter_email (VARCHAR, NOT NULL)
 * - reporter_name (VARCHAR, NULLABLE)
 * - category (VARCHAR, NOT NULL)
 * - severity (ENUM, NOT NULL)
 * - description (TEXT, NOT NULL)
 * - affected_user (VARCHAR, NULLABLE)
 * - evidence_url (VARCHAR, NULLABLE)
 * - ip_address (VARCHAR, NOT NULL)
 * - user_agent (VARCHAR, NULLABLE)
 * - status (ENUM, DEFAULT 'submitted')
 * - summary (TEXT, NULLABLE)
 * - created_at (TIMESTAMP, NOT NULL)
 * - updated_at (TIMESTAMP, NOT NULL)
 * - admin_notes (TEXT, NULLABLE)
 * - admin_id (VARCHAR, NULLABLE) - Admin who handled the report
 * 
 * Indexes:
 * - INDEX on (status)
 * - INDEX on (category)
 * - INDEX on (severity)
 * - INDEX on (created_at)
 * - INDEX on (reporter_email)
 * 
 * Audit Log Table:
 * - id (PRIMARY KEY)
 * - report_id (FOREIGN KEY)
 * - action (VARCHAR, NOT NULL) - 'created', 'status_changed', etc.
 * - old_value (JSON, NULLABLE)
 * - new_value (JSON, NULLABLE)
 * - changed_by (VARCHAR, NOT NULL)
 * - timestamp (TIMESTAMP, NOT NULL)
 * 
 * Email Notifications:
 * - When report is submitted
 * - When status changes to investigated/resolved
 * - Admin alerts for critical/high severity reports
 * 
 * Logging:
 * - Log all submissions with timestamp, IP, and email
 * - Monitor for duplicate/spam reports from same IP/email
 * - Track resolution metrics
 * 
 * Security Considerations:
 * - Validate all inputs server-side
 * - Rate limit by IP address
 * - Store IP and user agent for fraud detection
 * - Encrypt sensitive data at rest
 * - Use HTTPS for all communication
 * - Implement CORS properly
 * - Log all admin actions
 * - Regular security audits
 */

export {};
