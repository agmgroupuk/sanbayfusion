// AI Lab Configuration - Production Ready
// Simple config for our beautiful AI laboratory

module.exports = {
  // Environment
  NODE_ENV: process.env.NODE_ENV || 'production',
  
  // Database
  MONGODB_URI: process.env.MONGODB_URI || 'mongodb+srv://iamai-global:miczugamark@iamai-global.pwzfji.mongodb.net/iamai-global?appName=iamai-global',
  
  // Server
  PORT: process.env.PORT || 3001,
  
  // API Keys (add your keys here)
  OPENAI_API_KEY: process.env.OPENAI_API_KEY || '',
  ANTHROPIC_API_KEY: process.env.ANTHROPIC_API_KEY || '',
  GOOGLE_API_KEY: process.env.GOOGLE_API_KEY || '',
  MISTRAL_API_KEY: process.env.MISTRAL_API_KEY || '',
  
  // JWT
  JWT_SECRET: process.env.JWT_SECRET || 'iamai-lab-secret-key-2025',
  
  // Rate Limiting
  RATE_LIMIT_WINDOW: 15 * 60 * 1000, // 15 minutes
  RATE_LIMIT_MAX: 100, // requests per window
  
  // AI Lab Settings
  AI_LAB: {
    MAX_EXPERIMENTS_PER_DAY: {
      daily: 10,
      weekly: 50,
      monthly: 200,
      yearly: 1000
    },
    DEFAULT_MODEL_TIMEOUT: 30000, // 30 seconds
    MAX_TOKENS: 4000
  },
  
  // Subscription Plans
  SUBSCRIPTION_PLANS: {
    daily: { price: 2.99, duration: '1 day' },
    weekly: { price: 9.99, duration: '7 days' },
    monthly: { price: 29.99, duration: '30 days' },
    yearly: { price: 299.99, duration: '365 days' }
  }
};