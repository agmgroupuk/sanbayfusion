// Advanced Monitoring and Metrics System for IAMAI Global
// Features: Prometheus metrics, health checks, performance monitoring, alerting

const promClient = require('prom-client');
const express = require('express');
const os = require('os');
const { performance } = require('perf_hooks');
const logger = require('./logger.js');

// Create a Registry which registers the metrics
const register = new promClient.Registry();

// Add a default label which is added to all metrics
register.setDefaultLabels({
  app: 'iamai-backend'
});

// Enable the collection of default metrics
promClient.collectDefaultMetrics({ register });

// Custom metrics
const httpRequestDuration = new promClient.Histogram({
  name: 'http_request_duration_seconds',
  help: 'Duration of HTTP requests in seconds',
  labelNames: ['method', 'route', 'status_code'],
  buckets: [0.1, 0.5, 1, 2, 5, 10]
});

const httpRequestsTotal = new promClient.Counter({
  name: 'http_requests_total',
  help: 'Total number of HTTP requests',
  labelNames: ['method', 'route', 'status_code']
});

const activeConnections = new promClient.Gauge({
  name: 'active_connections',
  help: 'Number of active connections'
});

const databaseConnections = new promClient.Gauge({
  name: 'database_connections_active',
  help: 'Number of active database connections'
});

const aiRequestsTotal = new promClient.Counter({
  name: 'ai_requests_total',
  help: 'Total number of AI API requests',
  labelNames: ['provider', 'model', 'status']
});

const aiRequestDuration = new promClient.Histogram({
  name: 'ai_request_duration_seconds',
  help: 'Duration of AI API requests in seconds',
  labelNames: ['provider', 'model'],
  buckets: [0.1, 0.5, 1, 2, 5, 10, 30]
});

const userSessionsActive = new promClient.Gauge({
  name: 'user_sessions_active',
  help: 'Number of active user sessions'
});

const agentInteractionsTotal = new promClient.Counter({
  name: 'agent_interactions_total',
  help: 'Total number of agent interactions',
  labelNames: ['agent_id', 'agent_type']
});

const errorRate = new promClient.Counter({
  name: 'errors_total',
  help: 'Total number of errors',
  labelNames: ['type', 'component']
});

const memoryUsage = new promClient.Gauge({
  name: 'memory_usage_bytes',
  help: 'Memory usage in bytes',
  labelNames: ['type']
});

const cpuUsage = new promClient.Gauge({
  name: 'cpu_usage_percent',
  help: 'CPU usage percentage'
});

// Register custom metrics
register.registerMetric(httpRequestDuration);
register.registerMetric(httpRequestsTotal);
register.registerMetric(activeConnections);
register.registerMetric(databaseConnections);
register.registerMetric(aiRequestsTotal);
register.registerMetric(aiRequestDuration);
register.registerMetric(userSessionsActive);
register.registerMetric(agentInteractionsTotal);
register.registerMetric(errorRate);
register.registerMetric(memoryUsage);
register.registerMetric(cpuUsage);

// System monitoring
class SystemMonitor {
  constructor() {
    this.isMonitoring = false;
    this.monitoringInterval = null;
  }

  start() {
    if (this.isMonitoring) return;

    this.isMonitoring = true;
    logger.info('Starting system monitoring...');

    // Update system metrics every 30 seconds
    this.monitoringInterval = setInterval(() => {
      this.updateSystemMetrics();
    }, 30000);

    // Initial update
    this.updateSystemMetrics();
  }

  stop() {
    if (!this.isMonitoring) return;

    this.isMonitoring = false;
    if (this.monitoringInterval) {
      clearInterval(this.monitoringInterval);
      this.monitoringInterval = null;
    }
    logger.info('Stopped system monitoring');
  }

  updateSystemMetrics() {
    try {
      // Memory usage
      const memUsage = process.memoryUsage();
      memoryUsage.set({ type: 'rss' }, memUsage.rss);
      memoryUsage.set({ type: 'heap_used' }, memUsage.heapUsed);
      memoryUsage.set({ type: 'heap_total' }, memUsage.heapTotal);
      memoryUsage.set({ type: 'external' }, memUsage.external);

      // CPU usage (simplified)
      const cpuUsagePercent = os.loadavg()[0] / os.cpus().length * 100;
      cpuUsage.set(cpuUsagePercent);

    } catch (error) {
      logger.error('Error updating system metrics:', error);
      errorRate.inc({ type: 'system_monitoring', component: 'metrics_update' });
    }
  }
}

// Health check system
class HealthChecker {
  constructor() {
    this.checks = new Map();
    this.lastResults = new Map();
  }

  registerCheck(name, checkFunction, interval = 60000) {
    this.checks.set(name, {
      function: checkFunction,
      interval,
      lastRun: 0,
      timeout: null
    });

    // Start periodic checks
    this.scheduleCheck(name);
  }

  async scheduleCheck(name) {
    const check = this.checks.get(name);
    if (!check) return;

    const now = Date.now();
    if (now - check.lastRun >= check.interval) {
      check.lastRun = now;
      try {
        const result = await check.function();
        this.lastResults.set(name, {
          status: result.healthy ? 'healthy' : 'unhealthy',
          timestamp: now,
          details: result,
          responseTime: Date.now() - now
        });
      } catch (error) {
        this.lastResults.set(name, {
          status: 'error',
          timestamp: now,
          error: error.message,
          responseTime: Date.now() - now
        });
        logger.error(`Health check failed for ${name}:`, error);
        errorRate.inc({ type: 'health_check', component: name });
      }
    }

    // Schedule next check
    check.timeout = setTimeout(() => this.scheduleCheck(name), check.interval);
  }

  getHealthStatus() {
    const results = {};
    let overallHealthy = true;

    for (const [name, result] of this.lastResults) {
      results[name] = result;
      if (result.status !== 'healthy') {
        overallHealthy = false;
      }
    }

    return {
      status: overallHealthy ? 'healthy' : 'unhealthy',
      timestamp: Date.now(),
      checks: results,
      uptime: process.uptime(),
      version: process.env.npm_package_version || '1.0.0'
    };
  }

  async runAllChecks() {
    const promises = Array.from(this.checks.keys()).map(name =>
      this.scheduleCheck(name)
    );
    await Promise.all(promises);
  }
}

// Performance profiler
class PerformanceProfiler {
  constructor() {
    this.activeTraces = new Map();
  }

  startTrace(traceId, operation) {
    const trace = {
      id: traceId,
      operation,
      startTime: performance.now(),
      startMemory: process.memoryUsage(),
      spans: []
    };
    this.activeTraces.set(traceId, trace);
    return traceId;
  }

  addSpan(traceId, spanName, data = {}) {
    const trace = this.activeTraces.get(traceId);
    if (!trace) return;

    trace.spans.push({
      name: spanName,
      startTime: performance.now(),
      data
    });
  }

  endTrace(traceId) {
    const trace = this.activeTraces.get(traceId);
    if (!trace) return null;

    const endTime = performance.now();
    const endMemory = process.memoryUsage();

    const completedTrace = {
      ...trace,
      endTime,
      duration: endTime - trace.startTime,
      memoryDelta: {
        rss: endMemory.rss - trace.startMemory.rss,
        heapUsed: endMemory.heapUsed - trace.startMemory.heapUsed
      }
    };

    this.activeTraces.delete(traceId);

    // Log performance trace
    logger.performance(`Trace completed: ${trace.operation}`, completedTrace);

    return completedTrace;
  }

  getActiveTraces() {
    return Array.from(this.activeTraces.values());
  }
}

// Alerting system
class AlertManager {
  constructor() {
    this.alerts = [];
    this.rules = [];
  }

  addRule(name, condition, severity = 'warning', cooldown = 300000) { // 5 minutes cooldown
    this.rules.push({
      name,
      condition,
      severity,
      cooldown,
      lastTriggered: 0
    });
  }

  checkRules(metrics) {
    const now = Date.now();

    for (const rule of this.rules) {
      if (now - rule.lastTriggered < rule.cooldown) continue;

      try {
        if (rule.condition(metrics)) {
          const alert = {
            id: `${rule.name}_${now}`,
            name: rule.name,
            severity: rule.severity,
            timestamp: now,
            metrics: { ...metrics }
          };

          this.alerts.push(alert);
          rule.lastTriggered = now;

          // Keep only last 100 alerts
          if (this.alerts.length > 100) {
            this.alerts.shift();
          }

          logger.warn(`Alert triggered: ${rule.name}`, alert);

          // Trigger alert actions based on severity
          this.triggerAlert(alert);
        }
      } catch (error) {
        logger.error(`Error checking rule ${rule.name}:`, error);
      }
    }
  }

  triggerAlert(alert) {
    // Implement alert actions (email, webhook, etc.)
    console.log(`🚨 ALERT [${alert.severity.toUpperCase()}]: ${alert.name}`);

    if (alert.severity === 'critical') {
      // Critical alerts might need immediate action
      logger.error('Critical alert triggered:', alert);
    }
  }

  getAlerts(limit = 50) {
    return this.alerts.slice(-limit);
  }
}

// Initialize components
const systemMonitor = new SystemMonitor();
const healthChecker = new HealthChecker();
const performanceProfiler = new PerformanceProfiler();
const alertManager = new AlertManager();

// Default alert rules
alertManager.addRule(
  'high_memory_usage',
  (metrics) => metrics.memoryUsage > 0.9, // 90% memory usage
  'warning'
);

alertManager.addRule(
  'high_error_rate',
  (metrics) => metrics.errorRate > 10, // More than 10 errors per minute
  'critical'
);

alertManager.addRule(
  'high_response_time',
  (metrics) => metrics.avgResponseTime > 5000, // 5 seconds average
  'warning'
);

// Middleware for HTTP metrics
export const metricsMiddleware = (req, res, next) => {
  const start = performance.now();
  activeConnections.inc();

  res.on('finish', () => {
    const duration = performance.now() - start;
    activeConnections.dec();

    httpRequestDuration
      .labels(req.method, req.route?.path || req.path, res.statusCode.toString())
      .observe(duration / 1000); // Convert to seconds

    httpRequestsTotal
      .labels(req.method, req.route?.path || req.path, res.statusCode.toString())
      .inc();
  });

  next();
};

// AI metrics tracking
export const trackAIRequest = async (provider, model, operation, callback) => {
  const start = performance.now();
  let status = 'success';

  try {
    const result = await callback();
    return result;
  } catch (error) {
    status = 'error';
    throw error;
  } finally {
    const duration = performance.now() - start;
    aiRequestsTotal.labels(provider, model, status).inc();
    aiRequestDuration.labels(provider, model).observe(duration / 1000);
  }
};

// Express routes for metrics
export const metricsRouter = express.Router();

// Prometheus metrics endpoint
metricsRouter.get('/metrics', async (req, res) => {
  try {
    res.set('Content-Type', register.contentType);
    const metrics = await register.metrics();
    res.end(metrics);
  } catch (error) {
    logger.error('Error generating metrics:', error);
    res.status(500).end();
  }
});

// Health check endpoint
metricsRouter.get('/health', async (req, res) => {
  try {
    const health = healthChecker.getHealthStatus();
    const statusCode = health.status === 'healthy' ? 200 : 503;
    res.status(statusCode).json(health);
  } catch (error) {
    logger.error('Error generating health check:', error);
    res.status(500).json({ status: 'error', error: error.message });
  }
});

// Detailed health endpoint
metricsRouter.get('/health/detailed', async (req, res) => {
  try {
    const health = healthChecker.getHealthStatus();
    const systemInfo = {
      platform: os.platform(),
      arch: os.arch(),
      cpus: os.cpus().length,
      totalMemory: os.totalmem(),
      freeMemory: os.freemem(),
      uptime: os.uptime(),
      loadAverage: os.loadavg(),
      nodeVersion: process.version
    };

    res.json({
      ...health,
      system: systemInfo,
      alerts: alertManager.getAlerts(),
      activeTraces: performanceProfiler.getActiveTraces()
    });
  } catch (error) {
    logger.error('Error generating detailed health check:', error);
    res.status(500).json({ status: 'error', error: error.message });
  }
});

// Start monitoring
export const startMonitoring = () => {
  systemMonitor.start();
  logger.info('Advanced monitoring system started');
};

// Stop monitoring
export const stopMonitoring = () => {
  systemMonitor.stop();
};

// Graceful shutdown
process.on('SIGINT', () => {
  stopMonitoring();
});

process.on('SIGTERM', () => {
  stopMonitoring();
});

export {
  register,
  systemMonitor,
  healthChecker,
  performanceProfiler,
  alertManager,
  httpRequestDuration,
  httpRequestsTotal,
  activeConnections,
  databaseConnections,
  aiRequestsTotal,
  aiRequestDuration,
  userSessionsActive,
  agentInteractionsTotal,
  errorRate,
  memoryUsage,
  cpuUsage
};

module.exports = {
  register,
  httpRequestDuration,
  httpRequestsTotal,
  aiRequestDuration,
  userSessionsActive,
  agentInteractionsTotal,
  errorRate,
  memoryUsage,
  cpuUsage
};