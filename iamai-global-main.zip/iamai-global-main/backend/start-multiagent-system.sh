#!/bin/bash
#
# ⚠️  IMPORTANT DEPLOYMENT PATHS (EC2 Production):
#   BACKEND:  /home/ubuntu/iamai-global/backend/  (where PM2 runs from, has node_modules)
#   FRONTEND: /var/www/iamai-global/              (static files only, served by nginx)
#   NEVER deploy backend to /var/www/iamai-global/backend/ - it won't work!
#

echo "🚀 IAMAI MULTI-AGENT SYSTEM STARTUP"
echo "==================================="

cd /Users/onelastai/Downloads/iamai-global/backend

# Check if MongoDB is running
if ! pgrep -x "mongod" > /dev/null; then
    echo "❌ MongoDB not running. Please start MongoDB first:"
    echo "   brew services start mongodb/brew/mongodb-community"
    exit 1
fi

echo "✅ MongoDB is running"

# Initialize agents if not already done
echo "🤖 Initializing 17 agents..."
node populate-agent-configs.js

# Populate sample data
echo "📊 Populating sample data..."
node populate-multiagent-data.js

echo ""
echo "🎉 MULTI-AGENT SYSTEM READY!"
echo ""
echo "🔗 Available endpoints:"
echo "   • GET  /api/agents/agents - List all agents"
echo "   • POST /api/agents/subscription/create - Create subscription"
echo "   • POST /api/agents/chat/:userId/message - Send message"
echo "   • GET  /api/agents/health - System health"
echo ""
echo "📖 Full documentation: MULTI_AGENT_SYSTEM_COMPLETE.md"
echo ""
echo "🚀 Starting production server..."
echo "   Server will be available at: http://localhost:3001"
echo ""

# Start the production server
node production-server.js