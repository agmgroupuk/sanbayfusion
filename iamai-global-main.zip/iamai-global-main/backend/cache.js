// Advanced Caching System for IAMAI Global
// Features: Redis caching, multi-layer caching, cache invalidation, performance monitoring

const Redis = require('ioredis');
const { createClient } = require('@redis/client');
const logger = require('./logger.js');

// Redis configuration
const redisConfig = {
  host: process.env.REDIS_HOST || 'localhost',
  port: process.env.REDIS_PORT || 6379,
  password: process.env.REDIS_PASSWORD || undefined,
  db: process.env.REDIS_DB || 0,
  retryDelayOnFailover: 100,
  maxRetriesPerRequest: 3,
  lazyConnect: true,
  reconnectOnError: (err) => {
    logger.warn('Redis reconnect on error:', err.message);
    return err.message.includes('READONLY');
  }
};

// Create Redis clients
let redisClient = null;
let redisSubscriber = null;

try {
  redisClient = new Redis(redisConfig);
  redisSubscriber = new Redis(redisConfig);

  // Redis event handlers
  redisClient.on('connect', () => {
    logger.info('Redis client connected');
  });

  redisClient.on('error', (err) => {
    logger.error('Redis client error:', err);
  });

  redisClient.on('ready', () => {
    logger.info('Redis client ready');
  });

  redisSubscriber.on('connect', () => {
    logger.info('Redis subscriber connected');
  });

} catch (error) {
  logger.warn('Redis not available, falling back to in-memory cache:', error.message);
}

// In-memory fallback cache
class MemoryCache {
  constructor() {
    this.cache = new Map();
    this.ttlStore = new Map();
    this.cleanupInterval = setInterval(() => this.cleanup(), 60000); // Clean every minute
  }

  async get(key) {
    const item = this.cache.get(key);
    if (!item) return null;

    if (this.isExpired(key)) {
      this.cache.delete(key);
      this.ttlStore.delete(key);
      return null;
    }

    return item.value;
  }

  async set(key, value, ttl = 3600) {
    this.cache.set(key, { value, timestamp: Date.now() });
    if (ttl > 0) {
      this.ttlStore.set(key, Date.now() + (ttl * 1000));
    }
    return true;
  }

  async del(key) {
    this.cache.delete(key);
    this.ttlStore.delete(key);
    return 1;
  }

  async exists(key) {
    return this.cache.has(key) && !this.isExpired(key) ? 1 : 0;
  }

  async expire(key, ttl) {
    if (this.cache.has(key)) {
      this.ttlStore.set(key, Date.now() + (ttl * 1000));
      return 1;
    }
    return 0;
  }

  async ttl(key) {
    const expiry = this.ttlStore.get(key);
    if (!expiry) return -1;

    const remaining = Math.ceil((expiry - Date.now()) / 1000);
    return remaining > 0 ? remaining : -1;
  }

  isExpired(key) {
    const expiry = this.ttlStore.get(key);
    return expiry && Date.now() > expiry;
  }

  cleanup() {
    const now = Date.now();
    for (const [key, expiry] of this.ttlStore) {
      if (now > expiry) {
        this.cache.delete(key);
        this.ttlStore.delete(key);
      }
    }
  }

  async keys(pattern = '*') {
    const keys = Array.from(this.cache.keys());
    if (pattern === '*') return keys;

    // Simple pattern matching
    const regex = new RegExp(pattern.replace(/\*/g, '.*'));
    return keys.filter(key => regex.test(key));
  }

  async flushall() {
    this.cache.clear();
    this.ttlStore.clear();
    return 'OK';
  }

  quit() {
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
    }
  }
}

// Fallback to memory cache if Redis is not available
const cacheClient = redisClient || new MemoryCache();

// Multi-layer cache with different TTLs
class MultiLayerCache {
  constructor() {
    this.layers = {
      l1: { ttl: 300, name: 'L1 Fast Cache' },    // 5 minutes - hot data
      l2: { ttl: 1800, name: 'L2 Medium Cache' }, // 30 minutes - warm data
      l3: { ttl: 3600, name: 'L3 Slow Cache' }    // 1 hour - cold data
    };
  }

  async get(key, layer = 'l1') {
    const cacheKey = `${layer}:${key}`;
    try {
      const value = await cacheClient.get(cacheKey);
      if (value) {
        logger.debug(`Cache hit: ${cacheKey}`);
        return JSON.parse(value);
      }
      logger.debug(`Cache miss: ${cacheKey}`);
      return null;
    } catch (error) {
      logger.error(`Cache get error for ${cacheKey}:`, error);
      return null;
    }
  }

  async set(key, value, layer = 'l1', customTtl = null) {
    const cacheKey = `${layer}:${key}`;
    const ttl = customTtl || this.layers[layer].ttl;

    try {
      const serializedValue = JSON.stringify(value);
      await cacheClient.set(cacheKey, serializedValue, ttl);
      logger.debug(`Cache set: ${cacheKey} (TTL: ${ttl}s)`);
      return true;
    } catch (error) {
      logger.error(`Cache set error for ${cacheKey}:`, error);
      return false;
    }
  }

  async del(key, layer = null) {
    try {
      if (layer) {
        const cacheKey = `${layer}:${key}`;
        await cacheClient.del(cacheKey);
        logger.debug(`Cache delete: ${cacheKey}`);
      } else {
        // Delete from all layers
        const deletions = await Promise.all(
          Object.keys(this.layers).map(layer =>
            cacheClient.del(`${layer}:${key}`)
          )
        );
        logger.debug(`Cache delete all layers: ${key}`);
        return deletions;
      }
      return 1;
    } catch (error) {
      logger.error(`Cache delete error for ${key}:`, error);
      return 0;
    }
  }

  async invalidatePattern(pattern) {
    try {
      const keys = await cacheClient.keys(`*:${pattern}`);
      if (keys.length > 0) {
        await Promise.all(keys.map(key => cacheClient.del(key)));
        logger.info(`Invalidated ${keys.length} cache keys matching: ${pattern}`);
      }
      return keys.length;
    } catch (error) {
      logger.error(`Cache invalidation error for pattern ${pattern}:`, error);
      return 0;
    }
  }
}

// Cache manager with advanced features
class CacheManager {
  constructor() {
    this.multiLayer = new MultiLayerCache();
    this.cacheStats = {
      hits: 0,
      misses: 0,
      sets: 0,
      deletes: 0
    };
  }

  // User session caching
  async getUserSession(sessionId) {
    return await this.multiLayer.get(`session:${sessionId}`, 'l1');
  }

  async setUserSession(sessionId, sessionData, ttl = 3600) {
    return await this.multiLayer.set(`session:${sessionId}`, sessionData, 'l1', ttl);
  }

  async deleteUserSession(sessionId) {
    return await this.multiLayer.del(`session:${sessionId}`);
  }

  // API response caching
  async getAPIResponse(endpoint, params = {}) {
    const key = `${endpoint}:${JSON.stringify(params)}`;
    return await this.multiLayer.get(key, 'l2');
  }

  async setAPIResponse(endpoint, params = {}, data, ttl = 1800) {
    const key = `${endpoint}:${JSON.stringify(params)}`;
    return await this.multiLayer.set(key, data, 'l2', ttl);
  }

  // Agent data caching
  async getAgentData(agentId) {
    return await this.multiLayer.get(`agent:${agentId}`, 'l2');
  }

  async setAgentData(agentId, data, ttl = 1800) {
    return await this.multiLayer.set(`agent:${agentId}`, data, 'l2', ttl);
  }

  async invalidateAgentData(agentId) {
    return await this.multiLayer.del(`agent:${agentId}`);
  }

  // AI model responses caching
  async getAIResponse(promptHash, model = 'default') {
    return await this.multiLayer.get(`ai:${model}:${promptHash}`, 'l3');
  }

  async setAIResponse(promptHash, response, model = 'default', ttl = 3600) {
    return await this.multiLayer.set(`ai:${model}:${promptHash}`, response, 'l3', ttl);
  }

  // Database query result caching
  async getQueryResult(queryHash) {
    return await this.multiLayer.get(`query:${queryHash}`, 'l2');
  }

  async setQueryResult(queryHash, result, ttl = 1800) {
    return await this.multiLayer.set(`query:${queryHash}`, result, 'l2', ttl);
  }

  // Cache warming
  async warmCache(dataMap) {
    logger.info('Starting cache warming...');
    const promises = [];

    for (const [key, data] of Object.entries(dataMap)) {
      promises.push(this.multiLayer.set(key, data, 'l3'));
    }

    await Promise.all(promises);
    logger.info(`Cache warming completed for ${promises.length} items`);
  }

  // Cache statistics
  getStats() {
    return {
      ...this.cacheStats,
      hitRate: this.cacheStats.hits / (this.cacheStats.hits + this.cacheStats.misses) || 0,
      totalRequests: this.cacheStats.hits + this.cacheStats.misses
    };
  }

  // Cache invalidation by tags
  async invalidateByTag(tag) {
    return await this.multiLayer.invalidatePattern(`*${tag}*`);
  }

  // Bulk operations
  async setMultiple(keyValuePairs, layer = 'l2', ttl = 1800) {
    const promises = keyValuePairs.map(([key, value]) =>
      this.multiLayer.set(key, value, layer, ttl)
    );
    return await Promise.all(promises);
  }

  async getMultiple(keys, layer = 'l2') {
    const promises = keys.map(key => this.multiLayer.get(key, layer));
    return await Promise.all(promises);
  }

  async deleteMultiple(keys) {
    const promises = keys.map(key => this.multiLayer.del(key));
    return await Promise.all(promises);
  }

  // Pub/Sub for cache invalidation
  async publishInvalidation(channel, message) {
    if (redisClient) {
      await redisClient.publish(channel, JSON.stringify(message));
    }
  }

  subscribeToInvalidation(channel, callback) {
    if (redisSubscriber) {
      redisSubscriber.subscribe(channel);
      redisSubscriber.on('message', (ch, message) => {
        if (ch === channel) {
          try {
            const data = JSON.parse(message);
            callback(data);
          } catch (error) {
            logger.error('Error parsing invalidation message:', error);
          }
        }
      });
    }
  }
}

// Create cache manager instance
const cacheManager = new CacheManager();

// Cache middleware for Express
export const cacheMiddleware = (ttl = 300, layer = 'l2') => {
  return async (req, res, next) => {
    // Skip caching for non-GET requests
    if (req.method !== 'GET') return next();

    const key = `api:${req.originalUrl}`;

    try {
      const cached = await cacheManager.multiLayer.get(key, layer);
      if (cached) {
        logger.debug(`API cache hit: ${key}`);
        return res.json(cached);
      }

      // Store original json method
      const originalJson = res.json;

      // Override json method to cache response
      res.json = function(data) {
        cacheManager.multiLayer.set(key, data, layer, ttl);
        logger.debug(`API cache set: ${key}`);
        return originalJson.call(this, data);
      };

      next();
    } catch (error) {
      logger.error('Cache middleware error:', error);
      next();
    }
  };
};

// Cache invalidation helpers
export const invalidateUserCache = async (userId) => {
  await cacheManager.invalidateByTag(`user:${userId}`);
  await cacheManager.publishInvalidation('cache_invalidation', {
    type: 'user',
    userId
  });
};

export const invalidateAgentCache = async (agentId) => {
  await cacheManager.invalidateByTag(`agent:${agentId}`);
  await cacheManager.publishInvalidation('cache_invalidation', {
    type: 'agent',
    agentId
  });
};

// Graceful shutdown
process.on('SIGINT', async () => {
  if (redisClient) {
    await redisClient.quit();
  }
  if (cacheClient.quit) {
    cacheClient.quit();
  }
});

process.on('SIGTERM', async () => {
  if (redisClient) {
    await redisClient.quit();
  }
  if (cacheClient.quit) {
    cacheClient.quit();
  }
});

module.exports = cacheManager;
module.exports.CacheManager = CacheManager;
module.exports.MultiLayerCache = MultiLayerCache;