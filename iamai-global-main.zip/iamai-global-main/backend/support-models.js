// Support Tickets and Customer Service Models
// Complete ticketing system with responses and status tracking

const mongoose = require('mongoose');

// ============================================
// 1. SUPPORT TICKETS MODEL
// ============================================

const SupportTicketSchema = new mongoose.Schema(
  {
    // Ticket Identification
    ticketId: {
      type: String,
      required: true,
      unique: true, // e.g., "IAMAI-2024-001"
    },

    // User Information
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },

    // Ticket Content
    subject: {
      type: String,
      required: true,
      trim: true,
      maxlength: 200,
    },
    description: {
      type: String,
      required: true,
      maxlength: 5000,
    },

    // Ticket Classification
    category: {
      type: String,
      required: true,
      enum: [
        'technical_support',
        'billing',
        'account_issues',
        'agent_problems',
        'feature_request',
        'bug_report',
        'general_inquiry',
        'refund_request',
        'subscription_help',
      ],
    },
    priority: {
      type: String,
      required: true,
      enum: ['low', 'medium', 'high', 'urgent', 'critical'],
      default: 'medium',
    },
    type: {
      type: String,
      required: true,
      enum: ['question', 'incident', 'problem', 'request'],
      default: 'question',
    },

    // Ticket Status
    status: {
      type: String,
      required: true,
      enum: [
        'new',
        'open',
        'pending',
        'in_progress',
        'waiting_for_customer',
        'waiting_for_agent',
        'resolved',
        'closed',
        'canceled',
      ],
      default: 'new',
    },

    // Assignment
    assignedTo: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User', // Support agent
      default: null,
    },
    assignedAt: Date,
    assignedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },

    // Department/Team
    department: {
      type: String,
      enum: [
        'technical_support',
        'billing_support',
        'customer_success',
        'product_team',
        'sales',
        'general',
      ],
      default: 'general',
    },

    // Resolution
    resolution: {
      summary: String,
      resolvedBy: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
      },
      resolvedAt: Date,
      resolutionTime: Number, // Time to resolution in minutes
      satisfactionRating: {
        type: Number,
        min: 1,
        max: 5,
      },
      satisfactionFeedback: String,
    },

    // Timing and SLA
    firstResponseAt: Date,
    firstResponseTime: Number, // Time to first response in minutes
    lastActivityAt: {
      type: Date,
      default: Date.now,
    },
    closedAt: Date,

    // SLA Tracking
    sla: {
      firstResponseDue: Date,
      resolutionDue: Date,
      isBreached: {
        type: Boolean,
        default: false,
      },
      breachedAt: Date,
    },

    // Related Information
    relatedTickets: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'SupportTicket',
      },
    ],

    // User Contact Info at time of creation
    contactInfo: {
      email: String,
      name: String,
      phone: String,
    },

    // Technical Details
    technicalDetails: {
      browser: String,
      os: String,
      device: String,
      userAgent: String,
      ipAddress: String,
      url: String,
      errorMessage: String,
      steps: String,
    },

    // Escalation
    escalation: {
      isEscalated: {
        type: Boolean,
        default: false,
      },
      escalatedAt: Date,
      escalatedBy: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
      },
      escalationReason: String,
      escalationLevel: {
        type: Number,
        min: 1,
        max: 3,
        default: 1,
      },
    },

    // Internal Notes
    internalNotes: [
      {
        note: String,
        createdBy: {
          type: mongoose.Schema.Types.ObjectId,
          ref: 'User',
        },
        createdAt: {
          type: Date,
          default: Date.now,
        },
        isPrivate: {
          type: Boolean,
          default: true,
        },
      },
    ],

    // Tags for organization
    tags: [String],

    // Metadata
    metadata: {
      source: {
        type: String,
        enum: ['web', 'email', 'phone', 'chat', 'api', 'mobile'],
        default: 'web',
      },
      originalMessage: String, // If created from email
      conversationId: String, // If from chat system
      subscriptionId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Subscription',
      },
      agentId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Agent',
      },
    },
  },
  {
    timestamps: true,
  }
);

// Indexes
// SupportTicketSchema.index({ ticketId: 1 }); // Removed: unique: true already creates index
SupportTicketSchema.index({ userId: 1, createdAt: -1 });
SupportTicketSchema.index({ status: 1, priority: 1 });
SupportTicketSchema.index({ assignedTo: 1, status: 1 });
SupportTicketSchema.index({ category: 1, department: 1 });
SupportTicketSchema.index({ 'sla.resolutionDue': 1, status: 1 });
SupportTicketSchema.index({ tags: 1 });

// Generate ticket ID before saving
SupportTicketSchema.pre('save', async function (next) {
  if (this.isNew && !this.ticketId) {
    const count = await mongoose.model('SupportTicket').countDocuments();
    const year = new Date().getFullYear();
    this.ticketId = `IAMAI-${year}-${String(count + 1).padStart(6, '0')}`;
  }
  next();
});

// NOTE: SupportTicket model is defined in models.js to avoid duplicate model error

// ============================================
// 2. TICKET RESPONSES MODEL
// ============================================

const TicketResponseSchema = new mongoose.Schema(
  {
    ticketId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'SupportTicket',
      required: true,
    },

    // Response Content
    message: {
      type: String,
      required: true,
      maxlength: 10000,
    },

    // Response Type
    type: {
      type: String,
      required: true,
      enum: [
        'customer_reply',
        'agent_reply',
        'internal_note',
        'status_change',
        'system_message',
        'escalation',
        'resolution',
      ],
    },

    // Author Information
    authorId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    authorType: {
      type: String,
      required: true,
      enum: ['customer', 'agent', 'admin', 'system'],
    },
    authorName: String, // Cached name at time of response

    // Visibility
    isPublic: {
      type: Boolean,
      default: true, // False for internal notes
    },
    isFromCustomer: {
      type: Boolean,
      default: false,
    },

    // Status Changes
    statusChange: {
      from: String,
      to: String,
      reason: String,
    },

    // Timing
    responseTime: Number, // Time since last response in minutes

    // Email Information
    email: {
      messageId: String, // If response came via email
      inReplyTo: String,
      subject: String,
      sentAt: Date,
      deliveredAt: Date,
    },

    // Satisfaction Survey (for resolution responses)
    satisfaction: {
      requested: {
        type: Boolean,
        default: false,
      },
      requestedAt: Date,
      rating: {
        type: Number,
        min: 1,
        max: 5,
      },
      feedback: String,
      submittedAt: Date,
    },

    // Metadata
    metadata: {
      source: {
        type: String,
        enum: ['web', 'email', 'api', 'mobile', 'system'],
        default: 'web',
      },
      ipAddress: String,
      userAgent: String,
      editedAt: Date,
      editedBy: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
      },
    },
  },
  {
    timestamps: true,
  }
);

// Indexes
TicketResponseSchema.index({ ticketId: 1, createdAt: 1 });
TicketResponseSchema.index({ authorId: 1, createdAt: -1 });
TicketResponseSchema.index({ type: 1, isPublic: 1 });
TicketResponseSchema.index({ isFromCustomer: 1, ticketId: 1 });

const TicketResponse =
  mongoose.models.TicketResponse || mongoose.model('TicketResponse', TicketResponseSchema);

// ============================================
// 3. TICKET ATTACHMENTS MODEL
// ============================================

const TicketAttachmentSchema = new mongoose.Schema(
  {
    ticketId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'SupportTicket',
      required: true,
    },
    responseId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'TicketResponse',
      default: null, // Null if attached to original ticket
    },

    // File Information
    filename: {
      type: String,
      required: true,
    },
    originalName: {
      type: String,
      required: true,
    },
    mimeType: {
      type: String,
      required: true,
    },
    size: {
      type: Number,
      required: true, // Size in bytes
    },

    // Storage Information
    storage: {
      provider: {
        type: String,
        enum: ['local', 'aws_s3', 'google_cloud', 'azure'],
        default: 'aws_s3',
      },
      path: String,
      bucket: String,
      key: String,
      url: String,
    },

    // Security
    isPublic: {
      type: Boolean,
      default: false,
    },
    downloadToken: String, // For secure downloads

    // Uploaded By
    uploadedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    uploaderType: {
      type: String,
      enum: ['customer', 'agent', 'admin'],
      required: true,
    },

    // File Processing
    processing: {
      status: {
        type: String,
        enum: ['pending', 'processing', 'completed', 'failed'],
        default: 'completed',
      },
      scanned: {
        type: Boolean,
        default: false, // Virus/malware scan
      },
      scanResult: String,
      compressed: {
        type: Boolean,
        default: false,
      },
      thumbnail: String, // For images
    },

    // Access Control
    downloadCount: {
      type: Number,
      default: 0,
    },
    lastDownloadAt: Date,
    expiresAt: Date, // For temporary files

    // Metadata
    metadata: {
      source: String,
      description: String,
      tags: [String],
    },
  },
  {
    timestamps: true,
  }
);

// Indexes
TicketAttachmentSchema.index({ ticketId: 1 });
TicketAttachmentSchema.index({ responseId: 1 });
TicketAttachmentSchema.index({ uploadedBy: 1, createdAt: -1 });
TicketAttachmentSchema.index({ 'processing.status': 1 });

const TicketAttachment =
  mongoose.models.TicketAttachment || mongoose.model('TicketAttachment', TicketAttachmentSchema);

// ============================================
// 4. SUPPORT TEAM MODEL
// ============================================

const SupportTeamSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      unique: true,
    },
    description: String,

    // Team Settings
    department: {
      type: String,
      required: true,
      enum: ['technical_support', 'billing_support', 'customer_success', 'product_team', 'sales'],
    },

    // Team Members
    members: [
      {
        userId: {
          type: mongoose.Schema.Types.ObjectId,
          ref: 'User',
          required: true,
        },
        role: {
          type: String,
          enum: ['agent', 'senior_agent', 'lead', 'manager'],
          default: 'agent',
        },
        joinedAt: {
          type: Date,
          default: Date.now,
        },
        isActive: {
          type: Boolean,
          default: true,
        },
      },
    ],

    // Assignment Rules
    assignment: {
      method: {
        type: String,
        enum: ['round_robin', 'least_active', 'random', 'manual'],
        default: 'round_robin',
      },
      autoAssign: {
        type: Boolean,
        default: true,
      },
      maxTicketsPerAgent: {
        type: Number,
        default: 50,
      },
    },

    // SLA Settings
    sla: {
      firstResponse: {
        type: Number,
        default: 60, // Minutes
      },
      resolution: {
        type: Number,
        default: 1440, // Minutes (24 hours)
      },
    },

    // Business Hours
    businessHours: {
      timezone: {
        type: String,
        default: 'UTC',
      },
      schedule: {
        monday: {
          start: { type: String, default: '09:00' },
          end: { type: String, default: '17:00' },
          enabled: { type: Boolean, default: true },
        },
        tuesday: {
          start: { type: String, default: '09:00' },
          end: { type: String, default: '17:00' },
          enabled: { type: Boolean, default: true },
        },
        wednesday: {
          start: { type: String, default: '09:00' },
          end: { type: String, default: '17:00' },
          enabled: { type: Boolean, default: true },
        },
        thursday: {
          start: { type: String, default: '09:00' },
          end: { type: String, default: '17:00' },
          enabled: { type: Boolean, default: true },
        },
        friday: {
          start: { type: String, default: '09:00' },
          end: { type: String, default: '17:00' },
          enabled: { type: Boolean, default: true },
        },
        saturday: {
          start: { type: String, default: '10:00' },
          end: { type: String, default: '14:00' },
          enabled: { type: Boolean, default: false },
        },
        sunday: {
          start: { type: String, default: '10:00' },
          end: { type: String, default: '14:00' },
          enabled: { type: Boolean, default: false },
        },
      },
    },

    // Statistics
    stats: {
      ticketsAssigned: {
        type: Number,
        default: 0,
      },
      ticketsResolved: {
        type: Number,
        default: 0,
      },
      avgResolutionTime: {
        type: Number,
        default: 0,
      },
      avgSatisfactionRating: {
        type: Number,
        default: 0,
      },
    },

    // Settings
    isActive: {
      type: Boolean,
      default: true,
    },

    // Metadata
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
  },
  {
    timestamps: true,
  }
);

// Indexes
SupportTeamSchema.index({ department: 1, isActive: 1 });
SupportTeamSchema.index({ 'members.userId': 1 });

const SupportTeam = mongoose.models.SupportTeam || mongoose.model('SupportTeam', SupportTeamSchema);

// Export all support models (SupportTicket exported from models.js to avoid conflicts)
module.exports = {
  TicketResponse,
  TicketAttachment,
  SupportTeam,
};
