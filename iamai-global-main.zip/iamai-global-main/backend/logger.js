// Advanced Logging System for IAMAI Global
// Features: Winston with multiple transports, structured logging, performance monitoring

const winston = require('winston');
const DailyRotateFile = require('winston-daily-rotate-file');
const winstonMongoDB = require('winston-mongodb');
const path = require('path');

const __filename = __filename;
const __dirname = __dirname;
const __dirname = path.dirname(__filename);

// Custom log levels
const customLevels = {
  error: 0,
  warn: 1,
  info: 2,
  http: 3,
  debug: 4,
  performance: 5,
  security: 6,
  audit: 7
};

const customColors = {
  error: 'red',
  warn: 'yellow',
  info: 'green',
  http: 'magenta',
  debug: 'blue',
  performance: 'cyan',
  security: 'red',
  audit: 'grey'
};

winston.addColors(customColors);

// Performance monitoring transport
class PerformanceTransport extends winston.Transport {
  constructor(opts) {
    super(opts);
    this.name = 'performance';
    this.metrics = new Map();
  }

  log(level, msg, meta, callback) {
    if (level === 'performance') {
      const { operation, duration, memory, cpu } = meta;
      if (operation) {
        const key = `${operation}_${Date.now()}`;
        this.metrics.set(key, { duration, memory, cpu, timestamp: new Date() });

        // Keep only last 1000 metrics
        if (this.metrics.size > 1000) {
          const firstKey = this.metrics.keys().next().value;
          this.metrics.delete(firstKey);
        }
      }
    }
    callback();
  }

  getMetrics() {
    return Array.from(this.metrics.entries()).map(([key, value]) => ({
      operation: key.split('_')[0],
      ...value
    }));
  }
}

// Security monitoring transport
class SecurityTransport extends winston.Transport {
  constructor(opts) {
    super(opts);
    this.name = 'security';
    this.alerts = [];
  }

  log(level, msg, meta, callback) {
    if (level === 'security') {
      const alert = {
        timestamp: new Date(),
        level,
        message: msg,
        ...meta,
        severity: this.calculateSeverity(meta)
      };
      this.alerts.push(alert);

      // Keep only last 500 alerts
      if (this.alerts.length > 500) {
        this.alerts.shift();
      }

      // Trigger immediate alerts for critical security events
      if (alert.severity === 'critical') {
        this.triggerAlert(alert);
      }
    }
    callback();
  }

  calculateSeverity(meta) {
    const { type, attempts, ip } = meta;
    if (type === 'brute_force' && attempts > 10) return 'critical';
    if (type === 'suspicious_ip' && attempts > 5) return 'high';
    if (type === 'unauthorized_access') return 'high';
    return 'medium';
  }

  triggerAlert(alert) {
    // Implement alert mechanism (email, SMS, webhook, etc.)
    console.error('🚨 CRITICAL SECURITY ALERT:', alert);
  }

  getAlerts() {
    return this.alerts;
  }
}

// Create logger instance
const logger = winston.createLogger({
  levels: customLevels,
  level: process.env.LOG_LEVEL || 'info',
  format: winston.format.combine(
    winston.format.timestamp({
      format: 'YYYY-MM-DD HH:mm:ss'
    }),
    winston.format.errors({ stack: true }),
    winston.format.json(),
    winston.format.colorize({ all: true })
  ),
  defaultMeta: { service: 'iamai-backend' },
  transports: [
    // Console transport for development
    new winston.transports.Console({
      format: winston.format.combine(
        winston.format.colorize(),
        winston.format.simple()
      )
    }),

    // Error log file
    new DailyRotateFile({
      filename: path.join(__dirname, '../logs/error-%DATE%.log'),
      datePattern: 'YYYY-MM-DD',
      level: 'error',
      maxSize: '20m',
      maxFiles: '14d'
    }),

    // Combined log file
    new DailyRotateFile({
      filename: path.join(__dirname, '../logs/combined-%DATE%.log'),
      datePattern: 'YYYY-MM-DD',
      maxSize: '20m',
      maxFiles: '14d'
    }),

    // Performance log file
    new DailyRotateFile({
      filename: path.join(__dirname, '../logs/performance-%DATE%.log'),
      datePattern: 'YYYY-MM-DD',
      level: 'performance',
      maxSize: '20m',
      maxFiles: '7d'
    }),

    // Security log file
    new DailyRotateFile({
      filename: path.join(__dirname, '../logs/security-%DATE%.log'),
      datePattern: 'YYYY-MM-DD',
      level: 'security',
      maxSize: '20m',
      maxFiles: '30d'
    }),

    // Audit log file
    new DailyRotateFile({
      filename: path.join(__dirname, '../logs/audit-%DATE%.log'),
      datePattern: 'YYYY-MM-DD',
      level: 'audit',
      maxSize: '20m',
      maxFiles: '90d'
    })
  ]
});

// Add MongoDB transport if configured
if (process.env.MONGODB_URI) {
  logger.add(new winstonMongoDB.MongoDB({
    level: 'error',
    db: process.env.MONGODB_URI,
    collection: 'logs',
    format: winston.format.combine(
      winston.format.timestamp(),
      winston.format.json()
    ),
    options: { useUnifiedTopology: true },
    metaKey: 'meta'
  }));
}

// Add custom transports
const performanceTransport = new PerformanceTransport();
const securityTransport = new SecurityTransport();

logger.add(performanceTransport);
logger.add(securityTransport);

// Performance monitoring middleware
export const performanceMonitor = (operation) => {
  return (req, res, next) => {
    const start = process.hrtime.bigint();
    const startMemory = process.memoryUsage();
    const startCpu = process.cpuUsage();

    res.on('finish', () => {
      const end = process.hrtime.bigint();
      const endMemory = process.memoryUsage();
      const endCpu = process.cpuUsage();

      const duration = Number(end - start) / 1000000; // Convert to milliseconds
      const memoryDelta = {
        rss: endMemory.rss - startMemory.rss,
        heapUsed: endMemory.heapUsed - startMemory.heapUsed,
        heapTotal: endMemory.heapTotal - startMemory.heapTotal
      };
      const cpuDelta = {
        user: endCpu.user - startCpu.user,
        system: endCpu.system - startCpu.system
      };

      logger.performance('API Performance', {
        operation: operation || `${req.method} ${req.path}`,
        duration,
        memory: memoryDelta,
        cpu: cpuDelta,
        statusCode: res.statusCode,
        userAgent: req.get('User-Agent'),
        ip: req.ip
      });
    });

    next();
  };
};

// Security monitoring functions
export const logSecurityEvent = (type, details) => {
  logger.security(`Security Event: ${type}`, {
    type,
    ...details,
    timestamp: new Date()
  });
};

export const logAuditEvent = (action, userId, details) => {
  logger.audit(`Audit: ${action}`, {
    action,
    userId,
    ...details,
    timestamp: new Date()
  });
};

// Request logging middleware
export const requestLogger = winston.createLogger({
  level: 'http',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json()
  ),
  transports: [
    new DailyRotateFile({
      filename: path.join(__dirname, '../logs/requests-%DATE%.log'),
      datePattern: 'YYYY-MM-DD',
      maxSize: '20m',
      maxFiles: '7d'
    })
  ]
});

// Express middleware for request logging
export const expressRequestLogger = (req, res, next) => {
  const start = Date.now();

  res.on('finish', () => {
    const duration = Date.now() - start;
    requestLogger.http('Request', {
      method: req.method,
      url: req.url,
      status: res.statusCode,
      duration,
      ip: req.ip,
      userAgent: req.get('User-Agent'),
      userId: req.user?.id || 'anonymous'
    });
  });

  next();
};

// Health check and metrics
export const getSystemHealth = () => {
  const memUsage = process.memoryUsage();
  const cpuUsage = process.cpuUsage();

  return {
    uptime: process.uptime(),
    memory: {
      rss: memUsage.rss,
      heapUsed: memUsage.heapUsed,
      heapTotal: memUsage.heapTotal,
      external: memUsage.external
    },
    cpu: cpuUsage,
    performanceMetrics: performanceTransport.getMetrics(),
    securityAlerts: securityTransport.getAlerts(),
    timestamp: new Date()
  };
};

export const getLogStats = () => {
  // Implementation for log statistics
  return {
    totalLogs: 'N/A', // Would need to implement log file analysis
    errorCount: 'N/A',
    performanceMetricsCount: performanceTransport.getMetrics().length,
    securityAlertsCount: securityTransport.getAlerts().length
  };
};

// Graceful shutdown
process.on('SIGINT', () => {
  logger.info('Received SIGINT, shutting down gracefully...');
  logger.end();
});

process.on('SIGTERM', () => {
  logger.info('Received SIGTERM, shutting down gracefully...');
  logger.end();
});

module.exports = logger;