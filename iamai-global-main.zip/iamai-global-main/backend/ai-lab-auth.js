// AI Lab & Toolbox Subscription Validation Middleware
// Centralized access control for AI Lab experiments and Toolbox tools
//
// IMPORTANT BUSINESS RULE (2025 update):
// - There are NO separate subscriptions for the AI Lab or Toolbox.
// - If a user has ANY active IAMAI subscription (to any agent/plan),
//   they can access ALL AI Lab experiments and ALL Toolbox tools.
// - If the user has NO active subscription, access is denied.

const jwt = require('jsonwebtoken');
const {
  AILabAccess,
  AILabUsageAnalytics,
  ToolboxAccess,
  ToolboxUsageAnalytics,
} = require('./ai-lab-models');
const { UserAuth } = require('./models');

// ============================================
// HELPER: Resolve userId from HttpOnly cookie or Authorization header
// ============================================

const getUserIdFromRequest = req => {
  // Prefer HttpOnly cookie (primary auth mechanism)
  let token = req.cookies?.authToken || null;

  // Fallback to Authorization header for legacy clients
  if (!token) {
    const header = req.header('Authorization');
    if (header && header.startsWith('Bearer ')) {
      token = header.replace('Bearer ', '');
    }
  }

  if (!token) {
    return { error: 'NO_TOKEN' };
  }

  // Try both secrets - JWT_SECRET first, then legacy fallback
  const secrets = [
    process.env.JWT_SECRET,
    'your-secret-key-change-this'  // Legacy fallback for tokens issued before JWT_SECRET fix
  ].filter(Boolean);
  
  let decoded = null;
  let lastError = null;
  
  for (const secret of secrets) {
    try {
      decoded = jwt.verify(token, secret);
      break;
    } catch (error) {
      lastError = error;
    }
  }
  
  if (!decoded) {
    if (lastError?.name === 'TokenExpiredError') {
      return { error: 'TOKEN_EXPIRED' };
    }
    return { error: 'INVALID_TOKEN' };
  }
  
  const userId = decoded.id || decoded.userId;
  if (!userId) {
    return { error: 'INVALID_TOKEN' };
  }
  return { userId };
};

// ============================================
// HELPER: Determine if user has ANY active IAMAI purchase
// ============================================

const getActiveSubscriptionForUser = async userId => {
  const now = new Date();

  // Look for the most recent active purchase (unified + legacy fields)
  const AgentPurchase = require('./agent-purchase-models').AgentPurchase;
  const purchase = await AgentPurchase.findOne({
    userId,
    $or: [
      { status: 'ACTIVE', expiresAt: { $gt: now } },
      { status: 'active', expirationDate: { $gt: now } },
    ],
  }).sort({ expiresAt: -1, expirationDate: -1 });

  if (!purchase) {
    return { isActive: false, subscription: null };
  }

  const metaPlan = purchase.metadata?.plan;
  const rawPlan = (
    purchase.plan ||
    metaPlan ||
    purchase.planType ||
    'DAILY'
  )
    .toString()
    .toUpperCase();

  const currentPeriodEnd = purchase.expiresAt || purchase.expirationDate || purchase.purchaseDate;

  const subscription = {
    plan: rawPlan,
    status: 'ACTIVE',
    billing: {
      currentPeriodEnd,
    },
  };

  return { isActive: true, subscription };
};

// ============================================
// SUBSCRIPTION VALIDATION MIDDLEWARE (AI LAB)
// ============================================

const validateSubscription = async (req, res, next) => {
  try {
    // 1. Resolve authenticated user from cookie/header
    const { userId, error } = getUserIdFromRequest(req);

    if (error) {
      const statusCode = error === 'NO_TOKEN' ? 401 : 401;
      const message =
        error === 'NO_TOKEN'
          ? 'Access denied. No authentication token provided.'
          : error === 'TOKEN_EXPIRED'
            ? 'Authentication token has expired.'
            : 'Invalid authentication token.';

      return res.status(statusCode).json({
        success: false,
        error: message,
        code: error,
      });
    }

    // 2. Get user authentication record (sanity check)
    const user = await UserAuth.findById(userId);
    if (!user) {
      return res.status(401).json({
        success: false,
        error: 'User not found.',
        code: 'USER_NOT_FOUND',
      });
    }

    // 3. Get or create AI Lab access record (for usage & permissions)
    let labAccess = await AILabAccess.findOne({ userId });

    if (!labAccess) {
      // Create default access record for new users
      labAccess = new AILabAccess({
        userId,
        subscriptionStatus: {
          hasActiveSubscription: false,
        },
        permissions: {
          canAccessPlayground: false,
          canAccessBattleArena: false,
          canAccessResearch: false,
          canAccessCodePlayground: false,
          canAccessAdvancedTools: false,
          maxExperimentsPerDay: 0,
          maxModelsPerComparison: 1,
          canExportResults: false,
        },
        usage: {
          totalExperiments: 0,
          todayExperiments: 0,
          lastResetDate: new Date(),
          totalTokensUsed: 0,
          totalCostIncurred: 0,
        },
      });
      await labAccess.save();
    }

    // 4. Check global IAMAI subscription status – this is the ONLY gate
    const { isActive, subscription } = await getActiveSubscriptionForUser(userId);

    if (!isActive || !subscription) {
      // Ensure lab access record reflects inactive state
      labAccess.subscriptionStatus.hasActiveSubscription = false;
      await labAccess.save();

      return res.status(403).json({
        success: false,
        error: 'AI Lab access requires an active subscription to any IAMAI agent.',
        code: 'NO_SUBSCRIPTION',
        subscriptionRequired: true,
      });
    }

    // 5. Sync AI Lab access record with global subscription
    const planType = (subscription.plan || '').toLowerCase(); // 'daily' | 'weekly' | 'monthly'

    labAccess.subscriptionStatus = {
      ...(labAccess.subscriptionStatus || {}),
      hasActiveSubscription: true,
      subscriptionType: planType || 'monthly',
      subscriptionId: subscription.stripeSubscriptionId || subscription._id?.toString(),
      expiresAt: subscription.billing?.currentPeriodEnd,
      startedAt: subscription.billing?.startDate || new Date(),
      autoRenew: subscription.autoRenew !== undefined ? subscription.autoRenew : true,
    };

    // Preserve any existing permission tuning but ensure reasonable defaults
    if (!labAccess.permissions || !labAccess.permissions.maxExperimentsPerDay) {
      // Basic tiered permissions based on plan
      const permissionPresets = {
        daily: {
          canAccessPlayground: true,
          canAccessBattleArena: false,
          canAccessResearch: false,
          canAccessCodePlayground: false,
          canAccessAdvancedTools: false,
          maxExperimentsPerDay: 10,
          maxModelsPerComparison: 2,
          canExportResults: false,
        },
        weekly: {
          canAccessPlayground: true,
          canAccessBattleArena: true,
          canAccessResearch: false,
          canAccessCodePlayground: true,
          canAccessAdvancedTools: false,
          maxExperimentsPerDay: 50,
          maxModelsPerComparison: 3,
          canExportResults: true,
        },
        monthly: {
          canAccessPlayground: true,
          canAccessBattleArena: true,
          canAccessResearch: true,
          canAccessCodePlayground: true,
          canAccessAdvancedTools: true,
          maxExperimentsPerDay: 200,
          maxModelsPerComparison: 5,
          canExportResults: true,
        },
      };

      const effectivePermissions =
        permissionPresets[planType] || permissionPresets.monthly || labAccess.permissions;

      labAccess.permissions = {
        ...(labAccess.permissions || {}),
        ...effectivePermissions,
      };
    }

    await labAccess.save();

    // 5. Check subscription expiry
    if (
      labAccess.subscriptionStatus.expiresAt &&
      new Date() > labAccess.subscriptionStatus.expiresAt
    ) {
      // Subscription expired - disable access
      labAccess.subscriptionStatus.hasActiveSubscription = false;
      labAccess.permissions.canAccessPlayground = false;
      labAccess.permissions.canAccessBattleArena = false;
      labAccess.permissions.canAccessResearch = false;
      labAccess.permissions.canAccessCodePlayground = false;
      labAccess.permissions.canAccessAdvancedTools = false;
      labAccess.permissions.maxExperimentsPerDay = 0;

      await labAccess.save();

      return res.status(403).json({
        success: false,
        error: 'Your AI Lab subscription has expired.',
        code: 'SUBSCRIPTION_EXPIRED',
        expiredOn: labAccess.subscriptionStatus.expiresAt,
        renewalRequired: true,
      });
    }

    // 6. Reset daily usage if needed
    const today = new Date();
    const lastReset = new Date(labAccess.usage.lastResetDate);

    if (today.toDateString() !== lastReset.toDateString()) {
      labAccess.usage.todayExperiments = 0;
      labAccess.usage.lastResetDate = today;
      await labAccess.save();
    }

    // 7. Check daily experiment limits
    if (labAccess.usage.todayExperiments >= labAccess.permissions.maxExperimentsPerDay) {
      return res.status(429).json({
        success: false,
        error: `Daily experiment limit reached (${labAccess.permissions.maxExperimentsPerDay} experiments).`,
        code: 'DAILY_LIMIT_REACHED',
        resetTime: new Date(today.getTime() + 24 * 60 * 60 * 1000), // tomorrow
      });
    }

    // 8. Attach user and lab access to request
    req.user = user;
    req.userId = userId;
    req.labAccess = labAccess;

    next();
  } catch (error) {
    console.error('Subscription validation error:', error);

    if (error.name === 'JsonWebTokenError') {
      return res.status(401).json({
        success: false,
        error: 'Invalid token.',
        code: 'INVALID_TOKEN',
      });
    }

    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({
        success: false,
        error: 'Token expired.',
        code: 'TOKEN_EXPIRED',
      });
    }

    return res.status(500).json({
      success: false,
      error: 'Subscription validation failed.',
      code: 'VALIDATION_ERROR',
    });
  }
};

// ============================================
// FEATURE-SPECIFIC PERMISSION VALIDATORS
// ============================================

const requireFeatureAccess = feature => {
  return (req, res, next) => {
    const { labAccess } = req;

    const featurePermissions = {
      playground: labAccess.permissions.canAccessPlayground,
      'battle-arena': labAccess.permissions.canAccessBattleArena,
      research: labAccess.permissions.canAccessResearch,
      'code-playground': labAccess.permissions.canAccessCodePlayground,
      'advanced-tools': labAccess.permissions.canAccessAdvancedTools,
      export: labAccess.permissions.canExportResults,
    };

    if (!featurePermissions[feature]) {
      return res.status(403).json({
        success: false,
        error: `Access to ${feature} requires a higher subscription tier.`,
        code: 'FEATURE_ACCESS_DENIED',
        requiredFeature: feature,
        currentPermissions: labAccess.permissions,
      });
    }

    next();
  };
};

// ============================================
// USAGE TRACKING MIDDLEWARE
// ============================================

const trackUsage = (experimentType = 'general') => {
  return async (req, res, next) => {
    // Store original send function
    const originalSend = res.send;

    // Override send to track usage after response
    res.send = function (data) {
      // Call original send first
      originalSend.call(this, data);

      // Track usage asynchronously
      setImmediate(async () => {
        try {
          const { userId, labAccess } = req;

          // Update lab access usage
          labAccess.usage.totalExperiments += 1;
          labAccess.usage.todayExperiments += 1;

          if (req.tokensUsed) {
            labAccess.usage.totalTokensUsed += req.tokensUsed;
          }

          if (req.costIncurred) {
            labAccess.usage.totalCostIncurred += req.costIncurred;
          }

          await labAccess.save();

          // Create usage analytics record
          const sessionId = req.sessionId || req.ip + '-' + Date.now();

          await AILabUsageAnalytics.findOneAndUpdate(
            {
              userId,
              sessionId,
              'usage.date': {
                $gte: new Date().setHours(0, 0, 0, 0),
                $lt: new Date().setHours(23, 59, 59, 999),
              },
            },
            {
              $inc: {
                'usage.experimentsCount': 1,
                'usage.totalTokens': req.tokensUsed || 0,
                'usage.totalCost': req.costIncurred || 0,
                [`usage.breakdown.${experimentType}.experiments`]: 1,
                [`usage.breakdown.${experimentType}.tokens`]: req.tokensUsed || 0,
                [`usage.breakdown.${experimentType}.cost`]: req.costIncurred || 0,
              },
              $addToSet: {
                'usage.toolsUsed': experimentType,
                'usage.modelsUsed': { $each: req.modelsUsed || [] },
              },
              $set: {
                subscriptionSnapshot: {
                  type: labAccess.subscriptionStatus.subscriptionType,
                  tier: labAccess.subscriptionStatus.subscriptionType,
                  validUntil: labAccess.subscriptionStatus.expiresAt,
                  permissions: labAccess.permissions,
                },
              },
            },
            {
              upsert: true,
              new: true,
              setDefaultsOnInsert: true,
            }
          );
        } catch (error) {
          console.error('Usage tracking error:', error);
        }
      });
    };

    next();
  };
};

// ============================================
// SUBSCRIPTION MANAGEMENT FUNCTIONS
// ============================================

const activateSubscription = async (userId, subscriptionData) => {
  try {
    const { type, duration, features } = subscriptionData;

    // Calculate expiry date
    const now = new Date();
    let expiresAt;

    switch (type) {
      case 'daily':
        expiresAt = new Date(now.getTime() + 24 * 60 * 60 * 1000);
        break;
      case 'weekly':
        expiresAt = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
        break;
      case 'monthly':
        expiresAt = new Date(now.getFullYear(), now.getMonth() + 1, now.getDate());
        break;
      case 'yearly':
        expiresAt = new Date(now.getFullYear() + 1, now.getMonth(), now.getDate());
        break;
      case 'lifetime':
        expiresAt = new Date(2099, 11, 31); // Far future
        break;
      default:
        throw new Error('Invalid subscription type');
    }

    // Define permissions based on subscription type
    const permissions = {
      daily: {
        canAccessPlayground: true,
        canAccessBattleArena: false,
        canAccessResearch: false,
        canAccessCodePlayground: false,
        canAccessAdvancedTools: false,
        maxExperimentsPerDay: 10,
        maxModelsPerComparison: 2,
        canExportResults: false,
      },
      weekly: {
        canAccessPlayground: true,
        canAccessBattleArena: true,
        canAccessResearch: false,
        canAccessCodePlayground: true,
        canAccessAdvancedTools: false,
        maxExperimentsPerDay: 50,
        maxModelsPerComparison: 3,
        canExportResults: true,
      },
      monthly: {
        canAccessPlayground: true,
        canAccessBattleArena: true,
        canAccessResearch: true,
        canAccessCodePlayground: true,
        canAccessAdvancedTools: true,
        maxExperimentsPerDay: 200,
        maxModelsPerComparison: 5,
        canExportResults: true,
      },
      yearly: {
        canAccessPlayground: true,
        canAccessBattleArena: true,
        canAccessResearch: true,
        canAccessCodePlayground: true,
        canAccessAdvancedTools: true,
        maxExperimentsPerDay: 1000,
        maxModelsPerComparison: 10,
        canExportResults: true,
      },
      lifetime: {
        canAccessPlayground: true,
        canAccessBattleArena: true,
        canAccessResearch: true,
        canAccessCodePlayground: true,
        canAccessAdvancedTools: true,
        maxExperimentsPerDay: 9999,
        maxModelsPerComparison: 20,
        canExportResults: true,
      },
    };

    // Update AI Lab access
    const labAccess = await AILabAccess.findOneAndUpdate(
      { userId },
      {
        subscriptionStatus: {
          hasActiveSubscription: true,
          subscriptionType: type,
          subscriptionId: subscriptionData.subscriptionId,
          expiresAt,
          startedAt: now,
          autoRenew: subscriptionData.autoRenew || true,
        },
        permissions: permissions[type] || permissions.monthly,
      },
      {
        upsert: true,
        new: true,
        setDefaultsOnInsert: true,
      }
    );

    return {
      success: true,
      subscription: labAccess.subscriptionStatus,
      permissions: labAccess.permissions,
      message: `AI Lab ${type} subscription activated successfully!`,
    };
  } catch (error) {
    console.error('Subscription activation error:', error);
    return {
      success: false,
      error: 'Failed to activate subscription',
      details: error.message,
    };
  }
};

const deactivateSubscription = async (userId, reason = 'user_request') => {
  try {
    const labAccess = await AILabAccess.findOneAndUpdate(
      { userId },
      {
        'subscriptionStatus.hasActiveSubscription': false,
        'permissions.canAccessPlayground': false,
        'permissions.canAccessBattleArena': false,
        'permissions.canAccessResearch': false,
        'permissions.canAccessCodePlayground': false,
        'permissions.canAccessAdvancedTools': false,
        'permissions.maxExperimentsPerDay': 0,
        'permissions.canExportResults': false,
      },
      { new: true }
    );

    return {
      success: true,
      message: 'AI Lab subscription deactivated',
      reason,
      deactivatedAt: new Date(),
    };
  } catch (error) {
    console.error('Subscription deactivation error:', error);
    return {
      success: false,
      error: 'Failed to deactivate subscription',
      details: error.message,
    };
  }
};

// ============================================
// TOOLBOX SUBSCRIPTION VALIDATION
// ============================================

const validateToolboxSubscription = async (req, res, next) => {
  try {
    // Resolve user via cookie/header (same as AI Lab)
    const { userId, error } = getUserIdFromRequest(req);

    if (error) {
      const statusCode = error === 'NO_TOKEN' ? 401 : 401;
      const message =
        error === 'NO_TOKEN'
          ? 'Access denied. Please login to access toolbox.'
          : error === 'TOKEN_EXPIRED'
            ? 'Authentication token has expired.'
            : 'Invalid authentication token.';

      return res.status(statusCode).json({
        success: false,
        error: message,
        code: error,
      });
    }

    // Check unified IAMAI subscription (no separate Toolbox/AI Lab plan)
    const { isActive, subscription } = await getActiveSubscriptionForUser(userId);

    if (!isActive || !subscription) {
      return res.status(403).json({
        success: false,
        error: 'Toolbox access requires an active subscription to any IAMAI agent.',
        code: 'NO_SUBSCRIPTION',
        redirectTo: '/pricing',
        message:
          'Subscribe to any agent (daily, weekly, or monthly) to unlock all toolbox features',
      });
    }

    // Get or create AI Lab access record used for toolbox permissions snapshot
    let labAccess = await AILabAccess.findOne({ userId });

    if (!labAccess) {
      labAccess = new AILabAccess({
        userId,
        subscriptionStatus: {
          hasActiveSubscription: true,
          subscriptionType: (subscription.plan || '').toLowerCase() || 'monthly',
          subscriptionId: subscription.stripeSubscriptionId || subscription._id?.toString(),
          expiresAt: subscription.billing?.currentPeriodEnd,
          startedAt: subscription.billing?.startDate || new Date(),
          autoRenew: subscription.autoRenew !== undefined ? subscription.autoRenew : true,
        },
        permissions: {},
        usage: {
          totalExperiments: 0,
          todayExperiments: 0,
          lastResetDate: new Date(),
          totalTokensUsed: 0,
          totalCostIncurred: 0,
        },
      });
    } else {
      // Ensure subscriptionStatus reflects current global subscription
      labAccess.subscriptionStatus.hasActiveSubscription = true;
      labAccess.subscriptionStatus.subscriptionType = (subscription.plan || '').toLowerCase();
      labAccess.subscriptionStatus.subscriptionId =
        subscription.stripeSubscriptionId || subscription._id?.toString();
      labAccess.subscriptionStatus.expiresAt = subscription.billing?.currentPeriodEnd;
      labAccess.subscriptionStatus.startedAt =
        labAccess.subscriptionStatus.startedAt || subscription.billing?.startDate || new Date();
      labAccess.subscriptionStatus.autoRenew =
        subscription.autoRenew !== undefined ? subscription.autoRenew : true;
    }

    // Get or create toolbox access record (permissions derived from subscription tier)
    let toolboxAccess = await ToolboxAccess.findOne({ userId });

    if (!toolboxAccess) {
      // Create toolbox access based on AI Lab subscription
      const permissions = getToolboxPermissions(labAccess.subscriptionStatus.subscriptionType);

      toolboxAccess = new ToolboxAccess({
        userId,
        hasToolboxAccess: true,
        permissions,
        usage: {
          totalToolUsage: 0,
          todayToolUsage: 0,
          lastResetDate: new Date(),
          toolsUsed: [],
          favoriteTools: [],
        },
      });
      await toolboxAccess.save();
    }

    // Reset daily usage if needed
    const today = new Date();
    const lastReset = new Date(toolboxAccess.usage.lastResetDate);

    if (today.toDateString() !== lastReset.toDateString()) {
      toolboxAccess.usage.todayToolUsage = 0;
      toolboxAccess.usage.lastResetDate = today;
      await toolboxAccess.save();
    }

    // Check daily limits
    if (toolboxAccess.usage.todayToolUsage >= toolboxAccess.permissions.maxToolUsagePerDay) {
      return res.status(429).json({
        success: false,
        error: `Daily toolbox limit reached (${toolboxAccess.permissions.maxToolUsagePerDay} uses).`,
        code: 'DAILY_LIMIT_REACHED',
        resetTime: new Date(today.getTime() + 24 * 60 * 60 * 1000),
      });
    }

    req.userId = userId;
    req.toolboxAccess = toolboxAccess;
    req.labAccess = labAccess;

    next();
  } catch (error) {
    console.error('Toolbox subscription validation error:', error);

    if (error.name === 'JsonWebTokenError') {
      return res.status(401).json({
        success: false,
        error: 'Invalid token.',
        code: 'INVALID_TOKEN',
      });
    }

    return res.status(500).json({
      success: false,
      error: 'Toolbox access validation failed.',
      code: 'VALIDATION_ERROR',
    });
  }
};

// Get toolbox permissions based on AI Lab subscription tier
const getToolboxPermissions = subscriptionType => {
  const permissions = {
    daily: {
      canAccessNetworkTools: true,
      canAccessDomainTools: true,
      canAccessSecurityTools: false,
      canAccessUtilityTools: true,
      canAccessWebTools: false,
      canAccessMonitoringTools: false,
      canAccessDevelopmentTools: false,
      maxToolUsagePerDay: 50,
      canExportResults: false,
    },
    weekly: {
      canAccessNetworkTools: true,
      canAccessDomainTools: true,
      canAccessSecurityTools: true,
      canAccessUtilityTools: true,
      canAccessWebTools: true,
      canAccessMonitoringTools: false,
      canAccessDevelopmentTools: true,
      maxToolUsagePerDay: 200,
      canExportResults: true,
    },
    monthly: {
      canAccessNetworkTools: true,
      canAccessDomainTools: true,
      canAccessSecurityTools: true,
      canAccessUtilityTools: true,
      canAccessWebTools: true,
      canAccessMonitoringTools: true,
      canAccessDevelopmentTools: true,
      maxToolUsagePerDay: 1000,
      canExportResults: true,
    },
    yearly: {
      canAccessNetworkTools: true,
      canAccessDomainTools: true,
      canAccessSecurityTools: true,
      canAccessUtilityTools: true,
      canAccessWebTools: true,
      canAccessMonitoringTools: true,
      canAccessDevelopmentTools: true,
      maxToolUsagePerDay: 5000,
      canExportResults: true,
    },
  };

  return permissions[subscriptionType] || permissions.daily;
};

// Track toolbox usage
const trackToolboxUsage = (toolCategory = 'general') => {
  return async (req, res, next) => {
    const originalSend = res.send;

    res.send = function (data) {
      originalSend.call(this, data);

      setImmediate(async () => {
        try {
          const { userId, toolboxAccess } = req;

          // Update toolbox usage
          toolboxAccess.usage.totalToolUsage += 1;
          toolboxAccess.usage.todayToolUsage += 1;

          if (!toolboxAccess.usage.toolsUsed.includes(toolCategory)) {
            toolboxAccess.usage.toolsUsed.push(toolCategory);
          }

          await toolboxAccess.save();

          // Create usage analytics record
          const sessionId = req.sessionId || req.ip + '-' + Date.now();

          await ToolboxUsageAnalytics.findOneAndUpdate(
            {
              userId,
              sessionId,
              'usage.date': {
                $gte: new Date().setHours(0, 0, 0, 0),
                $lt: new Date().setHours(23, 59, 59, 999),
              },
            },
            {
              $inc: {
                'usage.totalQueries': 1,
                [`usage.breakdown.${toolCategory}.queries`]: 1,
              },
              $addToSet: {
                'usage.toolsUsed': toolCategory,
              },
              $set: {
                subscriptionSnapshot: {
                  type: req.labAccess?.subscriptionStatus?.subscriptionType || 'none',
                  tier: req.labAccess?.subscriptionStatus?.subscriptionType || 'none',
                  validUntil: req.labAccess?.subscriptionStatus?.expiresAt,
                },
              },
            },
            {
              upsert: true,
              new: true,
              setDefaultsOnInsert: true,
            }
          );
        } catch (error) {
          console.error('Toolbox usage tracking error:', error);
        }
      });
    };

    next();
  };
};

// ============================================
// EXPORTS
// ============================================

module.exports = {
  validateSubscription,
  requireFeatureAccess,
  trackUsage,
  activateSubscription,
  deactivateSubscription,
  validateToolboxSubscription,
  trackToolboxUsage,
  getToolboxPermissions,
};
