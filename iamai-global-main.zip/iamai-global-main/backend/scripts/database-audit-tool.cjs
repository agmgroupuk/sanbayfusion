#!/usr/bin/env node
/**
 * ============================================
 * IAMAI-GLOBAL DATABASE AUDIT TOOL
 * Professional systematic verification of ALL data flows
 * ============================================
 * 
 * This tool verifies that EVERY feature stores data correctly in MongoDB
 * No more guessing, no more manual checking!
 */

const mongoose = require('mongoose');
require('dotenv').config({ path: require('path').join(__dirname, '../.env') });

// ============================================
// CONFIGURATION
// ============================================

const MONGODB_URI = process.env.MONGODB_URI || 'mongodb+srv://iamai-global:miczugamark@iamai-global.pwzfji.mongodb.net/iamai-global';

// Colors for console output
const colors = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m',
  cyan: '\x1b[36m',
};

const log = {
  header: (msg) => console.log(`\n${colors.bright}${colors.cyan}${'='.repeat(60)}${colors.reset}`),
  title: (msg) => console.log(`${colors.bright}${colors.cyan}${msg}${colors.reset}`),
  success: (msg) => console.log(`${colors.green}✅ ${msg}${colors.reset}`),
  error: (msg) => console.log(`${colors.red}❌ ${msg}${colors.reset}`),
  warning: (msg) => console.log(`${colors.yellow}⚠️  ${msg}${colors.reset}`),
  info: (msg) => console.log(`${colors.blue}ℹ️  ${msg}${colors.reset}`),
  data: (msg) => console.log(`   ${colors.magenta}→ ${msg}${colors.reset}`),
};

// ============================================
// FEATURE → DATABASE MAPPING
// Complete map of what data should exist for each feature
// ============================================

const FEATURE_DATABASE_MAP = {
  // ==========================================
  // USER AUTHENTICATION & ACCOUNT
  // ==========================================
  'USER_REGISTRATION': {
    description: 'User signs up for account',
    collection: 'users',
    requiredFields: ['email', 'password', 'createdAt'],
    optionalFields: ['name', 'username', 'avatar'],
    relatedCollections: ['activity_logs', 'notification_settings'],
    endpoint: 'POST /api/auth/register',
    frontendPage: '/register',
  },
  
  'USER_LOGIN': {
    description: 'User logs into account',
    collection: 'users',
    updatedFields: ['security.lastLoginAt', 'security.lastLoginIP', 'security.activeSessions'],
    relatedCollections: ['activity_logs'],
    endpoint: 'POST /api/auth/login',
    frontendPage: '/login',
  },
  
  'USER_LOGOUT': {
    description: 'User logs out',
    collection: 'users',
    updatedFields: ['security.activeSessions'],
    relatedCollections: ['activity_logs'],
    endpoint: 'POST /api/auth/logout',
    frontendPage: 'Any page (header logout button)',
  },
  
  'PASSWORD_CHANGE': {
    description: 'User changes password',
    collection: 'users',
    updatedFields: ['password', 'security.lastPasswordChange'],
    relatedCollections: ['activity_logs', 'security_logs'],
    endpoint: 'POST /api/users/security/password',
    frontendPage: '/settings/security',
  },
  
  'EMAIL_CHANGE': {
    description: 'User changes email',
    collection: 'users',
    updatedFields: ['email', 'security.emailChangeRequest'],
    relatedCollections: ['activity_logs'],
    endpoint: 'POST /api/users/security/email',
    frontendPage: '/settings/security',
  },
  
  '2FA_SETUP': {
    description: 'User enables 2FA',
    collection: 'users',
    updatedFields: ['security.twoFactorEnabled', 'security.twoFactorSecret', 'security.backupCodes'],
    relatedCollections: ['activity_logs', 'security_logs'],
    endpoint: 'POST /api/users/security/2fa/setup',
    frontendPage: '/settings/security',
  },
  
  '2FA_DISABLE': {
    description: 'User disables 2FA',
    collection: 'users',
    updatedFields: ['security.twoFactorEnabled', 'security.twoFactorSecret'],
    relatedCollections: ['activity_logs', 'security_logs'],
    endpoint: 'POST /api/users/security/2fa/disable',
    frontendPage: '/settings/security',
  },
  
  // ==========================================
  // USER PROFILE & SETTINGS
  // ==========================================
  'PROFILE_UPDATE': {
    description: 'User updates profile info',
    collection: 'users',
    updatedFields: ['name', 'username', 'avatar', 'bio', 'updatedAt'],
    relatedCollections: ['activity_logs'],
    endpoint: 'PUT /api/users/profile',
    frontendPage: '/settings/profile',
  },
  
  'AVATAR_UPLOAD': {
    description: 'User uploads avatar',
    collection: 'users',
    updatedFields: ['avatar'],
    relatedCollections: ['file_uploads', 'activity_logs'],
    endpoint: 'POST /api/users/avatar',
    frontendPage: '/settings/profile',
  },
  
  'PREFERENCES_UPDATE': {
    description: 'User updates preferences (theme, language, etc)',
    collection: 'users',
    updatedFields: ['preferences.theme', 'preferences.language', 'preferences.timezone'],
    relatedCollections: ['activity_logs'],
    endpoint: 'PUT /api/users/preferences',
    frontendPage: '/settings/preferences',
  },
  
  'NOTIFICATION_SETTINGS': {
    description: 'User updates notification preferences',
    collection: 'notification_settings',
    requiredFields: ['userId', 'email', 'push', 'sms', 'inApp'],
    relatedCollections: ['activity_logs'],
    endpoint: 'PUT /api/notifications/settings',
    frontendPage: '/settings/notifications',
  },
  
  'PRIVACY_SETTINGS': {
    description: 'User updates privacy settings',
    collection: 'users',
    updatedFields: ['privacy.dataCollection', 'privacy.shareActivity', 'privacy.showOnlineStatus'],
    relatedCollections: ['activity_logs'],
    endpoint: 'PUT /api/users/privacy',
    frontendPage: '/settings/privacy',
  },
  
  // ==========================================
  // AGENT PURCHASES (CRITICAL!)
  // ==========================================
  'AGENT_PURCHASE_INITIATE': {
    description: 'User initiates agent purchase (Stripe checkout)',
    collection: 'agent_purchases',
    requiredFields: ['userId', 'agentId', 'plan', 'status', 'stripeCheckoutSessionId'],
    initialStatus: 'PENDING',
    relatedCollections: ['activity_logs'],
    endpoint: 'POST /api/agents/:agentId/purchase',
    frontendPage: '/agents/:agentId (purchase modal)',
  },
  
  'AGENT_PURCHASE_COMPLETE': {
    description: 'Stripe webhook confirms payment',
    collection: 'agent_purchases',
    updatedFields: ['status', 'paymentStatus', 'stripePaymentIntentId', 'expiresAt'],
    finalStatus: 'ACTIVE',
    relatedCollections: ['transactions', 'webhook_events', 'activity_logs'],
    endpoint: 'POST /api/webhooks/stripe (webhook)',
    frontendPage: '/thank-you',
  },
  
  'AGENT_PURCHASE_EXPIRE': {
    description: 'Purchase expires after plan duration',
    collection: 'agent_purchases',
    updatedFields: ['status'],
    finalStatus: 'EXPIRED',
    relatedCollections: ['activity_logs'],
    endpoint: 'Cron job / automatic',
    frontendPage: 'N/A (background)',
  },
  
  'AGENT_PURCHASE_CANCEL': {
    description: 'User cancels active purchase',
    collection: 'agent_purchases',
    updatedFields: ['status', 'cancelledAt', 'cancelReason'],
    finalStatus: 'CANCELLED',
    relatedCollections: ['activity_logs'],
    endpoint: 'POST /api/agents/:agentId/cancel',
    frontendPage: '/dashboard or /agents/:agentId',
  },
  
  'AGENT_ACCESS_CHECK': {
    description: 'Check if user has access to agent',
    collection: 'agent_purchases',
    query: '{ userId, agentId, status: ACTIVE, expiresAt: { $gt: now } }',
    endpoint: 'GET /api/agents/:agentId/access',
    frontendPage: 'Any agent chat page',
  },
  
  // ==========================================
  // CHAT & CONVERSATIONS
  // ==========================================
  'CHAT_START': {
    description: 'User starts new chat with agent',
    collection: 'chats',
    requiredFields: ['participants', 'agentType', 'createdAt'],
    relatedCollections: ['individual_agent_sessions', 'activity_logs'],
    endpoint: 'POST /api/chat/start',
    frontendPage: '/chat/:agentId',
  },
  
  'CHAT_MESSAGE_SEND': {
    description: 'User sends message in chat',
    collection: 'chats',
    updatedFields: ['messages (push)', 'lastMessageAt'],
    relatedCollections: ['individual_agent_chat_histories', 'activity_logs'],
    endpoint: 'POST /api/chat/message',
    frontendPage: '/chat/:agentId',
  },
  
  'CHAT_MESSAGE_RECEIVE': {
    description: 'Agent responds to user',
    collection: 'chats',
    updatedFields: ['messages (push)', 'lastMessageAt'],
    relatedCollections: ['individual_agent_chat_histories'],
    endpoint: 'POST /api/chat/message (AI response)',
    frontendPage: '/chat/:agentId',
  },
  
  'CHAT_HISTORY_LOAD': {
    description: 'User loads chat history',
    collection: 'chats',
    query: '{ participants: userId, agentType }',
    endpoint: 'GET /api/chat/history/:agentId',
    frontendPage: '/chat/:agentId',
  },
  
  // ==========================================
  // BILLING & TRANSACTIONS
  // ==========================================
  'BILLING_HISTORY': {
    description: 'User views billing history',
    collection: 'transactions',
    query: '{ userId }',
    relatedCollections: ['agent_purchases'],
    endpoint: 'GET /api/billing/history',
    frontendPage: '/settings/billing',
  },
  
  'INVOICE_VIEW': {
    description: 'User views specific invoice',
    collection: 'transactions',
    query: '{ _id, userId }',
    endpoint: 'GET /api/billing/invoice/:id',
    frontendPage: '/settings/billing/invoice/:id',
  },
  
  // ==========================================
  // SUPPORT
  // ==========================================
  'SUPPORT_TICKET_CREATE': {
    description: 'User creates support ticket',
    collection: 'support_tickets',
    requiredFields: ['userId', 'subject', 'description', 'category', 'priority', 'status'],
    initialStatus: 'open',
    relatedCollections: ['activity_logs'],
    endpoint: 'POST /api/support/tickets',
    frontendPage: '/support/new',
  },
  
  'SUPPORT_TICKET_REPLY': {
    description: 'User or admin replies to ticket',
    collection: 'support_tickets',
    updatedFields: ['responses (push)', 'status', 'updatedAt'],
    relatedCollections: ['activity_logs'],
    endpoint: 'POST /api/support/tickets/:id/reply',
    frontendPage: '/support/tickets/:id',
  },
  
  'CONTACT_FORM_SUBMIT': {
    description: 'Visitor submits contact form',
    collection: 'contact_forms',
    requiredFields: ['email', 'message', 'type', 'status'],
    initialStatus: 'new',
    relatedCollections: ['activity_logs'],
    endpoint: 'POST /api/contact',
    frontendPage: '/contact',
  },
  
  // ==========================================
  // ANALYTICS & TRACKING
  // ==========================================
  'PAGE_VIEW': {
    description: 'User/visitor views a page',
    collection: 'visitors',
    updatedFields: ['pageViews (push)', 'totalPageViews', 'lastVisit'],
    relatedCollections: ['activity_logs'],
    endpoint: 'POST /api/analytics/pageview',
    frontendPage: 'Every page',
  },
  
  'SESSION_START': {
    description: 'New visitor session starts',
    collection: 'visitors',
    requiredFields: ['sessionId', 'device', 'location', 'firstVisit'],
    relatedCollections: ['activity_logs'],
    endpoint: 'POST /api/analytics/session',
    frontendPage: 'Site entry',
  },
  
  // ==========================================
  // API KEYS
  // ==========================================
  'API_KEY_CREATE': {
    description: 'User creates API key',
    collection: 'api_keys',
    requiredFields: ['userId', 'key', 'name', 'permissions', 'isActive'],
    relatedCollections: ['activity_logs'],
    endpoint: 'POST /api/users/api-keys',
    frontendPage: '/settings/api-keys',
  },
  
  'API_KEY_REVOKE': {
    description: 'User revokes API key',
    collection: 'api_keys',
    updatedFields: ['isActive'],
    finalStatus: false,
    relatedCollections: ['activity_logs'],
    endpoint: 'DELETE /api/users/api-keys/:id',
    frontendPage: '/settings/api-keys',
  },
};

// ============================================
// DATABASE VERIFICATION FUNCTIONS
// ============================================

async function connectDatabase() {
  try {
    await mongoose.connect(MONGODB_URI);
    log.success('Connected to MongoDB');
    return true;
  } catch (error) {
    log.error(`Failed to connect: ${error.message}`);
    return false;
  }
}

async function getCollectionStats() {
  const db = mongoose.connection.db;
  const collections = await db.listCollections().toArray();
  const stats = {};
  
  for (const col of collections) {
    const count = await db.collection(col.name).countDocuments();
    stats[col.name] = count;
  }
  
  return stats;
}

async function verifyCollection(collectionName, requiredFields = []) {
  const db = mongoose.connection.db;
  const collection = db.collection(collectionName);
  
  const exists = await collection.countDocuments() >= 0;
  if (!exists) {
    return { exists: false, count: 0, hasAllFields: false };
  }
  
  const count = await collection.countDocuments();
  const sample = await collection.findOne();
  
  let hasAllFields = true;
  const missingFields = [];
  
  if (sample && requiredFields.length > 0) {
    for (const field of requiredFields) {
      const fieldPath = field.split('.');
      let value = sample;
      for (const part of fieldPath) {
        value = value?.[part];
      }
      if (value === undefined) {
        hasAllFields = false;
        missingFields.push(field);
      }
    }
  }
  
  return { exists: true, count, hasAllFields, missingFields, sample };
}

async function checkRecentActivity(collectionName, hours = 24) {
  const db = mongoose.connection.db;
  const collection = db.collection(collectionName);
  
  const cutoff = new Date(Date.now() - hours * 60 * 60 * 1000);
  
  // Try different date field names
  const dateFields = ['createdAt', 'created_at', 'timestamp', 'purchaseDate', 'firstVisit'];
  
  for (const field of dateFields) {
    try {
      const count = await collection.countDocuments({ [field]: { $gte: cutoff } });
      if (count > 0) {
        return { field, count, lastDocument: await collection.findOne({}, { sort: { [field]: -1 } }) };
      }
    } catch (e) {
      continue;
    }
  }
  
  return { count: 0 };
}

// ============================================
// MAIN AUDIT FUNCTIONS
// ============================================

async function runFullAudit() {
  log.header();
  log.title('🔍 IAMAI-GLOBAL DATABASE AUDIT');
  log.title('   Professional Data Flow Verification');
  log.header();
  
  // Connect
  const connected = await connectDatabase();
  if (!connected) {
    process.exit(1);
  }
  
  // Get all collection stats
  console.log('\n📊 COLLECTION STATISTICS:\n');
  const stats = await getCollectionStats();
  
  const expectedCollections = [
    'users',
    'agents', 
    'agent_purchases',
    'chats',
    'activity_logs',
    'visitors',
    'support_tickets',
    'contact_forms',
    'transactions',
    'webhook_events',
    'file_uploads',
    'notification_settings',
    'api_keys',
    'individual_agent_configurations',
    'individual_agent_sessions',
    'individual_agent_chat_histories',
  ];
  
  const report = {
    collections: {},
    issues: [],
    warnings: [],
    healthy: [],
  };
  
  for (const colName of expectedCollections) {
    const count = stats[colName] || 0;
    const recent = await checkRecentActivity(colName);
    
    report.collections[colName] = { count, recent: recent.count };
    
    if (count === 0) {
      log.error(`${colName}: EMPTY (0 documents)`);
      report.issues.push(`${colName} is empty`);
    } else if (count < 5) {
      log.warning(`${colName}: ${count} documents (very few)`);
      report.warnings.push(`${colName} has only ${count} documents`);
    } else {
      log.success(`${colName}: ${count} documents`);
      report.healthy.push(colName);
    }
    
    if (recent.count > 0) {
      log.data(`Recent activity (24h): ${recent.count} new documents`);
    }
  }
  
  // Check for unexpected collections
  const unexpectedCollections = Object.keys(stats).filter(c => !expectedCollections.includes(c));
  if (unexpectedCollections.length > 0) {
    console.log('\n📁 Other collections found:');
    unexpectedCollections.forEach(c => {
      log.info(`${c}: ${stats[c]} documents`);
    });
  }
  
  // ==========================================
  // FEATURE VERIFICATION
  // ==========================================
  console.log('\n' + '='.repeat(60));
  console.log('📋 FEATURE DATA FLOW VERIFICATION:\n');
  
  const db = mongoose.connection.db;
  
  // Check Users
  const usersCheck = await verifyCollection('users', ['email', 'createdAt']);
  if (usersCheck.count > 0) {
    log.success(`Users: ${usersCheck.count} registered`);
    
    // Check security fields
    const usersWithSecurity = await db.collection('users').countDocuments({ 'security.twoFactorEnabled': { $exists: true } });
    log.data(`Users with security settings: ${usersWithSecurity}`);
    
    const usersWith2FA = await db.collection('users').countDocuments({ 'security.twoFactorEnabled': true });
    log.data(`Users with 2FA enabled: ${usersWith2FA}`);
  } else {
    log.error('No users in database!');
    report.issues.push('No users registered');
  }
  
  // Check Agent Purchases (CRITICAL)
  console.log('');
  const purchasesCheck = await verifyCollection('agent_purchases', ['userId', 'agentId', 'status']);
  if (purchasesCheck.count > 0) {
    log.success(`Agent Purchases: ${purchasesCheck.count} total`);
    
    const activePurchases = await db.collection('agent_purchases').countDocuments({ 
      status: { $in: ['ACTIVE', 'active'] },
      $or: [
        { expiresAt: { $gt: new Date() } },
        { expirationDate: { $gt: new Date() } }
      ]
    });
    log.data(`Active purchases: ${activePurchases}`);
    
    const pendingPurchases = await db.collection('agent_purchases').countDocuments({ 
      status: { $in: ['PENDING', 'pending'] }
    });
    if (pendingPurchases > 0) {
      log.warning(`Pending purchases (not completed): ${pendingPurchases}`);
      report.warnings.push(`${pendingPurchases} purchases stuck in PENDING`);
    }
    
    const expiredPurchases = await db.collection('agent_purchases').countDocuments({ 
      status: { $in: ['EXPIRED', 'expired'] }
    });
    log.data(`Expired purchases: ${expiredPurchases}`);
    
    // Check for purchases without Stripe IDs
    const purchasesWithoutStripe = await db.collection('agent_purchases').countDocuments({
      status: { $in: ['ACTIVE', 'active'] },
      stripePaymentIntentId: { $exists: false }
    });
    if (purchasesWithoutStripe > 0) {
      log.warning(`Active purchases without Stripe ID: ${purchasesWithoutStripe}`);
    }
  } else {
    log.error('No agent purchases in database!');
    report.issues.push('No agent purchases');
  }
  
  // Check Chats
  console.log('');
  const chatsCheck = await verifyCollection('chats', ['participants', 'agentType']);
  if (chatsCheck.count > 0) {
    log.success(`Chats: ${chatsCheck.count} conversations`);
    
    // Check for chats with messages
    const chatsWithMessages = await db.collection('chats').countDocuments({ 
      'messages.0': { $exists: true }
    });
    log.data(`Chats with messages: ${chatsWithMessages}`);
    
    // Recent chat activity
    const recentChats = await db.collection('chats').countDocuments({
      lastMessageAt: { $gte: new Date(Date.now() - 24 * 60 * 60 * 1000) }
    });
    log.data(`Active chats (24h): ${recentChats}`);
  } else {
    log.warning('No chat conversations in database');
  }
  
  // Check Activity Logs
  console.log('');
  const activityCheck = await verifyCollection('activity_logs', ['action', 'createdAt']);
  if (activityCheck.count > 0) {
    log.success(`Activity Logs: ${activityCheck.count} entries`);
    
    // Check for critical actions
    const loginLogs = await db.collection('activity_logs').countDocuments({ action: 'LOGIN' });
    log.data(`Login events logged: ${loginLogs}`);
    
    const purchaseLogs = await db.collection('activity_logs').countDocuments({ 
      action: { $regex: /purchase/i }
    });
    log.data(`Purchase events logged: ${purchaseLogs}`);
  } else {
    log.error('No activity logs - events are not being tracked!');
    report.issues.push('Activity logging not working');
  }
  
  // Check Webhook Events
  console.log('');
  const webhookCheck = await verifyCollection('webhook_events', ['source', 'eventType']);
  if (webhookCheck.count > 0) {
    log.success(`Webhook Events: ${webhookCheck.count} received`);
    
    const stripeWebhooks = await db.collection('webhook_events').countDocuments({ source: 'stripe' });
    log.data(`Stripe webhooks: ${stripeWebhooks}`);
    
    const failedWebhooks = await db.collection('webhook_events').countDocuments({ status: 'failed' });
    if (failedWebhooks > 0) {
      log.warning(`Failed webhooks: ${failedWebhooks}`);
      report.warnings.push(`${failedWebhooks} webhook events failed`);
    }
  } else {
    log.warning('No webhook events - Stripe webhooks may not be configured');
    report.warnings.push('No webhook events received');
  }
  
  // Check Transactions
  console.log('');
  const transactionsCheck = await verifyCollection('transactions', ['userId', 'type', 'amount']);
  if (transactionsCheck.count > 0) {
    log.success(`Transactions: ${transactionsCheck.count} records`);
    
    const totalRevenue = await db.collection('transactions').aggregate([
      { $match: { status: 'completed' } },
      { $group: { _id: null, total: { $sum: '$amount' } } }
    ]).toArray();
    if (totalRevenue[0]) {
      log.data(`Total revenue: $${totalRevenue[0].total.toFixed(2)}`);
    }
  } else {
    log.warning('No transaction records');
  }
  
  // Check Agents
  console.log('');
  const agentsCheck = await verifyCollection('agents', ['agentId', 'name', 'category']);
  if (agentsCheck.count > 0) {
    log.success(`Agents: ${agentsCheck.count} defined`);
    
    const activeAgents = await db.collection('agents').countDocuments({ isActive: true });
    log.data(`Active agents: ${activeAgents}`);
    
    const agentsWithPricing = await db.collection('agents').countDocuments({ 
      'pricing.daily': { $exists: true }
    });
    log.data(`Agents with pricing: ${agentsWithPricing}`);
  } else {
    log.error('No agents in database!');
    report.issues.push('No agents defined');
  }
  
  // ==========================================
  // SUMMARY REPORT
  // ==========================================
  log.header();
  log.title('📊 AUDIT SUMMARY');
  log.header();
  
  console.log(`\n${colors.green}✅ Healthy Collections: ${report.healthy.length}${colors.reset}`);
  report.healthy.forEach(c => console.log(`   • ${c}`));
  
  if (report.warnings.length > 0) {
    console.log(`\n${colors.yellow}⚠️  Warnings: ${report.warnings.length}${colors.reset}`);
    report.warnings.forEach(w => console.log(`   • ${w}`));
  }
  
  if (report.issues.length > 0) {
    console.log(`\n${colors.red}❌ Critical Issues: ${report.issues.length}${colors.reset}`);
    report.issues.forEach(i => console.log(`   • ${i}`));
  }
  
  // Data flow status
  console.log('\n📈 DATA FLOW STATUS:');
  
  const dataFlowChecks = [
    { name: 'User Registration', ok: stats.users > 0 },
    { name: 'Agent Definitions', ok: stats.agents > 0 },
    { name: 'Purchase Flow', ok: stats.agent_purchases > 0 },
    { name: 'Chat System', ok: stats.chats > 0 },
    { name: 'Activity Tracking', ok: stats.activity_logs > 0 },
    { name: 'Webhook Processing', ok: stats.webhook_events > 0 },
    { name: 'Visitor Analytics', ok: stats.visitors > 0 },
  ];
  
  dataFlowChecks.forEach(check => {
    if (check.ok) {
      log.success(check.name);
    } else {
      log.error(`${check.name} - NO DATA`);
    }
  });
  
  console.log('\n' + '='.repeat(60));
  
  // Disconnect
  await mongoose.disconnect();
  log.info('Disconnected from MongoDB');
  
  return report;
}

// ============================================
// SPECIFIC FEATURE TESTS
// ============================================

async function testUserDataFlow(userId) {
  log.header();
  log.title(`🔍 USER DATA FLOW TEST: ${userId}`);
  log.header();
  
  await connectDatabase();
  const db = mongoose.connection.db;
  
  // Find user
  const user = await db.collection('users').findOne({ _id: new mongoose.Types.ObjectId(userId) });
  if (!user) {
    log.error('User not found!');
    return;
  }
  
  log.success(`User found: ${user.email}`);
  
  // Check all related data
  console.log('\n📁 Related Data:\n');
  
  // Purchases
  const purchases = await db.collection('agent_purchases').find({ userId: user._id }).toArray();
  log.info(`Agent Purchases: ${purchases.length}`);
  purchases.forEach(p => {
    log.data(`${p.agentId} - ${p.plan} - ${p.status} (expires: ${p.expiresAt || p.expirationDate})`);
  });
  
  // Chats
  const chats = await db.collection('chats').find({ participants: user._id }).toArray();
  log.info(`Chat Conversations: ${chats.length}`);
  
  // Activity Logs
  const activities = await db.collection('activity_logs').countDocuments({ userId: user._id });
  log.info(`Activity Log Entries: ${activities}`);
  
  // Transactions
  const transactions = await db.collection('transactions').find({ userId: user._id }).toArray();
  log.info(`Transactions: ${transactions.length}`);
  
  // Notification Settings
  const notifSettings = await db.collection('notification_settings').findOne({ userId: user._id });
  log.info(`Notification Settings: ${notifSettings ? 'Configured' : 'NOT SET'}`);
  
  // Security check
  console.log('\n🔐 Security Status:\n');
  log.info(`2FA Enabled: ${user.security?.twoFactorEnabled || false}`);
  log.info(`Active Sessions: ${user.security?.activeSessions?.length || 0}`);
  log.info(`Last Login: ${user.security?.lastLoginAt || 'Unknown'}`);
  
  await mongoose.disconnect();
}

// ============================================
// RUN
// ============================================

const args = process.argv.slice(2);

if (args[0] === '--user' && args[1]) {
  testUserDataFlow(args[1]);
} else {
  runFullAudit().then(report => {
    if (report.issues.length > 0) {
      console.log(`\n${colors.red}${colors.bright}ACTION REQUIRED: Fix ${report.issues.length} critical issues!${colors.reset}\n`);
      process.exit(1);
    } else {
      console.log(`\n${colors.green}${colors.bright}✅ Database health check passed!${colors.reset}\n`);
      process.exit(0);
    }
  });
}
