const mongoose = require('mongoose');
const { AgentRegistry, getAgentData, AGENT_LIST, getAllAgentCollections } = require('./agent-collections');

// ============================================
// AGENT DATA MANAGEMENT SERVICE
// Central service for managing agent collections
// ============================================

class AgentDataManager {
  constructor() {
    this.agentCollections = {};
    this.initialized = false;
  }

  // Initialize all agent collections
  async initialize() {
    try {
      console.log('🎯 Initializing Agent Data Manager...');
      
      // Create all agent collections
      this.agentCollections = getAllAgentCollections();
      
      // Initialize agent registry
      await this.initializeAgentRegistry();
      
      this.initialized = true;
      console.log(`✅ Agent Data Manager initialized with ${AGENT_LIST.length} agents`);
      return true;
    } catch (error) {
      console.error('❌ Failed to initialize Agent Data Manager:', error);
      return false;
    }
  }

  // Initialize agent registry with all agents
  // ⚠️ UPDATED: Now uses correct 17 agents matching the 'agents' collection
  async initializeAgentRegistry() {
    const agentConfigs = [
      // ========== CORE AGENTS (9) ==========
      {
        agentId: 'ai-girlfriend',
        agentName: 'AI Girlfriend Pro',
        displayName: 'AI Girlfriend Pro - Your Digital Companion',
        description: 'Your personal AI companion for meaningful conversations and emotional support',
        category: 'companion',
        config: {
          personality: { tone: 'warm', specialties: ['emotional-support', 'conversation', 'companionship'] },
          capabilities: { features: ['emotional-intelligence', 'relationship-advice', 'daily-chat'] },
          pricing: { daily: 1, weekly: 5, monthly: 19 }
        }
      },
      {
        agentId: 'emo-ai',
        agentName: 'EmoAI',
        displayName: 'EmoAI - Emotional Intelligence Assistant',
        description: 'Advanced emotional intelligence and mental wellness companion',
        category: 'companion',
        config: {
          personality: { tone: 'empathetic', specialties: ['emotional-support', 'mental-wellness'] },
          capabilities: { features: ['mood-tracking', 'emotional-analysis', 'wellness-tips'] },
          pricing: { daily: 1, weekly: 5, monthly: 19 }
        }
      },
      {
        agentId: 'pdf-mind',
        agentName: 'PDFMind',
        displayName: 'PDFMind - Document Intelligence',
        description: 'AI-powered PDF analysis and document understanding',
        category: 'productivity',
        config: {
          personality: { tone: 'analytical', specialties: ['document-analysis', 'research'] },
          capabilities: { features: ['pdf-analysis', 'document-summary', 'data-extraction'] },
          pricing: { daily: 1, weekly: 5, monthly: 19 }
        }
      },
      {
        agentId: 'chat-revive',
        agentName: 'ChatRevive',
        displayName: 'ChatRevive - Conversation Enhancer',
        description: 'Revive and enhance your conversations with AI-powered suggestions',
        category: 'companion',
        config: {
          personality: { tone: 'engaging', specialties: ['conversation', 'social-skills'] },
          capabilities: { features: ['conversation-starters', 'reply-suggestions', 'chat-analysis'] },
          pricing: { daily: 1, weekly: 5, monthly: 19 }
        }
      },
      {
        agentId: 'tok-boost',
        agentName: 'TokBoost',
        displayName: 'TokBoost - Social Media Growth',
        description: 'AI-powered social media content and growth strategies',
        category: 'creative',
        config: {
          personality: { tone: 'trendy', specialties: ['social-media', 'content-creation'] },
          capabilities: { features: ['content-ideas', 'hashtag-optimization', 'trend-analysis'] },
          pricing: { daily: 1, weekly: 5, monthly: 19 }
        }
      },
      {
        agentId: 'you-gen',
        agentName: 'YouGen',
        displayName: 'YouGen - Content Generator',
        description: 'Generate YouTube scripts, thumbnails ideas, and video content',
        category: 'creative',
        config: {
          personality: { tone: 'creative', specialties: ['youtube', 'video-content'] },
          capabilities: { features: ['script-writing', 'thumbnail-ideas', 'seo-optimization'] },
          pricing: { daily: 1, weekly: 5, monthly: 19 }
        }
      },
      {
        agentId: 'agent-x',
        agentName: 'AgentX',
        displayName: 'AgentX - Your AI Assistant',
        description: 'Versatile AI assistant for any task or question',
        category: 'productivity',
        config: {
          personality: { tone: 'professional', specialties: ['general-assistance', 'problem-solving'] },
          capabilities: { features: ['task-management', 'research', 'writing'] },
          pricing: { daily: 1, weekly: 5, monthly: 19 }
        }
      },
      {
        agentId: 'auto-chat',
        agentName: 'AutoChat',
        displayName: 'AutoChat - Automated Responses',
        description: 'Intelligent automated chat responses and message management',
        category: 'productivity',
        config: {
          personality: { tone: 'efficient', specialties: ['automation', 'messaging'] },
          capabilities: { features: ['auto-reply', 'message-scheduling', 'chat-templates'] },
          pricing: { daily: 1, weekly: 5, monthly: 19 }
        }
      },
      {
        agentId: 'cv-smash',
        agentName: 'CVSmash',
        displayName: 'CVSmash - Resume Builder',
        description: 'AI-powered resume and CV optimization',
        category: 'business',
        config: {
          personality: { tone: 'professional', specialties: ['career', 'resume-writing'] },
          capabilities: { features: ['resume-optimization', 'cover-letters', 'interview-prep'] },
          pricing: { daily: 1, weekly: 5, monthly: 19 }
        }
      },
      // ========== PERSONALITY AGENTS (8) ==========
      {
        agentId: 'comedy-chad',
        agentName: 'Comedy Chad',
        displayName: 'Comedy Chad - The Comedian',
        description: 'Your personal comedy writer and entertainer',
        category: 'entertainment',
        config: {
          personality: { tone: 'humorous', specialties: ['comedy', 'entertainment'] },
          capabilities: { features: ['joke-generation', 'story-telling', 'roasts'] },
          pricing: { daily: 1, weekly: 5, monthly: 19 }
        }
      },
      {
        agentId: 'lazy-larry',
        agentName: 'Lazy Larry',
        displayName: 'Lazy Larry - The Chill Guy',
        description: 'Laid-back assistant who finds the easiest way to do things',
        category: 'lifestyle',
        config: {
          personality: { tone: 'relaxed', specialties: ['efficiency', 'shortcuts'] },
          capabilities: { features: ['life-hacks', 'minimal-effort-solutions'] },
          pricing: { daily: 1, weekly: 5, monthly: 19 }
        }
      },
      {
        agentId: 'flirty-fiona',
        agentName: 'Flirty Fiona',
        displayName: 'Flirty Fiona - The Charmer',
        description: 'Playful and charming conversation partner',
        category: 'entertainment',
        config: {
          personality: { tone: 'flirty', specialties: ['charm', 'wit'] },
          capabilities: { features: ['flirty-banter', 'dating-advice', 'confidence-boost'] },
          pricing: { daily: 1, weekly: 5, monthly: 19 }
        }
      },
      {
        agentId: 'sassy-sarah',
        agentName: 'Sassy Sarah',
        displayName: 'Sassy Sarah - The Real One',
        description: 'Bold, honest, and unapologetically sassy assistant',
        category: 'entertainment',
        config: {
          personality: { tone: 'sassy', specialties: ['honesty', 'attitude'] },
          capabilities: { features: ['real-talk', 'opinion-sharing', 'roasts'] },
          pricing: { daily: 1, weekly: 5, monthly: 19 }
        }
      },
      {
        agentId: 'nerdy-neil',
        agentName: 'Nerdy Neil',
        displayName: 'Nerdy Neil - The Know-It-All',
        description: 'Your go-to expert for trivia, facts, and deep knowledge',
        category: 'education',
        config: {
          personality: { tone: 'intellectual', specialties: ['facts', 'trivia', 'research'] },
          capabilities: { features: ['fact-checking', 'deep-dives', 'explanations'] },
          pricing: { daily: 1, weekly: 5, monthly: 19 }
        }
      },
      {
        agentId: 'cool-kyle',
        agentName: 'Cool Kyle',
        displayName: 'Cool Kyle - The Smooth Talker',
        description: 'Effortlessly cool advice on life, style, and confidence',
        category: 'lifestyle',
        config: {
          personality: { tone: 'cool', specialties: ['style', 'confidence'] },
          capabilities: { features: ['style-advice', 'social-tips', 'confidence-coaching'] },
          pricing: { daily: 1, weekly: 5, monthly: 19 }
        }
      },
      {
        agentId: 'zen-master-zara',
        agentName: 'Zen Master Zara',
        displayName: 'Zen Master Zara - The Mindful Guide',
        description: 'Find peace and balance with mindfulness and meditation guidance',
        category: 'technical',
        config: {
          personality: { tone: 'calm', specialties: ['mindfulness', 'meditation'] },
          capabilities: { features: ['guided-meditation', 'breathing-exercises', 'stress-relief'] },
          pricing: { daily: 1, weekly: 5, monthly: 19 }
        }
      },
      {
        agentId: 'gamer-gary',
        agentName: 'Gamer Gary',
        displayName: 'Gamer Gary - The Gaming Expert',
        description: 'Ultimate gaming companion for tips, strategies, and game talk',
        category: 'entertainment',
        config: {
          personality: { tone: 'enthusiastic', specialties: ['gaming', 'strategy'] },
          capabilities: { features: ['game-guides', 'strategy-tips', 'gaming-news'] },
          pricing: { daily: 1, weekly: 5, monthly: 19 }
        }
      }
    ];

    // Insert or update agent registry
    for (const agentConfig of agentConfigs) {
      await AgentRegistry.findOneAndUpdate(
        { agentId: agentConfig.agentId },
        {
          ...agentConfig,
          collectionName: `${agentConfig.agentId}-data`,
          metadata: { updatedAt: new Date() }
        },
        { upsert: true, new: true }
      );
    }
  }

  // Get agent collection by agentId
  getAgentCollection(agentId) {
    if (!this.initialized) {
      throw new Error('Agent Data Manager not initialized');
    }
    
    if (!AGENT_LIST.includes(agentId)) {
      throw new Error(`Invalid agent ID: ${agentId}`);
    }
    
    return getAgentData(agentId);
  }

  // Create or get user data for specific agent
  async getUserAgentData(userId, agentId) {
    const AgentData = this.getAgentCollection(agentId);
    
    let userData = await AgentData.findOne({ userId, agentId });
    
    if (!userData) {
      // Create new user data for this agent
      userData = new AgentData({
        userId,
        agentId,
        subscription: {
          status: 'inactive',
          pricing: { amount: 0, period: 'none' },
          billing: {},
          limits: {
            messagesPerDay: 0,
            messagesPerWeek: 0,
            messagesPerMonth: 0
          },
          usage: {
            messagesUsed: 0,
            dailyUsage: 0,
            weeklyUsage: 0,
            monthlyUsage: 0
          }
        },
        chats: [],
        sessions: [],
        analytics: [],
        activities: [],
        // transactions: [], // Don't initialize empty array to avoid index issues
        metadata: {
          createdAt: new Date(),
          updatedAt: new Date()
        }
      });
      
      await userData.save();
    }
    
    return userData;
  }

  // Add chat message to agent collection (while keeping existing flow)
  async addChatToAgent(userId, agentId, chatData) {
    const userData = await this.getUserAgentData(userId, agentId);
    
    // Add to agent-specific collection
    await userData.addChat({
      chatId: chatData.chatId || new mongoose.Types.ObjectId(),
      sessionId: chatData.sessionId,
      message: chatData.message,
      response: chatData.response,
      metadata: chatData.metadata || {}
    });
    
    // Update agent statistics
    await this.updateAgentStats(agentId);
    
    return userData;
  }

  // Create session in agent collection (while keeping existing flow)
  async createSessionForAgent(userId, agentId, sessionData) {
    const userData = await this.getUserAgentData(userId, agentId);
    
    await userData.createSession({
      sessionId: sessionData.sessionId,
      startTime: sessionData.startTime || new Date(),
      metadata: sessionData.metadata || {},
      analytics: sessionData.analytics || {},
      isActive: true
    });
    
    return userData;
  }

  // Subscribe user to specific agent
  async subscribeToAgent(userId, agentId, subscriptionData) {
    const userData = await this.getUserAgentData(userId, agentId);
    
    // Update subscription
    userData.subscription = {
      id: new mongoose.Types.ObjectId(),
      plan: subscriptionData.plan,
      status: 'active',
      pricing: subscriptionData.pricing,
      billing: subscriptionData.billing || {},
      limits: subscriptionData.limits || {
        messagesPerDay: 100,
        messagesPerWeek: 500,
        messagesPerMonth: 2000
      },
      usage: {
        messagesUsed: 0,
        dailyUsage: 0,
        weeklyUsage: 0,
        monthlyUsage: 0,
        lastResetDate: new Date()
      },
      subscribedAt: new Date(),
      lastActivity: new Date()
    };
    
    // Log subscription activity
    userData.activities.push({
      type: 'subscription',
      action: 'created',
      description: `Subscribed to ${subscriptionData.plan} plan`,
      data: { subscriptionId: userData.subscription.id, plan: subscriptionData.plan }
    });
    
    await userData.save();
    
    // Update agent statistics
    await this.updateAgentStats(agentId);
    
    return userData;
  }

  // Get all agents from registry
  async getAllAgents() {
    return await AgentRegistry.find({ isActive: true }).sort({ displayName: 1 });
  }

  // Get user's subscriptions for all agents
  async getUserSubscriptions(userId) {
    const subscriptions = [];
    
    for (const agentId of AGENT_LIST) {
      const AgentData = this.getAgentCollection(agentId);
      const userData = await AgentData.findOne({ 
        userId, 
        'subscription.status': 'active' 
      });
      
      if (userData) {
        subscriptions.push({
          agentId: userData.agentId,
          subscription: userData.subscription,
          lastActivity: userData.metadata.updatedAt
        });
      }
    }
    
    return subscriptions;
  }

  // Update agent statistics
  async updateAgentStats(agentId) {
    const AgentData = this.getAgentCollection(agentId);
    
    // Calculate stats
    const totalUsers = await AgentData.countDocuments({});
    const activeSubscriptions = await AgentData.countDocuments({ 'subscription.status': 'active' });
    
    const totalMessagesAgg = await AgentData.aggregate([
      { $project: { messageCount: { $size: '$chats' } } },
      { $group: { _id: null, total: { $sum: '$messageCount' } } }
    ]);
    
    const totalRevenueAgg = await AgentData.aggregate([
      { $project: { revenue: '$subscription.billing.totalAmountPaid' } },
      { $group: { _id: null, total: { $sum: '$revenue' } } }
    ]);
    
    const stats = {
      totalUsers,
      activeSubscriptions,
      totalMessages: totalMessagesAgg[0]?.total || 0,
      totalRevenue: totalRevenueAgg[0]?.total || 0,
      avgRating: 0, // Will be calculated from user feedback
      lastStatsUpdate: new Date()
    };
    
    await AgentRegistry.findOneAndUpdate(
      { agentId },
      { $set: { stats, 'metadata.lastStatsUpdate': new Date() } }
    );
    
    return stats;
  }

  // Get agent analytics
  async getAgentAnalytics(agentId, timeframe = 'daily') {
    const AgentData = this.getAgentCollection(agentId);
    
    const analytics = await AgentData.aggregate([
      { $match: { 'analytics.type': timeframe } },
      { $unwind: '$analytics' },
      { $match: { 'analytics.type': timeframe } },
      { $sort: { 'analytics.date': -1 } },
      { $limit: 30 }
    ]);
    
    return analytics;
  }

  // Sync data with existing collections (for backward compatibility)
  async syncWithExistingCollections() {
    // This method ensures data consistency between agent collections
    // and existing chat/session collections
    console.log('🔄 Syncing agent collections with existing data...');
    
    // Implementation for syncing existing chat messages, sessions, etc.
    // with agent-specific collections
    
    console.log('✅ Sync completed');
  }
}

// Singleton instance
const agentDataManager = new AgentDataManager();

module.exports = {
  AgentDataManager,
  agentDataManager
};