// Critical Missing Models
// Essential models that every SaaS platform requires

const mongoose = require('mongoose');

// ============================================
// 1. SUBSCRIPTION PLANS MODEL
// ============================================

const PlanSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    unique: true,
    trim: true,
    enum: ['daily', 'weekly', 'monthly']
  },
  displayName: {
    type: String,
    required: true
  },
  description: {
    type: String,
    required: true
  },
  price: {
    amount: {
      type: Number,
      required: true,
      min: 0
    },
    currency: {
      type: String,
      default: 'USD',
      enum: ['USD', 'EUR', 'GBP']
    },
    period: {
      type: String,
      required: true,
      enum: ['daily', 'weekly', 'monthly']
    },
    periodDays: {
      type: Number,
      required: true,
      min: 1
    }
  },
  features: [{
    name: {
      type: String,
      required: true
    },
    description: String,
    included: {
      type: Boolean,
      default: true
    },
    limit: {
      type: Number,
      default: null // null = unlimited
    }
  }],
  limits: {
    maxAgents: {
      type: Number,
      default: 1, // Always 1 agent per subscription
      max: 1
    },
    duration: {
      type: Number,
      required: true, // Duration in days
      min: 1
    },
    agentSwitching: {
      type: Boolean,
      default: true // Can switch agents (requires new subscription)
    },
    fullFeatures: {
      type: Boolean,
      default: true // All agents have same features
    }
  },
  stripePriceId: {
    monthly: String,
    yearly: String
  },
  isActive: {
    type: Boolean,
    default: true
  },
  isPopular: {
    type: Boolean,
    default: false
  },
  sortOrder: {
    type: Number,
    default: 0
  },
  metadata: {
    targetAudience: String,
    recommendedFor: [String],
    badges: [String] // ['Most Popular', 'Best Value', etc.]
  }
}, {
  timestamps: true
});

PlanSchema.index({ name: 1 });
PlanSchema.index({ isActive: 1, sortOrder: 1 });

const Plan = mongoose.model('Plan', PlanSchema);

// ============================================
// 2. USER SESSIONS MODEL
// ============================================

const SessionSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  sessionId: {
    type: String,
    required: true,
    unique: true
  },
  token: {
    type: String,
    required: true
  },
  refreshToken: {
    type: String,
    required: true
  },
  deviceInfo: {
    userAgent: String,
    browser: String,
    os: String,
    device: String,
    platform: String
  },
  ipAddress: {
    type: String,
    required: true
  },
  location: {
    country: String,
    region: String,
    city: String,
    timezone: String,
    coordinates: {
      lat: Number,
      lng: Number
    }
  },
  isActive: {
    type: Boolean,
    default: true
  },
  lastActivity: {
    type: Date,
    default: Date.now
  },
  expiresAt: {
    type: Date,
    required: true
  },
  revokedAt: {
    type: Date,
    default: null
  },
  revokedBy: {
    type: String,
    enum: ['user', 'admin', 'system', 'security'],
    default: null
  },
  revokeReason: {
    type: String,
    default: null
  },
  isTrusted: {
    type: Boolean,
    default: false
  },
  metadata: {
    loginMethod: {
      type: String,
      enum: ['password', 'oauth', 'magic-link', '2fa'],
      default: 'password'
    },
    rememberMe: {
      type: Boolean,
      default: false
    },
    firstLogin: {
      type: Boolean,
      default: false
    }
  }
}, {
  timestamps: true
});

SessionSchema.index({ userId: 1, isActive: 1 });
// SessionSchema.index({ sessionId: 1 }); // Removed: unique: true already creates index
SessionSchema.index({ token: 1 });
SessionSchema.index({ expiresAt: 1 });
SessionSchema.index({ lastActivity: 1 });

// Session model is defined in main models.js to avoid conflicts
// const Session = mongoose.model('Session', SessionSchema);

// ============================================
// 3. LOGIN ACTIVITY / AUTH LOGS MODEL
// ============================================

const LoginActivitySchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    default: null // null for failed attempts with unknown user
  },
  email: {
    type: String,
    required: true
  },
  action: {
    type: String,
    required: true,
    enum: [
      'login_success',
      'login_failed',
      'logout',
      'password_reset_request',
      'password_reset_success',
      'password_changed',
      'email_verified',
      'account_locked',
      'account_unlocked',
      'session_expired',
      'session_revoked',
      '2fa_enabled',
      '2fa_disabled',
      '2fa_success',
      '2fa_failed'
    ]
  },
  status: {
    type: String,
    required: true,
    enum: ['success', 'failed', 'blocked', 'suspicious']
  },
  failureReason: {
    type: String,
    enum: [
      'invalid_credentials',
      'account_not_found',
      'account_locked',
      'account_disabled',
      'invalid_2fa',
      'rate_limited',
      'suspicious_activity',
      'password_expired',
      'email_not_verified'
    ]
  },
  deviceInfo: {
    userAgent: String,
    browser: String,
    os: String,
    device: String,
    platform: String,
    fingerprint: String
  },
  ipAddress: {
    type: String,
    required: true
  },
  location: {
    country: String,
    region: String,
    city: String,
    timezone: String,
    isp: String,
    isVPN: Boolean,
    isTor: Boolean,
    coordinates: {
      lat: Number,
      lng: Number
    }
  },
  sessionId: {
    type: String,
    default: null
  },
  riskScore: {
    type: Number,
    min: 0,
    max: 100,
    default: 0
  },
  riskFactors: [{
    factor: String,
    score: Number,
    description: String
  }],
  isNewDevice: {
    type: Boolean,
    default: false
  },
  isNewLocation: {
    type: Boolean,
    default: false
  },
  metadata: {
    duration: Number, // session duration in seconds
    pagesVisited: Number,
    actionsPerformed: Number,
    referrer: String
  }
}, {
  timestamps: true
});

LoginActivitySchema.index({ userId: 1, createdAt: -1 });
LoginActivitySchema.index({ email: 1, createdAt: -1 });
LoginActivitySchema.index({ action: 1, status: 1 });
LoginActivitySchema.index({ ipAddress: 1, createdAt: -1 });
LoginActivitySchema.index({ riskScore: 1 });
LoginActivitySchema.index({ createdAt: -1 });

const LoginActivity = mongoose.model('LoginActivity', LoginActivitySchema);

// ============================================
// 4. SYSTEM SETTINGS MODEL
// ============================================

const SettingsSchema = new mongoose.Schema({
  category: {
    type: String,
    required: true,
    enum: [
      'general',
      'branding',
      'email',
      'payment',
      'security',
      'ai',
      'notifications',
      'analytics',
      'integrations',
      'maintenance'
    ]
  },
  key: {
    type: String,
    required: true
  },
  value: {
    type: mongoose.Schema.Types.Mixed,
    required: true
  },
  dataType: {
    type: String,
    required: true,
    enum: ['string', 'number', 'boolean', 'object', 'array']
  },
  displayName: {
    type: String,
    required: true
  },
  description: {
    type: String,
    required: true
  },
  isPublic: {
    type: Boolean,
    default: false // if true, can be accessed without admin auth
  },
  isRequired: {
    type: Boolean,
    default: false
  },
  validation: {
    min: Number,
    max: Number,
    pattern: String,
    enum: [String],
    required: Boolean
  },
  updatedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  previousValue: {
    type: mongoose.Schema.Types.Mixed,
    default: null
  },
  changeReason: {
    type: String,
    default: null
  }
}, {
  timestamps: true
});

SettingsSchema.index({ category: 1, key: 1 }, { unique: true });
SettingsSchema.index({ isPublic: 1 });
SettingsSchema.index({ category: 1 });

const Settings = mongoose.model('Settings', SettingsSchema);

// ============================================
// 5. USER PROFILES MODEL (EXTENDED USER INFO)
// ============================================

const UserProfileSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    unique: true
  },
  personalInfo: {
    firstName: String,
    lastName: String,
    displayName: String,
    bio: {
      type: String,
      maxlength: 500
    },
    avatar: {
      url: String,
      cloudinaryId: String
    },
    dateOfBirth: Date,
    gender: {
      type: String,
      enum: ['male', 'female', 'other', 'prefer_not_to_say']
    },
    phoneNumber: String,
    website: String,
    socialLinks: {
      twitter: String,
      linkedin: String,
      github: String,
      facebook: String
    }
  },
  location: {
    country: String,
    region: String,
    city: String,
    timezone: String,
    address: {
      street: String,
      city: String,
      state: String,
      zipCode: String,
      country: String
    }
  },
  preferences: {
    language: {
      type: String,
      default: 'en'
    },
    theme: {
      type: String,
      enum: ['light', 'dark', 'auto'],
      default: 'auto'
    },
    currency: {
      type: String,
      default: 'USD'
    },
    dateFormat: {
      type: String,
      default: 'MM/DD/YYYY'
    },
    timeFormat: {
      type: String,
      enum: ['12h', '24h'],
      default: '12h'
    },
    notifications: {
      email: {
        marketing: { type: Boolean, default: true },
        updates: { type: Boolean, default: true },
        security: { type: Boolean, default: true },
        billing: { type: Boolean, default: true }
      },
      push: {
        enabled: { type: Boolean, default: false },
        marketing: { type: Boolean, default: false },
        updates: { type: Boolean, default: true },
        security: { type: Boolean, default: true }
      },
      sms: {
        enabled: { type: Boolean, default: false },
        security: { type: Boolean, default: false }
      }
    }
  },
  privacy: {
    profileVisibility: {
      type: String,
      enum: ['public', 'private', 'friends'],
      default: 'private'
    },
    showEmail: {
      type: Boolean,
      default: false
    },
    showPhone: {
      type: Boolean,
      default: false
    },
    allowMessages: {
      type: Boolean,
      default: true
    }
  },
  verification: {
    email: {
      verified: { type: Boolean, default: false },
      verifiedAt: Date
    },
    phone: {
      verified: { type: Boolean, default: false },
      verifiedAt: Date
    },
    identity: {
      verified: { type: Boolean, default: false },
      verifiedAt: Date,
      method: String
    }
  },
  metadata: {
    onboardingCompleted: {
      type: Boolean,
      default: false
    },
    profileCompleteness: {
      type: Number,
      min: 0,
      max: 100,
      default: 0
    },
    lastProfileUpdate: Date
  }
}, {
  timestamps: true
});

UserProfileSchema.index({ userId: 1 });
UserProfileSchema.index({ 'personalInfo.displayName': 'text', 'personalInfo.bio': 'text' });

// UserProfile model is defined in main models.js to avoid conflicts
// const UserProfile = mongoose.model('UserProfile', UserProfileSchema);

// ============================================
// 6. BILLING HISTORY / INVOICES MODEL
// ============================================

const InvoiceSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  subscriptionId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Subscription',
    default: null
  },
  transactionId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Transaction',
    default: null
  },
  invoiceNumber: {
    type: String,
    required: true,
    unique: true
  },
  stripeInvoiceId: String,
  status: {
    type: String,
    required: true,
    enum: ['draft', 'pending', 'paid', 'failed', 'cancelled', 'refunded'],
    default: 'pending'
  },
  billingPeriod: {
    start: {
      type: Date,
      required: true
    },
    end: {
      type: Date,
      required: true
    }
  },
  items: [{
    description: {
      type: String,
      required: true
    },
    quantity: {
      type: Number,
      required: true,
      min: 1
    },
    unitPrice: {
      type: Number,
      required: true,
      min: 0
    },
    totalPrice: {
      type: Number,
      required: true,
      min: 0
    },
    planId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Plan'
    }
  }],
  amounts: {
    subtotal: {
      type: Number,
      required: true,
      min: 0
    },
    tax: {
      type: Number,
      default: 0,
      min: 0
    },
    discount: {
      type: Number,
      default: 0,
      min: 0
    },
    total: {
      type: Number,
      required: true,
      min: 0
    },
    currency: {
      type: String,
      required: true,
      default: 'USD'
    }
  },
  paymentDetails: {
    method: String,
    paidAt: Date,
    dueDate: Date,
    attemptCount: {
      type: Number,
      default: 0
    },
    nextRetryAt: Date
  },
  billingAddress: {
    name: String,
    email: String,
    street: String,
    city: String,
    state: String,
    zipCode: String,
    country: String,
    taxId: String
  },
  metadata: {
    downloadUrl: String,
    emailSentAt: Date,
    reminderSentAt: Date,
    notes: String
  }
}, {
  timestamps: true
});

InvoiceSchema.index({ userId: 1, createdAt: -1 });
// InvoiceSchema.index({ invoiceNumber: 1 }); // Removed: unique: true already creates index
InvoiceSchema.index({ status: 1 });
InvoiceSchema.index({ 'billingPeriod.start': 1, 'billingPeriod.end': 1 });

const Invoice = mongoose.model('Invoice', InvoiceSchema);

// ============================================
// 7. EMAIL LOGS MODEL
// ============================================

const EmailLogSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    default: null
  },
  to: {
    type: [String],
    required: true
  },
  from: {
    type: String,
    required: true
  },
  cc: [String],
  bcc: [String],
  subject: {
    type: String,
    required: true
  },
  template: {
    name: String,
    version: String,
    data: mongoose.Schema.Types.Mixed
  },
  content: {
    html: String,
    text: String
  },
  status: {
    type: String,
    required: true,
    enum: ['queued', 'sent', 'delivered', 'opened', 'clicked', 'bounced', 'failed', 'rejected'],
    default: 'queued'
  },
  provider: {
    type: String,
    enum: ['sendgrid', 'mailgun', 'ses', 'smtp'],
    required: true
  },
  providerId: String, // External provider message ID
  deliveryInfo: {
    sentAt: Date,
    deliveredAt: Date,
    openedAt: Date,
    clickedAt: Date,
    bouncedAt: Date,
    bounceReason: String,
    failureReason: String
  },
  tracking: {
    opens: [{
      timestamp: Date,
      userAgent: String,
      ipAddress: String
    }],
    clicks: [{
      timestamp: Date,
      url: String,
      userAgent: String,
      ipAddress: String
    }]
  },
  priority: {
    type: String,
    enum: ['low', 'normal', 'high', 'critical'],
    default: 'normal'
  },
  category: {
    type: String,
    enum: [
      'welcome',
      'verification',
      'password_reset',
      'billing',
      'notification',
      'marketing',
      'support',
      'system'
    ]
  },
  metadata: {
    campaignId: String,
    source: String,
    tags: [String],
    retryCount: {
      type: Number,
      default: 0
    }
  }
}, {
  timestamps: true
});

EmailLogSchema.index({ userId: 1, createdAt: -1 });
EmailLogSchema.index({ to: 1, createdAt: -1 });
EmailLogSchema.index({ status: 1 });
EmailLogSchema.index({ category: 1, createdAt: -1 });
EmailLogSchema.index({ providerId: 1 });

const EmailLog = mongoose.model('EmailLog', EmailLogSchema);

// ============================================
// 8. AUDIT LOGS MODEL
// ============================================

const AuditLogSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  action: {
    type: String,
    required: true
  },
  resource: {
    type: {
      type: String,
      required: true // 'user', 'plan', 'setting', etc.
    },
    id: {
      type: String,
      required: true
    },
    name: String
  },
  changes: {
    before: mongoose.Schema.Types.Mixed,
    after: mongoose.Schema.Types.Mixed,
    fields: [String] // List of changed fields
  },
  severity: {
    type: String,
    enum: ['low', 'medium', 'high', 'critical'],
    default: 'medium'
  },
  category: {
    type: String,
    enum: [
      'authentication',
      'authorization',
      'data_modification',
      'system_configuration',
      'security',
      'billing',
      'user_management'
    ],
    required: true
  },
  ipAddress: String,
  userAgent: String,
  source: {
    type: String,
    enum: ['web', 'api', 'admin', 'system', 'integration'],
    default: 'web'
  },
  metadata: {
    sessionId: String,
    requestId: String,
    additionalContext: mongoose.Schema.Types.Mixed
  }
}, {
  timestamps: true
});

AuditLogSchema.index({ userId: 1, createdAt: -1 });
AuditLogSchema.index({ action: 1, createdAt: -1 });
AuditLogSchema.index({ 'resource.type': 1, 'resource.id': 1 });
AuditLogSchema.index({ category: 1, severity: 1 });
AuditLogSchema.index({ createdAt: -1 });

const AuditLog = mongoose.model('AuditLog', AuditLogSchema);

// Export all critical models
module.exports = {
  Plan,
  // Session, // Defined in main models.js
  LoginActivity,
  Settings,
  // UserProfile, // Defined in main models.js
  Invoice,
  EmailLog,
  AuditLog
};