// Fix duplicate key error on stripePaymentIntentId
// This script drops the unique index that's causing issues

const mongoose = require('mongoose');
require('dotenv').config();

async function fixIndex() {
  try {
    const mongoUrl = process.env.MONGODB_URI || 'mongodb://localhost:27017/iamai-global';
    console.log('🔌 Connecting to MongoDB...');
    await mongoose.connect(mongoUrl);
    console.log('✅ Connected to MongoDB');

    const db = mongoose.connection.db;
    const collection = db.collection('agent_purchases');

    // Get existing indexes
    console.log('\n📋 Current indexes:');
    const indexes = await collection.indexes();
    indexes.forEach(idx => {
      console.log(`  - ${idx.name}:`, JSON.stringify(idx.key), idx.unique ? '(UNIQUE)' : '');
    });

    // Drop the problematic unique index
    try {
      console.log('\n🗑️  Dropping stripePaymentIntentId_1 unique index...');
      await collection.dropIndex('stripePaymentIntentId_1');
      console.log('✅ Index dropped successfully');
    } catch (err) {
      if (err.codeName === 'IndexNotFound') {
        console.log('ℹ️  Index not found (already dropped or never existed)');
      } else {
        throw err;
      }
    }

    // Create non-unique index
    console.log('\n📝 Creating non-unique index on stripePaymentIntentId...');
    await collection.createIndex({ stripePaymentIntentId: 1 }, { sparse: true });
    console.log('✅ Non-unique index created');

    // Show final indexes
    console.log('\n📋 Final indexes:');
    const finalIndexes = await collection.indexes();
    finalIndexes.forEach(idx => {
      console.log(`  - ${idx.name}:`, JSON.stringify(idx.key), idx.unique ? '(UNIQUE)' : '');
    });

    console.log('\n✅ Database index fix complete!');
    process.exit(0);
  } catch (error) {
    console.error('❌ Error:', error);
    process.exit(1);
  }
}

fixIndex();
