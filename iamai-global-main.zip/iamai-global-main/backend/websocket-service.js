/**
 * WebSocket Service for Real-time Chat
 * Handles Socket.IO connections, room management, and live chat features
 */

const socketIO = require('socket.io');
const jwt = require('jsonwebtoken');

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-this';
const LEGACY_SECRET = 'your-secret-key-change-this';  // Fallback for tokens issued before JWT_SECRET fix
const DEFAULT_PROD_ORIGINS = ['https://iamai.global', 'https://www.iamai.global'];
const DEFAULT_DEV_ORIGINS = [
  'https://iamai.global',
  'https://www.iamai.global',
];

// Helper function to verify token with multiple secrets
function verifyTokenWithFallback(token) {
  const secrets = [JWT_SECRET, LEGACY_SECRET].filter((s, i, arr) => s && arr.indexOf(s) === i);
  for (const secret of secrets) {
    try {
      return jwt.verify(token, secret);
    } catch (err) {
      // Try next secret
    }
  }
  throw new Error('Invalid token');
}

// Import ActivityLog model for tracking
let ActivityLog = null;

class WebSocketService {
  constructor() {
    this.io = null;
    this.connectedUsers = new Map(); // userId -> socketId
    this.userSockets = new Map(); // socketId -> userId
    this.chatRooms = new Map(); // roomId -> Set of socketIds
    this.typingUsers = new Map(); // roomId -> Set of userIds
  }

  /**
   * Set ActivityLog model for tracking
   */
  setActivityLog(model) {
    try {
      if (!model) {
        console.log('⚠️  ActivityLog model not provided, WebSocket tracking disabled');
        return;
      }
      ActivityLog = model;
      console.log('📊 ActivityLog model set for WebSocket tracking');
    } catch (error) {
      console.error('⚠️  Error setting ActivityLog model:', error.message);
    }
  }

  /**
   * Log WebSocket activity
   */
  async logActivity(socket, action, metadata = {}) {
    if (!ActivityLog) {
      console.log('📊 WebSocket activity not logged - ActivityLog not available');
      return;
    }

    try {
      await ActivityLog.create({
        userId: socket.isAnonymous ? null : socket.userId,
        sessionId: socket.userId, // Use userId as sessionId for WS
        action: action,
        route: '/ws',
        method: 'WS',
        statusCode: 200,
        ipAddress: socket.handshake.address || 'unknown',
        userAgent: socket.handshake.headers['user-agent'] || 'unknown',
        isAnonymous: socket.isAnonymous || false,
        metadata: {
          socketId: socket.id,
          ...metadata,
        },
      });
      console.log(`📊 WS Activity: ${action} - ${socket.isAnonymous ? 'anonymous' : 'user'}`);
    } catch (error) {
      console.error('❌ Failed to log WebSocket activity:', error.message);
    }
  }

  /**
   * Initialize Socket.IO server
   */
  initialize(server) {
    const envOrigins = process.env.WS_ALLOWED_ORIGINS
      ? process.env.WS_ALLOWED_ORIGINS.split(',')
          .map(origin => origin.trim())
          .filter(Boolean)
      : [];
    const frontendOrigin = process.env.FRONTEND_URL ? [process.env.FRONTEND_URL.trim()] : [];

    const allowedOrigins =
      envOrigins.length > 0
        ? envOrigins
        : frontendOrigin.length > 0
          ? frontendOrigin
          : process.env.NODE_ENV === 'production'
            ? DEFAULT_PROD_ORIGINS
            : DEFAULT_DEV_ORIGINS;

    const corsOrigin =
      allowedOrigins.length === 0 || allowedOrigins.includes('*') ? '*' : allowedOrigins;

    console.log('🔌 WebSocket allowed origins:', corsOrigin);

    this.io = socketIO(server, {
      cors: {
        origin: corsOrigin,
        methods: ['GET', 'POST'],
        credentials: true,
      },
      pingTimeout: 60000,
      pingInterval: 25000,
    });

    this.setupMiddleware();
    this.setupEventHandlers();

    console.log('🔌 WebSocket service initialized');
    return this.io;
  }

  /**
   * Setup authentication middleware
   */
  setupMiddleware() {
    this.io.use((socket, next) => {
      try {
        const token =
          socket.handshake.auth.token ||
          socket.handshake.headers.authorization?.replace('Bearer ', '');

        if (!token) {
          // Allow anonymous connections for toolbox features
          console.log(`🔓 Anonymous WebSocket connection allowed`);
          socket.userId = `anon_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
          socket.userEmail = 'anonymous';
          socket.userTier = 'FREE';
          socket.isAnonymous = true;
          return next();
        }

        // Verify JWT token (supports both new and legacy secrets)
        const decoded = verifyTokenWithFallback(token);
        socket.userId = decoded.id;
        socket.userEmail = decoded.email;
        socket.userTier = decoded.tier;
        socket.isAnonymous = false;

        console.log(`✅ User authenticated: ${socket.userEmail} (${socket.userId})`);
        next();
      } catch (error) {
        console.error('❌ WebSocket auth error:', error.message);
        // On token verification failure, allow anonymous connection
        console.log(`🔓 Token invalid, allowing anonymous connection`);
        socket.userId = `anon_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        socket.userEmail = 'anonymous';
        socket.userTier = 'FREE';
        socket.isAnonymous = true;
        next();
      }
    });
  }

  /**
   * Setup Socket.IO event handlers
   */
  setupEventHandlers() {
    this.io.on('connection', socket => {
      console.log(`🔗 User connected: ${socket.userId} (Socket: ${socket.id})`);

      // Track connected user
      this.connectedUsers.set(socket.userId, socket.id);
      this.userSockets.set(socket.id, socket.userId);

      // Log connection activity
      this.logActivity(socket, 'WS_CONNECT', {
        userEmail: socket.userEmail,
        userTier: socket.userTier,
      });

      // Send connection confirmation
      socket.emit('connected', {
        userId: socket.userId,
        socketId: socket.id,
        timestamp: new Date().toISOString(),
      });

      // Broadcast online status to others
      this.broadcastUserStatus(socket.userId, 'online');

      // === CHAT ROOM EVENTS ===

      // Join a chat room
      socket.on('join_room', data => {
        this.handleJoinRoom(socket, data);
      });

      // Leave a chat room
      socket.on('leave_room', data => {
        this.handleLeaveRoom(socket, data);
      });

      // Send message
      socket.on('send_message', data => {
        this.handleSendMessage(socket, data);

        // Log message activity
        this.logActivity(socket, 'WS_MESSAGE', {
          roomId: data.roomId,
          messageLength: data.message?.length || 0,
        });
      });

      // Typing indicator
      socket.on('typing_start', data => {
        this.handleTypingStart(socket, data);
      });

      socket.on('typing_stop', data => {
        this.handleTypingStop(socket, data);
      });

      // === AI CHAT EVENTS ===

      // Start AI chat session
      socket.on('ai_chat_start', data => {
        this.handleAIChatStart(socket, data);

        // Log chat start activity
        this.logActivity(socket, 'AI_CHAT_START', {
          agentId: data.agentId,
        });
      });

      // AI chat message
      socket.on('ai_chat_message', data => {
        this.handleAIChatMessage(socket, data);

        // Log chat message activity
        this.logActivity(socket, 'AI_CHAT_MESSAGE', {
          agentId: data.agentId,
          messageLength: data.message?.length || 0,
        });
      });

      // === LIVE SUPPORT EVENTS ===

      // Live support chat message
      socket.on('support:chat:message', data => {
        this.handleSupportChatMessage(socket, data);
      });

      // Live support typing indicator
      socket.on('support:typing', data => {
        this.handleSupportTyping(socket, data);
      });

      // Live support ticket creation
      socket.on('support:ticket:create', data => {
        this.handleSupportTicketCreate(socket, data);
      });

      // === PRESENCE EVENTS ===

      // Request online users
      socket.on('get_online_users', () => {
        this.handleGetOnlineUsers(socket);
      });

      // User status update
      socket.on('update_status', data => {
        this.handleStatusUpdate(socket, data);
      });

      // === TOOLS EVENTS ===

      // Port scan
      socket.on('tools:portscan:start', data => {
        this.handlePortScan(socket, data);
      });

      // Ping test
      socket.on('tools:ping:start', data => {
        console.log('[WebSocket] Received tools:ping:start', data);
        this.handlePingStart(socket, data);
      });

      socket.on('tools:ping:stop', () => {
        console.log('[WebSocket] Received tools:ping:stop');
        this.handlePingStop(socket);
      });

      // === DISCONNECT ===

      socket.on('disconnect', () => {
        this.handleDisconnect(socket);

        // Log disconnection activity
        this.logActivity(socket, 'WS_DISCONNECT');
      });

      socket.on('error', error => {
        console.error(`❌ Socket error for user ${socket.userId}:`, error);

        // Log error activity
        this.logActivity(socket, 'WS_ERROR', { error: error.message });
      });
    });
  }

  /**
   * Handle user joining a chat room
   */
  handleJoinRoom(socket, data) {
    const { roomId, roomType = 'chat' } = data;

    if (!roomId) {
      return socket.emit('error', { message: 'Room ID required' });
    }

    socket.join(roomId);

    // Track room membership
    if (!this.chatRooms.has(roomId)) {
      this.chatRooms.set(roomId, new Set());
    }
    this.chatRooms.get(roomId).add(socket.id);

    console.log(`📥 User ${socket.userId} joined room: ${roomId}`);

    // Notify room members
    socket.to(roomId).emit('user_joined', {
      userId: socket.userId,
      roomId,
      timestamp: new Date().toISOString(),
    });

    // Send room info to user
    socket.emit('room_joined', {
      roomId,
      roomType,
      memberCount: this.chatRooms.get(roomId).size,
      timestamp: new Date().toISOString(),
    });
  }

  /**
   * Handle user leaving a chat room
   */
  handleLeaveRoom(socket, data) {
    const { roomId } = data;

    if (!roomId) return;

    socket.leave(roomId);

    // Remove from room tracking
    if (this.chatRooms.has(roomId)) {
      this.chatRooms.get(roomId).delete(socket.id);
      if (this.chatRooms.get(roomId).size === 0) {
        this.chatRooms.delete(roomId);
      }
    }

    console.log(`📤 User ${socket.userId} left room: ${roomId}`);

    // Notify room members
    socket.to(roomId).emit('user_left', {
      userId: socket.userId,
      roomId,
      timestamp: new Date().toISOString(),
    });
  }

  /**
   * Handle sending a message
   */
  handleSendMessage(socket, data) {
    const { roomId, message, messageType = 'text', metadata = {} } = data;

    if (!roomId || !message) {
      return socket.emit('error', { message: 'Room ID and message required' });
    }

    const messageData = {
      id: `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      roomId,
      userId: socket.userId,
      userEmail: socket.userEmail,
      message,
      messageType,
      metadata,
      timestamp: new Date().toISOString(),
    };

    // Broadcast to room (including sender)
    this.io.to(roomId).emit('new_message', messageData);

    console.log(`💬 Message in room ${roomId} from ${socket.userId}: ${message.substring(0, 50)}`);
  }

  /**
   * Handle typing indicator start
   */
  handleTypingStart(socket, data) {
    const { roomId } = data;

    if (!roomId) return;

    if (!this.typingUsers.has(roomId)) {
      this.typingUsers.set(roomId, new Set());
    }
    this.typingUsers.get(roomId).add(socket.userId);

    // Broadcast to others in room
    socket.to(roomId).emit('user_typing', {
      userId: socket.userId,
      roomId,
      isTyping: true,
    });
  }

  /**
   * Handle typing indicator stop
   */
  handleTypingStop(socket, data) {
    const { roomId } = data;

    if (!roomId) return;

    if (this.typingUsers.has(roomId)) {
      this.typingUsers.get(roomId).delete(socket.userId);
    }

    // Broadcast to others in room
    socket.to(roomId).emit('user_typing', {
      userId: socket.userId,
      roomId,
      isTyping: false,
    });
  }

  /**
   * Handle AI chat start
   */
  handleAIChatStart(socket, data) {
    const { agentId, conversationId } = data;

    const roomId = conversationId || `ai_${agentId}_${socket.userId}_${Date.now()}`;

    socket.join(roomId);

    socket.emit('ai_chat_ready', {
      roomId,
      agentId,
      userId: socket.userId,
      timestamp: new Date().toISOString(),
    });

    console.log(
      `🤖 AI chat started: User ${socket.userId} with agent ${agentId} in room ${roomId}`
    );
  }

  /**
   * Handle AI chat message (to be integrated with AI service)
   */
  handleAIChatMessage(socket, data) {
    const { roomId, message, agentId } = data;

    if (!roomId || !message || !agentId) {
      return socket.emit('error', { message: 'Missing required fields' });
    }

    // Emit user message immediately
    socket.emit('ai_message_received', {
      roomId,
      message,
      userId: socket.userId,
      timestamp: new Date().toISOString(),
    });

    // Emit "AI is thinking" indicator
    socket.emit('ai_thinking', {
      roomId,
      agentId,
      status: 'processing',
    });

    console.log(
      `🤖 AI chat message from ${socket.userId} to agent ${agentId}: ${message.substring(0, 50)}`
    );

    // Note: Actual AI processing should be done through AI service
    // This event can trigger the AI service to process and respond
    socket.emit('ai_processing_started', {
      roomId,
      agentId,
      messageId: data.messageId || `msg_${Date.now()}`,
    });
  }

  /**
   * Handle get online users
   */
  handleGetOnlineUsers(socket) {
    const onlineUsers = Array.from(this.connectedUsers.keys());

    socket.emit('online_users', {
      users: onlineUsers,
      count: onlineUsers.length,
      timestamp: new Date().toISOString(),
    });
  }

  /**
   * Handle status update
   */
  handleStatusUpdate(socket, data) {
    const { status } = data; // 'online', 'away', 'busy', 'offline'

    if (!status) return;

    this.broadcastUserStatus(socket.userId, status);
  }

  /**
   * Handle port scan
   */
  async handlePortScan(socket, data) {
    const { host, ports } = data;

    if (!host || !ports || !Array.isArray(ports)) {
      return socket.emit('error', { message: 'Host and ports array required' });
    }

    console.log(`🔍 Starting port scan for ${host} on ${ports.length} ports`);

    const net = require('net');

    // Scan ports sequentially with delay
    for (let i = 0; i < ports.length; i++) {
      const port = ports[i];

      try {
        const isOpen = await this.checkPort(host, port);

        socket.emit('tools:portscan:update', {
          host,
          port,
          open: isOpen,
          service: this.getServiceName(port),
          progress: Math.round(((i + 1) / ports.length) * 100),
        });

        // Small delay to prevent overwhelming the system
        await new Promise(resolve => setTimeout(resolve, 50));
      } catch (error) {
        socket.emit('tools:portscan:update', {
          host,
          port,
          open: false,
          error: error.message,
        });
      }
    }

    socket.emit('tools:portscan:done', {
      host,
      totalPorts: ports.length,
      timestamp: new Date().toISOString(),
    });

    console.log(`✅ Port scan completed for ${host}`);
  }

  /**
   * Check if a port is open
   */
  checkPort(host, port, timeout = 2000) {
    return new Promise(resolve => {
      const net = require('net');
      const socket = new net.Socket();

      socket.setTimeout(timeout);

      socket.on('connect', () => {
        socket.destroy();
        resolve(true);
      });

      socket.on('timeout', () => {
        socket.destroy();
        resolve(false);
      });

      socket.on('error', () => {
        socket.destroy();
        resolve(false);
      });

      socket.connect(port, host);
    });
  }

  /**
   * Get common service name for port
   */
  getServiceName(port) {
    const services = {
      21: 'FTP',
      22: 'SSH',
      23: 'Telnet',
      25: 'SMTP',
      53: 'DNS',
      80: 'HTTP',
      110: 'POP3',
      143: 'IMAP',
      443: 'HTTPS',
      445: 'SMB',
      465: 'SMTPS',
      587: 'SMTP Submission',
      993: 'IMAPS',
      995: 'POP3S',
      1433: 'MS SQL',
      3306: 'MySQL',
      3389: 'RDP',
      5432: 'PostgreSQL',
      5900: 'VNC',
      6379: 'Redis',
      8080: 'HTTP Alt',
      8443: 'HTTPS Alt',
      27017: 'MongoDB',
    };

    return services[port] || 'Unknown';
  }

  /**
   * Handle disconnect
   */
  handleDisconnect(socket) {
    console.log(`🔌 User disconnected: ${socket.userId} (Socket: ${socket.id})`);

    // Remove from tracking
    this.connectedUsers.delete(socket.userId);
    this.userSockets.delete(socket.id);

    // Remove from all rooms
    this.chatRooms.forEach((members, roomId) => {
      if (members.has(socket.id)) {
        members.delete(socket.id);
        socket.to(roomId).emit('user_left', {
          userId: socket.userId,
          roomId,
          timestamp: new Date().toISOString(),
        });
      }
    });

    // Remove from typing indicators
    this.typingUsers.forEach((users, roomId) => {
      if (users.has(socket.userId)) {
        users.delete(socket.userId);
      }
    });

    // Broadcast offline status
    this.broadcastUserStatus(socket.userId, 'offline');
  }

  /**
   * Broadcast user status to all connected clients
   */
  broadcastUserStatus(userId, status) {
    this.io.emit('user_status_changed', {
      userId,
      status,
      timestamp: new Date().toISOString(),
    });
  }

  /**
   * Send message to specific user
   */
  sendToUser(userId, event, data) {
    const socketId = this.connectedUsers.get(userId);
    if (socketId) {
      this.io.to(socketId).emit(event, data);
      return true;
    }
    return false;
  }

  /**
   * Send message to room
   */
  sendToRoom(roomId, event, data) {
    this.io.to(roomId).emit(event, data);
  }

  /**
   * Broadcast to all connected clients
   */
  broadcast(event, data) {
    this.io.emit(event, data);
  }

  /**
   * Get online users count
   */
  getOnlineCount() {
    return this.connectedUsers.size;
  }

  /**
   * Get room members count
   */
  getRoomMemberCount(roomId) {
    return this.chatRooms.get(roomId)?.size || 0;
  }

  /**
   * Check if user is online
   */
  isUserOnline(userId) {
    return this.connectedUsers.has(userId);
  }

  /**
   * Get all online user IDs
   */
  getOnlineUsers() {
    return Array.from(this.connectedUsers.keys());
  }

  /**
   * Handle ping test start
   */
  async handlePingStart(socket, data) {
    console.log('[Ping] handlePingStart called', data);
    const { host, count = 10, intervalMs = 1000 } = data;

    if (!host) {
      console.log('[Ping] No host provided, sending error');
      socket.emit('tools:ping:error', { error: 'Host is required' });
      return;
    }

    console.log('[Ping] Starting ping test', { host, count, intervalMs });

    // Stop any existing ping for this socket
    this.handlePingStop(socket);

    // Store ping interval ID
    socket.pingIntervalId = null;
    socket.pingCount = 0;
    socket.pingHost = host;
    socket.pingMaxCount = count;

    let seq = 1;

    const doPing = async () => {
      console.log('[Ping] Executing ping', {
        seq,
        count: socket.pingCount,
        max: socket.pingMaxCount,
      });
      if (socket.pingCount >= socket.pingMaxCount) {
        console.log('[Ping] Max count reached, stopping');
        this.handlePingStop(socket);
        socket.emit('tools:ping:done');
        return;
      }

      socket.pingCount++;
      const startTime = Date.now();

      try {
        // Use TCP connection test as ping (ICMP not available in Node without special permissions)
        const net = require('net');
        const url = require('url');

        let targetHost = host;
        let targetPort = 80;

        // Parse if it's a URL
        if (host.includes('://')) {
          const parsed = url.parse(host);
          targetHost = parsed.hostname;
          targetPort = parsed.port || (parsed.protocol === 'https:' ? 443 : 80);
        } else if (host.includes(':')) {
          const parts = host.split(':');
          targetHost = parts[0];
          targetPort = parseInt(parts[1]) || 80;
        }

        const testConnection = () => {
          return new Promise((resolve, reject) => {
            const timeout = setTimeout(() => {
              client.destroy();
              reject(new Error('Connection timeout'));
            }, 5000);

            const client = net.createConnection({ host: targetHost, port: targetPort }, () => {
              clearTimeout(timeout);
              const timeMs = Date.now() - startTime;
              client.end();
              resolve(timeMs);
            });

            client.on('error', err => {
              clearTimeout(timeout);
              reject(err);
            });
          });
        };

        const timeMs = await testConnection();

        socket.emit('tools:ping:update', {
          host,
          seq: seq++,
          alive: true,
          timeMs,
          timestamp: Date.now(),
        });
      } catch (error) {
        socket.emit('tools:ping:update', {
          host,
          seq: seq++,
          alive: false,
          timeMs: null,
          error: error.message,
          timestamp: Date.now(),
        });
      }
    };

    // Start first ping immediately
    doPing();

    // Continue pinging at interval
    socket.pingIntervalId = setInterval(doPing, intervalMs);
  }

  /**
   * Handle ping test stop
   */
  handlePingStop(socket) {
    if (socket.pingIntervalId) {
      clearInterval(socket.pingIntervalId);
      socket.pingIntervalId = null;
    }
    socket.pingCount = 0;
    socket.pingHost = null;
    socket.pingMaxCount = 0;
  }

  // ===== LIVE SUPPORT HANDLERS =====

  /**
   * Handle live support chat message
   */
  async handleSupportChatMessage(socket, data) {
    try {
      const { message, conversationId } = data;
      const userId = socket.userId;

      console.log(`💬 Support message from ${userId}:`, message.substring(0, 50));

      // Emit message received confirmation
      socket.emit('support:message:received', {
        messageId: data.messageId || Date.now().toString(),
        timestamp: new Date().toISOString(),
      });

      // In a real implementation, this would:
      // 1. Save message to database
      // 2. Process with AI
      // 3. Create ticket if needed
      // 4. Notify support team if escalated

      // For now, acknowledge receipt
      socket.emit('support:message:status', {
        messageId: data.messageId,
        status: 'processing',
      });
    } catch (error) {
      console.error('Error handling support message:', error);
      socket.emit('support:error', {
        message: 'Failed to process message',
        error: error.message,
      });
    }
  }

  /**
   * Handle live support typing indicator
   */
  handleSupportTyping(socket, data) {
    const { isTyping, conversationId } = data;
    const userId = socket.userId;

    // Broadcast typing status to support team
    this.io.emit('support:typing:update', {
      userId,
      conversationId,
      isTyping,
      timestamp: new Date().toISOString(),
    });
  }

  /**
   * Handle support ticket creation via WebSocket
   */
  async handleSupportTicketCreate(socket, data) {
    try {
      const { category, severity, description } = data;
      const userId = socket.userId;

      console.log(`🎫 Creating support ticket for ${userId}`);

      // Emit ticket creation started
      socket.emit('support:ticket:creating', {
        timestamp: new Date().toISOString(),
      });

      // In real implementation:
      // 1. Create ticket in database
      // 2. Notify support team
      // 3. Send confirmation email
      // 4. Start SLA timer

      // For now, send success response
      const caseId = `SUP-${Date.now()}-${Math.random().toString(36).substr(2, 4).toUpperCase()}`;

      socket.emit('support:ticket:created', {
        caseId,
        category: category || 'general',
        severity: severity || 'medium',
        status: 'open',
        createdAt: new Date().toISOString(),
        slaHours: 48,
      });
    } catch (error) {
      console.error('Error creating support ticket:', error);
      socket.emit('support:error', {
        message: 'Failed to create ticket',
        error: error.message,
      });
    }
  }

  /**
   * Get WebSocket service statistics
   */
  getStats() {
    return {
      connectedUsers: this.connectedUsers.size,
      totalSockets: this.userSockets.size,
      activeRooms: this.chatRooms.size,
      typingUsers: Array.from(this.typingUsers.values()).reduce(
        (total, users) => total + users.size,
        0
      ),
      serverInitialized: !!this.io,
      timestamp: new Date().toISOString(),
    };
  }
}
const wsService = new WebSocketService();

module.exports = wsService;
