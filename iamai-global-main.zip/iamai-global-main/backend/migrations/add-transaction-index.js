const mongoose = require('mongoose');
require('dotenv').config();
const { AGENT_LIST } = require('../agent-collections');

/**
 * Migration: Add sparse unique index on transactions.transactionId
 * 
 * This migration safely adds a sparse unique index to the transactionId field
 * in all agent collections. A sparse index only includes documents that have
 * the indexed field, preventing duplicate key errors on null values.
 */

async function addTransactionIndexes() {
  try {
    console.log('🔄 MIGRATION: Adding Transaction Indexes');
    console.log('=========================================');
    
    // Connect to MongoDB
    const mongoUri = process.env.MONGODB_URI || 'mongodb://localhost:27017/iamai-global';
    await mongoose.connect(mongoUri);
    console.log('✅ Connected to MongoDB');
    
    const db = mongoose.connection.db;
    let successCount = 0;
    let skipCount = 0;
    let errorCount = 0;
    
    // Add index to each agent collection
    for (const agentId of AGENT_LIST) {
      const collectionName = `${agentId}-data`;
      
      try {
        // Check if collection exists
        const collections = await db.listCollections({ name: collectionName }).toArray();
        
        if (collections.length === 0) {
          console.log(`⚪ Skipping ${collectionName} - collection doesn't exist`);
          skipCount++;
          continue;
        }
        
        const collection = db.collection(collectionName);
        
        // Check if index already exists
        const indexes = await collection.indexes();
        const indexExists = indexes.some(idx => 
          idx.key && idx.key['transactions.transactionId']
        );
        
        if (indexExists) {
          console.log(`✓ ${collectionName} - index already exists`);
          skipCount++;
          continue;
        }
        
        // Create sparse unique index
        await collection.createIndex(
          { 'transactions.transactionId': 1 },
          { 
            sparse: true, 
            unique: true,
            name: 'transactions_transactionId_sparse_unique'
          }
        );
        
        console.log(`✅ ${collectionName} - index created successfully`);
        successCount++;
        
      } catch (error) {
        console.error(`❌ ${collectionName} - Error: ${error.message}`);
        errorCount++;
      }
    }
    
    console.log('\n📊 MIGRATION SUMMARY');
    console.log('===================');
    console.log(`✅ Indexes created: ${successCount}`);
    console.log(`⚪ Skipped: ${skipCount}`);
    console.log(`❌ Errors: ${errorCount}`);
    console.log(`📝 Total collections processed: ${AGENT_LIST.length}`);
    
    if (errorCount === 0) {
      console.log('\n🎉 Migration completed successfully!');
    } else {
      console.log('\n⚠️  Migration completed with errors. Please review.');
    }
    
    await mongoose.connection.close();
    console.log('✅ Database connection closed');
    
    process.exit(errorCount > 0 ? 1 : 0);
    
  } catch (error) {
    console.error('❌ Migration failed:', error);
    process.exit(1);
  }
}

// Run migration if called directly
if (require.main === module) {
  addTransactionIndexes();
}

module.exports = { addTransactionIndexes };
