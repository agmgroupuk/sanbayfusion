// Role-Based Access Control (RBAC) Models
// Complete permission management and access control system

const mongoose = require('mongoose');

// ============================================
// 1. ROLE MODEL
// ============================================

const RoleSchema = new mongoose.Schema({
  // Role Identification
  name: {
    type: String,
    required: true,
    unique: true,
    trim: true,
    lowercase: true,
    enum: [
      'super_admin',
      'admin', 
      'moderator',
      'support_agent',
      'billing_manager',
      'user_manager',
      'content_manager',
      'analytics_viewer',
      'api_user',
      'subscriber',
      'free_user',
      'guest'
    ]
  },
  
  displayName: {
    type: String,
    required: true,
    trim: true
  },
  
  description: {
    type: String,
    required: true,
    maxlength: 500
  },
  
  // Role Properties
  level: {
    type: Number,
    required: true,
    min: 0,
    max: 100,
    // 100 = Super Admin, 90 = Admin, 80 = Moderator, etc.
  },
  
  category: {
    type: String,
    required: true,
    enum: [
      'system',      // System roles (admin, moderator)
      'support',     // Customer support roles
      'business',    // Business operation roles
      'customer',    // Customer/subscriber roles
      'api'         // API access roles
    ]
  },
  
  // Role Status
  isActive: {
    type: Boolean,
    default: true
  },
  
  isSystem: {
    type: Boolean,
    default: false // System roles cannot be deleted
  },
  
  isDefault: {
    type: Boolean,
    default: false // Default role for new users
  },
  
  // Permission Sets
  permissions: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Permission'
  }],
  
  // Inherited Roles (hierarchical roles)
  inheritsFrom: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Role'
  }],
  
  // Role Limitations
  limitations: {
    maxUsers: {
      type: Number,
      default: null // null = unlimited
    },
    expiresAfter: {
      type: Number, // days
      default: null // null = no expiration
    },
    requiresApproval: {
      type: Boolean,
      default: false
    },
    ipRestrictions: [String], // IP whitelist
    timeRestrictions: {
      allowedHours: [{
        start: String, // "09:00"
        end: String   // "17:00"
      }],
      allowedDays: [{
        type: String,
        enum: ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday']
      }],
      timezone: {
        type: String,
        default: 'UTC'
      }
    }
  },
  
  // Subscription Requirements
  subscription: {
    requiredPlan: {
      type: String,
      enum: ['daily', 'weekly', 'monthly', 'any', 'none'],
      default: 'none'
    },
    requiredTier: {
      type: String,
      enum: ['FREE', 'PRO', 'ENTERPRISE', 'any', 'none'],
      default: 'none'
    }
  },
  
  // UI Configuration
  ui: {
    color: {
      type: String,
      default: '#6b7280'
    },
    icon: {
      type: String,
      default: 'UserIcon'
    },
    badge: {
      text: String,
      color: String,
      backgroundColor: String
    },
    dashboardLayout: String, // JSON string for custom dashboard
    menuItems: [String], // Custom menu configuration
    hideFromLists: {
      type: Boolean,
      default: false
    }
  },
  
  // Metadata
  metadata: {
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    tags: [String],
    notes: String,
    version: {
      type: Number,
      default: 1
    }
  }
}, {
  timestamps: true
});

// Indexes
// RoleSchema.index({ name: 1 }); // Removed: unique: true already creates index
RoleSchema.index({ level: -1 });
RoleSchema.index({ category: 1, isActive: 1 });
RoleSchema.index({ isDefault: 1 });

const Role = mongoose.model('Role', RoleSchema);

// ============================================
// 2. PERMISSION MODEL
// ============================================

const PermissionSchema = new mongoose.Schema({
  // Permission Identification
  name: {
    type: String,
    required: true,
    unique: true,
    trim: true,
    lowercase: true
  },
  
  displayName: {
    type: String,
    required: true,
    trim: true
  },
  
  description: {
    type: String,
    required: true,
    maxlength: 500
  },
  
  // Permission Organization
  category: {
    type: String,
    required: true,
    enum: [
      'users',           // User management
      'agents',          // AI agent management
      'subscriptions',   // Subscription management
      'billing',         // Billing and payments
      'support',         // Customer support
      'content',         // Content management
      'analytics',       // Analytics and reporting
      'settings',        // System settings
      'api',            // API access
      'security',       // Security operations
      'audit'           // Audit logs
    ]
  },
  
  resource: {
    type: String,
    required: true
    // Examples: 'user', 'agent', 'subscription', 'invoice', 'ticket'
  },
  
  action: {
    type: String,
    required: true,
    enum: [
      'create',
      'read',
      'update',
      'delete',
      'list',
      'search',
      'export',
      'import',
      'publish',
      'archive',
      'restore',
      'approve',
      'reject',
      'assign',
      'transfer',
      'execute',
      'manage'
    ]
  },
  
  // Permission Properties
  level: {
    type: String,
    required: true,
    enum: [
      'system',    // System-level operations
      'global',    // Global operations
      'owned',     // Own resources only
      'assigned',  // Assigned resources
      'team',      // Team resources
      'department' // Department resources
    ]
  },
  
  // Access Control
  conditions: [{
    field: String,        // Field to check
    operator: {
      type: String,
      enum: ['equals', 'not_equals', 'contains', 'not_contains', 'greater_than', 'less_than', 'in', 'not_in']
    },
    value: mongoose.Schema.Types.Mixed,
    description: String
  }],
  
  // Resource Restrictions
  restrictions: {
    fields: {
      allowed: [String],    // Specific fields allowed
      denied: [String]      // Specific fields denied
    },
    filters: {
      type: Map,
      of: mongoose.Schema.Types.Mixed
    },
    limits: {
      maxRecords: Number,   // Maximum records to return
      rateLimit: Number,    // Requests per minute
      dailyLimit: Number    // Daily operation limit
    }
  },
  
  // Permission Status
  isActive: {
    type: Boolean,
    default: true
  },
  
  isSystem: {
    type: Boolean,
    default: false // System permissions cannot be deleted
  },
  
  requiresApproval: {
    type: Boolean,
    default: false
  },
  
  // Risk Assessment
  riskLevel: {
    type: String,
    enum: ['low', 'medium', 'high', 'critical'],
    default: 'low'
  },
  
  // Audit Requirements
  audit: {
    logAccess: {
      type: Boolean,
      default: false
    },
    logChanges: {
      type: Boolean,
      default: false
    },
    requiresJustification: {
      type: Boolean,
      default: false
    },
    notifyOnUse: {
      type: Boolean,
      default: false
    },
    notifyEmails: [String]
  },
  
  // Dependencies
  dependencies: {
    requires: [{
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Permission'
    }],
    conflicts: [{
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Permission'
    }]
  },
  
  // UI Configuration
  ui: {
    group: String,        // Permission group for UI
    order: {
      type: Number,
      default: 0
    },
    icon: String,
    color: String,
    hideFromAssignment: {
      type: Boolean,
      default: false
    }
  },
  
  // Metadata
  metadata: {
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    tags: [String],
    notes: String,
    version: {
      type: Number,
      default: 1
    }
  }
}, {
  timestamps: true
});

// Indexes
// PermissionSchema.index({ name: 1 }); // Removed: unique: true already creates index
PermissionSchema.index({ category: 1, resource: 1, action: 1 });
PermissionSchema.index({ riskLevel: 1 });
PermissionSchema.index({ isActive: 1, isSystem: 1 });

const Permission = mongoose.model('Permission', PermissionSchema);

// ============================================
// 3. USER ROLE MODEL (Junction Table)
// ============================================

const UserRoleSchema = new mongoose.Schema({
  // User and Role Association
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  
  roleId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Role',
    required: true
  },
  
  // Assignment Details
  assignedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  
  assignedAt: {
    type: Date,
    default: Date.now,
    required: true
  },
  
  // Role Validity
  validFrom: {
    type: Date,
    default: Date.now
  },
  
  validUntil: {
    type: Date,
    default: null // null = permanent
  },
  
  // Status
  isActive: {
    type: Boolean,
    default: true
  },
  
  isTemporary: {
    type: Boolean,
    default: false
  },
  
  // Assignment Context
  context: {
    reason: {
      type: String,
      required: true,
      maxlength: 500
    },
    
    source: {
      type: String,
      enum: ['manual', 'automatic', 'api', 'import', 'upgrade', 'subscription'],
      default: 'manual'
    },
    
    department: String,
    team: String,
    project: String,
    
    // Conditional assignment
    conditions: [{
      type: String,
      value: mongoose.Schema.Types.Mixed,
      description: String
    }]
  },
  
  // Permission Overrides
  overrides: {
    // Additional permissions beyond role
    additionalPermissions: [{
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Permission'
    }],
    
    // Revoked permissions from role
    revokedPermissions: [{
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Permission'
    }],
    
    // Custom restrictions
    restrictions: {
      ipWhitelist: [String],
      timeRestrictions: {
        allowedHours: [{
          start: String,
          end: String
        }],
        timezone: String
      },
      dailyLimits: {
        type: Map,
        of: Number
      }
    }
  },
  
  // Approval Workflow
  approval: {
    status: {
      type: String,
      enum: ['pending', 'approved', 'rejected', 'auto_approved'],
      default: 'auto_approved'
    },
    
    approvedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    
    approvedAt: Date,
    
    rejectedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    
    rejectedAt: Date,
    
    rejectionReason: String,
    
    requestedAt: {
      type: Date,
      default: Date.now
    },
    
    approvalNotes: String
  },
  
  // Usage Tracking
  usage: {
    lastUsed: Date,
    usageCount: {
      type: Number,
      default: 0
    },
    
    // Permission usage breakdown
    permissionUsage: [{
      permissionId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Permission'
      },
      count: {
        type: Number,
        default: 0
      },
      lastUsed: Date
    }],
    
    // Activity metrics
    metrics: {
      loginCount: {
        type: Number,
        default: 0
      },
      actionsPerformed: {
        type: Number,
        default: 0
      },
      lastActivity: Date
    }
  },
  
  // Audit Trail
  audit: {
    changes: [{
      field: String,
      oldValue: mongoose.Schema.Types.Mixed,
      newValue: mongoose.Schema.Types.Mixed,
      changedBy: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
      },
      changedAt: {
        type: Date,
        default: Date.now
      },
      reason: String
    }],
    
    // Security events
    securityEvents: [{
      event: String,
      severity: {
        type: String,
        enum: ['low', 'medium', 'high', 'critical']
      },
      description: String,
      occurredAt: {
        type: Date,
        default: Date.now
      },
      ipAddress: String,
      userAgent: String
    }]
  },
  
  // Metadata
  metadata: {
    tags: [String],
    notes: String,
    customFields: {
      type: Map,
      of: mongoose.Schema.Types.Mixed
    },
    version: {
      type: Number,
      default: 1
    }
  }
}, {
  timestamps: true
});

// Compound indexes for performance
UserRoleSchema.index({ userId: 1, roleId: 1 }, { unique: true });
UserRoleSchema.index({ userId: 1, isActive: 1 });
UserRoleSchema.index({ roleId: 1, isActive: 1 });
UserRoleSchema.index({ assignedBy: 1, assignedAt: -1 });
UserRoleSchema.index({ validFrom: 1, validUntil: 1 });
UserRoleSchema.index({ 'approval.status': 1 });
UserRoleSchema.index({ 'context.source': 1 });

// Check if role assignment is currently valid
UserRoleSchema.methods.isCurrentlyValid = function() {
  const now = new Date();
  
  if (!this.isActive) return false;
  if (this.approval.status !== 'approved' && this.approval.status !== 'auto_approved') return false;
  if (this.validFrom > now) return false;
  if (this.validUntil && this.validUntil < now) return false;
  
  return true;
};

// Update usage statistics
UserRoleSchema.methods.recordUsage = function(permissionId = null) {
  this.usage.lastUsed = new Date();
  this.usage.usageCount += 1;
  
  if (permissionId) {
    const permUsage = this.usage.permissionUsage.find(
      p => p.permissionId.toString() === permissionId.toString()
    );
    
    if (permUsage) {
      permUsage.count += 1;
      permUsage.lastUsed = new Date();
    } else {
      this.usage.permissionUsage.push({
        permissionId: permissionId,
        count: 1,
        lastUsed: new Date()
      });
    }
  }
  
  return this.save();
};

const UserRole = mongoose.model('UserRole', UserRoleSchema);

// ============================================
// 4. ROLE PERMISSION MODEL (Junction Table)
// ============================================

const RolePermissionSchema = new mongoose.Schema({
  roleId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Role',
    required: true
  },
  
  permissionId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Permission',
    required: true
  },
  
  // Assignment metadata
  assignedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  
  assignedAt: {
    type: Date,
    default: Date.now
  },
  
  // Custom conditions for this role-permission combination
  conditions: [{
    field: String,
    operator: String,
    value: mongoose.Schema.Types.Mixed,
    description: String
  }],
  
  // Override permission settings for this role
  overrides: {
    restrictions: {
      fields: {
        allowed: [String],
        denied: [String]
      },
      limits: {
        maxRecords: Number,
        rateLimit: Number,
        dailyLimit: Number
      }
    }
  },
  
  isActive: {
    type: Boolean,
    default: true
  },
  
  metadata: {
    notes: String,
    tags: [String]
  }
}, {
  timestamps: true
});

// Indexes
RolePermissionSchema.index({ roleId: 1, permissionId: 1 }, { unique: true });
RolePermissionSchema.index({ roleId: 1, isActive: 1 });
RolePermissionSchema.index({ permissionId: 1, isActive: 1 });

const RolePermission = mongoose.model('RolePermission', RolePermissionSchema);

// Export RBAC models
module.exports = {
  Role,
  Permission,
  UserRole,
  RolePermission
};