// Complete Authentication Models for IAMAI Platform
// Signup, Signin, Password Reset, Email Verification, 2FA, Sessions

const mongoose = require('mongoose');
const { Schema } = mongoose;
const { UserSession } = require('./models');

// ============================================
// 1. USER AUTHENTICATION MODEL (Enhanced)
// ============================================

const UserAuthSchema = new Schema(
  {
    // Basic Info
    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
      match: [/^[^\s@]+@[^\s@]+\.[^\s@]+$/, 'Please enter a valid email'],
    },
    username: {
      type: String,
      unique: true,
      sparse: true,
      trim: true,
      minlength: 3,
      maxlength: 30,
    },

    // Password & Security
    password: {
      type: String,
      required: function () {
        return !this.oauth?.google?.id;
      }, // Not required for OAuth users
      minlength: 8,
    },
    passwordHistory: [
      {
        hash: String,
        createdAt: { type: Date, default: Date.now },
      },
    ], // Prevent password reuse

    // Profile Information
    profile: {
      firstName: String,
      lastName: String,
      displayName: String,
      avatar: String,
      bio: String,
      dateOfBirth: Date,
      phone: String,
      country: String,
      timezone: String,
      language: { type: String, default: 'en' },
    },

    // Account Status
    isActive: { type: Boolean, default: true },
    isEmailVerified: { type: Boolean, default: false },
    isPhoneVerified: { type: Boolean, default: false },
    isBanned: { type: Boolean, default: false },
    banReason: String,
    banExpiresAt: Date,

    // Account Type & Subscription
    accountType: {
      type: String,
      enum: ['FREE', 'PREMIUM', 'ENTERPRISE', 'ADMIN'],
      default: 'FREE',
    },
    subscription: {
      plan: { type: String, enum: ['NONE', 'DAILY', 'WEEKLY', 'MONTHLY'], default: 'NONE' },
      status: {
        type: String,
        enum: ['NONE', 'ACTIVE', 'CANCELLED', 'PAST_DUE', 'EXPIRED'],
        default: 'NONE',
      },
      startDate: Date,
      endDate: Date,
      autoRenew: { type: Boolean, default: true },
    },

    // OAuth Integration
    oauth: {
      google: {
        id: String,
        email: String,
        verified: Boolean,
        connectedAt: Date,
      },
      github: {
        id: String,
        username: String,
        connectedAt: Date,
      },
      discord: {
        id: String,
        username: String,
        connectedAt: Date,
      },
    },

    // Security Settings
    security: {
      twoFactorEnabled: { type: Boolean, default: false },
      twoFactorSecret: String,
      backupCodes: [String],
      lastPasswordChange: Date,
      passwordChangeRequired: { type: Boolean, default: false },
      suspiciousActivityDetected: { type: Boolean, default: false },
    },

    // Login Tracking
    loginHistory: [
      {
        timestamp: { type: Date, default: Date.now },
        ipAddress: String,
        userAgent: String,
        location: {
          country: String,
          city: String,
          coordinates: [Number], // [longitude, latitude]
        },
        successful: Boolean,
        failureReason: String,
      },
    ],

    // Preferences
    preferences: {
      notifications: {
        email: { type: Boolean, default: true },
        sms: { type: Boolean, default: false },
        push: { type: Boolean, default: true },
        marketing: { type: Boolean, default: true },
      },
      privacy: {
        profileVisibility: { type: String, enum: ['PUBLIC', 'PRIVATE'], default: 'PUBLIC' },
        showOnlineStatus: { type: Boolean, default: true },
        allowDataCollection: { type: Boolean, default: true },
      },
      ui: {
        theme: { type: String, enum: ['LIGHT', 'DARK', 'AUTO'], default: 'AUTO' },
        language: { type: String, default: 'en' },
        dateFormat: { type: String, default: 'MM/DD/YYYY' },
      },
    },

    // Timestamps & Metadata
    lastLoginAt: Date,
    lastActiveAt: Date,
    emailVerifiedAt: Date,
    phoneVerifiedAt: Date,
    metadata: { type: Schema.Types.Mixed, default: {} },
  },
  {
    timestamps: true,
    collection: 'user_auth',
  }
);

// Indexes for performance
// UserAuthSchema.index({ email: 1 }); // Removed: unique: true already creates index
// UserAuthSchema.index({ username: 1 }); // Removed: unique: true already creates index
UserAuthSchema.index({ 'oauth.google.id': 1 });
UserAuthSchema.index({ isActive: 1, isEmailVerified: 1 });
UserAuthSchema.index({ lastLoginAt: -1 });
UserAuthSchema.index({ createdAt: -1 });

// UserAuth model is defined in main models.js to avoid conflicts
// const UserAuth = mongoose.model('UserAuth', UserAuthSchema);

// ============================================
// 2. PASSWORD RESET TOKENS
// ============================================

const PasswordResetTokenSchema = new Schema(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'UserAuth',
      required: true,
    },
    email: {
      type: String,
      required: true,
      lowercase: true,
    },
    token: {
      type: String,
      required: true,
      unique: true,
    },
    tokenHash: {
      type: String,
      required: true,
    },
    expiresAt: {
      type: Date,
      required: true,
      default: () => new Date(Date.now() + 60 * 60 * 1000), // 1 hour
    },
    isUsed: {
      type: Boolean,
      default: false,
    },
    usedAt: Date,
    ipAddress: String,
    userAgent: String,
    attempts: {
      type: Number,
      default: 0,
    },
    maxAttempts: {
      type: Number,
      default: 3,
    },
  },
  {
    timestamps: true,
    collection: 'password_reset_tokens',
  }
);

// Auto-delete expired tokens
PasswordResetTokenSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 });
PasswordResetTokenSchema.index({ userId: 1 });
// PasswordResetTokenSchema.index({ token: 1 }); // Removed: unique: true already creates index

const PasswordResetToken = mongoose.model('PasswordResetToken', PasswordResetTokenSchema);

// ============================================
// 3. EMAIL VERIFICATION TOKENS
// ============================================

const EmailVerificationTokenSchema = new Schema(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'UserAuth',
      required: true,
    },
    email: {
      type: String,
      required: true,
      lowercase: true,
    },
    token: {
      type: String,
      required: true,
      unique: true,
    },
    tokenHash: {
      type: String,
      required: true,
    },
    expiresAt: {
      type: Date,
      required: true,
      default: () => new Date(Date.now() + 24 * 60 * 60 * 1000), // 24 hours
    },
    isUsed: {
      type: Boolean,
      default: false,
    },
    usedAt: Date,
    ipAddress: String,
    userAgent: String,
    resendCount: {
      type: Number,
      default: 0,
    },
    maxResends: {
      type: Number,
      default: 5,
    },
  },
  {
    timestamps: true,
    collection: 'email_verification_tokens',
  }
);

// Auto-delete expired tokens
EmailVerificationTokenSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 });
EmailVerificationTokenSchema.index({ userId: 1 });
EmailVerificationTokenSchema.index({ email: 1 });

const EmailVerificationToken = mongoose.model(
  'EmailVerificationToken',
  EmailVerificationTokenSchema
);

// ============================================
// 4. USER SESSIONS
// ============================================

// UserSession model is defined in models/UserSession.js to avoid conflicts
// This consolidates all session tracking into a single comprehensive model

// ============================================
// 5. FAILED LOGIN ATTEMPTS (Security)
// ============================================

const FailedLoginAttemptSchema = new Schema(
  {
    email: {
      type: String,
      lowercase: true,
      trim: true,
    },
    ipAddress: {
      type: String,
      required: true,
    },
    userAgent: String,
    attemptCount: {
      type: Number,
      default: 1,
    },
    lastAttemptAt: {
      type: Date,
      default: Date.now,
    },
    isBlocked: {
      type: Boolean,
      default: false,
    },
    blockedUntil: Date,
    location: {
      country: String,
      city: String,
    },
  },
  {
    timestamps: true,
    collection: 'failed_login_attempts',
  }
);

// Auto-delete old attempts after 24 hours
FailedLoginAttemptSchema.index({ createdAt: 1 }, { expireAfterSeconds: 86400 });
FailedLoginAttemptSchema.index({ email: 1 });
FailedLoginAttemptSchema.index({ ipAddress: 1 });

const FailedLoginAttempt = mongoose.model('FailedLoginAttempt', FailedLoginAttemptSchema);

// ============================================
// 6. TWO-FACTOR AUTHENTICATION
// ============================================

const TwoFactorAuthSchema = new Schema(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'UserAuth',
      required: true,
      unique: true,
    },
    method: {
      type: String,
      enum: ['TOTP', 'SMS', 'EMAIL'],
      default: 'TOTP',
    },
    secret: {
      type: String,
      required: true,
    },
    backupCodes: [
      {
        code: String,
        isUsed: { type: Boolean, default: false },
        usedAt: Date,
      },
    ],
    isEnabled: {
      type: Boolean,
      default: false,
    },
    enabledAt: Date,
    lastUsedAt: Date,

    // Phone for SMS 2FA
    phoneNumber: String,
    phoneVerified: { type: Boolean, default: false },

    // Recovery
    recoveryEmail: String,
  },
  {
    timestamps: true,
    collection: 'two_factor_auth',
  }
);

TwoFactorAuthSchema.index({ userId: 1 });

// TwoFactorAuth model is defined in main models.js to avoid conflicts
// const TwoFactorAuth = mongoose.model('TwoFactorAuth', TwoFactorAuthSchema);

// ============================================
// 7. ACCOUNT ACTIVITY LOG
// ============================================

const AccountActivitySchema = new Schema(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'UserAuth',
      required: true,
    },
    action: {
      type: String,
      required: true,
      enum: [
        'SIGNUP',
        'LOGIN',
        'LOGOUT',
        'PASSWORD_CHANGE',
        'PASSWORD_RESET_REQUEST',
        'PASSWORD_RESET_COMPLETE',
        'EMAIL_VERIFICATION',
        'PROFILE_UPDATE',
        'SECURITY_SETTINGS_CHANGE',
        '2FA_ENABLED',
        '2FA_DISABLED',
        'ACCOUNT_DEACTIVATED',
      ],
    },
    details: {
      type: Schema.Types.Mixed,
      default: {},
    },
    ipAddress: String,
    userAgent: String,
    location: {
      country: String,
      city: String,
    },
    success: {
      type: Boolean,
      default: true,
    },
    errorMessage: String,
  },
  {
    timestamps: true,
    collection: 'account_activity',
  }
);

AccountActivitySchema.index({ userId: 1, createdAt: -1 });
AccountActivitySchema.index({ action: 1 });

const AccountActivity = mongoose.model('AccountActivity', AccountActivitySchema);

// ============================================
// EXPORT ALL MODELS
// ============================================

module.exports = {
  // UserAuth, // Defined in main models.js
  PasswordResetToken,
  EmailVerificationToken,
  // UserSession, // Defined in models/UserSession.js to avoid conflicts
  FailedLoginAttempt,
  // TwoFactorAuth, // Defined in main models.js
  AccountActivity,
};
