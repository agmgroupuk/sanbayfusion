// Activate pending purchases that have valid Stripe sessions
require("dotenv").config();
const mongoose = require("mongoose");
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

async function activatePendingPurchases() {
  try {
    console.log("🔌 Connecting to MongoDB...");
    await mongoose.connect(process.env.MONGODB_URI);
    console.log("✅ Connected\n");
    
    const db = mongoose.connection.db;
    
    // Find all PENDING purchases
    const pendingPurchases = await db.collection("agent_purchases").find({
      status: { $in: ["PENDING", "pending"] }
    }).toArray();
    
    console.log(`📦 Found ${pendingPurchases.length} PENDING purchases\n`);
    
    for (const purchase of pendingPurchases) {
      const sessionId = purchase.stripeCheckoutSessionId;
      
      if (!sessionId) {
        console.log(`⚠️ Purchase ${purchase._id} has no session ID, skipping`);
        continue;
      }
      
      try {
        // Check Stripe session status
        const session = await stripe.checkout.sessions.retrieve(sessionId);
        
        console.log(`🔍 Purchase ${purchase._id}:`);
        console.log(`   Agent: ${purchase.agentId}`);
        console.log(`   Session: ${sessionId}`);
        console.log(`   Payment Status: ${session.payment_status}`);
        console.log(`   Session Status: ${session.status}`);
        
        if (session.payment_status === 'paid') {
          // Calculate new expiration if needed
          const planType = purchase.plan || purchase.planType?.toUpperCase() || 'DAILY';
          const purchaseDate = purchase.purchaseDate || new Date();
          
          let durationMs;
          switch (planType) {
            case 'DAILY':
              durationMs = 24 * 60 * 60 * 1000; // 1 day
              break;
            case 'WEEKLY':
              durationMs = 7 * 24 * 60 * 60 * 1000; // 7 days
              break;
            case 'MONTHLY':
              durationMs = 30 * 24 * 60 * 60 * 1000; // 30 days
              break;
            default:
              durationMs = 24 * 60 * 60 * 1000;
          }
          
          const expiresAt = new Date(purchaseDate.getTime() + durationMs);
          
          // Update to ACTIVE
          await db.collection("agent_purchases").updateOne(
            { _id: purchase._id },
            {
              $set: {
                status: 'ACTIVE',
                paymentStatus: 'SUCCESS',
                stripeCustomerId: session.customer,
                expiresAt: expiresAt,
                metadata: {
                  ...(purchase.metadata || {}),
                  source: 'stripe_checkout',
                  activated_manually: true,
                  activated_at: new Date().toISOString()
                }
              }
            }
          );
          
          console.log(`   ✅ ACTIVATED! Expires: ${expiresAt.toISOString()}\n`);
        } else if (session.status === 'expired') {
          // Mark as CANCELLED if session expired
          await db.collection("agent_purchases").updateOne(
            { _id: purchase._id },
            {
              $set: {
                status: 'CANCELLED',
                paymentStatus: 'FAILED',
                metadata: {
                  ...(purchase.metadata || {}),
                  cancelled_reason: 'checkout_session_expired'
                }
              }
            }
          );
          console.log(`   ⏰ Session expired, marked as CANCELLED\n`);
        } else {
          console.log(`   ⏳ Payment not completed yet (status: ${session.payment_status})\n`);
        }
        
      } catch (stripeError) {
        console.log(`   ❌ Stripe error: ${stripeError.message}\n`);
      }
    }
    
    // Show final counts
    const active = await db.collection("agent_purchases").countDocuments({ status: { $in: ["ACTIVE", "active"] } });
    const pending = await db.collection("agent_purchases").countDocuments({ status: { $in: ["PENDING", "pending"] } });
    const cancelled = await db.collection("agent_purchases").countDocuments({ status: { $in: ["CANCELLED", "cancelled"] } });
    
    console.log("\n📊 Final Status:");
    console.log(`   ACTIVE: ${active}`);
    console.log(`   PENDING: ${pending}`);
    console.log(`   CANCELLED: ${cancelled}`);
    
    process.exit(0);
  } catch (error) {
    console.error("❌ Error:", error);
    process.exit(1);
  }
}

activatePendingPurchases();
