/**
 * 🚦 Advanced Rate Limiting Configuration
 * Sophisticated rate limiting with different tiers and burst handling
 */

const rateLimit = require('express-rate-limit');
const { rateLimitConfigs } = require('./validation-middleware');

// Create rate limiters with different configurations
const createRateLimiter = config => {
  return rateLimit({
    windowMs: config.windowMs,
    max: config.max,
    message: config.message,
    standardHeaders: true,
    legacyHeaders: false,
    // Add custom key generator for user-based limiting
    keyGenerator: req => {
      // Use user ID if authenticated, otherwise IP
      return req.user?.id || req.ip;
    },
    // Skip rate limiting for certain conditions
    skip: req => {
      // Skip for health checks
      if (req.path === '/api/health/status') return true;
      // Skip for admin users (if implemented)
      if (req.user?.role === 'admin') return true;
      return false;
    },
    // Custom handler for rate limit exceeded
    handler: (req, res) => {
      res.status(429).json({
        success: false,
        error: config.message.error,
        retryAfter: config.message.retryAfter,
        limit: config.max,
        windowMs: config.windowMs,
      });
    },
  });
};

// Rate limiters for different endpoint types
const rateLimiters = {
  // General API endpoints
  general: createRateLimiter(rateLimitConfigs.general),

  // Authentication endpoints (stricter limits)
  auth: createRateLimiter(rateLimitConfigs.auth),

  // Chat endpoints (higher limits for active users)
  chat: createRateLimiter(rateLimitConfigs.chat),

  // File upload endpoints
  uploads: createRateLimiter(rateLimitConfigs.uploads),

  // API key endpoints
  apiKeys: createRateLimiter(rateLimitConfigs.apiKeys),

  // Admin endpoints (higher limits for admins)
  admin: rateLimit({
    windowMs: 60 * 1000, // 1 minute
    max: 1000, // 1000 requests per minute for admins
    message: {
      success: false,
      error: 'Admin rate limit exceeded',
      retryAfter: 60,
    },
    standardHeaders: true,
    legacyHeaders: false,
    skip: req => req.user?.role !== 'admin',
  }),

  // Health check endpoints (no limits)
  health: rateLimit({
    windowMs: 60 * 1000,
    max: 1000, // Very high limit for health checks
    message: 'Health check rate limit exceeded',
    skip: req => req.path.startsWith('/api/health/'),
  }),
};

// Middleware to apply appropriate rate limiting based on route
const applyRateLimiting = (req, res, next) => {
  const path = req.path;

  // Apply specific rate limiting based on path patterns
  if (path.startsWith('/api/auth/')) {
    return rateLimiters.auth(req, res, next);
  }

  if (path.startsWith('/api/chat/')) {
    return rateLimiters.chat(req, res, next);
  }

  if (path.startsWith('/api/files/upload')) {
    return rateLimiters.uploads(req, res, next);
  }

  if (path.startsWith('/api/api-keys/')) {
    return rateLimiters.apiKeys(req, res, next);
  }

  if (path.startsWith('/api/admin/')) {
    return rateLimiters.admin(req, res, next);
  }

  if (path.startsWith('/api/health/')) {
    return rateLimiters.health(req, res, next);
  }

  // Default to general rate limiting
  return rateLimiters.general(req, res, next);
};

// Export rate limiters and middleware
module.exports = {
  rateLimiters,
  applyRateLimiting,
  createRateLimiter,
};
