/**
 * 🗄️ Database Query Optimization
 * Optimized queries with proper indexing and caching
 */

const mongoose = require('mongoose');

// Database indexes for performance
const createIndexes = async () => {
  try {
    const db = mongoose.connection.db;

    // User collection indexes
    await db.collection('users').createIndexes([
      { key: { email: 1 }, options: { unique: true } },
      { key: { stripeCustomerId: 1 }, options: { sparse: true } },
      { key: { currentPlan: 1 } },
      { key: { subscriptionStatus: 1 } },
      { key: { createdAt: -1 } },
      { key: { lastLogin: -1 } },
      // Compound indexes for common queries
      { key: { email: 1, subscriptionStatus: 1 } },
      { key: { currentPlan: 1, createdAt: -1 } },
    ]);

    // Chat collection indexes
    await db
      .collection('chats')
      .createIndexes([
        { key: { userId: 1, createdAt: -1 } },
        { key: { sessionId: 1, createdAt: -1 } },
        { key: { agentId: 1, createdAt: -1 } },
        { key: { userId: 1, agentId: 1, createdAt: -1 } },
      ]);

    // Subscription collection indexes
    await db
      .collection('subscriptions')
      .createIndexes([
        { key: { userId: 1, status: 1 } },
        { key: { providerSubscriptionId: 1 }, options: { unique: true, sparse: true } },
        { key: { status: 1, currentPeriodEnd: 1 } },
        { key: { userId: 1, createdAt: -1 } },
      ]);

    // Analytics collection indexes
    await db
      .collection('analytics')
      .createIndexes([
        { key: { userId: 1, date: -1 } },
        { key: { agentId: 1, date: -1 } },
        { key: { type: 1, date: -1 } },
        { key: { userId: 1, agentId: 1, date: -1 } },
      ]);

    // Activity logs indexes
    await db.collection('activitylogs').createIndexes([
      { key: { userId: 1, timestamp: -1 } },
      { key: { action: 1, timestamp: -1 } },
      { key: { sessionId: 1, timestamp: -1 } },
      // TTL index for automatic cleanup (30 days)
      { key: { timestamp: 1 }, options: { expireAfterSeconds: 30 * 24 * 60 * 60 } },
    ]);

    console.log('✅ Database indexes created successfully');
  } catch (error) {
    console.error('❌ Error creating database indexes:', error);
  }
};

// Optimized query functions
const optimizedQueries = {
  // Get user with subscription data
  getUserWithSubscription: async userId => {
    return await mongoose.connection.db
      .collection('users')
      .aggregate([
        {
          $match: { _id: new mongoose.Types.ObjectId(userId) },
        },
        {
          $lookup: {
            from: 'subscriptions',
            localField: '_id',
            foreignField: 'userId',
            as: 'subscriptions',
            pipeline: [
              { $match: { status: { $in: ['ACTIVE', 'TRIALING'] } } },
              { $sort: { createdAt: -1 } },
              { $limit: 1 },
            ],
          },
        },
        {
          $lookup: {
            from: 'analytics',
            localField: '_id',
            foreignField: 'userId',
            as: 'usage',
            pipeline: [
              {
                $match: {
                  date: {
                    $gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000), // Last 30 days
                  },
                },
              },
              {
                $group: {
                  _id: null,
                  totalMessages: { $sum: '$data.messagesSent' },
                  totalTokens: { $sum: '$data.tokensUsed' },
                },
              },
            ],
          },
        },
      ])
      .toArray();
  },

  // Get chat history with pagination
  getChatHistory: async (userId, page = 1, limit = 20) => {
    const skip = (page - 1) * limit;

    const chats = await mongoose.connection.db
      .collection('chats')
      .find({ userId: new mongoose.Types.ObjectId(userId) })
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit)
      .toArray();

    const total = await mongoose.connection.db
      .collection('chats')
      .countDocuments({ userId: new mongoose.Types.ObjectId(userId) });

    return {
      chats,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    };
  },

  // Get dashboard analytics
  getDashboardAnalytics: async userId => {
    const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);

    return await mongoose.connection.db
      .collection('analytics')
      .aggregate([
        {
          $match: {
            userId: new mongoose.Types.ObjectId(userId),
            date: { $gte: thirtyDaysAgo },
          },
        },
        {
          $group: {
            _id: {
              $dateToString: { format: '%Y-%m-%d', date: '$date' },
            },
            messagesSent: { $sum: '$data.messagesSent' },
            tokensUsed: { $sum: '$data.tokensUsed' },
            apiCalls: { $sum: '$data.apiCalls' },
          },
        },
        {
          $sort: { _id: 1 },
        },
      ])
      .toArray();
  },

  // Bulk operations for better performance
  bulkUpdateUsage: async updates => {
    const bulkOps = updates.map(update => ({
      updateOne: {
        filter: { userId: update.userId, date: update.date },
        update: {
          $inc: {
            'data.messagesSent': update.messagesSent || 0,
            'data.tokensUsed': update.tokensUsed || 0,
            'data.apiCalls': update.apiCalls || 0,
          },
        },
        upsert: true,
      },
    }));

    return await mongoose.connection.db
      .collection('analytics')
      .bulkWrite(bulkOps, { ordered: false });
  },
};

// Connection optimization
const optimizeConnection = () => {
  mongoose.set('bufferCommands', false);
  mongoose.set('maxTimeMS', 30000);

  // Connection pool settings
  const connectionOptions = {
    maxPoolSize: 10,
    serverSelectionTimeoutMS: 5000,
    socketTimeoutMS: 45000,
    bufferMaxEntries: 0,
    bufferCommands: false,
    maxIdleTimeMS: 30000,
    family: 4, // Use IPv4
  };

  return connectionOptions;
};

module.exports = {
  createIndexes,
  optimizedQueries,
  optimizeConnection,
};

// Run if called directly
if (require.main === module) {
  const { connectDB } = require('./database');

  connectDB()
    .then(async () => {
      try {
        console.log('🚀 Applying database optimizations...');
        await createIndexes();
        console.log('✅ Database indexes created successfully');
        process.exit(0);
      } catch (error) {
        console.error('❌ Database optimization failed:', error);
        process.exit(1);
      }
    })
    .catch(error => {
      console.error('❌ Database connection failed:', error);
      process.exit(1);
    });
}
