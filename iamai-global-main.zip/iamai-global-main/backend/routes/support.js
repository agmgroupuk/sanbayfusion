// Support Management Routes
// Complete customer support and ticketing system

const express = require('express');
const { SupportTicket, TicketResponse, TicketAttachment, SupportTeam } = require('../support-models');
const { User } = require('../models');
const { authenticate, requireTier, validateFields } = require('../auth-middleware');

const router = express.Router();

// ============================================
// SUPPORT TICKET ROUTES
// ============================================

/**
 * POST /api/support/tickets
 * Create a new support ticket
 */
router.post('/tickets', authenticate, validateFields(['subject', 'description', 'category']), async (req, res) => {
  try {
    const { subject, description, category, priority, tags } = req.body;

    const ticket = new SupportTicket({
      userId: req.userId,
      subject,
      description,
      category,
      priority: priority || 'medium',
      tags: tags || [],
      submissionDetails: {
        source: 'web_portal',
        ipAddress: req.ip,
        userAgent: req.get('User-Agent'),
        timestamp: new Date()
      }
    });

    await ticket.save();
    await ticket.populate('userId', 'name email');

    res.json({
      success: true,
      data: ticket,
      message: 'Support ticket created successfully'
    });

  } catch (error) {
    console.error('Ticket creation error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to create support ticket',
      message: error.message
    });
  }
});

/**
 * GET /api/support/tickets/user
 * Get user's support tickets
 */
router.get('/tickets/user', authenticate, async (req, res) => {
  try {
    const { page = 1, limit = 20, status, category } = req.query;
    const skip = (page - 1) * limit;
    
    const query = { userId: req.userId };
    if (status) query.status = status;
    if (category) query.category = category;

    const tickets = await SupportTicket.find(query)
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit))
      .populate('assignedTo', 'name email')
      .select('-internalNotes');

    const total = await SupportTicket.countDocuments(query);

    res.json({
      success: true,
      data: {
        tickets,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total,
          pages: Math.ceil(total / limit)
        }
      }
    });

  } catch (error) {
    console.error('User tickets fetch error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve tickets',
      message: error.message
    });
  }
});

/**
 * GET /api/support/tickets/:ticketId
 * Get specific ticket details
 */
router.get('/tickets/:ticketId', authenticate, async (req, res) => {
  try {
    const ticket = await SupportTicket.findOne({
      _id: req.params.ticketId,
      userId: req.userId
    }).populate('userId', 'name email')
      .populate('assignedTo', 'name email')
      .select('-internalNotes');

    if (!ticket) {
      return res.status(404).json({
        success: false,
        error: 'Ticket not found'
      });
    }

    // Get ticket responses
    const responses = await TicketResponse.find({
      ticketId: ticket._id
    }).sort({ createdAt: 1 })
      .populate('authorId', 'name email')
      .select('-internalNotes');

    res.json({
      success: true,
      data: {
        ticket,
        responses
      }
    });

  } catch (error) {
    console.error('Ticket fetch error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve ticket',
      message: error.message
    });
  }
});

/**
 * PUT /api/support/tickets/:ticketId
 * Update ticket (user can only update certain fields)
 */
router.put('/tickets/:ticketId', authenticate, async (req, res) => {
  try {
    const { priority, tags } = req.body;
    
    const updateData = {};
    if (priority) updateData.priority = priority;
    if (tags) updateData.tags = tags;
    updateData.lastUpdated = new Date();

    const ticket = await SupportTicket.findOneAndUpdate(
      {
        _id: req.params.ticketId,
        userId: req.userId
      },
      updateData,
      { new: true }
    ).populate('userId', 'name email')
      .populate('assignedTo', 'name email');

    if (!ticket) {
      return res.status(404).json({
        success: false,
        error: 'Ticket not found'
      });
    }

    res.json({
      success: true,
      data: ticket,
      message: 'Ticket updated successfully'
    });

  } catch (error) {
    console.error('Ticket update error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to update ticket',
      message: error.message
    });
  }
});

// ============================================
// TICKET RESPONSE ROUTES
// ============================================

/**
 * POST /api/support/tickets/:ticketId/responses
 * Add response to ticket
 */
router.post('/tickets/:ticketId/responses', authenticate, validateFields(['message']), async (req, res) => {
  try {
    const { message, attachmentIds } = req.body;

    // Verify ticket exists and user has access
    const ticket = await SupportTicket.findOne({
      _id: req.params.ticketId,
      userId: req.userId
    });

    if (!ticket) {
      return res.status(404).json({
        success: false,
        error: 'Ticket not found'
      });
    }

    const response = new TicketResponse({
      ticketId: ticket._id,
      authorId: req.userId,
      authorType: 'customer',
      message,
      attachments: attachmentIds || [],
      metadata: {
        source: 'web_portal',
        ipAddress: req.ip,
        userAgent: req.get('User-Agent')
      }
    });

    await response.save();
    await response.populate('authorId', 'name email');

    // Update ticket last activity
    ticket.lastActivity = new Date();
    ticket.lastResponseBy = req.userId;
    ticket.lastResponseAt = new Date();
    if (ticket.status === 'waiting_for_customer') {
      ticket.status = 'in_progress';
    }
    await ticket.save();

    res.json({
      success: true,
      data: response,
      message: 'Response added successfully'
    });

  } catch (error) {
    console.error('Response creation error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to add response',
      message: error.message
    });
  }
});

// ============================================
// TICKET ATTACHMENT ROUTES
// ============================================

/**
 * POST /api/support/attachments
 * Upload ticket attachment
 */
router.post('/attachments', authenticate, async (req, res) => {
  try {
    const { filename, fileUrl, fileSize, mimeType, ticketId, responseId } = req.body;

    const attachment = new TicketAttachment({
      ticketId,
      responseId,
      uploadedBy: req.userId,
      filename,
      fileUrl,
      fileSize,
      mimeType,
      uploadInfo: {
        source: 'web_upload',
        ipAddress: req.ip,
        userAgent: req.get('User-Agent')
      }
    });

    await attachment.save();

    res.json({
      success: true,
      data: attachment,
      message: 'Attachment uploaded successfully'
    });

  } catch (error) {
    console.error('Attachment upload error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to upload attachment',
      message: error.message
    });
  }
});

/**
 * GET /api/support/attachments/:attachmentId
 * Get attachment details
 */
router.get('/attachments/:attachmentId', authenticate, async (req, res) => {
  try {
    const attachment = await TicketAttachment.findById(req.params.attachmentId)
      .populate('ticketId', 'userId')
      .populate('uploadedBy', 'name email');

    if (!attachment) {
      return res.status(404).json({
        success: false,
        error: 'Attachment not found'
      });
    }

    // Check if user has access to this attachment
    if (attachment.ticketId.userId.toString() !== req.userId && !req.user.isAdmin) {
      return res.status(403).json({
        success: false,
        error: 'Access denied'
      });
    }

    res.json({
      success: true,
      data: attachment
    });

  } catch (error) {
    console.error('Attachment fetch error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve attachment',
      message: error.message
    });
  }
});

// ============================================
// SUPPORT AGENT ROUTES
// ============================================

/**
 * GET /api/support/agent/tickets
 * Agent: Get assigned tickets
 */
router.get('/agent/tickets', authenticate, requireTier(['support_agent', 'admin']), async (req, res) => {
  try {
    const { page = 1, limit = 20, status, priority } = req.query;
    const skip = (page - 1) * limit;
    
    const query = { assignedTo: req.userId };
    if (status) query.status = status;
    if (priority) query.priority = priority;

    const tickets = await SupportTicket.find(query)
      .sort({ priority: -1, createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit))
      .populate('userId', 'name email')
      .populate('assignedTo', 'name email');

    const total = await SupportTicket.countDocuments(query);

    res.json({
      success: true,
      data: {
        tickets,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total,
          pages: Math.ceil(total / limit)
        }
      }
    });

  } catch (error) {
    console.error('Agent tickets fetch error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve assigned tickets',
      message: error.message
    });
  }
});

/**
 * PUT /api/support/agent/tickets/:ticketId/assign
 * Agent: Assign ticket to themselves or another agent
 */
router.put('/agent/tickets/:ticketId/assign', authenticate, requireTier(['support_agent', 'admin']), async (req, res) => {
  try {
    const { assignedTo } = req.body;

    const ticket = await SupportTicket.findByIdAndUpdate(
      req.params.ticketId,
      {
        assignedTo: assignedTo || req.userId,
        status: 'in_progress',
        assignedAt: new Date(),
        lastUpdated: new Date()
      },
      { new: true }
    ).populate('userId', 'name email')
      .populate('assignedTo', 'name email');

    if (!ticket) {
      return res.status(404).json({
        success: false,
        error: 'Ticket not found'
      });
    }

    res.json({
      success: true,
      data: ticket,
      message: 'Ticket assigned successfully'
    });

  } catch (error) {
    console.error('Ticket assignment error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to assign ticket',
      message: error.message
    });
  }
});

/**
 * PUT /api/support/agent/tickets/:ticketId/status
 * Agent: Update ticket status
 */
router.put('/agent/tickets/:ticketId/status', authenticate, requireTier(['support_agent', 'admin']), async (req, res) => {
  try {
    const { status, resolution } = req.body;

    const updateData = {
      status,
      lastUpdated: new Date()
    };

    if (status === 'resolved' || status === 'closed') {
      updateData.resolvedAt = new Date();
      updateData.resolvedBy = req.userId;
      if (resolution) updateData.resolution = resolution;
    }

    const ticket = await SupportTicket.findByIdAndUpdate(
      req.params.ticketId,
      updateData,
      { new: true }
    ).populate('userId', 'name email')
      .populate('assignedTo', 'name email')
      .populate('resolvedBy', 'name email');

    if (!ticket) {
      return res.status(404).json({
        success: false,
        error: 'Ticket not found'
      });
    }

    res.json({
      success: true,
      data: ticket,
      message: 'Ticket status updated successfully'
    });

  } catch (error) {
    console.error('Ticket status update error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to update ticket status',
      message: error.message
    });
  }
});

// ============================================
// ADMIN ROUTES
// ============================================

/**
 * GET /api/support/admin/tickets
 * Admin: Get all tickets
 */
router.get('/admin/tickets', authenticate, requireTier(['admin']), async (req, res) => {
  try {
    const { page = 1, limit = 50, status, category, priority } = req.query;
    const skip = (page - 1) * limit;
    
    const query = {};
    if (status) query.status = status;
    if (category) query.category = category;
    if (priority) query.priority = priority;

    const tickets = await SupportTicket.find(query)
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit))
      .populate('userId', 'name email')
      .populate('assignedTo', 'name email');

    const total = await SupportTicket.countDocuments(query);

    res.json({
      success: true,
      data: {
        tickets,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total,
          pages: Math.ceil(total / limit)
        }
      }
    });

  } catch (error) {
    console.error('Admin tickets fetch error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve tickets',
      message: error.message
    });
  }
});

/**
 * GET /api/support/admin/stats
 * Admin: Get support statistics
 */
router.get('/admin/stats', authenticate, requireTier(['admin']), async (req, res) => {
  try {
    const totalTickets = await SupportTicket.countDocuments();
    const openTickets = await SupportTicket.countDocuments({ status: { $in: ['open', 'in_progress'] } });
    const resolvedTickets = await SupportTicket.countDocuments({ status: 'resolved' });
    const avgResponseTime = await SupportTicket.aggregate([
      { $match: { firstResponseAt: { $exists: true } } },
      { $project: { responseTime: { $subtract: ['$firstResponseAt', '$createdAt'] } } },
      { $group: { _id: null, avgResponseTime: { $avg: '$responseTime' } } }
    ]);

    res.json({
      success: true,
      data: {
        totalTickets,
        openTickets,
        resolvedTickets,
        avgResponseTime: avgResponseTime[0]?.avgResponseTime || 0,
        responseTimeHours: avgResponseTime[0] ? (avgResponseTime[0].avgResponseTime / (1000 * 60 * 60)).toFixed(2) : 0
      }
    });

  } catch (error) {
    console.error('Support stats error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve support statistics',
      message: error.message
    });
  }
});

module.exports = router;