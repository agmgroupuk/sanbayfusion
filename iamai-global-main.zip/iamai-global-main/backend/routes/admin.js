// Admin Dashboard Routes
// Complete admin interface for managing all platform content

const express = require('express');
const models = require('../models/index.js');
const { User, Agent, Chat } = models;
const { 
  BlogPost, Faq, Documentation, Tutorial, Template, News, 
  AboutSection, TeamMember, JobPosting, Partner, LegalDocument, Report, 
  DeveloperResource, EducationContent, SystemStatus, 
  ChatSession, Reward, UserReward, ChatMessage, 
  TicketResponse, TicketAttachment
} = require('../content-models.js');
const { authenticate, requireTier } = require('../auth-middleware.js');

const router = express.Router();

// Middleware to ensure admin access
const requireAdmin = async (req, res, next) => {
  try {
    const user = await User.findById(req.userId);
    if (!user || user.tier !== 'ADMIN') {
      return res.status(403).json({
        success: false,
        error: 'Admin access required'
      });
    }
    req.adminUser = user;
    next();
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Failed to verify admin access',
      message: error.message
    });
  }
};

// Apply admin middleware to all routes
router.use(authenticate);
router.use(requireAdmin);

// ============================================
// DASHBOARD OVERVIEW
// ============================================

/**
 * GET /api/admin/dashboard
 * Get comprehensive dashboard overview
 */
router.get('/dashboard', async (req, res) => {
  try {
    const [
      // User Statistics
      totalUsers,
      activeUsers,
      newUsersThisMonth,
      
      // Content Statistics
      totalBlogPosts,
      totalFAQs,
      totalTutorials,
      totalNews,
      
      // System Statistics
      totalChats,
      totalAgents,
      pendingContacts,
      systemStatus,
      
      // Recent Activity
      recentUsers,
      recentContacts,
      recentBlogPosts
    ] = await Promise.all([
      // User counts
      User.countDocuments(),
      User.countDocuments({ 
        lastLoginAt: { $gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) }
      }),
      User.countDocuments({ 
        createdAt: { $gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) }
      }),
      
      // Content counts
      BlogPost.countDocuments({ status: 'published' }),
      FAQ.countDocuments({ status: 'published' }),
      Tutorial.countDocuments({ status: 'published' }),
      News.countDocuments({ status: 'published' }),
      
      // System counts
      Chat.countDocuments(),
      Agent.countDocuments(),
      ContactSubmission.countDocuments({ status: 'pending' }),
      SystemStatus.findOne().sort({ createdAt: -1 }),
      
      // Recent activity
      User.find().sort({ createdAt: -1 }).limit(5).select('email tier createdAt'),
      ContactSubmission.find().sort({ createdAt: -1 }).limit(5).select('name email subject type priority status createdAt'),
      BlogPost.find({ status: 'published' }).sort({ publishedAt: -1 }).limit(5).select('title slug publishedAt')
    ]);

    res.json({
      success: true,
      data: {
        overview: {
          users: {
            total: totalUsers,
            active: activeUsers,
            newThisMonth: newUsersThisMonth,
            growthRate: totalUsers > 0 ? ((newUsersThisMonth / totalUsers) * 100).toFixed(1) : 0
          },
          content: {
            blogPosts: totalBlogPosts,
            faqs: totalFAQs,
            tutorials: totalTutorials,
            news: totalNews
          },
          system: {
            chats: totalChats,
            agents: totalAgents,
            pendingContacts: pendingContacts,
            systemHealth: systemStatus?.status || 'unknown'
          }
        },
        recentActivity: {
          users: recentUsers,
          contacts: recentContacts,
          blogPosts: recentBlogPosts
        },
        lastUpdated: new Date().toISOString()
      }
    });

  } catch (error) {
    console.error('Admin dashboard error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to load dashboard',
      message: error.message
    });
  }
});

// ============================================
// USER MANAGEMENT
// ============================================

/**
 * GET /api/admin/users
 * Get all users with pagination and filters
 */
router.get('/users', async (req, res) => {
  try {
    const {
      page = 1,
      limit = 20,
      tier,
      status,
      search,
      sortBy = 'createdAt',
      sortOrder = 'desc'
    } = req.query;

    // Build query
    const query = {};
    if (tier) query.tier = tier;
    if (status === 'active') {
      query.lastLoginAt = { $gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) };
    }
    if (search) {
      query.$or = [
        { email: { $regex: search, $options: 'i' } },
        { firstName: { $regex: search, $options: 'i' } },
        { lastName: { $regex: search, $options: 'i' } }
      ];
    }

    const skip = (page - 1) * limit;
    const sort = { [sortBy]: sortOrder === 'desc' ? -1 : 1 };

    const [users, total] = await Promise.all([
      User.find(query)
        .select('-password')
        .sort(sort)
        .skip(skip)
        .limit(parseInt(limit)),
      User.countDocuments(query)
    ]);

    res.json({
      success: true,
      data: {
        users,
        pagination: {
          current: parseInt(page),
          total: Math.ceil(total / limit),
          count: users.length,
          totalRecords: total
        }
      }
    });

  } catch (error) {
    console.error('Admin users list error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve users',
      message: error.message
    });
  }
});

/**
 * PUT /api/admin/users/:userId/tier
 * Update user tier
 */
router.put('/users/:userId/tier', async (req, res) => {
  try {
    const { tier } = req.body;
    
    if (!['NONE', 'DAILY', 'WEEKLY', 'MONTHLY', 'PRO', 'ENTERPRISE', 'ADMIN'].includes(tier)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid tier value'
      });
    }

    const user = await User.findById(req.params.userId);
    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User not found'
      });
    }

    user.tier = tier;
    await user.save();

    res.json({
      success: true,
      message: 'User tier updated successfully',
      data: {
        userId: user._id,
        email: user.email,
        tier: user.tier
      }
    });

  } catch (error) {
    console.error('User tier update error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to update user tier',
      message: error.message
    });
  }
});

// ============================================
// CONTENT MANAGEMENT
// ============================================

/**
 * GET /api/admin/content/stats
 * Get content statistics across all types
 */
router.get('/content/stats', async (req, res) => {
  try {
    const [
      blogStats,
      faqStats,
      tutorialStats,
      newsStats,
      documentationStats,
      teamStats,
      jobStats
    ] = await Promise.all([
      BlogPost.aggregate([
        { $group: { _id: '$status', count: { $sum: 1 } } }
      ]),
      FAQ.aggregate([
        { $group: { _id: '$status', count: { $sum: 1 } } }
      ]),
      Tutorial.aggregate([
        { $group: { _id: '$status', count: { $sum: 1 } } }
      ]),
      News.aggregate([
        { $group: { _id: '$status', count: { $sum: 1 } } }
      ]),
      Documentation.aggregate([
        { $group: { _id: '$status', count: { $sum: 1 } } }
      ]),
      Team.countDocuments({ isActive: true }),
      Jobs.countDocuments({ isActive: true })
    ]);

    const formatStats = (stats) => {
      return stats.reduce((acc, item) => {
        acc[item._id] = item.count;
        return acc;
      }, {});
    };

    res.json({
      success: true,
      data: {
        blogPosts: formatStats(blogStats),
        faqs: formatStats(faqStats),
        tutorials: formatStats(tutorialStats),
        news: formatStats(newsStats),
        documentation: formatStats(documentationStats),
        team: { active: teamStats },
        jobs: { active: jobStats }
      }
    });

  } catch (error) {
    console.error('Content stats error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve content statistics',
      message: error.message
    });
  }
});

// ============================================
// SYSTEM MANAGEMENT
// ============================================

/**
 * GET /api/admin/system/health
 * Get detailed system health information
 */
router.get('/system/health', async (req, res) => {
  try {
    const [
      dbStats,
      userGrowth,
      contentActivity,
      systemErrors
    ] = await Promise.all([
      // Database statistics
      User.countDocuments(),
      
      // User growth over time (last 7 days)
      User.aggregate([
        {
          $match: {
            createdAt: { $gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) }
          }
        },
        {
          $group: {
            _id: {
              $dateToString: {
                format: "%Y-%m-%d",
                date: "$createdAt"
              }
            },
            count: { $sum: 1 }
          }
        },
        { $sort: { _id: 1 } }
      ]),
      
      // Content creation activity
      BlogPost.aggregate([
        {
          $match: {
            createdAt: { $gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) }
          }
        },
        {
          $group: {
            _id: null,
            count: { $sum: 1 }
          }
        }
      ]),
      
      // Recent system status
      SystemStatus.findOne().sort({ createdAt: -1 })
    ]);

    res.json({
      success: true,
      data: {
        database: {
          status: 'connected',
          totalUsers: dbStats,
          uptime: process.uptime()
        },
        growth: {
          userSignups: userGrowth,
          contentCreated: contentActivity[0]?.count || 0
        },
        system: {
          status: systemErrors?.status || 'operational',
          lastCheck: systemErrors?.createdAt || new Date(),
          memoryUsage: process.memoryUsage(),
          nodeVersion: process.version
        }
      }
    });

  } catch (error) {
    console.error('System health error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve system health',
      message: error.message
    });
  }
});

/**
 * POST /api/admin/system/status
 * Update system status
 */
router.post('/system/status', async (req, res) => {
  try {
    const { status, message, maintenanceMode = false } = req.body;

    if (!['operational', 'degraded', 'maintenance', 'down'].includes(status)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid status value'
      });
    }

    const systemStatus = new SystemStatus({
      status,
      message,
      maintenanceMode,
      updatedBy: req.userId
    });

    await systemStatus.save();

    res.json({
      success: true,
      message: 'System status updated successfully',
      data: {
        status: systemStatus.status,
        message: systemStatus.message,
        maintenanceMode: systemStatus.maintenanceMode,
        updatedAt: systemStatus.createdAt
      }
    });

  } catch (error) {
    console.error('System status update error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to update system status',
      message: error.message
    });
  }
});

// ============================================
// QUICK ACTIONS
// ============================================

/**
 * GET /api/admin/quick-stats
 * Get quick statistics for admin header/sidebar
 */
router.get('/quick-stats', async (req, res) => {
  try {
    const [
      pendingContacts,
      newUsers,
      draftContent,
      systemAlerts
    ] = await Promise.all([
      ContactSubmission.countDocuments({ status: 'pending' }),
      User.countDocuments({ 
        createdAt: { $gte: new Date(Date.now() - 24 * 60 * 60 * 1000) }
      }),
      BlogPost.countDocuments({ status: 'draft' }),
      SystemStatus.findOne({ status: { $ne: 'operational' } }).sort({ createdAt: -1 })
    ]);

    res.json({
      success: true,
      data: {
        pendingContacts,
        newUsers,
        draftContent,
        hasSystemAlerts: !!systemAlerts
      }
    });

  } catch (error) {
    console.error('Quick stats error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve quick statistics',
      message: error.message
    });
  }
});

module.exports = router;