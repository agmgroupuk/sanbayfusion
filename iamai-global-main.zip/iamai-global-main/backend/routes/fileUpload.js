// File Upload Routes with AWS S3 Integration
// Handles file uploads for the IAMAI platform

const express = require('express');
const multer = require('multer');
const AWS = require('aws-sdk');
const path = require('path');
const crypto = require('crypto');
const { FileUpload } = require('../models');
const { authenticate } = require('../auth-middleware');

const router = express.Router();

// Configure AWS S3
const s3 = new AWS.S3({
  accessKeyId: process.env.AWS_ACCESS_KEY_ID,
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  region: process.env.AWS_REGION || 'us-east-1'
});

const BUCKET_NAME = process.env.S3_BUCKET_NAME || 'iamai-uploads';

// Configure multer for memory storage
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    // Allowed file types
    const allowedTypes = [
      'image/jpeg',
      'image/png',
      'image/gif',
      'image/webp',
      'application/pdf',
      'text/plain',
      'text/csv',
      'application/json',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    ];

    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type'), false);
    }
  }
});

// Helper function to generate unique filename
const generateFileName = (originalName) => {
  const timestamp = Date.now();
  const randomString = crypto.randomBytes(8).toString('hex');
  const extension = path.extname(originalName);
  return `${timestamp}-${randomString}${extension}`;
};

// Helper function to upload to S3
const uploadToS3 = async (file, fileName, folder = 'general') => {
  const params = {
    Bucket: BUCKET_NAME,
    Key: `${folder}/${fileName}`,
    Body: file.buffer,
    ContentType: file.mimetype,
    ACL: 'private' // Files are private by default
  };

  return s3.upload(params).promise();
};

// Helper function to generate signed URL
const getSignedUrl = (s3Key, expiresIn = 3600) => {
  const params = {
    Bucket: BUCKET_NAME,
    Key: s3Key,
    Expires: expiresIn
  };

  return s3.getSignedUrl('getObject', params);
};

// ============================================
// ROUTES
// ============================================

/**
 * POST /api/files/upload
 * Upload a single file
 */
router.post('/upload', authenticate, upload.single('file'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        error: 'No file provided'
      });
    }

    const { folder = 'general', isPublic = false } = req.body;
    const fileName = generateFileName(req.file.originalname);
    
    // Upload to S3
    const s3Result = await uploadToS3(req.file, fileName, folder);
    
    // Save file metadata to database
    const fileUpload = new FileUpload({
      userId: req.userId,
      filename: fileName,
      originalName: req.file.originalname,
      mimeType: req.file.mimetype,
      size: req.file.size,
      url: s3Result.Location,
      s3Key: s3Result.Key,
      s3Bucket: BUCKET_NAME,
      metadata: {
        folder,
        isPublic: isPublic === 'true',
        uploadedFrom: req.headers['user-agent'] || 'Unknown'
      }
    });

    await fileUpload.save();

    res.json({
      success: true,
      data: {
        id: fileUpload._id,
        filename: fileUpload.filename,
        originalName: fileUpload.originalName,
        size: fileUpload.size,
        mimeType: fileUpload.mimeType,
        url: isPublic === 'true' ? s3Result.Location : null,
        uploadedAt: fileUpload.createdAt
      }
    });

  } catch (error) {
    console.error('File upload error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to upload file',
      message: error.message
    });
  }
});

/**
 * POST /api/files/upload/multiple
 * Upload multiple files
 */
router.post('/upload/multiple', authenticate, upload.array('files', 5), async (req, res) => {
  try {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        success: false,
        error: 'No files provided'
      });
    }

    const { folder = 'general', isPublic = false } = req.body;
    const uploadPromises = [];
    const fileRecords = [];

    // Process each file
    for (const file of req.files) {
      const fileName = generateFileName(file.originalname);
      
      // Upload to S3
      const uploadPromise = uploadToS3(file, fileName, folder)
        .then(async (s3Result) => {
          // Save to database
          const fileUpload = new FileUpload({
            userId: req.userId,
            filename: fileName,
            originalName: file.originalname,
            mimeType: file.mimetype,
            size: file.size,
            url: s3Result.Location,
            s3Key: s3Result.Key,
            s3Bucket: BUCKET_NAME,
            metadata: {
              folder,
              isPublic: isPublic === 'true',
              uploadedFrom: req.headers['user-agent'] || 'Unknown'
            }
          });

          await fileUpload.save();
          fileRecords.push(fileUpload);
          return fileUpload;
        });

      uploadPromises.push(uploadPromise);
    }

    // Wait for all uploads to complete
    await Promise.all(uploadPromises);

    res.json({
      success: true,
      data: {
        files: fileRecords.map(file => ({
          id: file._id,
          filename: file.filename,
          originalName: file.originalName,
          size: file.size,
          mimeType: file.mimeType,
          url: file.metadata.isPublic ? file.url : null,
          uploadedAt: file.createdAt
        })),
        totalUploaded: fileRecords.length
      }
    });

  } catch (error) {
    console.error('Multiple file upload error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to upload files',
      message: error.message
    });
  }
});

/**
 * GET /api/files/:fileId
 * Get file metadata and signed URL
 */
router.get('/:fileId', authenticate, async (req, res) => {
  try {
    const file = await FileUpload.findById(req.params.fileId);

    if (!file) {
      return res.status(404).json({
        success: false,
        error: 'File not found'
      });
    }

    // Check if user owns the file or if it's public
    if (file.userId.toString() !== req.userId && !file.metadata?.isPublic) {
      return res.status(403).json({
        success: false,
        error: 'Access denied'
      });
    }

    // Generate signed URL for private files
    let downloadUrl = file.url;
    if (!file.metadata?.isPublic) {
      downloadUrl = getSignedUrl(file.s3Key);
    }

    res.json({
      success: true,
      data: {
        id: file._id,
        filename: file.filename,
        originalName: file.originalName,
        size: file.size,
        mimeType: file.mimeType,
        downloadUrl,
        uploadedAt: file.createdAt,
        metadata: file.metadata
      }
    });

  } catch (error) {
    console.error('File retrieval error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve file',
      message: error.message
    });
  }
});

/**
 * GET /api/files/user/list
 * Get user's uploaded files
 */
router.get('/user/list', authenticate, async (req, res) => {
  try {
    const { page = 1, limit = 20, folder, mimeType } = req.query;
    
    const query = { userId: req.userId };
    
    if (folder) query['metadata.folder'] = folder;
    if (mimeType) query.mimeType = new RegExp(mimeType, 'i');

    const files = await FileUpload.find(query)
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await FileUpload.countDocuments(query);

    res.json({
      success: true,
      data: {
        files: files.map(file => ({
          id: file._id,
          filename: file.filename,
          originalName: file.originalName,
          size: file.size,
          mimeType: file.mimeType,
          uploadedAt: file.createdAt,
          folder: file.metadata?.folder || 'general'
        })),
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total,
          pages: Math.ceil(total / limit)
        }
      }
    });

  } catch (error) {
    console.error('File list error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve files',
      message: error.message
    });
  }
});

/**
 * DELETE /api/files/:fileId
 * Delete a file
 */
router.delete('/:fileId', authenticate, async (req, res) => {
  try {
    const file = await FileUpload.findById(req.params.fileId);

    if (!file) {
      return res.status(404).json({
        success: false,
        error: 'File not found'
      });
    }

    // Check if user owns the file
    if (file.userId.toString() !== req.userId) {
      return res.status(403).json({
        success: false,
        error: 'Access denied'
      });
    }

    // Delete from S3
    try {
      await s3.deleteObject({
        Bucket: BUCKET_NAME,
        Key: file.s3Key
      }).promise();
    } catch (s3Error) {
      console.error('S3 deletion error:', s3Error);
      // Continue with database deletion even if S3 fails
    }

    // Delete from database
    await FileUpload.findByIdAndDelete(req.params.fileId);

    res.json({
      success: true,
      message: 'File deleted successfully'
    });

  } catch (error) {
    console.error('File deletion error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to delete file',
      message: error.message
    });
  }
});

/**
 * GET /api/files/stats
 * Get file upload statistics for user
 */
router.get('/user/stats', authenticate, async (req, res) => {
  try {
    const totalFiles = await FileUpload.countDocuments({ userId: req.userId });
    
    const sizeResult = await FileUpload.aggregate([
      { $match: { userId: req.userId } },
      { $group: { _id: null, totalSize: { $sum: '$size' } } }
    ]);

    const totalSize = sizeResult[0]?.totalSize || 0;

    const typeStats = await FileUpload.aggregate([
      { $match: { userId: req.userId } },
      { $group: { _id: '$mimeType', count: { $sum: 1 }, size: { $sum: '$size' } } },
      { $sort: { count: -1 } }
    ]);

    res.json({
      success: true,
      data: {
        totalFiles,
        totalSize,
        averageSize: totalFiles > 0 ? Math.round(totalSize / totalFiles) : 0,
        typeBreakdown: typeStats.map(stat => ({
          mimeType: stat._id,
          count: stat.count,
          size: stat.size
        }))
      }
    });

  } catch (error) {
    console.error('File stats error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve file statistics',
      message: error.message
    });
  }
});

module.exports = router;