// Plans Management Routes
// Complete subscription plans CRUD operations

const express = require('express');
const { Plan } = require('../critical-models');
const { User } = require('../models');
const { authenticate, requireTier } = require('../auth-middleware');

const router = express.Router();

// ============================================
// PUBLIC ROUTES (NO AUTH REQUIRED)
// ============================================

/**
 * GET /api/plans
 * Get all active subscription plans (public)
 */
router.get('/', async (req, res) => {
  try {
    const plans = await Plan.find({ 
      isActive: true 
    }).sort({ sortOrder: 1 }).select('-stripePriceId -metadata');

    res.json({
      success: true,
      data: plans
    });

  } catch (error) {
    console.error('Plans fetch error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve plans',
      message: error.message
    });
  }
});

/**
 * GET /api/plans/:planName
 * Get specific plan details (public)
 */
router.get('/:planName', async (req, res) => {
  try {
    const plan = await Plan.findOne({ 
      name: req.params.planName.toLowerCase(),
      isActive: true 
    }).select('-stripePriceId');

    if (!plan) {
      return res.status(404).json({
        success: false,
        error: 'Plan not found'
      });
    }

    res.json({
      success: true,
      data: plan
    });

  } catch (error) {
    console.error('Plan fetch error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve plan',
      message: error.message
    });
  }
});

/**
 * GET /api/plans/compare/all
 * Get plan comparison data (public)
 */
router.get('/compare/all', async (req, res) => {
  try {
    const plans = await Plan.find({ 
      isActive: true 
    }).sort({ sortOrder: 1 });

    // Format for comparison table
    const comparison = {
      plans: plans.map(plan => ({
        name: plan.name,
        displayName: plan.displayName,
        description: plan.description,
        price: plan.price,
        isPopular: plan.isPopular
      })),
      features: {}
    };

    // Extract all unique features
    const allFeatures = new Set();
    plans.forEach(plan => {
      plan.features.forEach(feature => {
        allFeatures.add(feature.name);
      });
      Object.keys(plan.limits).forEach(limit => {
        allFeatures.add(limit);
      });
    });

    // Build feature comparison matrix
    Array.from(allFeatures).forEach(featureName => {
      comparison.features[featureName] = {};
      plans.forEach(plan => {
        const feature = plan.features.find(f => f.name === featureName);
        const limit = plan.limits[featureName];
        
        comparison.features[featureName][plan.name] = {
          included: feature ? feature.included : (limit !== undefined),
          limit: feature ? feature.limit : limit,
          description: feature ? feature.description : null
        };
      });
    });

    res.json({
      success: true,
      data: comparison
    });

  } catch (error) {
    console.error('Plans comparison error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve plan comparison',
      message: error.message
    });
  }
});

// ============================================
// USER ROUTES (AUTH REQUIRED)
// ============================================

/**
 * GET /api/plans/user/recommendations
 * Get plan recommendations for current user
 */
router.get('/user/recommendations', authenticate, async (req, res) => {
  try {
    const user = await User.findById(req.userId);
    const plans = await Plan.find({ isActive: true }).sort({ sortOrder: 1 });

    // Simple recommendation logic based on user's current usage
    let recommendedPlan = null;
    
    if (user.tier === 'NONE') {
      // Recommend PRO if user is active
      const proPlans = plans.filter(p => p.name.includes('pro'));
      if (proPlans.length > 0) {
        recommendedPlan = proPlans[0];
      }
    } else if (user.tier === 'PRO') {
      // Recommend ENTERPRISE if user has high usage
      const enterprisePlans = plans.filter(p => p.name.includes('enterprise'));
      if (enterprisePlans.length > 0) {
        recommendedPlan = enterprisePlans[0];
      }
    }

    res.json({
      success: true,
      data: {
        currentTier: user.tier,
        recommendedPlan: recommendedPlan,
        allPlans: plans.map(plan => ({
          ...plan.toObject(),
          isCurrent: plan.name.toUpperCase() === user.tier,
          isRecommended: recommendedPlan && plan._id.equals(recommendedPlan._id)
        }))
      }
    });

  } catch (error) {
    console.error('Plan recommendations error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to get plan recommendations',
      message: error.message
    });
  }
});

// ============================================
// ADMIN ROUTES (ADMIN ACCESS REQUIRED)
// ============================================

// Admin middleware
const requireAdmin = async (req, res, next) => {
  try {
    const user = await User.findById(req.userId);
    if (!user || user.tier !== 'ADMIN') {
      return res.status(403).json({
        success: false,
        error: 'Admin access required'
      });
    }
    next();
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Failed to verify admin access'
    });
  }
};

/**
 * GET /api/plans/admin/all
 * Get all plans including inactive (admin only)
 */
router.get('/admin/all', authenticate, requireAdmin, async (req, res) => {
  try {
    const plans = await Plan.find().sort({ sortOrder: 1, createdAt: -1 });

    res.json({
      success: true,
      data: plans
    });

  } catch (error) {
    console.error('Admin plans fetch error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve plans',
      message: error.message
    });
  }
});

/**
 * POST /api/plans/admin
 * Create new plan (admin only)
 */
router.post('/admin', authenticate, requireAdmin, async (req, res) => {
  try {
    const {
      name,
      displayName,
      description,
      price,
      features = [],
      limits = {},
      stripePriceId,
      isPopular = false,
      sortOrder = 0,
      metadata = {}
    } = req.body;

    // Validation
    if (!name || !displayName || !description || !price) {
      return res.status(400).json({
        success: false,
        error: 'Missing required fields',
        required: ['name', 'displayName', 'description', 'price']
      });
    }

    // Check for duplicate name
    const existingPlan = await Plan.findOne({ name: name.toLowerCase() });
    if (existingPlan) {
      return res.status(409).json({
        success: false,
        error: 'Plan with this name already exists'
      });
    }

    // Create plan
    const plan = new Plan({
      name: name.toLowerCase(),
      displayName,
      description,
      price,
      features,
      limits: {
        maxAgents: 1,
        maxChatsPerMonth: 100,
        maxTokensPerMonth: 10000,
        maxFileUploads: 10,
        maxStorageGB: 1,
        maxApiKeys: 2,
        maxTeamMembers: 1,
        advancedAnalytics: false,
        prioritySupport: false,
        customBranding: false,
        ...limits
      },
      stripePriceId,
      isPopular,
      sortOrder,
      metadata
    });

    await plan.save();

    res.status(201).json({
      success: true,
      message: 'Plan created successfully',
      data: plan
    });

  } catch (error) {
    console.error('Plan creation error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to create plan',
      message: error.message
    });
  }
});

/**
 * PUT /api/plans/admin/:planId
 * Update plan (admin only)
 */
router.put('/admin/:planId', authenticate, requireAdmin, async (req, res) => {
  try {
    const plan = await Plan.findById(req.params.planId);
    
    if (!plan) {
      return res.status(404).json({
        success: false,
        error: 'Plan not found'
      });
    }

    // Update allowed fields
    const allowedFields = [
      'displayName', 'description', 'price', 'features', 'limits',
      'stripePriceId', 'isActive', 'isPopular', 'sortOrder', 'metadata'
    ];

    allowedFields.forEach(field => {
      if (req.body[field] !== undefined) {
        plan[field] = req.body[field];
      }
    });

    await plan.save();

    res.json({
      success: true,
      message: 'Plan updated successfully',
      data: plan
    });

  } catch (error) {
    console.error('Plan update error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to update plan',
      message: error.message
    });
  }
});

/**
 * DELETE /api/plans/admin/:planId
 * Delete plan (admin only) - soft delete by setting isActive to false
 */
router.delete('/admin/:planId', authenticate, requireAdmin, async (req, res) => {
  try {
    const plan = await Plan.findById(req.params.planId);
    
    if (!plan) {
      return res.status(404).json({
        success: false,
        error: 'Plan not found'
      });
    }

    // Soft delete - don't actually remove, just deactivate
    plan.isActive = false;
    await plan.save();

    res.json({
      success: true,
      message: 'Plan deactivated successfully'
    });

  } catch (error) {
    console.error('Plan deletion error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to delete plan',
      message: error.message
    });
  }
});

/**
 * GET /api/plans/admin/stats
 * Get plan statistics (admin only)
 */
router.get('/admin/stats', authenticate, requireAdmin, async (req, res) => {
  try {
    const [
      totalPlans,
      activePlans,
      usersByTier
    ] = await Promise.all([
      Plan.countDocuments(),
      Plan.countDocuments({ isActive: true }),
      User.aggregate([
        { $group: { _id: '$tier', count: { $sum: 1 } } }
      ])
    ]);

    const tierStats = usersByTier.reduce((acc, item) => {
      acc[item._id] = item.count;
      return acc;
    }, {});

    res.json({
      success: true,
      data: {
        plans: {
          total: totalPlans,
          active: activePlans,
          inactive: totalPlans - activePlans
        },
        users: tierStats,
        popularTier: Object.keys(tierStats).reduce((a, b) => 
          tierStats[a] > tierStats[b] ? a : b, 'NONE'
        )
      }
    });

  } catch (error) {
    console.error('Plan stats error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve plan statistics',
      message: error.message
    });
  }
});

module.exports = router;