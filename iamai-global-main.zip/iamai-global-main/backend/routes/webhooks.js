// Webhook Management Routes
// Webhook logging, endpoint management and API integration tracking

const express = require('express');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const { WebhookLog, WebhookEndpoint } = require('../webhook-models');
const { User, ActivityLog } = require('../models');
const { AgentPurchase } = require('../agent-purchase-models');
const { authenticate, requireTier, validateFields } = require('../auth-middleware');
const { TrackingService } = require('../middleware/universal-tracking');

const router = express.Router();

// ============================================
// WEBHOOK LOG ROUTES
// ============================================

/**
 * GET /api/webhooks/logs
 * Get webhook logs (admin only)
 */
router.get('/logs', authenticate, requireTier(['admin', 'support_agent']), async (req, res) => {
  try {
    const { page = 1, limit = 50, source, status, eventType } = req.query;
    const skip = (page - 1) * limit;
    
    const query = {};
    if (source) query['event.source'] = source;
    if (status) query['processing.status'] = status;
    if (eventType) query['event.type'] = eventType;

    const logs = await WebhookLog.find(query)
      .sort({ 'request.receivedAt': -1 })
      .skip(skip)
      .limit(parseInt(limit))
      .select('-request.body.raw -response.body.raw -debug.logs')
      .populate('related.userId', 'email name')
      .populate('source.endpoint', 'name url');

    const total = await WebhookLog.countDocuments(query);

    res.json({
      success: true,
      data: {
        logs,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total,
          pages: Math.ceil(total / limit)
        }
      }
    });

  } catch (error) {
    console.error('Webhook logs fetch error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve webhook logs',
      message: error.message
    });
  }
});

/**
 * GET /api/webhooks/logs/:logId
 * Get specific webhook log details
 */
router.get('/logs/:logId', authenticate, requireTier(['admin', 'support_agent']), async (req, res) => {
  try {
    const log = await WebhookLog.findById(req.params.logId)
      .populate('related.userId', 'email name')
      .populate('source.endpoint', 'name url');

    if (!log) {
      return res.status(404).json({
        success: false,
        error: 'Webhook log not found'
      });
    }

    res.json({
      success: true,
      data: log
    });

  } catch (error) {
    console.error('Webhook log fetch error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve webhook log',
      message: error.message
    });
  }
});

/**
 * POST /api/webhooks/logs/:logId/retry
 * Retry failed webhook processing
 */
router.post('/logs/:logId/retry', authenticate, requireTier(['admin']), async (req, res) => {
  try {
    const log = await WebhookLog.findById(req.params.logId);

    if (!log) {
      return res.status(404).json({
        success: false,
        error: 'Webhook log not found'
      });
    }

    if (log.processing.status === 'completed') {
      return res.status(400).json({
        success: false,
        error: 'Webhook already processed successfully'
      });
    }

    // Reset processing status for retry
    log.processing.status = 'pending';
    log.processing.retry.attempt += 1;
    log.processing.retry.nextAttemptAt = new Date();
    log.request.processingStartedAt = new Date();
    
    await log.save();

    res.json({
      success: true,
      data: log,
      message: 'Webhook queued for retry'
    });

  } catch (error) {
    console.error('Webhook retry error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retry webhook',
      message: error.message
    });
  }
});

// ============================================
// WEBHOOK ENDPOINT ROUTES
// ============================================

/**
 * GET /api/webhooks/endpoints
 * Get webhook endpoints (admin only)
 */
router.get('/endpoints', authenticate, requireTier(['admin']), async (req, res) => {
  try {
    const endpoints = await WebhookEndpoint.find()
      .sort({ createdAt: -1 })
      .populate('metadata.createdBy', 'name email');

    res.json({
      success: true,
      data: endpoints
    });

  } catch (error) {
    console.error('Webhook endpoints fetch error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve webhook endpoints',
      message: error.message
    });
  }
});

/**
 * POST /api/webhooks/endpoints
 * Create new webhook endpoint (admin only)
 */
router.post('/endpoints', authenticate, requireTier(['admin']), validateFields(['name', 'url', 'events']), async (req, res) => {
  try {
    const { name, description, url, events, security } = req.body;

    const endpoint = new WebhookEndpoint({
      name,
      description,
      url,
      events,
      security: security || { authMethod: 'none' },
      metadata: {
        createdBy: req.userId,
        environment: process.env.NODE_ENV || 'development'
      }
    });

    await endpoint.save();

    res.json({
      success: true,
      data: endpoint,
      message: 'Webhook endpoint created successfully'
    });

  } catch (error) {
    console.error('Webhook endpoint creation error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to create webhook endpoint',
      message: error.message
    });
  }
});

/**
 * PUT /api/webhooks/endpoints/:endpointId
 * Update webhook endpoint (admin only)
 */
router.put('/endpoints/:endpointId', authenticate, requireTier(['admin']), async (req, res) => {
  try {
    const { name, description, url, events, security, isActive } = req.body;

    const endpoint = await WebhookEndpoint.findByIdAndUpdate(
      req.params.endpointId,
      {
        name,
        description,
        url,
        events,
        security,
        isActive,
        'metadata.updatedBy': req.userId
      },
      { new: true }
    );

    if (!endpoint) {
      return res.status(404).json({
        success: false,
        error: 'Webhook endpoint not found'
      });
    }

    res.json({
      success: true,
      data: endpoint,
      message: 'Webhook endpoint updated successfully'
    });

  } catch (error) {
    console.error('Webhook endpoint update error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to update webhook endpoint',
      message: error.message
    });
  }
});

/**
 * DELETE /api/webhooks/endpoints/:endpointId
 * Delete webhook endpoint (admin only)
 */
router.delete('/endpoints/:endpointId', authenticate, requireTier(['admin']), async (req, res) => {
  try {
    const endpoint = await WebhookEndpoint.findByIdAndUpdate(
      req.params.endpointId,
      { isActive: false },
      { new: true }
    );

    if (!endpoint) {
      return res.status(404).json({
        success: false,
        error: 'Webhook endpoint not found'
      });
    }

    res.json({
      success: true,
      message: 'Webhook endpoint deactivated successfully'
    });

  } catch (error) {
    console.error('Webhook endpoint deletion error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to delete webhook endpoint',
      message: error.message
    });
  }
});

// ============================================
// STRIPE CHECKOUT WEBHOOK (AGENT PURCHASES)
// ============================================

/**
 * POST /api/webhooks/stripe/checkout
 * Stripe Checkout webhook to create one-time AgentPurchase records
 * Now includes signature verification for security
 * NOTE: Raw body parsing is handled globally in production-server.js
 */
router.post('/stripe/checkout', async (req, res) => {
  const sig = req.headers['stripe-signature'];
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

  try {
    const event = stripe.webhooks.constructEvent(req.body, sig, webhookSecret);

    console.log('[Stripe Checkout Webhook] Received event type:', event.type);

    if (event.type !== 'checkout.session.completed') {
      console.log('[Stripe Checkout Webhook] Ignoring event type:', event.type);
      return res.json({ received: true, ignored: true });
    }

    const session = event.data.object;

    const userId = session.client_reference_id || session.metadata?.userId;
    const agentId = session.metadata?.agentId;
    const planType = session.metadata?.planType;

    console.log('[Stripe Checkout Webhook] Processing webhook:', {
      eventType: event.type,
      sessionId: session.id,
      userId,
      agentId,
      planType,
      customerEmail: session.customer_details?.email,
    });

    if (!userId || !agentId || !planType) {
      console.error('[Stripe Checkout Webhook] Missing metadata:', {
        userId,
        agentId,
        planType,
      });
      return res.status(400).send('Missing required metadata');
    }

    // Look up user for email
    const user = await User.findById(userId);
    if (!user) {
      console.error('[Stripe Checkout Webhook] User not found for purchase:', userId);
      return res.status(400).send('User not found');
    }

    const normalizedPlan = planType.toString().toUpperCase();

    // Try to find existing PENDING purchase created at checkout
    let purchase = await AgentPurchase.findOne({
      stripeCheckoutSessionId: session.id,
      status: 'PENDING',
    });

    if (purchase) {
      // Update existing PENDING purchase to ACTIVE
      purchase.status = 'ACTIVE';
      purchase.paymentStatus = 'SUCCESS';
      purchase.stripeCustomerId = session.customer;
      purchase.metadata = {
        ...(purchase.metadata || {}),
        ...(session.metadata || {}),
        source: 'stripe_checkout',
        webhook_received: new Date().toISOString(),
      };
      await purchase.save();
      
      // Log the purchase activity
      try {
        await ActivityLog.create({
          userId: userId,
          sessionId: `purchase_${purchase._id}`,
          action: 'AGENT_PURCHASED',
          route: '/api/webhooks/stripe/checkout',
          method: 'POST',
          statusCode: 200,
          metadata: {
            agentId: agentId,
            agentName: purchase.agentName || agentId,
            plan: purchase.plan,
            purchaseId: purchase._id.toString(),
            amount: purchase.pricing?.amount || 0,
            source: 'stripe_webhook'
          },
          isAnonymous: false
        });
        console.log('[ACTIVITY] AGENT_PURCHASED logged via webhook for user:', userId);
      } catch (logError) {
        console.error('[ACTIVITY] Failed to log AGENT_PURCHASED:', logError);
      }
      
      // ============================================
      // RECORD TRANSACTION (Professional Tracking!)
      // ============================================
      try {
        await TrackingService.recordTransaction({
          userId: userId,
          type: 'AGENT_PURCHASE',
          amount: purchase.pricing?.amount || 0,
          currency: 'USD',
          status: 'COMPLETED',
          stripePaymentIntentId: session.payment_intent,
          stripeCheckoutSessionId: session.id,
          stripeCustomerId: session.customer,
          metadata: {
            agentId: agentId,
            agentName: purchase.agentName || agentId,
            plan: purchase.plan,
            purchaseId: purchase._id.toString(),
            email: user.email,
            source: 'stripe_checkout_webhook',
          },
        });
        console.log('[TRANSACTION] Recorded for user:', userId, 'amount:', purchase.pricing?.amount);
      } catch (txError) {
        console.error('[TRANSACTION] Failed to record:', txError.message);
      }
      
      // ============================================
      // RECORD WEBHOOK EVENT (Professional Tracking!)
      // ============================================
      try {
        await TrackingService.recordWebhookEvent({
          source: 'stripe',
          eventType: event.type,
          eventId: event.id,
          payload: {
            sessionId: session.id,
            userId: userId,
            agentId: agentId,
            plan: purchase.plan,
            amount: purchase.pricing?.amount,
          },
          status: 'PROCESSED',
          processingTime: Date.now() - new Date(event.created * 1000).getTime(),
          relatedUserId: userId,
          relatedPurchaseId: purchase._id,
        });
        console.log('[WEBHOOK_EVENT] Recorded stripe event:', event.id);
      } catch (whError) {
        console.error('[WEBHOOK_EVENT] Failed to record:', whError.message);
      }
      
      // ============================================
      // UPDATE USER DOCUMENT (Sync user status!)
      // ============================================
      try {
        const activeCount = await AgentPurchase.countDocuments({
          userId: userId,
          status: { $in: ['ACTIVE', 'active'] },
          $or: [
            { expiresAt: { $gt: new Date() } },
            { expirationDate: { $gt: new Date() } }
          ]
        });
        
        await User.findByIdAndUpdate(userId, {
          $set: {
            activeAgents: activeCount,
            subscriptionStatus: activeCount > 0 ? 'ACTIVE' : 'NONE',
            currentPlan: activeCount > 0 ? 'AGENT_ACCESS' : 'NONE',
            tier: activeCount > 0 ? 'premium' : 'free',
          },
          $inc: { agentsUsed: 1 }
        });
        console.log('[USER] Updated user stats - activeAgents:', activeCount);
      } catch (userError) {
        console.error('[USER] Failed to update user document:', userError.message);
      }
      
      console.log(
        `✅ [Stripe Checkout Webhook] Activated existing purchase ${purchase._id} for user ${userId}, agent ${agentId}`
      );
    } else {
      // Create new purchase if PENDING not found (fallback)
      const purchaseDate = new Date();
      const expiresAt = AgentPurchase.calculateExpiration(normalizedPlan, purchaseDate);
      const planConfig = AgentPurchase.getPlanConfig(normalizedPlan);

      purchase = new AgentPurchase({
        userId,
        email: user.email,
        agentId,
        agentName: agentId,
        plan: normalizedPlan,
        planName: planConfig?.name,
        pricing: {
          amount: planConfig?.amount ?? 0,
          currency: 'USD',
        },
        purchaseDate,
        expiresAt,
        stripeCheckoutSessionId: session.id,
        stripeCustomerId: session.customer,
        paymentMethod: 'CARD',
        paymentStatus: 'SUCCESS',
        status: 'ACTIVE',
        metadata: {
          ...(session.metadata || {}),
          source: 'stripe_checkout',
          created_by_webhook: true,
        },
      });

      await purchase.save();
      
      // ============================================
      // RECORD TRANSACTION (Professional Tracking!)
      // ============================================
      try {
        await TrackingService.recordTransaction({
          userId: userId,
          type: 'AGENT_PURCHASE',
          amount: purchase.pricing?.amount || 0,
          currency: 'USD',
          status: 'COMPLETED',
          stripePaymentIntentId: session.payment_intent,
          stripeCheckoutSessionId: session.id,
          stripeCustomerId: session.customer,
          metadata: {
            agentId: agentId,
            agentName: purchase.agentName || agentId,
            plan: purchase.plan,
            purchaseId: purchase._id.toString(),
            email: user.email,
            source: 'stripe_checkout_webhook_new',
            created_by_webhook: true,
          },
        });
        console.log('[TRANSACTION] Recorded NEW purchase for user:', userId);
      } catch (txError) {
        console.error('[TRANSACTION] Failed to record:', txError.message);
      }
      
      // ============================================
      // RECORD WEBHOOK EVENT (Professional Tracking!)
      // ============================================
      try {
        await TrackingService.recordWebhookEvent({
          source: 'stripe',
          eventType: event.type,
          eventId: event.id,
          payload: {
            sessionId: session.id,
            userId: userId,
            agentId: agentId,
            plan: purchase.plan,
            amount: purchase.pricing?.amount,
            created_by_webhook: true,
          },
          status: 'PROCESSED',
          processingTime: Date.now() - new Date(event.created * 1000).getTime(),
          relatedUserId: userId,
          relatedPurchaseId: purchase._id,
        });
        console.log('[WEBHOOK_EVENT] Recorded stripe event for new purchase:', event.id);
      } catch (whError) {
        console.error('[WEBHOOK_EVENT] Failed to record:', whError.message);
      }
      
      // ============================================
      // UPDATE USER DOCUMENT (Sync user status!)
      // ============================================
      try {
        const activeCount = await AgentPurchase.countDocuments({
          userId: userId,
          status: { $in: ['ACTIVE', 'active'] },
          $or: [
            { expiresAt: { $gt: new Date() } },
            { expirationDate: { $gt: new Date() } }
          ]
        });
        
        await User.findByIdAndUpdate(userId, {
          $set: {
            activeAgents: activeCount,
            subscriptionStatus: activeCount > 0 ? 'ACTIVE' : 'NONE',
            currentPlan: activeCount > 0 ? 'AGENT_ACCESS' : 'NONE',
            tier: activeCount > 0 ? 'premium' : 'free',
          },
          $inc: { agentsUsed: 1 }
        });
        console.log('[USER] Updated user stats for new purchase - activeAgents:', activeCount);
      } catch (userError) {
        console.error('[USER] Failed to update user document:', userError.message);
      }
      
      console.log(
        `✅ [Stripe Checkout Webhook] Created new purchase for user ${userId}, agent ${agentId}, plan ${normalizedPlan}`
      );
    }

    return res.json({ received: true });
  } catch (error) {
    console.error('[Stripe Checkout Webhook] Error:', error);
    return res.status(400).send(`Webhook Error: ${error.message}`);
  }
});

/**
 * POST /api/webhooks/endpoints/:endpointId/test
 * Test webhook endpoint (admin only)
 */
router.post('/endpoints/:endpointId/test', authenticate, requireTier(['admin']), async (req, res) => {
  try {
    const endpoint = await WebhookEndpoint.findById(req.params.endpointId);

    if (!endpoint) {
      return res.status(404).json({
        success: false,
        error: 'Webhook endpoint not found'
      });
    }

    // Create a test webhook log
    const testLog = new WebhookLog({
      event: {
        type: 'test_event',
        name: 'Test Webhook',
        source: 'manual',
        version: '1.0'
      },
      source: {
        endpoint: endpoint._id,
        service: {
          name: 'IAMAI Test',
          environment: 'test'
        },
        ipAddress: req.ip,
        authenticated: true
      },
      request: {
        method: 'POST',
        url: endpoint.url,
        body: {
          parsed: {
            test: true,
            message: 'This is a test webhook',
            timestamp: new Date()
          }
        }
      },
      processing: {
        status: 'completed'
      },
      response: {
        statusCode: 200,
        delivered: true
      },
      related: {
        userId: req.userId
      }
    });

    await testLog.save();

    // Record the test in endpoint statistics
    await endpoint.recordDelivery(true, 100, 200, 'test_event');

    res.json({
      success: true,
      data: {
        testLog,
        endpoint: {
          name: endpoint.name,
          url: endpoint.url,
          isHealthy: endpoint.isHealthy
        }
      },
      message: 'Test webhook sent successfully'
    });

  } catch (error) {
    console.error('Webhook test error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to test webhook endpoint',
      message: error.message
    });
  }
});

// ============================================
// WEBHOOK STATISTICS ROUTES
// ============================================

/**
 * GET /api/webhooks/stats
 * Get webhook statistics (admin only)
 */
router.get('/stats', authenticate, requireTier(['admin']), async (req, res) => {
  try {
    const { period = '30d' } = req.query;
    
    let dateFilter = new Date();
    if (period === '7d') {
      dateFilter.setDate(dateFilter.getDate() - 7);
    } else if (period === '30d') {
      dateFilter.setDate(dateFilter.getDate() - 30);
    } else if (period === '90d') {
      dateFilter.setDate(dateFilter.getDate() - 90);
    }

    const totalWebhooks = await WebhookLog.countDocuments({
      'request.receivedAt': { $gte: dateFilter }
    });

    const successfulWebhooks = await WebhookLog.countDocuments({
      'request.receivedAt': { $gte: dateFilter },
      'processing.status': 'completed'
    });

    const failedWebhooks = await WebhookLog.countDocuments({
      'request.receivedAt': { $gte: dateFilter },
      'processing.status': 'failed'
    });

    const eventTypeStats = await WebhookLog.aggregate([
      { $match: { 'request.receivedAt': { $gte: dateFilter } } },
      {
        $group: {
          _id: '$event.type',
          count: { $sum: 1 },
          avgProcessingTime: { $avg: '$processing.metrics.processingTime' }
        }
      },
      { $sort: { count: -1 } }
    ]);

    const sourceStats = await WebhookLog.aggregate([
      { $match: { 'request.receivedAt': { $gte: dateFilter } } },
      {
        $group: {
          _id: '$event.source',
          count: { $sum: 1 },
          successRate: {
            $avg: {
              $cond: [{ $eq: ['$processing.status', 'completed'] }, 1, 0]
            }
          }
        }
      },
      { $sort: { count: -1 } }
    ]);

    const avgProcessingTime = await WebhookLog.aggregate([
      { $match: { 
        'request.receivedAt': { $gte: dateFilter },
        'processing.metrics.processingTime': { $exists: true }
      }},
      {
        $group: {
          _id: null,
          avgTime: { $avg: '$processing.metrics.processingTime' }
        }
      }
    ]);

    res.json({
      success: true,
      data: {
        period,
        overview: {
          totalWebhooks,
          successfulWebhooks,
          failedWebhooks,
          successRate: totalWebhooks > 0 ? ((successfulWebhooks / totalWebhooks) * 100).toFixed(2) : 0,
          avgProcessingTime: avgProcessingTime[0]?.avgTime || 0
        },
        eventTypes: eventTypeStats,
        sources: sourceStats
      }
    });

  } catch (error) {
    console.error('Webhook stats error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve webhook statistics',
      message: error.message
    });
  }
});

/**
 * GET /api/webhooks/health
 * Get webhook system health status
 */
router.get('/health', authenticate, requireTier(['admin', 'support_agent']), async (req, res) => {
  try {
    const activeEndpoints = await WebhookEndpoint.countDocuments({ isActive: true });
    const healthyEndpoints = await WebhookEndpoint.countDocuments({ 
      isActive: true, 
      isHealthy: true 
    });

    const recentFailures = await WebhookLog.countDocuments({
      'request.receivedAt': { $gte: new Date(Date.now() - 60 * 60 * 1000) }, // Last hour
      'processing.status': 'failed'
    });

    const endpointHealth = await WebhookEndpoint.find({
      isActive: true
    }).select('name url isHealthy health.consecutiveFailures health.lastSuccessfulDelivery');

    res.json({
      success: true,
      data: {
        overview: {
          activeEndpoints,
          healthyEndpoints,
          unhealthyEndpoints: activeEndpoints - healthyEndpoints,
          recentFailures,
          systemHealth: healthyEndpoints === activeEndpoints ? 'healthy' : 'degraded'
        },
        endpoints: endpointHealth
      }
    });

  } catch (error) {
    console.error('Webhook health check error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to check webhook health',
      message: error.message
    });
  }
});

module.exports = router;