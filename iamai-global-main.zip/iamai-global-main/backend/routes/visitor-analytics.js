const express = require('express');
const router = express.Router();
const {
  getVisitorAnalytics,
  getCurrentActiveVisitors,
  getRecentVisitors,
  Visitor,
} = require('../middleware/simple-visitor-tracking');

// Get visitor analytics dashboard
router.get('/analytics', async (req, res) => {
  try {
    const timeframe = req.query.timeframe || '24h';
    console.log('📊 Analytics request for:', timeframe);

    const analytics = await getVisitorAnalytics(timeframe);

    res.json({
      success: true,
      data: analytics,
    });
  } catch (error) {
    console.error('❌ Analytics error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch analytics',
      message: error.message,
    });
  }
});

// Get current active visitors
router.get('/active', async (req, res) => {
  try {
    const activeCount = await getCurrentActiveVisitors();
    console.log('🔴 Active visitors:', activeCount);

    res.json({
      success: true,
      activeVisitors: activeCount,
    });
  } catch (error) {
    console.error('❌ Active visitors error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch active visitors',
      activeVisitors: 0,
    });
  }
});

// Get recent visitors (last 24 hours)
router.get('/recent', async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 50;
    console.log('👥 Recent visitors request, limit:', limit);

    const recentVisitors = await getRecentVisitors(limit);

    res.json({
      success: true,
      visitors: recentVisitors,
      count: recentVisitors.length,
    });
  } catch (error) {
    console.error('❌ Recent visitors error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch recent visitors',
      visitors: [],
    });
  }
});

// Get visitor by session ID
router.get('/session/:sessionId', async (req, res) => {
  try {
    const visitor = await Visitor.findOne({ sessionId: req.params.sessionId });

    if (!visitor) {
      return res.status(404).json({
        success: false,
        error: 'Visitor not found',
      });
    }

    res.json({
      success: true,
      visitor,
    });
  } catch (error) {
    console.error('❌ Visitor lookup error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch visitor',
    });
  }
});

// Analytics dashboard page
router.get('/dashboard', (req, res) => {
  try {
    const dashboardPath = require('path').join(__dirname, '../public/analytics-dashboard.html');
    res.sendFile(dashboardPath);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Dashboard not available',
    });
  }
});

// Get real-time statistics
router.get('/stats', async (req, res) => {
  try {
    console.log('📈 Real-time stats request');

    const [totalVisitors, activeVisitors, todayVisitors, totalPageViews] = await Promise.all([
      Visitor.countDocuments(),
      getCurrentActiveVisitors(),
      Visitor.countDocuments({
        lastActivity: {
          $gte: new Date(new Date().setHours(0, 0, 0, 0)),
        },
      }),
      Visitor.aggregate([{ $group: { _id: null, totalPageViews: { $sum: '$totalPageViews' } } }]),
    ]);

    res.json({
      success: true,
      stats: {
        totalVisitors,
        activeVisitors,
        todayVisitors,
        totalPageViews: totalPageViews[0]?.totalPageViews || 0,
        timestamp: new Date(),
      },
    });
  } catch (error) {
    console.error('❌ Stats error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch statistics',
    });
  }
});

// Get device breakdown
router.get('/devices', async (req, res) => {
  try {
    const timeframe = req.query.timeframe || '24h';
    const now = new Date();
    let startDate = new Date(now.getTime() - 24 * 60 * 60 * 1000);

    if (timeframe === '7d') {
      startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    } else if (timeframe === '30d') {
      startDate = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
    }

    const [devices, browsers, os] = await Promise.all([
      Visitor.aggregate([
        { $match: { lastActivity: { $gte: startDate } } },
        { $group: { _id: '$device.type', count: { $sum: 1 } } },
        { $sort: { count: -1 } },
      ]),
      Visitor.aggregate([
        { $match: { lastActivity: { $gte: startDate } } },
        { $group: { _id: '$device.browser', count: { $sum: 1 } } },
        { $sort: { count: -1 } },
      ]),
      Visitor.aggregate([
        { $match: { lastActivity: { $gte: startDate } } },
        { $group: { _id: '$device.os', count: { $sum: 1 } } },
        { $sort: { count: -1 } },
      ]),
    ]);

    res.json({
      success: true,
      devices,
      browsers,
      operatingSystems: os,
    });
  } catch (error) {
    console.error('❌ Device breakdown error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch device data',
    });
  }
});

// Test endpoint to create sample visitor data
router.post('/test-visitor', async (req, res) => {
  try {
    const sampleVisitor = new Visitor({
      sessionId: `test_${Date.now()}`,
      ipAddress: '192.168.1.' + Math.floor(Math.random() * 255),
      userAgent: 'Test Browser/1.0',
      country: ['US', 'UK', 'CA', 'DE', 'FR'][Math.floor(Math.random() * 5)],
      city: 'Test City',
      device: {
        type: ['desktop', 'mobile', 'tablet'][Math.floor(Math.random() * 3)],
        browser: ['Chrome', 'Firefox', 'Safari'][Math.floor(Math.random() * 3)],
        os: ['Windows', 'macOS', 'Linux'][Math.floor(Math.random() * 3)],
      },
      pages: [
        {
          url: '/test',
          title: 'Test Page',
          timestamp: new Date(),
        },
      ],
    });

    await sampleVisitor.save();

    res.json({
      success: true,
      message: 'Test visitor created',
      visitor: sampleVisitor,
    });
  } catch (error) {
    console.error('❌ Test visitor error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to create test visitor',
    });
  }
});

module.exports = router;
