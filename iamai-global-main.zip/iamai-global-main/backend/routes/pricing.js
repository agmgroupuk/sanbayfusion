import express from 'express';
const router = express.Router();

const PRICING = {
  daily: { amount: 1, name: 'Daily', interval: 'day' },
  weekly: { amount: 5, name: 'Weekly', interval: 'week' },
  monthly: { amount: 19, name: 'Monthly', interval: 'month' }
};

router.get('/', (req, res) => {
  res.json(PRICING);
});

export default router;