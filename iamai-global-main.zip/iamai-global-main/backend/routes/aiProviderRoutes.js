/**
 * AI Provider Routes
 * Unified API endpoints for all AI operations with multi-provider support
 */

const express = require('express');
const comprehensiveAI = require('../services/comprehensiveAIService');
const aiProviderService = require('../services/aiProviderService');
const { createHash } = require('crypto');
const fs = require('fs').promises;
const path = require('path');
const { getRuntimeConfig } = require('../config/agentConfigs.js');

const router = express.Router();

// Cache directory for TTS and embeddings
const CACHE_DIR = path.join(process.cwd(), 'cache');
const TTS_CACHE_DIR = path.join(CACHE_DIR, 'tts');
const EMBEDDINGS_CACHE_DIR = path.join(CACHE_DIR, 'embeddings');

// Initialize cache directories
async function initCacheDirs() {
  await fs.mkdir(TTS_CACHE_DIR, { recursive: true });
  await fs.mkdir(EMBEDDINGS_CACHE_DIR, { recursive: true });
}
initCacheDirs().catch(console.error);

/**
 * POST /api/ai/chat
 * Chat completion with agent configuration OR demo chat
 */
router.post('/chat', async (req, res) => {
  try {
    const { agentId, messages, message, provider = 'mistral', temperature = 0.7, maxTokens = 1000, conversationHistory, stream = false } = req.body;
    
    console.log('📥 Chat request:', {
      agentId,
      hasMessages: !!messages,
      hasMessage: !!message,
      hasConversationHistory: !!conversationHistory,
      conversationHistoryType: typeof conversationHistory,
      conversationHistoryIsArray: Array.isArray(conversationHistory),
      provider
    });
    
    // Demo chat mode (for AI Studio demo)
    if (!agentId && (message || conversationHistory)) {
      // Ensure conversationHistory is an array
      let chatMessages = [];
      
      console.log('🔍 Raw conversationHistory:', JSON.stringify(conversationHistory).substring(0, 200));
      
      if (Array.isArray(conversationHistory)) {
        chatMessages = conversationHistory;
      } else if (conversationHistory && typeof conversationHistory === 'object') {
        // If it's an object, try to convert it to array
        console.log('⚠️ Converting conversationHistory object to array');
        chatMessages = Object.values(conversationHistory);
      }
      
      if (message) {
        chatMessages.push({ role: 'user', content: message });
      }
      
      console.log('📤 Sending to AI:', {
        messageCount: chatMessages.length,
        isArray: Array.isArray(chatMessages),
        firstMessage: chatMessages[0],
        provider,
        stream
      });

      // Set up SSE headers for streaming
      if (stream) {
        res.setHeader('Content-Type', 'text/event-stream');
        res.setHeader('Cache-Control', 'no-cache');
        res.setHeader('Connection', 'keep-alive');
        res.setHeader('X-Accel-Buffering', 'no'); // Disable nginx buffering
      }

      try {
        // Call comprehensive AI service - messages as first param, options as second
        const result = await comprehensiveAI.chat(chatMessages, {
          provider: provider,
          temperature: temperature,
          maxTokens: maxTokens,
          stream: stream
        });

        // Handle streaming response
        if (stream && result.stream) {
          try {
            console.log('📡 Starting stream...', typeof result.stream, result.stream.constructor.name);
            
            // Stream chunks to client
            for await (const chunk of result.stream) {
              // Handle different chunk formats from different providers
              let text = '';
              
              if (chunk.choices && chunk.choices[0]) {
                // OpenAI/Mistral format
                text = chunk.choices[0].delta?.content || chunk.choices[0].message?.content || '';
              } else if (chunk.data?.choices && chunk.data.choices[0]) {
                // Alternative format
                text = chunk.data.choices[0].delta?.content || '';
              } else if (chunk.text) {
                // Simple text format
                text = chunk.text;
              } else if (typeof chunk === 'string') {
                // Raw text chunk
                text = chunk;
              }
              
              if (text) {
                res.write(`data: ${JSON.stringify({ text, done: false })}\n\n`);
              }
            }
            
            console.log('✅ Stream completed successfully');
            res.write(`data: ${JSON.stringify({ done: true, provider: result.provider })}\n\n`);
            res.end();
          } catch (streamError) {
            console.error('Streaming error:', streamError);
            console.error('Stream object:', result.stream);
            res.write(`data: ${JSON.stringify({ error: streamError.message, done: true })}\n\n`);
            res.end();
          }
          return;
        }

        // Non-streaming response
        return res.json({
          success: true,
          provider: result.provider,
          response: result.text,
          usage: result.usage
        });
      } catch (error) {
        console.error('Chat error:', error);
        
        if (stream) {
          // If streaming, send error through SSE
          res.write(`data: ${JSON.stringify({ error: error.message, done: true })}\n\n`);
          res.end();
        } else {
          // Otherwise send JSON error
          return res.status(500).json({
            success: false,
            error: error.message || 'Failed to process chat request'
          });
        }
      }
    }

    // Agent mode (existing functionality)
    if (!agentId || !messages || !Array.isArray(messages)) {
      return res.status(400).json({ error: 'agentId and messages array required, or use message for demo chat' });
    }

    // Get agent configuration from database
    let agent = null;
    try {
      const { Agent } = require('../models.cjs');
      agent = await Agent.findOne({ agentId });
    } catch (dbError) {
      console.warn('Database not available, falling back to config system:', dbError.message);
    }
    
    if (!agent) {
      // Fallback to old config system
      const agentConfig = getRuntimeConfig(agentId);
      // Prepare system message
      const fullMessages = agentConfig.systemPrompt 
        ? [{ role: 'system', content: agentConfig.systemPrompt }, ...messages]
        : messages;

      // Execute with fallback
      const result = await aiProviderService.executeWithFallback('chat', {
        messages: fullMessages,
        model: agentConfig.chatModel,
        temperature: agentConfig.temperature,
        maxTokens: agentConfig.maxTokens,
        stream
      });

      if (stream) {
        // Set up SSE headers
        res.setHeader('Content-Type', 'text/event-stream');
        res.setHeader('Cache-Control', 'no-cache');
        res.setHeader('Connection', 'keep-alive');

        // Stream response
        for await (const chunk of result.data) {
          if (chunk.text) {
            res.write(`data: ${JSON.stringify({ text: chunk.text })}\n\n`);
          }
          if (chunk.done) {
            res.write('data: [DONE]\n\n');
            res.end();
          }
        }
      } else {
        res.json({
          success: true,
          agentId,
          provider: result.provider,
          latency: result.latency,
          message: result.data.text,
          usage: result.data.usage,
          finishReason: result.data.finishReason
        });
      }
      return;
    }
    
    // Prepare system message
    const systemPrompt = agent.aiConfig?.systemPrompt || agent.systemPrompt || 'You are a helpful AI assistant.';
    const fullMessages = [{ role: 'system', content: systemPrompt }, ...messages];

    // Execute with fallback using AI service
    const aiService = require('../ai-service');
    const result = await aiService.chat(fullMessages, {
      model: agent.aiConfig?.chatModel || 'balanced',
      temperature: agent.aiConfig?.temperature || 0.7,
      maxTokens: agent.aiConfig?.maxTokens || 2000,
      agentId,
      preferredProvider: agent.aiConfig?.preferredProvider,
      stream
    });

    if (stream) {
      // For now, disable streaming since the AI service doesn't support it in the same way
      // TODO: Implement proper streaming support
      return res.status(400).json({ error: 'Streaming not yet supported in this endpoint' });
    } else {
      res.json({
        success: true,
        agentId,
        provider: result.provider,
        model: result.model,
        message: result.content,
        usage: result.usage,
        finishReason: result.finishReason
      });
    }

  } catch (error) {
    console.error('Chat error:', error);
    res.status(500).json({ 
      error: 'Chat failed', 
      message: error.message 
    });
  }
});

/**
 * POST /api/ai/embed
 * Generate embeddings with caching
 */
router.post('/embed', async (req, res) => {
  try {
    const { text, agentId } = req.body;
    
    if (!text) {
      return res.status(400).json({ error: 'text required' });
    }

    const agentConfig = agentId ? getRuntimeConfig(agentId) : null;
    
    // Check cache
    if (agentConfig?.cache?.embeddings) {
      const cacheKey = createHash('md5').update(text).digest('hex');
      const cachePath = path.join(EMBEDDINGS_CACHE_DIR, `${cacheKey}.json`);
      
      try {
        const cached = await fs.readFile(cachePath, 'utf8');
        const data = JSON.parse(cached);
        return res.json({
          success: true,
          cached: true,
          ...data
        });
      } catch (e) {
        // Cache miss, continue
      }
    }

    // Generate embedding
    const result = await aiProviderService.executeWithFallback('embed', {
      text,
      model: agentConfig?.embeddingModel
    });

    // Cache result
    if (agentConfig?.cache?.embeddings) {
      const cacheKey = createHash('md5').update(text).digest('hex');
      const cachePath = path.join(EMBEDDINGS_CACHE_DIR, `${cacheKey}.json`);
      await fs.writeFile(cachePath, JSON.stringify({
        provider: result.provider,
        embedding: result.data.embedding,
        dimensions: result.data.dimensions
      }));
    }

    res.json({
      success: true,
      cached: false,
      provider: result.provider,
      embedding: result.data.embedding,
      dimensions: result.data.dimensions,
      latency: result.latency
    });

  } catch (error) {
    console.error('Embedding error:', error);
    res.status(500).json({ 
      error: 'Embedding failed', 
      message: error.message 
    });
  }
});

/**
 * POST /api/ai/image
 * Generate images
 */
router.post('/image', async (req, res) => {
  try {
    const { prompt, agentId, size = '1024x1024', quality = 'standard' } = req.body;
    
    if (!prompt) {
      return res.status(400).json({ error: 'prompt required' });
    }

    const agentConfig = agentId ? getRuntimeConfig(agentId) : null;
    
    if (agentConfig && !agentConfig.features.imageGeneration) {
      return res.status(403).json({ error: 'Image generation not enabled for this agent' });
    }

    const result = await aiProviderService.executeWithFallback('generateImage', {
      prompt,
      size,
      quality
    });

    res.json({
      success: true,
      provider: result.provider,
      url: result.data.url,
      revisedPrompt: result.data.revisedPrompt,
      latency: result.latency
    });

  } catch (error) {
    console.error('Image generation error:', error);
    res.status(500).json({ 
      error: 'Image generation failed', 
      message: error.message 
    });
  }
});

/**
 * POST /api/ai/transcribe
 * Speech-to-text
 */
router.post('/transcribe', async (req, res) => {
  try {
    const { audio, language = 'en' } = req.body;
    
    if (!audio) {
      return res.status(400).json({ error: 'audio data required' });
    }

    // Convert base64 to buffer
    const audioBuffer = Buffer.from(audio, 'base64');

    const result = await aiProviderService.executeWithFallback('transcribe', {
      audioBuffer,
      language
    });

    res.json({
      success: true,
      provider: result.provider,
      text: result.data.text,
      confidence: result.data.confidence,
      latency: result.latency
    });

  } catch (error) {
    console.error('Transcription error:', error);
    res.status(500).json({ 
      error: 'Transcription failed', 
      message: error.message 
    });
  }
});

/**
 * POST /api/ai/tts
 * Text-to-speech with agent voice and caching
 */
router.post('/tts', async (req, res) => {
  try {
    const { text, agentId } = req.body;
    
    if (!text || !agentId) {
      return res.status(400).json({ error: 'text and agentId required' });
    }

    const agentConfig = getRuntimeConfig(agentId);
    
    if (!agentConfig.features.voiceResponse) {
      return res.status(403).json({ error: 'Voice response not enabled for this agent' });
    }

    // Check cache
    if (agentConfig.cache.ttsAudio) {
      const cacheKey = createHash('md5')
        .update(`${agentId}:${text}:${agentConfig.voice.speed}`)
        .digest('hex');
      const cachePath = path.join(TTS_CACHE_DIR, `${cacheKey}.mp3`);
      
      try {
        await fs.access(cachePath);
        // Cache hit - serve file
        return res.sendFile(cachePath);
      } catch (e) {
        // Cache miss, continue
      }
    }

    // Generate speech
    const result = await aiProviderService.executeWithFallback('synthesize', {
      text,
      voice: getVoiceForProvider(agentConfig.voice.profile, result?.provider || 'gemini'),
      speed: agentConfig.voice.speed
    });

    // Decode base64 audio
    const audioBuffer = Buffer.from(result.data.audioContent, 'base64');

    // Cache audio
    if (agentConfig.cache.ttsAudio) {
      const cacheKey = createHash('md5')
        .update(`${agentId}:${text}:${agentConfig.voice.speed}`)
        .digest('hex');
      const cachePath = path.join(TTS_CACHE_DIR, `${cacheKey}.mp3`);
      await fs.writeFile(cachePath, audioBuffer);
    }

    // Send audio
    res.set({
      'Content-Type': 'audio/mpeg',
      'Content-Length': audioBuffer.length,
      'X-Provider': result.provider,
      'X-Latency': result.latency
    });
    res.send(audioBuffer);

  } catch (error) {
    console.error('TTS error:', error);
    res.status(500).json({ 
      error: 'TTS failed', 
      message: error.message 
    });
  }
});

/**
 * GET /api/ai/providers
 * Get provider status
 */
router.get('/providers', (req, res) => {
  try {
    const status = aiProviderService.getProvidersStatus();
    res.json({
      success: true,
      providers: status
    });
  } catch (error) {
    res.status(500).json({ 
      error: 'Failed to get provider status', 
      message: error.message 
    });
  }
});

/**
 * GET /api/ai/agents
 * Get all agent configurations
 */
router.get('/agents', (req, res) => {
  try {
    const { getAllAgents } = require('../config/agentConfigs.js');
    const agents = getAllAgents();
    res.json({
      success: true,
      agents
    });
  } catch (error) {
    res.status(500).json({ 
      error: 'Failed to get agents', 
      message: error.message 
    });
  }
});

/**
 * GET /api/ai/agents/:agentId
 * Get specific agent configuration
 */
router.get('/agents/:agentId', (req, res) => {
  try {
    const config = getRuntimeConfig(req.params.agentId);
    res.json({
      success: true,
      config
    });
  } catch (error) {
    res.status(404).json({ 
      error: 'Agent not found', 
      message: error.message 
    });
  }
});

/**
 * PATCH /api/ai/agents/:agentId
 * Update agent configuration (runtime only)
 */
router.patch('/agents/:agentId', (req, res) => {
  try {
    const { updateAgentConfig } = require('../config/agentConfigs.js');
    const updated = updateAgentConfig(req.params.agentId, req.body);
    res.json({
      success: true,
      config: updated
    });
  } catch (error) {
    res.status(400).json({ 
      error: 'Failed to update agent', 
      message: error.message 
    });
  }
});

/**
 * DELETE /api/ai/cache
 * Clear cache (TTS, embeddings)
 */
router.delete('/cache', async (req, res) => {
  try {
    const { type } = req.query; // tts | embeddings | all
    
    if (type === 'tts' || type === 'all') {
      const files = await fs.readdir(TTS_CACHE_DIR);
      await Promise.all(files.map(f => fs.unlink(path.join(TTS_CACHE_DIR, f))));
    }
    
    if (type === 'embeddings' || type === 'all') {
      const files = await fs.readdir(EMBEDDINGS_CACHE_DIR);
      await Promise.all(files.map(f => fs.unlink(path.join(EMBEDDINGS_CACHE_DIR, f))));
    }
    
    res.json({
      success: true,
      message: 'Cache cleared'
    });
  } catch (error) {
    res.status(500).json({ 
      error: 'Failed to clear cache', 
      message: error.message 
    });
  }
});

module.exports = router;
