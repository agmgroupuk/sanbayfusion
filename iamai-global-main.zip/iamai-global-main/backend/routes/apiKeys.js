// API Key Management Routes
// Complete CRUD operations for user API keys

const express = require('express');
const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const { ApiKey, User } = require('../models');
const { authenticate, requireTier } = require('../auth-middleware');

const router = express.Router();

// Helper function to generate API key
const generateApiKey = () => {
  const prefix = 'iamai';
  const randomBytes = crypto.randomBytes(24).toString('hex');
  return `${prefix}_${randomBytes}`;
};

// Helper function to hash API key for storage
const hashApiKey = async (apiKey) => {
  const saltRounds = 12;
  return bcrypt.hash(apiKey, saltRounds);
};

// Helper function to get key prefix for display
const getKeyPrefix = (apiKey) => {
  return apiKey.substring(0, 12) + '...';
};

// ============================================
// ROUTES
// ============================================

/**
 * GET /api/api-keys
 * Get user's API keys (without revealing actual keys)
 */
router.get('/', authenticate, async (req, res) => {
  try {
    const apiKeys = await ApiKey.find({ 
      userId: req.userId,
      isActive: true 
    }).select('-keyHash').sort({ createdAt: -1 });

    const user = await User.findById(req.userId);

    res.json({
      success: true,
      data: {
        apiKeys: apiKeys.map(key => ({
          id: key._id,
          name: key.name,
          keyPrefix: key.keyPrefix,
          lastUsed: key.lastUsed,
          expiresAt: key.expiresAt,
          permissions: key.permissions,
          createdAt: key.createdAt,
          isExpired: key.expiresAt && key.expiresAt < new Date()
        })),
        limits: {
          maxKeys: user.tier === 'FREE' ? 2 : user.tier === 'PRO' ? 5 : 10,
          currentCount: apiKeys.length
        }
      }
    });

  } catch (error) {
    console.error('API key list error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve API keys',
      message: error.message
    });
  }
});

/**
 * POST /api/api-keys
 * Create a new API key
 */
router.post('/', authenticate, async (req, res) => {
  try {
    const { name, expiresInDays, permissions = { scopes: ['read'] } } = req.body;

    if (!name || name.trim().length === 0) {
      return res.status(400).json({
        success: false,
        error: 'API key name is required'
      });
    }

    // Check user limits
    const user = await User.findById(req.userId);
    const existingKeys = await ApiKey.countDocuments({ 
      userId: req.userId, 
      isActive: true 
    });

    const maxKeys = user.tier === 'NONE' ? 2 : user.tier === 'PRO' ? 5 : 10;
    
    if (existingKeys >= maxKeys) {
      return res.status(403).json({
        success: false,
        error: `Maximum API keys limit reached (${maxKeys} for ${user.tier} tier)`,
        upgrade: user.tier === 'NONE' ? 'Upgrade to PRO for more API keys' : null
      });
    }

    // Generate and hash API key
    const apiKey = generateApiKey();
    const keyHash = await hashApiKey(apiKey);
    const keyPrefix = getKeyPrefix(apiKey);

    // Set expiration
    let expiresAt = null;
    if (expiresInDays && expiresInDays > 0) {
      expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + expiresInDays);
    }

    // Validate permissions based on user tier
    const allowedScopes = user.tier === 'NONE' 
      ? ['read']
      : user.tier === 'PRO'
        ? ['read', 'write'] 
        : ['read', 'write', 'admin'];

    const validScopes = permissions.scopes.filter(scope => allowedScopes.includes(scope));

    // Create API key record
    const apiKeyRecord = new ApiKey({
      userId: req.userId,
      name: name.trim(),
      keyHash,
      keyPrefix,
      expiresAt,
      permissions: {
        scopes: validScopes
      },
      metadata: {
        createdFrom: req.headers['user-agent'] || 'Unknown',
        ipAddress: req.ip
      }
    });

    await apiKeyRecord.save();

    res.status(201).json({
      success: true,
      data: {
        id: apiKeyRecord._id,
        name: apiKeyRecord.name,
        apiKey: apiKey, // Only returned once on creation
        keyPrefix: apiKeyRecord.keyPrefix,
        expiresAt: apiKeyRecord.expiresAt,
        permissions: apiKeyRecord.permissions,
        createdAt: apiKeyRecord.createdAt
      },
      warning: 'Save this API key now. You will not be able to see it again.'
    });

  } catch (error) {
    console.error('API key creation error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to create API key',
      message: error.message
    });
  }
});

/**
 * PUT /api/api-keys/:keyId
 * Update API key (name and permissions only)
 */
router.put('/:keyId', authenticate, async (req, res) => {
  try {
    const { name, permissions } = req.body;

    const apiKey = await ApiKey.findOne({
      _id: req.params.keyId,
      userId: req.userId,
      isActive: true
    });

    if (!apiKey) {
      return res.status(404).json({
        success: false,
        error: 'API key not found'
      });
    }

    // Update allowed fields
    if (name) {
      apiKey.name = name.trim();
    }

    if (permissions) {
      const user = await User.findById(req.userId);
      const allowedScopes = user.tier === 'NONE' 
        ? ['read']
        : user.tier === 'PRO'
          ? ['read', 'write'] 
          : ['read', 'write', 'admin'];

      const validScopes = permissions.scopes.filter(scope => allowedScopes.includes(scope));
      apiKey.permissions.scopes = validScopes;
    }

    await apiKey.save();

    res.json({
      success: true,
      data: {
        id: apiKey._id,
        name: apiKey.name,
        keyPrefix: apiKey.keyPrefix,
        lastUsed: apiKey.lastUsed,
        expiresAt: apiKey.expiresAt,
        permissions: apiKey.permissions,
        updatedAt: apiKey.updatedAt
      }
    });

  } catch (error) {
    console.error('API key update error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to update API key',
      message: error.message
    });
  }
});

/**
 * DELETE /api/api-keys/:keyId
 * Delete (deactivate) an API key
 */
router.delete('/:keyId', authenticate, async (req, res) => {
  try {
    const apiKey = await ApiKey.findOne({
      _id: req.params.keyId,
      userId: req.userId,
      isActive: true
    });

    if (!apiKey) {
      return res.status(404).json({
        success: false,
        error: 'API key not found'
      });
    }

    // Deactivate instead of deleting
    apiKey.isActive = false;
    await apiKey.save();

    res.json({
      success: true,
      message: 'API key deleted successfully'
    });

  } catch (error) {
    console.error('API key deletion error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to delete API key',
      message: error.message
    });
  }
});

/**
 * POST /api/api-keys/:keyId/regenerate
 * Regenerate an API key (creates new key, deactivates old one)
 */
router.post('/:keyId/regenerate', authenticate, async (req, res) => {
  try {
    const oldApiKey = await ApiKey.findOne({
      _id: req.params.keyId,
      userId: req.userId,
      isActive: true
    });

    if (!oldApiKey) {
      return res.status(404).json({
        success: false,
        error: 'API key not found'
      });
    }

    // Generate new API key
    const newApiKeyValue = generateApiKey();
    const newKeyHash = await hashApiKey(newApiKeyValue);
    const newKeyPrefix = getKeyPrefix(newApiKeyValue);

    // Create new API key record
    const newApiKey = new ApiKey({
      userId: req.userId,
      name: oldApiKey.name,
      keyHash: newKeyHash,
      keyPrefix: newKeyPrefix,
      expiresAt: oldApiKey.expiresAt,
      permissions: oldApiKey.permissions,
      metadata: {
        regeneratedFrom: oldApiKey._id,
        createdFrom: req.headers['user-agent'] || 'Unknown',
        ipAddress: req.ip
      }
    });

    await newApiKey.save();

    // Deactivate old key
    oldApiKey.isActive = false;
    await oldApiKey.save();

    res.json({
      success: true,
      data: {
        id: newApiKey._id,
        name: newApiKey.name,
        apiKey: newApiKeyValue, // Only returned once
        keyPrefix: newApiKey.keyPrefix,
        expiresAt: newApiKey.expiresAt,
        permissions: newApiKey.permissions,
        createdAt: newApiKey.createdAt
      },
      warning: 'Save this new API key now. The old key has been deactivated.'
    });

  } catch (error) {
    console.error('API key regeneration error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to regenerate API key',
      message: error.message
    });
  }
});

/**
 * GET /api/api-keys/validate/:key
 * Validate an API key (for testing purposes)
 */
router.get('/validate/:key', async (req, res) => {
  try {
    const providedKey = req.params.key;

    if (!providedKey || !providedKey.startsWith('iamai_')) {
      return res.status(400).json({
        success: false,
        error: 'Invalid API key format'
      });
    }

    // Find all active API keys and check against hashes
    const activeKeys = await ApiKey.find({ 
      isActive: true,
      $or: [
        { expiresAt: { $gt: new Date() } },
        { expiresAt: null }
      ]
    }).populate('userId', 'email tier');

    let matchedKey = null;

    for (const key of activeKeys) {
      const isMatch = await bcrypt.compare(providedKey, key.keyHash);
      if (isMatch) {
        matchedKey = key;
        break;
      }
    }

    if (!matchedKey) {
      return res.status(401).json({
        success: false,
        error: 'Invalid or expired API key'
      });
    }

    // Update last used timestamp
    matchedKey.lastUsed = new Date();
    await matchedKey.save();

    res.json({
      success: true,
      data: {
        valid: true,
        keyId: matchedKey._id,
        keyName: matchedKey.name,
        permissions: matchedKey.permissions,
        user: {
          id: matchedKey.userId._id,
          email: matchedKey.userId.email,
          tier: matchedKey.userId.tier
        },
        lastUsed: matchedKey.lastUsed
      }
    });

  } catch (error) {
    console.error('API key validation error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to validate API key',
      message: error.message
    });
  }
});

/**
 * GET /api/api-keys/usage-stats
 * Get usage statistics for user's API keys
 */
router.get('/usage-stats', authenticate, async (req, res) => {
  try {
    const { days = 30 } = req.query;
    
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    const apiKeys = await ApiKey.find({
      userId: req.userId,
      isActive: true
    }).select('name keyPrefix lastUsed createdAt');

    // TODO: Implement actual usage tracking from activity logs
    // For now, return mock statistics
    const stats = apiKeys.map(key => ({
      id: key._id,
      name: key.name,
      keyPrefix: key.keyPrefix,
      lastUsed: key.lastUsed,
      createdAt: key.createdAt,
      usage: {
        totalRequests: Math.floor(Math.random() * 1000),
        successfulRequests: Math.floor(Math.random() * 900),
        errorRequests: Math.floor(Math.random() * 100),
        lastRequest: key.lastUsed
      }
    }));

    res.json({
      success: true,
      data: {
        period: `Last ${days} days`,
        apiKeys: stats,
        summary: {
          totalKeys: apiKeys.length,
          activeKeys: apiKeys.filter(k => k.lastUsed && k.lastUsed > startDate).length,
          totalRequests: stats.reduce((sum, key) => sum + key.usage.totalRequests, 0)
        }
      }
    });

  } catch (error) {
    console.error('API key usage stats error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve usage statistics',
      message: error.message
    });
  }
});

module.exports = router;