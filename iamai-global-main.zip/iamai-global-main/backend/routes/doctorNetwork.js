/**
 * Doctor Network API Endpoint Handler
 * 
 * Backend Implementation (Node.js/Express)
 * 
 * API Endpoint: POST /api/doctor-network/ask
 */

const express = require('express');
const axios = require('axios');

const router = express.Router();

console.log('✅ Doctor Network route module loaded successfully');

// System prompt for Doctor Network
const SYSTEM_PROMPT = `You are "Doctor Network", designed by IAMAI Global - a friendly and knowledgeable AI assistant specialized in helping users understand network, IP, and internet connectivity topics.

Your introduction (use when greeting new users):
"Hello! I'm Doctor Network, designed by IAMAI Global. I'm here to help you understand networking, IP addresses, security, and internet connectivity. How can I assist you today? 😊"

Your personality:
- Warm, friendly, and approachable - like a helpful tech-savvy friend
- Use simple language - avoid jargon unless explaining terms
- Be concise (1-3 sentences for quick answers, 2-3 paragraphs for complex topics)
- Use analogies and real-world examples to explain technical concepts
- Encourage learning without overwhelming users
- NEVER mention which AI model or provider you're using (Mistral, OpenAI, etc.)

Your expertise areas:
- IP addresses (IPv4, IPv6, public vs private)
- Geolocation and location data accuracy
- ISPs and network providers
- VPNs, proxies, and anonymity services
- Tor network and privacy tools
- DNS, domain systems, and DNS security
- Network security threats and protection
- Network privacy and safety best practices
- Cloud computing and CDN basics
- Network infrastructure and routing

Guidelines:
1. If user asks about THEIR IP data, use the provided context to give personalized explanations
2. For security concerns, be balanced - explain risks clearly without causing panic
3. If user asks something outside networking, politely redirect: "I specialize in networking topics! Would you like to know something about IP addresses, security, or internet connectivity instead?"
4. End complex answers with "Want to know more?" or "Any other networking questions?" to encourage follow-ups
5. Use emojis thoughtfully (🔒 for security, 🌍 for location, 🛡️ for protection, 📡 for connectivity, 🔍 for investigation)
6. When greeting users, introduce yourself as "Doctor Network, designed by IAMAI Global"

Remember: You're helping users UNDERSTAND their network data and stay safe online, not making them paranoid or confused. Be their trusted networking companion!`;

/**
 * Provider health tracking
 */
const providerHealth = {
  mistral: { healthy: true, lastError: null, consecutiveErrors: 0 },
  openai: { healthy: true, lastError: null, consecutiveErrors: 0 },
  anthropic: { healthy: true, lastError: null, consecutiveErrors: 0 },
  gemini: { healthy: true, lastError: null, consecutiveErrors: 0 },
};

/**
 * Call Mistral AI API
 */
const callMistral = async (question, context, history) => {
  const messages = [
    ...history.map(m => ({
      role: m.role === 'user' ? 'user' : 'assistant',
      content: m.content,
    })),
    {
      role: 'user',
      content: `${context}\n\nUser's question: ${question}`,
    },
  ];

  const response = await axios.post('https://api.mistral.ai/v1/chat/completions', {
    model: 'mistral-large-latest',
    messages: [
      { role: 'system', content: SYSTEM_PROMPT },
      ...messages,
    ],
    temperature: 0.7,
    max_tokens: 512,
    stream: false,
  }, {
    headers: {
      'Authorization': `Bearer ${process.env.MISTRAL_API_KEY}`,
      'Content-Type': 'application/json',
    },
    timeout: 15000,
  });

  return response.data.choices[0].message.content;
};

/**
 * Call OpenAI API
 */
const callOpenAI = async (question, context, history) => {
  const messages = [
    ...history.map(m => ({
      role: m.role === 'user' ? 'user' : 'assistant',
      content: m.content,
    })),
    {
      role: 'user',
      content: `${context}\n\nUser's question: ${question}`,
    },
  ];

  const response = await axios.post('https://api.openai.com/v1/chat/completions', {
    model: 'gpt-4-turbo',
    messages: [
      { role: 'system', content: SYSTEM_PROMPT },
      ...messages,
    ],
    temperature: 0.7,
    max_tokens: 512,
  }, {
    headers: {
      'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
      'Content-Type': 'application/json',
    },
    timeout: 10000,
  });

  return response.data.choices[0].message.content;
};

/**
 * Call Anthropic API
 */
const callAnthropic = async (question, context, history) => {
  const messages = [
    ...history.map(m => ({
      role: m.role === 'user' ? 'user' : 'assistant',
      content: m.content,
    })),
    {
      role: 'user',
      content: `${context}\n\nUser's question: ${question}`,
    },
  ];

  const response = await axios.post('https://api.anthropic.com/v1/messages', {
    model: 'claude-3-opus-20240229',
    max_tokens: 512,
    system: SYSTEM_PROMPT,
    messages: messages,
  }, {
    headers: {
      'x-api-key': process.env.ANTHROPIC_API_KEY,
      'Content-Type': 'application/json',
      'anthropic-version': '2023-06-01',
    },
    timeout: 10000,
  });

  return response.data.content[0].text;
};

/**
 * Call Google Gemini API
 */
const callGemini = async (question, context, history) => {
  const contents = [
    ...history.map(m => ({
      role: m.role === 'user' ? 'user' : 'model',
      parts: [{ text: m.content }],
    })),
    {
      role: 'user',
      parts: [{ text: `${context}\n\nUser's question: ${question}` }],
    },
  ];

  const response = await axios.post(
    `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-pro:generateContent?key=${process.env.GEMINI_API_KEY}`,
    {
      systemInstruction: { parts: [{ text: SYSTEM_PROMPT }] },
      contents: contents,
      generationConfig: {
        temperature: 0.7,
        maxOutputTokens: 512,
      },
    },
    { timeout: 10000 }
  );

  return response.data.candidates[0].content.parts[0].text;
};

/**
 * Main endpoint handler
 */
router.post('/ask', async (req, res) => {
  console.log('🔍 Doctor Network /ask endpoint hit');
  try {
    const { question, context, conversationHistory } = req.body;

    if (!question || typeof question !== 'string' || question.trim().length === 0) {
      return res.status(400).json({ error: 'Invalid question provided' });
    }

    // Sanitize context
    const sanitizedContext = context ? context.substring(0, 500) : '';
    const sanitizedHistory = conversationHistory ? conversationHistory.slice(-10) : [];

    let answer = null;
    const errors = [];

    // Try providers in order: Mistral → OpenAI → Anthropic → Gemini
    const providers = [
      {
        name: 'mistral',
        fn: () => callMistral(question, sanitizedContext, sanitizedHistory),
        health: providerHealth.mistral,
      },
      {
        name: 'openai',
        fn: () => callOpenAI(question, sanitizedContext, sanitizedHistory),
        health: providerHealth.openai,
      },
      {
        name: 'anthropic',
        fn: () => callAnthropic(question, sanitizedContext, sanitizedHistory),
        health: providerHealth.anthropic,
      },
      {
        name: 'gemini',
        fn: () => callGemini(question, sanitizedContext, sanitizedHistory),
        health: providerHealth.gemini,
      },
    ];

    for (const provider of providers) {
      try {
        // Skip unhealthy providers temporarily
        if (!provider.health.healthy && provider.health.lastError) {
          const timeSinceError = Date.now() - provider.health.lastError.getTime();
          if (timeSinceError < 60000) { // Skip for 1 minute
            console.log(`Skipping ${provider.name} - in recovery`);
            continue;
          }
        }

        console.log(`Trying ${provider.name}...`);
        answer = await provider.fn();
        
        // Mark as healthy on success
        provider.health.healthy = true;
        provider.health.consecutiveErrors = 0;
        
        console.log(`${provider.name} succeeded`);
        break;
      } catch (error) {
        provider.health.consecutiveErrors += 1;
        if (provider.health.consecutiveErrors >= 3) {
          provider.health.healthy = false;
        }
        provider.health.lastError = new Date();
        
        const errorMsg = error instanceof Error ? error.message : String(error);
        errors.push(`${provider.name}: ${errorMsg}`);
        console.error(`${provider.name} failed:`, errorMsg);
        continue;
      }
    }

    // Fallback response if all APIs fail
    if (!answer) {
      answer = getFallbackResponse(question);
      console.warn('Using fallback response. Provider errors:', errors);
    }

    res.json({ answer });
  } catch (error) {
    console.error('Doctor Network endpoint error:', error);
    res.status(500).json({
      error: 'Failed to process your question',
      answer: 'I encountered an issue processing your question. Please try again in a moment! 😊',
    });
  }
});

/**
 * Fallback responses
 */
function getFallbackResponse(question) {
  const lowerQuestion = question.toLowerCase();

  const responses = {
    'hello|hi|hey|greet': '👋 Hello! I\'m Doctor Network, designed by IAMAI Global. I\'m here to help you understand networking, IP addresses, security, and internet connectivity. How can I assist you today? 😊',
    'vpn|proxy|tor': '🔐 VPNs hide your real IP by routing traffic through servers in other locations. Proxies do similar jobs but work at different layers. Tor is a network of relays for extra anonymity. All make you appear to be from a different location. Want to know more?',
    'ip address|ipv4|ipv6': '🌐 An IP address is like your computer\'s home address on the internet. IPv4 uses 4 numbers (like 192.168.1.1), while IPv6 uses a longer format for more addresses. Your IP helps websites know where to send data back to you.',
    'asn|autonomous system': '🔗 An ASN is a unique number assigned to organizations that control routing on the internet. It helps identify which ISP or company owns a group of IP addresses. Think of it like a postal code for internet networks!',
    'geolocation|location': '📍 Geolocation uses IP databases to estimate where you are. It\'s usually accurate to city-level but can vary based on how ISPs register their IP ranges. It\'s not as precise as GPS but works without any device tracking.',
    'safe|security|privacy': '🛡️ Whether to share your IP depends on context. Your IP is visible to every website you visit - that\'s normal. Use a VPN if you want to hide it. Be cautious about sharing other personal details. Any other security questions?',
    'dns': '🔍 DNS translates domain names (like google.com) into IP addresses. It\'s like the phone book of the internet - when you type a web address, DNS looks up the corresponding IP so your browser knows where to connect.',
    'isp': '🏢 Your ISP (Internet Service Provider) is the company that connects you to the internet. They assign your IP address and manage your connection. Examples include Comcast, AT&T, or local providers in your area.',
  };

  for (const [keywords, response] of Object.entries(responses)) {
    const regex = new RegExp(keywords, 'i');
    if (regex.test(question)) {
      return response;
    }
  }

  return '💡 That\'s a great networking question! I\'m Doctor Network, designed by IAMAI Global to help you understand networking topics. I can explain IP addresses, VPNs, proxies, DNS, ISPs, geolocation, and internet security. What would you like to know? 😊';
}

console.log('✅ Doctor Network router registered with POST /ask endpoint');

module.exports = router;
