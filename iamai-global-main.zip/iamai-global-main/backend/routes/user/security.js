/**
 * 🔐 User Security Routes - Complete 2FA, Password, Email Management
 * Features: 2FA setup/disable, password change, email change, session management
 */

const express = require('express');
const bcrypt = require('bcryptjs');
const speakeasy = require('speakeasy');
const QRCode = require('qrcode');
const crypto = require('crypto');
const geoip = require('geoip-lite');
const router = express.Router();

// Middleware imports
const { authenticate } = require('../../auth-middleware');
const { User, ActivityLog } = require('../../models');

const buildSessionId = req => {
  if (req.session?.id) return req.session.id;
  if (req.sessionId) return req.sessionId;
  if (req.userId) return req.userId.toString();
  return `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
};

const logSecurityActivity = async (req, action, overrides = {}) => {
  try {
    await ActivityLog.create({
      userId: overrides.userId ?? req.userId ?? null,
      sessionId: overrides.sessionId ?? buildSessionId(req),
      action,
      category: overrides.category ?? 'security',
      details: overrides.details || {},
      ipAddress: overrides.ipAddress || req.ip,
      userAgent: overrides.userAgent || req.headers['user-agent'],
    });
  } catch (error) {
    console.warn('[SECURITY API] ⚠️ Failed to log activity:', action, error.message);
  }
};

/**
 * 🔍 GET /api/users/security/overview - Get security overview
 */
router.get('/overview', authenticate, async (req, res) => {
  console.log('[SECURITY API] 📥 GET security overview for user:', req.userId);

  try {
    const user = await User.findById(req.userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Get active sessions count based on embedded security.activeSessions
    const activeSessions = (user.security?.activeSessions || []).length;

    const overview = {
      twoFactorEnabled: user.security?.twoFactorEnabled || user.twoFactorEnabled || false,
      backupCodesCount: user.security?.backupCodes?.length || user.backupCodes?.length || 0,
      lastPasswordChange: user.security?.lastPasswordChange || user.lastPasswordChange || user.createdAt,
      activeSessions,
      emailChangeRequest: user.security?.emailChangeRequest || user.emailChangeRequest || null,
      notifications: user.security?.notifications || user.notifications || { email: true, sms: false },
      lastLoginAt: user.security?.lastLoginAt || user.lastLoginAt,
      lastLoginIP: user.security?.lastLoginIP || user.lastLoginIP,
    };

    console.log('[SECURITY API] ✅ Security overview retrieved');
    res.json(overview);
  } catch (error) {
    console.error('[SECURITY API] ❌ Error fetching security overview:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

/**
 * 🔐 POST /api/users/security/2fa/setup - Initialize 2FA setup
 */
router.post('/2fa/setup', authenticate, async (req, res) => {
  console.log('[SECURITY API] 🔐 POST 2FA setup for user:', req.userId);

  try {
    const user = await User.findById(req.userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    if (user.twoFactorEnabled) {
      return res.status(400).json({ message: '2FA is already enabled' });
    }

    // Generate secret
    const secret = speakeasy.generateSecret({
      name: `IAMAI Global (${user.email})`,
      issuer: 'IAMAI Global',
      length: 32,
    });

    // Store temporary secret (inside security object per schema)
    if (!user.security) user.security = {};
    user.security.tempTwoFactorSecret = secret.base32;
    await user.save();
    console.log('[SECURITY API] 📝 Saved tempTwoFactorSecret to user.security');

    // Generate QR code
    const qrCodeUrl = await QRCode.toDataURL(secret.otpauth_url);

    // Generate backup codes
    const backupCodes = [];
    for (let i = 0; i < 8; i++) {
      backupCodes.push(crypto.randomBytes(4).toString('hex').toUpperCase());
    }

    console.log('[SECURITY API] ✅ 2FA setup initialized');
    res.json({
      qrCode: qrCodeUrl,
      secret: secret.base32,
      backupCodes,
    });
  } catch (error) {
    console.error('[SECURITY API] ❌ Error setting up 2FA:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

/**
 * ✅ POST /api/users/security/2fa/verify - Verify and enable 2FA
 */
router.post('/2fa/verify', authenticate, async (req, res) => {
  console.log('[SECURITY API] ✅ POST verify 2FA for user:', req.userId);

  try {
    const { code, backupCodes } = req.body;

    if (!code) {
      return res.status(400).json({ message: 'Verification code is required' });
    }

    const user = await User.findById(req.userId);
    if (!user || !user.security?.tempTwoFactorSecret) {
      console.log('[SECURITY API] ❌ No tempTwoFactorSecret found, user.security:', user?.security);
      return res.status(400).json({ message: 'No 2FA setup in progress' });
    }

    // Verify the TOTP code.
    // NOTE: We intentionally allow a slightly larger time window (window: 4) to tolerate
    // minor clock drift between the authenticator device and the server, reducing the
    // chance of false negatives for valid users while still keeping strong security.
    const verified = speakeasy.totp.verify({
      secret: user.security.tempTwoFactorSecret,
      encoding: 'base32',
      token: code,
      digits: 6,
      step: 30,
      window: 4, // allow modest clock skew so valid users aren't blocked
    });

    if (!verified) {
      return res.status(400).json({
        message:
          'Invalid verification code. Please make sure your device time is correct and try again.',
      });
    }

    // Enable 2FA (store in security object per schema)
    user.security.twoFactorEnabled = true;
    user.security.twoFactorSecret = user.security.tempTwoFactorSecret;
    user.security.tempTwoFactorSecret = undefined;
    user.security.twoFactorEnabledAt = new Date();
    // Also set root level for backwards compatibility
    user.twoFactorEnabled = true;

    // Hash and store backup codes (in security object)
    if (backupCodes && Array.isArray(backupCodes)) {
      user.security.backupCodes = await Promise.all(backupCodes.map(code => bcrypt.hash(code, 10)));
    }

    await user.save();

    // Log security event
    await logSecurityActivity(req, 'SECURITY_2FA_ENABLED', {
      userId: user._id,
      details: { timestamp: new Date() },
    });

    console.log('[SECURITY API] ✅ 2FA enabled successfully');
    res.json({ message: '2FA enabled successfully' });
  } catch (error) {
    console.error('[SECURITY API] ❌ Error terminating sessions:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

/**
 * 🔔 PUT /api/users/security/notifications - Update notification settings
 */
router.put('/notifications', authenticate, async (req, res) => {
  console.log('[SECURITY API] 🔔 Updating notification settings for user:', req.userId);

  try {
    const user = await User.findById(req.userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Update notification settings (store in both locations for compatibility)
    const notifications = req.body;
    if (!user.security) user.security = {};
    user.security.notifications = { ...user.security.notifications, ...notifications };
    // Also update root level for backwards compatibility
    user.notifications = { ...user.notifications, ...notifications };
    await user.save();

    // Log activity
    await logSecurityActivity(req, 'SECURITY_NOTIFICATIONS_UPDATED', {
      details: notifications,
    });

    console.log('[SECURITY API] ✅ Notification settings updated');
    res.json({
      message: 'Notification settings updated',
      notifications: user.security.notifications,
    });
  } catch (error) {
    console.error('[SECURITY API] ❌ Error updating notification settings:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

/**
 * 🔑 PUT /api/users/security/password/change - Change password
 */
router.put('/password/change', authenticate, async (req, res) => {
  console.log('[SECURITY API] 🔑 Password change request for user:', req.userId);

  try {
    const { currentPassword, newPassword } = req.body;

    if (!currentPassword || !newPassword) {
      return res.status(400).json({ message: 'Current password and new password are required' });
    }

    const user = await User.findById(req.userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Verify current password
    const isCurrentPasswordValid = await bcrypt.compare(currentPassword, user.password);
    if (!isCurrentPasswordValid) {
      return res.status(400).json({ message: 'Current password is incorrect' });
    }

    // Hash and update new password
    const hashedNewPassword = await bcrypt.hash(newPassword, 12);
    user.password = hashedNewPassword;
    // Store lastPasswordChange in both locations for compatibility
    if (!user.security) user.security = {};
    user.security.lastPasswordChange = new Date();
    user.lastPasswordChange = new Date();
    await user.save();

    // Log activity
    await logSecurityActivity(req, 'SECURITY_PASSWORD_CHANGED', {
      details: { timestamp: new Date() },
    });

    console.log('[SECURITY API] ✅ Password changed successfully');
    res.json({ message: 'Password changed successfully' });
  } catch (error) {
    console.error('[SECURITY API] ❌ Error changing password:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

module.exports = router;

/**
 * 🔓 POST /api/users/security/2fa/disable - Disable 2FA
 */
router.post('/2fa/disable', authenticate, async (req, res) => {
  try {
    const { currentPassword } = req.body;

    if (!currentPassword) {
      return res.status(400).json({ message: 'Current password is required' });
    }

    const user = await User.findById(req.userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Verify current password
    const isValidPassword = await bcrypt.compare(currentPassword, user.password);
    if (!isValidPassword) {
      return res.status(400).json({ message: 'Invalid current password' });
    }

    // Disable 2FA (in security object)
    if (!user.security) user.security = {};
    user.security.twoFactorEnabled = false;
    user.security.twoFactorSecret = undefined;
    user.security.twoFactorDisabledAt = new Date();
    user.security.backupCodes = [];
    // Also update root level for backwards compatibility
    user.twoFactorEnabled = false;

    await user.save();

    await logSecurityActivity(req, 'SECURITY_2FA_DISABLED', {
      userId: user._id,
      details: { timestamp: new Date() },
    });

    res.json({ message: '2FA disabled successfully' });
  } catch (error) {
    console.error('[SECURITY API] ❌ Error disabling 2FA:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

/**
 * 🔑 POST /api/users/security/password/change - Change password
 */
router.post('/password/change', authenticate, async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;

    if (!currentPassword || !newPassword) {
      return res.status(400).json({ message: 'Current password and new password are required' });
    }

    if (newPassword.length < 8) {
      return res.status(400).json({ message: 'New password must be at least 8 characters long' });
    }

    const user = await User.findById(req.userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Verify current password
    const isValidPassword = await bcrypt.compare(currentPassword, user.password);
    if (!isValidPassword) {
      return res.status(400).json({ message: 'Invalid current password' });
    }

    // Hash new password
    const hashedPassword = await bcrypt.hash(newPassword, 10);

    // Update password (store in both locations for compatibility)
    user.password = hashedPassword;
    if (!user.security) user.security = {};
    user.security.lastPasswordChange = new Date();
    user.security.passwordChangeCount = (user.security.passwordChangeCount || 0) + 1;
    // Also update root level
    user.lastPasswordChange = new Date();
    user.passwordChangeCount = (user.passwordChangeCount || 0) + 1;

    await user.save();

    await logSecurityActivity(req, 'SECURITY_PASSWORD_CHANGED', {
      userId: user._id,
      details: { timestamp: new Date() },
    });

    res.json({ message: 'Password changed successfully' });
  } catch (error) {
    console.error('[SECURITY API] ❌ Error changing password:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

/**
 * 📧 POST /api/users/security/email/request-change - Request email change
 */
router.post('/email/request-change', authenticate, async (req, res) => {
  try {
    const { newEmail, currentPassword } = req.body;

    if (!newEmail || !currentPassword) {
      return res.status(400).json({ message: 'New email and current password are required' });
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(newEmail)) {
      return res.status(400).json({ message: 'Invalid email format' });
    }

    const user = await User.findById(req.userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Verify current password
    const isValidPassword = await bcrypt.compare(currentPassword, user.password);
    if (!isValidPassword) {
      return res.status(400).json({ message: 'Invalid current password' });
    }

    // Check if email is already in use
    const existingUser = await User.findOne({ email: newEmail.toLowerCase() });
    if (existingUser) {
      return res.status(400).json({ message: 'Email is already in use' });
    }

    // Generate verification token
    const token = crypto.randomBytes(32).toString('hex');
    const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 hours

    // Store email change request
    user.emailChangeRequest = {
      newEmail: newEmail.toLowerCase(),
      token,
      expiresAt,
      requestedAt: new Date(),
    };

    await user.save();

    res.json({
      message: 'Email change verification sent to new email address',
      expiresAt,
    });
  } catch (error) {
    console.error('[SECURITY API] ❌ Error requesting email change:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

/**
 * 📱 GET /api/users/security/sessions - Get active sessions
 */
router.get('/sessions', authenticate, async (req, res) => {
  try {
    const user = await User.findById(req.userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    const sessions = user.security?.activeSessions || [];
    
    // Get current request info
    let currentIp = req.ip || req.connection.remoteAddress || req.headers['x-forwarded-for'] || 'Unknown';
    
    // Clean up IP (remove ::ffff: prefix for IPv4-mapped IPv6)
    if (currentIp.startsWith('::ffff:')) {
      currentIp = currentIp.substring(7);
    }
    
    const currentUserAgent = req.headers['user-agent'] || 'Unknown';
    
    // Check if any session needs IP update (for sessions created before this fix)
    let needsUpdate = false;
    for (const session of sessions) {
      const cookieSessionId = req.cookies?.sessionId;
      if (cookieSessionId && session.sessionId === cookieSessionId && !session.ip) {
        session.ip = currentIp;
        session.lastActive = new Date();
        needsUpdate = true;
        console.log('[SECURITY API] 📝 Updated missing IP for current session');
      }
    }
    if (needsUpdate) {
      await user.save();
    }

    // Parse user agent to get browser/OS info and get geolocation
    const formattedSessions = sessions.map(session => {
      const ua = require('ua-parser-js')(session.userAgent || '');
      
      // Get location from IP using geoip-lite
      let location = { country: 'Unknown', city: 'Unknown' };
      let sessionIp = session.ip || 'Unknown';
      
      // Clean up session IP as well
      if (sessionIp.startsWith('::ffff:')) {
        sessionIp = sessionIp.substring(7);
      }
      
      // Try geo lookup, show IP if geo not available
      if (sessionIp && sessionIp !== 'Unknown' && sessionIp !== '127.0.0.1' && sessionIp !== '::1' && !sessionIp.startsWith('192.168.') && !sessionIp.startsWith('10.')) {
        try {
          const geo = geoip.lookup(sessionIp);
          if (geo) {
            location = {
              country: geo.country || sessionIp,
              city: geo.city || 'Unknown'
            };
          } else {
            // Show IP if no geo data available
            location = { country: sessionIp, city: 'Unknown' };
          }
        } catch (geoError) {
          console.warn('[SECURITY API] ⚠️ Geolocation lookup failed for IP:', sessionIp, geoError.message);
          location = { country: sessionIp, city: 'Unknown' };
        }
      } else if (sessionIp === '127.0.0.1' || sessionIp === '::1' || sessionIp?.startsWith('192.168.') || sessionIp?.startsWith('10.')) {
        // Local/private network
        location = { country: 'Local Network', city: sessionIp };
      }
      
      // Improved current session detection - ONLY use sessionId cookie match
      // Removed IP+UA fallback as it causes false positives when multiple sessions 
      // are from the same device/IP
      const cookieSessionId = req.cookies?.sessionId;
      const isCurrent = cookieSessionId && session.sessionId === cookieSessionId;
      
      return {
        sessionId: session.sessionId,
        browser: ua.browser.name || 'Unknown Browser',
        os: ua.os.name || 'Unknown OS',
        device: ua.device.type || 'desktop',
        location: location,
        ip: sessionIp, // Include IP for debugging
        lastActive: session.lastActive,
        isCurrent: isCurrent,
      };
    });

    console.log(`[SECURITY API] ✅ Fetched ${formattedSessions.length} sessions, current IP: ${currentIp}`);
    res.json(formattedSessions);
  } catch (error) {
    console.error('[SECURITY API] ❌ Error fetching sessions:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

/**
 * 🚫 POST /api/users/security/sessions/terminate - Terminate sessions
 */
router.post('/sessions/terminate', authenticate, async (req, res) => {
  try {
    const { sessionIds, terminateAll } = req.body;
    const user = await User.findById(req.userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    if (!user.security || !Array.isArray(user.security.activeSessions)) {
      user.security = user.security || {};
      user.security.activeSessions = [];
    }

    // Get current session from cookie ONLY (no IP+UA fallback)
    const cookieSessionId = req.cookies?.sessionId;
    const currentSessionId = cookieSessionId;

    // Helper function to check if a session is the current one
    const isCurrentSession = (session) => {
      // Only use sessionId cookie match - no IP+UA fallback
      return cookieSessionId && session.sessionId === cookieSessionId;
    };

    if (terminateAll) {
      // Keep only the current session and drop all others
      const initialCount = user.security.activeSessions.length;
      user.security.activeSessions = user.security.activeSessions.filter(isCurrentSession);
      const terminatedCount = initialCount - user.security.activeSessions.length;
      
      await user.save();
      console.log(`[SECURITY API] ✅ Terminated ${terminatedCount} sessions, kept current session`);
      res.json({ 
        message: 'All other sessions terminated successfully',
        terminatedCount
      });
    } else if (sessionIds && Array.isArray(sessionIds) && sessionIds.length > 0) {
      // Check if trying to terminate current session
      const currentSession = user.security.activeSessions.find(isCurrentSession);
      if (currentSession && sessionIds.includes(currentSession.sessionId)) {
        return res.status(400).json({ 
          message: 'Cannot terminate your current session. Please use logout instead.',
          currentSessionId: currentSession.sessionId
        });
      }
      
      // Remove only the selected sessions
      const initialCount = user.security.activeSessions.length;
      user.security.activeSessions = user.security.activeSessions.filter(session => {
        return !sessionIds.includes(session.sessionId);
      });
      const terminatedCount = initialCount - user.security.activeSessions.length;
      
      await user.save();
      console.log(`[SECURITY API] ✅ Terminated ${terminatedCount} specific sessions`);
      res.json({ 
        message: 'Selected sessions terminated successfully',
        terminatedCount
      });
    } else {
      return res.status(400).json({ message: 'Invalid request: provide sessionIds or set terminateAll=true' });
    }

    await logSecurityActivity(req, 'SECURITY_SESSIONS_TERMINATED', {
      details: {
        terminateAll: !!terminateAll,
        sessionIds: sessionIds || [],
        timestamp: new Date(),
      },
    });
  } catch (error) {
    console.error('[SECURITY API] ❌ Error terminating sessions:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});
