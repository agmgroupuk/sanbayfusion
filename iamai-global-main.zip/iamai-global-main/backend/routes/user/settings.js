// Settings Management Routes
// Complete system settings CRUD operations

const express = require('express');
const { Settings } = require('../../critical-models');
const { User } = require('../../models');
const { authenticate } = require('../../auth-middleware');

const router = express.Router();

// Admin middleware
const requireAdmin = async (req, res, next) => {
  try {
    const user = await User.findById(req.userId);
    if (!user || user.tier !== 'ADMIN') {
      return res.status(403).json({
        success: false,
        error: 'Admin access required',
      });
    }
    req.adminUser = user;
    next();
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Failed to verify admin access',
    });
  }
};

// ============================================
// PUBLIC ROUTES (NO AUTH REQUIRED)
// ============================================

/**
 * GET /api/settings/public
 * Get public settings that don't require authentication
 */
router.get('/public', async (req, res) => {
  try {
    const publicSettings = await Settings.find({ isPublic: true });

    const formattedSettings = {};
    publicSettings.forEach(setting => {
      if (!formattedSettings[setting.category]) {
        formattedSettings[setting.category] = {};
      }
      formattedSettings[setting.category][setting.key] = {
        value: setting.value,
        displayName: setting.displayName,
        description: setting.description,
      };
    });

    res.json({
      success: true,
      data: formattedSettings,
    });
  } catch (error) {
    console.error('Public settings fetch error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve public settings',
      message: error.message,
    });
  }
});

/**
 * GET /api/settings/branding
 * Get branding settings for frontend (public)
 */
router.get('/branding', async (req, res) => {
  try {
    const brandingSettings = await Settings.find({
      category: 'branding',
      isPublic: true,
    });

    const branding = {
      siteName: 'IAMAI Global',
      logo: '/logo.png',
      favicon: '/favicon.ico',
      primaryColor: '#2563eb',
      secondaryColor: '#64748b',
      theme: 'light',
    };

    // Override with actual settings
    brandingSettings.forEach(setting => {
      branding[setting.key] = setting.value;
    });

    res.json({
      success: true,
      data: branding,
    });
  } catch (error) {
    console.error('Branding settings fetch error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve branding settings',
      message: error.message,
    });
  }
});

// ============================================
// ADMIN ROUTES (AUTH REQUIRED)
// ============================================

/**
 * GET /api/settings/admin
 * Get all settings (admin only)
 */
router.get('/admin', authenticate, requireAdmin, async (req, res) => {
  try {
    const { category } = req.query;

    const query = category ? { category } : {};
    const settings = await Settings.find(query).sort({ category: 1, key: 1 });

    const formattedSettings = {};
    settings.forEach(setting => {
      if (!formattedSettings[setting.category]) {
        formattedSettings[setting.category] = {};
      }
      formattedSettings[setting.category][setting.key] = setting.toObject();
    });

    res.json({
      success: true,
      data: formattedSettings,
    });
  } catch (error) {
    console.error('Admin settings fetch error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve settings',
      message: error.message,
    });
  }
});

/**
 * GET /api/settings/admin/categories
 * Get all setting categories (admin only)
 */
router.get('/admin/categories', authenticate, requireAdmin, async (req, res) => {
  try {
    const categories = await Settings.distinct('category');

    const categoryInfo = {
      general: { label: 'General', icon: 'settings', description: 'Basic site settings' },
      branding: {
        label: 'Branding',
        icon: 'palette',
        description: 'Logo, colors, and visual identity',
      },
      email: { label: 'Email', icon: 'mail', description: 'Email configuration and templates' },
      payment: {
        label: 'Payment',
        icon: 'credit-card',
        description: 'Payment processing settings',
      },
      security: {
        label: 'Security',
        icon: 'shield',
        description: 'Security and authentication settings',
      },
      ai: {
        label: 'AI Services',
        icon: 'cpu',
        description: 'AI provider and model configurations',
      },
      notifications: {
        label: 'Notifications',
        icon: 'bell',
        description: 'Notification preferences',
      },
      analytics: {
        label: 'Analytics',
        icon: 'bar-chart',
        description: 'Analytics and tracking settings',
      },
      integrations: {
        label: 'Integrations',
        icon: 'link',
        description: 'Third-party service integrations',
      },
      maintenance: {
        label: 'Maintenance',
        icon: 'tool',
        description: 'System maintenance settings',
      },
    };

    const formattedCategories = categories.map(category => ({
      value: category,
      ...(categoryInfo[category] || { label: category, icon: 'folder', description: '' }),
    }));

    res.json({
      success: true,
      data: formattedCategories,
    });
  } catch (error) {
    console.error('Categories fetch error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve categories',
      message: error.message,
    });
  }
});

/**
 * POST /api/settings/admin
 * Create or update setting (admin only)
 */
router.post('/admin', authenticate, requireAdmin, async (req, res) => {
  try {
    const {
      category,
      key,
      value,
      dataType,
      displayName,
      description,
      isPublic = false,
      isRequired = false,
      validation = {},
      changeReason,
    } = req.body;

    // Validation
    if (!category || !key || value === undefined || !dataType || !displayName || !description) {
      return res.status(400).json({
        success: false,
        error: 'Missing required fields',
        required: ['category', 'key', 'value', 'dataType', 'displayName', 'description'],
      });
    }

    // Validate dataType
    const validDataTypes = ['string', 'number', 'boolean', 'object', 'array'];
    if (!validDataTypes.includes(dataType)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid dataType',
        validTypes: validDataTypes,
      });
    }

    // Check if setting exists
    let setting = await Settings.findOne({ category, key });

    if (setting) {
      // Update existing setting
      const previousValue = setting.value;

      setting.value = value;
      setting.dataType = dataType;
      setting.displayName = displayName;
      setting.description = description;
      setting.isPublic = isPublic;
      setting.isRequired = isRequired;
      setting.validation = validation;
      setting.updatedBy = req.userId;
      setting.previousValue = previousValue;
      setting.changeReason = changeReason || 'Updated via admin panel';

      await setting.save();

      res.json({
        success: true,
        message: 'Setting updated successfully',
        data: setting,
      });
    } else {
      // Create new setting
      setting = new Settings({
        category,
        key,
        value,
        dataType,
        displayName,
        description,
        isPublic,
        isRequired,
        validation,
        updatedBy: req.userId,
        changeReason: changeReason || 'Created via admin panel',
      });

      await setting.save();

      res.status(201).json({
        success: true,
        message: 'Setting created successfully',
        data: setting,
      });
    }
  } catch (error) {
    console.error('Setting create/update error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to save setting',
      message: error.message,
    });
  }
});

/**
 * PUT /api/settings/admin/bulk
 * Bulk update settings (admin only)
 */
router.put('/admin/bulk', authenticate, requireAdmin, async (req, res) => {
  try {
    const { settings, changeReason = 'Bulk update via admin panel' } = req.body;

    if (!Array.isArray(settings)) {
      return res.status(400).json({
        success: false,
        error: 'Settings must be an array',
      });
    }

    const results = [];
    const errors = [];

    for (const settingData of settings) {
      try {
        const { category, key, value } = settingData;

        if (!category || !key || value === undefined) {
          errors.push({
            setting: settingData,
            error: 'Missing required fields (category, key, value)',
          });
          continue;
        }

        const setting = await Settings.findOne({ category, key });

        if (setting) {
          const previousValue = setting.value;
          setting.value = value;
          setting.updatedBy = req.userId;
          setting.previousValue = previousValue;
          setting.changeReason = changeReason;

          await setting.save();
          results.push({ category, key, status: 'updated' });
        } else {
          errors.push({
            setting: settingData,
            error: 'Setting not found',
          });
        }
      } catch (error) {
        errors.push({
          setting: settingData,
          error: error.message,
        });
      }
    }

    res.json({
      success: errors.length === 0,
      message: `Updated ${results.length} settings${errors.length > 0 ? ` with ${errors.length} errors` : ''}`,
      data: {
        updated: results,
        errors: errors,
      },
    });
  } catch (error) {
    console.error('Bulk settings update error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to bulk update settings',
      message: error.message,
    });
  }
});

/**
 * DELETE /api/settings/admin/:category/:key
 * Delete setting (admin only)
 */
router.delete('/admin/:category/:key', authenticate, requireAdmin, async (req, res) => {
  try {
    const { category, key } = req.params;

    const setting = await Settings.findOne({ category, key });

    if (!setting) {
      return res.status(404).json({
        success: false,
        error: 'Setting not found',
      });
    }

    if (setting.isRequired) {
      return res.status(400).json({
        success: false,
        error: 'Cannot delete required setting',
      });
    }

    await Settings.deleteOne({ category, key });

    res.json({
      success: true,
      message: 'Setting deleted successfully',
    });
  } catch (error) {
    console.error('Setting deletion error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to delete setting',
      message: error.message,
    });
  }
});

/**
 * POST /api/settings/admin/reset/:category
 * Reset category to default values (admin only)
 */
router.post('/admin/reset/:category', authenticate, requireAdmin, async (req, res) => {
  try {
    const { category } = req.params;

    // Define default settings for each category
    const defaultSettings = {
      general: [
        {
          key: 'siteName',
          value: 'IAMAI Global',
          dataType: 'string',
          displayName: 'Site Name',
          description: 'The name of your site',
          isPublic: true,
        },
        {
          key: 'siteDescription',
          value: 'Advanced AI Multi-Agent Platform',
          dataType: 'string',
          displayName: 'Site Description',
          description: 'Brief description of your site',
          isPublic: true,
        },
        {
          key: 'adminEmail',
          value: 'admin@iamai-global.com',
          dataType: 'string',
          displayName: 'Admin Email',
          description: 'Main admin contact email',
          isRequired: true,
        },
        {
          key: 'maintenanceMode',
          value: false,
          dataType: 'boolean',
          displayName: 'Maintenance Mode',
          description: 'Enable maintenance mode',
          isPublic: true,
        },
      ],
      branding: [
        {
          key: 'logo',
          value: '/logo.png',
          dataType: 'string',
          displayName: 'Logo URL',
          description: 'Main logo image URL',
          isPublic: true,
        },
        {
          key: 'favicon',
          value: '/favicon.ico',
          dataType: 'string',
          displayName: 'Favicon URL',
          description: 'Favicon image URL',
          isPublic: true,
        },
        {
          key: 'primaryColor',
          value: '#2563eb',
          dataType: 'string',
          displayName: 'Primary Color',
          description: 'Main brand color',
          isPublic: true,
        },
        {
          key: 'secondaryColor',
          value: '#64748b',
          dataType: 'string',
          displayName: 'Secondary Color',
          description: 'Secondary brand color',
          isPublic: true,
        },
      ],
      security: [
        {
          key: 'sessionTimeout',
          value: 24,
          dataType: 'number',
          displayName: 'Session Timeout (hours)',
          description: 'User session timeout in hours',
          isRequired: true,
        },
        {
          key: 'maxLoginAttempts',
          value: 5,
          dataType: 'number',
          displayName: 'Max Login Attempts',
          description: 'Maximum failed login attempts before lockout',
          isRequired: true,
        },
        {
          key: 'lockoutDuration',
          value: 15,
          dataType: 'number',
          displayName: 'Lockout Duration (minutes)',
          description: 'Account lockout duration in minutes',
          isRequired: true,
        },
      ],
    };

    if (!defaultSettings[category]) {
      return res.status(400).json({
        success: false,
        error: 'Invalid category or no defaults available',
      });
    }

    // Delete existing settings in category
    await Settings.deleteMany({ category });

    // Create default settings
    const newSettings = defaultSettings[category].map(setting => ({
      ...setting,
      category,
      updatedBy: req.userId,
      changeReason: 'Reset to defaults',
    }));

    await Settings.insertMany(newSettings);

    res.json({
      success: true,
      message: `${category} settings reset to defaults`,
      data: newSettings,
    });
  } catch (error) {
    console.error('Settings reset error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to reset settings',
      message: error.message,
    });
  }
});

/**
 * GET /api/settings/admin/history/:category/:key
 * Get setting change history (admin only)
 */
router.get('/admin/history/:category/:key', authenticate, requireAdmin, async (req, res) => {
  try {
    const { category, key } = req.params;

    // Get current setting
    const currentSetting = await Settings.findOne({ category, key });

    if (!currentSetting) {
      return res.status(404).json({
        success: false,
        error: 'Setting not found',
      });
    }

    // For full history, you'd need to implement a separate changes log
    // For now, return basic info
    const history = [
      {
        timestamp: currentSetting.updatedAt,
        value: currentSetting.value,
        previousValue: currentSetting.previousValue,
        updatedBy: currentSetting.updatedBy,
        reason: currentSetting.changeReason,
      },
    ];

    res.json({
      success: true,
      data: {
        setting: {
          category: currentSetting.category,
          key: currentSetting.key,
          displayName: currentSetting.displayName,
        },
        history: history,
      },
    });
  } catch (error) {
    console.error('Setting history error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve setting history',
      message: error.message,
    });
  }
});

module.exports = router;
