/**
 * 👤 User Routes - Backend API
 * Centralized user-related routes including dashboard, profile, and settings
 */

const express = require('express');
const router = express.Router();

// Import individual route modules
const dashboardRoutes = require('./dashboard');
const profileRoutes = require('./profile');
const settingsRoutes = require('./settings');
const dashboardCompatibilityRoutes = require('./dashboardCompatibility');

// Mount routes
router.use('/dashboard', dashboardRoutes);
router.use('/profile', profileRoutes);
router.use('/settings', settingsRoutes);
router.use('/compatibility', dashboardCompatibilityRoutes);

module.exports = router;
