/**
 * Frontend Compatibility Layer
 * Provides data in the format expected by current dashboard components
 */

const { ActivityLog } = require('../../models');
const mongoose = require('mongoose');

/**
 * Format sessions data for current frontend dashboard
 */
function formatSessionsForCurrentDashboard(enhancedSessions) {
  return enhancedSessions.map(session => ({
    id: session.id,
    device: session.device.name,
    browser: session.device.browser,
    os: session.device.os,
    location: session.location.display,
    ip: session.ip,
    lastActive: session.lastActive,
    isCurrent: session.isCurrent,
    flag: session.location.flag
  }));
}

/**
 * Format activity data for current frontend dashboard
 */
function formatActivityForCurrentDashboard(activities) {
  return activities.map(activity => {
    const detailSummary =
      (typeof activity.details === 'string' && activity.details) ||
      activity.details?.description ||
      activity.details?.route ||
      activity.details?.message ||
      activity.action ||
      'Activity';

    return {
      id: activity._id || activity.id,
      type: activity.action,
      action: activity.action,
      timestamp: activity.createdAt || activity.timestamp,
      details: detailSummary,
      description: detailSummary,
      ipAddress: activity.ipAddress || null,
      userAgent: activity.userAgent || null,
      category: activity.category || 'system',
      result: activity.result || 'success',
      severity: activity.severity || 'low',
      metadata: activity.metadata || {},
    };
  });
}

/**
 * Get sessions in current dashboard format
 * GET /api/users/sessions
 */
async function getSessionsCompatible(req, res) {
  try {
    const { getEnhancedSessions } = require('./enhancedSecurity');
    
    // Get enhanced sessions data
    const mockRes = {
      json: (data) => data,
      status: (code) => ({ json: (data) => ({ ...data, statusCode: code }) })
    };
    
    const enhancedData = await new Promise((resolve, reject) => {
      const mockReq = { ...req };
      const mockResponse = {
        json: resolve,
        status: (code) => ({
          json: (data) => resolve({ ...data, statusCode: code })
        })
      };
      
      getEnhancedSessions(mockReq, mockResponse).catch(reject);
    });
    
    if (enhancedData.statusCode >= 400) {
      return res.status(enhancedData.statusCode).json(enhancedData);
    }
    
    const sessions = formatSessionsForCurrentDashboard(enhancedData.data.sessions);
    
    res.json({
      success: true,
      sessions: sessions,
      total: sessions.length,
      summary: enhancedData.data.summary
    });
  } catch (error) {
    console.error('Sessions compatibility error:', error);
    res.status(500).json({
      success: false,
      sessions: [],
      total: 0,
      error: 'Failed to fetch sessions'
    });
  }
}

/**
 * Get activity in current dashboard format
 * GET /api/users/activity
 * Supports query params: page, limit, startDate, action
 */
async function getActivityCompatible(req, res) {
  try {
    const { page = 1, limit = 50, startDate, action } = req.query;
    const userId = req.userId;

    // Convert userId to ObjectId for proper matching
    let userObjectId;
    try {
      userObjectId = new mongoose.Types.ObjectId(userId);
    } catch (e) {
      userObjectId = userId; // fallback if already ObjectId
    }

    // Build query
    const query = { userId: userObjectId };

    // Date filtering
    if (startDate) {
      query.createdAt = { $gte: new Date(startDate) };
    }

    // Action type filtering - THIS IS THE KEY FIX
    if (action && action !== 'all') {
      query.action = action;
    }

    console.log(`[ACTIVITY API] Query:`, JSON.stringify(query));

    // Pagination
    const skip = (parseInt(page) - 1) * parseInt(limit);
    const limitNum = parseInt(limit);

    // Get total count
    const total = await ActivityLog.countDocuments(query);

    // Get activity logs
    const activities = await ActivityLog.find(query)
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limitNum)
      .select('action category details result errorMessage ipAddress userAgent referrer metadata severity createdAt');

    // Format for frontend
    const formattedActivities = formatActivityForCurrentDashboard(activities);

    const totalPages = Math.ceil(total / limitNum);

    console.log(`[ACTIVITY API] ✅ Found ${activities.length} activities for user ${userId}, action filter: ${action || 'all'}`);

    res.json({
      success: true,
      activity: formattedActivities,
      data: formattedActivities,
      total,
      pagination: {
        page: parseInt(page),
        limit: limitNum,
        total,
        pages: totalPages,
        hasNext: parseInt(page) < totalPages,
        hasPrev: parseInt(page) > 1,
      },
    });
  } catch (error) {
    console.error('Activity compatibility error:', error);
    res.status(500).json({
      success: false,
      activity: [],
      data: [],
      total: 0,
      error: 'Failed to fetch activity'
    });
  }
}

module.exports = {
  getSessionsCompatible,
  getActivityCompatible,
  formatSessionsForCurrentDashboard,
  formatActivityForCurrentDashboard
};