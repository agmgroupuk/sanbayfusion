// Dashboard Analytics API Routes - OverviewSection.tsx Support
// Implements /api/dashboard/stats and /api/dashboard/analytics endpoints

const express = require('express');
const router = express.Router();
const { User, UsageAnalytics, ActivityLog } = require('../../models');
const { AgentPurchase } = require('../../agent-purchase-models');
const { authenticate } = require('../../auth-middleware');

// ============================================
// DASHBOARD STATS ENDPOINT (CRITICAL)
// ============================================

// GET /api/dashboard/stats - OverviewSection.tsx expects this endpoint
router.get('/stats', authenticate, async (req, res) => {
  try {
    console.log('Dashboard stats - req.user:', req.user);
    console.log('Dashboard stats - req.userId:', req.userId);
    const userId = req.userId; // Use req.userId directly since it's set in auth middleware
    console.log('Dashboard stats - using userId:', userId);

    // Get user data from User model for basic stats
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ success: false, error: 'User not found' });
    }

    // Load active purchases for this user - ONLY purchased agents should count
    const now = new Date();
    const activePurchases = await AgentPurchase.find({
      userId,
      $or: [
        { status: 'ACTIVE', expiresAt: { $gt: now } },
        { status: 'active', expirationDate: { $gt: now } },
      ],
    })
      .select('agentId')
      .lean();

    const activeAgentIds = [...new Set(activePurchases.map(purchase => purchase.agentId))];

    // If user has no active purchases, return zeroed stats but keep structure
    if (activeAgentIds.length === 0) {
      const emptyDailyUsage = [];
      const today = new Date();
      for (let i = 6; i >= 0; i--) {
        const date = new Date(today);
        date.setDate(date.getDate() - i);
        const dateString = date.toISOString().split('T')[0];
        emptyDailyUsage.push({
          date: dateString,
          messages: 0,
          sessions: 0,
        });
      }

      return res.json({
        success: true,
        stats: {
          totalMessages: 0,
          activeAgents: 0,
          avgResponseTime: 1.2,
          successRate: 100,
        },
        dailyUsage: emptyDailyUsage,
        agentUsage: [],
      });
    }

    // Calculate real stats from ActivityLog, filtered to purchased agents only
    const monthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);

    // Get message count from activity logs
    const messageActivities = await ActivityLog.countDocuments({
      userId,
      action: { $in: ['AI_CHAT_MESSAGE', 'DEMO_CHAT_MESSAGE'] },
      'metadata.agentId': { $in: activeAgentIds },
      createdAt: { $gte: monthAgo },
    });

    // Get active agents count from active purchases only
    const activeAgents = activeAgentIds.length;

    // Calculate average response time from activity logs
    const responseTimeActivities = await ActivityLog.find({
      userId,
      action: 'AI_CHAT_MESSAGE',
      'metadata.agentId': { $in: activeAgentIds },
      responseTime: { $exists: true, $ne: null },
    })
      .limit(100)
      .select('responseTime');

    const avgResponseTime =
      responseTimeActivities.length > 0
        ? responseTimeActivities.reduce((sum, act) => sum + (act.responseTime || 0), 0) /
          responseTimeActivities.length /
          1000 // Convert to seconds
        : 1.2;

    // Calculate success rate (messages without errors)
    const totalMessages = await ActivityLog.countDocuments({
      userId,
      action: { $in: ['AI_CHAT_MESSAGE', 'DEMO_CHAT_MESSAGE'] },
      'metadata.agentId': { $in: activeAgentIds },
      createdAt: { $gte: monthAgo },
    });

    const errorMessages = await ActivityLog.countDocuments({
      userId,
      action: 'ERROR',
      'metadata.agentId': { $in: activeAgentIds },
      createdAt: { $gte: monthAgo },
    });

    const successRate =
      totalMessages > 0 ? ((totalMessages - errorMessages) / totalMessages) * 100 : 99.9;

    // Calculate dashboard stats in the format OverviewSection expects
    const stats = {
      totalMessages: Math.max(user.totalMessages || 0, messageActivities),
      activeAgents: Math.max(user.activeAgents || 0, activeAgents),
      avgResponseTime: Math.round(avgResponseTime * 100) / 100, // Round to 2 decimal places
      successRate: Math.round(successRate * 10) / 10, // Round to 1 decimal place
    };

    // Generate daily usage data (last 7 days)
    const dailyUsage = [];
    const today = new Date();
    for (let i = 6; i >= 0; i--) {
      const date = new Date(today);
      date.setDate(date.getDate() - i);
      const dateString = date.toISOString().split('T')[0];

      // Check activity logs for this date, restricted to purchased agents
      const dayStart = new Date(dateString);
      const dayEnd = new Date(dayStart);
      dayEnd.setDate(dayEnd.getDate() + 1);

      const dayMessages = await ActivityLog.countDocuments({
        userId,
        action: { $in: ['AI_CHAT_MESSAGE', 'DEMO_CHAT_MESSAGE'] },
        'metadata.agentId': { $in: activeAgentIds },
        createdAt: { $gte: dayStart, $lt: dayEnd },
      });

      const daySessions = await ActivityLog.distinct('sessionId', {
        userId,
        action: 'AI_CHAT_START',
        'metadata.agentId': { $in: activeAgentIds },
        createdAt: { $gte: dayStart, $lt: dayEnd },
      });

      dailyUsage.push({
        date: dateString,
        messages: dayMessages,
        sessions: daySessions.length,
      });
    }

    // Generate agent usage data from user data and analytics
    const agentUsage = [];
    if (user.customAgents && user.customAgents.length > 0) {
      for (const agent of user.customAgents) {
        // Only include agents the user has an active purchase for
        if (!activeAgentIds.includes(agent.id)) continue;

        // Get usage for this agent from analytics
        const agentMessages = await ActivityLog.countDocuments({
          userId,
          action: 'AI_CHAT_MESSAGE',
          'metadata.agentId': agent.id,
          createdAt: { $gte: monthAgo },
        });

        agentUsage.push({
          agentId: agent.id,
          name: agent.name,
          messages: agentMessages,
          sessions: Math.floor(agentMessages / 5), // Estimate sessions
        });
      }
    }

    res.json({
      success: true,
      stats,
      dailyUsage,
      agentUsage,
    });
  } catch (error) {
    console.error('Dashboard stats error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch dashboard stats',
    });
  }
});

// ============================================
// DASHBOARD ANALYTICS ENDPOINT (CRITICAL)
// ============================================

// GET /api/dashboard/analytics - Advanced analytics for OverviewSection.tsx
router.get('/analytics', authenticate, async (req, res) => {
  try {
    const userId = req.userId; // Use req.userId directly since it's set in auth middleware
    const { period = 'month', agentId } = req.query;

    // Calculate date ranges
    const now = new Date();
    let startDate;

    switch (period) {
      case 'week': {
        startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        break;
      }
      case 'month': {
        startDate = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
        break;
      }
      case 'year': {
        startDate = new Date(now.getTime() - 365 * 24 * 60 * 60 * 1000);
        break;
      }
      default: {
        startDate = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
      }
    }

    // Load active purchases and determine which agents should be included
    const activePurchases = await AgentPurchase.find({
      userId,
      status: 'active',
      expirationDate: { $gt: now },
    })
      .select('agentId')
      .lean();

    let activeAgentIds = [...new Set(activePurchases.map(purchase => purchase.agentId))];

    // If a specific agentId is requested, restrict to that if it's purchased
    if (agentId) {
      if (!activeAgentIds.includes(agentId)) {
        // Requested agent is not purchased; return empty analytics
        return res.json({
          success: true,
          data: {
            timeSeries: [],
            agentBreakdown: [],
            totals: { messages: 0, sessions: 0, timeSpent: 0 },
            growth: { messagesGrowth: 0, sessionsGrowth: 0, timeSpentGrowth: 0 },
            peaks: { bestDay: null, peakHour: null, mostActiveAgent: null },
          },
          period,
          dateRange: { start: startDate, end: now },
        });
      }
      activeAgentIds = [agentId];
    }

    // If user has no active purchases, return empty analytics
    if (activeAgentIds.length === 0) {
      return res.json({
        success: true,
        data: {
          timeSeries: [],
          agentBreakdown: [],
          totals: { messages: 0, sessions: 0, timeSpent: 0 },
          growth: { messagesGrowth: 0, sessionsGrowth: 0, timeSpentGrowth: 0 },
          peaks: { bestDay: null, peakHour: null, mostActiveAgent: null },
        },
        period,
        dateRange: { start: startDate, end: now },
      });
    }

    // Fetch per-message activity for this user and purchased agents only
    const messageActions = ['AI_CHAT_MESSAGE', 'DEMO_CHAT_MESSAGE'];

    const messageLogs = await ActivityLog.find({
      userId,
      action: { $in: messageActions },
      'metadata.agentId': { $in: activeAgentIds },
      createdAt: { $gte: startDate, $lte: now },
    }).select('createdAt metadata.agentId sessionId');

    // Build per-day aggregates
    const toDayString = date => date.toISOString().split('T')[0];

    const dayBuckets = new Map(); // key: YYYY-MM-DD -> { messages, sessions: Set, agentsUsed: Set }

    const agentStats = {}; // agentId -> stats accumulator

    messageLogs.forEach(log => {
      const dayKey = toDayString(log.createdAt);
      let bucket = dayBuckets.get(dayKey);
      if (!bucket) {
        bucket = { messages: 0, sessions: new Set(), agentsUsed: new Set() };
        dayBuckets.set(dayKey, bucket);
      }

      bucket.messages += 1;
      if (log.sessionId) bucket.sessions.add(String(log.sessionId));
      const agentIdFromLog = log.metadata && log.metadata.agentId;
      if (agentIdFromLog) bucket.agentsUsed.add(agentIdFromLog);

      // Agent-level stats
      if (agentIdFromLog) {
        if (!agentStats[agentIdFromLog]) {
          agentStats[agentIdFromLog] = {
            agentId: agentIdFromLog,
            totalMessages: 0,
            sessions: new Set(),
            totalTime: 0,
            lastUsed: log.createdAt,
          };
        }
        agentStats[agentIdFromLog].totalMessages += 1;
        if (log.sessionId) agentStats[agentIdFromLog].sessions.add(String(log.sessionId));
        agentStats[agentIdFromLog].lastUsed = log.createdAt;
      }
    });

    // Build ordered time series from startDate to now
    const timeSeries = [];
    const cursor = new Date(startDate);
    while (cursor <= now) {
      const key = toDayString(cursor);
      const bucket = dayBuckets.get(key);
      timeSeries.push({
        date: key,
        messages: bucket ? bucket.messages : 0,
        sessions: bucket ? bucket.sessions.size : 0,
        timeSpent: 0,
        agentsUsed: bucket ? bucket.agentsUsed.size : 0,
      });

      cursor.setDate(cursor.getDate() + 1);
    }

    // Totals
    const totals = {
      messages: timeSeries.reduce((sum, day) => sum + day.messages, 0),
      sessions: timeSeries.reduce((sum, day) => sum + day.sessions, 0),
      timeSpent: 0,
    };

    // Map agent IDs to friendly names using purchases + user customAgents
    const user = await User.findById(userId).select('customAgents').lean();
    const agentNameMap = {};

    if (user?.customAgents) {
      user.customAgents.forEach(agent => {
        if (!agentNameMap[agent.id]) {
          agentNameMap[agent.id] = agent.name;
        }
      });
    }

    // activePurchases does not include names; rely on user.customAgents mapping

    const agentBreakdown = Object.values(agentStats).map(stats => ({
      agentId: stats.agentId,
      agentName: agentNameMap[stats.agentId] || stats.agentId,
      totalMessages: stats.totalMessages,
      totalSessions: stats.sessions.size,
      totalTime: stats.totalTime,
      averageRating: 0,
      lastUsed: stats.lastUsed,
    }));

    agentBreakdown.sort((a, b) => b.totalMessages - a.totalMessages);

    // Growth metrics: compare last 7 days vs previous 7 days
    const growth = {
      messagesGrowth: 0,
      sessionsGrowth: 0,
      timeSpentGrowth: 0,
    };

    if (timeSeries.length > 14) {
      const recent = timeSeries.slice(-7);
      const previous = timeSeries.slice(-14, -7);

      const recentAvgMessages =
        recent.reduce((sum, day) => sum + day.messages, 0) / recent.length;
      const previousAvgMessages =
        previous.reduce((sum, day) => sum + day.messages, 0) / previous.length || 1;

      growth.messagesGrowth =
        previousAvgMessages > 0
          ? Number((((recentAvgMessages - previousAvgMessages) / previousAvgMessages) * 100).toFixed(1))
          : 0;
    }

    // Peaks
    const peaks = {
      bestDay: null,
      peakHour: null,
      mostActiveAgent: null,
    };

    if (timeSeries.length > 0) {
      const bestDay = timeSeries.reduce((best, current) =>
        current.messages > best.messages ? current : best
      );

      peaks.bestDay = {
        date: bestDay.date,
        messages: bestDay.messages,
      };
    }

    if (agentBreakdown.length > 0) {
      peaks.mostActiveAgent = agentBreakdown[0];
    }

    const processedData = {
      timeSeries,
      agentBreakdown,
      totals,
      growth,
      peaks,
    };

    res.json({
      success: true,
      data: processedData,
      period,
      dateRange: {
        start: startDate,
        end: now,
      },
    });
  } catch (error) {
    console.error('Dashboard analytics error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch dashboard analytics',
    });
  }
});

// ============================================
// DASHBOARD CONFIGURATION ENDPOINTS
// ============================================

// GET /api/dashboard/config - Get user's dashboard configuration
router.get('/config', authenticate, async (req, res) => {
  try {
    const userId = req.userId; // Use req.userId directly since it's set in auth middleware

    let config = await DashboardConfig.findOne({ userId });
    if (!config) {
      // Create default dashboard config
      config = new DashboardConfig({
        userId,
        widgets: [
          {
            widgetId: 'stats-overview',
            widgetType: 'stats',
            position: { row: 1, col: 1, width: 2, height: 1 },
            isVisible: true,
          },
          {
            widgetId: 'recent-activity',
            widgetType: 'activity',
            position: { row: 1, col: 3, width: 1, height: 2 },
            isVisible: true,
          },
          {
            widgetId: 'subscriptions',
            widgetType: 'subscriptions',
            position: { row: 2, col: 1, width: 2, height: 1 },
            isVisible: true,
          },
        ],
      });
      await config.save();
    }

    res.json({
      success: true,
      data: config,
    });
  } catch (error) {
    console.error('Dashboard config error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch dashboard configuration',
    });
  }
});

// POST /api/dashboard/config - Update dashboard configuration
router.post('/config', authenticate, async (req, res) => {
  try {
    const userId = req.userId; // Use req.userId directly since it's set in auth middleware
    const { widgets, layout, quickActions } = req.body;

    const config = await DashboardConfig.findOneAndUpdate(
      { userId },
      {
        widgets: widgets || [],
        layout: layout || {},
        quickActions: quickActions || [],
      },
      {
        new: true,
        upsert: true,
        runValidators: true,
      }
    );

    res.json({
      success: true,
      data: config,
    });
  } catch (error) {
    console.error('Dashboard config update error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to update dashboard configuration',
    });
  }
});

// ============================================
// USER ACTIVITY FEED ENDPOINT
// ============================================

// GET /api/dashboard/activity-feed - User activity timeline
router.get('/activity-feed', authenticate, async (req, res) => {
  try {
    const userId = req.userId; // Use req.userId directly since it's set in auth middleware
    const { limit = 20, offset = 0, category, type } = req.query;

    // Build query
    const query = { userId };
    if (category) query['activity.category'] = category;
    if (type) query['activity.type'] = type;

    const activities = await ActivityLog.find(query)
      .sort({ timestamp: -1 })
      .limit(parseInt(limit))
      .skip(parseInt(offset))
      .select('activity timestamp relatedEntities');

    const total = await ActivityLog.countDocuments(query);

    res.json({
      success: true,
      data: {
        activities,
        pagination: {
          total,
          limit: parseInt(limit),
          offset: parseInt(offset),
          hasMore: parseInt(offset) + parseInt(limit) < total,
        },
      },
    });
  } catch (error) {
    console.error('Activity feed error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch activity feed',
    });
  }
});

module.exports = router;
