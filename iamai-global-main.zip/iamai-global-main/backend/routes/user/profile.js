/**
 * 👤 User Profile API Routes - Backend support for Dashboard
 *
 * Handles profile data, avatar uploads, stats, and user preferences
 */

const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const fs = require('fs');

// Middleware imports
const { authenticate } = require('../../auth-middleware');
const { User, UserProfile, NotificationSettings, ActivityLog } = require('../../models');

// Configure multer for avatar uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = path.join(__dirname, '..', 'uploads', 'avatars');
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
    cb(null, `avatar-${req.userId}-${uniqueSuffix}${path.extname(file.originalname)}`);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
  fileFilter: (req, file, cb) => {
    const allowedTypes = /jpeg|jpg|png|gif|webp/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);

    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb(new Error('Only image files are allowed!'));
    }
  },
});

/**
 * 🔍 GET /api/users/profile - Get user profile data
 */
router.get('/profile', authenticate, async (req, res) => {
  console.log('[PROFILE API] 📥 GET profile request for user:', req.userId);

  try {
    const user = await User.findById(req.userId).select('-password -refreshTokens');

    if (!user) {
      console.log('[PROFILE API] ❌ User not found:', req.userId);
      return res.status(404).json({ message: 'User not found' });
    }

    console.log('[PROFILE API] ✅ Profile retrieved successfully');
    res.json({
      id: user._id,
      name: user.name,
      firstName: user.firstName,
      lastName: user.lastName,
      email: user.email,
      phone: user.phone,
      bio: user.bio,
      address: user.address,
      city: user.city,
      country: user.country,
      avatar: user.avatar,
      preferences: user.preferences || { language: 'en', timezone: 'UTC', theme: 'dark' },
      notifications: user.notifications || { email: true, sms: false, browser: true },
      createdAt: user.createdAt,
      updatedAt: user.updatedAt,
    });
  } catch (error) {
    console.error('[PROFILE API] ❌ Error fetching profile:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

/**
 * ✏️ PUT /api/users/profile - Update user profile data
 */
router.put('/profile', authenticate, async (req, res) => {
  console.log('[PROFILE API] 📝 PUT profile update for user:', req.userId);
  console.log('[PROFILE API] 📤 Update data:', req.body);

  try {
    const {
      name,
      firstName,
      lastName,
      email,
      phone,
      bio,
      address,
      city,
      country,
      preferences,
      notifications,
    } = req.body;

    // Validate required fields (name is required)
    if (!name || name.trim() === '') {
      return res.status(400).json({ message: 'Name is required' });
    }

    // Email validation only if email is provided (email changes handled in security section)
    if (email) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email)) {
        return res.status(400).json({ message: 'Invalid email format' });
      }

      // Check if email is already taken by another user
      const existingUser = await User.findOne({
        email: email.toLowerCase(),
        _id: { $ne: req.userId },
      });

      if (existingUser) {
        return res.status(400).json({ message: 'Email is already in use by another account' });
      }
    }

    // Update user data
    const updateData = {
      updatedAt: new Date(),
    };

    // Handle name fields - prioritize single name field, then split into first/last
    if (name) {
      updateData.name = name.trim();
      // Also split name into firstName/lastName if not provided separately
      if (!firstName && !lastName) {
        const nameParts = name.trim().split(' ');
        updateData.firstName = nameParts[0];
        updateData.lastName = nameParts.slice(1).join(' ');
      }
    }

    // Update email only if provided (for security page)
    if (email) {
      updateData.email = email.toLowerCase();
    }

    // Update profile fields
    if (firstName !== undefined) updateData.firstName = firstName;
    if (lastName !== undefined) updateData.lastName = lastName;
    if (phone !== undefined) updateData.phone = phone;
    if (bio !== undefined) updateData.bio = bio;
    if (address !== undefined) updateData.address = address;
    if (city !== undefined) updateData.city = city;
    if (country !== undefined) updateData.country = country;
    if (preferences) {
      // Merge preferences with existing ones to avoid overwriting
      updateData.preferences = {
        ...updateData.preferences,
        ...preferences,
      };
      console.log('[PROFILE API] 🎨 Updating preferences:', preferences);
    }
    if (notifications) {
      // Merge notifications with existing ones
      updateData.notifications = {
        ...updateData.notifications,
        ...notifications,
      };
      console.log('[PROFILE API] 🔔 Updating notifications:', notifications);
    }

    const updatedUser = await User.findByIdAndUpdate(req.userId, updateData, {
      new: true,
      runValidators: true,
    }).select('-password -refreshTokens');

    if (!updatedUser) {
      console.log('[PROFILE API] ❌ User not found during update:', req.userId);
      return res.status(404).json({ message: 'User not found' });
    }

    console.log('[PROFILE API] ✅ Profile updated successfully for user:', req.userId);
    res.json({
      message: 'Profile updated successfully',
      user: {
        id: updatedUser._id,
        name: updatedUser.name,
        firstName: updatedUser.firstName,
        lastName: updatedUser.lastName,
        email: updatedUser.email,
        phone: updatedUser.phone,
        bio: updatedUser.bio,
        address: updatedUser.address,
        city: updatedUser.city,
        country: updatedUser.country,
        avatar: updatedUser.avatar,
        preferences: updatedUser.preferences,
        notifications: updatedUser.notifications,
        updatedAt: updatedUser.updatedAt,
      },
    });
  } catch (error) {
    console.error('[PROFILE API] ❌ Error updating profile:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

/**
 * 🖼️ POST /api/users/avatar - Upload user avatar
 */
router.post('/avatar', authenticate, upload.single('avatar'), async (req, res) => {
  console.log('[AVATAR API] 📷 Avatar upload for user:', req.userId);

  try {
    if (!req.file) {
      return res.status(400).json({ message: 'No file uploaded' });
    }

    // Create avatar URL
    const avatarUrl = `/uploads/avatars/${req.file.filename}`;

    // Update user with new avatar
    const updatedUser = await User.findByIdAndUpdate(
      req.userId,
      { avatar: avatarUrl },
      { new: true }
    ).select('avatar');

    console.log('[AVATAR API] ✅ Avatar uploaded successfully:', avatarUrl);
    res.json({
      message: 'Avatar uploaded successfully',
      avatarUrl: avatarUrl,
    });
  } catch (error) {
    console.error('[AVATAR API] ❌ Error uploading avatar:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

/**
 * 🔍 GET /api/users/avatar - Get user avatar URL
 */
router.get('/avatar', authenticate, async (req, res) => {
  try {
    const user = await User.findById(req.userId).select('avatar');

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.json({ avatarUrl: user.avatar || null });
  } catch (error) {
    console.error('[AVATAR API] ❌ Error fetching avatar:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

/**
 * 📊 GET /api/users/stats - Get user usage statistics
 */
router.get('/stats', authenticate, async (req, res) => {
  console.log('[STATS API] 📊 Stats request for user:', req.userId);

  try {
    const user = await User.findById(req.userId);

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Mock stats for now - replace with actual analytics data
    const stats = {
      totalMessages: user.totalMessages || 0,
      messagesThisMonth: user.messagesThisMonth || 0,
      messageLimit: 1000, // Based on subscription
      agentsUsed: user.agentsUsed || 0,
      activeAgents: user.activeAgents || 0,
      avgResponseTime: 1.2, // seconds
      successRate: 95.8, // percentage
      totalSessionTime: user.totalSessionTime || 0,
      lastActiveDate: user.lastActive || new Date().toISOString(),
    };

    console.log('[STATS API] ✅ Stats retrieved successfully');
    res.json(stats);
  } catch (error) {
    console.error('[STATS API] ❌ Error fetching stats:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

/**
 * 🔐 PUT /api/users/password - Update user password
 */
router.put('/password', authenticate, async (req, res) => {
  console.log('[PASSWORD API] 🔐 Password update for user:', req.userId);

  try {
    const { currentPassword, newPassword } = req.body;

    // Validate inputs
    if (!oldPassword || !newPassword) {
      return res.status(400).json({ message: 'Old and new passwords are required' });
    }

    if (newPassword.length < 6) {
      return res.status(400).json({ message: 'New password must be at least 6 characters long' });
    }

    const user = await User.findById(req.userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Verify old password
    const isValidPassword = await user.comparePassword(oldPassword);
    if (!isValidPassword) {
      return res.status(400).json({ message: 'Current password is incorrect' });
    }

    // Update password
    user.password = newPassword;
    await user.save();

    console.log('[PASSWORD API] ✅ Password updated successfully');
    res.json({ message: 'Password updated successfully' });
  } catch (error) {
    console.error('[PASSWORD API] ❌ Error updating password:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

/**
 * ⚙️ GET /api/users/settings - Get user settings
 */
router.get('/settings', authenticate, async (req, res) => {
  console.log('[SETTINGS API] ⚙️ Fetching settings for user:', req.userId);

  try {
    const userId = req.userId;

    // Get user profile for settings
    const userProfile = await UserProfile.findOne({ userId });

    // Get notification settings
    const notificationSettings = await NotificationSettings.findOne({ userId });

    // Build settings response
    const settings = {
      preferences: userProfile?.preferences || {
        language: 'en',
        timezone: 'UTC',
        theme: 'dark',
        currency: 'USD',
        dateFormat: 'MM/DD/YYYY',
        timeFormat: '12h',
      },
      notifications: notificationSettings || {
        email: true,
        sms: false,
        browser: true,
        chatMessages: true,
        agentUpdates: true,
        billingAlerts: true,
        systemUpdates: true,
        marketingEmails: false,
        securityAlerts: true,
        weeklyReports: false,
      },
      privacy: userProfile?.privacy || {
        profileVisibility: 'private',
        dataCollection: true,
        searchIndexing: false,
        analyticsTracking: true,
        thirdPartySharing: false,
        locationTracking: false,
      },
      security: {
        isSecured: true,
        passwordProtected: true,
        dataEncrypted: true,
        twoFactorEnabled: false,
        sessionTimeout: 30,
        deviceTracking: true,
      },
      lastUpdated: userProfile?.updatedAt || new Date().toISOString(),
      version: 1,
    };

    console.log('[SETTINGS API] ✅ Settings fetched successfully');
    res.json({ settings });
  } catch (error) {
    console.error('[SETTINGS API] ❌ Error fetching settings:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

/**
 * ⚙️ PUT /api/users/preferences - Update user preferences
 */
router.put('/preferences', authenticate, async (req, res) => {
  console.log('[PREFERENCES API] ⚙️ Updating preferences for user:', req.userId);
  console.log('[PREFERENCES API] 📝 Preferences data:', req.body);

  try {
    const userId = req.userId;
    const preferences = req.body;

    if (!preferences || typeof preferences !== 'object') {
      return res.status(400).json({ message: 'Invalid preferences data' });
    }

    // Get current user to merge preferences
    const currentUser = await User.findById(userId);
    if (!currentUser) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Merge new preferences with existing ones
    const mergedPreferences = {
      ...currentUser.preferences,
      ...preferences,
    };

    // Update user preferences in main User model
    const updatedUser = await User.findByIdAndUpdate(
      userId,
      {
        $set: {
          preferences: mergedPreferences,
          updatedAt: new Date(),
        },
      },
      { new: true }
    ).select('-password -refreshTokens');

    if (!updatedUser) {
      return res.status(404).json({ message: 'User not found during update' });
    }

    console.log('[PREFERENCES API] ✅ Preferences updated successfully:', mergedPreferences);
    res.json({
      message: 'Preferences updated successfully',
      preferences: updatedUser.preferences,
    });
  } catch (error) {
    console.error('[PREFERENCES API] ❌ Error updating preferences:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

/**
 * 🔔 PUT /api/users/notifications - Update notification settings
 */
router.put('/notifications', authenticate, async (req, res) => {
  console.log('[NOTIFICATIONS API] 🔔 Updating notifications for user:', req.userId);

  try {
    const userId = req.userId;
    const notifications = req.body;

    // Update notification settings in main User model
    await User.findByIdAndUpdate(
      userId,
      {
        $set: {
          notifications,
          updatedAt: new Date(),
        },
      },
      { new: true }
    );

    console.log('[NOTIFICATIONS API] ✅ Notifications updated successfully');
    res.json({ message: 'Notifications updated successfully' });
  } catch (error) {
    console.error('[NOTIFICATIONS API] ❌ Error updating notifications:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

/**
 * 🔒 GET /api/users/2fa/status - Get 2FA status
 */
router.get('/2fa/status', authenticate, async (req, res) => {
  console.log('[2FA API] 🔒 Checking 2FA status for user:', req.userId);

  try {
    const userId = req.userId;

    // Check if user has 2FA enabled
    const twoFactorAuth = await require('../models').TwoFactorAuth.findOne({ userId });

    res.json({
      enabled: !!twoFactorAuth,
      method: twoFactorAuth?.method || null,
      backupCodesGenerated: twoFactorAuth?.backupCodes?.length > 0 || false,
    });
  } catch (error) {
    console.error('[2FA API] ❌ Error checking 2FA status:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

/**
 * 🔒 PUT /api/users/privacy - Update privacy settings
 */
router.put('/privacy', authenticate, async (req, res) => {
  console.log('[PRIVACY API] 🔒 Updating privacy settings for user:', req.userId);

  try {
    const userId = req.userId;
    const privacy = req.body;

    // Update privacy settings in main User model
    await User.findByIdAndUpdate(
      userId,
      {
        $set: {
          privacy,
          updatedAt: new Date(),
        },
      },
      { new: true }
    );

    console.log('[PRIVACY API] ✅ Privacy settings updated successfully');
    res.json({ message: 'Privacy settings updated successfully' });
  } catch (error) {
    console.error('[PRIVACY API] ❌ Error updating privacy settings:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

/**
 * 📱 GET /api/users/sessions - Get user sessions
 */
router.get('/sessions', authenticate, async (req, res) => {
  console.log('[SESSIONS API] 📱 Fetching sessions for user:', req.userId);

  try {
    const userId = req.userId;

    // Get recent sessions from ActivityLog
    const sessions = await ActivityLog.find({
      userId,
      'activity.type': { $in: ['LOGIN', 'LOGOUT'] },
    })
      .sort({ timestamp: -1 })
      .limit(10)
      .select('activity timestamp ipAddress userAgent');

    // Format sessions
    const formattedSessions = sessions.map(session => ({
      id: session._id,
      device: session.userAgent || 'Unknown Device',
      location: 'Unknown Location', // Could be enhanced with IP geolocation
      ipAddress: session.ipAddress,
      lastActive: session.timestamp,
      current: false, // Mark first as current for demo
    }));

    if (formattedSessions.length > 0) {
      formattedSessions[0].current = true;
    }

    res.json(formattedSessions);
  } catch (error) {
    console.error('[SESSIONS API] ❌ Error fetching sessions:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

/**
 * 📊 GET /api/users/login-activity - Get login activity
 */
router.get('/login-activity', authenticate, async (req, res) => {
  console.log('[LOGIN ACTIVITY API] 📊 Fetching login activity for user:', req.userId);

  try {
    const userId = req.userId;

    // Get login/logout activity
    const activities = await ActivityLog.find({
      userId,
      'activity.type': { $in: ['LOGIN', 'LOGOUT'] },
    })
      .sort({ timestamp: -1 })
      .limit(20)
      .select('activity timestamp ipAddress userAgent');

    // Format activities
    const formattedActivities = activities.map(activity => ({
      id: activity._id,
      action: activity.activity.type === 'LOGIN' ? 'Signed in' : 'Signed out',
      device: activity.userAgent || 'Unknown Device',
      location: 'Unknown Location', // Could be enhanced with IP geolocation
      ipAddress: activity.ipAddress,
      timestamp: activity.timestamp,
      suspicious: false, // Could be enhanced with security checks
    }));

    res.json(formattedActivities);
  } catch (error) {
    console.error('[LOGIN ACTIVITY API] ❌ Error fetching login activity:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

/**
 * 📊 GET /api/users/activity - Get user activity logs with pagination and filtering
 */
router.get('/activity', authenticate, async (req, res) => {
  console.log('[ACTIVITY API] 📊 Fetching activity logs for user:', req.userId);

  try {
    const { page = 1, limit = 50, startDate, endDate, action } = req.query;
    const userId = req.userId;

    // Build query
    const query = { userId };

    // Date filtering
    if (startDate || endDate) {
      query.createdAt = {};
      if (startDate) query.createdAt.$gte = new Date(startDate);
      if (endDate) query.createdAt.$lte = new Date(endDate);
    }

    // Action type filtering
    if (action) {
      query['action'] = action;
    }

    // Pagination
    const skip = (parseInt(page) - 1) * parseInt(limit);
    const limitNum = parseInt(limit);

    // Get total count for pagination
    const total = await ActivityLog.countDocuments(query);

    // Get activity logs (no populate; ActivityLog schema does not define agentId)
    const activities = await ActivityLog.find(query)
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limitNum)
      .select('action category details result errorMessage ipAddress userAgent referrer metadata severity createdAt');

    // Format for frontend using the new ActivityLog schema shape
    const formattedActivities = activities.map(activity => {
      const detailSummary =
        (typeof activity.details === 'string' && activity.details) ||
        activity.details?.description ||
        activity.details?.route ||
        activity.details?.message ||
        activity.action ||
        'Activity';

      return {
        id: activity._id,
        timestamp: activity.createdAt,
        // Keep "type" field for compatibility; frontend also accepts "action" or "type"
        type: activity.action,
        details: detailSummary,
        ipAddress: activity.ipAddress || null,
        userAgent: activity.userAgent || null,
        category: activity.category || 'system',
        result: activity.result || 'success',
        severity: activity.severity || 'low',
        metadata: activity.metadata || {},
      };
    });

    const totalPages = Math.ceil(total / limitNum);

    console.log(`[ACTIVITY API] ✅ Found ${activities.length} activities for user ${userId}`);

    res.json({
      success: true,
      data: formattedActivities,
      pagination: {
        page: parseInt(page),
        limit: limitNum,
        total,
        pages: totalPages,
        hasNext: parseInt(page) < totalPages,
        hasPrev: parseInt(page) > 1,
      },
    });
  } catch (error) {
    console.error('[ACTIVITY API] ❌ Error fetching activity logs:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch activity logs',
      message: error.message,
    });
  }
});

/**
 * 🔐 PUT /api/users/password - Update user password
 */
router.put('/password', authenticate, async (req, res) => {
  console.log('[PASSWORD API] 🔐 Password update for user:', req.userId);

  try {
    const { oldPassword, newPassword } = req.body;

    // Validate inputs
    if (!oldPassword || !newPassword) {
      return res.status(400).json({ message: 'Old and new passwords are required' });
    }

    if (newPassword.length < 6) {
      return res.status(400).json({ message: 'New password must be at least 6 characters long' });
    }

    const user = await User.findById(req.userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Verify old password
    const isValidPassword = await user.comparePassword(oldPassword);
    if (!isValidPassword) {
      return res.status(400).json({ message: 'Current password is incorrect' });
    }

    // Update password
    user.password = newPassword;
    await user.save();

    console.log('[PASSWORD API] ✅ Password updated successfully');
    res.json({ message: 'Password updated successfully' });
  } catch (error) {
    console.error('[PASSWORD API] ❌ Error updating password:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

/**
 * 📊 GET /api/users/activity - Get user activity logs for dashboard
 */
router.get('/activity', authenticate, async (req, res) => {
  console.log('[ACTIVITY API] 📥 GET activity logs for user:', req.userId);

  try {
    const { page = 1, limit = 50, startDate, action } = req.query;

    // Build query
    const query = {
      userId: req.userId, // Only get activities for the authenticated user
    };

    // Add date filter if provided
    if (startDate) {
      query.createdAt = { $gte: new Date(startDate) };
    }

    // Add action filter if provided
    if (action) {
      query.action = action;
    }

    // Calculate pagination
    const skip = (parseInt(page) - 1) * parseInt(limit);

    // Get activities with pagination
    const activities = await ActivityLog.find(query)
      .sort({ createdAt: -1 })
      .limit(parseInt(limit))
      .skip(skip)
      .select('action createdAt metadata route statusCode responseTime location');

    // Get total count for pagination
    const total = await ActivityLog.countDocuments(query);

    // Transform activities to match frontend expectations
    const transformedActivities = activities.map(activity => ({
      id: activity._id,
      timestamp: activity.createdAt.toISOString(),
      agent: getAgentNameFromAction(activity.action),
      agentIcon: getAgentIconFromAction(activity.action),
      type: getActivityTypeFromAction(activity.action),
      details: getActivityDetails(activity),
      metric: activity.responseTime ? `${activity.responseTime}ms` : null,
    }));

    console.log('[ACTIVITY API] ✅ Retrieved', activities.length, 'activities for user');

    res.json({
      success: true,
      data: transformedActivities,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / parseInt(limit)),
      },
    });
  } catch (error) {
    console.error('[ACTIVITY API] ❌ Error fetching activity logs:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch activity logs',
      message: error.message,
    });
  }
});

// Helper functions for activity transformation
function getAgentNameFromAction(action) {
  const agentMap = {
    AI_CHAT_MESSAGE: 'AI Assistant',
    AI_CHAT_START: 'AI Assistant',
    AI_CHAT_END: 'AI Assistant',
    LOGIN_SUCCESS: 'Authentication',
    LOGIN_FAILED: 'Authentication',
    LOGOUT: 'Authentication',
    PROFILE_UPDATE: 'Profile',
    PASSWORD_CHANGE: 'Security',
    EMAIL_CHANGE: 'Security',
    FILE_UPLOAD: 'File Manager',
    API_CALL: 'API Service',
    SUBSCRIPTION_UPGRADE: 'Billing',
    SUBSCRIPTION_CANCEL: 'Billing',
  };
  return agentMap[action] || 'System';
}

function getAgentIconFromAction(action) {
  const iconMap = {
    AI_CHAT_MESSAGE: 'fa-robot',
    AI_CHAT_START: 'fa-robot',
    AI_CHAT_END: 'fa-robot',
    LOGIN_SUCCESS: 'fa-shield-alt',
    LOGIN_FAILED: 'fa-shield-alt',
    LOGOUT: 'fa-shield-alt',
    PROFILE_UPDATE: 'fa-user',
    PASSWORD_CHANGE: 'fa-lock',
    EMAIL_CHANGE: 'fa-envelope',
    FILE_UPLOAD: 'fa-file',
    API_CALL: 'fa-code',
    SUBSCRIPTION_UPGRADE: 'fa-credit-card',
    SUBSCRIPTION_CANCEL: 'fa-credit-card',
  };
  return iconMap[action] || 'fa-cog';
}

function getActivityTypeFromAction(action) {
  const typeMap = {
    AI_CHAT_MESSAGE: 'Message Sent',
    AI_CHAT_START: 'Session Started',
    AI_CHAT_END: 'Session Ended',
    LOGIN_SUCCESS: 'Login',
    LOGIN_FAILED: 'Failed Login',
    LOGOUT: 'Logout',
    PROFILE_UPDATE: 'Profile Update',
    PASSWORD_CHANGE: 'Security',
    EMAIL_CHANGE: 'Security',
    FILE_UPLOAD: 'File Processed',
    API_CALL: 'API Call',
    SUBSCRIPTION_UPGRADE: 'Billing',
    SUBSCRIPTION_CANCEL: 'Billing',
  };
  return typeMap[action] || 'System Alert';
}

module.exports = router;

// Helper function to map backend activity types to frontend types
function mapActivityTypeToFrontend(backendType) {
  const typeMap = {
    CHAT: 'Message Sent',
    FILE: 'File Processed',
    API: 'API Call',
    SYSTEM: 'System Alert',
    LOGIN: 'System Alert',
    LOGOUT: 'System Alert',
    SUBSCRIPTION: 'System Alert',
    PAYMENT: 'System Alert',
    PROFILE_UPDATE: 'System Alert',
  };

  return typeMap[backendType] || 'System Alert';
}

const defaultAgentCapabilities = {
  canAttachFiles: false,
  canUseVoice: false,
  canAccessWeb: false,
};

const defaultPersonalityMatrix = {
  formality: 50,
  humor: 50,
  enthusiasm: 50,
};

const defaultVoicePreferences = {
  defaultGender: 'female',
  allowGenderToggle: true,
};

const normalizeCustomAgent = agent => {
  if (!agent) return null;
  const config = agent.config || {};

  return {
    id: agent.id,
    name: agent.name,
    role: agent.role || config.role || 'Custom Agent',
    description: agent.description || config.description || '',
    icon: agent.icon || config.icon || 'fa-solid fa-robot',
    capabilities: agent.capabilities || config.capabilities || { ...defaultAgentCapabilities },
    personalityMatrix: agent.personalityMatrix ||
      config.personalityMatrix || { ...defaultPersonalityMatrix },
    voicePreferences: agent.voicePreferences ||
      config.voicePreferences || { ...defaultVoicePreferences },
    tags: agent.tags || config.tags || [],
    config,
    createdAt: agent.createdAt,
    updatedAt: agent.updatedAt,
  };
};

/**
 * 🤖 GET /api/users/agents - Get user's custom agents
 */
router.get('/agents', authenticate, async (req, res) => {
  console.log('[AGENTS API] 🤖 Fetching custom agents for user:', req.userId);

  try {
    const user = await User.findById(req.userId).select('customAgents');
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    const normalizedAgents = (user.customAgents || []).map(normalizeCustomAgent).filter(Boolean);

    console.log(`[AGENTS API] ✅ Found ${normalizedAgents.length} custom agents`);
    res.json({
      success: true,
      data: normalizedAgents,
    });
  } catch (error) {
    console.error('[AGENTS API] ❌ Error fetching custom agents:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch custom agents',
      message: error.message,
    });
  }
});

/**
 * 🤖 POST /api/users/agents - Create a new custom agent
 */
router.post('/agents', authenticate, async (req, res) => {
  console.log('[AGENTS API] 🤖 Creating custom agent for user:', req.userId);

  try {
    const {
      name,
      role,
      description,
      icon,
      capabilities,
      personalityMatrix,
      voicePreferences,
      tags,
      config,
    } = req.body;

    if (!name) {
      return res.status(400).json({ message: 'Name is required' });
    }

    const user = await User.findById(req.userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    const normalizedRole = role || config?.role || description || 'Custom Agent';
    const normalizedDescription = description || config?.description || '';
    const normalizedIcon = icon || config?.icon || 'fa-solid fa-robot';

    const newAgent = {
      id: `custom_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      name: name.trim(),
      role: normalizedRole,
      description: normalizedDescription,
      icon: normalizedIcon,
      capabilities: capabilities || config?.capabilities || { ...defaultAgentCapabilities },
      personalityMatrix: personalityMatrix ||
        config?.personalityMatrix || { ...defaultPersonalityMatrix },
      voicePreferences: voicePreferences ||
        config?.voicePreferences || { ...defaultVoicePreferences },
      tags: tags || config?.tags || [],
      config: config || {},
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    if (!user.customAgents) {
      user.customAgents = [];
    }

    user.customAgents.push(newAgent);
    await user.save();

    console.log('[AGENTS API] ✅ Custom agent created:', newAgent.id);
    res.json({
      success: true,
      data: normalizeCustomAgent(newAgent),
      message: 'Custom agent created successfully',
    });
  } catch (error) {
    console.error('[AGENTS API] ❌ Error creating custom agent:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to create custom agent',
      message: error.message,
    });
  }
});

/**
 * 🤖 PUT /api/users/agents/:agentId - Update a custom agent
 */
router.put('/agents/:agentId', authenticate, async (req, res) => {
  console.log('[AGENTS API] 🤖 Updating custom agent:', req.params.agentId);

  try {
    const { agentId } = req.params;
    const {
      name,
      role,
      description,
      icon,
      capabilities,
      personalityMatrix,
      voicePreferences,
      tags,
      config,
    } = req.body;

    const user = await User.findById(req.userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    const agentIndex = user.customAgents?.findIndex(agent => agent.id === agentId);
    if (agentIndex === -1 || agentIndex === undefined) {
      return res.status(404).json({ message: 'Agent not found' });
    }

    const targetAgent = user.customAgents[agentIndex];

    if (name !== undefined) targetAgent.name = name;
    if (role !== undefined) targetAgent.role = role;
    if (description !== undefined) targetAgent.description = description;
    if (icon !== undefined) targetAgent.icon = icon;
    if (capabilities !== undefined) targetAgent.capabilities = capabilities;
    if (personalityMatrix !== undefined) targetAgent.personalityMatrix = personalityMatrix;
    if (voicePreferences !== undefined) targetAgent.voicePreferences = voicePreferences;
    if (tags !== undefined) targetAgent.tags = tags;
    if (config !== undefined) targetAgent.config = config;

    // Ensure essential fallbacks exist for legacy agents
    if (!targetAgent.role) {
      targetAgent.role = targetAgent.config?.role || 'Custom Agent';
    }
    if (!targetAgent.description) {
      targetAgent.description = targetAgent.config?.description || '';
    }
    if (!targetAgent.icon) {
      targetAgent.icon = targetAgent.config?.icon || 'fa-solid fa-robot';
    }
    if (!targetAgent.capabilities) {
      targetAgent.capabilities = targetAgent.config?.capabilities || {
        ...defaultAgentCapabilities,
      };
    }
    if (!targetAgent.personalityMatrix) {
      targetAgent.personalityMatrix = targetAgent.config?.personalityMatrix || {
        ...defaultPersonalityMatrix,
      };
    }
    if (!targetAgent.voicePreferences) {
      targetAgent.voicePreferences = targetAgent.config?.voicePreferences || {
        ...defaultVoicePreferences,
      };
    }

    targetAgent.updatedAt = new Date();

    await user.save();

    console.log('[AGENTS API] ✅ Custom agent updated:', agentId);
    res.json({
      success: true,
      data: normalizeCustomAgent(targetAgent),
      message: 'Custom agent updated successfully',
    });
  } catch (error) {
    console.error('[AGENTS API] ❌ Error updating custom agent:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to update custom agent',
      message: error.message,
    });
  }
});

/**
 * 🤖 DELETE /api/users/agents/:agentId - Delete a custom agent
 */
router.delete('/agents/:agentId', authenticate, async (req, res) => {
  console.log('[AGENTS API] 🤖 Deleting custom agent:', req.params.agentId);

  try {
    const { agentId } = req.params;

    const user = await User.findById(req.userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    const agentIndex = user.customAgents?.findIndex(agent => agent.id === agentId);
    if (agentIndex === -1 || agentIndex === undefined) {
      return res.status(404).json({ message: 'Agent not found' });
    }

    user.customAgents.splice(agentIndex, 1);
    await user.save();

    console.log('[AGENTS API] ✅ Custom agent deleted:', agentId);
    res.json({
      success: true,
      message: 'Custom agent deleted successfully',
    });
  } catch (error) {
    console.error('[AGENTS API] ❌ Error deleting custom agent:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to delete custom agent',
      message: error.message,
    });
  }
});

/**
 * ⚙️ GET /api/users/preferences - Get user preferences/settings
 */
router.get('/preferences', authenticate, async (req, res) => {
  console.log('[PREFERENCES API] ⚙️ Fetching preferences for user:', req.userId);

  try {
    const user = await User.findById(req.userId).select('preferences');
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    console.log('[PREFERENCES API] ✅ Preferences loaded');
    res.json({
      success: true,
      data: user.preferences || {},
    });
  } catch (error) {
    console.error('[PREFERENCES API] ❌ Error fetching preferences:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch preferences',
      message: error.message,
    });
  }
});

/**
 * ⚙️ PUT /api/users/preferences - Update user preferences/settings
 */
router.put('/preferences', authenticate, async (req, res) => {
  console.log('[PREFERENCES API] ⚙️ Updating preferences for user:', req.userId);

  try {
    const preferences = req.body;

    const user = await User.findById(req.userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    user.preferences = { ...user.preferences, ...preferences };
    await user.save();

    console.log('[PREFERENCES API] ✅ Preferences updated');
    res.json({
      success: true,
      data: user.preferences,
      message: 'Preferences updated successfully',
    });
  } catch (error) {
    console.error('[PREFERENCES API] ❌ Error updating preferences:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to update preferences',
      message: error.message,
    });
  }
});

/**
 * 📦 PUT /api/users/preferences/bulk - Bulk update preferences with conflict resolution
 */
router.put('/preferences/bulk', authenticate, async (req, res) => {
  console.log('[BULK PREFERENCES API] 📦 Bulk updating preferences for user:', req.userId);

  try {
    const { preferences, metadata } = req.body;

    if (!preferences || typeof preferences !== 'object') {
      return res.status(400).json({
        success: false,
        message: 'Invalid preferences data',
      });
    }

    const user = await User.findById(req.userId);
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    // Track conflicts and resolutions
    const conflicts = [];
    const originalPreferences = { ...user.preferences };
    let updatedCount = 0;
    let conflictCount = 0;

    // Process each preference update
    for (const [key, newValue] of Object.entries(preferences)) {
      const existingValue = user.preferences[key];

      // Check for conflicts (different values with recent server updates)
      if (existingValue !== undefined && existingValue !== newValue) {
        // Simple conflict resolution: client wins for now
        // In production, this could be more sophisticated
        conflicts.push({
          key,
          localValue: newValue,
          serverValue: existingValue,
          resolution: 'local_wins',
          resolvedValue: newValue,
        });
        conflictCount++;
      }

      user.preferences[key] = newValue;
      updatedCount++;
    }

    // Save all changes atomically
    await user.save();

    // Log the bulk update
    const activityData = {
      userId: req.userId,
      action: 'bulk_preferences_update',
      resourceType: 'user_preferences',
      resourceId: req.userId,
      details: {
        updatedCount,
        conflictCount,
        batchSize: metadata?.batchSize || Object.keys(preferences).length,
        timestamp: new Date().toISOString(),
      },
    };

    // Don't fail the request if activity logging fails
    try {
      await ActivityLog.create(activityData);
    } catch (logError) {
      console.warn('[BULK PREFERENCES API] ⚠️ Failed to log activity:', logError);
    }

    console.log(
      `[BULK PREFERENCES API] ✅ Bulk update completed: ${updatedCount} updates, ${conflictCount} conflicts`
    );

    res.json({
      success: true,
      updatedCount,
      failedCount: 0,
      conflicts,
      data: user.preferences,
      message: `Successfully updated ${updatedCount} preference(s)`,
      metadata: {
        processingTime: Date.now() - (metadata?.timestamp || Date.now()),
        conflictsResolved: conflictCount,
        batchSize: updatedCount,
      },
    });
  } catch (error) {
    console.error('[BULK PREFERENCES API] ❌ Error in bulk update:', error);
    res.status(500).json({
      success: false,
      updatedCount: 0,
      failedCount: Object.keys(req.body.preferences || {}).length,
      conflicts: [],
      errors: [error.message],
      message: 'Bulk preference update failed',
    });
  }
});

module.exports = router;
