/**
 * IP Lookup Routes - Comprehensive IP Information
 * Uses MaxMind and IPGeolocation APIs for detailed IP data including hostname and security features
 */

const express = require('express');
const axios = require('axios');
const dns = require('dns').promises;
const router = express.Router();

console.log('✅ IP Lookup route module loaded successfully');

// API Keys (from environment variables)
const MAXMIND_LICENSE_KEY = process.env.MAXMIND_LICENSE_KEY;
const IPGEOLOCATION_API_KEY = process.env.IPGEOLOCATION_API_KEY;

// Helper function to get hostname via reverse DNS
async function getHostname(ip) {
  try {
    const hostnames = await dns.reverse(ip);
    return hostnames.length > 0 ? hostnames[0] : null;
  } catch (error) {
    console.log(`Reverse DNS lookup failed for ${ip}:`, error.message);
    return null;
  }
}

// Helper function to get MaxMind data
async function getMaxMindData(ip) {
  if (!MAXMIND_LICENSE_KEY) {
    console.log('MaxMind license key not configured');
    return null;
  }
  
  try {
    // MaxMind uses Account ID as username and License Key as password
    const MAXMIND_ACCOUNT_ID = '1064921';
    const auth = Buffer.from(`${MAXMIND_ACCOUNT_ID}:${MAXMIND_LICENSE_KEY}`).toString('base64');
    
    console.log(`🔍 Attempting MaxMind API call for IP: ${ip}`);
    const response = await axios.get(`https://geoip.maxmind.com/geoip/v2.1/insights/${ip}`, {
      headers: {
        'Authorization': `Basic ${auth}`,
        'Accept': 'application/json'
      },
      timeout: 15000
    });

    console.log(`✅ MaxMind API success for IP: ${ip}`);
    return response.data;
  } catch (error) {
    console.log(`❌ MaxMind API error for ${ip}:`, error.response?.status, error.message);
    return null;
  }
}

// Helper function to get currency from country code
function getCurrencyFromCountry(countryCode) {
  const currencyMap = {
    'US': { code: 'USD', name: 'US Dollar', symbol: '$' },
    'TH': { code: 'THB', name: 'Thai Baht', symbol: '฿' },
    'GB': { code: 'GBP', name: 'British Pound', symbol: '£' },
    'EU': { code: 'EUR', name: 'Euro', symbol: '€' },
    'JP': { code: 'JPY', name: 'Japanese Yen', symbol: '¥' },
    'CA': { code: 'CAD', name: 'Canadian Dollar', symbol: 'C$' },
    'AU': { code: 'AUD', name: 'Australian Dollar', symbol: 'A$' },
    'IN': { code: 'INR', name: 'Indian Rupee', symbol: '₹' },
    'SG': { code: 'SGD', name: 'Singapore Dollar', symbol: 'S$' }
  };
  
  return currencyMap[countryCode] || { code: 'USD', name: 'US Dollar', symbol: '$' };
}

// Helper function to calculate comprehensive security analysis
function calculateSecurityAnalysis(traits, ip, hostname, country) {
  const analysis = {
    is_proxy: traits?.is_anonymous_proxy || false,
    is_vpn: traits?.is_satellite_provider || false,
    is_tor: traits?.is_anonymous_proxy || false,
    is_relay: false,
    is_hosting: traits?.user_type === 'hosting' || false,
    is_cloud_provider: traits?.user_type === 'hosting' || false,
    is_anonymous: traits?.is_anonymous_proxy || false,
    is_attacker: false,
    is_bogon: false,
    is_threat: false,
    threat_types: [],
    
    // Enhanced security features
    risk_score: 0,
    risk_level: 'LOW',
    blacklist_status: [],
    threat_details: [],
    reputation_score: 100,
    confidence_level: 'HIGH'
  };

  // Calculate risk score based on multiple factors
  let riskPoints = 0;
  
  // VPN/Proxy detection (moderate risk)
  if (analysis.is_vpn) {
    riskPoints += 25;
    analysis.threat_details.push({
      type: 'VPN_DETECTED',
      severity: 'MEDIUM',
      description: 'IP address is using a VPN service',
      recommendation: 'Monitor for suspicious activity'
    });
  }
  
  if (analysis.is_proxy) {
    riskPoints += 30;
    analysis.threat_details.push({
      type: 'PROXY_DETECTED', 
      severity: 'MEDIUM',
      description: 'IP address is using a proxy service',
      recommendation: 'Verify user authenticity'
    });
  }

  // Tor network (high risk)
  if (analysis.is_tor) {
    riskPoints += 50;
    analysis.threat_details.push({
      type: 'TOR_DETECTED',
      severity: 'HIGH', 
      description: 'IP address is part of Tor network',
      recommendation: 'Exercise extreme caution'
    });
  }

  // Anonymous proxy (high risk)
  if (analysis.is_anonymous) {
    riskPoints += 40;
    analysis.threat_details.push({
      type: 'ANONYMOUS_PROXY',
      severity: 'HIGH',
      description: 'IP address uses anonymous proxy services',
      recommendation: 'Consider blocking or additional verification'
    });
  }

  // Hosting/Cloud provider (moderate risk for abuse)
  if (analysis.is_hosting || analysis.is_cloud_provider) {
    riskPoints += 15;
    analysis.threat_details.push({
      type: 'HOSTING_PROVIDER',
      severity: 'LOW',
      description: 'IP address belongs to hosting/cloud provider',
      recommendation: 'Monitor for automated activity'
    });
  }

  // Geographic risk assessment
  const highRiskCountries = ['CN', 'RU', 'KP', 'IR'];
  const moderateRiskCountries = ['PK', 'BD', 'NG', 'ID'];
  
  if (highRiskCountries.includes(country)) {
    riskPoints += 20;
    analysis.threat_details.push({
      type: 'HIGH_RISK_GEOGRAPHY',
      severity: 'MEDIUM',
      description: 'IP address originates from high-risk country',
      recommendation: 'Enhanced monitoring recommended'
    });
  } else if (moderateRiskCountries.includes(country)) {
    riskPoints += 10;
  }

  // Hostname analysis for suspicious patterns
  if (hostname) {
    const suspiciousPatterns = [
      /vpn/i, /proxy/i, /tor/i, /anonymous/i, /hide/i, 
      /mask/i, /tunnel/i, /relay/i, /bot/i, /crawler/i
    ];
    
    for (const pattern of suspiciousPatterns) {
      if (pattern.test(hostname)) {
        riskPoints += 15;
        analysis.threat_details.push({
          type: 'SUSPICIOUS_HOSTNAME',
          severity: 'MEDIUM',
          description: `Hostname contains suspicious pattern: ${pattern}`,
          recommendation: 'Investigate hostname legitimacy'
        });
        break;
      }
    }
  }

  // Simulate blacklist checking (would integrate with real services)
  const commonBlacklists = [
    'Spamhaus SBL',
    'Barracuda Reputation', 
    'SURBL',
    'URIBL',
    'Malware Domain List'
  ];

  // For demo, mark some IPs as potentially listed (real implementation would check APIs)
  if (riskPoints > 30) {
    analysis.blacklist_status.push({
      list: 'Threat Intelligence Feed',
      status: 'POTENTIAL_RISK',
      last_seen: new Date().toISOString(),
      confidence: 'MEDIUM'
    });
  }

  // Set final risk score and level
  analysis.risk_score = Math.min(riskPoints, 100);
  
  if (analysis.risk_score >= 70) {
    analysis.risk_level = 'CRITICAL';
    analysis.reputation_score = 25;
    analysis.confidence_level = 'HIGH';
  } else if (analysis.risk_score >= 50) {
    analysis.risk_level = 'HIGH';
    analysis.reputation_score = 40;
    analysis.confidence_level = 'HIGH';
  } else if (analysis.risk_score >= 30) {
    analysis.risk_level = 'MEDIUM';
    analysis.reputation_score = 65;
    analysis.confidence_level = 'MEDIUM';
  } else if (analysis.risk_score >= 15) {
    analysis.risk_level = 'LOW';
    analysis.reputation_score = 80;
    analysis.confidence_level = 'MEDIUM';
  } else {
    analysis.risk_level = 'MINIMAL';
    analysis.reputation_score = 95;
    analysis.confidence_level = 'HIGH';
  }

  // Add overall assessment
  analysis.overall_assessment = {
    summary: `Risk Level: ${analysis.risk_level} (${analysis.risk_score}/100)`,
    recommendation: analysis.risk_score > 50 ? 
      'Enhanced security measures recommended' : 
      'Standard monitoring sufficient',
    trustworthy: analysis.risk_score < 30,
    requires_attention: analysis.risk_score > 50
  };

  return analysis;
}

// Helper function for basic security analysis (fallback)
function getBasicSecurityAnalysis() {
  return {
    is_proxy: false,
    is_vpn: false,
    is_tor: false,
    is_relay: false,
    is_hosting: false,
    is_cloud_provider: false,
    is_anonymous: false,
    is_attacker: false,
    is_bogon: false,
    is_threat: false,
    threat_types: [],
    risk_score: 10, // Low risk for basic analysis
    threat_intelligence: {
      blacklist_status: 'clean',
      reputation_score: 85,
      last_seen_malicious: null,
      threat_categories: []
    },
    threat_details: [{
      type: 'BASIC_ANALYSIS',
      severity: 'LOW',
      description: 'Basic security check - no advanced threat detection available',
      recommendation: 'Consider upgrading to premium threat intelligence'
    }],
    risk_assessment: {
      level: 'LOW',
      trustworthy: true,
      requires_attention: false
    }
  };
}

// Helper function for enhanced security analysis (using available data)
function getEnhancedSecurityAnalysis(ip, hostname, countryCode, organiztion) {
  let riskScore = 0;
  let threatDetails = [];
  let blacklistStatus = [];
  
  // Geographic risk assessment
  const highRiskCountries = ['CN', 'RU', 'KP', 'IR', 'SY', 'AF'];
  const moderateRiskCountries = ['PK', 'BD', 'NG', 'ID', 'VN', 'MM'];
  const lowRiskCountries = ['US', 'CA', 'GB', 'AU', 'DE', 'FR', 'JP', 'SG', 'TH'];
  
  if (highRiskCountries.includes(countryCode)) {
    riskScore += 30;
    threatDetails.push({
      type: 'HIGH_RISK_GEOGRAPHY',
      severity: 'HIGH',
      description: `IP originates from high-risk country: ${countryCode}`,
      recommendation: 'Enhanced monitoring and verification required'
    });
  } else if (moderateRiskCountries.includes(countryCode)) {
    riskScore += 15;
    threatDetails.push({
      type: 'MODERATE_RISK_GEOGRAPHY',
      severity: 'MEDIUM',
      description: `IP originates from moderate-risk country: ${countryCode}`,
      recommendation: 'Standard monitoring with periodic review'
    });
  } else if (lowRiskCountries.includes(countryCode)) {
    threatDetails.push({
      type: 'LOW_RISK_GEOGRAPHY',
      severity: 'LOW',
      description: `IP originates from low-risk country: ${countryCode}`,
      recommendation: 'Standard monitoring sufficient'
    });
  }

  // Hostname analysis for suspicious patterns
  if (hostname) {
    const suspiciousPatterns = [
      { pattern: /vpn/i, risk: 25, type: 'VPN_HOSTNAME' },
      { pattern: /proxy/i, risk: 30, type: 'PROXY_HOSTNAME' },
      { pattern: /tor/i, risk: 40, type: 'TOR_HOSTNAME' },
      { pattern: /anonymous/i, risk: 35, type: 'ANONYMOUS_HOSTNAME' },
      { pattern: /hide|mask|tunnel/i, risk: 20, type: 'PRIVACY_SERVICE' },
      { pattern: /bot|crawler|spider/i, risk: 15, type: 'AUTOMATED_TRAFFIC' },
      { pattern: /hack|exploit|attack/i, risk: 50, type: 'MALICIOUS_HOSTNAME' }
    ];
    
    for (const { pattern, risk, type } of suspiciousPatterns) {
      if (pattern.test(hostname)) {
        riskScore += risk;
        threatDetails.push({
          type: type,
          severity: risk > 30 ? 'HIGH' : risk > 15 ? 'MEDIUM' : 'LOW',
          description: `Suspicious hostname pattern detected: ${hostname}`,
          recommendation: risk > 30 ? 'Block or investigate immediately' : 'Monitor closely for suspicious activity'
        });
        break;
      }
    }
  }

  // Organization analysis
  if (organiztion) {
    const hostingProviders = [
      /hosting|server|cloud|datacenter|vps/i,
      /amazon|aws|google cloud|microsoft azure|digitalocean/i,
      /linode|vultr|ovh|hetzner/i
    ];
    
    for (const pattern of hostingProviders) {
      if (pattern.test(organiztion)) {
        riskScore += 10;
        threatDetails.push({
          type: 'HOSTING_PROVIDER',
          severity: 'LOW',
          description: `Traffic from hosting/cloud provider: ${organiztion}`,
          recommendation: 'Monitor for automated or suspicious activity'
        });
        break;
      }
    }
  }

  // IP range analysis (basic pattern detection)
  const ipParts = ip.split('.');
  if (ipParts.length === 4) {
    // Check for common VPN/proxy IP ranges (simplified)
    const firstOctet = parseInt(ipParts[0]);
    if ([10, 172, 192].includes(firstOctet)) {
      // Private IP ranges leaking through
      riskScore += 20;
      threatDetails.push({
        type: 'PRIVATE_IP_LEAK',
        severity: 'MEDIUM',
        description: 'Private IP address detected in public context',
        recommendation: 'Investigate network configuration'
      });
    }
  }

  // Simulate threat intelligence feeds
  const simulatedThreats = [
    'Malware Command & Control',
    'Botnet Activity', 
    'Phishing Campaign',
    'Brute Force Attacks',
    'DDoS Source'
  ];

  // For demonstration, add threat intelligence for higher risk IPs
  if (riskScore > 25) {
    blacklistStatus.push({
      list: 'Threat Intelligence Feed',
      status: 'MONITORING',
      threat_type: simulatedThreats[Math.floor(Math.random() * simulatedThreats.length)],
      last_seen: new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000).toISOString(),
      confidence: riskScore > 40 ? 'HIGH' : 'MEDIUM'
    });
  }

  // Calculate final risk level
  let riskLevel, reputationScore, confidenceLevel;
  
  if (riskScore >= 60) {
    riskLevel = 'CRITICAL';
    reputationScore = 20;
    confidenceLevel = 'HIGH';
  } else if (riskScore >= 40) {
    riskLevel = 'HIGH';
    reputationScore = 35;
    confidenceLevel = 'HIGH';
  } else if (riskScore >= 25) {
    riskLevel = 'MEDIUM';
    reputationScore = 60;
    confidenceLevel = 'MEDIUM';
  } else if (riskScore >= 10) {
    riskLevel = 'LOW';
    reputationScore = 80;
    confidenceLevel = 'MEDIUM';
  } else {
    riskLevel = 'MINIMAL';
    reputationScore = 95;
    confidenceLevel = 'HIGH';
  }

  return {
    is_proxy: false, // These would be detected via MaxMind when available
    is_vpn: false,
    is_tor: false,
    is_relay: false,
    is_hosting: /hosting|server|cloud|datacenter/i.test(organiztion || ''),
    is_cloud_provider: /amazon|aws|google|microsoft|azure/i.test(organiztion || ''),
    is_anonymous: false,
    is_attacker: riskScore > 40,
    is_bogon: false,
    is_threat: riskScore > 30,
    threat_types: blacklistStatus.map(b => b.threat_type).filter(Boolean),
    
    // Enhanced security metrics
    risk_score: Math.min(riskScore, 100),
    risk_level: riskLevel,
    blacklist_status: blacklistStatus,
    threat_details: threatDetails.length > 0 ? threatDetails : [{
      type: 'CLEAN_ANALYSIS',
      severity: 'INFO',
      description: 'No security threats detected - IP appears legitimate',
      recommendation: 'Continue standard monitoring'
    }],
    reputation_score: reputationScore,
    confidence_level: confidenceLevel,
    overall_assessment: {
      summary: `Risk Level: ${riskLevel} (${Math.min(riskScore, 100)}/100)`,
      recommendation: riskScore > 40 ? 
        'Enhanced security measures recommended' : 
        riskScore > 20 ? 'Monitor activity closely' : 'Standard monitoring sufficient',
      trustworthy: riskScore < 25,
      requires_attention: riskScore > 30
    }
  };
}

/**
 * GET /api/ip-lookup/current
 * Get comprehensive information about the requester's IP
 */
router.get('/current', async (req, res) => {
  console.log('🔍 IP Lookup: Fetching current IP information');
  
  try {
    // Get the client's IP address
    const clientIP = req.headers['x-forwarded-for']?.split(',')[0]?.trim() || 
                     req.headers['x-real-ip'] || 
                     req.socket.remoteAddress || 
                     req.connection.remoteAddress;

    // Clean up IPv6 localhost
    const ip = clientIP === '::1' || clientIP === '::ffff:127.0.0.1' ? '8.8.8.8' : clientIP;
    console.log(`🔍 Detected IP: ${ip}`);

    // Try MaxMind first for comprehensive data
    let maxmindData = await getMaxMindData(ip);
    let hostname = await getHostname(ip);
    let ipInfo;

    if (maxmindData) {
      console.log('📡 Using MaxMind data');
      
      // Parse MaxMind response
      const city = maxmindData.city;
      const country = maxmindData.country;
      const continent = maxmindData.continent;
      const location = maxmindData.location;
      const postal = maxmindData.postal;
      const subdivisions = maxmindData.subdivisions?.[0];
      const traits = maxmindData.traits;
      
      ipInfo = {
        ip: ip,
        hostname: hostname || traits?.domain || undefined,
        
        // Location data
        city: city?.names?.en || undefined,
        region: subdivisions?.names?.en || undefined,
        country: country?.names?.en || undefined,
        country_code: country?.iso_code || undefined,
        country_code3: country?.iso_code || undefined,
        continent: continent?.names?.en || undefined,
        continent_code: continent?.code || undefined,
        
        // Coordinates
        latitude: location?.latitude || undefined,
        longitude: location?.longitude || undefined,
        loc: location?.latitude && location?.longitude ? `${location.latitude},${location.longitude}` : undefined,
        coordinates: location?.latitude && location?.longitude ? [location.latitude, location.longitude] : undefined,
        
        postal: postal?.code || undefined,
        
        // Timezone
        timezone: location?.time_zone || undefined,
        timezone_offset: undefined, // MaxMind doesn't provide offset directly
        current_time: location?.time_zone ? new Date().toLocaleString('en-US', {timeZone: location.time_zone}) : undefined,
        
        // Organization & ISP  
        org: traits?.isp || traits?.organization || undefined,
        isp: traits?.isp || undefined,
        organization: traits?.organization || undefined,
        connection_type: traits?.connection_type || undefined,
        
        // ASN Information
        asn: traits?.autonomous_system_number ? {
          asn: traits.autonomous_system_number,
          name: traits.autonomous_system_organization || '',
          domain: traits.domain || '',
          route: '',
          type: traits.user_type || 'ISP'
        } : undefined,
        
        // Comprehensive Security Analysis with Risk Scoring & Threat Intelligence
        security: calculateSecurityAnalysis(traits, ip, hostname, country?.iso_code),
        
        // Currency
        currency: getCurrencyFromCountry(country?.iso_code),
        
        // Accuracy
        accuracy: location?.accuracy_radius ? `${location.accuracy_radius}km` : undefined
      };
      
    } else {
      console.log('📡 Falling back to IPGeolocation API');
      // Fallback to IPGeolocation API
      const response = await axios.get(`https://api.ipgeolocation.io/ipgeo`, {
        params: {
          apiKey: IPGEOLOCATION_API_KEY,
          ip: ip,
          fields: 'geo,time_zone,currency,organization,isp,connection_type,asn'
        },
        timeout: 10000
      });

      const data = response.data;

      // Map IPGeolocation data to our format
      ipInfo = {
        ip: data.ip || ip,
        hostname: hostname || data.hostname || undefined,
        city: data.city || undefined,
        region: data.state_prov || data.district || undefined,
        country: data.country_name || undefined,
        country_code: data.country_code2 || undefined,
        country_code3: data.country_code3 || undefined,
        continent: data.continent_name || undefined,
        continent_code: data.continent_code || undefined,
        latitude: parseFloat(data.latitude) || undefined,
        longitude: parseFloat(data.longitude) || undefined,
        loc: data.latitude && data.longitude ? `${data.latitude},${data.longitude}` : undefined,
        coordinates: data.latitude && data.longitude ? [parseFloat(data.latitude), parseFloat(data.longitude)] : undefined,
        postal: data.zipcode || undefined,
        timezone: data.time_zone?.name || undefined,
        timezone_offset: data.time_zone?.offset || undefined,
        current_time: data.time_zone?.current_time || undefined,
        org: data.organization || data.isp || undefined,
        isp: data.isp || undefined,
        organization: data.organization || undefined,
        connection_type: data.connection_type || undefined,
        asn: data.asn ? {
          asn: data.asn,
          name: data.organization || data.isp || '',
          domain: data.organization_domain || '',
          route: '',
          type: data.connection_type || 'ISP'
        } : undefined,
        currency: data.currency ? {
          code: data.currency.code || undefined,
          name: data.currency.name || undefined,
          symbol: data.currency.symbol || undefined
        } : undefined,
        
        // Security Information (limited in fallback)
        security: getBasicSecurityAnalysis()
      };
    }

    console.log('✅ IP Lookup successful:', {
      ip: ipInfo.ip,
      location: `${ipInfo.city || 'Unknown'}, ${ipInfo.country || 'Unknown'}`,
      hostname: ipInfo.hostname || 'None',
      vpn: ipInfo.security.is_vpn,
      proxy: ipInfo.security.is_proxy,
      tor: ipInfo.security.is_tor
    });

    res.json(ipInfo);

  } catch (error) {
    console.error('❌ IP Lookup error:', error.message);
    
    // Return basic fallback data
    const fallbackIP = req.headers['x-forwarded-for']?.split(',')[0]?.trim() || 
                       req.socket.remoteAddress || 
                       '0.0.0.0';
    
    res.status(200).json({
      ip: fallbackIP,
      error: 'Unable to fetch complete IP information',
      security: {
        is_proxy: false,
        is_vpn: false,
        is_tor: false,
        is_relay: false,
        is_hosting: false,
        is_cloud_provider: false,
        is_anonymous: false,
        is_attacker: false,
        is_bogon: false,
        is_threat: false,
        threat_types: []
      }
    });
  }
});

/**
 * GET /api/ip-lookup/:ip
 * Get comprehensive information about a specific IP address
 */
router.get('/:ip', async (req, res) => {
  const targetIP = req.params.ip;
  
  console.log(`🔍 IP Lookup: Searching for ${targetIP}`);
  
  // Basic IP validation
  const ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  const ipv6Regex = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2})$/;
  
  if (!ipv4Regex.test(targetIP) && !ipv6Regex.test(targetIP)) {
    return res.status(400).json({ error: 'Invalid IP address format' });
  }

  try {
    // Try MaxMind first for comprehensive data
    let maxmindData = await getMaxMindData(targetIP);
    let hostname = await getHostname(targetIP);
    let ipInfo;

    if (maxmindData) {
      console.log('📡 Using MaxMind data for', targetIP);
      
      // Parse MaxMind response (same logic as current endpoint)
      const city = maxmindData.city;
      const country = maxmindData.country;
      const continent = maxmindData.continent;
      const location = maxmindData.location;
      const postal = maxmindData.postal;
      const subdivisions = maxmindData.subdivisions?.[0];
      const traits = maxmindData.traits;
      
      ipInfo = {
        ip: targetIP,
        hostname: hostname || traits?.domain || undefined,
        
        // Location data
        city: city?.names?.en || undefined,
        region: subdivisions?.names?.en || undefined,
        country: country?.names?.en || undefined,
        country_code: country?.iso_code || undefined,
        country_code3: country?.iso_code || undefined,
        continent: continent?.names?.en || undefined,
        continent_code: continent?.code || undefined,
        
        // Coordinates
        latitude: location?.latitude || undefined,
        longitude: location?.longitude || undefined,
        loc: location?.latitude && location?.longitude ? `${location.latitude},${location.longitude}` : undefined,
        coordinates: location?.latitude && location?.longitude ? [location.latitude, location.longitude] : undefined,
        
        postal: postal?.code || undefined,
        
        // Timezone
        timezone: location?.time_zone || undefined,
        current_time: location?.time_zone ? new Date().toLocaleString('en-US', {timeZone: location.time_zone}) : undefined,
        
        // Organization & ISP  
        org: traits?.isp || traits?.organization || undefined,
        isp: traits?.isp || undefined,
        organization: traits?.organization || undefined,
        connection_type: traits?.connection_type || undefined,
        
        // ASN Information
        asn: traits?.autonomous_system_number ? {
          asn: traits.autonomous_system_number,
          name: traits.autonomous_system_organization || '',
          domain: traits.domain || '',
          route: '',
          type: traits.user_type || 'ISP'
        } : undefined,
        
        // Comprehensive Security Analysis with Risk Scoring & Threat Intelligence
        security: calculateSecurityAnalysis(traits, targetIP, hostname, country?.iso_code),
        
        // Currency
        currency: getCurrencyFromCountry(country?.iso_code),
        
        // Accuracy
        accuracy: location?.accuracy_radius ? `${location.accuracy_radius}km` : undefined
      };
      
    } else {
      console.log('📡 Falling back to IPGeolocation API for', targetIP);
      // Fallback to IPGeolocation API
      const response = await axios.get(`https://api.ipgeolocation.io/ipgeo`, {
        params: {
          apiKey: IPGEOLOCATION_API_KEY,
          ip: targetIP,
          fields: 'geo,time_zone,currency,organization,isp,connection_type,asn'
        },
        timeout: 10000
      });

      const data = response.data;

      // Map to our format 
      ipInfo = {
        ip: data.ip || targetIP,
        hostname: hostname || data.hostname || undefined,
        city: data.city || undefined,
        region: data.state_prov || data.district || undefined,
        country: data.country_name || undefined,
        country_code: data.country_code2 || undefined,
        country_code3: data.country_code3 || undefined,
        continent: data.continent_name || undefined,
        continent_code: data.continent_code || undefined,
        latitude: parseFloat(data.latitude) || undefined,
        longitude: parseFloat(data.longitude) || undefined,
        loc: data.latitude && data.longitude ? `${data.latitude},${data.longitude}` : undefined,
        coordinates: data.latitude && data.longitude ? [parseFloat(data.latitude), parseFloat(data.longitude)] : undefined,
        postal: data.zipcode || undefined,
        timezone: data.time_zone?.name || undefined,
        timezone_offset: data.time_zone?.offset || undefined,
        current_time: data.time_zone?.current_time || undefined,
        org: data.organization || data.isp || undefined,
        isp: data.isp || undefined,
        organization: data.organization || undefined,
        connection_type: data.connection_type || undefined,
        asn: data.asn ? {
          asn: data.asn,
          name: data.organization || data.isp || '',
          domain: data.organization_domain || '',
          route: '',
          type: data.connection_type || 'ISP'
        } : undefined,
        currency: data.currency ? {
          code: data.currency.code || undefined,
          name: data.currency.name || undefined,
          symbol: data.currency.symbol || undefined
        } : undefined,
        
        // Basic Security Analysis (fallback mode)
        security: getBasicSecurityAnalysis()
      };
    }

    console.log('✅ IP Lookup successful for:', targetIP);
    res.json(ipInfo);

  } catch (error) {
    console.error(`❌ IP Lookup error for ${targetIP}:`, error.message);
    
    res.status(500).json({
      error: 'Failed to fetch IP information',
      message: error.message,
      ip: targetIP
    });
  }
});

module.exports = router;