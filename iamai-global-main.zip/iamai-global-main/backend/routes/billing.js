// Billing Management Routes
// Advanced invoicing, billing history, and tax management

const express = require('express');
const { InvoiceAdvanced, BillingHistory, PaymentReceipt, TaxRecord } = require('../billing-models');
const { User } = require('../models');
const { authenticate, requireTier, validateFields } = require('../auth-middleware');

const router = express.Router();

// ============================================
// INVOICE ROUTES
// ============================================

/**
 * GET /api/billing/invoices
 * Get user's invoices (alias for /invoices/user)
 */
router.get('/invoices', authenticate, async (req, res) => {
  try {
    const { page = 1, limit = 20, status } = req.query;
    const skip = (page - 1) * limit;

    const query = { 'customer.userId': req.userId };
    if (status) query.status = status;

    const invoices = await InvoiceAdvanced.find(query)
      .sort({ 'details.issueDate': -1 })
      .skip(skip)
      .limit(parseInt(limit))
      .select('-business -audit -metadata');

    const total = await InvoiceAdvanced.countDocuments(query);

    res.json({
      success: true,
      data: {
        invoices,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total,
          pages: Math.ceil(total / limit),
        },
      },
    });
  } catch (error) {
    console.error('User invoices fetch error:', error);
    res.status(500).json({
      error: 'Failed to retrieve invoices',
      message: error.message,
    });
  }
});

/**
 * GET /api/billing/invoices/user
 * Get user's invoices
 */
router.get('/invoices/user', authenticate, async (req, res) => {
  try {
    const { page = 1, limit = 20, status } = req.query;
    const skip = (page - 1) * limit;

    const query = { 'customer.userId': req.userId };
    if (status) query.status = status;

    const invoices = await InvoiceAdvanced.find(query)
      .sort({ 'details.issueDate': -1 })
      .skip(skip)
      .limit(parseInt(limit))
      .select('-business -audit -metadata');

    const total = await InvoiceAdvanced.countDocuments(query);

    res.json({
      success: true,
      data: {
        invoices,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total,
          pages: Math.ceil(total / limit),
        },
      },
    });
  } catch (error) {
    console.error('User invoices fetch error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve invoices',
      message: error.message,
    });
  }
});

/**
 * GET /api/billing/invoices/:invoiceId
 * Get specific invoice details
 */
router.get('/invoices/:invoiceId', authenticate, async (req, res) => {
  try {
    const invoice = await InvoiceAdvanced.findOne({
      _id: req.params.invoiceId,
      'customer.userId': req.userId,
    });

    if (!invoice) {
      return res.status(404).json({
        success: false,
        error: 'Invoice not found',
      });
    }

    res.json({
      success: true,
      data: invoice,
    });
  } catch (error) {
    console.error('Invoice fetch error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve invoice',
      message: error.message,
    });
  }
});

/**
 * GET /api/billing/invoices/:invoiceId/pdf
 * Download invoice PDF
 */
router.get('/invoices/:invoiceId/pdf', authenticate, async (req, res) => {
  try {
    const invoice = await InvoiceAdvanced.findOne({
      _id: req.params.invoiceId,
      'customer.userId': req.userId,
    });

    if (!invoice) {
      return res.status(404).json({
        success: false,
        error: 'Invoice not found',
      });
    }

    // In a real implementation, you would generate or retrieve the PDF
    const pdfUrl =
      invoice.payment.invoicePdf || `/api/billing/invoices/${invoice._id}/generate-pdf`;

    res.json({
      success: true,
      data: {
        pdfUrl,
        invoiceNumber: invoice.invoiceNumber,
        downloadUrl: pdfUrl,
      },
    });
  } catch (error) {
    console.error('Invoice PDF error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve invoice PDF',
      message: error.message,
    });
  }
});

// ============================================
// BILLING HISTORY ROUTES
// ============================================

/**
 * GET /api/billing/history/user
 * Get user's billing history
 */
router.get('/history/user', authenticate, async (req, res) => {
  try {
    const { page = 1, limit = 20, type } = req.query;
    const skip = (page - 1) * limit;

    const query = { userId: req.userId };
    if (type) query['transaction.type'] = type;

    const history = await BillingHistory.find(query)
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit))
      .populate('references.subscriptionId', 'plan status')
      .populate('references.invoiceId', 'invoiceNumber status');

    const total = await BillingHistory.countDocuments(query);

    res.json({
      success: true,
      data: {
        history,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total,
          pages: Math.ceil(total / limit),
        },
      },
    });
  } catch (error) {
    console.error('Billing history fetch error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve billing history',
      message: error.message,
    });
  }
});

/**
 * GET /api/billing/receipts/user
 * Get user's payment receipts
 */
router.get('/receipts/user', authenticate, async (req, res) => {
  try {
    const { page = 1, limit = 20 } = req.query;
    const skip = (page - 1) * limit;

    const receipts = await PaymentReceipt.find({
      'customer.userId': req.userId,
    })
      .sort({ 'payment.paymentDate': -1 })
      .skip(skip)
      .limit(parseInt(limit));

    const total = await PaymentReceipt.countDocuments({ 'customer.userId': req.userId });

    res.json({
      success: true,
      data: {
        receipts,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total,
          pages: Math.ceil(total / limit),
        },
      },
    });
  } catch (error) {
    console.error('Receipts fetch error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve receipts',
      message: error.message,
    });
  }
});

/**
 * GET /api/billing/receipts/:receiptId
 * Get specific receipt
 */
router.get('/receipts/:receiptId', authenticate, async (req, res) => {
  try {
    const receipt = await PaymentReceipt.findOne({
      _id: req.params.receiptId,
      'customer.userId': req.userId,
    });

    if (!receipt) {
      return res.status(404).json({
        success: false,
        error: 'Receipt not found',
      });
    }

    // Update download count
    receipt.delivery.downloadCount += 1;
    receipt.delivery.lastDownloadAt = new Date();
    await receipt.save();

    res.json({
      success: true,
      data: receipt,
    });
  } catch (error) {
    console.error('Receipt fetch error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve receipt',
      message: error.message,
    });
  }
});

// ============================================
// ADMIN ROUTES
// ============================================

/**
 * GET /api/billing/admin/invoices
 * Admin: Get all invoices
 */
router.get('/admin/invoices', authenticate, requireTier(['admin']), async (req, res) => {
  try {
    const { page = 1, limit = 50, status, search } = req.query;
    const skip = (page - 1) * limit;

    const query = {};
    if (status) query.status = status;
    if (search) {
      query.$or = [
        { invoiceNumber: { $regex: search, $options: 'i' } },
        { 'customer.email': { $regex: search, $options: 'i' } },
        { 'customer.name': { $regex: search, $options: 'i' } },
      ];
    }

    const invoices = await InvoiceAdvanced.find(query)
      .sort({ 'details.issueDate': -1 })
      .skip(skip)
      .limit(parseInt(limit))
      .populate('customer.userId', 'email name');

    const total = await InvoiceAdvanced.countDocuments(query);

    res.json({
      success: true,
      data: {
        invoices,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total,
          pages: Math.ceil(total / limit),
        },
      },
    });
  } catch (error) {
    console.error('Admin invoices fetch error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve invoices',
      message: error.message,
    });
  }
});

/**
 * GET /api/billing/admin/stats
 * Admin: Get billing statistics
 */
router.get('/admin/stats', authenticate, requireTier(['admin']), async (req, res) => {
  try {
    const totalInvoices = await InvoiceAdvanced.countDocuments();
    const paidInvoices = await InvoiceAdvanced.countDocuments({ status: 'paid' });
    const overdueInvoices = await InvoiceAdvanced.countDocuments({ status: 'overdue' });

    const revenueStats = await InvoiceAdvanced.aggregate([
      { $match: { status: 'paid' } },
      {
        $group: {
          _id: null,
          totalRevenue: { $sum: '$totals.totalAmount' },
          avgInvoiceValue: { $avg: '$totals.totalAmount' },
        },
      },
    ]);

    const monthlyRevenue = await InvoiceAdvanced.aggregate([
      { $match: { status: 'paid' } },
      {
        $group: {
          _id: {
            year: { $year: '$details.paidDate' },
            month: { $month: '$details.paidDate' },
          },
          revenue: { $sum: '$totals.totalAmount' },
          count: { $sum: 1 },
        },
      },
      { $sort: { '_id.year': -1, '_id.month': -1 } },
      { $limit: 12 },
    ]);

    res.json({
      success: true,
      data: {
        overview: {
          totalInvoices,
          paidInvoices,
          overdueInvoices,
          paymentRate: totalInvoices > 0 ? ((paidInvoices / totalInvoices) * 100).toFixed(2) : 0,
        },
        revenue: {
          total: revenueStats[0]?.totalRevenue || 0,
          average: revenueStats[0]?.avgInvoiceValue || 0,
          monthly: monthlyRevenue,
        },
      },
    });
  } catch (error) {
    console.error('Billing stats error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve billing statistics',
      message: error.message,
    });
  }
});

module.exports = router;
