// Payment Management Routes
// Complete payment processing and transaction management

const express = require('express');
const { Payment, PaymentTransaction, PaymentMethod, BillingCycle } = require('../payment-models');
const { User } = require('../models');
const { authenticate, requireTier, validateFields } = require('../auth-middleware');

const router = express.Router();

// ============================================
// PAYMENT ROUTES
// ============================================

/**
 * POST /api/payments/create
 * Create a new payment
 */
router.post('/create', authenticate, validateFields(['amount', 'currency', 'paymentMethodId']), async (req, res) => {
  try {
    const { amount, currency, paymentMethodId, subscriptionId, description } = req.body;

    const payment = new Payment({
      userId: req.userId,
      amount: {
        total: amount,
        currency: currency || 'USD'
      },
      paymentMethod: {
        id: paymentMethodId,
        type: req.body.paymentMethodType || 'card'
      },
      subscriptionId,
      description: description || 'IAMAI Subscription Payment',
      metadata: {
        source: 'api',
        userAgent: req.get('User-Agent'),
        ipAddress: req.ip
      }
    });

    await payment.save();

    res.json({
      success: true,
      data: payment,
      message: 'Payment created successfully'
    });

  } catch (error) {
    console.error('Payment creation error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to create payment',
      message: error.message
    });
  }
});

/**
 * GET /api/payments/user
 * Get user's payment history
 */
router.get('/user', authenticate, async (req, res) => {
  try {
    const { page = 1, limit = 20, status } = req.query;
    const skip = (page - 1) * limit;
    
    const query = { userId: req.userId };
    if (status) query.status = status;

    const payments = await Payment.find(query)
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit))
      .populate('subscriptionId', 'plan status');

    const total = await Payment.countDocuments(query);

    res.json({
      success: true,
      data: {
        payments,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total,
          pages: Math.ceil(total / limit)
        }
      }
    });

  } catch (error) {
    console.error('Payment history error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve payment history',
      message: error.message
    });
  }
});

/**
 * GET /api/payments/:paymentId
 * Get specific payment details
 */
router.get('/:paymentId', authenticate, async (req, res) => {
  try {
    const payment = await Payment.findOne({
      _id: req.params.paymentId,
      userId: req.userId
    }).populate('subscriptionId');

    if (!payment) {
      return res.status(404).json({
        success: false,
        error: 'Payment not found'
      });
    }

    res.json({
      success: true,
      data: payment
    });

  } catch (error) {
    console.error('Payment fetch error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve payment',
      message: error.message
    });
  }
});

// ============================================
// TRANSACTION ROUTES
// ============================================

/**
 * GET /api/payments/transactions/user
 * Get user's transaction history
 */
router.get('/transactions/user', authenticate, async (req, res) => {
  try {
    const { page = 1, limit = 20, type } = req.query;
    const skip = (page - 1) * limit;
    
    const query = { userId: req.userId };
    if (type) query.type = type;

    const transactions = await PaymentTransaction.find(query)
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit))
      .populate('paymentId', 'amount status');

    const total = await PaymentTransaction.countDocuments(query);

    res.json({
      success: true,
      data: {
        transactions,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total,
          pages: Math.ceil(total / limit)
        }
      }
    });

  } catch (error) {
    console.error('Transaction history error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve transaction history',
      message: error.message
    });
  }
});

// ============================================
// PAYMENT METHOD ROUTES
// ============================================

/**
 * POST /api/payments/methods
 * Add new payment method
 */
router.post('/methods', authenticate, validateFields(['type']), async (req, res) => {
  try {
    const { type, cardDetails, bankDetails, walletDetails } = req.body;

    const paymentMethod = new PaymentMethod({
      userId: req.userId,
      type,
      cardDetails,
      bankDetails,
      walletDetails,
      metadata: {
        addedVia: 'api',
        ipAddress: req.ip
      }
    });

    await paymentMethod.save();

    res.json({
      success: true,
      data: paymentMethod,
      message: 'Payment method added successfully'
    });

  } catch (error) {
    console.error('Payment method creation error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to add payment method',
      message: error.message
    });
  }
});

/**
 * GET /api/payments/methods/user
 * Get user's payment methods
 */
router.get('/methods/user', authenticate, async (req, res) => {
  try {
    const paymentMethods = await PaymentMethod.find({
      userId: req.userId,
      isActive: true
    }).sort({ isDefault: -1, createdAt: -1 });

    res.json({
      success: true,
      data: paymentMethods
    });

  } catch (error) {
    console.error('Payment methods fetch error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve payment methods',
      message: error.message
    });
  }
});

/**
 * DELETE /api/payments/methods/:methodId
 * Delete payment method
 */
router.delete('/methods/:methodId', authenticate, async (req, res) => {
  try {
    const paymentMethod = await PaymentMethod.findOneAndUpdate(
      {
        _id: req.params.methodId,
        userId: req.userId
      },
      { isActive: false },
      { new: true }
    );

    if (!paymentMethod) {
      return res.status(404).json({
        success: false,
        error: 'Payment method not found'
      });
    }

    res.json({
      success: true,
      message: 'Payment method deleted successfully'
    });

  } catch (error) {
    console.error('Payment method deletion error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to delete payment method',
      message: error.message
    });
  }
});

// ============================================
// BILLING CYCLE ROUTES
// ============================================

/**
 * GET /api/payments/billing-cycles/user
 * Get user's billing cycles
 */
router.get('/billing-cycles/user', authenticate, async (req, res) => {
  try {
    const billingCycles = await BillingCycle.find({
      userId: req.userId
    }).sort({ createdAt: -1 })
      .populate('subscriptionId', 'plan status');

    res.json({
      success: true,
      data: billingCycles
    });

  } catch (error) {
    console.error('Billing cycles fetch error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve billing cycles',
      message: error.message
    });
  }
});

// ============================================
// ADMIN ROUTES
// ============================================

/**
 * GET /api/payments/admin/all
 * Admin: Get all payments
 */
router.get('/admin/all', authenticate, requireTier(['admin']), async (req, res) => {
  try {
    const { page = 1, limit = 50, status, userId } = req.query;
    const skip = (page - 1) * limit;
    
    const query = {};
    if (status) query.status = status;
    if (userId) query.userId = userId;

    const payments = await Payment.find(query)
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit))
      .populate('userId', 'email name')
      .populate('subscriptionId', 'plan status');

    const total = await Payment.countDocuments(query);

    res.json({
      success: true,
      data: {
        payments,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total,
          pages: Math.ceil(total / limit)
        }
      }
    });

  } catch (error) {
    console.error('Admin payments fetch error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve payments',
      message: error.message
    });
  }
});

/**
 * PUT /api/payments/admin/:paymentId/status
 * Admin: Update payment status
 */
router.put('/admin/:paymentId/status', authenticate, requireTier(['admin']), async (req, res) => {
  try {
    const { status, reason } = req.body;

    const payment = await Payment.findByIdAndUpdate(
      req.params.paymentId,
      { 
        status,
        'processing.adminNotes': reason,
        'processing.updatedBy': req.userId,
        'processing.updatedAt': new Date()
      },
      { new: true }
    );

    if (!payment) {
      return res.status(404).json({
        success: false,
        error: 'Payment not found'
      });
    }

    res.json({
      success: true,
      data: payment,
      message: 'Payment status updated successfully'
    });

  } catch (error) {
    console.error('Payment status update error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to update payment status',
      message: error.message
    });
  }
});

module.exports = router;