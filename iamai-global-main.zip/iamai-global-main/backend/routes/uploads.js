/**
 * 📁 File Upload API Routes
 * Handle file upload, management, and storage endpoints
 */

const express = require('express');
const router = express.Router();
const fileUploadService = require('../services/file-upload-service');
const { authenticate: authMiddleware } = require('../auth-middleware');
const { query, validationResult } = require('express-validator');

/**
 * Upload single file
 */
router.post(
  '/single',
  authMiddleware,
  fileUploadService.getUploadMiddleware().single('file'),
  async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: 'No file uploaded' });
      }

      const userId = req.user.userId;
      const options = {
        useCloud: req.body.useCloud !== 'false',
        processImage: req.body.processImage !== 'false',
      };

      const result = await fileUploadService.uploadFile(userId, req.file, options);

      res.json(result);
    } catch (error) {
      console.error('Single file upload error:', error);
      res.status(500).json({ error: error.message || 'Failed to upload file' });
    }
  }
);

/**
 * Upload multiple files
 */
router.post(
  '/multiple',
  authMiddleware,
  fileUploadService.getUploadMiddleware().array('files', 10),
  async (req, res) => {
    try {
      if (!req.files || req.files.length === 0) {
        return res.status(400).json({ error: 'No files uploaded' });
      }

      const userId = req.user.userId;
      const options = {
        useCloud: req.body.useCloud !== 'false',
        processImage: req.body.processImage !== 'false',
      };

      const result = await fileUploadService.uploadFiles(userId, req.files, options);

      res.json(result);
    } catch (error) {
      console.error('Multiple files upload error:', error);
      res.status(500).json({ error: error.message || 'Failed to upload files' });
    }
  }
);

/**
 * Get user files
 */
router.get(
  '/',
  authMiddleware,
  [
    query('category').optional().isIn(['image', 'document', 'audio', 'video', 'other']),
    query('limit').optional().isInt({ min: 1, max: 100 }),
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const userId = req.user.userId;
      const options = {
        category: req.query.category,
        limit: parseInt(req.query.limit) || 50,
      };

      const files = await fileUploadService.getUserFiles(userId, options);

      res.json({
        success: true,
        files,
      });
    } catch (error) {
      console.error('Get user files error:', error);
      res.status(500).json({ error: 'Failed to get files' });
    }
  }
);

/**
 * Get specific file
 */
router.get('/:fileId', authMiddleware, async (req, res) => {
  try {
    const { fileId } = req.params;
    const userId = req.user.userId;

    const file = await fileUploadService.getFile(userId, fileId);

    res.json({
      success: true,
      file,
    });
  } catch (error) {
    console.error('Get file error:', error);
    if (error.message === 'File not found') {
      res.status(404).json({ error: 'File not found' });
    } else {
      res.status(500).json({ error: 'Failed to get file' });
    }
  }
});

/**
 * Delete file
 */
router.delete('/:fileId', authMiddleware, async (req, res) => {
  try {
    const { fileId } = req.params;
    const userId = req.user.userId;

    const result = await fileUploadService.deleteFile(userId, fileId);

    res.json(result);
  } catch (error) {
    console.error('Delete file error:', error);
    if (error.message === 'File not found') {
      res.status(404).json({ error: 'File not found' });
    } else {
      res.status(500).json({ error: 'Failed to delete file' });
    }
  }
});

/**
 * Get storage usage
 */
router.get('/usage/statistics', authMiddleware, async (req, res) => {
  try {
    const userId = req.user.userId;
    const usage = await fileUploadService.getStorageUsage(userId);

    res.json({
      success: true,
      usage,
    });
  } catch (error) {
    console.error('Get storage usage error:', error);
    res.status(500).json({ error: 'Failed to get storage usage' });
  }
});

/**
 * Upload avatar/profile image
 */
router.post(
  '/avatar',
  authMiddleware,
  fileUploadService.getUploadMiddleware().single('avatar'),
  async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: 'No avatar file uploaded' });
      }

      // Validate image type
      if (!req.file.mimetype.startsWith('image/')) {
        return res.status(400).json({ error: 'Avatar must be an image file' });
      }

      const userId = req.user.userId;
      const options = {
        useCloud: true, // Always use cloud for avatars
        processImage: true, // Process images for optimization
      };

      const result = await fileUploadService.uploadFile(userId, req.file, options);

      if (result.success) {
        // Update user profile with new avatar URL
        const User = require('../models').User;
        await User.updateOne(
          { _id: userId },
          { avatarUrl: result.file.url, updatedAt: new Date() }
        );
      }

      res.json(result);
    } catch (error) {
      console.error('Avatar upload error:', error);
      res.status(500).json({ error: error.message || 'Failed to upload avatar' });
    }
  }
);

/**
 * Upload document for processing
 */
router.post(
  '/document',
  authMiddleware,
  fileUploadService.getUploadMiddleware().single('document'),
  async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: 'No document uploaded' });
      }

      // Validate document type
      const allowedTypes = [
        'application/pdf',
        'text/plain',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      ];

      if (!allowedTypes.includes(req.file.mimetype)) {
        return res.status(400).json({ error: 'Unsupported document type' });
      }

      const userId = req.user.userId;
      const options = {
        useCloud: true,
        processDocument: true,
      };

      const result = await fileUploadService.uploadFile(userId, req.file, options);

      res.json(result);
    } catch (error) {
      console.error('Document upload error:', error);
      res.status(500).json({ error: error.message || 'Failed to upload document' });
    }
  }
);

/**
 * Bulk delete files
 */
router.delete('/bulk/delete', authMiddleware, async (req, res) => {
  try {
    const { fileIds } = req.body;

    if (!Array.isArray(fileIds) || fileIds.length === 0) {
      return res.status(400).json({ error: 'File IDs array is required' });
    }

    const userId = req.user.userId;
    const results = [];

    for (const fileId of fileIds) {
      try {
        await fileUploadService.deleteFile(userId, fileId);
        results.push({ fileId, success: true });
      } catch (error) {
        results.push({ fileId, success: false, error: error.message });
      }
    }

    res.json({
      success: true,
      results,
      deleted: results.filter(r => r.success).length,
      failed: results.filter(r => !r.success).length,
    });
  } catch (error) {
    console.error('Bulk delete error:', error);
    res.status(500).json({ error: 'Failed to delete files' });
  }
});

/**
 * Get file categories
 */
router.get('/categories/list', async (req, res) => {
  try {
    const categories = [
      { id: 'image', name: 'Images', extensions: ['jpg', 'jpeg', 'png', 'gif', 'webp'] },
      { id: 'document', name: 'Documents', extensions: ['pdf', 'doc', 'docx', 'txt'] },
      { id: 'audio', name: 'Audio', extensions: ['mp3', 'wav', 'ogg'] },
      { id: 'video', name: 'Video', extensions: ['mp4', 'mpeg', 'mov'] },
      { id: 'other', name: 'Other', extensions: [] },
    ];

    res.json({
      success: true,
      categories,
    });
  } catch (error) {
    console.error('Get categories error:', error);
    res.status(500).json({ error: 'Failed to get categories' });
  }
});

module.exports = router;
