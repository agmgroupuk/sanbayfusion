/**
 * Live Support Routes - Real-time AI-powered support with user context
 * Handles chat, document uploads, and ticket creation
 */

const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const fs = require('fs').promises;
const { authenticate } = require('../auth-middleware');
const { getAIService } = require('../ai-service');
const models = require('../models');
const { User, SupportTicket, FileUpload, Agent } = models;

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: async (req, file, cb) => {
    const uploadDir = path.join(__dirname, '../uploads/support');
    try {
      await fs.mkdir(uploadDir, { recursive: true });
      cb(null, uploadDir);
    } catch (error) {
      cb(error, null);
    }
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, `support-${uniqueSuffix}${path.extname(file.originalname)}`);
  }
});

const upload = multer({
  storage: storage,
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = [
      'application/pdf',
      'image/jpeg',
      'image/png',
      'image/gif',
      'text/plain',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    ];
    
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only PDF, images, and documents are allowed.'));
    }
  }
});

/**
 * GET /api/live-support/user-context
 * Fetch comprehensive user context for personalized support
 */
router.get('/user-context', authenticate, async (req, res) => {
  try {
    const userId = req.userId;
    
    // Fetch user profile
    const user = await User.findById(userId)
      .select('name email subscriptionTier subscriptionStatus credits createdAt');
    
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Fetch user's agents
    const agents = await Agent.find({ userId })
      .select('name type createdAt usageCount')
      .sort({ createdAt: -1 })
      .limit(10);

    // Fetch recent support tickets
    const tickets = await SupportTicket.find({ userId })
      .select('caseId category severity status createdAt resolvedAt')
      .sort({ createdAt: -1 })
      .limit(5);

    // Calculate usage stats
    const totalAgents = await Agent.countDocuments({ userId });
    const totalTickets = await SupportTicket.countDocuments({ userId });
    const openTickets = await SupportTicket.countDocuments({ userId, status: { $in: ['open', 'in-progress'] } });

    const context = {
      profile: {
        name: user.name,
        email: user.email,
        subscriptionTier: user.subscriptionTier || 'free',
        subscriptionStatus: user.subscriptionStatus || 'active',
        credits: user.credits || 0,
        memberSince: user.createdAt,
      },
      usage: {
        totalAgents,
        recentAgents: agents.length,
        totalTickets,
        openTickets,
      },
      agents: agents.map(a => ({
        name: a.name,
        type: a.type,
        createdAt: a.createdAt,
        usageCount: a.usageCount || 0,
      })),
      tickets: tickets.map(t => ({
        caseId: t.caseId,
        category: t.category,
        severity: t.severity,
        status: t.status,
        createdAt: t.createdAt,
        resolvedAt: t.resolvedAt,
      })),
    };

    res.json(context);
  } catch (error) {
    console.error('Error fetching user context:', error);
    res.status(500).json({ error: 'Failed to fetch user context' });
  }
});

/**
 * POST /api/live-support/chat
 * Process support chat messages with AI
 */
router.post('/chat', authenticate, async (req, res) => {
  try {
    const { message, documentIds = [], conversationHistory = [] } = req.body;
    const userId = req.userId;

    if (!message || message.trim().length === 0) {
      return res.status(400).json({ error: 'Message is required' });
    }

    // Fetch user context
    const user = await User.findById(userId)
      .select('name email subscriptionTier subscriptionStatus credits');
    
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Fetch agents for context
    const agentCount = await Agent.countDocuments({ userId });
    const recentAgents = await Agent.find({ userId })
      .select('name type')
      .sort({ createdAt: -1 })
      .limit(3);

    // Fetch recent tickets
    const openTickets = await SupportTicket.find({ 
      userId, 
      status: { $in: ['open', 'in-progress'] } 
    }).select('caseId category severity status createdAt');

    // Build AI context
    const systemPrompt = `You are an expert AI support agent for IA M AI platform. You have access to the user's profile and context.

USER PROFILE:
- Name: ${user.name}
- Email: ${user.email}
- Subscription: ${user.subscriptionTier?.toUpperCase() || 'FREE'} (${user.subscriptionStatus || 'active'})
- Credits: ${user.credits || 0}
- Total Agents: ${agentCount}
- Recent Agents: ${recentAgents.map(a => a.name).join(', ') || 'None'}
- Open Support Tickets: ${openTickets.length}

YOUR ROLE:
1. Provide helpful, accurate support for IA M AI platform features
2. Use the user's context to personalize responses
3. Be empathetic and professional
4. Offer step-by-step solutions when needed
5. Escalate complex issues by suggesting ticket creation
6. For billing/subscription issues, acknowledge and offer to create a ticket
7. For technical issues, try to troubleshoot first

RESPONSE GUIDELINES:
- Be concise but thorough
- Use bullet points for multiple steps
- Reference the user's subscription tier for feature availability
- Mention their agent names when relevant
- If the issue requires escalation, suggest: "Would you like me to create a support ticket for priority handling?"

Now respond to the user's message naturally and helpfully.`;

    // Prepare conversation for AI
    const messages = [
      { role: 'system', content: systemPrompt }
    ];

    // Add conversation history (last 10 messages)
    const recentHistory = conversationHistory.slice(-10);
    recentHistory.forEach(msg => {
      if (msg.role === 'user' || msg.role === 'assistant') {
        messages.push({
          role: msg.role === 'assistant' ? 'assistant' : 'user',
          content: msg.content
        });
      }
    });

    // Add current message
    messages.push({
      role: 'user',
      content: message
    });

    // Get AI response
    const aiService = getAIService();
    let response;

    try {
      // Try Gemini first
      response = await aiService.chat('gemini', {
        messages,
        temperature: 0.7,
        maxTokens: 1000,
      });
    } catch (error) {
      console.error('AI service error:', error);
      // Fallback response
      response = {
        content: `Thank you for contacting support. I'm having trouble processing your request right now. Please try again in a moment, or I can create a support ticket for you to ensure you get help from our team.`
      };
    }

    // Check if ticket should be created based on keywords
    const shouldCreateTicket = checkIfTicketNeeded(message);
    let ticket = null;

    if (shouldCreateTicket && openTickets.length === 0) {
      // Create support ticket
      ticket = await createSupportTicket(userId, message, user);
    }

    res.json({
      response: response.content || response,
      ticket: ticket ? {
        id: ticket._id,
        caseId: ticket.caseId,
        category: ticket.category,
        severity: ticket.severity,
        status: ticket.status,
        createdAt: ticket.createdAt,
      } : null,
      context: {
        subscriptionTier: user.subscriptionTier,
        credits: user.credits,
        openTicketsCount: openTickets.length,
      }
    });

  } catch (error) {
    console.error('Error in live support chat:', error);
    res.status(500).json({ 
      error: 'Failed to process message',
      message: 'We encountered an error. Please try again or contact support@iamai.global'
    });
  }
});

/**
 * POST /api/live-support/upload
 * Upload support documents
 */
router.post('/upload', authenticate, upload.array('files', 5), async (req, res) => {
  try {
    const userId = req.userId;
    const uploadedFiles = req.files;

    if (!uploadedFiles || uploadedFiles.length === 0) {
      return res.status(400).json({ error: 'No files uploaded' });
    }

    const documents = [];

    for (const file of uploadedFiles) {
      // Create file record in database
      const fileUpload = new FileUpload({
        userId,
        filename: file.originalname,
        filepath: file.path,
        mimetype: file.mimetype,
        size: file.size,
        category: 'support',
        uploadedAt: new Date(),
      });

      await fileUpload.save();

      documents.push({
        id: fileUpload._id,
        name: file.originalname,
        type: file.mimetype,
        size: file.size,
        uploadedAt: fileUpload.uploadedAt,
      });
    }

    res.json({
      success: true,
      documents,
      message: `${documents.length} file(s) uploaded successfully`
    });

  } catch (error) {
    console.error('Error uploading support documents:', error);
    res.status(500).json({ error: 'Failed to upload documents' });
  }
});

/**
 * GET /api/live-support/tickets
 * Get user's support tickets
 */
router.get('/tickets', authenticate, async (req, res) => {
  try {
    const userId = req.userId;
    const { status, limit = 10 } = req.query;

    const query = { userId };
    if (status) {
      query.status = status;
    }

    const tickets = await SupportTicket.find(query)
      .select('caseId category severity status priority description createdAt updatedAt resolvedAt responseTime')
      .sort({ createdAt: -1 })
      .limit(parseInt(limit));

    res.json({
      tickets: tickets.map(t => ({
        id: t._id,
        caseId: t.caseId,
        category: t.category,
        severity: t.severity,
        status: t.status,
        priority: t.priority,
        description: t.description,
        createdAt: t.createdAt,
        updatedAt: t.updatedAt,
        resolvedAt: t.resolvedAt,
        responseTime: t.responseTime,
        timeRemaining: calculateTimeRemaining(t.createdAt, t.status),
      })),
      total: tickets.length
    });

  } catch (error) {
    console.error('Error fetching tickets:', error);
    res.status(500).json({ error: 'Failed to fetch tickets' });
  }
});

/**
 * POST /api/live-support/ticket/create
 * Manually create a support ticket
 */
router.post('/ticket/create', authenticate, async (req, res) => {
  try {
    const { category, severity, description, attachments = [] } = req.body;
    const userId = req.userId;

    if (!category || !description) {
      return res.status(400).json({ error: 'Category and description are required' });
    }

    const user = await User.findById(userId).select('name email subscriptionTier');
    const ticket = await createSupportTicket(userId, description, user, category, severity);

    res.json({
      success: true,
      ticket: {
        id: ticket._id,
        caseId: ticket.caseId,
        category: ticket.category,
        severity: ticket.severity,
        status: ticket.status,
        createdAt: ticket.createdAt,
      }
    });

  } catch (error) {
    console.error('Error creating ticket:', error);
    res.status(500).json({ error: 'Failed to create ticket' });
  }
});

// ============= HELPER FUNCTIONS =============

/**
 * Check if message requires ticket creation
 */
function checkIfTicketNeeded(message) {
  const keywords = [
    'billing', 'payment', 'charge', 'refund', 'subscription',
    'urgent', 'critical', 'broken', 'not working', 'error',
    'bug', 'issue', 'problem', 'help', 'stuck',
    'account locked', 'can\'t login', 'reset password'
  ];

  const lowerMessage = message.toLowerCase();
  return keywords.some(keyword => lowerMessage.includes(keyword));
}

/**
 * Create support ticket
 */
async function createSupportTicket(userId, description, user, category = null, severity = null) {
  // Auto-categorize if not provided
  if (!category) {
    category = categorizeProblem(description);
  }

  // Auto-set severity if not provided
  if (!severity) {
    severity = calculateSeverity(description, user.subscriptionTier);
  }

  // Generate case ID
  const caseId = `SUP-${Date.now()}-${Math.random().toString(36).substr(2, 4).toUpperCase()}`;

  // Set priority based on subscription tier
  let priority = 'normal';
  if (user.subscriptionTier === 'enterprise') priority = 'urgent';
  else if (user.subscriptionTier === 'pro') priority = 'high';

  const ticket = new SupportTicket({
    userId,
    caseId,
    category,
    severity,
    status: 'open',
    priority,
    description: description.substring(0, 500), // Limit description length
    userEmail: user.email,
    userName: user.name,
    subscriptionTier: user.subscriptionTier,
    createdAt: new Date(),
    updatedAt: new Date(),
  });

  await ticket.save();
  return ticket;
}

/**
 * Auto-categorize problem
 */
function categorizeProblem(description) {
  const lower = description.toLowerCase();
  
  if (lower.includes('billing') || lower.includes('payment') || lower.includes('charge')) {
    return 'billing';
  }
  if (lower.includes('login') || lower.includes('password') || lower.includes('account')) {
    return 'account';
  }
  if (lower.includes('agent') || lower.includes('ai') || lower.includes('chat')) {
    return 'technical';
  }
  if (lower.includes('feature') || lower.includes('how to') || lower.includes('setup')) {
    return 'feature-request';
  }
  if (lower.includes('bug') || lower.includes('error') || lower.includes('broken')) {
    return 'bug-report';
  }
  
  return 'general';
}

/**
 * Calculate severity
 */
function calculateSeverity(description, subscriptionTier) {
  const lower = description.toLowerCase();
  const urgentKeywords = ['urgent', 'critical', 'emergency', 'down', 'broken', 'not working'];
  
  if (urgentKeywords.some(k => lower.includes(k))) {
    return 'high';
  }
  
  if (subscriptionTier === 'enterprise' || subscriptionTier === 'pro') {
    return 'medium';
  }
  
  return 'low';
}

/**
 * Calculate time remaining for 48-hour SLA
 */
function calculateTimeRemaining(createdAt, status) {
  if (status === 'resolved' || status === 'closed') {
    return null;
  }

  const SLA_HOURS = 48;
  const now = new Date();
  const created = new Date(createdAt);
  const hoursElapsed = (now - created) / (1000 * 60 * 60);
  const hoursRemaining = Math.max(0, SLA_HOURS - hoursElapsed);

  return {
    hours: Math.floor(hoursRemaining),
    minutes: Math.floor((hoursRemaining % 1) * 60),
    isOverdue: hoursRemaining === 0,
    percentage: Math.min(100, (hoursElapsed / SLA_HOURS) * 100)
  };
}

module.exports = router;
