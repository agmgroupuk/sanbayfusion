// Contact Form System Routes
// Complete contact form handling with email notifications

const express = require('express');
const nodemailer = require('nodemailer');
const { ContactSubmission } = require('../content-models');
const { User } = require('../models');
const { authenticate } = require('../auth-middleware');

const router = express.Router();

// Email transporter setup (configure with your email service)
const createEmailTransporter = () => {
  return nodemailer.createTransporter({
    host: process.env.SMTP_HOST || 'smtp.gmail.com',
    port: process.env.SMTP_PORT || 587,
    secure: false,
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS
    }
  });
};

// Email templates
const getEmailTemplates = () => {
  return {
    userConfirmation: (name, subject) => ({
      subject: 'Thank you for contacting IAMAI Global',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #2563eb;">Thank you for your message!</h2>
          <p>Dear ${name},</p>
          <p>We've received your message regarding: <strong>${subject}</strong></p>
          <p>Our team will review your inquiry and get back to you within 24-48 hours.</p>
          <div style="background: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <h3 style="margin-top: 0;">What happens next?</h3>
            <ul>
              <li>Our team reviews your message</li>
              <li>We'll assign it to the right department</li>
              <li>You'll receive a detailed response via email</li>
              <li>For urgent matters, we may contact you directly</li>
            </ul>
          </div>
          <p>Thank you for your interest in IAMAI Global!</p>
          <p>Best regards,<br>IAMAI Global Team</p>
        </div>
      `
    }),
    
    adminNotification: (submission) => ({
      subject: `New Contact Form: ${submission.subject}`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #dc2626;">New Contact Form Submission</h2>
          <div style="background: #f8fafc; padding: 20px; border-radius: 8px;">
            <p><strong>Name:</strong> ${submission.name}</p>
            <p><strong>Email:</strong> ${submission.email}</p>
            <p><strong>Company:</strong> ${submission.company || 'Not provided'}</p>
            <p><strong>Type:</strong> ${submission.type}</p>
            <p><strong>Subject:</strong> ${submission.subject}</p>
            <p><strong>Priority:</strong> ${submission.priority}</p>
            <p><strong>Submitted:</strong> ${new Date(submission.createdAt).toLocaleString()}</p>
          </div>
          <div style="margin: 20px 0;">
            <h3>Message:</h3>
            <div style="background: white; border: 1px solid #e5e7eb; padding: 15px; border-radius: 4px;">
              ${submission.message.replace(/\n/g, '<br>')}
            </div>
          </div>
          <p><a href="${process.env.ADMIN_URL || 'http://localhost:3001'}/admin/contacts/${submission._id}" 
             style="background: #2563eb; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px;">
             View in Admin Panel
          </a></p>
        </div>
      `
    })
  };
};

// ============================================
// ROUTES
// ============================================

/**
 * POST /api/contact
 * Submit a contact form
 */
router.post('/', async (req, res) => {
  try {
    const {
      name,
      email,
      company,
      phone,
      type = 'general',
      subject,
      message,
      priority = 'medium',
      newsletterOptIn = false
    } = req.body;

    // Validation
    if (!name || !email || !subject || !message) {
      return res.status(400).json({
        success: false,
        error: 'Missing required fields',
        required: ['name', 'email', 'subject', 'message']
      });
    }

    if (!email.includes('@')) {
      return res.status(400).json({
        success: false,
        error: 'Invalid email address'
      });
    }

    // Check for spam/rate limiting (simple implementation)
    const recentSubmissions = await ContactSubmission.countDocuments({
      email: email.toLowerCase(),
      createdAt: { $gte: new Date(Date.now() - 10 * 60 * 1000) } // Last 10 minutes
    });

    if (recentSubmissions >= 3) {
      return res.status(429).json({
        success: false,
        error: 'Too many submissions. Please wait before submitting again.'
      });
    }

    // Create submission record
    const submission = new ContactSubmission({
      name: name.trim(),
      email: email.toLowerCase().trim(),
      company: company ? company.trim() : undefined,
      phone: phone ? phone.trim() : undefined,
      type,
      subject: subject.trim(),
      message: message.trim(),
      priority,
      newsletterOptIn,
      metadata: {
        userAgent: req.headers['user-agent'],
        ipAddress: req.ip,
        referer: req.headers.referer
      }
    });

    await submission.save();

    // Send emails asynchronously
    const templates = getEmailTemplates();
    
    try {
      const transporter = createEmailTransporter();

      // Send confirmation to user
      const userTemplate = templates.userConfirmation(name, subject);
      await transporter.sendMail({
        from: process.env.SMTP_FROM || 'noreply@iamai-global.com',
        to: email,
        subject: userTemplate.subject,
        html: userTemplate.html
      });

      // Send notification to admin
      const adminTemplate = templates.adminNotification(submission);
      await transporter.sendMail({
        from: process.env.SMTP_FROM || 'noreply@iamai-global.com',
        to: process.env.CONTACT_EMAIL || 'contact@iamai-global.com',
        subject: adminTemplate.subject,
        html: adminTemplate.html
      });

      console.log('Contact form emails sent successfully');

    } catch (emailError) {
      console.error('Email sending failed:', emailError);
      // Don't fail the request if email fails
    }

    res.status(201).json({
      success: true,
      message: 'Your message has been sent successfully!',
      data: {
        id: submission._id,
        status: 'received',
        estimatedResponse: '24-48 hours'
      }
    });

  } catch (error) {
    console.error('Contact form submission error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to submit contact form',
      message: error.message
    });
  }
});

/**
 * GET /api/contact/types
 * Get available contact form types and priorities
 */
router.get('/types', (req, res) => {
  res.json({
    success: true,
    data: {
      types: [
        { value: 'general', label: 'General Inquiry' },
        { value: 'support', label: 'Technical Support' },
        { value: 'sales', label: 'Sales & Pricing' },
        { value: 'partnership', label: 'Partnership' },
        { value: 'media', label: 'Media & Press' },
        { value: 'careers', label: 'Careers' },
        { value: 'feedback', label: 'Feedback' },
        { value: 'bug', label: 'Bug Report' }
      ],
      priorities: [
        { value: 'low', label: 'Low', description: 'General inquiry' },
        { value: 'medium', label: 'Medium', description: 'Standard support' },
        { value: 'high', label: 'High', description: 'Urgent issue' },
        { value: 'critical', label: 'Critical', description: 'Service down' }
      ]
    }
  });
});

/**
 * GET /api/contact/admin
 * Get all contact submissions (admin only)
 */
router.get('/admin', authenticate, async (req, res) => {
  try {
    // Check if user is admin
    const user = await User.findById(req.userId);
    if (!user || user.tier !== 'ADMIN') {
      return res.status(403).json({
        success: false,
        error: 'Admin access required'
      });
    }

    const {
      page = 1,
      limit = 20,
      status,
      type,
      priority,
      search
    } = req.query;

    // Build query
    const query = {};
    if (status) query.status = status;
    if (type) query.type = type;
    if (priority) query.priority = priority;
    
    if (search) {
      query.$or = [
        { name: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } },
        { subject: { $regex: search, $options: 'i' } },
        { company: { $regex: search, $options: 'i' } }
      ];
    }

    const skip = (page - 1) * limit;
    
    const [submissions, total] = await Promise.all([
      ContactSubmission.find(query)
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(parseInt(limit))
        .select('-metadata'),
      ContactSubmission.countDocuments(query)
    ]);

    res.json({
      success: true,
      data: {
        submissions,
        pagination: {
          current: parseInt(page),
          total: Math.ceil(total / limit),
          count: submissions.length,
          totalRecords: total
        }
      }
    });

  } catch (error) {
    console.error('Contact admin list error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve contact submissions',
      message: error.message
    });
  }
});

/**
 * GET /api/contact/admin/:id
 * Get specific contact submission (admin only)
 */
router.get('/admin/:id', authenticate, async (req, res) => {
  try {
    // Check if user is admin
    const user = await User.findById(req.userId);
    if (!user || user.tier !== 'ADMIN') {
      return res.status(403).json({
        success: false,
        error: 'Admin access required'
      });
    }

    const submission = await ContactSubmission.findById(req.params.id);
    
    if (!submission) {
      return res.status(404).json({
        success: false,
        error: 'Contact submission not found'
      });
    }

    res.json({
      success: true,
      data: submission
    });

  } catch (error) {
    console.error('Contact admin get error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve contact submission',
      message: error.message
    });
  }
});

/**
 * PUT /api/contact/admin/:id/status
 * Update contact submission status (admin only)
 */
router.put('/admin/:id/status', authenticate, async (req, res) => {
  try {
    // Check if user is admin
    const user = await User.findById(req.userId);
    if (!user || user.tier !== 'ADMIN') {
      return res.status(403).json({
        success: false,
        error: 'Admin access required'
      });
    }

    const { status, response } = req.body;
    
    if (!['pending', 'in-progress', 'resolved', 'closed'].includes(status)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid status value'
      });
    }

    const submission = await ContactSubmission.findById(req.params.id);
    
    if (!submission) {
      return res.status(404).json({
        success: false,
        error: 'Contact submission not found'
      });
    }

    submission.status = status;
    submission.adminResponse = response || submission.adminResponse;
    submission.respondedAt = status === 'resolved' ? new Date() : submission.respondedAt;
    submission.respondedBy = req.userId;

    await submission.save();

    // Send email notification to user if resolved
    if (status === 'resolved' && response) {
      try {
        const transporter = createEmailTransporter();
        await transporter.sendMail({
          from: process.env.SMTP_FROM || 'noreply@iamai-global.com',
          to: submission.email,
          subject: `Re: ${submission.subject}`,
          html: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
              <h2 style="color: #2563eb;">Response to your inquiry</h2>
              <p>Dear ${submission.name},</p>
              <p>Thank you for contacting IAMAI Global. We have reviewed your inquiry and here's our response:</p>
              <div style="background: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
                ${response.replace(/\n/g, '<br>')}
              </div>
              <p>If you have any further questions, please don't hesitate to contact us.</p>
              <p>Best regards,<br>IAMAI Global Team</p>
            </div>
          `
        });
      } catch (emailError) {
        console.error('Failed to send response email:', emailError);
      }
    }

    res.json({
      success: true,
      message: 'Contact submission updated successfully',
      data: {
        id: submission._id,
        status: submission.status,
        respondedAt: submission.respondedAt
      }
    });

  } catch (error) {
    console.error('Contact status update error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to update contact submission',
      message: error.message
    });
  }
});

/**
 * GET /api/contact/stats
 * Get contact form statistics (admin only)
 */
router.get('/stats', authenticate, async (req, res) => {
  try {
    // Check if user is admin
    const user = await User.findById(req.userId);
    if (!user || user.tier !== 'ADMIN') {
      return res.status(403).json({
        success: false,
        error: 'Admin access required'
      });
    }

    const { days = 30 } = req.query;
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    const [
      totalSubmissions,
      recentSubmissions,
      statusCounts,
      typeCounts,
      priorityCounts
    ] = await Promise.all([
      ContactSubmission.countDocuments(),
      ContactSubmission.countDocuments({ createdAt: { $gte: startDate } }),
      ContactSubmission.aggregate([
        { $group: { _id: '$status', count: { $sum: 1 } } }
      ]),
      ContactSubmission.aggregate([
        { $group: { _id: '$type', count: { $sum: 1 } } }
      ]),
      ContactSubmission.aggregate([
        { $group: { _id: '$priority', count: { $sum: 1 } } }
      ])
    ]);

    // Calculate response time
    const avgResponseTime = await ContactSubmission.aggregate([
      { 
        $match: { 
          respondedAt: { $exists: true },
          createdAt: { $gte: startDate }
        }
      },
      {
        $project: {
          responseTime: { $subtract: ['$respondedAt', '$createdAt'] }
        }
      },
      {
        $group: {
          _id: null,
          avgResponseTime: { $avg: '$responseTime' }
        }
      }
    ]);

    res.json({
      success: true,
      data: {
        period: `Last ${days} days`,
        summary: {
          total: totalSubmissions,
          recent: recentSubmissions,
          avgResponseTimeHours: avgResponseTime[0] 
            ? Math.round(avgResponseTime[0].avgResponseTime / (1000 * 60 * 60))
            : null
        },
        breakdown: {
          byStatus: statusCounts.reduce((acc, item) => {
            acc[item._id] = item.count;
            return acc;
          }, {}),
          byType: typeCounts.reduce((acc, item) => {
            acc[item._id] = item.count;
            return acc;
          }, {}),
          byPriority: priorityCounts.reduce((acc, item) => {
            acc[item._id] = item.count;
            return acc;
          }, {})
        }
      }
    });

  } catch (error) {
    console.error('Contact stats error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve contact statistics',
      message: error.message
    });
  }
});

module.exports = router;