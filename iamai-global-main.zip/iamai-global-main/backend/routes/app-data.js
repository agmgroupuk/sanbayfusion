/**
 * 🗂️ App Data API Routes - Handles user app data persistence
 *
 * Stores: Auth preferences, Theme, API Keys, Subscriptions, Agents, Selected Agent
 * Replaces localStorage dependency with proper database persistence
 */
/* eslint-disable no-console */
/* eslint-disable @typescript-eslint/no-var-requires */

const express = require('express');
const models = require('../models');
const { User } = models;
const { IndividualAgentConfiguration } = models;
// Use the unified AgentPurchase model which now handles both legacy
// and new purchase documents. Legacy fields (planType, expirationDate,
// amount, currency, status: 'active') are still supported, but new code
// should prefer plan/planName/pricing/expiresAt/status: 'ACTIVE'.
const { AgentPurchase } = require('../agent-purchase-models');
const router = express.Router();

// Use the standard authentication middleware
const { authenticate } = require('../auth-middleware');

/**
 * @route GET /api/users/app-data
 * @desc Get user's app data (theme, API keys, subscriptions, etc.)
 * @access Private
 */
router.get('/app-data', authenticate, async (req, res) => {
  try {
    console.log('[APP_DATA] 📥 Loading app data for user:', req.userId);

    const user = await User.findById(req.userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    let agentSubscriptions = [];
    let agentSubscriptionsById = {};

    try {
      const now = new Date();

      // Read active purchases from the unified AgentPurchase model
      // (includes both legacy-shaped and new documents).
      const rawPurchases = await AgentPurchase.getUserActivePurchases(req.userId);

      const PLAN_CONFIGS = {
        DAILY: {
          name: 'Daily',
          amount: 1,
        },
        WEEKLY: {
          name: 'Weekly',
          amount: 5,
        },
        MONTHLY: {
          name: 'Monthly',
          amount: 19,
        },
      };

      agentSubscriptions = await Promise.all(
        rawPurchases.map(async purchase => {
          let agentInfo = { ...(purchase.agentInfo || {}) };

          // Prefer explicit agent metadata when available
          if (!agentInfo.agentDisplayName && purchase.metadata?.agentName) {
            agentInfo.agentDisplayName = purchase.metadata.agentName;
          }

          if (!agentInfo.agentDisplayName && purchase.agentName) {
            agentInfo.agentDisplayName = purchase.agentName;
          }

          if (!agentInfo.agentDisplayName || !agentInfo.agentCategory) {
            const agentConfig = await IndividualAgentConfiguration.findOne({
              agentId: purchase.agentId,
            })
              .select({ 'info.displayName': 1, 'info.category': 1 })
              .lean();

            if (agentConfig?.info) {
              agentInfo = {
                ...agentInfo,
                agentDisplayName:
                  agentInfo.agentDisplayName ||
                  agentConfig.info.displayName ||
                  purchase.agentName ||
                  purchase.agentId,
                agentCategory: agentInfo.agentCategory || agentConfig.info.category,
              };
            }
          }

          // Normalize plan information from unified or legacy schema/metadata
          const metaPlan = purchase.metadata?.plan;
          const rawPlan = (
            purchase.plan ||
            metaPlan ||
            purchase.planType ||
            'DAILY'
          )
            .toString()
            .toUpperCase();
          const planKey = ['DAILY', 'WEEKLY', 'MONTHLY'].includes(rawPlan) ? rawPlan : 'DAILY';
          const planConfig = PLAN_CONFIGS[planKey] || PLAN_CONFIGS.DAILY;

          const metaPricing = purchase.metadata?.pricing || {};

          const priceAmount =
            purchase.pricing?.amount != null
              ? purchase.pricing.amount
              : metaPricing.amount != null
              ? metaPricing.amount
              : purchase.amount != null
              ? purchase.amount
              : planConfig.amount;

          const priceCurrency = (
            purchase.pricing?.currency ||
            metaPricing.currency ||
            purchase.currency ||
            'USD'
          )
            .toString()
            .toUpperCase();

          const expiresAtDate = purchase.expiresAt
            ? new Date(purchase.expiresAt)
            : purchase.expirationDate
            ? new Date(purchase.expirationDate)
            : null;
          const daysRemaining = expiresAtDate
            ? Math.max(0, Math.ceil((expiresAtDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)))
            : 0;

          const normalizedStatus = (purchase.status || 'active').toString().toLowerCase();

          return {
            id: purchase._id?.toString(),
            agentId: purchase.agentId,
            plan: planKey,
            planName: purchase.metadata?.planName || planConfig.name,
            status: normalizedStatus, // frontend expects 'active' (lowercase)
            pricing: {
              amount: priceAmount,
              currency: priceCurrency,
            },
            usage: purchase.currentUsage || purchase.usage || {},
            billing: {}, // No recurring billing in purchase model
            preferences: purchase.preferences || {},
            agentInfo,
            subscribedAt: purchase.purchaseDate,
            // Convenience fields for UI components
            expiresAt: expiresAtDate ? expiresAtDate.toISOString() : null,
            daysRemaining,
          };
        })
      );

      agentSubscriptionsById = agentSubscriptions.reduce((acc, record) => {
        if (record?.agentId) {
          acc[record.agentId] = record;
        }
        return acc;
      }, {});
    } catch (subscriptionError) {
      console.error(
        '[APP_DATA] ⚠️ Failed to load agent purchases:',
        subscriptionError
      );
    }

    // Structure the app data response
    const appData = {
      auth: {
        isLoggedIn: true,
        timestamp: Date.now(),
        user: {
          id: user._id,
          username: user.username,
          email: user.email,
          name: user.name,
          avatar: user.avatar,
          subscriptionTier: user.subscriptionTier || 'free',
          subscriptionStatus: user.subscriptionStatus || 'active',
        },
      },
      theme: user.preferences?.theme || 'dark',
      apiKeys: {
        gemini: user.apiKeys?.gemini || '',
        openai: user.apiKeys?.openai || '',
        anthropic: user.apiKeys?.anthropic || '',
      },
      subscriptions: user.subscriptions || {},
      agents: user.customAgents || [],
      selectedAgent: user.preferences?.selectedAgent || null,
      agentSubscriptions,
      agentSubscriptionsById,
    };

    console.log('[APP_DATA] ✅ App data loaded successfully');
    res.json(appData);
  } catch (error) {
    console.error('[APP_DATA] ❌ Error loading app data:', error);
    res.status(500).json({ message: 'Server error loading app data' });
  }
});

/**
 * @route PUT /api/users/app-data
 * @desc Update user's app data
 * @access Private
 */
router.put('/app-data', authenticate, async (req, res) => {
  const maxRetries = 3;
  const baseDelay = 100; // ms

  const { auth: authData, theme, apiKeys, subscriptions, agents, selectedAgent } = req.body;

  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      if (attempt === 0) {
        console.log('[APP_DATA] 💾 Saving app data for user:', req.userId);
      } else {
        console.log(
          `[APP_DATA] 💾 Retrying app data save (attempt ${attempt + 1}/${maxRetries + 1}) for user:`,
          req.userId
        );
      }
      console.log('[APP_DATA] 📝 Data to save:', req.body);

      const user = await User.findById(req.userId);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }

      // Initialize objects if they don't exist
      if (!user.preferences) user.preferences = {};
      if (!user.apiKeys) user.apiKeys = {};

      // Update theme
      if (theme !== undefined) {
        if (!user.preferences) user.preferences = {};
        user.preferences.theme = theme;
        console.log('[APP_DATA] 🎨 Updated theme:', theme, 'for user:', req.userId);
      }

      // Update API keys
      if (apiKeys) {
        user.apiKeys = {
          ...user.apiKeys,
          ...apiKeys,
        };
        console.log('[APP_DATA] 🔑 Updated API keys');
      }

      // Update subscriptions
      if (subscriptions !== undefined) {
        user.subscriptions = subscriptions;
        console.log('[APP_DATA] 💳 Updated subscriptions');
      }

      // Update custom agents
      if (agents !== undefined) {
        user.customAgents = agents;
        console.log('[APP_DATA] 🤖 Updated agents');
      }

      // Update selected agent
      if (selectedAgent !== undefined) {
        user.preferences.selectedAgent = selectedAgent;
        console.log('[APP_DATA] ⭐ Updated selected agent');
      }

      // Update auth-related user data if provided
      if (authData?.user) {
        const { name, avatar } = authData.user;
        if (name !== undefined) user.name = name;
        if (avatar !== undefined) user.avatar = avatar;
        console.log('[APP_DATA] 👤 Updated user profile data');
      }

      // Save to database
      user.updatedAt = new Date();
      await user.save();

      console.log('[APP_DATA] ✅ App data saved successfully');
      return res.json({
        message: 'App data saved successfully',
        timestamp: Date.now(),
      });
    } catch (error) {
      // Handle version conflicts with a bounded retry loop
      if (error.name === 'VersionError' && attempt < maxRetries) {
        const delay = baseDelay * Math.pow(2, attempt);
        console.warn(
          `[APP_DATA] ⚠️ Version conflict detected, retrying in ${delay}ms (attempt ${
            attempt + 1
          }/${maxRetries + 1}) for user: ${req.userId}`
        );
        await new Promise(resolve => setTimeout(resolve, delay));
        continue;
      }

      console.error('[APP_DATA] ❌ Error saving app data:', error);
      return res.status(500).json({ message: 'Server error saving app data' });
    }
  }
});

/**
 * @route DELETE /api/users/app-data
 * @desc Clear user's app data (logout cleanup)
 * @access Private
 */
router.delete('/app-data', authenticate, async (req, res) => {
  try {
    console.log('[APP_DATA] 🧹 Clearing app data for user:', req.userId);

    const user = await User.findById(req.userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Clear app-specific data while preserving account data
    user.preferences = {
      theme: 'dark',
      selectedAgent: null,
    };
    user.customAgents = [];

    // Keep API keys and subscriptions as they're valuable user data
    // Only clear theme and selected agent on logout

    user.updatedAt = new Date();
    await user.save();

    console.log('[APP_DATA] ✅ App data cleared successfully');
    res.json({ message: 'App data cleared successfully' });
  } catch (error) {
    console.error('[APP_DATA] ❌ Error clearing app data:', error);
    res.status(500).json({ message: 'Server error clearing app data' });
  }
});

module.exports = router;
