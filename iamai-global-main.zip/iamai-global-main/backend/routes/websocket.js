/**
 * 🔌 WebSocket API Routes
 * Handle WebSocket connection management and real-time features
 */

const express = require('express');
const router = express.Router();
const websocketService = require('../websocket-service');
const { authenticate: authMiddleware } = require('../auth-middleware');
const { body, query, validationResult } = require('express-validator');

/**
 * Get WebSocket connection statistics
 */
router.get('/stats', authMiddleware, async (req, res) => {
  try {
    const stats = websocketService.getStats();

    res.json({
      success: true,
      stats,
    });
  } catch (error) {
    console.error('Get WebSocket stats error:', error);
    res.status(500).json({ error: 'Failed to get WebSocket statistics' });
  }
});

/**
 * Send message to specific user
 */
router.post(
  '/send-to-user',
  authMiddleware,
  [
    body('targetUserId').notEmpty().withMessage('Target user ID is required'),
    body('type').notEmpty().withMessage('Message type is required'),
    body('data').optional().isObject(),
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const { targetUserId, type, data = {} } = req.body;

      const message = {
        type,
        data: {
          ...data,
          fromUserId: req.user.userId,
          timestamp: new Date().toISOString(),
        },
      };

      const sent = websocketService.sendToUser(targetUserId, message);

      res.json({
        success: true,
        sent,
        message: sent ? 'Message sent successfully' : 'User not connected, message queued',
      });
    } catch (error) {
      console.error('Send to user error:', error);
      res.status(500).json({ error: 'Failed to send message' });
    }
  }
);

/**
 * Broadcast message to all users
 */
router.post(
  '/broadcast',
  authMiddleware,
  [
    body('type').notEmpty().withMessage('Message type is required'),
    body('data').optional().isObject(),
  ],
  async (req, res) => {
    try {
      // Check admin permission for broadcasts
      if (!req.user.isAdmin) {
        return res.status(403).json({ error: 'Admin access required for broadcasts' });
      }

      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const { type, data = {} } = req.body;

      const message = {
        type,
        data: {
          ...data,
          fromUserId: req.user.userId,
          timestamp: new Date().toISOString(),
          isBroadcast: true,
        },
      };

      const sentCount = websocketService.broadcast(message);

      res.json({
        success: true,
        sentCount,
        message: `Broadcast sent to ${sentCount} connections`,
      });
    } catch (error) {
      console.error('Broadcast error:', error);
      res.status(500).json({ error: 'Failed to broadcast message' });
    }
  }
);

/**
 * Send system update
 */
router.post(
  '/system-update',
  authMiddleware,
  [
    body('message').isObject().withMessage('Message object is required'),
    body('userIds').optional().isArray(),
  ],
  async (req, res) => {
    try {
      // Check admin permission for system updates
      if (!req.user.isAdmin) {
        return res.status(403).json({ error: 'Admin access required for system updates' });
      }

      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const { message, userIds } = req.body;

      const sentCount = websocketService.sendSystemUpdate(message, userIds);

      res.json({
        success: true,
        sentCount,
        message: userIds
          ? `System update sent to ${sentCount} specific users`
          : `System update broadcast to ${sentCount} connections`,
      });
    } catch (error) {
      console.error('System update error:', error);
      res.status(500).json({ error: 'Failed to send system update' });
    }
  }
);

/**
 * Send notification via WebSocket
 */
router.post(
  '/notification',
  authMiddleware,
  [
    body('targetUserId').notEmpty().withMessage('Target user ID is required'),
    body('notification').isObject().withMessage('Notification object is required'),
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const { targetUserId, notification } = req.body;

      const sent = websocketService.sendNotification(targetUserId, notification);

      res.json({
        success: true,
        sent,
        message: sent
          ? 'Notification sent successfully'
          : 'User not connected, notification queued',
      });
    } catch (error) {
      console.error('Send notification error:', error);
      res.status(500).json({ error: 'Failed to send notification' });
    }
  }
);

/**
 * Send agent response via WebSocket
 */
router.post(
  '/agent-response',
  authMiddleware,
  [
    body('targetUserId').notEmpty().withMessage('Target user ID is required'),
    body('agentResponse').isObject().withMessage('Agent response object is required'),
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const { targetUserId, agentResponse } = req.body;

      const sent = websocketService.sendAgentResponse(targetUserId, agentResponse);

      res.json({
        success: true,
        sent,
        message: sent ? 'Agent response sent successfully' : 'User not connected, response queued',
      });
    } catch (error) {
      console.error('Send agent response error:', error);
      res.status(500).json({ error: 'Failed to send agent response' });
    }
  }
);

/**
 * Get room information
 */
router.get('/rooms', authMiddleware, async (req, res) => {
  try {
    const stats = websocketService.getStats();

    res.json({
      success: true,
      rooms: stats.roomStats,
      totalRooms: stats.totalRooms,
    });
  } catch (error) {
    console.error('Get rooms error:', error);
    res.status(500).json({ error: 'Failed to get room information' });
  }
});

/**
 * Force disconnect user (admin only)
 */
router.post(
  '/disconnect-user',
  authMiddleware,
  [
    body('targetUserId').notEmpty().withMessage('Target user ID is required'),
    body('reason').optional().isString(),
  ],
  async (req, res) => {
    try {
      // Check admin permission
      if (!req.user.isAdmin) {
        return res.status(403).json({ error: 'Admin access required' });
      }

      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const { targetUserId, reason = 'Admin disconnection' } = req.body;

      // Send disconnect message first
      websocketService.sendToUser(targetUserId, {
        type: 'force_disconnect',
        data: {
          reason,
          timestamp: new Date().toISOString(),
        },
      });

      res.json({
        success: true,
        message: 'User disconnect message sent',
      });
    } catch (error) {
      console.error('Disconnect user error:', error);
      res.status(500).json({ error: 'Failed to disconnect user' });
    }
  }
);

/**
 * Get connection token for WebSocket authentication
 */
router.get('/token', authMiddleware, async (req, res) => {
  try {
    const jwt = require('jsonwebtoken');

    const token = jwt.sign({ userId: req.user.userId }, process.env.JWT_SECRET, {
      expiresIn: '1h',
    });

    res.json({
      success: true,
      token,
      expiresIn: 3600, // 1 hour
      websocketUrl: `${process.env.NODE_ENV === 'production' ? 'wss' : 'ws'}://${req.get('host')}/ws`,
    });
  } catch (error) {
    console.error('Get WebSocket token error:', error);
    res.status(500).json({ error: 'Failed to generate WebSocket token' });
  }
});

/**
 * Test WebSocket connection
 */
router.post('/test', authMiddleware, async (req, res) => {
  try {
    const userId = req.user.userId;

    const testMessage = {
      type: 'test_message',
      data: {
        message: 'WebSocket connection test',
        timestamp: new Date().toISOString(),
        fromServer: true,
      },
    };

    const sent = websocketService.sendToUser(userId, testMessage);

    res.json({
      success: true,
      sent,
      message: sent ? 'Test message sent successfully' : 'User not connected to WebSocket',
    });
  } catch (error) {
    console.error('WebSocket test error:', error);
    res.status(500).json({ error: 'Failed to test WebSocket connection' });
  }
});

module.exports = router;
