// Notification System API Routes - Critical Missing Backend Feature
// Implements /api/notifications/preferences and notification management

const express = require('express');
const router = express.Router();
const { NotificationSettings } = require('../models');
const { authenticate } = require('../auth-middleware');

// ============================================
// NOTIFICATION PREFERENCES ENDPOINTS (CRITICAL)
// ============================================

// GET /api/notifications/preferences - Get user's notification settings
router.get('/preferences', authenticate, async (req, res) => {
  try {
    const userId = req.userId;

    let settings = await NotificationSettings.findOne({ userId });
    if (!settings) {
      // Create default notification settings
      settings = new NotificationSettings({
        userId,
        emailSettings: {
          enabled: true,
          frequency: 'daily',
          types: {
            newMessage: true,
            subscriptionUpdates: true,
            billingAlerts: true,
            systemUpdates: false,
            marketingEmails: false,
            securityAlerts: true,
          },
        },
        pushSettings: {
          enabled: false,
          types: {
            newMessage: true,
            agentResponse: true,
            systemAlerts: true,
          },
        },
        inAppSettings: {
          enabled: true,
          sound: true,
          desktop: false,
          showPreview: true,
        },
      });
      await settings.save();
    }

    res.json({
      success: true,
      data: settings,
    });
  } catch (error) {
    console.error('Get notification preferences error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch notification preferences',
    });
  }
});

// POST /api/notifications/preferences - Update notification settings
router.post('/preferences', authenticate, async (req, res) => {
  try {
    const userId = req.userId;
    const { emailSettings, pushSettings, inAppSettings } = req.body;

    const settings = await NotificationSettings.findOneAndUpdate(
      { userId },
      {
        emailSettings: emailSettings || {},
        pushSettings: pushSettings || {},
        inAppSettings: inAppSettings || {},
      },
      {
        new: true,
        upsert: true,
        runValidators: true,
      }
    );

    res.json({
      success: true,
      data: settings,
      message: 'Notification preferences updated successfully',
    });
  } catch (error) {
    console.error('Update notification preferences error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to update notification preferences',
    });
  }
});

// ============================================
// IN-APP NOTIFICATIONS COLLECTION
// ============================================

const mongoose = require('mongoose');
const { Schema } = mongoose;

const InAppNotificationSchema = new Schema(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'UserAuth',
      required: true,
    },

    notificationId: {
      type: String,
      required: true,
      unique: true,
    },

    // Notification Content
    content: {
      title: { type: String, required: true },
      message: { type: String, required: true },
      type: { type: String, enum: ['info', 'success', 'warning', 'error'], default: 'info' },
      category: {
        type: String,
        enum: ['system', 'chat', 'subscription', 'billing', 'security'],
        required: true,
      },
      icon: String,
      image: String,
    },

    // Action Configuration
    actions: [
      {
        actionId: String,
        label: String,
        url: String,
        type: { type: String, enum: ['link', 'button', 'dismiss'] },
        style: { type: String, enum: ['primary', 'secondary', 'danger'] },
      },
    ],

    // Related Entities
    relatedEntities: {
      agentId: String,
      sessionId: String,
      subscriptionId: String,
      messageId: String,
      paymentId: String,
    },

    // Status
    status: {
      isRead: { type: Boolean, default: false },
      isArchived: { type: Boolean, default: false },
      isDismissed: { type: Boolean, default: false },
      readAt: Date,
      archivedAt: Date,
      dismissedAt: Date,
    },

    // Delivery
    delivery: {
      scheduledFor: Date,
      deliveredAt: Date,
      expiresAt: Date,
      priority: { type: String, enum: ['low', 'normal', 'high', 'urgent'], default: 'normal' },
    },
  },
  {
    timestamps: true,
    collection: 'in_app_notifications',
  }
);

// Indexes for notification queries
InAppNotificationSchema.index({ userId: 1, 'status.isRead': 1 });
InAppNotificationSchema.index({ userId: 1, createdAt: -1 });
InAppNotificationSchema.index({ notificationId: 1 }, { unique: true });
InAppNotificationSchema.index({ 'delivery.expiresAt': 1 });

const InAppNotification = mongoose.model('InAppNotification', InAppNotificationSchema);

// ============================================
// IN-APP NOTIFICATIONS ENDPOINTS
// ============================================

// GET /api/notifications/inbox - Get user's in-app notifications
router.get('/inbox', authenticate, async (req, res) => {
  try {
    const userId = req.userId;
    const { limit = 20, offset = 0, unreadOnly = false, category, type } = req.query;

    // Build query
    const query = {
      userId,
      'status.isArchived': false,
      'delivery.expiresAt': { $gte: new Date() },
    };

    if (unreadOnly === 'true') {
      query['status.isRead'] = false;
    }
    if (category) query['content.category'] = category;
    if (type) query['content.type'] = type;

    const notifications = await InAppNotification.find(query)
      .sort({ 'delivery.priority': -1, createdAt: -1 })
      .limit(parseInt(limit))
      .skip(parseInt(offset))
      .select('-__v');

    const unreadCount = await InAppNotification.countDocuments({
      userId,
      'status.isRead': false,
      'status.isArchived': false,
      'delivery.expiresAt': { $gte: new Date() },
    });

    const total = await InAppNotification.countDocuments(query);

    res.json({
      success: true,
      data: {
        notifications,
        unreadCount,
        pagination: {
          total,
          limit: parseInt(limit),
          offset: parseInt(offset),
          hasMore: parseInt(offset) + parseInt(limit) < total,
        },
      },
    });
  } catch (error) {
    console.error('Get notifications error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch notifications',
    });
  }
});

// POST /api/notifications/:notificationId/read - Mark notification as read
router.post('/:notificationId/read', authenticate, async (req, res) => {
  try {
    const userId = req.userId;
    const { notificationId } = req.params;

    const notification = await InAppNotification.findOneAndUpdate(
      { notificationId, userId },
      {
        'status.isRead': true,
        'status.readAt': new Date(),
      },
      { new: true }
    );

    if (!notification) {
      return res.status(404).json({
        success: false,
        error: 'Notification not found',
      });
    }

    res.json({
      success: true,
      data: notification,
    });
  } catch (error) {
    console.error('Mark notification read error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to mark notification as read',
    });
  }
});

// POST /api/notifications/read-all - Mark all notifications as read
router.post('/read-all', authenticate, async (req, res) => {
  try {
    const userId = req.userId;

    const result = await InAppNotification.updateMany(
      {
        userId,
        'status.isRead': false,
        'status.isArchived': false,
      },
      {
        'status.isRead': true,
        'status.readAt': new Date(),
      }
    );

    res.json({
      success: true,
      data: {
        modifiedCount: result.modifiedCount,
      },
      message: 'All notifications marked as read',
    });
  } catch (error) {
    console.error('Mark all read error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to mark all notifications as read',
    });
  }
});

// DELETE /api/notifications/:notificationId - Delete notification
router.delete('/:notificationId', authenticate, async (req, res) => {
  try {
    const userId = req.userId;
    const { notificationId } = req.params;

    const notification = await InAppNotification.findOneAndUpdate(
      { notificationId, userId },
      {
        'status.isArchived': true,
        'status.archivedAt': new Date(),
      },
      { new: true }
    );

    if (!notification) {
      return res.status(404).json({
        success: false,
        error: 'Notification not found',
      });
    }

    res.json({
      success: true,
      message: 'Notification archived successfully',
    });
  } catch (error) {
    console.error('Archive notification error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to archive notification',
    });
  }
});

// ============================================
// NOTIFICATION SERVICE FUNCTIONS
// ============================================

// Create notification helper function
const createNotification = async (userId, notificationData) => {
  try {
    const notification = new InAppNotification({
      userId,
      notificationId: `notif_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      ...notificationData,
      delivery: {
        ...notificationData.delivery,
        deliveredAt: new Date(),
        expiresAt:
          notificationData.delivery?.expiresAt || new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days default
      },
    });

    await notification.save();
    return notification;
  } catch (error) {
    console.error('Create notification error:', error);
    throw error;
  }
};

// Send notification helper function (for internal use)
const sendNotification = async (userId, type, data) => {
  try {
    // Get user notification preferences
    const settings = await NotificationSettings.findOne({ userId });
    if (!settings || !settings.inAppSettings.enabled) {
      return null; // User has notifications disabled
    }

    // Create notification based on type
    let notificationData;

    switch (type) {
      case 'new_message':
        notificationData = {
          content: {
            title: 'New Message',
            message: `You have a new message from ${data.agentName}`,
            type: 'info',
            category: 'chat',
            icon: 'message',
          },
          relatedEntities: {
            agentId: data.agentId,
            sessionId: data.sessionId,
            messageId: data.messageId,
          },
          actions: [
            {
              actionId: 'view_message',
              label: 'View Message',
              url: `/chat/${data.agentId}?session=${data.sessionId}`,
              type: 'link',
              style: 'primary',
            },
          ],
        };
        break;

      case 'subscription_update':
        notificationData = {
          content: {
            title: 'Subscription Updated',
            message: data.message,
            type: 'success',
            category: 'subscription',
            icon: 'subscription',
          },
          relatedEntities: {
            subscriptionId: data.subscriptionId,
          },
        };
        break;

      case 'billing_alert':
        notificationData = {
          content: {
            title: 'Billing Alert',
            message: data.message,
            type: 'warning',
            category: 'billing',
            icon: 'billing',
          },
          delivery: {
            priority: 'high',
          },
        };
        break;

      default:
        notificationData = {
          content: {
            title: data.title || 'Notification',
            message: data.message,
            type: data.type || 'info',
            category: data.category || 'system',
          },
        };
    }

    const notification = await createNotification(userId, notificationData);
    return notification;
  } catch (error) {
    console.error('Send notification error:', error);
    throw error;
  }
};

// Export models and helper functions
module.exports = router;
module.exports.InAppNotification = InAppNotification;
module.exports.createNotification = createNotification;
module.exports.sendNotification = sendNotification;
