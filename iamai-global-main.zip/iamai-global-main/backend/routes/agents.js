/**
 * Agent API Routes
 * Production-ready endpoints for fetching agents from database
 * 
 * GET /api/agents - Get all active agents
 * GET /api/agents/detail/:agentId - Get single agent by ID
 * GET /api/agents/category/:category - Get agents by category
 * GET /api/agents/featured - Get featured agents
 * GET /api/agents/search?q=query - Search agents
 */

console.log('📦 Loading agents routes module...');

const express = require('express');
const router = express.Router();
const Agent = require('../models/Agent');

console.log('✅ agents.js routes file loaded');

// ==========================================
// CACHE LAYER (Simple in-memory cache)
// ==========================================

const agentCache = {
  data: null,
  timestamp: null,
  TTL: 5 * 60 * 1000 // 5 minutes
};

async function getCachedAgents() {
  const now = Date.now();
  
  if (agentCache.data && agentCache.timestamp && (now - agentCache.timestamp) < agentCache.TTL) {
    return agentCache.data;
  }
  
  // Refresh cache
  const agents = await Agent.getAllActive();
  agentCache.data = agents.map(a => a.toPublicJSON());
  agentCache.timestamp = now;
  
  return agentCache.data;
}

function invalidateCache() {
  agentCache.data = null;
  agentCache.timestamp = null;
}

// ==========================================
// PUBLIC ROUTES
// ==========================================

/**
 * GET /api/agents
 * Get all active agents
 */
router.get('/', async (req, res) => {
  try {
    const agents = await getCachedAgents();
    
    res.json({
      success: true,
      count: agents.length,
      agents
    });
  } catch (error) {
    console.error('Error fetching agents:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch agents'
    });
  }
});

/**
 * GET /api/agents/featured
 * Get featured agents
 */
router.get('/featured', async (req, res) => {
  try {
    const agents = await Agent.getFeatured();
    
    res.json({
      success: true,
      count: agents.length,
      agents: agents.map(a => a.toPublicJSON())
    });
  } catch (error) {
    console.error('Error fetching featured agents:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch featured agents'
    });
  }
});

/**
 * GET /api/agents/categories
 * Get list of all categories with agent counts
 */
router.get('/categories', async (req, res) => {
  try {
    const categories = await Agent.aggregate([
      { $match: { isActive: true } },
      { $group: { _id: '$category', count: { $sum: 1 } } },
      { $sort: { count: -1 } }
    ]);
    
    res.json({
      success: true,
      categories: categories.map(c => ({
        name: c._id,
        count: c.count
      }))
    });
  } catch (error) {
    console.error('Error fetching categories:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch categories'
    });
  }
});

/**
 * GET /api/agents/category/:category
 * Get agents by category
 */
router.get('/category/:category', async (req, res) => {
  try {
    const { category } = req.params;
    const agents = await Agent.getByCategory(category);
    
    res.json({
      success: true,
      category,
      count: agents.length,
      agents: agents.map(a => a.toPublicJSON())
    });
  } catch (error) {
    console.error('Error fetching agents by category:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch agents by category'
    });
  }
});

/**
 * GET /api/agents/search
 * Search agents by name, description, or tags
 */
router.get('/search', async (req, res) => {
  try {
    const { q } = req.query;
    
    if (!q || q.trim().length < 2) {
      return res.status(400).json({
        success: false,
        error: 'Search query must be at least 2 characters'
      });
    }
    
    const agents = await Agent.search(q.trim());
    
    res.json({
      success: true,
      query: q,
      count: agents.length,
      agents: agents.map(a => a.toPublicJSON())
    });
  } catch (error) {
    console.error('Error searching agents:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to search agents'
    });
  }
});

/**
 * GET /api/agents/detail/:agentId
 * Get single agent by agentId
 * Using /detail/:agentId to avoid conflict with purchase routes /:agentId/purchase
 */
router.get('/detail/:agentId', async (req, res) => {
  try {
    const { agentId } = req.params;
    const agent = await Agent.getByAgentId(agentId);
    
    if (!agent) {
      return res.status(404).json({
        success: false,
        error: 'Agent not found'
      });
    }
    
    res.json({
      success: true,
      agent: agent.toPublicJSON()
    });
  } catch (error) {
    console.error('Error fetching agent:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch agent'
    });
  }
});

/**
 * GET /api/agents/config/:agentId
 * Get agent backend configuration (for AI processing)
 * Protected - should be internal use only
 */
router.get('/config/:agentId', async (req, res) => {
  try {
    const { agentId } = req.params;
    const agent = await Agent.getByAgentId(agentId);
    
    if (!agent) {
      return res.status(404).json({
        success: false,
        error: 'Agent not found'
      });
    }
    
    res.json({
      success: true,
      config: agent.getBackendConfig()
    });
  } catch (error) {
    console.error('Error fetching agent config:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch agent config'
    });
  }
});

// ==========================================
// ADMIN ROUTES (Add auth middleware in production)
// ==========================================

/**
 * POST /api/agents/invalidate-cache
 * Invalidate the agents cache (admin only)
 */
router.post('/invalidate-cache', async (req, res) => {
  try {
    invalidateCache();
    res.json({
      success: true,
      message: 'Agent cache invalidated'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Failed to invalidate cache'
    });
  }
});

/**
 * POST /api/agents/:agentId/stats
 * Update agent statistics (internal use)
 */
router.post('/:agentId/stats', async (req, res) => {
  try {
    const { agentId } = req.params;
    const { field, value = 1 } = req.body;
    
    if (!field || !['totalUsers', 'totalMessages'].includes(field)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid stats field'
      });
    }
    
    await Agent.incrementStats(agentId, field, value);
    invalidateCache();
    
    res.json({
      success: true,
      message: `Stats updated for ${agentId}`
    });
  } catch (error) {
    console.error('Error updating agent stats:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to update agent stats'
    });
  }
});

module.exports = router;
