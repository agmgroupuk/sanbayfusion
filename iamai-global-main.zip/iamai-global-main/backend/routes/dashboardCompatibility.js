/**
 * Dashboard Compatibility Routes
 * Provides backward-compatible dashboard data endpoints backed by real ActivityLog data
 */

const { ActivityLog } = require('../models');

/**
 * Get sessions data in a compatible format
 * Uses real ActivityLog data for the authenticated user
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 */
const getSessionsCompatible = async (req, res) => {
  try {
    if (!req.userId) {
      return res.status(401).json({
        success: false,
        error: 'Authentication required',
      });
    }

    const now = new Date();
    const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);

    // Aggregate sessions for the current user over the last 30 days
    const sessions = await ActivityLog.aggregate([
      {
        $match: {
          userId: req.userId,
          createdAt: { $gte: thirtyDaysAgo },
        },
      },
      {
        $group: {
          _id: '$sessionId',
          firstSeen: { $min: '$createdAt' },
          lastSeen: { $max: '$createdAt' },
          ipAddress: { $first: '$ipAddress' },
          userAgent: { $first: '$userAgent' },
        },
      },
      { $sort: { lastSeen: -1 } },
      { $limit: 50 },
    ]);

    const totalSessions = sessions.length;
    const activeSessions = sessions.filter((s) =>
      s.lastSeen && s.lastSeen > new Date(now.getTime() - 24 * 60 * 60 * 1000)
    ).length;

    const recentSessions = sessions.map((s) => ({
      sessionId: s._id,
      firstSeen: s.firstSeen,
      lastSeen: s.lastSeen,
      ipAddress: s.ipAddress,
      userAgent: s.userAgent,
    }));

    const sessionsData = {
      totalSessions,
      activeSessions,
      recentSessions,
      sessionsByHour: [],
      sessionsByDay: [],
    };

    res.json({
      success: true,
      data: sessionsData,
    });
  } catch (error) {
    console.error('Error in getSessionsCompatible:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch sessions data',
    });
  }
};

/**
 * Get activity data in a compatible format
 * Uses real ActivityLog data for the authenticated user
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 */
const getActivityCompatible = async (req, res) => {
  try {
    if (!req.userId) {
      return res.status(401).json({
        success: false,
        error: 'Authentication required',
      });
    }

    const { limit = 100 } = req.query;

    const activities = await ActivityLog.find({ userId: req.userId })
      .sort({ createdAt: -1 })
      .limit(parseInt(limit, 10))
      .lean();

    const totalActivity = await ActivityLog.countDocuments({ userId: req.userId });

    const recentActivity = activities.map((a) => ({
      id: a._id,
      action: a.action,
      createdAt: a.createdAt,
      route: a.route,
      method: a.method,
      statusCode: a.statusCode,
      ipAddress: a.ipAddress,
      userAgent: a.userAgent,
      metadata: a.metadata,
    }));

    const activityData = {
      totalActivity,
      recentActivity,
      activityByHour: [],
      activityByDay: [],
      topPages: [],
      userActions: [],
    };

    res.json({
      success: true,
      data: activityData,
    });
  } catch (error) {
    console.error('Error in getActivityCompatible:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch activity data',
    });
  }
};

module.exports = {
  getSessionsCompatible,
  getActivityCompatible,
};
