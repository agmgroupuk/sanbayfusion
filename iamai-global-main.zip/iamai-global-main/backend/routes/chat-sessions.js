// Enhanced Chat Session API Routes - Critical EnhancedChatInterface Support
// Implements /api/chat/sessions and related endpoints for chat management

const express = require('express');
const router = express.Router();
const { FileUpload } = require('../models');
const { ChatSession, MessageReaction, ConversationAnalytics } = require('../content-models');
const { authenticate } = require('../auth-middleware');
const multer = require('multer');
const path = require('path');

// Multer configuration for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/chat-attachments/');
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
    cb(null, `${uniqueSuffix}${path.extname(file.originalname)}`);
  },
});

const upload = multer({
  storage,
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    // Allow images, documents, and text files
    const allowedTypes = /jpeg|jpg|png|gif|pdf|doc|docx|txt|csv|json/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);

    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb(new Error('Invalid file type'));
    }
  },
});

// ============================================
// CHAT SESSION MANAGEMENT ENDPOINTS
// ============================================

// GET /api/chat/sessions/user/:userId - Get user's chat sessions
router.get('/sessions/user/:userId', authenticate, async (req, res) => {
  try {
    const { userId } = req.params;
    const {
      agentId,
      isActive,
      limit = 20,
      offset = 0,
      sortBy = 'createdAt',
      sortOrder = 'desc',
    } = req.query;

    // Verify user can access these sessions
    if (req.userId.toString() !== userId) {
      return res.status(403).json({
        success: false,
        error: 'Access denied',
      });
    }

    // Build query
    const query = { userId };
    if (agentId) query.agentId = agentId;
    if (isActive !== undefined) query['sessionInfo.isActive'] = isActive === 'true';

    const sessions = await ChatSession.find(query)
      .sort({ [sortBy]: sortOrder === 'desc' ? -1 : 1 })
      .limit(parseInt(limit))
      .skip(parseInt(offset))
      .select('sessionId agentId sessionInfo sessionStats createdAt updatedAt messages')
      .lean();

    // Add message preview for each session
    const sessionsWithPreview = sessions.map(session => ({
      ...session,
      lastMessage:
        session.messages && session.messages.length > 0
          ? session.messages[session.messages.length - 1]
          : null,
      messageCount: session.messages ? session.messages.length : 0,
    }));

    const total = await ChatSession.countDocuments(query);

    res.json({
      success: true,
      data: {
        sessions: sessionsWithPreview,
        pagination: {
          total,
          limit: parseInt(limit),
          offset: parseInt(offset),
          hasMore: parseInt(offset) + parseInt(limit) < total,
        },
      },
    });
  } catch (error) {
    console.error('Get chat sessions error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch chat sessions',
    });
  }
});

// GET /api/chat/sessions/:sessionId - Get specific chat session with full message history
router.get('/sessions/:sessionId', authenticate, async (req, res) => {
  try {
    const { sessionId } = req.params;
    const userId = req.userId || '507f1f77bcf86cd799439011'; // Valid ObjectId for testing without auth

    const session = await ChatSession.findOne({
      sessionId,
      userId,
    }).lean();

    if (!session) {
      return res.status(404).json({
        success: false,
        error: 'Chat session not found',
      });
    }

    // Get conversation analytics if available
    const analytics = await ConversationAnalytics.findOne({
      sessionId,
      userId,
    });

    res.json({
      success: true,
      data: {
        session,
        analytics: analytics || null,
      },
    });
  } catch (error) {
    console.error('Get chat session error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch chat session',
    });
  }
});

// POST /api/chat/sessions/create - Create new chat session
router.post('/sessions/create', authenticate, async (req, res) => {
  console.log('🔄 CHAT SESSION CREATE REQUEST:', {
    userId: req.userId,
    body: req.body,
    headers: req.headers.authorization ? 'Bearer token present' : 'No auth header',
  });
  try {
    const userId = req.userId || '507f1f77bcf86cd799439011'; // Valid ObjectId for testing without auth
    const { agentId, agentName, agentDisplayName, title, description } = req.body;

    if (!agentId || !agentName) {
      return res.status(400).json({
        success: false,
        error: 'AgentId and agentName are required',
      });
    }

    const sessionId = `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

    const session = new ChatSession({
      userId,
      agentId,
      sessionId,
      sessionInfo: {
        agentName,
        agentDisplayName: agentDisplayName || agentName,
        title: title || `Chat with ${agentDisplayName || agentName}`,
        description,
        isActive: true,
      },
      messages: [],
      sessionStats: {
        totalMessages: 0,
        userMessages: 0,
        assistantMessages: 0,
      },
    });

    await session.save();

    res.json({
      success: true,
      data: session,
      message: 'Chat session created successfully',
    });
  } catch (error) {
    console.error('Create chat session error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to create chat session',
    });
  }
});

// POST /api/chat/sessions/:sessionId/messages - Add message to chat session
router.post('/sessions/:sessionId/messages', authenticate, async (req, res) => {
  console.log('💬 ADD MESSAGE REQUEST:', {
    sessionId: req.params.sessionId,
    userId: req.userId || '507f1f77bcf86cd799439011',
    message: req.body,
  });
  try {
    const { sessionId } = req.params;
    const userId = req.userId || '507f1f77bcf86cd799439011'; // Valid ObjectId for testing without auth
    const { content, role = 'user', attachments = [], metadata = {} } = req.body;

    if (!content) {
      return res.status(400).json({
        success: false,
        error: 'Message content is required',
      });
    }

    const messageId = `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

    const message = {
      messageId,
      role,
      content,
      timestamp: new Date(),
      metadata,
      attachments,
      reactions: [],
      status: {
        delivered: true,
        read: false,
      },
    };

    const session = await ChatSession.findOneAndUpdate(
      { sessionId, userId },
      {
        $push: { messages: message },
        $inc: {
          'sessionStats.totalMessages': 1,
          [`sessionStats.${role}Messages`]: 1,
        },
        $set: {
          'sessionStats.lastMessageAt': new Date(),
        },
      },
      { new: true }
    );

    if (!session) {
      return res.status(404).json({
        success: false,
        error: 'Chat session not found',
      });
    }

    res.json({
      success: true,
      data: {
        message,
        sessionStats: session.sessionStats,
      },
    });
  } catch (error) {
    console.error('Add message error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to add message to chat session',
    });
  }
});

// ============================================
// FILE UPLOAD ENDPOINTS FOR CHAT
// ============================================

// POST /api/chat/upload - Upload file for chat attachment
router.post('/upload', authenticate, upload.single('file'), async (req, res) => {
  try {
    const userId = req.userId;
    const { sessionId, messageId } = req.body;

    if (!req.file) {
      return res.status(400).json({
        success: false,
        error: 'No file uploaded',
      });
    }

    const fileId = `file_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

    const fileUpload = new FileUpload({
      userId,
      fileId,
      fileInfo: {
        originalName: req.file.originalname,
        fileName: req.file.filename,
        mimeType: req.file.mimetype,
        fileSize: req.file.size,
        fileExtension: path.extname(req.file.originalname),
      },
      storage: {
        provider: 'local',
        path: req.file.path,
        url: `/uploads/chat-attachments/${req.file.filename}`,
      },
      processing: {
        status: 'completed',
      },
      usage: {
        associatedSessions: sessionId ? [sessionId] : [],
        associatedMessages: messageId ? [messageId] : [],
      },
    });

    await fileUpload.save();

    res.json({
      success: true,
      data: {
        fileId,
        fileName: req.file.originalname,
        fileType: req.file.mimetype,
        fileSize: req.file.size,
        fileUrl: fileUpload.storage.url,
      },
      message: 'File uploaded successfully',
    });
  } catch (error) {
    console.error('File upload error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to upload file',
    });
  }
});

// GET /api/chat/files/user/:userId - Get user's uploaded files
router.get('/files/user/:userId', authenticate, async (req, res) => {
  try {
    const { userId } = req.params;
    const { limit = 20, offset = 0, fileType } = req.query;

    // Verify user can access these files
    if (req.userId.toString() !== userId) {
      return res.status(403).json({
        success: false,
        error: 'Access denied',
      });
    }

    const query = { userId };
    if (fileType) query['fileInfo.mimeType'] = new RegExp(fileType, 'i');

    const files = await FileUpload.find(query)
      .sort({ createdAt: -1 })
      .limit(parseInt(limit))
      .skip(parseInt(offset))
      .select('fileId fileInfo storage usage createdAt');

    const total = await FileUpload.countDocuments(query);

    res.json({
      success: true,
      data: {
        files,
        pagination: {
          total,
          limit: parseInt(limit),
          offset: parseInt(offset),
          hasMore: parseInt(offset) + parseInt(limit) < total,
        },
      },
    });
  } catch (error) {
    console.error('Get user files error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch user files',
    });
  }
});

// ============================================
// MESSAGE REACTIONS ENDPOINTS
// ============================================

// POST /api/chat/messages/:messageId/reactions - Add reaction to message
router.post('/messages/:messageId/reactions', authenticate, async (req, res) => {
  try {
    const { messageId } = req.params;
    const userId = req.userId;
    const { reactionType, sessionId, comment } = req.body;

    if (!reactionType || !sessionId) {
      return res.status(400).json({
        success: false,
        error: 'Reaction type and session ID are required',
      });
    }

    // Check if user already has a reaction for this message
    const existingReaction = await MessageReaction.findOne({ messageId, userId });

    let reaction;
    if (existingReaction) {
      // Update existing reaction
      reaction = await MessageReaction.findOneAndUpdate(
        { messageId, userId },
        {
          'reaction.type': reactionType,
          'reaction.comment': comment,
        },
        { new: true }
      );
    } else {
      // Create new reaction
      reaction = new MessageReaction({
        messageId,
        sessionId,
        userId,
        reaction: {
          type: reactionType,
          comment,
        },
      });
      await reaction.save();
    }

    // Update the message in chat session
    await ChatSession.updateOne(
      {
        sessionId,
        userId,
        'messages.messageId': messageId,
      },
      {
        $set: {
          'messages.$.reactions': [
            {
              reactionType,
              userId,
              timestamp: new Date(),
            },
          ],
        },
      }
    );

    res.json({
      success: true,
      data: reaction,
      message: 'Reaction added successfully',
    });
  } catch (error) {
    console.error('Add reaction error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to add reaction',
    });
  }
});

// GET /api/chat/messages/:messageId/reactions - Get message reactions
router.get('/messages/:messageId/reactions', authenticate, async (req, res) => {
  try {
    const { messageId } = req.params;

    const reactions = await MessageReaction.find({ messageId })
      .populate('userId', 'email profile.displayName')
      .sort({ createdAt: -1 });

    const reactionSummary = reactions.reduce((acc, reaction) => {
      const type = reaction.reaction.type;
      if (!acc[type]) {
        acc[type] = 0;
      }
      acc[type]++;
      return acc;
    }, {});

    res.json({
      success: true,
      data: {
        reactions,
        summary: reactionSummary,
        total: reactions.length,
      },
    });
  } catch (error) {
    console.error('Get reactions error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch message reactions',
    });
  }
});

module.exports = router;
