/**
 * Analytics API Routes
 * Endpoints for fetching activity tracking data
 */

const express = require('express');
const router = express.Router();

module.exports = (ActivityLog, Chat, User) => {
  
  /**
   * GET /api/analytics/overview
   * Get high-level analytics overview
   */
  router.get('/overview', async (req, res) => {
    try {
      const { timeframe = '24h', userId } = req.query;
      
      // Calculate time range
      const now = new Date();
      let startDate = new Date();
      
      switch (timeframe) {
        case '1h':
          startDate.setHours(now.getHours() - 1);
          break;
        case '24h':
          startDate.setDate(now.getDate() - 1);
          break;
        case '7d':
          startDate.setDate(now.getDate() - 7);
          break;
        case '30d':
          startDate.setDate(now.getDate() - 30);
          break;
        default:
          startDate.setDate(now.getDate() - 1);
      }
      
      // Build query
      const query = {
        createdAt: { $gte: startDate }
      };
      
      if (userId) {
        query.userId = userId;
      }
      
      // Get aggregated stats
      const [
        totalActivities,
        uniqueSessions,
        uniqueUsers,
        actionBreakdown,
        anonymousCount,
        topActions
      ] = await Promise.all([
        ActivityLog.countDocuments(query),
        ActivityLog.distinct('sessionId', query).then(sessions => sessions.length),
        ActivityLog.distinct('userId', { ...query, userId: { $ne: null } }).then(users => users.length),
        ActivityLog.aggregate([
          { $match: query },
          { $group: { _id: '$action', count: { $sum: 1 } } },
          { $sort: { count: -1 } }
        ]),
        ActivityLog.countDocuments({ ...query, isAnonymous: true }),
        ActivityLog.aggregate([
          { $match: query },
          { $group: { _id: '$action', count: { $sum: 1 }, avgResponseTime: { $avg: '$responseTime' } } },
          { $sort: { count: -1 } },
          { $limit: 10 }
        ])
      ]);
      
      // Get demo chat stats
      const demoChatCount = await Chat.countDocuments({
        createdAt: { $gte: startDate },
        isAnonymous: true
      });
      
      const demoChatMessages = await Chat.aggregate([
        {
          $match: {
            createdAt: { $gte: startDate },
            isAnonymous: true
          }
        },
        {
          $project: {
            messageCount: { $size: '$messages' }
          }
        },
        {
          $group: {
            _id: null,
            totalMessages: { $sum: '$messageCount' }
          }
        }
      ]);
      
      res.json({
        success: true,
        timeframe,
        period: {
          start: startDate.toISOString(),
          end: now.toISOString()
        },
        overview: {
          totalActivities,
          uniqueSessions,
          uniqueUsers,
          anonymousUsers: anonymousCount,
          registeredUsers: uniqueUsers
        },
        demoChats: {
          totalChats: demoChatCount,
          totalMessages: demoChatMessages[0]?.totalMessages || 0
        },
        actionBreakdown: actionBreakdown.reduce((acc, item) => {
          acc[item._id] = item.count;
          return acc;
        }, {}),
        topActions: topActions.map(item => ({
          action: item._id,
          count: item.count,
          avgResponseTime: Math.round(item.avgResponseTime || 0)
        }))
      });
      
    } catch (error) {
      console.error('Error fetching analytics overview:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to fetch analytics overview'
      });
    }
  });
  
  /**
   * GET /api/analytics/activities
   * Get detailed activity logs
   */
  router.get('/activities', async (req, res) => {
    try {
      const { 
        page = 1, 
        limit = 50, 
        action, 
        userId, 
        sessionId, 
        isAnonymous,
        startDate,
        endDate
      } = req.query;
      
      // Build query
      const query = {};
      
      if (action) query.action = action;
      if (userId) query.userId = userId;
      if (sessionId) query.sessionId = sessionId;
      if (isAnonymous !== undefined) query.isAnonymous = isAnonymous === 'true';
      
      if (startDate || endDate) {
        query.createdAt = {};
        if (startDate) query.createdAt.$gte = new Date(startDate);
        if (endDate) query.createdAt.$lte = new Date(endDate);
      }
      
      const skip = (parseInt(page) - 1) * parseInt(limit);
      
      const [activities, total] = await Promise.all([
        ActivityLog.find(query)
          .sort({ createdAt: -1 })
          .skip(skip)
          .limit(parseInt(limit))
          .populate('userId', 'name email')
          .lean(),
        ActivityLog.countDocuments(query)
      ]);
      
      res.json({
        success: true,
        data: activities,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total,
          pages: Math.ceil(total / parseInt(limit))
        }
      });
      
    } catch (error) {
      console.error('Error fetching activities:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to fetch activities'
      });
    }
  });
  
  /**
   * GET /api/analytics/sessions
   * Get session-based analytics
   */
  router.get('/sessions', async (req, res) => {
    try {
      const { timeframe = '24h', limit = 20 } = req.query;
      
      // Calculate time range
      const now = new Date();
      let startDate = new Date();
      
      switch (timeframe) {
        case '1h':
          startDate.setHours(now.getHours() - 1);
          break;
        case '24h':
          startDate.setDate(now.getDate() - 1);
          break;
        case '7d':
          startDate.setDate(now.getDate() - 7);
          break;
        default:
          startDate.setDate(now.getDate() - 1);
      }
      
      // Aggregate session data
      const sessions = await ActivityLog.aggregate([
        {
          $match: {
            createdAt: { $gte: startDate }
          }
        },
        {
          $group: {
            _id: '$sessionId',
            userId: { $first: '$userId' },
            isAnonymous: { $first: '$isAnonymous' },
            activityCount: { $sum: 1 },
            actions: { $push: '$action' },
            firstSeen: { $min: '$createdAt' },
            lastSeen: { $max: '$createdAt' },
            ipAddress: { $first: '$ipAddress' },
            userAgent: { $first: '$userAgent' }
          }
        },
        {
          $project: {
            sessionId: '$_id',
            userId: 1,
            isAnonymous: 1,
            activityCount: 1,
            uniqueActions: { $size: { $setUnion: '$actions' } },
            duration: { $subtract: ['$lastSeen', '$firstSeen'] },
            firstSeen: 1,
            lastSeen: 1,
            ipAddress: 1,
            userAgent: 1
          }
        },
        {
          $sort: { lastSeen: -1 }
        },
        {
          $limit: parseInt(limit)
        }
      ]);
      
      res.json({
        success: true,
        timeframe,
        sessions: sessions.map(s => ({
          ...s,
          durationMinutes: Math.round(s.duration / 60000)
        }))
      });
      
    } catch (error) {
      console.error('Error fetching sessions:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to fetch session data'
      });
    }
  });
  
  /**
   * GET /api/analytics/demo-chats
   * Get demo chat analytics
   */
  router.get('/demo-chats', async (req, res) => {
    try {
      const { timeframe = '24h', limit = 20 } = req.query;
      
      // Calculate time range
      const now = new Date();
      let startDate = new Date();
      
      switch (timeframe) {
        case '1h':
          startDate.setHours(now.getHours() - 1);
          break;
        case '24h':
          startDate.setDate(now.getDate() - 1);
          break;
        case '7d':
          startDate.setDate(now.getDate() - 7);
          break;
        default:
          startDate.setDate(now.getDate() - 1);
      }
      
      // Get demo chats
      const demoChats = await Chat.find({
        createdAt: { $gte: startDate },
        isAnonymous: true
      })
        .sort({ createdAt: -1 })
        .limit(parseInt(limit))
        .select('sessionId agentId title messages createdAt updatedAt totalCreditsUsed')
        .lean();
      
      // Aggregate stats
      const stats = await Chat.aggregate([
        {
          $match: {
            createdAt: { $gte: startDate },
            isAnonymous: true
          }
        },
        {
          $group: {
            _id: '$agentId',
            count: { $sum: 1 },
            totalMessages: { $sum: { $size: '$messages' } },
            avgMessages: { $avg: { $size: '$messages' } }
          }
        },
        {
          $sort: { count: -1 }
        }
      ]);
      
      res.json({
        success: true,
        timeframe,
        demoChats: demoChats.map(chat => ({
          ...chat,
          messageCount: chat.messages?.length || 0
        })),
        stats: {
          byAgent: stats.map(s => ({
            agentId: s._id,
            chatCount: s.count,
            totalMessages: s.totalMessages,
            avgMessagesPerChat: Math.round(s.avgMessages)
          }))
        }
      });
      
    } catch (error) {
      console.error('Error fetching demo chats:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to fetch demo chat data'
      });
    }
  });
  
  /**
   * GET /api/analytics/realtime
   * Get real-time activity feed
   */
  router.get('/realtime', async (req, res) => {
    try {
      const { limit = 10 } = req.query;
      
      // Get most recent activities
      const activities = await ActivityLog.find()
        .sort({ createdAt: -1 })
        .limit(parseInt(limit))
        .populate('userId', 'name email')
        .lean();
      
      // Get active sessions (activity in last 5 minutes)
      const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000);
      const activeSessions = await ActivityLog.distinct('sessionId', {
        createdAt: { $gte: fiveMinutesAgo }
      });
      
      res.json({
        success: true,
        recentActivities: activities,
        activeSessionsCount: activeSessions.length
      });
      
    } catch (error) {
      console.error('Error fetching realtime data:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to fetch realtime data'
      });
    }
  });
  
  /**
   * GET /api/analytics/lab-metrics
   * Get current metrics for all AI Lab features
   */
  router.get('/lab-metrics', async (req, res) => {
    try {
      // In-memory metrics storage (in production, this would be in a database)
      const labMetrics = {
        'playground': { tests: 0, users: 0, views: 0 },
        'prompt-engineering': { tests: 0, users: 0, views: 0 },
        'battle-arena': { tests: 0, users: 0, views: 0 },
        'text-transformers': { tests: 0, users: 0, views: 0 },
        'code-playground': { tests: 0, users: 0, views: 0 },
        'sentiment-analyzer': { tests: 0, users: 0, views: 0 },
        'ai-lab-research': { tests: 0, users: 0, views: 0 },
        'ai-lab-settings': { tests: 0, users: 0, views: 0 },
        'ai-lab-templates': { tests: 0, users: 0, views: 0 },
        'ai-lab-cost': { tests: 0, users: 0, views: 0 },
        'ai-lab-latency': { tests: 0, users: 0, views: 0 },
        'ai-lab-history': { tests: 0, users: 0, views: 0 }
      };

      // Try to get real metrics from ActivityLog if available
      try {
        const last24h = new Date(Date.now() - 24 * 60 * 60 * 1000);
        
        // Get activity counts for each lab feature
        const activities = await ActivityLog.find({
          createdAt: { $gte: last24h },
          action: { $regex: /^ai-lab/ }
        }).lean();

        // Count activities by feature
        activities.forEach(activity => {
          const feature = activity.action.replace('ai-lab-', '').replace('-view', '').replace('-test', '');
          if (labMetrics[feature]) {
            labMetrics[feature].views += 1;
            if (activity.action.includes('-test')) {
              labMetrics[feature].tests += 1;
            }
          }
        });

        // Get unique users per feature
        const userCounts = await ActivityLog.aggregate([
          {
            $match: {
              createdAt: { $gte: last24h },
              action: { $regex: /^ai-lab/ },
              userId: { $ne: null }
            }
          },
          {
            $group: {
              _id: {
                feature: {
                  $regexMatch: {
                    input: '$action',
                    regex: '^ai-lab-([^-]+)'
                  }
                },
                userId: '$userId'
              }
            }
          },
          {
            $group: {
              _id: '$_id.feature',
              userCount: { $sum: 1 }
            }
          }
        ]);

        userCounts.forEach(count => {
          const feature = count._id?.groups?.[1];
          if (feature && labMetrics[feature]) {
            labMetrics[feature].users = count.userCount;
          }
        });

      } catch (error) {
        console.warn('Could not fetch real metrics, using defaults:', error.message);
      }

      res.json({
        success: true,
        data: labMetrics
      });
    } catch (error) {
      console.error('Error fetching lab metrics:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to retrieve lab metrics'
      });
    }
  });
  
  return router;
};
