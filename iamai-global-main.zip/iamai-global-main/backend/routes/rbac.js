// Role-Based Access Control Routes
// Complete RBAC management system

const express = require('express');
const { Role, Permission, UserRole, RolePermission } = require('../rbac-models');
const { User } = require('../models');
const { authenticate, requireTier, validateFields } = require('../auth-middleware');

const router = express.Router();

// ============================================
// ROLE ROUTES
// ============================================

/**
 * GET /api/rbac/roles
 * Get all active roles (public for role selection)
 */
router.get('/roles', authenticate, async (req, res) => {
  try {
    const roles = await Role.find({ 
      isActive: true,
      'ui.hideFromLists': { $ne: true }
    })
      .sort({ level: -1 })
      .select('name displayName description level category ui')
      .populate('permissions', 'name displayName category');

    res.json({
      success: true,
      data: roles
    });

  } catch (error) {
    console.error('Roles fetch error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve roles',
      message: error.message
    });
  }
});

/**
 * GET /api/rbac/roles/:roleId
 * Get specific role details
 */
router.get('/roles/:roleId', authenticate, requireTier(['admin', 'user_manager']), async (req, res) => {
  try {
    const role = await Role.findById(req.params.roleId)
      .populate('permissions')
      .populate('inheritsFrom', 'name displayName');

    if (!role) {
      return res.status(404).json({
        success: false,
        error: 'Role not found'
      });
    }

    res.json({
      success: true,
      data: role
    });

  } catch (error) {
    console.error('Role fetch error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve role',
      message: error.message
    });
  }
});

/**
 * POST /api/rbac/roles
 * Create new role (admin only)
 */
router.post('/roles', authenticate, requireTier(['admin']), validateFields(['name', 'displayName', 'description', 'level', 'category']), async (req, res) => {
  try {
    const { name, displayName, description, level, category, permissions, limitations } = req.body;

    const role = new Role({
      name: name.toLowerCase(),
      displayName,
      description,
      level,
      category,
      permissions: permissions || [],
      limitations: limitations || {},
      metadata: {
        createdBy: req.userId
      }
    });

    await role.save();

    res.json({
      success: true,
      data: role,
      message: 'Role created successfully'
    });

  } catch (error) {
    console.error('Role creation error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to create role',
      message: error.message
    });
  }
});

// ============================================
// PERMISSION ROUTES
// ============================================

/**
 * GET /api/rbac/permissions
 * Get all permissions grouped by category
 */
router.get('/permissions', authenticate, requireTier(['admin', 'user_manager']), async (req, res) => {
  try {
    const { category } = req.query;
    
    const query = { isActive: true };
    if (category) query.category = category;

    const permissions = await Permission.find(query)
      .sort({ category: 1, 'ui.order': 1, name: 1 });

    // Group by category
    const groupedPermissions = permissions.reduce((acc, permission) => {
      if (!acc[permission.category]) {
        acc[permission.category] = [];
      }
      acc[permission.category].push(permission);
      return acc;
    }, {});

    res.json({
      success: true,
      data: {
        permissions,
        grouped: groupedPermissions,
        categories: Object.keys(groupedPermissions)
      }
    });

  } catch (error) {
    console.error('Permissions fetch error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve permissions',
      message: error.message
    });
  }
});

// ============================================
// USER ROLE ROUTES
// ============================================

/**
 * GET /api/rbac/user-roles/me
 * Get current user's roles
 */
router.get('/user-roles/me', authenticate, async (req, res) => {
  try {
    const userRoles = await UserRole.find({
      userId: req.userId,
      isActive: true
    })
      .populate('roleId', 'name displayName description level permissions')
      .populate('assignedBy', 'name email');

    // Check which roles are currently valid
    const validRoles = userRoles.filter(ur => ur.isCurrentlyValid());

    res.json({
      success: true,
      data: {
        userRoles: validRoles,
        totalRoles: userRoles.length,
        activeRoles: validRoles.length
      }
    });

  } catch (error) {
    console.error('User roles fetch error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve user roles',
      message: error.message
    });
  }
});

/**
 * POST /api/rbac/user-roles
 * Assign role to user (admin only)
 */
router.post('/user-roles', authenticate, requireTier(['admin', 'user_manager']), validateFields(['userId', 'roleId', 'reason']), async (req, res) => {
  try {
    const { userId, roleId, reason, validUntil, isTemporary } = req.body;

    // Check if user already has this role
    const existingUserRole = await UserRole.findOne({
      userId,
      roleId,
      isActive: true
    });

    if (existingUserRole) {
      return res.status(400).json({
        success: false,
        error: 'User already has this role'
      });
    }

    const userRole = new UserRole({
      userId,
      roleId,
      assignedBy: req.userId,
      validUntil,
      isTemporary: isTemporary || false,
      context: {
        reason,
        source: 'manual'
      },
      approval: {
        status: 'auto_approved'
      }
    });

    await userRole.save();
    await userRole.populate('userId', 'name email');
    await userRole.populate('roleId', 'name displayName');
    await userRole.populate('assignedBy', 'name email');

    res.json({
      success: true,
      data: userRole,
      message: 'Role assigned successfully'
    });

  } catch (error) {
    console.error('Role assignment error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to assign role',
      message: error.message
    });
  }
});

/**
 * DELETE /api/rbac/user-roles/:userRoleId
 * Remove role from user (admin only)
 */
router.delete('/user-roles/:userRoleId', authenticate, requireTier(['admin', 'user_manager']), async (req, res) => {
  try {
    const userRole = await UserRole.findByIdAndUpdate(
      req.params.userRoleId,
      { 
        isActive: false,
        'metadata.updatedBy': req.userId
      },
      { new: true }
    );

    if (!userRole) {
      return res.status(404).json({
        success: false,
        error: 'User role assignment not found'
      });
    }

    res.json({
      success: true,
      message: 'Role removed successfully'
    });

  } catch (error) {
    console.error('Role removal error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to remove role',
      message: error.message
    });
  }
});

/**
 * GET /api/rbac/check-permission
 * Check if current user has specific permission
 */
router.get('/check-permission', authenticate, async (req, res) => {
  try {
    const { permission, resource, action } = req.query;

    if (!permission && (!resource || !action)) {
      return res.status(400).json({
        success: false,
        error: 'Permission name or resource+action required'
      });
    }

    // Get user's active roles
    const userRoles = await UserRole.find({
      userId: req.userId,
      isActive: true
    }).populate({
      path: 'roleId',
      populate: {
        path: 'permissions',
        model: 'Permission'
      }
    });

    const validRoles = userRoles.filter(ur => ur.isCurrentlyValid());
    
    // Check permissions
    let hasPermission = false;
    const permissionName = permission || `${resource}_${action}`;

    for (const userRole of validRoles) {
      const rolePermissions = userRole.roleId.permissions || [];
      hasPermission = rolePermissions.some(perm => 
        perm.name === permissionName || 
        (perm.resource === resource && perm.action === action)
      );
      
      if (hasPermission) break;
    }

    res.json({
      success: true,
      data: {
        hasPermission,
        permission: permissionName,
        roles: validRoles.map(ur => ur.roleId.name)
      }
    });

  } catch (error) {
    console.error('Permission check error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to check permission',
      message: error.message
    });
  }
});

// ============================================
// ADMIN ROUTES
// ============================================

/**
 * GET /api/rbac/admin/users
 * Admin: Get all users with their roles
 */
router.get('/admin/users', authenticate, requireTier(['admin']), async (req, res) => {
  try {
    const { page = 1, limit = 50, search, role } = req.query;
    const skip = (page - 1) * limit;
    
    let userQuery = {};
    if (search) {
      userQuery.$or = [
        { name: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } }
      ];
    }

    const users = await User.find(userQuery)
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit))
      .select('name email currentPlan subscriptionStatus isActive createdAt');

    // Get roles for each user
    const usersWithRoles = await Promise.all(
      users.map(async (user) => {
        const userRoles = await UserRole.find({
          userId: user._id,
          isActive: true
        }).populate('roleId', 'name displayName level');
        
        const validRoles = userRoles.filter(ur => ur.isCurrentlyValid());
        
        return {
          ...user.toObject(),
          roles: validRoles.map(ur => ur.roleId)
        };
      })
    );

    const total = await User.countDocuments(userQuery);

    res.json({
      success: true,
      data: {
        users: usersWithRoles,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total,
          pages: Math.ceil(total / limit)
        }
      }
    });

  } catch (error) {
    console.error('Admin users fetch error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve users',
      message: error.message
    });
  }
});

/**
 * GET /api/rbac/admin/analytics
 * Admin: Get RBAC analytics
 */
router.get('/admin/analytics', authenticate, requireTier(['admin']), async (req, res) => {
  try {
    const totalRoles = await Role.countDocuments({ isActive: true });
    const totalPermissions = await Permission.countDocuments({ isActive: true });
    const totalUserRoles = await UserRole.countDocuments({ isActive: true });
    
    const roleDistribution = await UserRole.aggregate([
      { $match: { isActive: true } },
      {
        $lookup: {
          from: 'roles',
          localField: 'roleId',
          foreignField: '_id',
          as: 'role'
        }
      },
      { $unwind: '$role' },
      {
        $group: {
          _id: '$role.name',
          count: { $sum: 1 },
          displayName: { $first: '$role.displayName' }
        }
      },
      { $sort: { count: -1 } }
    ]);

    const permissionsByCategory = await Permission.aggregate([
      { $match: { isActive: true } },
      {
        $group: {
          _id: '$category',
          count: { $sum: 1 }
        }
      },
      { $sort: { count: -1 } }
    ]);

    res.json({
      success: true,
      data: {
        overview: {
          totalRoles,
          totalPermissions,
          totalUserRoles
        },
        roleDistribution,
        permissionsByCategory
      }
    });

  } catch (error) {
    console.error('RBAC analytics error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve RBAC analytics',
      message: error.message
    });
  }
});

module.exports = router;