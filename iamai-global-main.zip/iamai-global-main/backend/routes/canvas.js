/**
 * Canvas App API Routes
 * Backend integration for the canvas app builder with multi-provider AI support
 */

const express = require('express');
const { getAIService } = require('../ai-service');
const { authenticate } = require('../auth-middleware');
const { CanvasProject, CanvasTemplate } = require('../models.cjs');
const router = express.Router();

// Initialize AI Service
const aiService = getAIService();

/**
 * POST /api/canvas/generate
 * Generate or modify a canvas app using selected AI provider
 */
router.post('/generate', async (req, res) => {
  try {
    const {
      prompt,
      model = 'gemini-pro',
      provider = 'gemini',
      isThinking = false,
      currentCode,
      history = [],
      temperature = 0.7
    } = req.body;

    console.log('🎨 Canvas generation request:', {
      prompt: prompt?.substring(0, 100) + '...',
      model,
      provider,
      isThinking,
      hasCurrentCode: !!currentCode,
      historyLength: history.length
    });

    if (!prompt?.trim()) {
      return res.status(400).json({
        error: 'Prompt is required'
      });
    }

    // Build messages for AI
    const messages = [];

    // Add system instruction
    const systemInstruction = `You are a world-class senior frontend engineer and UI/UX designer.
Your task is to generate or modify a complete, high-quality, single-file HTML application.

Rules for generated code:
1. Use Tailwind CSS via CDN (<script src="https://cdn.tailwindcss.com"></script>).
2. Use Lucide icons via CDN (<script src="https://unpkg.com/lucide@latest"></script>).
3. Ensure the design is modern, professional, and mobile-responsive.
4. Include all necessary JavaScript.
5. The output MUST be a single, valid HTML file containing <html>, <head>, and <body> tags.
6. Return ONLY the code. No explanations, no markdown blocks.
7. Always return the FULL updated file.`;

    messages.push({
      role: 'system',
      content: systemInstruction
    });

    // Add current code context if modifying
    if (currentCode) {
      messages.push({
        role: 'user',
        content: `Current code:\n${currentCode}`
      });
      messages.push({
        role: 'assistant',
        content: 'I understand the current code. How would you like to modify it?'
      });
    }

    // Add conversation history
    history.forEach(msg => {
      messages.push({
        role: msg.role,
        content: msg.text
      });
    });

    // Add the new prompt
    messages.push({
      role: 'user',
      content: prompt
    });

    // Generate with selected provider
    const result = await aiService.chat(messages, {
      model,
      temperature: isThinking ? 1 : temperature,
      maxTokens: 8000,
      agentId: 'canvas-app',
      preferredProvider: provider
    });

    // Clean the response
    const cleanCode = result.content
      .replace(/```html/g, '')
      .replace(/```/g, '')
      .trim();

    res.json({
      code: cleanCode,
      provider: result.provider,
      model: result.model,
      usage: result.usage,
      thinking: isThinking
    });

  } catch (error) {
    console.error('Canvas generation error:', error);
    res.status(500).json({
      error: error.message || 'Failed to generate canvas app',
      details: process.env.NODE_ENV === 'development' ? error.stack : undefined
    });
  }
});

/**
 * GET /api/canvas/providers
 * Get available AI providers and their status
 */
router.get('/providers', async (req, res) => {
  try {
    const availableKeys = aiService.getAvailableKeys();
    const providers = {};

    // Only include providers with valid API keys
    if (availableKeys.openai) {
      providers.openai = {
        name: 'OpenAI',
        available: true,
        models: ['gpt-4', 'gpt-4-turbo', 'gpt-3.5-turbo']
      };
    }

    if (availableKeys.anthropic) {
      providers.anthropic = {
        name: 'Anthropic Claude',
        available: true,
        models: ['claude-3-opus', 'claude-3-sonnet', 'claude-3-haiku']
      };
    }

    if (availableKeys.groq) {
      providers.groq = {
        name: 'Groq',
        available: true,
        models: ['llama-3.3-70b-versatile', 'llama-3.1-8b-instant', 'mixtral-8x7b-32768']
      };
    }

    if (availableKeys.huggingface) {
      providers.huggingface = {
        name: 'Hugging Face',
        available: true,
        models: ['microsoft/DialoGPT-medium', 'facebook/blenderbot-400M-distill', 'google/flan-t5-base']
      };
    }

    if (availableKeys.replicate) {
      providers.replicate = {
        name: 'Replicate',
        available: true,
        models: ['meta/llama-2-70b-chat', 'stability-ai/sdxl', 'cjwbw/anything-v3-better-vae']
      };
    }

    res.json({
      providers,
      availableKeys: Object.keys(availableKeys)
    });
  } catch (error) {
    console.error('Error fetching providers:', error);
    res.status(500).json({ error: 'Failed to fetch providers' });
  }
});

/**
 * GET /api/canvas/templates
 * Get available canvas app templates
 */
router.get('/templates', async (req, res) => {
  try {
    const { category, limit = 50 } = req.query;

    let query = { isActive: true };
    if (category) {
      query.category = category;
    }

    const templates = await CanvasTemplate.find(query)
      .sort({ usageCount: -1, createdAt: -1 })
      .limit(parseInt(limit))
      .select('templateId name description category prompt difficulty estimatedTokens usageCount tags previewImage')
      .lean();

    // If no templates in database, return default templates
    if (templates.length === 0) {
      const defaultTemplates = [
        {
          templateId: 'landing-page',
          name: 'Landing Page',
          description: 'Modern SaaS landing page with hero, features, and CTA',
          category: 'business',
          prompt: 'Create a modern SaaS landing page for a productivity tool with hero section, feature grid, testimonials, and pricing section.',
          difficulty: 'beginner',
          estimatedTokens: 1500,
          usageCount: 0,
          tags: ['landing', 'saas', 'business'],
          isActive: true
        },
        {
          templateId: 'dashboard',
          name: 'Analytics Dashboard',
          description: 'Dark-themed analytics dashboard with charts and metrics',
          category: 'business',
          prompt: 'Build a dark-themed analytics dashboard with multiple chart types, KPI cards, and a sidebar navigation.',
          difficulty: 'intermediate',
          estimatedTokens: 2000,
          usageCount: 0,
          tags: ['dashboard', 'analytics', 'charts'],
          isActive: true
        },
        {
          templateId: 'portfolio',
          name: 'Portfolio Website',
          description: 'Creative portfolio with gallery and contact form',
          category: 'personal',
          prompt: 'Design a creative portfolio website with image gallery, about section, skills showcase, and contact form.',
          difficulty: 'beginner',
          estimatedTokens: 1200,
          usageCount: 0,
          tags: ['portfolio', 'personal', 'gallery'],
          isActive: true
        },
        {
          templateId: 'ecommerce',
          name: 'E-commerce Store',
          description: 'Simple online store with product grid and cart',
          category: 'business',
          prompt: 'Create a minimal e-commerce website with product grid, shopping cart, and checkout flow.',
          difficulty: 'intermediate',
          estimatedTokens: 1800,
          usageCount: 0,
          tags: ['ecommerce', 'shopping', 'store'],
          isActive: true
        },
        {
          templateId: 'blog',
          name: 'Blog Platform',
          description: 'Clean blog layout with articles and categories',
          category: 'content',
          prompt: 'Build a clean blog platform with article cards, categories, search functionality, and responsive design.',
          difficulty: 'intermediate',
          estimatedTokens: 1600,
          usageCount: 0,
          tags: ['blog', 'content', 'articles'],
          isActive: true
        },
        {
          templateId: 'chat-app',
          name: 'Chat Application',
          description: 'Real-time chat interface with message bubbles',
          category: 'utility',
          prompt: 'Design a modern chat application with message bubbles, user avatars, typing indicators, and emoji support.',
          difficulty: 'advanced',
          estimatedTokens: 2200,
          usageCount: 0,
          tags: ['chat', 'realtime', 'messaging'],
          isActive: true
        }
      ];

      // Optionally save default templates to database
      // await CanvasTemplate.insertMany(defaultTemplates);

      return res.json({ templates: defaultTemplates });
    }

    res.json({ templates });
  } catch (error) {
    console.error('Get templates error:', error);
    res.status(500).json({ error: 'Failed to fetch templates' });
  }
});

/**
 * POST /api/canvas/save
 * Save a canvas project to database
 */
router.post('/save', authenticate, async (req, res) => {
  try {
    const { projectId, code, name, description, template, provider, model, isPublic = false, tags = [] } = req.body;
    const userId = req.userId;

    if (!code || !name) {
      return res.status(400).json({ error: 'Code and name are required' });
    }

    let project;

    if (projectId) {
      // Update existing project
      project = await CanvasProject.findOneAndUpdate(
        { projectId, userId },
        {
          code,
          name,
          description,
          template,
          provider,
          model,
          isPublic,
          tags,
          'metadata.lastGenerated': new Date(),
          $inc: { 'metadata.generationCount': 1 }
        },
        { new: true, upsert: false }
      );

      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }
    } else {
      // Create new project
      const newProjectId = `canvas_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

      project = new CanvasProject({
        userId,
        projectId: newProjectId,
        name,
        description,
        code,
        template,
        provider,
        model,
        isPublic,
        tags,
        metadata: {
          lastGenerated: new Date(),
          generationCount: 1,
          totalTokens: 0,
          estimatedCost: 0
        }
      });

      await project.save();
    }

    res.json({
      success: true,
      projectId: project.projectId,
      message: projectId ? 'Project updated successfully' : 'Project saved successfully',
      project: {
        projectId: project.projectId,
        name: project.name,
        description: project.description,
        template: project.template,
        provider: project.provider,
        model: project.model,
        isPublic: project.isPublic,
        tags: project.tags,
        createdAt: project.createdAt,
        updatedAt: project.updatedAt
      }
    });
  } catch (error) {
    console.error('Save project error:', error);
    res.status(500).json({ error: 'Failed to save project' });
  }
});

/**
 * GET /api/canvas/projects
 * Get user's saved canvas projects
 */
router.get('/projects', authenticate, async (req, res) => {
  try {
    const userId = req.userId;
    const { limit = 20, offset = 0, sortBy = 'updatedAt', sortOrder = 'desc' } = req.query;

    const sortOptions = {};
    sortOptions[sortBy] = sortOrder === 'desc' ? -1 : 1;

    const projects = await CanvasProject.find({ userId })
      .sort(sortOptions)
      .limit(parseInt(limit))
      .skip(parseInt(offset))
      .select('projectId name description template provider model isPublic tags metadata createdAt updatedAt')
      .lean();

    const total = await CanvasProject.countDocuments({ userId });

    res.json({
      projects: projects.map(project => ({
        ...project,
        generationCount: project.metadata?.generationCount || 0,
        lastGenerated: project.metadata?.lastGenerated
      })),
      total,
      limit: parseInt(limit),
      offset: parseInt(offset)
    });
  } catch (error) {
    console.error('Get projects error:', error);
    res.status(500).json({ error: 'Failed to fetch projects' });
  }
});

/**
 * GET /api/canvas/projects/:projectId
 * Get a specific canvas project
 */
router.get('/projects/:projectId', authenticate, async (req, res) => {
  try {
    const { projectId } = req.params;
    const userId = req.userId;

    const project = await CanvasProject.findOne({ projectId, userId });

    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }

    res.json({
      project: {
        projectId: project.projectId,
        name: project.name,
        description: project.description,
        code: project.code,
        template: project.template,
        provider: project.provider,
        model: project.model,
        isPublic: project.isPublic,
        tags: project.tags,
        metadata: project.metadata,
        createdAt: project.createdAt,
        updatedAt: project.updatedAt
      }
    });
  } catch (error) {
    console.error('Get project error:', error);
    res.status(500).json({ error: 'Failed to fetch project' });
  }
});

/**
 * DELETE /api/canvas/projects/:projectId
 * Delete a canvas project
 */
router.delete('/projects/:projectId', authenticate, async (req, res) => {
  try {
    const { projectId } = req.params;
    const userId = req.userId;

    const result = await CanvasProject.findOneAndDelete({ projectId, userId });

    if (!result) {
      return res.status(404).json({ error: 'Project not found' });
    }

    res.json({
      success: true,
      message: 'Project deleted successfully'
    });
  } catch (error) {
    console.error('Delete project error:', error);
    res.status(500).json({ error: 'Failed to delete project' });
  }
});

module.exports = router;