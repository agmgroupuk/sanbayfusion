/**
 * Emotional TTS Routes
 * API endpoints for human-like emotional text-to-speech
 */

const express = require('express');
const path = require('path');
const fs = require('fs/promises');
const crypto = require('crypto');
const emotionalTTS = require('../services/emotionalTTS');
const router = express.Router();

const CACHE_DIR = path.join(__dirname, '../cache');
const EMO_TTS_CACHE_DIR = path.join(CACHE_DIR, 'tts-emotional');

async function ensureCacheDir() {
  try {
    await fs.mkdir(EMO_TTS_CACHE_DIR, { recursive: true });
  } catch {}
}

function makeCacheKey(obj) {
  const str = JSON.stringify(obj);
  return crypto.createHash('sha1').update(str).digest('hex');
}

/**
 * POST /api/tts/synthesize
 * Generate emotional speech from text
 * 
 * Body:
 * {
 *   text: "Hello, how are you?",
 *   agentId: "ai-girlfriend",
 *   gender: "female", // optional, auto-detected from agent
 *   emotion: "romantic", // optional, auto-detected from text
 *   provider: "elevenlabs" // optional, default: elevenlabs (also supports: google, azure, openai, polly)
 *   style: "romantic" // optional, overrides emotion-based style
 * }
 */
router.post('/synthesize', async (req, res) => {
  try {
    const { text, agentId, gender, emotion, provider, language, style } = req.body;

    if (!text) {
      return res.status(400).json({ error: 'Text is required' });
    }

    if (!agentId) {
      return res.status(400).json({ error: 'Agent ID is required' });
    }

    await ensureCacheDir();
    const cacheKey = makeCacheKey({ text, agentId, gender, emotion, style, provider: provider || 'elevenlabs', language: language || 'en-US' });
    const cachePath = path.join(EMO_TTS_CACHE_DIR, `${cacheKey}.mp3`);

    try {
      const cached = await fs.readFile(cachePath);
      return res.json({
        success: true,
        audio: cached.toString('base64'),
        provider: provider || 'elevenlabs',
        emotion: emotion || 'auto',
        voice: 'cached',
        metadata: { agentId, gender: gender || 'auto', style: style || 'auto', cached: true }
      });
    } catch {}

    // Synthesize with emotion
    const result = await emotionalTTS.synthesize({ text, agentId, gender, emotion, style, provider, language });

    // Cache audio
    try {
      await fs.writeFile(cachePath, result.audioBuffer);
    } catch {}

    // Return audio as base64 for easy frontend handling
    const audioBase64 = result.audioBuffer.toString('base64');

    res.json({
      success: true,
      audio: audioBase64,
      provider: result.provider,
      emotion: result.emotion,
      voice: result.voice,
      metadata: result.metadata
    });

  } catch (error) {
    console.error('TTS synthesis error:', error);
    res.status(500).json({
      error: 'TTS synthesis failed',
      message: error.message
    });
  }
});

/**
 * POST /api/tts/synthesize-stream
 * Stream emotional speech (for longer texts)
 */
router.post('/synthesize-stream', async (req, res) => {
  try {
    const { text, agentId, gender, emotion, provider, style } = req.body;

    if (!text || !agentId) {
      return res.status(400).json({ error: 'Text and agentId required' });
    }

    const result = await emotionalTTS.synthesize({ text, agentId, gender, emotion, style, provider });

    // Set headers for audio streaming
    res.setHeader('Content-Type', 'audio/mpeg');
    res.setHeader('Content-Length', result.audioBuffer.length);
    res.setHeader('X-Emotion', result.emotion);
    res.setHeader('X-Provider', result.provider);

    // Send audio buffer
    res.send(result.audioBuffer);

  } catch (error) {
    console.error('TTS stream error:', error);
    res.status(500).json({
      error: 'TTS streaming failed',
      message: error.message
    });
  }
});

/**
 * POST /api/tts/synthesize-fallback
 * Synthesize with automatic provider fallback
 */
router.post('/synthesize-fallback', async (req, res) => {
  try {
    const { text, agentId, gender, emotion, language, style } = req.body;

    if (!text || !agentId) {
      return res.status(400).json({ error: 'Text and agentId required' });
    }

    await ensureCacheDir();
    const cacheKey = makeCacheKey({ text, agentId, gender, emotion, style, provider: 'fallback', language: language || 'en-US' });
    const cachePath = path.join(EMO_TTS_CACHE_DIR, `${cacheKey}.mp3`);

    try {
      const cached = await fs.readFile(cachePath);
      return res.json({
        success: true,
        audio: cached.toString('base64'),
        provider: 'cached',
        emotion: emotion || 'auto',
        voice: 'cached',
        metadata: { agentId, gender: gender || 'auto', style: style || 'auto', cached: true }
      });
    } catch {}

    const result = await emotionalTTS.synthesizeWithFallback({ text, agentId, gender, emotion, language, style });

    // Cache audio
    try {
      await fs.writeFile(cachePath, result.audioBuffer);
    } catch {}

    const audioBase64 = result.audioBuffer.toString('base64');

    res.json({
      success: true,
      audio: audioBase64,
      provider: result.provider,
      emotion: result.emotion,
      voice: result.voice,
      metadata: result.metadata
    });

  } catch (error) {
    console.error('TTS fallback error:', error);
    res.status(500).json({
      error: 'All TTS providers failed',
      message: error.message
    });
  }
});

/**
 * GET /api/tts/voices/:agentId
 * Get available voices for an agent
 */
router.get('/voices/:agentId', (req, res) => {
  const { agentId } = req.params;
  
  // This would return the configured voices for the agent
  // For now, return a simple response
  res.json({
    agentId,
    configured: true,
    message: 'Voice configuration retrieved'
  });
});

module.exports = router;
