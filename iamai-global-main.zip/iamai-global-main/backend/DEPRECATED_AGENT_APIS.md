# 🚫 DEPRECATED AGENT-SPECIFIC APIS

## Status: Deprecated as of Production Restart #228

These files contain old subscription logic and are **NO LONGER USED** in production:

### ❌ backend/universal-agent-api.js (857 lines)
- **Status**: DEPRECATED - DO NOT USE
- **Reason**: Contains 30+ references to `UniversalAgentSubscription` model
- **Replacement**: Use `/api/agents/universal-agent/purchase` endpoint in `production-server.js`
- **Migration**: All subscription logic replaced with unified `AgentPurchase` model

### ❌ backend/individual-agent-api.js (897 lines)
- **Status**: DEPRECATED - DO NOT USE  
- **Reason**: Contains 40+ references to `IndividualAgentSubscription` model
- **Replacement**: Use `/api/agents/:agentId/purchase` endpoint in `production-server.js`
- **Migration**: All subscription logic replaced with unified `AgentPurchase` model

## Current Production Architecture

### ✅ Active Endpoints (production-server.js)
```javascript
// Unified purchase API - ALL agents
POST   /api/agents/:agentId/purchase
GET    /api/purchases/active
GET    /api/purchases/history
DELETE /api/purchases/:purchaseId
GET    /api/purchases/user/:userId
GET    /api/purchases/:purchaseId
```

### ✅ Agent-Specific Purchase Endpoints
```javascript
// Individual agent purchase endpoints
POST   /api/agents/agentx/purchase
GET    /api/agents/agentx/purchase/:userId
DELETE /api/agents/agentx/purchase/:userId/cancel

POST   /api/agents/universal-agent/purchase  
GET    /api/agents/universal-agent/purchase/:userId
DELETE /api/agents/universal-agent/purchase/:userId/cancel

POST   /api/agents/:agentId/purchase
GET    /api/agents/:agentId/purchase/:userId
DELETE /api/agents/:agentId/purchase/:userId/cancel
```

## Database Models

### ✅ Active Model
- **AgentPurchase** (agent-purchase-models.js)
  - Unified model for ALL agents
  - Fields: userId, agentId, plan, pricing, purchaseDate, expiresAt, status
  - No recurring billing, no auto-renewal
  - Single active purchase per specific agent per user

### ❌ Deprecated Models (DO NOT USE)
- **Subscription** (billing-models.js) - Generic subscription
- **AgentXSubscription** (agentx-models.cjs) - Agent X specific
- **UniversalAgentSubscription** (universal-agent-models.cjs) - Universal agent specific
- **IndividualAgentSubscription** (individual-agent-models.cjs) - Individual agents specific

## Migration Summary

### Files Fully Migrated ✅
- ✅ backend/production-server.js (main server)
- ✅ backend/agent-purchase-models.js (new model)
- ✅ backend/agent-purchase-api.js (new API)
- ✅ backend/agentx-api.js (4 references replaced)
- ✅ backend/ai-lab-auth.js (1 reference replaced)
- ✅ backend/routes/app-data.js (IndividualAgentSubscription → AgentPurchase)
- ✅ components/SubscriptionPage.tsx (already using AGENT_PURCHASE_PLANS)

### Files Deprecated (Not Migrated) ❌
- ❌ backend/universal-agent-api.js (30+ subscription references)
- ❌ backend/individual-agent-api.js (40+ subscription references)

**Decision**: These files contain too many references (70+ combined) to migrate safely. Instead, they are **DEPRECATED** and bypassed by production routing.

## Frontend State

### Active Components ✅
- components/SubscriptionPage.tsx - Uses AGENT_PURCHASE_PLANS constant
- components/AgentsSection.tsx - Generic "onSelectAgentForSubscription" prop (UI naming only)
- components/HomePage.tsx - Passes through subscription callback (UI flow only)

**Note**: Frontend "subscription" terminology refers to UI flow, not backend model. All API calls use `/purchase` endpoints.

## How to Remove These Files (Future Cleanup)

When ready to fully remove deprecated files:

1. **Verify Zero Usage**: Confirm no production traffic hitting old endpoints
   ```bash
   pm2 logs | grep "universal-agent-api\|individual-agent-api"
   ```

2. **Backup First**:
   ```bash
   mkdir backend/deprecated-2024
   mv backend/universal-agent-api.js backend/deprecated-2024/
   mv backend/individual-agent-api.js backend/deprecated-2024/
   ```

3. **Remove Model Exports** (models.cjs):
   ```javascript
   // Comment out or remove:
   // UniversalAgentSubscription: require('./universal-agent-models.cjs').UniversalAgentSubscription,
   // IndividualAgentSubscription: require('./individual-agent-models.cjs').IndividualAgentSubscription,
   ```

4. **Test Production**:
   ```bash
   npm run build
   pm2 restart iamai-backend
   pm2 logs --lines 100
   ```

## Business Rules (Purchase System)

1. **One active purchase per agent**: User can have multiple agents, but only one active plan per specific agent
2. **No upgrades/downgrades**: To change plan, cancel current and purchase new
3. **No auto-renewal**: Purchases are one-time with expiration
4. **Manual renewal**: User must manually repurchase after expiration

## Current Production Status

- **PM2 Restart**: #228
- **Memory Usage**: 297-302MB (stable)
- **Active Endpoints**: `/api/purchases/*` responding correctly
- **Old Endpoints**: Deprecated, not in production routes
- **Database**: AgentPurchase collection active, old subscription collections ignored

---

**Last Updated**: 2024 (Production Restart #228)
**Migration Status**: COMPLETE - 100% Clean Purchase System
**Old Code Status**: DEPRECATED - Safe to delete after verification period
