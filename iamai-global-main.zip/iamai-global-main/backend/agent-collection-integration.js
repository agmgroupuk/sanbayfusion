const { agentDataManager } = require('./agent-data-manager');
const { Chat, Session, User } = require('./models');

// ============================================
// AGENT COLLECTION INTEGRATION SERVICE
// Ensures existing flow continues + agent collections
// ============================================

class AgentCollectionIntegration {
  constructor() {
    this.enabled = true;
    this.initialized = false;
  }

  async initialize() {
    try {
      await agentDataManager.initialize();
      this.initialized = true;
      console.log('✅ Agent Collection Integration initialized');
      return true;
    } catch (error) {
      console.error('❌ Failed to initialize Agent Collection Integration:', error);
      return false;
    }
  }

  // Middleware to intercept chat messages and store in both places
  async interceptChatMessage(req, res, next) {
    if (!this.enabled || !this.initialized) {
      return next();
    }

    // Store original res.json to intercept response
    const originalJson = res.json;
    
    res.json = function(data) {
      // If this is a successful chat response, store in agent collection
      if (data && data.success && data.response && req.body) {
        const userId = req.body.userId || req.user?.id;
        const agentId = req.body.agentId || req.params.agentId;
        const message = req.body.message;
        const response = data.response;
        const sessionId = req.body.sessionId || data.sessionId;

        if (userId && agentId && message) {
          // Store in agent collection asynchronously (don't block response)
          setImmediate(async () => {
            try {
              await agentCollectionIntegration.storeInAgentCollection({
                userId,
                agentId,
                message,
                response,
                sessionId,
                metadata: {
                  timestamp: new Date(),
                  userAgent: req.headers['user-agent'],
                  ipAddress: req.ip,
                  tokens: data.tokens,
                  processingTime: data.processingTime
                }
              });
            } catch (error) {
              console.error('Error storing in agent collection:', error);
            }
          });
        }
      }

      // Call original res.json
      originalJson.call(this, data);
    };

    next();
  }

  // Store chat data in agent collection while keeping existing flow
  async storeInAgentCollection(chatData) {
    try {
      if (!this.initialized) {
        await this.initialize();
      }

      const { userId, agentId, message, response, sessionId, metadata } = chatData;

      // Store in agent-specific collection
      await agentDataManager.addChatToAgent(userId, agentId, {
        sessionId,
        message: {
          content: message,
          role: 'user',
          timestamp: new Date(),
          tokens: metadata?.tokens?.input || {},
          model: metadata?.model
        },
        response: {
          content: response,
          timestamp: new Date(),
          processingTime: metadata?.processingTime || 0,
          tokens: metadata?.tokens?.output || {},
          model: metadata?.model
        },
        metadata: {
          userAgent: metadata?.userAgent,
          ipAddress: metadata?.ipAddress,
          timestamp: metadata?.timestamp
        }
      });

      console.log(`📝 Chat stored in ${agentId}-data collection for user ${userId}`);
      return true;

    } catch (error) {
      console.error('Error in storeInAgentCollection:', error);
      return false;
    }
  }

  // Sync existing chat data to agent collections
  async syncExistingChats(limit = 1000) {
    try {
      console.log('🔄 Starting sync of existing chats to agent collections...');

      if (!this.initialized) {
        await this.initialize();
      }

      // Get recent chats from existing collection
      const existingChats = await Chat.find({})
        .populate('userId')
        .sort({ createdAt: -1 })
        .limit(limit);

      let syncedCount = 0;
      let errors = 0;

      for (const chat of existingChats) {
        try {
          // Extract agent ID from chat (you may need to adjust this based on your schema)
          const agentId = this.extractAgentIdFromChat(chat);
          
          if (agentId && chat.userId) {
            await this.storeInAgentCollection({
              userId: chat.userId._id || chat.userId,
              agentId,
              message: chat.message || chat.userMessage,
              response: chat.response || chat.aiResponse,
              sessionId: chat.sessionId,
              metadata: {
                timestamp: chat.createdAt,
                userAgent: chat.userAgent,
                ipAddress: chat.ipAddress,
                tokens: chat.tokens,
                processingTime: chat.processingTime,
                model: chat.model,
                synced: true // Mark as synced data
              }
            });
            syncedCount++;
          }
        } catch (error) {
          console.error(`Error syncing chat ${chat._id}:`, error);
          errors++;
        }
      }

      console.log(`✅ Sync completed: ${syncedCount} chats synced, ${errors} errors`);
      return { syncedCount, errors };

    } catch (error) {
      console.error('Error in syncExistingChats:', error);
      return { syncedCount: 0, errors: 1 };
    }
  }

  // Extract agent ID from existing chat data
  extractAgentIdFromChat(chat) {
    // This function extracts agentId from existing chat data
    // You may need to customize this based on how agent info is stored in your existing chats
    
    if (chat.agentId) {
      return chat.agentId;
    }
    
    if (chat.agent) {
      return chat.agent;
    }
    
    if (chat.metadata && chat.metadata.agentId) {
      return chat.metadata.agentId;
    }
    
    // Try to extract from message content or other fields
    if (chat.aiPersonality) {
      // Map existing personalities to agent IDs
      const personalityMap = {
        'AI Girlfriend': 'ai-girlfriend',
        'Comedy Chad': 'comedy-chad',
        'Gamer Gary': 'gamer-gary',
        'PDF Mind': 'pdf-mind',
        'Fitness Fury': 'fitness-fury',
        'Cool Kyle': 'cool-kyle',
        'Smart Susan': 'smart-susan',
        'Math Monster': 'math-monster',
        'Travel Tom': 'travel-tom',
        'Chef Charlie': 'chef-charlie',
        'Music Mike': 'music-mike',
        'Art Angel': 'art-angel',
        'Chat Revive': 'chat-revive',
        'Lazy Larry': 'lazy-larry',
        'Code Crusher': 'code-crusher',
        'Data Dynamo': 'data-dynamo'
      };
      
      return personalityMap[chat.aiPersonality] || 'agent-x'; // Default to agent-x
    }
    
    // Default agent if none found
    return 'agent-x';
  }

  // Create session in agent collection while keeping existing flow
  async interceptSessionCreation(sessionData) {
    try {
      if (!this.initialized) {
        await this.initialize();
      }

      const { userId, agentId, sessionId } = sessionData;

      if (userId && agentId && sessionId) {
        await agentDataManager.createSessionForAgent(userId, agentId, {
          sessionId,
          startTime: new Date(),
          metadata: sessionData.metadata || {},
          analytics: sessionData.analytics || {},
          isActive: true
        });

        console.log(`📊 Session stored in ${agentId}-data collection for user ${userId}`);
      }

    } catch (error) {
      console.error('Error in interceptSessionCreation:', error);
    }
  }

  // Middleware for session management
  async sessionMiddleware(req, res, next) {
    if (!this.enabled || !this.initialized) {
      return next();
    }

    // Store original res.json to intercept session creation responses
    const originalJson = res.json;
    
    res.json = function(data) {
      // If this is a successful session creation, store in agent collection
      if (data && data.success && data.sessionId && req.body) {
        const userId = req.body.userId || req.user?.id;
        const agentId = req.body.agentId || req.params.agentId;

        if (userId && agentId) {
          setImmediate(async () => {
            try {
              await agentCollectionIntegration.interceptSessionCreation({
                userId,
                agentId,
                sessionId: data.sessionId,
                metadata: {
                  userAgent: req.headers['user-agent'],
                  ipAddress: req.ip,
                  timestamp: new Date()
                }
              });
            } catch (error) {
              console.error('Error storing session in agent collection:', error);
            }
          });
        }
      }

      originalJson.call(this, data);
    };

    next();
  }

  // Sync existing sessions to agent collections
  async syncExistingSessions(limit = 1000) {
    try {
      console.log('🔄 Starting sync of existing sessions to agent collections...');

      const existingSessions = await Session.find({})
        .populate('userId')
        .sort({ createdAt: -1 })
        .limit(limit);

      let syncedCount = 0;

      for (const session of existingSessions) {
        try {
          const agentId = this.extractAgentIdFromSession(session);
          
          if (agentId && session.userId) {
            await agentDataManager.createSessionForAgent(
              session.userId._id || session.userId,
              agentId,
              {
                sessionId: session.sessionId || session._id.toString(),
                startTime: session.createdAt || session.startTime,
                endTime: session.endTime,
                duration: session.duration,
                messageCount: session.messageCount || 0,
                metadata: {
                  userAgent: session.userAgent,
                  ipAddress: session.ipAddress,
                  synced: true
                },
                analytics: session.analytics || {},
                isActive: session.isActive !== false
              }
            );
            syncedCount++;
          }
        } catch (error) {
          console.error(`Error syncing session ${session._id}:`, error);
        }
      }

      console.log(`✅ Session sync completed: ${syncedCount} sessions synced`);
      return syncedCount;

    } catch (error) {
      console.error('Error in syncExistingSessions:', error);
      return 0;
    }
  }

  // Extract agent ID from existing session data
  extractAgentIdFromSession(session) {
    // Similar to extractAgentIdFromChat but for sessions
    if (session.agentId) return session.agentId;
    if (session.agent) return session.agent;
    if (session.metadata && session.metadata.agentId) return session.metadata.agentId;
    
    // Default
    return 'agent-x';
  }

  // Enable/disable integration
  setEnabled(enabled) {
    this.enabled = enabled;
    console.log(`🎯 Agent Collection Integration ${enabled ? 'enabled' : 'disabled'}`);
  }

  // Get integration status
  getStatus() {
    return {
      enabled: this.enabled,
      initialized: this.initialized,
      agentDataManagerInitialized: agentDataManager.initialized
    };
  }
}

// Singleton instance
const agentCollectionIntegration = new AgentCollectionIntegration();

// Export middleware functions for easy use
const chatMiddleware = (req, res, next) => agentCollectionIntegration.interceptChatMessage(req, res, next);
const sessionMiddleware = (req, res, next) => agentCollectionIntegration.sessionMiddleware(req, res, next);

module.exports = {
  AgentCollectionIntegration,
  agentCollectionIntegration,
  chatMiddleware,
  sessionMiddleware
};