// Secure Database Backup Service
// Replaces the vulnerable backup-mongodb package
const { exec } = require('child_process');
const fs = require('fs').promises;
const path = require('path');
const crypto = require('crypto');

class SecureDatabaseBackup {
  constructor() {
    this.backupDir = process.env.BACKUP_DIR || './backups';
    this.encryptionKey = process.env.BACKUP_ENCRYPTION_KEY;
    this.mongoUri = process.env.MONGODB_URI;
  }

  async createBackup(databaseName = 'iamai-global') {
    try {
      await this.ensureBackupDirectory();

      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const backupFileName = `${databaseName}-${timestamp}.gz`;
      const backupPath = path.join(this.backupDir, backupFileName);

      console.log(`🔄 Creating backup: ${backupFileName}`);

      // Use mongodump with compression
      const command = `mongodump --uri="${this.mongoUri}" --db=${databaseName} --archive=${backupPath} --gzip`;

      await this.executeCommand(command);

      // Encrypt if encryption key is provided
      if (this.encryptionKey) {
        await this.encryptFile(backupPath);
      }

      console.log(`✅ Backup created successfully: ${backupFileName}`);
      return backupPath;
    } catch (error) {
      console.error('❌ Backup failed:', error.message);
      throw error;
    }
  }

  async restoreBackup(backupPath, databaseName = 'iamai-global') {
    try {
      console.log(`🔄 Restoring backup from: ${backupPath}`);

      // Decrypt if needed
      if (this.encryptionKey && backupPath.endsWith('.enc')) {
        backupPath = await this.decryptFile(backupPath);
      }

      const command = `mongorestore --uri="${this.mongoUri}" --db=${databaseName} --archive=${backupPath} --gzip --drop`;

      await this.executeCommand(command);

      console.log(`✅ Backup restored successfully`);
    } catch (error) {
      console.error('❌ Restore failed:', error.message);
      throw error;
    }
  }

  async listBackups() {
    try {
      const files = await fs.readdir(this.backupDir);
      return files
        .filter(file => file.endsWith('.gz') || file.endsWith('.gz.enc'))
        .map(file => ({
          name: file,
          path: path.join(this.backupDir, file),
          created: this.extractTimestampFromFilename(file),
        }))
        .sort((a, b) => new Date(b.created) - new Date(a.created));
    } catch (error) {
      console.error('❌ Failed to list backups:', error.message);
      return [];
    }
  }

  async cleanOldBackups(maxAge = 30) {
    try {
      const backups = await this.listBackups();
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - maxAge);

      const oldBackups = backups.filter(backup => new Date(backup.created) < cutoffDate);

      for (const backup of oldBackups) {
        await fs.unlink(backup.path);
        console.log(`🗑️  Deleted old backup: ${backup.name}`);
      }

      return oldBackups.length;
    } catch (error) {
      console.error('❌ Failed to clean old backups:', error.message);
      throw error;
    }
  }

  async ensureBackupDirectory() {
    try {
      await fs.access(this.backupDir);
    } catch {
      await fs.mkdir(this.backupDir, { recursive: true });
    }
  }

  executeCommand(command) {
    return new Promise((resolve, reject) => {
      exec(command, (error, stdout, stderr) => {
        if (error) {
          reject(new Error(`Command failed: ${error.message}`));
          return;
        }
        if (stderr) {
          console.warn('Command warning:', stderr);
        }
        resolve(stdout);
      });
    });
  }

  async encryptFile(filePath) {
    const algorithm = 'aes-256-gcm';
    const key = crypto.scryptSync(this.encryptionKey, 'salt', 32);
    const iv = crypto.randomBytes(16);

    const cipher = crypto.createCipher(algorithm, key);
    cipher.setAAD(Buffer.from('backup-encryption'));

    const input = await fs.readFile(filePath);
    const encrypted = Buffer.concat([cipher.update(input), cipher.final()]);
    const tag = cipher.getAuthTag();

    const result = Buffer.concat([iv, tag, encrypted]);
    const encryptedPath = `${filePath}.enc`;

    await fs.writeFile(encryptedPath, result);
    await fs.unlink(filePath); // Remove unencrypted file

    return encryptedPath;
  }

  async decryptFile(encryptedPath) {
    const algorithm = 'aes-256-gcm';
    const key = crypto.scryptSync(this.encryptionKey, 'salt', 32);

    const data = await fs.readFile(encryptedPath);
    const iv = data.slice(0, 16);
    const tag = data.slice(16, 32);
    const encrypted = data.slice(32);

    const decipher = crypto.createDecipher(algorithm, key);
    decipher.setAuthTag(tag);
    decipher.setAAD(Buffer.from('backup-encryption'));

    const decrypted = Buffer.concat([decipher.update(encrypted), decipher.final()]);

    const decryptedPath = encryptedPath.replace('.enc', '');
    await fs.writeFile(decryptedPath, decrypted);

    return decryptedPath;
  }

  extractTimestampFromFilename(filename) {
    const match = filename.match(/(\d{4}-\d{2}-\d{2}T\d{2}-\d{2}-\d{2}-\d{3}Z)/);
    return match
      ? match[1].replace(/T(\d{2})-(\d{2})-(\d{2})-(\d{3})Z/, 'T$1:$2:$3.$4Z')
      : new Date().toISOString();
  }
}

module.exports = { SecureDatabaseBackup };
