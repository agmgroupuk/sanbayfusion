/**
 * 📁 File Upload Service
 * Handle file uploads, cloud storage, and media processing
 */

const multer = require('multer');
const path = require('path');
const crypto = require('crypto');
const fs = require('fs').promises;
const { EventEmitter } = require('events');

// Cloud storage integrations
let cloudinary, s3;

try {
  if (process.env.CLOUDINARY_CLOUD_NAME) {
    cloudinary = require('cloudinary').v2;
    cloudinary.config({
      cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
      api_key: process.env.CLOUDINARY_API_KEY,
      api_secret: process.env.CLOUDINARY_API_SECRET,
    });
  }
} catch (error) {
  console.log('Cloudinary not configured');
}

try {
  if (process.env.AWS_ACCESS_KEY_ID) {
    const AWS = require('aws-sdk');
    s3 = new AWS.S3({
      accessKeyId: process.env.AWS_ACCESS_KEY_ID,
      secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
      region: process.env.AWS_REGION || 'us-east-1',
    });
  }
} catch (error) {
  console.log('AWS S3 not configured');
}

class FileUploadService extends EventEmitter {
  constructor() {
    super();
    this.uploadDir = path.join(process.cwd(), 'uploads');
    this.allowedTypes = {
      image: ['image/jpeg', 'image/png', 'image/gif', 'image/webp'],
      document: [
        'application/pdf',
        'text/plain',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      ],
      audio: ['audio/mpeg', 'audio/wav', 'audio/ogg'],
      video: ['video/mp4', 'video/mpeg', 'video/quicktime'],
    };
    this.maxFileSize = 50 * 1024 * 1024; // 50MB

    this.ensureUploadDir();
    this.setupMulter();
  }

  /**
   * Ensure upload directory exists
   */
  async ensureUploadDir() {
    try {
      await fs.mkdir(this.uploadDir, { recursive: true });
      await fs.mkdir(path.join(this.uploadDir, 'temp'), { recursive: true });
      await fs.mkdir(path.join(this.uploadDir, 'processed'), { recursive: true });
    } catch (error) {
      console.error('Upload directory setup error:', error);
    }
  }

  /**
   * Setup Multer configuration
   */
  setupMulter() {
    const storage = multer.diskStorage({
      destination: (req, file, cb) => {
        cb(null, path.join(this.uploadDir, 'temp'));
      },
      filename: (req, file, cb) => {
        const uniqueName = this.generateUniqueFileName(file.originalname);
        cb(null, uniqueName);
      },
    });

    this.upload = multer({
      storage,
      limits: {
        fileSize: this.maxFileSize,
        files: 10, // Max 10 files per request
      },
      fileFilter: (req, file, cb) => {
        if (this.isFileTypeAllowed(file)) {
          cb(null, true);
        } else {
          cb(new Error(`File type ${file.mimetype} not allowed`));
        }
      },
    });
  }

  /**
   * Generate unique filename
   */
  generateUniqueFileName(originalName) {
    const ext = path.extname(originalName);
    const hash = crypto.randomBytes(16).toString('hex');
    const timestamp = Date.now();
    return `${timestamp}_${hash}${ext}`;
  }

  /**
   * Check if file type is allowed
   */
  isFileTypeAllowed(file) {
    const allAllowedTypes = Object.values(this.allowedTypes).flat();
    return allAllowedTypes.includes(file.mimetype);
  }

  /**
   * Get file category
   */
  getFileCategory(mimetype) {
    for (const [category, types] of Object.entries(this.allowedTypes)) {
      if (types.includes(mimetype)) {
        return category;
      }
    }
    return 'other';
  }

  /**
   * Upload single file
   */
  async uploadFile(userId, file, options = {}) {
    try {
      const category = this.getFileCategory(file.mimetype);
      const fileId = crypto.randomUUID();

      // File metadata
      const fileData = {
        id: fileId,
        userId,
        originalName: file.originalname,
        filename: file.filename,
        mimetype: file.mimetype,
        size: file.size,
        category,
        path: file.path,
        url: null,
        cloudUrl: null,
        processed: false,
        metadata: {},
        createdAt: new Date(),
      };

      // Upload to cloud storage if available
      if (options.useCloud !== false) {
        const cloudResult = await this.uploadToCloud(file, fileData);
        if (cloudResult.success) {
          fileData.cloudUrl = cloudResult.url;
          fileData.url = cloudResult.url;
          fileData.cloudProvider = cloudResult.provider;

          // Remove local file after cloud upload
          try {
            await fs.unlink(file.path);
          } catch (error) {
            console.warn('Failed to delete local file:', error);
          }
        }
      }

      // If no cloud storage, use local URL
      if (!fileData.url) {
        fileData.url = `/uploads/${path.basename(file.path)}`;
      }

      // Process file if needed
      if (category === 'image' && options.processImage !== false) {
        const processedData = await this.processImage(file.path, fileData);
        fileData.metadata = { ...fileData.metadata, ...processedData };
        fileData.processed = true;
      }

      // Save to database
      const FileUpload = require('../models').FileUpload;
      const uploadRecord = new FileUpload(fileData);
      await uploadRecord.save();

      // Track upload event
      const analyticsService = require('./analytics-service');
      await analyticsService.trackEvent(userId, 'file_upload', {
        fileId,
        category,
        size: file.size,
        mimetype: file.mimetype,
      });

      this.emit('fileUploaded', { userId, fileData });

      return {
        success: true,
        file: {
          id: fileId,
          url: fileData.url,
          originalName: file.originalname,
          size: file.size,
          type: file.mimetype,
          category,
        },
      };
    } catch (error) {
      console.error('Upload file error:', error);

      // Clean up temporary file
      try {
        if (file.path) {
          await fs.unlink(file.path);
        }
      } catch (cleanupError) {
        console.warn('Failed to cleanup temp file:', cleanupError);
      }

      throw error;
    }
  }

  /**
   * Upload multiple files
   */
  async uploadFiles(userId, files, options = {}) {
    try {
      const results = [];

      for (const file of files) {
        try {
          const result = await this.uploadFile(userId, file, options);
          results.push(result);
        } catch (error) {
          results.push({
            success: false,
            error: error.message,
            file: file.originalname,
          });
        }
      }

      return {
        success: true,
        results,
        uploaded: results.filter(r => r.success).length,
        failed: results.filter(r => !r.success).length,
      };
    } catch (error) {
      console.error('Upload multiple files error:', error);
      throw error;
    }
  }

  /**
   * Upload to cloud storage
   */
  async uploadToCloud(file, fileData) {
    try {
      // Try Cloudinary first (better for images)
      if (cloudinary && fileData.category === 'image') {
        const result = await cloudinary.uploader.upload(file.path, {
          folder: `iamai-global/users/${fileData.userId}`,
          public_id: fileData.id,
          resource_type: 'auto',
        });

        return {
          success: true,
          url: result.secure_url,
          provider: 'cloudinary',
          cloudData: result,
        };
      }

      // Try AWS S3
      if (s3) {
        const fileStream = await fs.readFile(file.path);
        const key = `users/${fileData.userId}/${fileData.id}_${fileData.originalName}`;

        const uploadParams = {
          Bucket: process.env.AWS_S3_BUCKET,
          Key: key,
          Body: fileStream,
          ContentType: file.mimetype,
          ACL: 'public-read',
        };

        const result = await s3.upload(uploadParams).promise();

        return {
          success: true,
          url: result.Location,
          provider: 's3',
          cloudData: result,
        };
      }

      return { success: false, error: 'No cloud storage provider configured' };
    } catch (error) {
      console.error('Cloud upload error:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Process image (resize, optimize)
   */
  async processImage(imagePath, fileData) {
    try {
      // This would integrate with image processing library like Sharp
      // For now, return basic metadata

      const stats = await fs.stat(imagePath);

      return {
        processedAt: new Date(),
        originalSize: stats.size,
        // Additional processing metadata would go here
      };
    } catch (error) {
      console.error('Image processing error:', error);
      return {};
    }
  }

  /**
   * Get user files
   */
  async getUserFiles(userId, options = {}) {
    try {
      const FileUpload = require('../models').FileUpload;

      const query = { userId };
      if (options.category) {
        query.category = options.category;
      }

      const files = await FileUpload.find(query)
        .sort({ createdAt: -1 })
        .limit(options.limit || 50)
        .select('-path') // Don't return file path for security
        .lean();

      return files;
    } catch (error) {
      console.error('Get user files error:', error);
      throw error;
    }
  }

  /**
   * Delete file
   */
  async deleteFile(userId, fileId) {
    try {
      const FileUpload = require('../models').FileUpload;

      const file = await FileUpload.findOne({ id: fileId, userId });
      if (!file) {
        throw new Error('File not found');
      }

      // Delete from cloud storage
      if (file.cloudProvider === 'cloudinary' && cloudinary) {
        await cloudinary.uploader.destroy(file.id);
      } else if (file.cloudProvider === 's3' && s3) {
        const key = `users/${userId}/${fileId}_${file.originalName}`;
        await s3
          .deleteObject({
            Bucket: process.env.AWS_S3_BUCKET,
            Key: key,
          })
          .promise();
      }

      // Delete local file if exists
      if (file.path) {
        try {
          await fs.unlink(file.path);
        } catch (error) {
          console.warn('Local file already deleted or not found');
        }
      }

      // Remove from database
      await FileUpload.deleteOne({ id: fileId, userId });

      // Track deletion event
      const analyticsService = require('./analytics-service');
      await analyticsService.trackEvent(userId, 'file_delete', {
        fileId,
        category: file.category,
        size: file.size,
      });

      this.emit('fileDeleted', { userId, fileId, file });

      return { success: true };
    } catch (error) {
      console.error('Delete file error:', error);
      throw error;
    }
  }

  /**
   * Get file by ID
   */
  async getFile(userId, fileId) {
    try {
      const FileUpload = require('../models').FileUpload;

      const file = await FileUpload.findOne({ id: fileId, userId })
        .select('-path') // Don't return file path for security
        .lean();

      if (!file) {
        throw new Error('File not found');
      }

      return file;
    } catch (error) {
      console.error('Get file error:', error);
      throw error;
    }
  }

  /**
   * Get storage usage for user
   */
  async getStorageUsage(userId) {
    try {
      const FileUpload = require('../models').FileUpload;

      const pipeline = [
        { $match: { userId: new require('mongoose').Types.ObjectId(userId) } },
        {
          $group: {
            _id: '$category',
            totalSize: { $sum: '$size' },
            fileCount: { $sum: 1 },
          },
        },
      ];

      const usage = await FileUpload.aggregate(pipeline);

      const totalSize = usage.reduce((sum, cat) => sum + cat.totalSize, 0);
      const totalFiles = usage.reduce((sum, cat) => sum + cat.fileCount, 0);

      return {
        totalSize,
        totalFiles,
        byCategory: usage,
        formatted: {
          totalSize: this.formatFileSize(totalSize),
        },
      };
    } catch (error) {
      console.error('Get storage usage error:', error);
      throw error;
    }
  }

  /**
   * Format file size
   */
  formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';

    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));

    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }

  /**
   * Clean up old temporary files
   */
  async cleanupTempFiles() {
    try {
      const tempDir = path.join(this.uploadDir, 'temp');
      const files = await fs.readdir(tempDir);
      const now = Date.now();
      const maxAge = 24 * 60 * 60 * 1000; // 24 hours

      for (const file of files) {
        const filePath = path.join(tempDir, file);
        const stats = await fs.stat(filePath);

        if (now - stats.mtime.getTime() > maxAge) {
          await fs.unlink(filePath);
          console.log('Cleaned up temp file:', file);
        }
      }
    } catch (error) {
      console.error('Cleanup temp files error:', error);
    }
  }

  /**
   * Get multer middleware
   */
  getUploadMiddleware() {
    return {
      single: fieldName => this.upload.single(fieldName),
      array: (fieldName, maxCount) => this.upload.array(fieldName, maxCount),
      fields: fields => this.upload.fields(fields),
      any: () => this.upload.any(),
    };
  }
}

module.exports = new FileUploadService();
