/**
 * 🤖 COMPREHENSIVE MULTI-PROVIDER AI SERVICE
 * ============================================
 * Priority Order: Mistral → OpenAI → Gemini → Anthropic → Cohere → Groq
 * 
 * Features:
 * - ALL models from ALL providers
 * - Automatic failover with intelligent retry logic
 * - Specialized APIs: NASA, News, Finance, Security, Vectors
 * - Voice: ElevenLabs, Google TTS, OpenAI TTS
 * - Images: Stability AI, RunwayML, Replicate, Gemini, DALL-E
 * - Complete embeddings with Pinecone integration
 */

const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '../.env') });

const { GoogleGenerativeAI } = require('@google/generative-ai');
const Anthropic = require('@anthropic-ai/sdk');
const { Mistral } = require('@mistralai/mistralai');
const { CohereClient } = require('cohere-ai');
const Groq = require('groq-sdk');
const { Pinecone } = require('@pinecone-database/pinecone');
const axios = require('axios');

// ============================================
// PROVIDER CONFIGURATION
// ============================================

const PROVIDERS = {
  // Core LLM Providers (Priority Order)
  GEMINI: 'gemini',
  OPENAI: 'openai',
  MISTRAL: 'mistral',
  ANTHROPIC: 'anthropic',
  COHERE: 'cohere',
  GROQ: 'groq',
  HUGGINGFACE: 'huggingface',
  REPLICATE: 'replicate',
  
  // Specialized Providers
  ELEVENLABS: 'elevenlabs',
  STABILITY: 'stability',
  RUNWAY: 'runway',
  PINECONE: 'pinecone',
  
  // API Services
  NASA: 'nasa',
  NEWS: 'newsapi',
  FINANCE: 'alphavantage',
  SECURITY: 'security' // VirusTotal, Shodan, AbuseIPDB, etc.
};

const PROVIDER_ORDER = [
  PROVIDERS.MISTRAL,
  PROVIDERS.OPENAI,
  PROVIDERS.GEMINI,
  PROVIDERS.ANTHROPIC,
  PROVIDERS.COHERE,
  PROVIDERS.GROQ
];

// ============================================
// ALL MODELS FROM ALL PROVIDERS
// ============================================

const MODELS = {
  // GEMINI - Google AI (PRIMARY)
  [PROVIDERS.GEMINI]: {
    chat: {
      // Gemini 2.0 Series
      'gemini-2.0-flash-exp': { speed: 'fastest', context: 1000000, multimodal: true },
      'gemini-2.0-flash-thinking-exp': { speed: 'fast', context: 32000, reasoning: true },
      
      // Gemini 1.5 Series
      'gemini-1.5-pro': { speed: 'balanced', context: 2000000, multimodal: true },
      'gemini-1.5-pro-002': { speed: 'balanced', context: 2000000, multimodal: true },
      'gemini-1.5-flash': { speed: 'fast', context: 1000000, multimodal: true },
      'gemini-1.5-flash-002': { speed: 'fast', context: 1000000, multimodal: true },
      'gemini-1.5-flash-8b': { speed: 'fastest', context: 1000000, lightweight: true },
      
      // Gemini 1.0 Series
      'gemini-1.0-pro': { speed: 'balanced', context: 32000 },
      'gemini-1.0-pro-vision': { speed: 'balanced', context: 16000, vision: true }
    },
    embedding: {
      'text-embedding-004': { dimensions: 768, tasks: ['retrieval', 'similarity', 'classification'] },
      'text-multilingual-embedding-002': { dimensions: 768, multilingual: true }
    },
    image: {
      'imagen-3.0-generate-001': { quality: 'high', sizes: ['1024x1024', '1024x768', '768x1024'] },
      'imagen-3.0-fast-generate-001': { quality: 'standard', speed: 'fast' }
    }
  },

  // OPENAI - GPT Models (SECONDARY)
  [PROVIDERS.OPENAI]: {
    chat: {
      // GPT-4 Turbo
      'gpt-4-turbo': { speed: 'balanced', context: 128000, vision: true },
      'gpt-4-turbo-2024-04-09': { speed: 'balanced', context: 128000, vision: true },
      'gpt-4-turbo-preview': { speed: 'balanced', context: 128000 },
      
      // GPT-4o (Optimized)
      'gpt-4o': { speed: 'fast', context: 128000, multimodal: true, latest: true },
      'gpt-4o-2024-11-20': { speed: 'fast', context: 128000, multimodal: true },
      'gpt-4o-2024-08-06': { speed: 'fast', context: 128000, multimodal: true },
      'gpt-4o-mini': { speed: 'fastest', context: 128000, cost: 'low' },
      'gpt-4o-mini-2024-07-18': { speed: 'fastest', context: 128000 },
      
      // GPT-4 Classic
      'gpt-4': { speed: 'balanced', context: 8192 },
      'gpt-4-0613': { speed: 'balanced', context: 8192 },
      'gpt-4-32k': { speed: 'balanced', context: 32768 },
      
      // GPT-3.5 Turbo
      'gpt-3.5-turbo': { speed: 'fast', context: 16385, cost: 'low' },
      'gpt-3.5-turbo-0125': { speed: 'fast', context: 16385 },
      'gpt-3.5-turbo-1106': { speed: 'fast', context: 16385 },
      
      // O1 Series (Reasoning)
      'o1': { reasoning: true, context: 200000, speed: 'slow' },
      'o1-preview': { reasoning: true, context: 128000, speed: 'slow' },
      'o1-mini': { reasoning: true, context: 128000, speed: 'medium' }
    },
    embedding: {
      'text-embedding-3-large': { dimensions: 3072, quality: 'high' },
      'text-embedding-3-small': { dimensions: 1536, quality: 'standard', cost: 'low' },
      'text-embedding-ada-002': { dimensions: 1536, legacy: true }
    },
    image: {
      'dall-e-3': { quality: 'high', sizes: ['1024x1024', '1792x1024', '1024x1792'] },
      'dall-e-2': { quality: 'standard', sizes: ['256x256', '512x512', '1024x1024'] }
    },
    tts: {
      'tts-1': { quality: 'standard', voices: ['alloy', 'echo', 'fable', 'onyx', 'nova', 'shimmer'] },
      'tts-1-hd': { quality: 'high', voices: ['alloy', 'echo', 'fable', 'onyx', 'nova', 'shimmer'] }
    },
    stt: {
      'whisper-1': { languages: 50, transcription: true, translation: true }
    }
  },

  // MISTRAL - Mistral AI (THIRD)
  [PROVIDERS.MISTRAL]: {
    chat: {
      // Large Models
      'mistral-large-latest': { speed: 'balanced', context: 128000, multilingual: true },
      'mistral-large-2411': { speed: 'balanced', context: 128000, latest: true },
      'mistral-large-2407': { speed: 'balanced', context: 128000 },
      
      // Medium Models
      'mistral-medium-latest': { speed: 'fast', context: 32000 },
      
      // Small Models
      'mistral-small-latest': { speed: 'fastest', context: 32000, cost: 'low' },
      'mistral-small-2409': { speed: 'fastest', context: 32000 },
      
      // Specialized Models
      'codestral-latest': { coding: true, context: 32000 },
      'codestral-2405': { coding: true, context: 32000 },
      'codestral-mamba-latest': { coding: true, speed: 'fastest' },
      
      // Open Models
      'open-mistral-7b': { opensource: true, context: 32000 },
      'open-mixtral-8x7b': { opensource: true, context: 32000, moe: true },
      'open-mixtral-8x22b': { opensource: true, context: 64000, moe: true },
      
      // Nemo (Free)
      'open-mistral-nemo': { opensource: true, context: 128000, free: true }
    },
    embedding: {
      'mistral-embed': { dimensions: 1024, multilingual: true }
    }
  },

  // ANTHROPIC - Claude (FOURTH)
  [PROVIDERS.ANTHROPIC]: {
    chat: {
      // Claude 3.5 Sonnet (Latest)
      'claude-3-5-sonnet-20241022': { speed: 'fast', context: 200000, vision: true, latest: true },
      'claude-3-5-sonnet-20240620': { speed: 'fast', context: 200000, vision: true },
      
      // Claude 3 Opus (Most Capable)
      'claude-3-opus-20240229': { speed: 'balanced', context: 200000, vision: true, quality: 'highest' },
      
      // Claude 3 Sonnet
      'claude-3-sonnet-20240229': { speed: 'balanced', context: 200000, vision: true },
      
      // Claude 3 Haiku (Fastest)
      'claude-3-haiku-20240307': { speed: 'fastest', context: 200000, vision: true, cost: 'low' },
      
      // Claude 2 (Legacy)
      'claude-2.1': { speed: 'balanced', context: 200000, legacy: true },
      'claude-2.0': { speed: 'balanced', context: 100000, legacy: true }
    }
  },

  // COHERE - Cohere AI (FIFTH) - Updated models as of Sept 2025
  [PROVIDERS.COHERE]: {
    chat: {
      // New models (post-September 2025)
      'command-r-08-2024': { speed: 'balanced', context: 128000, rag: true, latest: true },
      'command-r-plus-08-2024': { speed: 'balanced', context: 128000, rag: true, quality: 'high' },
      'command-r-03-2024': { speed: 'fast', context: 128000, rag: true },
      'command-r-plus-04-2024': { speed: 'balanced', context: 128000, rag: true }
    },
    embedding: {
      'embed-english-v3.0': { dimensions: 1024, language: 'english' },
      'embed-multilingual-v3.0': { dimensions: 1024, multilingual: true },
      'embed-english-light-v3.0': { dimensions: 384, cost: 'low' },
      'embed-multilingual-light-v3.0': { dimensions: 384, multilingual: true, cost: 'low' }
    }
  },

  // GROQ - Fast Inference (SIXTH)
  [PROVIDERS.GROQ]: {
    chat: {
      'llama-3.3-70b-versatile': { speed: 'ultrafast', context: 128000, opensource: true },
      'llama-3.1-70b-versatile': { speed: 'ultrafast', context: 128000, opensource: true },
      'llama-3.1-8b-instant': { speed: 'ultrafast', context: 128000, cost: 'low' },
      'llama3-70b-8192': { speed: 'ultrafast', context: 8192 },
      'llama3-8b-8192': { speed: 'ultrafast', context: 8192 },
      'mixtral-8x7b-32768': { speed: 'ultrafast', context: 32768, moe: true },
      'gemma-7b-it': { speed: 'ultrafast', context: 8192 },
      'gemma2-9b-it': { speed: 'ultrafast', context: 8192 }
    }
  },

  // STABILITY AI - Image Generation
  [PROVIDERS.STABILITY]: {
    image: {
      'stable-diffusion-xl-1024-v1-0': { quality: 'high', size: 1024 },
      'stable-diffusion-xl-beta-v2-2-2': { quality: 'high', size: 512 },
      'stable-diffusion-v1-6': { quality: 'standard', size: 512 }
    }
  },

  // ELEVENLABS - Premium TTS
  [PROVIDERS.ELEVENLABS]: {
    tts: {
      'eleven_monolingual_v1': { quality: 'high', languages: ['english'] },
      'eleven_multilingual_v2': { quality: 'high', multilingual: true },
      'eleven_turbo_v2': { quality: 'standard', speed: 'fast' }
    }
  }
};

// ============================================
// COMPREHENSIVE AI SERVICE CLASS
// ============================================

class ComprehensiveAIService {
  constructor() {
    this.providers = {};
    this.apis = {};
    this.vectorDB = null;
    this.initializeAll();
    
    this.retryConfig = {
      maxRetries: 2, // Reduced from 3 for faster failover
      retryDelay: 500, // Reduced from 1000ms for quicker retries
      backoffMultiplier: 1.5 // Reduced from 2 for faster progression
    };
  }

  // ============================================
  // INITIALIZATION
  // ============================================

  initializeAll() {
    console.log('🚀 Initializing Comprehensive AI Service...\n');
    
    this.initializeLLMProviders();
    this.initializeSpecializedServices();
    this.initializeAPIs();
    
    console.log('\n✅ Initialization Complete!\n');
  }

  initializeLLMProviders() {
    console.log('📚 Initializing LLM Providers:');
    
    // 1. GEMINI (Primary)
    if (process.env.GEMINI_API_KEY) {
      try {
        this.providers[PROVIDERS.GEMINI] = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
        console.log('  ✓ Gemini (PRIMARY) - All models loaded');
      } catch (error) {
        console.error('  ✗ Gemini failed:', error.message);
      }
    }

    // 2. OPENAI (Secondary)
    if (process.env.OPENAI_API_KEY) {
      try {
        this.providers[PROVIDERS.OPENAI] = {
          apiKey: process.env.OPENAI_API_KEY,
          baseURL: 'https://api.openai.com/v1'
        };
        console.log('  ✓ OpenAI (SECONDARY) - All GPT models loaded');
      } catch (error) {
        console.error('  ✗ OpenAI failed:', error.message);
      }
    }

    // 3. MISTRAL (Third)
    if (process.env.MISTRAL_API_KEY) {
      try {
        this.providers[PROVIDERS.MISTRAL] = new Mistral({ apiKey: process.env.MISTRAL_API_KEY });
        console.log('  ✓ Mistral (THIRD) - All models loaded');
      } catch (error) {
        console.error('  ✗ Mistral failed:', error.message);
      }
    }

    // 4. ANTHROPIC (Fourth)
    if (process.env.ANTHROPIC_API_KEY) {
      try {
        this.providers[PROVIDERS.ANTHROPIC] = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
        console.log('  ✓ Anthropic (FOURTH) - All Claude models loaded');
      } catch (error) {
        console.error('  ✗ Anthropic failed:', error.message);
      }
    }

    // 5. COHERE (Fifth) - Using API directly for v2 models
    if (process.env.COHERE_API_KEY) {
      try {
        this.providers[PROVIDERS.COHERE] = {
          token: process.env.COHERE_API_KEY,
          baseURL: 'https://api.cohere.com/v2'
        };
        console.log('  ✓ Cohere (FIFTH) - New command models loaded');
      } catch (error) {
        console.error('  ✗ Cohere failed:', error.message);
      }
    }

    // 6. GROQ (Sixth - Fast Inference)
    if (process.env.GROQ_API_KEY) {
      try {
        this.providers[PROVIDERS.GROQ] = new Groq({ apiKey: process.env.GROQ_API_KEY });
        console.log('  ✓ Groq (SIXTH) - Ultra-fast models loaded');
      } catch (error) {
        console.error('  ✗ Groq failed:', error.message);
      }
    }
  }

  initializeSpecializedServices() {
    console.log('\n🎨 Initializing Specialized Services:');
    
    // Stability AI - Image Generation
    if (process.env.STABILITY_API_KEY) {
      this.apis[PROVIDERS.STABILITY] = {
        apiKey: process.env.STABILITY_API_KEY,
        baseURL: 'https://api.stability.ai'
      };
      console.log('  ✓ Stability AI - SDXL models loaded');
    }

    // ElevenLabs - Premium TTS
    if (process.env.ELEVENLABS_API_KEY) {
      this.apis[PROVIDERS.ELEVENLABS] = {
        apiKey: process.env.ELEVENLABS_API_KEY,
        baseURL: 'https://api.elevenlabs.io/v1'
      };
      console.log('  ✓ ElevenLabs - Premium voices loaded');
    }

    // RunwayML - Video Generation
    if (process.env.RUNWAYML_API_KEY) {
      this.apis[PROVIDERS.RUNWAY] = {
        apiKey: process.env.RUNWAYML_API_KEY,
        baseURL: 'https://api.runwayml.com/v1'
      };
      console.log('  ✓ RunwayML - Video generation loaded');
    }

    // Replicate - ML Models
    if (process.env.REPLICATE_API_TOKEN) {
      this.apis[PROVIDERS.REPLICATE] = {
        apiKey: process.env.REPLICATE_API_TOKEN,
        baseURL: 'https://api.replicate.com/v1'
      };
      console.log('  ✓ Replicate - ML models loaded');
    }

    // Hugging Face
    if (process.env.HUGGINGFACE_API_KEY) {
      this.apis[PROVIDERS.HUGGINGFACE] = {
        apiKey: process.env.HUGGINGFACE_API_KEY,
        baseURL: 'https://api-inference.huggingface.co'
      };
      console.log('  ✓ Hugging Face - Models loaded');
    }

    // Pinecone - Vector Database
    if (process.env.PINECONE_API_KEY) {
      try {
        this.vectorDB = new Pinecone({
          apiKey: process.env.PINECONE_API_KEY
        });
        console.log('  ✓ Pinecone - Vector DB initialized');
      } catch (error) {
        console.error('  ✗ Pinecone failed:', error.message);
      }
    }
  }

  initializeAPIs() {
    console.log('\n🌐 Initializing API Services:');
    
    // NASA API
    if (process.env.NASA_API_KEY) {
      this.apis[PROVIDERS.NASA] = {
        apiKey: process.env.NASA_API_KEY,
        baseURL: 'https://api.nasa.gov'
      };
      console.log('  ✓ NASA - Space data API');
    }

    // News API
    if (process.env.NEWSAPI_KEY) {
      this.apis[PROVIDERS.NEWS] = {
        apiKey: process.env.NEWSAPI_KEY,
        baseURL: 'https://newsapi.org/v2'
      };
      console.log('  ✓ NewsAPI - News aggregation');
    }

    // Alpha Vantage - Finance
    if (process.env.ALPHAVANTAGE_API_KEY) {
      this.apis[PROVIDERS.FINANCE] = {
        apiKey: process.env.ALPHAVANTAGE_API_KEY,
        baseURL: 'https://www.alphavantage.co'
      };
      console.log('  ✓ Alpha Vantage - Financial data');
    }

    // Security APIs
    this.apis[PROVIDERS.SECURITY] = {};
    
    if (process.env.VIRUSTOTAL_API_KEY) {
      this.apis[PROVIDERS.SECURITY].virustotal = {
        apiKey: process.env.VIRUSTOTAL_API_KEY,
        baseURL: 'https://www.virustotal.com/api/v3'
      };
      console.log('  ✓ VirusTotal - Malware detection');
    }

    if (process.env.SHODAN_API_KEY) {
      this.apis[PROVIDERS.SECURITY].shodan = {
        apiKey: process.env.SHODAN_API_KEY,
        baseURL: 'https://api.shodan.io'
      };
      console.log('  ✓ Shodan - Internet device search');
    }

    if (process.env.ABUSEIPDB_API_KEY) {
      this.apis[PROVIDERS.SECURITY].abuseipdb = {
        apiKey: process.env.ABUSEIPDB_API_KEY,
        baseURL: 'https://api.abuseipdb.com/api/v2'
      };
      console.log('  ✓ AbuseIPDB - IP reputation');
    }

    if (process.env.IPGEOLOCATION_API_KEY) {
      this.apis[PROVIDERS.SECURITY].ipgeo = {
        apiKey: process.env.IPGEOLOCATION_API_KEY,
        baseURL: 'https://api.ipgeolocation.io'
      };
      console.log('  ✓ IPGeolocation - IP location data');
    }

    if (process.env.WHOIS_API_KEY) {
      this.apis[PROVIDERS.SECURITY].whois = {
        apiKey: process.env.WHOIS_API_KEY,
        baseURL: 'https://www.whoisjsonapi.com/v1'
      };
      console.log('  ✓ WHOIS - Domain information');
    }

    if (process.env.HUNTER_API_KEY) {
      this.apis[PROVIDERS.SECURITY].hunter = {
        apiKey: process.env.HUNTER_API_KEY,
        baseURL: 'https://api.hunter.io/v2'
      };
      console.log('  ✓ Hunter.io - Email verification');
    }
  }

  // ============================================
  // PROVIDER STATUS & HEALTH
  // ============================================

  getProviderStatus() {
    const status = {};
    
    PROVIDER_ORDER.forEach(provider => {
      status[provider] = {
        available: !!this.providers[provider],
        models: MODELS[provider] ? Object.keys(MODELS[provider]) : []
      };
    });

    return status;
  }

  getAllAvailableModels() {
    const allModels = {};
    
    PROVIDER_ORDER.forEach(provider => {
      if (this.providers[provider] && MODELS[provider]) {
        allModels[provider] = MODELS[provider];
      }
    });

    return allModels;
  }

  // ============================================
  // CORE METHOD: EXECUTE WITH FALLBACK
  // ============================================

  async executeWithFallback(operation, options = {}) {
    const errors = [];
    
    for (const provider of PROVIDER_ORDER) {
      if (!this.providers[provider]) {
        continue;
      }

      try {
        console.log(`🔄 Trying ${provider}...`);
        const result = await this.executeOperation(provider, operation, options);
        console.log(`✅ Success with ${provider}`);
        return { ...result, provider };
      } catch (error) {
        console.error(`❌ ${provider} failed:`, error.message);
        errors.push({ provider, error: error.message });
        continue;
      }
    }

    throw new Error(`All providers failed: ${JSON.stringify(errors)}`);
  }

  async executeOperation(provider, operation, options) {
    switch (operation) {
      case 'chat':
        return await this.chatWithProvider(provider, options);
      case 'embed':
        return await this.embedWithProvider(provider, options);
      case 'image':
        return await this.generateImageWithProvider(provider, options);
      case 'tts':
        return await this.ttsWithProvider(provider, options);
      case 'stt':
        return await this.sttWithProvider(provider, options);
      default:
        throw new Error(`Unknown operation: ${operation}`);
    }
  }

  // ============================================
  // CHAT - ALL PROVIDERS, ALL MODELS
  // ============================================

  async chat(messages, options = {}) {
    const {
      model = 'auto', // Auto-select based on provider
      temperature = 0.7,
      maxTokens = 2048,
      stream = false,
      provider = null // Force specific provider
    } = options;

    if (provider && this.providers[provider]) {
      return await this.chatWithProvider(provider, { messages, model, temperature, maxTokens, stream });
    }

    return await this.executeWithFallback('chat', { messages, model, temperature, maxTokens, stream });
  }

  async chatWithProvider(provider, options) {
    const { messages, model, temperature, maxTokens, stream } = options;
    
    switch (provider) {
      case PROVIDERS.GEMINI:
        return await this.chatGemini(messages, model, temperature, maxTokens, stream);
      case PROVIDERS.OPENAI:
        return await this.chatOpenAI(messages, model, temperature, maxTokens, stream);
      case PROVIDERS.MISTRAL:
        return await this.chatMistral(messages, model, temperature, maxTokens, stream);
      case PROVIDERS.ANTHROPIC:
        return await this.chatAnthropic(messages, model, temperature, maxTokens, stream);
      case PROVIDERS.COHERE:
        return await this.chatCohere(messages, model, temperature, maxTokens, stream);
      case PROVIDERS.GROQ:
        return await this.chatGroq(messages, model, temperature, maxTokens, stream);
      default:
        throw new Error(`Chat not supported for provider: ${provider}`);
    }
  }

  async chatGemini(messages, modelName, temperature, maxTokens, stream) {
    const model = modelName === 'auto' ? 'gemini-2.0-flash-exp' : modelName;
    const genAI = this.providers[PROVIDERS.GEMINI];

    // Format messages for Gemini API
    const contents = messages.map(msg => ({
      role: msg.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: msg.content }]
    }));

    // Use the new @google/genai v1.x API
    const result = await genAI.models.generateContent({
      model,
      contents,
      generationConfig: {
        temperature,
        maxOutputTokens: maxTokens
      }
    });

    if (stream) {
      // Streaming support if needed
      return { stream: result.stream };
    }

    return { text: result.text, model };
  }

  async chatOpenAI(messages, modelName, temperature, maxTokens, stream) {
    const model = modelName === 'auto' ? 'gpt-4o-mini' : modelName;
    const config = this.providers[PROVIDERS.OPENAI];

    const response = await axios.post(
      `${config.baseURL}/chat/completions`,
      {
        model,
        messages,
        temperature,
        max_tokens: maxTokens,
        stream
      },
      {
        headers: {
          'Authorization': `Bearer ${config.apiKey}`,
          'Content-Type': 'application/json'
        },
        responseType: stream ? 'stream' : 'json'
      }
    );

    if (stream) {
      return { stream: response.data, provider: PROVIDERS.OPENAI };
    }

    return {
      text: response.data.choices[0].message.content,
      model,
      usage: response.data.usage
    };
  }

  async chatMistral(messages, modelName, temperature, maxTokens, stream) {
    const model = modelName === 'auto' ? 'mistral-large-latest' : modelName;
    const client = this.providers[PROVIDERS.MISTRAL];

    if (stream) {
      // For streaming, Mistral SDK uses completionStream which is an async iterable
      const streamResponse = await client.chat.stream({
        model,
        messages,
        temperature,
        maxTokens
      });
      
      return { stream: streamResponse, provider: PROVIDERS.MISTRAL };
    }

    // Non-streaming
    const response = await client.chat.complete({
      model,
      messages,
      temperature,
      maxTokens
    });

    return {
      text: response.choices[0].message.content,
      model,
      usage: response.usage
    };
  }

  async chatAnthropic(messages, modelName, temperature, maxTokens, stream) {
    const model = modelName === 'auto' ? 'claude-3-5-sonnet-20241022' : modelName;
    const client = this.providers[PROVIDERS.ANTHROPIC];

    const systemMessage = messages.find(m => m.role === 'system');
    const userMessages = messages.filter(m => m.role !== 'system');

    const response = await client.messages.create({
      model,
      max_tokens: maxTokens,
      temperature,
      system: systemMessage?.content || undefined,
      messages: userMessages,
      stream
    });

    if (stream) {
      return { stream: response };
    }

    return {
      text: response.content[0].text,
      model,
      usage: response.usage
    };
  }

  async chatCohere(messages, modelName, temperature, maxTokens) {
    const model = modelName === 'auto' ? 'command-r-08-2024' : modelName;
    const config = this.providers[PROVIDERS.COHERE];

    // Use Cohere v2 API with new models
    const response = await axios.post(
      'https://api.cohere.com/v2/chat',
      {
        model,
        messages: messages.map(msg => ({
          role: msg.role,
          content: msg.content
        })),
        temperature,
        max_tokens: maxTokens
      },
      {
        headers: {
          'Authorization': `Bearer ${config.token}`,
          'Content-Type': 'application/json'
        }
      }
    );

    return {
      text: response.data.message.content[0].text,
      model
    };
  }

  async chatGroq(messages, modelName, temperature, maxTokens) {
    const model = modelName === 'auto' ? 'llama-3.3-70b-versatile' : modelName;
    const client = this.providers[PROVIDERS.GROQ];

    const response = await client.chat.completions.create({
      model,
      messages,
      temperature,
      max_tokens: maxTokens
    });

    return {
      text: response.choices[0].message.content,
      model,
      usage: response.usage
    };
  }

  // ============================================
  // EMBEDDINGS - ALL PROVIDERS
  // ============================================

  async embed(text, options = {}) {
    const { model = 'auto', provider = null } = options;

    if (provider && this.providers[provider]) {
      return await this.embedWithProvider(provider, { text, model });
    }

    return await this.executeWithFallback('embed', { text, model });
  }

  async embedWithProvider(provider, options) {
    const { text, model } = options;
    
    switch (provider) {
      case PROVIDERS.GEMINI:
        return await this.embedGemini(text, model);
      case PROVIDERS.OPENAI:
        return await this.embedOpenAI(text, model);
      case PROVIDERS.MISTRAL:
        return await this.embedMistral(text, model);
      case PROVIDERS.COHERE:
        return await this.embedCohere(text, model);
      default:
        throw new Error(`Embeddings not supported for provider: ${provider}`);
    }
  }

  async embedGemini(text, modelName) {
    const model = modelName === 'auto' ? 'text-embedding-004' : modelName;
    const genAI = this.providers[PROVIDERS.GEMINI];

    // Use the new embedContent API
    const result = await genAI.models.embedContent({
      model,
      content: { parts: [{ text }] }
    });

    return {
      embedding: result.embedding.values,
      model,
      dimensions: result.embedding.values.length
    };
  }

  async embedOpenAI(text, modelName) {
    const model = modelName === 'auto' ? 'text-embedding-3-large' : modelName;
    const config = this.providers[PROVIDERS.OPENAI];

    const response = await axios.post(
      `${config.baseURL}/embeddings`,
      { model, input: text },
      {
        headers: {
          'Authorization': `Bearer ${config.apiKey}`,
          'Content-Type': 'application/json'
        }
      }
    );

    return {
      embedding: response.data.data[0].embedding,
      model,
      dimensions: response.data.data[0].embedding.length,
      usage: response.data.usage
    };
  }

  async embedMistral(text, modelName) {
    const model = modelName === 'auto' ? 'mistral-embed' : modelName;
    const client = this.providers[PROVIDERS.MISTRAL];

    const response = await client.embeddings.create({
      model,
      inputs: [text]
    });

    return {
      embedding: response.data[0].embedding,
      model,
      dimensions: response.data[0].embedding.length
    };
  }

  async embedCohere(text, modelName) {
    const model = modelName === 'auto' ? 'embed-english-v3.0' : modelName;
    const client = this.providers[PROVIDERS.COHERE];

    const response = await client.embed({
      texts: [text],
      model,
      inputType: 'search_query'
    });

    return {
      embedding: response.embeddings[0],
      model,
      dimensions: response.embeddings[0].length
    };
  }

  // ============================================
  // PINECONE VECTOR OPERATIONS
  // ============================================

  async storeEmbedding(id, embedding, metadata = {}) {
    if (!this.vectorDB) {
      throw new Error('Pinecone not initialized');
    }

    const index = this.vectorDB.Index(process.env.PINECONE_INDEX || 'intelcore-ai');
    
    await index.upsert([{
      id,
      values: embedding,
      metadata
    }]);

    return { success: true, id };
  }

  async queryVectors(embedding, topK = 10, filter = {}) {
    if (!this.vectorDB) {
      throw new Error('Pinecone not initialized');
    }

    const index = this.vectorDB.Index(process.env.PINECONE_INDEX || 'intelcore-ai');
    
    const results = await index.query({
      vector: embedding,
      topK,
      filter,
      includeMetadata: true
    });

    return results.matches;
  }

  // ============================================
  // IMAGE GENERATION - ALL PROVIDERS
  // ============================================

  async generateImage(prompt, options = {}) {
    const {
      model = 'auto',
      size = '1024x1024',
      quality = 'standard',
      provider = null
    } = options;

    if (provider && this.providers[provider]) {
      return await this.generateImageWithProvider(provider, { prompt, model, size, quality });
    }

    return await this.executeWithFallback('image', { prompt, model, size, quality });
  }

  async generateImageWithProvider(provider, options) {
    const { prompt, model, size, quality } = options;
    
    switch (provider) {
      case PROVIDERS.GEMINI:
        return await this.imageGemini(prompt, model);
      case PROVIDERS.OPENAI:
        return await this.imageOpenAI(prompt, model, size, quality);
      case PROVIDERS.STABILITY:
        return await this.imageStability(prompt, model);
      default:
        throw new Error(`Image generation not supported for provider: ${provider}`);
    }
  }

  async imageGemini(prompt, modelName) {
    const model = modelName === 'auto' ? 'imagen-3.0-generate-001' : modelName;
    // Implementation for Gemini Imagen
    throw new Error('Gemini Imagen requires separate API access');
  }

  async imageOpenAI(prompt, modelName, size, quality) {
    const model = modelName === 'auto' ? 'dall-e-3' : modelName;
    const config = this.providers[PROVIDERS.OPENAI];

    const response = await axios.post(
      `${config.baseURL}/images/generations`,
      { model, prompt, size, quality, n: 1 },
      {
        headers: {
          'Authorization': `Bearer ${config.apiKey}`,
          'Content-Type': 'application/json'
        }
      }
    );

    return {
      url: response.data.data[0].url,
      model,
      revised_prompt: response.data.data[0].revised_prompt
    };
  }

  async imageStability(prompt, modelName) {
    const model = modelName === 'auto' ? 'stable-diffusion-xl-1024-v1-0' : modelName;
    const config = this.apis[PROVIDERS.STABILITY];

    const response = await axios.post(
      `${config.baseURL}/v1/generation/${model}/text-to-image`,
      {
        text_prompts: [{ text: prompt }],
        cfg_scale: 7,
        height: 1024,
        width: 1024,
        steps: 30,
        samples: 1
      },
      {
        headers: {
          'Authorization': `Bearer ${config.apiKey}`,
          'Content-Type': 'application/json'
        }
      }
    );

    return {
      image: response.data.artifacts[0].base64,
      model,
      format: 'base64'
    };
  }

  // ============================================
  // TEXT-TO-SPEECH - ALL PROVIDERS
  // ============================================

  async textToSpeech(text, options = {}) {
    const {
      voice = 'auto',
      model = 'auto',
      provider = PROVIDERS.ELEVENLABS // Premium TTS by default
    } = options;

    if (this.apis[provider]) {
      return await this.ttsWithProvider(provider, { text, voice, model });
    }

    // Fallback to OpenAI or Gemini
    return await this.executeWithFallback('tts', { text, voice, model });
  }

  async ttsWithProvider(provider, options) {
    const { text, voice, model } = options;
    
    switch (provider) {
      case PROVIDERS.ELEVENLABS:
        return await this.ttsElevenLabs(text, voice);
      case PROVIDERS.OPENAI:
        return await this.ttsOpenAI(text, voice, model);
      default:
        throw new Error(`TTS not supported for provider: ${provider}`);
    }
  }

  async ttsElevenLabs(text, voiceId = 'EXAVITQu4vr4xnSDxMaL') {
    const config = this.apis[PROVIDERS.ELEVENLABS];

    const response = await axios.post(
      `${config.baseURL}/text-to-speech/${voiceId}`,
      {
        text,
        model_id: 'eleven_multilingual_v2',
        voice_settings: {
          stability: 0.5,
          similarity_boost: 0.75
        }
      },
      {
        headers: {
          'xi-api-key': config.apiKey,
          'Content-Type': 'application/json'
        },
        responseType: 'arraybuffer'
      }
    );

    return {
      audio: Buffer.from(response.data).toString('base64'),
      format: 'mp3',
      provider: PROVIDERS.ELEVENLABS
    };
  }

  async ttsOpenAI(text, voice = 'nova', modelName = 'tts-1-hd') {
    const config = this.providers[PROVIDERS.OPENAI];

    const response = await axios.post(
      `${config.baseURL}/audio/speech`,
      {
        model: modelName,
        input: text,
        voice
      },
      {
        headers: {
          'Authorization': `Bearer ${config.apiKey}`,
          'Content-Type': 'application/json'
        },
        responseType: 'arraybuffer'
      }
    );

    return {
      audio: Buffer.from(response.data).toString('base64'),
      format: 'mp3',
      provider: PROVIDERS.OPENAI
    };
  }

  // ============================================
  // SPECIALIZED API SERVICES
  // ============================================

  async getNASAData(endpoint = 'apod', params = {}) {
    const config = this.apis[PROVIDERS.NASA];
    if (!config) throw new Error('NASA API not configured');

    const response = await axios.get(`${config.baseURL}/${endpoint}`, {
      params: { ...params, api_key: config.apiKey }
    });

    return response.data;
  }

  async getNews(query, options = {}) {
    const config = this.apis[PROVIDERS.NEWS];
    if (!config) throw new Error('NewsAPI not configured');

    const { language = 'en', sortBy = 'publishedAt', pageSize = 10 } = options;

    const response = await axios.get(`${config.baseURL}/everything`, {
      params: {
        q: query,
        language,
        sortBy,
        pageSize,
        apiKey: config.apiKey
      }
    });

    return response.data.articles;
  }

  async getStockData(symbol, options = {}) {
    const config = this.apis[PROVIDERS.FINANCE];
    if (!config) throw new Error('Alpha Vantage not configured');

    const { function: func = 'TIME_SERIES_DAILY', outputsize = 'compact' } = options;

    const response = await axios.get(`${config.baseURL}/query`, {
      params: {
        function: func,
        symbol,
        outputsize,
        apikey: config.apiKey
      }
    });

    return response.data;
  }

  async scanFile(fileHash) {
    const config = this.apis[PROVIDERS.SECURITY]?.virustotal;
    if (!config) throw new Error('VirusTotal not configured');

    const response = await axios.get(
      `${config.baseURL}/files/${fileHash}`,
      {
        headers: { 'x-apikey': config.apiKey }
      }
    );

    return response.data;
  }

  async lookupIP(ip) {
    const config = this.apis[PROVIDERS.SECURITY]?.shodan;
    if (!config) throw new Error('Shodan not configured');

    const response = await axios.get(
      `${config.baseURL}/shodan/host/${ip}`,
      {
        params: { key: config.apiKey }
      }
    );

    return response.data;
  }

  async checkIPReputation(ip) {
    const config = this.apis[PROVIDERS.SECURITY]?.abuseipdb;
    if (!config) throw new Error('AbuseIPDB not configured');

    const response = await axios.get(
      `${config.baseURL}/check`,
      {
        params: { ipAddress: ip, maxAgeInDays: 90 },
        headers: { 'Key': config.apiKey }
      }
    );

    return response.data;
  }

  async verifyEmail(email) {
    const config = this.apis[PROVIDERS.SECURITY]?.hunter;
    if (!config) throw new Error('Hunter.io not configured');

    const response = await axios.get(
      `${config.baseURL}/email-verifier`,
      {
        params: { email, api_key: config.apiKey }
      }
    );

    return response.data;
  }

  // ============================================
  // UTILITY METHODS
  // ============================================

  listAllModels() {
    const modelList = {};
    
    for (const [provider, categories] of Object.entries(MODELS)) {
      if (this.providers[provider]) {
        modelList[provider] = {};
        
        for (const [category, models] of Object.entries(categories)) {
          modelList[provider][category] = Object.keys(models);
        }
      }
    }

    return modelList;
  }

  getModelInfo(provider, category, modelName) {
    return MODELS[provider]?.[category]?.[modelName];
  }
}

// ============================================
// EXPORT SINGLETON INSTANCE
// ============================================

const comprehensiveAI = new ComprehensiveAIService();

module.exports = comprehensiveAI;
module.exports.PROVIDERS = PROVIDERS;
module.exports.MODELS = MODELS;
module.exports.ComprehensiveAIService = ComprehensiveAIService;
