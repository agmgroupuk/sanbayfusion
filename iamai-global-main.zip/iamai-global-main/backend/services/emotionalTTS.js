/**
 * 🎭 EMOTIONAL TEXT-TO-SPEECH SERVICE
 * ====================================
 * Human-like, emotion-aware TTS with multiple provider support
 * 
 * Features:
 * - Emotional voice synthesis (happy, sad, romantic, energetic, calm, angry, etc.)
 * - Multi-provider support (ElevenLabs, Google Cloud, Azure, OpenAI)
 * - Agent personality-based voice selection
 * - Context-aware emotion detection
 * - Gender-specific voice mapping
 * - Speaking style customization
 */

const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '../.env') });
const axios = require('axios');
const { TextToSpeechClient } = require('@google-cloud/text-to-speech');
const { SpeechConfig, SpeechSynthesizer, AudioConfig } = require('microsoft-cognitiveservices-speech-sdk');
let PollyClient, SynthesizeSpeechCommand; // Loaded lazily if available
try {
  ({ PollyClient, SynthesizeSpeechCommand } = require('@aws-sdk/client-polly'));
} catch (e) {
  // Optional dependency; handled at runtime if provider=polly is requested
}

// ============================================
// EMOTIONAL VOICE CONFIGURATIONS
// ============================================

const EMOTION_STYLES = {
  // Positive emotions
  happy: { intensity: 0.8, pitch: '+5%', rate: '1.1' },
  excited: { intensity: 1.0, pitch: '+8%', rate: '1.15' },
  romantic: { intensity: 0.6, pitch: '+2%', rate: '0.9' },
  cheerful: { intensity: 0.7, pitch: '+3%', rate: '1.05' },
  
  // Neutral/Professional
  neutral: { intensity: 0.5, pitch: '0%', rate: '1.0' },
  calm: { intensity: 0.4, pitch: '-2%', rate: '0.95' },
  professional: { intensity: 0.5, pitch: '0%', rate: '1.0' },
  
  // Negative emotions
  sad: { intensity: 0.3, pitch: '-5%', rate: '0.85' },
  angry: { intensity: 0.9, pitch: '+3%', rate: '1.1' },
  fearful: { intensity: 0.6, pitch: '+5%', rate: '1.05' },
  
  // Specialized
  empathetic: { intensity: 0.6, pitch: '-1%', rate: '0.95' },
  playful: { intensity: 0.8, pitch: '+4%', rate: '1.1' },
  seductive: { intensity: 0.7, pitch: '-2%', rate: '0.88' },
  energetic: { intensity: 0.9, pitch: '+5%', rate: '1.15' },
  sarcastic: { intensity: 0.6, pitch: '+2%', rate: '1.05' },
  mysterious: { intensity: 0.5, pitch: '-3%', rate: '0.9' },
};

// ============================================
// VOICE LIBRARY - Agent-Specific Voices
// ============================================

const VOICE_LIBRARY = {
  // FEMALE VOICES
  female: {
    default: {
      elevenlabs: '21m00Tcm4TlvDq8ikWAM', // Rachel - warm female
      google: 'en-US-Neural2-F',
      azure: 'en-US-JennyNeural',
      openai: 'nova'
    },
    romantic: {
      elevenlabs: 'EXAVITQu4vr4xnSDxMaL', // Sarah - soft romantic
      google: 'en-US-Neural2-C',
      azure: 'en-US-AriaNeural',
      openai: 'shimmer'
    },
    professional: {
      elevenlabs: 'pNInz6obpgDQGcFmaJgB', // Bella - professional
      google: 'en-US-Neural2-F',
      azure: 'en-US-JennyNeural',
      openai: 'nova'
    },
    energetic: {
      elevenlabs: 'ThT5KcBeYPX3keUQqHPh', // Dorothy - energetic
      google: 'en-US-Neural2-E',
      azure: 'en-US-SaraNeural',
      openai: 'alloy'
    },
    calm: {
      elevenlabs: 'EXAVITQu4vr4xnSDxMaL', // Sarah - calm soothing
      google: 'en-US-Neural2-C',
      azure: 'en-US-JaneNeural',
      openai: 'shimmer'
    }
  },
  
  // MALE VOICES
  male: {
    default: {
      elevenlabs: 'TxGEqnHWrfWFTfGW9XjX', // Josh - friendly male
      google: 'en-US-Neural2-D',
      azure: 'en-US-GuyNeural',
      openai: 'onyx'
    },
    confident: {
      elevenlabs: 'VR6AewLTigWG4xSOukaG', // Arnold - confident
      google: 'en-US-Neural2-A',
      azure: 'en-US-DavisNeural',
      openai: 'echo'
    },
    friendly: {
      elevenlabs: 'TxGEqnHWrfWFTfGW9XjX', // Josh - friendly
      google: 'en-US-Neural2-D',
      azure: 'en-US-GuyNeural',
      openai: 'fable'
    },
    professional: {
      elevenlabs: 'ErXwobaYiN019PkySvjV', // Antoni - professional
      google: 'en-US-Neural2-J',
      azure: 'en-US-AndrewNeural',
      openai: 'onyx'
    },
    energetic: {
      elevenlabs: 'yoZ06aMxZJJ28mfd3POQ', // Sam - energetic
      google: 'en-US-Neural2-A',
      azure: 'en-US-TonyNeural',
      openai: 'echo'
    }
  },
  
  // NEUTRAL VOICES
  neutral: {
    default: {
      elevenlabs: 'pNInz6obpgDQGcFmaJgB',
      google: 'en-US-Neural2-H',
      azure: 'en-US-JennyNeural',
      openai: 'alloy'
    }
  }
};

// ============================================
// AGENT-SPECIFIC VOICE MAPPINGS
// ============================================

const AGENT_VOICE_CONFIG = {
  'ai-girlfriend': { gender: 'female', style: 'romantic', emotion: 'romantic' },
  'emo-ai': { gender: 'female', style: 'empathetic', emotion: 'empathetic' },
  'pdf-mind': { gender: 'female', style: 'professional', emotion: 'neutral' },
  'chat-revive': { gender: 'male', style: 'friendly', emotion: 'cheerful' },
  'tok-boost': { gender: 'male', style: 'energetic', emotion: 'excited' },
  'you-gen': { gender: 'female', style: 'energetic', emotion: 'excited' },
  'agent-x': { gender: 'female', style: 'professional', emotion: 'professional' },
  'auto-chat': { gender: 'male', style: 'friendly', emotion: 'cheerful' },
  'cv-smash': { gender: 'female', style: 'professional', emotion: 'professional' },
  'comedy-chad': { gender: 'male', style: 'energetic', emotion: 'playful' },
  'lazy-larry': { gender: 'male', style: 'calm', emotion: 'calm' },
  'flirty-fiona': { gender: 'female', style: 'romantic', emotion: 'seductive' },
  'sassy-sarah': { gender: 'female', style: 'energetic', emotion: 'sarcastic' },
  'nerdy-neil': { gender: 'male', style: 'professional', emotion: 'neutral' },
  'cool-kyle': { gender: 'male', style: 'confident', emotion: 'calm' },
  'zen-master-zara': { gender: 'female', style: 'calm', emotion: 'calm' },
  'gamer-gary': { gender: 'male', style: 'energetic', emotion: 'excited' },
};

// Prefer voice style that matches detected emotion, falling back to agent default
const EMOTION_TO_VOICE_STYLE = {
  romantic: 'romantic',
  excited: 'energetic',
  energetic: 'energetic',
  cheerful: 'friendly',
  playful: 'energetic',
  empathetic: 'calm',
  professional: 'professional',
  calm: 'calm',
  sad: 'calm',
  angry: 'confident',
  fearful: 'calm',
  mysterious: 'calm',
  sarcastic: 'confident',
};

// ============================================
// EMOTION DETECTION FROM TEXT
// ============================================

function detectEmotionFromText(text) {
  const lowerText = text.toLowerCase();
  
  // Romantic indicators
  if (/\b(love|darling|sweetheart|honey|kiss|romantic|adore|passion)\b/i.test(text)) {
    return 'romantic';
  }
  
  // Excitement indicators
  if (/\b(awesome|amazing|incredible|wow|fantastic|exciting|yay|woohoo)\b/i.test(text) || /!{2,}/.test(text)) {
    return 'excited';
  }
  
  // Sadness indicators
  if (/\b(sorry|sad|unfortunately|regret|disappointed|miss|alone)\b/i.test(text)) {
    return 'sad';
  }
  
  // Anger indicators
  if (/\b(angry|furious|mad|frustrated|annoyed|hate)\b/i.test(text)) {
    return 'angry';
  }
  
  // Playful indicators
  if (/\b(haha|lol|joke|fun|play|game|silly)\b/i.test(text) || /[😂😄😊😉]/.test(text)) {
    return 'playful';
  }
  
  // Calm/Professional indicators
  if (/\b(understand|explain|consider|analyze|professional|business)\b/i.test(text)) {
    return 'professional';
  }
  
  // Empathetic indicators
  if (/\b(feel|understand|support|here for you|empathy|care)\b/i.test(text)) {
    return 'empathetic';
  }
  
  // Energetic indicators
  if (/\b(let's go|come on|hurry|fast|quick|energy|power)\b/i.test(text)) {
    return 'energetic';
  }
  
  // Default to cheerful for general positive content
  return 'cheerful';
}

// ============================================
// ELEVENLABS TTS (Premium - Best Quality)
// ============================================

class EmotionalTTSService {
  constructor() {
    this.elevenLabsApiKey = process.env.ELEVENLABS_API_KEY;
    this.googleClient = null;
    this.azureSpeechKey = process.env.AZURE_SPEECH_KEY;
    this.azureRegion = process.env.AZURE_REGION || 'eastus';
    
    // Initialize Google Cloud TTS if credentials exist
    if (process.env.GOOGLE_APPLICATION_CREDENTIALS) {
      try {
        this.googleClient = new TextToSpeechClient();
      } catch (error) {
        console.warn('Google Cloud TTS not initialized:', error.message);
      }
    }
  }

  /**
   * Main TTS function with emotion support
   */
  async synthesize({
    text,
    agentId,
    gender = 'female',
    emotion = null,
    style = null,
    provider = 'elevenlabs',
    language = 'en-US'
  }) {
    try {
      // Get agent-specific configuration
      const agentConfig = AGENT_VOICE_CONFIG[agentId] || { gender, emotion: 'neutral' };
      
      // Auto-detect emotion from text if not provided
      const detectedEmotion = emotion || detectEmotionFromText(text) || agentConfig.emotion;
      
      // Get emotional parameters
  const emotionParams = EMOTION_STYLES[detectedEmotion] || EMOTION_STYLES.neutral;

  // Determine preferred voice style by explicit style override, emotion mapping, then agent default
  const preferredStyle = style || EMOTION_TO_VOICE_STYLE[detectedEmotion] || agentConfig.style || 'default';
  const genderKey = agentConfig.gender || gender || 'neutral';
  const voiceConfig = VOICE_LIBRARY[genderKey]?.[preferredStyle] || VOICE_LIBRARY[genderKey]?.default;
      
  console.log(`🎭 TTS: Agent=${agentId}, Gender=${genderKey}, Style=${preferredStyle}, Emotion=${detectedEmotion}`);
      
      // Try primary provider, fallback to others
      let audioBuffer;
      
      switch (provider) {
        case 'elevenlabs':
          audioBuffer = await this.synthesizeElevenLabs(text, voiceConfig.elevenlabs, emotionParams);
          break;
        case 'google':
          audioBuffer = await this.synthesizeGoogle(text, voiceConfig.google, emotionParams, language);
          break;
        case 'azure':
          audioBuffer = await this.synthesizeAzure(text, voiceConfig.azure, emotionParams, detectedEmotion);
          break;
        case 'openai':
          audioBuffer = await this.synthesizeOpenAI(text, voiceConfig.openai);
          break;
        case 'polly':
          audioBuffer = await this.synthesizePolly(text, genderKey, preferredStyle, language);
          break;
        default:
          throw new Error(`Unknown provider: ${provider}`);
      }
      
      return {
        success: true,
        audioBuffer,
        provider,
        emotion: detectedEmotion,
        voice: voiceConfig[provider],
        metadata: {
          agentId,
          gender: genderKey,
          style: preferredStyle,
          emotionParams
        }
      };
      
    } catch (error) {
      console.error('TTS synthesis error:', error);
      throw error;
    }
  }

  /**
   * Amazon Polly TTS (Neural voices where available)
   */
  async synthesizePolly(text, genderKey = 'neutral', preferredStyle = 'default', language = 'en-US') {
    if (!PollyClient || !SynthesizeSpeechCommand) {
      throw new Error("AWS Polly SDK not installed. Run `npm i @aws-sdk/client-polly` in backend.");
    }

    const region = process.env.AWS_REGION || 'us-east-1';
    const client = new PollyClient({ region });

    // Minimal mapping from gender/style to Polly voice names
    const femaleMap = {
      default: 'Joanna',
      romantic: 'Joanna',
      energetic: 'Ivy',
      friendly: 'Joanna',
      professional: 'Kendra',
      calm: 'Salli',
      confident: 'Kendra'
    };
    const maleMap = {
      default: 'Matthew',
      romantic: 'Matthew',
      energetic: 'Joey',
      friendly: 'Kevin',
      professional: 'Matthew',
      calm: 'Matthew',
      confident: 'Justin'
    };

    const voiceName = (genderKey === 'female' ? femaleMap[preferredStyle] : maleMap[preferredStyle])
      || (genderKey === 'female' ? femaleMap.default : maleMap.default);

    const params = {
      Text: text,
      OutputFormat: 'mp3',
      VoiceId: voiceName,
      Engine: 'neural'
    };

    const command = new SynthesizeSpeechCommand(params);
    const response = await client.send(command);
    const chunks = [];
    for await (const chunk of response.AudioStream) {
      chunks.push(Buffer.from(chunk));
    }
    return Buffer.concat(chunks);
  }

  /**
   * ElevenLabs TTS (Premium, Best Emotional Quality)
   */
  async synthesizeElevenLabs(text, voiceId, emotionParams) {
    if (!this.elevenLabsApiKey) {
      throw new Error('ElevenLabs API key not configured');
    }

    const response = await axios.post(
      `https://api.elevenlabs.io/v1/text-to-speech/${voiceId}`,
      {
        text,
        model_id: 'eleven_multilingual_v2',
        voice_settings: {
          stability: 0.5,
          similarity_boost: 0.75,
          style: emotionParams.intensity,
          use_speaker_boost: true
        }
      },
      {
        headers: {
          'xi-api-key': this.elevenLabsApiKey,
          'Content-Type': 'application/json'
        },
        responseType: 'arraybuffer'
      }
    );

    return Buffer.from(response.data);
  }

  /**
   * Google Cloud TTS (Good emotion support via SSML)
   */
  async synthesizeGoogle(text, voiceName, emotionParams, language) {
    if (!this.googleClient) {
      throw new Error('Google Cloud TTS not configured');
    }

    // Build SSML with emotional parameters
    const ssml = `
      <speak>
        <prosody rate="${emotionParams.rate}" pitch="${emotionParams.pitch}">
          ${text}
        </prosody>
      </speak>
    `;

    const [response] = await this.googleClient.synthesizeSpeech({
      input: { ssml },
      voice: {
        languageCode: language,
        name: voiceName,
        ssmlGender: 'NEUTRAL'
      },
      audioConfig: {
        audioEncoding: 'MP3',
        speakingRate: parseFloat(emotionParams.rate),
        pitch: parseFloat(emotionParams.pitch.replace('%', '')) / 10
      }
    });

    return response.audioContent;
  }

  /**
   * Azure TTS (Excellent emotion support with speaking styles)
   */
  async synthesizeAzure(text, voiceName, emotionParams, emotion) {
    if (!this.azureSpeechKey) {
      throw new Error('Azure Speech key not configured');
    }

    const speechConfig = SpeechConfig.fromSubscription(this.azureSpeechKey, this.azureRegion);
    speechConfig.speechSynthesisVoiceName = voiceName;
    
    const synthesizer = new SpeechSynthesizer(speechConfig);

    // Azure supports specific style names
    const azureStyleMap = {
      romantic: 'affectionate',
      excited: 'excited',
      sad: 'sad',
      angry: 'angry',
      cheerful: 'cheerful',
      empathetic: 'empathetic',
      calm: 'calm',
      professional: 'professional'
    };

    const style = azureStyleMap[emotion] || 'friendly';

    // Build SSML with emotion
    const ssml = `
      <speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" 
             xmlns:mstts="https://www.w3.org/2001/mstts" xml:lang="en-US">
        <voice name="${voiceName}">
          <mstts:express-as style="${style}" styledegree="${emotionParams.intensity}">
            <prosody rate="${emotionParams.rate}" pitch="${emotionParams.pitch}">
              ${text}
            </prosody>
          </mstts:express-as>
        </voice>
      </speak>
    `;

    return new Promise((resolve, reject) => {
      synthesizer.speakSsmlAsync(
        ssml,
        result => {
          if (result) {
            resolve(Buffer.from(result.audioData));
            synthesizer.close();
          } else {
            reject(new Error('No audio data returned'));
          }
        },
        error => {
          synthesizer.close();
          reject(error);
        }
      );
    });
  }

  /**
   * OpenAI TTS (Simple but effective)
   */
  async synthesizeOpenAI(text, voice) {
    const openaiKey = process.env.OPENAI_API_KEY;
    if (!openaiKey) {
      throw new Error('OpenAI API key not configured');
    }

    const response = await axios.post(
      'https://api.openai.com/v1/audio/speech',
      {
        model: 'tts-1-hd',
        input: text,
        voice: voice,
        speed: 1.0
      },
      {
        headers: {
          'Authorization': `Bearer ${openaiKey}`,
          'Content-Type': 'application/json'
        },
        responseType: 'arraybuffer'
      }
    );

    return Buffer.from(response.data);
  }

  /**
   * Fallback synthesis with automatic provider switching
   */
  async synthesizeWithFallback(options) {
    const providers = ['elevenlabs', 'google', 'azure', 'openai'];
    
    for (const provider of providers) {
      try {
        return await this.synthesize({ ...options, provider });
      } catch (error) {
        console.warn(`TTS failed with ${provider}, trying next...`);
        continue;
      }
    }
    
    throw new Error('All TTS providers failed');
  }
}

// ============================================
// EXPORT
// ============================================

module.exports = new EmotionalTTSService();
