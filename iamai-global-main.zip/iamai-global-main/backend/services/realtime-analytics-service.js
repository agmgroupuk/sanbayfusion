/**
 * Real-time Analytics Service
 * Tracks user activity, agent usage, system metrics in real-time
 * Broadcasts updates via WebSocket to connected clients
 */

const os = require('os');

class RealtimeAnalyticsService {
  constructor(io, db) {
    this.io = io;
    this.db = db;
    
    // In-memory caches for real-time data
    this.onlineUsers = new Set();
    this.activeAgents = new Map(); // agentId -> count
    this.recentActivity = [];
    this.systemMetrics = {
      totalMessages: 0,
      activeChats: 0,
      apiCalls: 0,
      responseTime: 0,
      cpuUsage: 0,
      memoryUsage: 0,
    };

    // Start periodic updates
    this.startMetricsCollection();
  }

  /**
   * Start collecting system metrics periodically
   */
  startMetricsCollection() {
    // Update system metrics every 5 seconds
    setInterval(() => {
      this.updateSystemMetrics();
    }, 5000);

    // Broadcast dashboard updates every 3 seconds
    setInterval(() => {
      this.broadcastDashboardUpdate();
    }, 3000);

    // Clean old activity every minute
    setInterval(() => {
      this.cleanOldActivity();
    }, 60000);
  }

  /**
   * Update system metrics (CPU, memory, etc.)
   */
  updateSystemMetrics() {
    const cpus = os.cpus();
    const totalIdle = cpus.reduce((acc, cpu) => acc + cpu.times.idle, 0);
    const totalTick = cpus.reduce((acc, cpu) => 
      acc + cpu.times.user + cpu.times.nice + cpu.times.sys + cpu.times.idle + cpu.times.irq, 0
    );
    const cpuUsage = 100 - (totalIdle / totalTick) * 100;

    const totalMem = os.totalmem();
    const freeMem = os.freemem();
    const memoryUsage = ((totalMem - freeMem) / totalMem) * 100;

    this.systemMetrics.cpuUsage = Math.round(cpuUsage);
    this.systemMetrics.memoryUsage = Math.round(memoryUsage);
  }

  /**
   * Track user connection
   */
  trackUserOnline(userId) {
    this.onlineUsers.add(userId);
    this.broadcastOnlineUsers();
  }

  /**
   * Track user disconnection
   */
  trackUserOffline(userId) {
    this.onlineUsers.delete(userId);
    this.broadcastOnlineUsers();
  }

  /**
   * Track agent usage
   */
  trackAgentUsage(agentId, agentName) {
    const current = this.activeAgents.get(agentId) || 0;
    this.activeAgents.set(agentId, current + 1);
    this.broadcastActiveAgents();
  }

  /**
   * Track user activity
   */
  async trackActivity(activity) {
    const activityEntry = {
      id: `activity-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      ...activity,
      timestamp: new Date().toISOString(),
    };

    // Add to recent activity
    this.recentActivity.unshift(activityEntry);
    
    // Keep only last 50 activities in memory
    if (this.recentActivity.length > 50) {
      this.recentActivity = this.recentActivity.slice(0, 50);
    }

    // Save to database
    try {
      if (this.db && this.db.collection) {
        await this.db.collection('activities').insertOne(activityEntry);
      }
    } catch (error) {
      console.error('Error saving activity to database:', error);
    }

    // Broadcast new activity
    this.io.emit('activity:new', activityEntry);
  }

  /**
   * Track message sent
   */
  trackMessage(userId, agentId) {
    this.systemMetrics.totalMessages++;
    this.trackActivity({
      userId,
      userName: 'User',
      agentId,
      agentName: 'Agent',
      action: 'chat',
      metadata: { messageCount: this.systemMetrics.totalMessages },
    });
  }

  /**
   * Track API call
   */
  trackAPICall(endpoint, responseTime) {
    this.systemMetrics.apiCalls++;
    
    // Calculate moving average for response time
    const weight = 0.2;
    this.systemMetrics.responseTime = 
      this.systemMetrics.responseTime * (1 - weight) + responseTime * weight;
  }

  /**
   * Track subscription
   */
  async trackSubscription(userId, userName, agentName, plan) {
    await this.trackActivity({
      userId,
      userName,
      agentId: agentName.toLowerCase().replace(/\s+/g, '-'),
      agentName,
      action: 'subscribe',
      metadata: { plan },
    });
  }

  /**
   * Track file upload
   */
  async trackFileUpload(userId, userName, agentId, agentName, fileName) {
    await this.trackActivity({
      userId,
      userName,
      agentId,
      agentName,
      action: 'upload',
      metadata: { fileName },
    });
  }

  /**
   * Track data export
   */
  async trackExport(userId, userName, exportType) {
    await this.trackActivity({
      userId,
      userName,
      agentId: 'system',
      agentName: 'System',
      action: 'export',
      metadata: { exportType },
    });
  }

  /**
   * Get real-time dashboard data
   */
  getDashboardData() {
    return {
      onlineUsers: this.onlineUsers.size,
      activeAgents: this.activeAgents.size,
      recentActivity: this.recentActivity.slice(0, 20),
      systemMetrics: { ...this.systemMetrics },
    };
  }

  /**
   * Get user analytics
   */
  async getUserAnalytics(userId) {
    try {
      if (!this.db || !this.db.collection) {
        throw new Error('Analytics database is not configured');
      }

      const activities = this.db.collection('activities');
      
      // Get user's activity count by action type
      const activityByType = await activities.aggregate([
        { $match: { userId } },
        { $group: { 
          _id: '$action', 
          count: { $sum: 1 } 
        }}
      ]).toArray();

      // Get user's most used agents
      const topAgents = await activities.aggregate([
        { $match: { userId } },
        { $group: { 
          _id: '$agentId', 
          agentName: { $first: '$agentName' },
          count: { $sum: 1 } 
        }},
        { $sort: { count: -1 } },
        { $limit: 5 }
      ]).toArray();

      // Get activity over time (last 7 days)
      const sevenDaysAgo = new Date();
      sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

      const activityOverTime = await activities.aggregate([
        { 
          $match: { 
            userId, 
            timestamp: { $gte: sevenDaysAgo.toISOString() } 
          } 
        },
        { 
          $group: { 
            _id: { 
              $dateToString: { 
                format: '%Y-%m-%d', 
                date: { $toDate: '$timestamp' } 
              } 
            },
            count: { $sum: 1 } 
          } 
        },
        { $sort: { _id: 1 } }
      ]).toArray();

      return {
        totalActivities: await activities.countDocuments({ userId }),
        activityByType: activityByType.reduce((acc, item) => {
          acc[item._id] = item.count;
          return acc;
        }, {}),
        topAgents: topAgents.map(a => ({
          id: a._id,
          name: a.agentName,
          interactions: a.count,
        })),
        activityOverTime: activityOverTime.map(a => ({
          date: a._id,
          count: a.count,
        })),
      };
    } catch (error) {
      console.error('Error getting user analytics:', error);
      throw error;
    }
  }

  /**
   * Broadcast online users count
   */
  broadcastOnlineUsers() {
    this.io.emit('users:online', this.onlineUsers.size);
  }

  /**
   * Broadcast active agents count
   */
  broadcastActiveAgents() {
    this.io.emit('agents:active', this.activeAgents.size);
  }

  /**
   * Broadcast full dashboard update
   */
  broadcastDashboardUpdate() {
    const data = this.getDashboardData();
    this.io.emit('dashboard:update', data);
  }

  /**
   * Broadcast metrics update
   */
  broadcastMetricsUpdate() {
    this.io.emit('metrics:update', this.systemMetrics);
  }

  /**
   * Send notification to specific user
   */
  sendNotification(userId, notification) {
    const notificationData = {
      id: `notif-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      ...notification,
      timestamp: new Date().toISOString(),
      read: false,
    };

    // Send to specific user
    this.io.to(userId).emit('notification:new', notificationData);
  }

  /**
   * Broadcast notification to all users
   */
  broadcastNotification(notification) {
    const notificationData = {
      id: `notif-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      ...notification,
      timestamp: new Date().toISOString(),
      read: false,
    };

    this.io.emit('notification:new', notificationData);
  }

  /**
   * Clean old activities (keep last 24 hours in memory)
   */
  cleanOldActivity() {
    const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
    this.recentActivity = this.recentActivity.filter(
      activity => activity.timestamp > oneDayAgo
    );
  }

  /**
   * Get platform statistics
   */
  async getPlatformStats() {
    try {
      if (!this.db || !this.db.collection) {
        throw new Error('Analytics database is not configured');
      }

      const users = this.db.collection('users');
      const activities = this.db.collection('activities');

      const totalUsers = await users.countDocuments();
      const totalActivities = await activities.countDocuments();
      
      // Most popular agents
      const popularAgents = await activities.aggregate([
        { $group: { 
          _id: '$agentId', 
          agentName: { $first: '$agentName' },
          count: { $sum: 1 } 
        }},
        { $sort: { count: -1 } },
        { $limit: 10 }
      ]).toArray();

      return {
        totalUsers,
        onlineUsers: this.onlineUsers.size,
        totalActivities,
        totalMessages: this.systemMetrics.totalMessages,
        popularAgents: popularAgents.map(a => ({
          id: a._id,
          name: a.agentName,
          usage: a.count,
        })),
      };
    } catch (error) {
      console.error('Error getting platform stats:', error);
      throw error;
    }
  }
}

module.exports = RealtimeAnalyticsService;
