/**
 * Multi-Provider AI Service
 * Primary: Gemini (Google AI)
 * Secondary: OpenAI
 * Fallback: Anthropic Claude
 *
 * Handles automatic failover, retries, and unified interface for all AI operations
 */

const { GoogleGenerativeAI } = require('@google/generative-ai');
const Anthropic = require('@anthropic-ai/sdk');

// Provider configuration
const PROVIDERS = {
  GEMINI: 'gemini',
  OPENAI: 'openai',
  ANTHROPIC: 'anthropic'
};

const PROVIDER_ORDER = [PROVIDERS.GEMINI, PROVIDERS.OPENAI, PROVIDERS.ANTHROPIC];

// Model mappings for each provider
const MODELS = {
  [PROVIDERS.GEMINI]: {
    chat: {
      fast: 'gemini-2.0-flash-exp',
      balanced: 'gemini-1.5-pro',
      advanced: 'gemini-1.5-pro-002'
    },
    embedding: 'text-embedding-004',
    image: 'imagen-3.0-generate-001',
    tts: 'en-US-Journey-F', // Google Cloud TTS voice
    stt: 'chirp-2' // Google Cloud STT
  },
  [PROVIDERS.OPENAI]: {
    chat: {
      fast: 'gpt-4o-mini',
      balanced: 'gpt-4o',
      advanced: 'gpt-4o'
    },
    embedding: 'text-embedding-3-large',
    image: 'dall-e-3',
    tts: 'tts-1-hd',
    stt: 'whisper-1'
  },
  [PROVIDERS.ANTHROPIC]: {
    chat: {
      fast: 'claude-3-haiku-20240307',
      balanced: 'claude-3-5-sonnet-20241022',
      advanced: 'claude-3-5-sonnet-20241022'
    }
  }
};

class AIProviderService {
  constructor() {
    this.providers = {};
    this.initializeProviders();
    this.retryConfig = {
      maxRetries: 3,
      retryDelay: 1000,
      backoffMultiplier: 2
    };
  }

  initializeProviders() {
    // Initialize Gemini (Primary)
    if (process.env.GEMINI_API_KEY) {
      try {
        this.providers[PROVIDERS.GEMINI] = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
        console.log('✓ Gemini API initialized (Primary)');
      } catch (error) {
        console.error('✗ Gemini initialization failed:', error.message);
      }
    }

    // Initialize OpenAI (Secondary)
    if (process.env.OPENAI_API_KEY) {
      try {
        this.providers[PROVIDERS.OPENAI] = {
          apiKey: process.env.OPENAI_API_KEY,
          baseURL: 'https://api.openai.com/v1'
        };
        console.log('✓ OpenAI API initialized (Secondary)');
      } catch (error) {
        console.error('✗ OpenAI initialization failed:', error.message);
      }
    }

    // Initialize Anthropic (Fallback)
    if (process.env.ANTHROPIC_API_KEY) {
      try {
        this.providers[PROVIDERS.ANTHROPIC] = new Anthropic({
          apiKey: process.env.ANTHROPIC_API_KEY
        });
        console.log('✓ Anthropic API initialized (Fallback)');
      } catch (error) {
        console.error('✗ Anthropic initialization failed:', error.message);
      }
    }
  }

  /**
   * Execute with automatic provider fallback
   */
  async executeWithFallback(operation, options = {}) {
    const errors = [];
    const startTime = Date.now();

    for (const provider of PROVIDER_ORDER) {
      if (!this.providers[provider]) {
        continue; // Skip if provider not initialized
      }

      try {
        console.log(`Attempting ${operation} with ${provider}...`);
        const result = await this.executeOperation(provider, operation, options);
        
        // Log success
        console.log(`✓ ${operation} succeeded with ${provider} (${Date.now() - startTime}ms)`);
        
        return {
          success: true,
          provider,
          data: result,
          latency: Date.now() - startTime
        };
      } catch (error) {
        console.error(`✗ ${operation} failed with ${provider}:`, error.message);
        errors.push({
          provider,
          error: error.message,
          code: error.code || error.status
        });
        
        // Continue to next provider
        continue;
      }
    }

    // All providers failed
    throw new Error(`All providers failed for ${operation}: ${JSON.stringify(errors)}`);
  }

  /**
   * Execute operation on specific provider
   */
  async executeOperation(provider, operation, options) {
    switch (operation) {
      case 'chat':
        return this.chat(provider, options);
      case 'embed':
        return this.embed(provider, options);
      case 'generateImage':
        return this.generateImage(provider, options);
      case 'transcribe':
        return this.transcribe(provider, options);
      case 'synthesize':
        return this.synthesize(provider, options);
      default:
        throw new Error(`Unknown operation: ${operation}`);
    }
  }

  /**
   * Chat/Completion (with streaming support)
   */
  async chat(provider, { messages, model = 'balanced', temperature = 0.7, maxTokens = 2048, stream = false }) {
    const selectedModel = MODELS[provider]?.chat?.[model] || MODELS[provider]?.chat?.balanced;
    
    if (!selectedModel) {
      throw new Error(`No chat model available for provider: ${provider}`);
    }

    switch (provider) {
      case PROVIDERS.GEMINI:
        return this.chatGemini(selectedModel, messages, { temperature, maxTokens, stream });
      
      case PROVIDERS.OPENAI:
        return this.chatOpenAI(selectedModel, messages, { temperature, maxTokens, stream });
      
      case PROVIDERS.ANTHROPIC:
        return this.chatAnthropic(selectedModel, messages, { temperature, maxTokens, stream });
      
      default:
        throw new Error(`Unsupported provider: ${provider}`);
    }
  }

  async chatGemini(model, messages, options) {
    const genAI = this.providers[PROVIDERS.GEMINI];
    const geminiModel = genAI.getGenerativeModel({ model });

    // Convert messages to Gemini format
    const contents = this.convertMessagesToGemini(messages);
    
    if (options.stream) {
      const result = await geminiModel.generateContentStream(contents);
      return this.streamGeminiResponse(result);
    } else {
      const result = await geminiModel.generateContent(contents);
      const response = result.response;
      return {
        text: response.text(),
        finishReason: response.candidates?.[0]?.finishReason,
        usage: {
          promptTokens: response.usageMetadata?.promptTokenCount,
          completionTokens: response.usageMetadata?.candidatesTokenCount,
          totalTokens: response.usageMetadata?.totalTokenCount
        }
      };
    }
  }

  async chatOpenAI(model, messages, options) {
    const { apiKey, baseURL } = this.providers[PROVIDERS.OPENAI];
    
    const response = await fetch(`${baseURL}/chat/completions`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model,
        messages: this.convertMessagesToOpenAI(messages),
        temperature: options.temperature,
        max_tokens: options.maxTokens,
        stream: options.stream
      })
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(`OpenAI API error: ${error.error?.message || response.statusText}`);
    }

    if (options.stream) {
      return this.streamOpenAIResponse(response);
    } else {
      const data = await response.json();
      return {
        text: data.choices[0].message.content,
        finishReason: data.choices[0].finish_reason,
        usage: {
          promptTokens: data.usage.prompt_tokens,
          completionTokens: data.usage.completion_tokens,
          totalTokens: data.usage.total_tokens
        }
      };
    }
  }

  async chatAnthropic(model, messages, options) {
    const client = this.providers[PROVIDERS.ANTHROPIC];
    
    // Extract system message if present
    const systemMessage = messages.find(m => m.role === 'system');
    const conversationMessages = messages.filter(m => m.role !== 'system');

    const response = await client.messages.create({
      model,
      max_tokens: options.maxTokens,
      temperature: options.temperature,
      system: systemMessage?.content,
      messages: this.convertMessagesToAnthropic(conversationMessages),
      stream: options.stream
    });

    if (options.stream) {
      return this.streamAnthropicResponse(response);
    } else {
      return {
        text: response.content[0].text,
        finishReason: response.stop_reason,
        usage: {
          promptTokens: response.usage.input_tokens,
          completionTokens: response.usage.output_tokens,
          totalTokens: response.usage.input_tokens + response.usage.output_tokens
        }
      };
    }
  }

  /**
   * Embeddings
   */
  async embed(provider, { text, model }) {
    const selectedModel = model || MODELS[provider]?.embedding;
    
    if (!selectedModel) {
      throw new Error(`No embedding model available for provider: ${provider}`);
    }

    switch (provider) {
      case PROVIDERS.GEMINI:
        return this.embedGemini(selectedModel, text);
      
      case PROVIDERS.OPENAI:
        return this.embedOpenAI(selectedModel, text);
      
      default:
        throw new Error(`Embedding not supported for provider: ${provider}`);
    }
  }

  async embedGemini(model, text) {
    const genAI = this.providers[PROVIDERS.GEMINI];
    const embeddingModel = genAI.getGenerativeModel({ model });
    
    const result = await embeddingModel.embedContent(text);
    
    return {
      embedding: result.embedding.values,
      dimensions: result.embedding.values.length
    };
  }

  async embedOpenAI(model, text) {
    const { apiKey, baseURL } = this.providers[PROVIDERS.OPENAI];
    
    const response = await fetch(`${baseURL}/embeddings`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model,
        input: text
      })
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(`OpenAI Embeddings error: ${error.error?.message}`);
    }

    const data = await response.json();
    return {
      embedding: data.data[0].embedding,
      dimensions: data.data[0].embedding.length,
      usage: data.usage
    };
  }

  /**
   * Image Generation
   */
  async generateImage(provider, { prompt, size = '1024x1024', quality = 'standard' }) {
    switch (provider) {
      case PROVIDERS.GEMINI:
        return this.generateImageGemini(prompt, { size });
      
      case PROVIDERS.OPENAI:
        return this.generateImageOpenAI(prompt, { size, quality });
      
      default:
        throw new Error(`Image generation not supported for provider: ${provider}`);
    }
  }

  async generateImageGemini(prompt, options) {
    // Gemini Imagen API integration
    const { apiKey } = this.providers[PROVIDERS.GEMINI];
    const model = MODELS[PROVIDERS.GEMINI].image;
    
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:predict`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        instances: [{ prompt }],
        parameters: {
          sampleCount: 1
        }
      })
    });

    const data = await response.json();
    return {
      url: data.predictions[0].bytesBase64Encoded ? 
        `data:image/png;base64,${data.predictions[0].bytesBase64Encoded}` : 
        data.predictions[0].url,
      provider: PROVIDERS.GEMINI
    };
  }

  async generateImageOpenAI(prompt, { size, quality }) {
    const { apiKey, baseURL } = this.providers[PROVIDERS.OPENAI];
    
    const response = await fetch(`${baseURL}/images/generations`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: MODELS[PROVIDERS.OPENAI].image,
        prompt,
        n: 1,
        size,
        quality
      })
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(`OpenAI Image error: ${error.error?.message}`);
    }

    const data = await response.json();
    return {
      url: data.data[0].url,
      revisedPrompt: data.data[0].revised_prompt,
      provider: PROVIDERS.OPENAI
    };
  }

  /**
   * Speech-to-Text (Transcription)
   */
  async transcribe(provider, { audioBuffer, language = 'en' }) {
    switch (provider) {
      case PROVIDERS.GEMINI:
        return this.transcribeGemini(audioBuffer, language);
      
      case PROVIDERS.OPENAI:
        return this.transcribeOpenAI(audioBuffer, language);
      
      default:
        throw new Error(`Transcription not supported for provider: ${provider}`);
    }
  }

  async transcribeGemini(audioBuffer, language) {
    // Google Cloud Speech-to-Text integration
    const { apiKey } = this.providers[PROVIDERS.GEMINI];
    
    const response = await fetch('https://speech.googleapis.com/v1/speech:recognize', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        config: {
          encoding: 'LINEAR16',
          languageCode: language,
          model: MODELS[PROVIDERS.GEMINI].stt
        },
        audio: {
          content: audioBuffer.toString('base64')
        }
      })
    });

    const data = await response.json();
    return {
      text: data.results?.map(r => r.alternatives[0].transcript).join(' ') || '',
      confidence: data.results?.[0]?.alternatives[0]?.confidence,
      provider: PROVIDERS.GEMINI
    };
  }

  async transcribeOpenAI(audioBuffer, language) {
    const { apiKey, baseURL } = this.providers[PROVIDERS.OPENAI];
    
    const formData = new FormData();
    formData.append('file', new Blob([audioBuffer]), 'audio.mp3');
    formData.append('model', MODELS[PROVIDERS.OPENAI].stt);
    formData.append('language', language);

    const response = await fetch(`${baseURL}/audio/transcriptions`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`
      },
      body: formData
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(`OpenAI Transcription error: ${error.error?.message}`);
    }

    const data = await response.json();
    return {
      text: data.text,
      provider: PROVIDERS.OPENAI
    };
  }

  /**
   * Text-to-Speech (Synthesis)
   */
  async synthesize(provider, { text, voice, speed = 1.0 }) {
    switch (provider) {
      case PROVIDERS.GEMINI:
        return this.synthesizeGemini(text, voice, speed);
      
      case PROVIDERS.OPENAI:
        return this.synthesizeOpenAI(text, voice, speed);
      
      default:
        throw new Error(`TTS not supported for provider: ${provider}`);
    }
  }

  async synthesizeGemini(text, voice, speed) {
    // Google Cloud Text-to-Speech integration
    const { apiKey } = this.providers[PROVIDERS.GEMINI];
    
    const response = await fetch('https://texttospeech.googleapis.com/v1/text:synthesize', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        input: { text },
        voice: {
          languageCode: 'en-US',
          name: voice || MODELS[PROVIDERS.GEMINI].tts
        },
        audioConfig: {
          audioEncoding: 'MP3',
          speakingRate: speed
        }
      })
    });

    const data = await response.json();
    return {
      audioContent: data.audioContent,
      provider: PROVIDERS.GEMINI
    };
  }

  async synthesizeOpenAI(text, voice, speed) {
    const { apiKey, baseURL } = this.providers[PROVIDERS.OPENAI];
    
    const response = await fetch(`${baseURL}/audio/speech`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: MODELS[PROVIDERS.OPENAI].tts,
        input: text,
        voice: voice || 'alloy',
        speed
      })
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(`OpenAI TTS error: ${error.error?.message}`);
    }

    const audioBuffer = await response.arrayBuffer();
    return {
      audioContent: Buffer.from(audioBuffer).toString('base64'),
      provider: PROVIDERS.OPENAI
    };
  }

  // Message format converters
  convertMessagesToGemini(messages) {
    return messages.map(msg => ({
      role: msg.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: msg.content }]
    }));
  }

  convertMessagesToOpenAI(messages) {
    return messages;
  }

  convertMessagesToAnthropic(messages) {
    return messages.map(msg => ({
      role: msg.role,
      content: msg.content
    }));
  }

  // Stream handlers
  async *streamGeminiResponse(result) {
    for await (const chunk of result.stream) {
      const text = chunk.text();
      yield { text, done: false };
    }
    yield { done: true };
  }

  async *streamOpenAIResponse(response) {
    const reader = response.body.getReader();
    const decoder = new TextDecoder();

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      const chunk = decoder.decode(value);
      const lines = chunk.split('\n').filter(line => line.trim() !== '');

      for (const line of lines) {
        if (line.startsWith('data: ')) {
          const data = line.slice(6);
          if (data === '[DONE]') {
            yield { done: true };
            return;
          }
          try {
            const parsed = JSON.parse(data);
            const text = parsed.choices[0]?.delta?.content || '';
            if (text) yield { text, done: false };
          } catch (e) {
            // Skip malformed JSON
          }
        }
      }
    }
  }

  async *streamAnthropicResponse(stream) {
    for await (const event of stream) {
      if (event.type === 'content_block_delta') {
        yield { text: event.delta.text, done: false };
      }
      if (event.type === 'message_stop') {
        yield { done: true };
      }
    }
  }

  /**
   * Get available providers status
   */
  getProvidersStatus() {
    return Object.keys(this.providers).map(provider => ({
      provider,
      available: !!this.providers[provider],
      models: MODELS[provider]
    }));
  }
}

// Export singleton instance
module.exports = new AIProviderService();
