/**
 * 🔔 Notification Service
 * Handle push notifications, emails, and in-app notifications
 */

const nodemailer = require('nodemailer');
const { EventEmitter } = require('events');

class NotificationService extends EventEmitter {
  constructor() {
    super();
    this.emailTransporter = null;
    this.pushNotifications = new Map();
    this.templates = new Map();

    try {
      this.initializeEmailService();
      this.loadNotificationTemplates();
    } catch (error) {
      console.warn(
        '⚠️ Notification service initialization encountered an error, but continuing:',
        error.message
      );
    }
  }

  /**
   * Initialize email service
   */
  async initializeEmailService() {
    try {
      if (process.env.SENDGRID_API_KEY) {
        // SendGrid configuration
        this.emailTransporter = nodemailer.createTransport({
          service: 'SendGrid',
          auth: {
            user: 'apikey',
            pass: process.env.SENDGRID_API_KEY,
          },
        });
      } else if (process.env.SMTP_HOST) {
        // SMTP configuration
        this.emailTransporter = nodemailer.createTransport({
          host: process.env.SMTP_HOST,
          port: parseInt(process.env.SMTP_PORT) || 587,
          secure: process.env.SMTP_SECURE === 'true',
          auth: {
            user: process.env.SMTP_USER,
            pass: process.env.SMTP_PASS,
          },
        });
      }

      if (this.emailTransporter) {
        try {
          await this.emailTransporter.verify();
          console.log('✅ Email service initialized successfully');
        } catch (verifyError) {
          console.warn(
            '⚠️ Email service verification failed, but continuing:',
            verifyError.message
          );
          // Don't throw error - allow server to continue running
        }
      }
    } catch (error) {
      console.error('Email service initialization failed:', error);
    }
  }

  /**
   * Load notification templates
   */
  loadNotificationTemplates() {
    this.templates.set('welcome', {
      email: {
        subject: 'Welcome to iAMAI Global! 🎉',
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h1 style="color: #2563eb;">Welcome to iAMAI Global!</h1>
            <p>Hi {{name}},</p>
            <p>Thank you for joining iAMAI Global. You're now part of our AI-powered community!</p>
            <div style="background: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
              <h3>Get Started:</h3>
              <ul>
                <li>Complete your profile setup</li>
                <li>Explore our AI agents</li>
                <li>Join the community discussions</li>
              </ul>
            </div>
            <a href="{{dashboardUrl}}" style="background: #2563eb; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
              Go to Dashboard
            </a>
            <p style="margin-top: 30px; color: #64748b; font-size: 14px;">
              Best regards,<br>The iAMAI Global Team
            </p>
          </div>
        `,
      },
      push: {
        title: 'Welcome to iAMAI Global! 🎉',
        body: 'Start exploring AI agents and join our community!',
        icon: '/icons/welcome.png',
      },
    });

    this.templates.set('agent_response', {
      push: {
        title: '{{agentName}} responded',
        body: '{{preview}}',
        icon: '/icons/agent-{{agentType}}.png',
        actions: [
          { action: 'view', title: 'View Response' },
          { action: 'reply', title: 'Reply' },
        ],
      },
    });

    this.templates.set('subscription_expired', {
      email: {
        subject: 'Your iAMAI Global subscription has expired',
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h1 style="color: #dc2626;">Subscription Expired</h1>
            <p>Hi {{name}},</p>
            <p>Your iAMAI Global subscription has expired. Renew now to continue enjoying premium features!</p>
            <div style="background: #fef2f2; border: 1px solid #fecaca; padding: 20px; border-radius: 8px; margin: 20px 0;">
              <h3 style="color: #dc2626;">What you're missing:</h3>
              <ul>
                <li>Unlimited AI agent interactions</li>
                <li>Priority support</li>
                <li>Advanced analytics</li>
                <li>Premium agent types</li>
              </ul>
            </div>
            <a href="{{renewUrl}}" style="background: #dc2626; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
              Renew Subscription
            </a>
          </div>
        `,
      },
      push: {
        title: 'Subscription Expired',
        body: 'Renew now to continue using premium features',
        icon: '/icons/subscription.png',
      },
    });
  }

  /**
   * Send notification
   */
  async sendNotification(userId, type, templateId, data = {}, options = {}) {
    try {
      const template = this.templates.get(templateId);
      if (!template) {
        throw new Error(`Template ${templateId} not found`);
      }

      const results = {};

      // Send email notification
      if (type.includes('email') && template.email && this.emailTransporter) {
        results.email = await this.sendEmail(userId, template.email, data);
      }

      // Send push notification
      if (type.includes('push') && template.push) {
        results.push = await this.sendPushNotification(userId, template.push, data);
      }

      // Send in-app notification
      if (type.includes('app')) {
        results.app = await this.sendInAppNotification(userId, templateId, data);
      }

      // Log notification
      await this.logNotification(userId, type, templateId, data, results);

      return results;
    } catch (error) {
      console.error('Send notification error:', error);
      throw error;
    }
  }

  /**
   * Send email notification
   */
  async sendEmail(userId, template, data) {
    try {
      const User = require('../models').User;
      const user = await User.findById(userId);

      if (!user || !user.email) {
        throw new Error('User email not found');
      }

      const subject = this.processTemplate(template.subject, { ...data, name: user.name });
      const html = this.processTemplate(template.html, {
        ...data,
        name: user.name,
        dashboardUrl: `${process.env.APP_URL}/dashboard`,
        renewUrl: `${process.env.APP_URL}/subscription/renew`,
      });

      const mailOptions = {
        from: process.env.DEFAULT_FROM_EMAIL || 'noreply@iamai.global',
        to: user.email,
        subject,
        html,
      };

      const result = await this.emailTransporter.sendMail(mailOptions);

      console.log('Email sent:', result.messageId);
      return { success: true, messageId: result.messageId };
    } catch (error) {
      console.error('Send email error:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Send push notification
   */
  async sendPushNotification(userId, template, data) {
    try {
      // This would integrate with a push notification service like FCM
      // For now, we'll store the notification for WebSocket delivery

      const notification = {
        userId,
        title: this.processTemplate(template.title, data),
        body: this.processTemplate(template.body, data),
        icon: this.processTemplate(template.icon, data),
        actions: template.actions,
        timestamp: new Date(),
      };

      // Store for WebSocket delivery
      this.pushNotifications.set(`${userId}_${Date.now()}`, notification);

      // Emit event for real-time delivery
      this.emit('pushNotification', notification);

      console.log('Push notification queued for user:', userId);
      return { success: true, notification };
    } catch (error) {
      console.error('Send push notification error:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Send in-app notification
   */
  async sendInAppNotification(userId, templateId, data) {
    try {
      const Notification = require('../models').Notification;

      const notification = new Notification({
        userId,
        type: 'in_app',
        templateId,
        data,
        read: false,
        createdAt: new Date(),
      });

      await notification.save();

      // Emit event for real-time delivery
      this.emit('inAppNotification', {
        userId,
        notification: notification.toObject(),
      });

      return { success: true, notificationId: notification._id };
    } catch (error) {
      console.error('Send in-app notification error:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Get user notifications
   */
  async getUserNotifications(userId, options = {}) {
    try {
      const Notification = require('../models').Notification;

      const query = { userId };
      if (options.unreadOnly) {
        query.read = false;
      }

      const notifications = await Notification.find(query)
        .sort({ createdAt: -1 })
        .limit(options.limit || 50)
        .lean();

      return notifications;
    } catch (error) {
      console.error('Get user notifications error:', error);
      throw error;
    }
  }

  /**
   * Mark notification as read
   */
  async markAsRead(userId, notificationId) {
    try {
      const Notification = require('../models').Notification;

      await Notification.updateOne(
        { _id: notificationId, userId },
        { read: true, readAt: new Date() }
      );

      return { success: true };
    } catch (error) {
      console.error('Mark as read error:', error);
      throw error;
    }
  }

  /**
   * Mark all notifications as read
   */
  async markAllAsRead(userId) {
    try {
      const Notification = require('../models').Notification;

      const result = await Notification.updateMany(
        { userId, read: false },
        { read: true, readAt: new Date() }
      );

      return { success: true, modifiedCount: result.modifiedCount };
    } catch (error) {
      console.error('Mark all as read error:', error);
      throw error;
    }
  }

  /**
   * Get notification preferences
   */
  async getNotificationPreferences(userId) {
    try {
      const User = require('../models').User;
      const user = await User.findById(userId).select('notificationPreferences');

      return (
        user?.notificationPreferences || {
          email: true,
          push: true,
          app: true,
          marketing: false,
        }
      );
    } catch (error) {
      console.error('Get notification preferences error:', error);
      throw error;
    }
  }

  /**
   * Update notification preferences
   */
  async updateNotificationPreferences(userId, preferences) {
    try {
      const User = require('../models').User;

      await User.updateOne({ _id: userId }, { notificationPreferences: preferences });

      return { success: true };
    } catch (error) {
      console.error('Update notification preferences error:', error);
      throw error;
    }
  }

  /**
   * Process template with data
   */
  processTemplate(template, data) {
    let processed = template;

    Object.keys(data).forEach(key => {
      const regex = new RegExp(`{{${key}}}`, 'g');
      processed = processed.replace(regex, data[key] || '');
    });

    return processed;
  }

  /**
   * Log notification
   */
  async logNotification(userId, type, templateId, data, results) {
    try {
      const NotificationLog = require('../models').NotificationLog;

      const log = new NotificationLog({
        userId,
        type,
        templateId,
        data,
        results,
        createdAt: new Date(),
      });

      await log.save();
    } catch (error) {
      console.error('Log notification error:', error);
    }
  }

  /**
   * Get pending push notifications
   */
  getPendingPushNotifications(userId) {
    const notifications = [];

    for (const [key, notification] of this.pushNotifications.entries()) {
      if (notification.userId.toString() === userId.toString()) {
        notifications.push(notification);
        this.pushNotifications.delete(key);
      }
    }

    return notifications;
  }
}

module.exports = new NotificationService();
