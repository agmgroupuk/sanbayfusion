/**
 * 📊 Analytics Service
 * Backend analytics processing and data aggregation
 */

const mongoose = require('mongoose');
const { EventEmitter } = require('events');

class AnalyticsService extends EventEmitter {
  constructor() {
    super();
    this.eventQueue = [];
    this.isProcessing = false;
    this.batchSize = 100;
    this.flushInterval = 30000; // 30 seconds

    this.startBatchProcessor();
  }

  /**
   * Track user event
   */
  async trackEvent(userId, eventName, properties = {}) {
    try {
      const event = {
        userId,
        eventName,
        properties: {
          ...properties,
          timestamp: new Date(),
          sessionId: properties.sessionId || this.generateSessionId(),
        },
        createdAt: new Date(),
      };

      // Add to queue for batch processing
      this.eventQueue.push(event);

      // Emit event for real-time processing
      this.emit('event', event);

      // Process immediately if queue is full
      if (this.eventQueue.length >= this.batchSize) {
        this.processBatch();
      }

      return event;
    } catch (error) {
      console.error('Analytics tracking error:', error);
      throw error;
    }
  }

  /**
   * Track page view
   */
  async trackPageView(userId, page, properties = {}) {
    return this.trackEvent(userId, 'page_view', {
      page,
      ...properties,
    });
  }

  /**
   * Track user action
   */
  async trackUserAction(userId, action, target, properties = {}) {
    return this.trackEvent(userId, 'user_action', {
      action,
      target,
      ...properties,
    });
  }

  /**
   * Track AI agent interaction
   */
  async trackAgentInteraction(userId, agentType, action, properties = {}) {
    return this.trackEvent(userId, 'agent_interaction', {
      agentType,
      action,
      duration: properties.duration,
      tokensUsed: properties.tokensUsed,
      model: properties.model,
      ...properties,
    });
  }

  /**
   * Track subscription events
   */
  async trackSubscriptionEvent(userId, event, planId, properties = {}) {
    return this.trackEvent(userId, 'subscription_event', {
      subscriptionEvent: event,
      planId,
      amount: properties.amount,
      currency: properties.currency,
      ...properties,
    });
  }

  /**
   * Track error events
   */
  async trackError(userId, error, context = {}) {
    return this.trackEvent(userId, 'error', {
      errorMessage: error.message,
      errorStack: error.stack,
      errorCode: error.code,
      ...context,
    });
  }

  /**
   * Get user analytics
   */
  async getUserAnalytics(userId, dateRange = {}) {
    try {
      const { startDate, endDate } = this.parseDateRange(dateRange);

      const Analytics = mongoose.model('Analytics');

      const pipeline = [
        {
          $match: {
            userId: new mongoose.Types.ObjectId(userId),
            createdAt: {
              $gte: startDate,
              $lte: endDate,
            },
          },
        },
        {
          $group: {
            _id: '$eventName',
            count: { $sum: 1 },
            firstEvent: { $min: '$createdAt' },
            lastEvent: { $max: '$createdAt' },
            properties: { $push: '$properties' },
          },
        },
        {
          $sort: { count: -1 },
        },
      ];

      const events = await Analytics.aggregate(pipeline);

      // Get session analytics
      const sessionStats = await this.getSessionAnalytics(userId, dateRange);

      // Get agent usage analytics
      const agentStats = await this.getAgentAnalytics(userId, dateRange);

      return {
        events,
        sessions: sessionStats,
        agents: agentStats,
        dateRange: { startDate, endDate },
      };
    } catch (error) {
      console.error('Get user analytics error:', error);
      throw error;
    }
  }

  /**
   * Get session analytics
   */
  async getSessionAnalytics(userId, dateRange = {}) {
    try {
      const { startDate, endDate } = this.parseDateRange(dateRange);

      const Analytics = mongoose.model('Analytics');

      const pipeline = [
        {
          $match: {
            userId: new mongoose.Types.ObjectId(userId),
            eventName: 'page_view',
            createdAt: {
              $gte: startDate,
              $lte: endDate,
            },
          },
        },
        {
          $group: {
            _id: '$properties.sessionId',
            pageViews: { $sum: 1 },
            startTime: { $min: '$createdAt' },
            endTime: { $max: '$createdAt' },
            pages: { $addToSet: '$properties.page' },
          },
        },
        {
          $addFields: {
            duration: {
              $subtract: ['$endTime', '$startTime'],
            },
          },
        },
        {
          $group: {
            _id: null,
            totalSessions: { $sum: 1 },
            avgDuration: { $avg: '$duration' },
            avgPageViews: { $avg: '$pageViews' },
            totalPageViews: { $sum: '$pageViews' },
          },
        },
      ];

      const result = await Analytics.aggregate(pipeline);
      return (
        result[0] || {
          totalSessions: 0,
          avgDuration: 0,
          avgPageViews: 0,
          totalPageViews: 0,
        }
      );
    } catch (error) {
      console.error('Get session analytics error:', error);
      throw error;
    }
  }

  /**
   * Get agent usage analytics
   */
  async getAgentAnalytics(userId, dateRange = {}) {
    try {
      const { startDate, endDate } = this.parseDateRange(dateRange);

      const Analytics = mongoose.model('Analytics');

      const pipeline = [
        {
          $match: {
            userId: new mongoose.Types.ObjectId(userId),
            eventName: 'agent_interaction',
            createdAt: {
              $gte: startDate,
              $lte: endDate,
            },
          },
        },
        {
          $group: {
            _id: '$properties.agentType',
            interactions: { $sum: 1 },
            totalTokens: { $sum: '$properties.tokensUsed' },
            avgDuration: { $avg: '$properties.duration' },
            models: { $addToSet: '$properties.model' },
          },
        },
        {
          $sort: { interactions: -1 },
        },
      ];

      return await Analytics.aggregate(pipeline);
    } catch (error) {
      console.error('Get agent analytics error:', error);
      throw error;
    }
  }

  /**
   * Get system-wide analytics (admin only)
   */
  async getSystemAnalytics(dateRange = {}) {
    try {
      const { startDate, endDate } = this.parseDateRange(dateRange);

      const Analytics = mongoose.model('Analytics');

      // Daily active users
      const dauPipeline = [
        {
          $match: {
            createdAt: {
              $gte: startDate,
              $lte: endDate,
            },
          },
        },
        {
          $group: {
            _id: {
              date: { $dateToString: { format: '%Y-%m-%d', date: '$createdAt' } },
              userId: '$userId',
            },
          },
        },
        {
          $group: {
            _id: '$_id.date',
            activeUsers: { $sum: 1 },
          },
        },
        {
          $sort: { _id: 1 },
        },
      ];

      // Event breakdown
      const eventsPipeline = [
        {
          $match: {
            createdAt: {
              $gte: startDate,
              $lte: endDate,
            },
          },
        },
        {
          $group: {
            _id: '$eventName',
            count: { $sum: 1 },
            uniqueUsers: { $addToSet: '$userId' },
          },
        },
        {
          $addFields: {
            uniqueUsers: { $size: '$uniqueUsers' },
          },
        },
        {
          $sort: { count: -1 },
        },
      ];

      const [dailyActiveUsers, eventBreakdown] = await Promise.all([
        Analytics.aggregate(dauPipeline),
        Analytics.aggregate(eventsPipeline),
      ]);

      return {
        dailyActiveUsers,
        eventBreakdown,
        dateRange: { startDate, endDate },
      };
    } catch (error) {
      console.error('Get system analytics error:', error);
      throw error;
    }
  }

  /**
   * Start batch processor
   */
  startBatchProcessor() {
    setInterval(() => {
      if (this.eventQueue.length > 0) {
        this.processBatch();
      }
    }, this.flushInterval);
  }

  /**
   * Process event batch
   */
  async processBatch() {
    if (this.isProcessing || this.eventQueue.length === 0) {
      return;
    }

    this.isProcessing = true;

    try {
      const events = this.eventQueue.splice(0, this.batchSize);
      const Analytics = mongoose.model('Analytics');

      await Analytics.insertMany(events);

      console.log(`Processed ${events.length} analytics events`);
    } catch (error) {
      console.error('Batch processing error:', error);
    } finally {
      this.isProcessing = false;
    }
  }

  /**
   * Parse date range
   */
  parseDateRange(dateRange) {
    const endDate = dateRange.endDate || new Date();
    const startDate = dateRange.startDate || new Date(endDate.getTime() - 30 * 24 * 60 * 60 * 1000); // 30 days ago

    return { startDate, endDate };
  }

  /**
   * Generate session ID
   */
  generateSessionId() {
    return `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }
}

module.exports = new AnalyticsService();
