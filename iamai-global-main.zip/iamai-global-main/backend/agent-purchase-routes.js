/**
 * Agent Purchase Routes - One-Time Payment System
 * Handles purchase, access check, cancellation, and listing of agent purchases
 */

const express = require('express');
const router = express.Router();
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const { AgentPurchase } = require('./agent-purchase-models');
const { User } = require('./models.cjs');
const { authenticate } = require('./auth-middleware');

// Helper to get current authenticated user ID from JWT or legacy session
const getUserId = req => req.userId || req.session?.userId;

// Agent ID alias mapping - maps frontend shorthand IDs to Stripe price key names
const AGENT_ID_ALIASES = {
  nerd: 'nerdyneil',
  cool: 'coolkyle',
  zen: 'zenmasterzara',
  gamer: 'gamergary',
  lazy: 'lazylarry',
  flirty: 'flirtyfiona',
  sassy: 'sassysarah',
  comedy: 'comedychad',
  girlfriend: 'aigirlfriend',
  emo: 'emoai',
};

/**
 * POST /api/agents/:agentId/purchase
 * Create a Stripe Checkout session for one-time payment
 */
router.post('/:agentId/purchase', authenticate, async (req, res) => {
  const startTime = Date.now();
  console.log(`🚀 PURCHASE REQUEST STARTED - ${new Date().toISOString()}`);
  console.log(
    `🔄 Purchase request started for agent: ${req.params.agentId}, plan: ${req.body.planType}`
  );
  console.log(`🔄 Request headers:`, JSON.stringify(req.headers, null, 2));
  console.log(`🔄 Request body:`, JSON.stringify(req.body, null, 2));
  console.log(`🔄 Request user:`, req.userId || req.session?.userId);
  console.log(`✅ AUTHENTICATION PASSED - ${new Date().toISOString()}`);

  try {
    const { agentId } = req.params;
    const { planType } = req.body; // daily, weekly, monthly
    const userId = getUserId(req);

    console.log(`👤 User ID: ${userId}, Agent: ${agentId}, Plan: ${planType}`);

    // Validate plan type
    if (!['daily', 'weekly', 'monthly'].includes(planType?.toLowerCase())) {
      console.log(`❌ Invalid plan type: ${planType}`);
      return res
        .status(400)
        .json({ error: 'Invalid plan type. Must be daily, weekly, or monthly.' });
    }

    // Normalize agent ID
    const normalizedAgentId = agentId.toLowerCase();
    console.log(`🔄 Normalized agent ID: ${normalizedAgentId}`);

    // Resolve alias to canonical agent ID for Stripe pricing lookup
    const canonicalAgentId = AGENT_ID_ALIASES[normalizedAgentId] || normalizedAgentId;
    console.log(`🔄 Canonical agent ID: ${canonicalAgentId}`);

    // Check if user already has active access (check both alias and canonical)
    console.log(`🔍 Checking active access for user ${userId}...`);
    const startActiveCheck = Date.now();
    const hasActive =
      (await AgentPurchase.hasActiveAccess(userId, normalizedAgentId)) ||
      (await AgentPurchase.hasActiveAccess(userId, canonicalAgentId));
    const endActiveCheck = Date.now();
    console.log(
      `🔍 Active access check completed in ${endActiveCheck - startActiveCheck}ms, result: ${hasActive}`
    );

    if (hasActive) {
      console.log(`❌ User already has active access`);
      return res.status(400).json({
        error:
          'You already have active access to this agent. Please wait for it to expire or cancel it first.',
      });
    }

    // Get Stripe price ID from environment
    const agentKeyBase = canonicalAgentId.replace(/[^a-z0-9]/gi, '').toUpperCase();
    const planKey = planType.toUpperCase();

    const agentPriceEnvKey = `STRIPE_PRICE_${agentKeyBase}_${planKey}`;
    const genericPriceEnvKey = `STRIPE_PRICE_${planKey}`;

    const priceId = process.env[agentPriceEnvKey] || process.env[genericPriceEnvKey] || null;

    console.log(
      `💰 Price ID lookup: ${agentPriceEnvKey} -> ${process.env[agentPriceEnvKey]}, ${genericPriceEnvKey} -> ${process.env[genericPriceEnvKey]}, selected: ${priceId}`
    );

    if (!priceId) {
      console.error(
        `Missing price ID: tried ${agentPriceEnvKey} and ${genericPriceEnvKey} for agent ${normalizedAgentId}`
      );
      return res.status(500).json({ error: 'Price configuration not found' });
    }

    // Create Stripe Checkout Session
    console.log(`💳 Creating Stripe checkout session...`);
    const stripeStartTime = Date.now();
    const session = await stripe.checkout.sessions.create({
      mode: 'payment', // One-time payment (NOT subscription)
      payment_method_types: ['card'],
      line_items: [
        {
          price: priceId,
          quantity: 1,
        },
      ],
      success_url: `${process.env.FRONTEND_BASE_URL}/thank-you?agent=${normalizedAgentId}&plan=${planType.toLowerCase()}`,
      cancel_url: `${process.env.FRONTEND_BASE_URL}/agents/${agentId}?purchase=cancelled`,
      client_reference_id: userId.toString(),
      metadata: {
        userId: userId.toString(),
        agentId: normalizedAgentId,
        planType: planType.toLowerCase(),
      },
    });

    const stripeEndTime = Date.now();
    console.log(
      `💳 Stripe session created in ${stripeEndTime - stripeStartTime}ms, session ID: ${session.id}`
    );

    // Create PENDING purchase record immediately (will be updated to ACTIVE by webhook)
    console.log(`💾 Creating pending purchase record...`);
    const dbStartTime = Date.now();
    console.log(`👤 Looking up user ${userId}...`);
    const userLookupStart = Date.now();
    const user = await User.findById(userId).maxTimeMS(10000);
    const userLookupEnd = Date.now();
    console.log(
      `👤 User lookup completed in ${userLookupEnd - userLookupStart}ms, found: ${!!user}`
    );
    const normalizedPlan = planType.toUpperCase();
    const purchaseDate = new Date();
    const expiresAt = AgentPurchase.calculateExpiration(normalizedPlan, purchaseDate);
    const planConfig = AgentPurchase.getPlanConfig(normalizedPlan);

    const pendingPurchase = new AgentPurchase({
      userId,
      email: user?.email || '',
      agentId: normalizedAgentId,
      agentName: normalizedAgentId,
      plan: normalizedPlan,
      planName: planConfig?.name,
      pricing: {
        amount: planConfig?.amount ?? 0,
        currency: 'USD',
      },
      purchaseDate,
      expiresAt,
      stripeCheckoutSessionId: session.id,
      stripePaymentIntentId: session.payment_intent, // Actual payment intent ID from Stripe
      paymentMethod: 'CARD',
      paymentStatus: 'PENDING',
      status: 'PENDING', // Will be updated to ACTIVE by webhook
      metadata: {
        userId: userId.toString(),
        agentId: normalizedAgentId,
        planType: planType.toLowerCase(),
        source: 'checkout_initiated',
      },
    });

    await pendingPurchase.save();
    const dbEndTime = Date.now();
    console.log(`💾 Purchase record saved in ${dbEndTime - dbStartTime}ms`);

    const endTime = Date.now();
    console.log(`✅ Purchase request completed in ${endTime - startTime}ms`);

    res.json({
      sessionId: session.id,
      url: session.url,
      purchaseId: pendingPurchase._id,
    });
  } catch (error) {
    console.error('Purchase endpoint error:', {
      message: error.message,
      type: error.type,
      code: error.code,
      param: error.param,
      agentId: req.params.agentId,
      planType: req.body.planType,
      priceId: priceId,
      userId: getUserId(req),
    });
    res.status(500).json({ error: 'Failed to create checkout session', details: error.message });
  }
});

/**
 * GET /api/agents/:agentId/access
 * Check if user has active access to an agent
 */
router.get('/:agentId/access', authenticate, async (req, res) => {
  try {
    const { agentId } = req.params;
    const userId = getUserId(req);
    const normalizedAgentId = agentId.toLowerCase();

    const purchase = await AgentPurchase.findActivePurchase(userId, normalizedAgentId);

    if (!purchase) {
      return res.json({
        hasAccess: false,
        message: 'No active access found',
      });
    }

    const now = new Date();
    const end = purchase.expiresAt || purchase.expirationDate;
    const daysRemaining = end
      ? Math.max(0, Math.ceil((end.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)))
      : 0;

    res.json({
      hasAccess: true,
      purchase: {
        id: purchase._id,
        agentId: purchase.agentId,
        plan: purchase.plan || purchase.planType,
        purchaseDate: purchase.purchaseDate,
        expirationDate: end,
        daysRemaining,
        status: purchase.status,
      },
    });
  } catch (error) {
    console.error('Access check error:', error);
    res.status(500).json({ error: 'Failed to check access' });
  }
});

/**
 * POST /api/agents/:agentId/cancel
 * Cancel active access (sets expiration to now)
 */
router.post('/:agentId/cancel', authenticate, async (req, res) => {
  try {
    const { agentId } = req.params;
    const { reason } = req.body;
    const userId = getUserId(req);
    const normalizedAgentId = agentId.toLowerCase();

    const purchase = await AgentPurchase.findActivePurchase(userId, normalizedAgentId);

    if (!purchase) {
      return res.status(404).json({ error: 'No active purchase found' });
    }

    // Cancel the purchase (expires immediately)
    purchase.cancelReason = reason || 'User requested cancellation';

    // Ensure email and agentName are populated for validation
    if (!purchase.email && userId) {
      const User = require('./models.cjs').User;
      const user = await User.findById(userId);
      if (user) purchase.email = user.email;
    }
    if (!purchase.agentName && purchase.agentId) {
      purchase.agentName = purchase.agentId;
    }

    const cancelledPurchase = await purchase.cancel();

    res.json({
      success: true,
      message: 'Access cancelled successfully',
      purchase: {
        id: cancelledPurchase._id,
        status: cancelledPurchase.status,
        cancelledAt: cancelledPurchase.cancelledAt,
      },
    });
  } catch (error) {
    console.error('Cancel endpoint error:', error);
    console.error('Error details:', {
      message: error.message,
      stack: error.stack,
      validation: error.errors,
    });
    res.status(500).json({
      error: 'Failed to cancel access',
      details: error.message,
    });
  }
});

/**
 * GET /api/purchases/my-purchases
 * List all purchases for the authenticated user
 */
router.get('/my-purchases', authenticate, async (req, res) => {
  try {
    const userId = getUserId(req);
    const { status, limit = 50, skip = 0 } = req.query;

    const query = { userId };
    if (status) {
      query.status = status;
    }

    const purchases = await AgentPurchase.find(query)
      .sort({ purchaseDate: -1 })
      .limit(parseInt(limit))
      .skip(parseInt(skip))
      .lean();

    // Add computed fields
    const enrichedPurchases = purchases.map(purchase => {
      const now = new Date();
      const msRemaining = purchase.expirationDate - now;
      const daysRemaining = Math.max(0, Math.ceil(msRemaining / (1000 * 60 * 60 * 24)));

      return {
        ...purchase,
        daysRemaining,
        isActive: purchase.status === 'active' && purchase.expirationDate > now,
      };
    });

    const total = await AgentPurchase.countDocuments(query);

    res.json({
      purchases: enrichedPurchases,
      total,
      hasMore: total > parseInt(skip) + enrichedPurchases.length,
    });
  } catch (error) {
    console.error('List purchases error:', error);
    res.status(500).json({ error: 'Failed to fetch purchases' });
  }
});

module.exports = router;
