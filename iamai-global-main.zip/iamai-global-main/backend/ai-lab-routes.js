// AI Lab API Routes - Comprehensive Routes for Subscription-Gated AI Lab System
// All 17 AI lab tools with complete data tracking and subscription validation

const express = require('express');
const router = express.Router();
const axios = require('axios');
const crypto = require('crypto');
const { v4: uuidv4 } = require('uuid');

// Import models and middleware
const { 
  AILabAccess, 
  AILabExperiment, 
  AILabUsageAnalytics, 
  AILabTemplate, 
  AILabModelBenchmark, 
  AILabSettings 
} = require('./ai-lab-models');

const { 
  validateSubscription, 
  requireFeatureAccess, 
  trackUsage,
  activateSubscription,
  deactivateSubscription 
} = require('./ai-lab-auth');

// Import AI service
const AIService = require('./services/comprehensiveAIService');

// ============================================
// AI LAB DASHBOARD & ACCESS
// ============================================

// Get AI Lab dashboard with subscription status
router.get('/dashboard', validateSubscription, async (req, res) => {
  try {
    const { userId, labAccess } = req;

    // Get recent experiments
    const recentExperiments = await AILabExperiment
      .find({ userId })
      .sort({ createdAt: -1 })
      .limit(10)
      .select('experimentId experiment.type experiment.title results metadata createdAt');

    // Get usage analytics for the last 30 days
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

    const usageStats = await AILabUsageAnalytics.aggregate([
      {
        $match: {
          userId: userId,
          'usage.date': { $gte: thirtyDaysAgo }
        }
      },
      {
        $group: {
          _id: null,
          totalExperiments: { $sum: '$usage.experimentsCount' },
          totalTokens: { $sum: '$usage.totalTokens' },
          totalCost: { $sum: '$usage.totalCost' },
          avgSessionDuration: { $avg: '$usage.sessionDuration' }
        }
      }
    ]);

    // Get popular templates
    const popularTemplates = await AILabTemplate
      .find({ 'sharing.isPublic': true })
      .sort({ 'sharing.usageCount': -1 })
      .limit(5)
      .select('templateId template.title template.description template.category sharing.rating');

    res.json({
      success: true,
      dashboard: {
        subscription: labAccess.subscriptionStatus,
        permissions: labAccess.permissions,
        usage: labAccess.usage,
        recentExperiments,
        usageStats: usageStats[0] || {
          totalExperiments: 0,
          totalTokens: 0,
          totalCost: 0,
          avgSessionDuration: 0
        },
        popularTemplates
      }
    });

  } catch (error) {
    console.error('Dashboard error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to load dashboard'
    });
  }
});

// ============================================
// SIMPLE AI GENERATION
// ============================================

// Simple AI generation endpoint for AILabPage
router.post('/generate', 
  validateSubscription, 
  requireFeatureAccess('playground'),
  trackUsage('aiGeneration'),
  async (req, res) => {
    try {
      const { userId } = req;
      const { prompt, model = 'gpt-3.5-turbo', temperature = 0.7, maxTokens = 2048 } = req.body;

      if (!prompt || !prompt.trim()) {
        return res.status(400).json({
          success: false,
          error: 'Prompt is required'
        });
      }

      // Create a simple model object for callModelAPI
      const modelObj = {
        id: model,
        name: getModelDisplayName(model),
        provider: getModelProvider(model)
      };

      const startTime = Date.now();
      
      // Generate response using AI service
      const result = await callModelAPI(modelObj, prompt, { temperature, maxTokens });
      
      const endTime = Date.now();
      const totalTime = endTime - startTime;

      // Calculate cost
      const cost = calculateCost(model, result.tokens);

      // Create test result record
      const testResult = {
        id: uuidv4(),
        timestamp: Date.now(),
        tool: 'text-generation',
        prompt: prompt,
        response: result.response,
        model: model,
        tokens: result.tokens.total,
        duration: totalTime,
        cost: parseFloat(cost.toFixed(4))
      };

      // Save to experiment log (optional, for analytics)
      try {
        const experiment = new AILabExperiment({
          userId,
          experimentId: `simple-gen-${uuidv4()}`,
          experiment: {
            type: 'simple-generation',
            title: 'Simple AI Generation',
            description: 'Single prompt AI generation',
            category: 'core'
          },
          input: {
            prompt,
            models: [modelObj],
            configuration: { temperature, maxTokens }
          },
          results: [{
            modelId: model,
            modelName: modelObj.name,
            output: {
              response: result.response,
              tokens: result.tokens,
              cost: cost,
              latency: result.latency,
              quality: await calculateQualityScore(result.response, prompt)
            },
            timestamp: new Date(),
            status: 'completed'
          }],
          metadata: {
            duration: totalTime,
            tokens: result.tokens.total,
            cost: cost
          }
        });

        await experiment.save();
      } catch (saveError) {
        console.warn('Failed to save experiment:', saveError.message);
      }

      // Attach usage data for tracking middleware
      req.tokensUsed = result.tokens.total;
      req.costIncurred = cost;
      req.modelsUsed = [modelObj.name];

      res.json({
        success: true,
        result: testResult
      });

    } catch (error) {
      console.error('AI Generation error:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to generate AI response'
      });
    }
  }
);

// ============================================
// TOOL 1: AI PLAYGROUND
// ============================================

router.post('/playground/experiment', 
  validateSubscription, 
  requireFeatureAccess('playground'),
  trackUsage('playground'),
  async (req, res) => {
    try {
      const { userId } = req;
      const { prompt, models, parameters } = req.body;

      if (!prompt || !models || models.length === 0) {
        return res.status(400).json({
          success: false,
          error: 'Prompt and at least one model are required'
        });
      }

      // Check model limit based on subscription
      const { labAccess } = req;
      if (models.length > labAccess.permissions.maxModelsPerComparison) {
        return res.status(403).json({
          success: false,
          error: `Your subscription allows comparing up to ${labAccess.permissions.maxModelsPerComparison} models`,
          code: 'MODEL_LIMIT_EXCEEDED'
        });
      }

      const experimentId = `playground-${uuidv4()}`;
      
      // Create experiment record
      const experiment = new AILabExperiment({
        userId,
        experimentId,
        experiment: {
          type: 'playground',
          title: `Playground Test - ${new Date().toISOString()}`,
          description: 'AI Playground experiment with multiple model comparison',
          category: 'core'
        },
        input: {
          prompt,
          models: models.map(m => ({
            modelId: m.id,
            modelName: m.name,
            provider: m.provider,
            parameters: { ...parameters, ...m.parameters }
          })),
          configuration: parameters
        },
        results: [],
        metadata: {
          complexity: prompt.length > 500 ? 'complex' : prompt.length > 200 ? 'moderate' : 'simple'
        }
      });

      await experiment.save();

      // Process each model
      const results = [];
      let totalTokens = 0;
      let totalCost = 0;

      for (const model of models) {
        try {
          const startTime = Date.now();
          
          // Make API call based on provider
          const modelResult = await callModelAPI(model, prompt, parameters);
          
          const endTime = Date.now();
          const latency = endTime - startTime;

          // Calculate costs (example rates - should be configurable)
          const costRates = {
            'gpt-4': { input: 0.03, output: 0.06 }, // per 1K tokens
            'gpt-3.5-turbo': { input: 0.0015, output: 0.002 },
            'claude-3-haiku': { input: 0.00025, output: 0.00125 },
            'claude-3-sonnet': { input: 0.003, output: 0.015 }
          };

          const rate = costRates[model.id] || { input: 0.001, output: 0.001 };
          const cost = (modelResult.tokens.input * rate.input + modelResult.tokens.output * rate.output) / 1000;

          totalTokens += modelResult.tokens.total;
          totalCost += cost;

          const result = {
            modelId: model.id,
            modelName: model.name,
            output: {
              response: modelResult.response,
              tokens: modelResult.tokens,
              cost: parseFloat(cost.toFixed(4)),
              latency,
              quality: await calculateQualityScore(modelResult.response, prompt)
            },
            timestamp: new Date(),
            status: 'completed'
          };

          results.push(result);

        } catch (modelError) {
          console.error(`Model ${model.id} error:`, modelError);
          results.push({
            modelId: model.id,
            modelName: model.name,
            output: null,
            timestamp: new Date(),
            status: 'failed',
            error: modelError.message
          });
        }
      }

      // Update experiment with results
      experiment.results = results;
      experiment.analysis = generateAnalysis(results);
      experiment.metadata.duration = results.reduce((acc, r) => acc + (r.output?.latency || 0), 0) / results.length;

      await experiment.save();

      // Attach usage data for tracking middleware
      req.tokensUsed = totalTokens;
      req.costIncurred = totalCost;
      req.modelsUsed = models.map(m => m.name);

      res.json({
        success: true,
        experiment: {
          id: experimentId,
          results,
          analysis: experiment.analysis,
          usage: {
            totalTokens,
            totalCost: parseFloat(totalCost.toFixed(4)),
            modelsUsed: models.length
          }
        }
      });

    } catch (error) {
      console.error('Playground experiment error:', error);
      res.status(500).json({
        success: false,
        error: 'Experiment failed'
      });
    }
  }
);

// ============================================
// TOOL 2: AI BATTLE ARENA
// ============================================

router.post('/battle-arena/battle',
  validateSubscription,
  requireFeatureAccess('battle-arena'),
  trackUsage('battleArena'),
  async (req, res) => {
    try {
      const { userId } = req;
      const { prompt, model1, model2, battleType = 'quality' } = req.body;

      if (!prompt || !model1 || !model2) {
        return res.status(400).json({
          success: false,
          error: 'Prompt and two models are required for battle'
        });
      }

      const experimentId = `battle-${uuidv4()}`;

      // Create battle experiment
      const experiment = new AILabExperiment({
        userId,
        experimentId,
        experiment: {
          type: 'battle',
          title: `AI Battle: ${model1.name} vs ${model2.name}`,
          description: `Battle arena comparing ${model1.name} and ${model2.name}`,
          category: 'advanced'
        },
        input: {
          prompt,
          models: [model1, model2],
          configuration: { battleType }
        },
        results: [],
        metadata: {
          complexity: 'moderate'
        }
      });

      // Run both models simultaneously
      const [result1, result2] = await Promise.allSettled([
        callModelAPI(model1, prompt, {}),
        callModelAPI(model2, prompt, {})
      ]);

      const battleResults = [];
      let totalTokens = 0;
      let totalCost = 0;

      // Process model 1 result
      if (result1.status === 'fulfilled') {
        const cost1 = calculateCost(model1.id, result1.value.tokens);
        totalTokens += result1.value.tokens.total;
        totalCost += cost1;

        battleResults.push({
          modelId: model1.id,
          modelName: model1.name,
          output: {
            response: result1.value.response,
            tokens: result1.value.tokens,
            cost: cost1,
            latency: result1.value.latency,
            quality: await calculateQualityScore(result1.value.response, prompt)
          },
          timestamp: new Date(),
          status: 'completed'
        });
      } else {
        battleResults.push({
          modelId: model1.id,
          modelName: model1.name,
          output: null,
          timestamp: new Date(),
          status: 'failed',
          error: result1.reason.message
        });
      }

      // Process model 2 result
      if (result2.status === 'fulfilled') {
        const cost2 = calculateCost(model2.id, result2.value.tokens);
        totalTokens += result2.value.tokens.total;
        totalCost += cost2;

        battleResults.push({
          modelId: model2.id,
          modelName: model2.name,
          output: {
            response: result2.value.response,
            tokens: result2.value.tokens,
            cost: cost2,
            latency: result2.value.latency,
            quality: await calculateQualityScore(result2.value.response, prompt)
          },
          timestamp: new Date(),
          status: 'completed'
        });
      } else {
        battleResults.push({
          modelId: model2.id,
          modelName: model2.name,
          output: null,
          timestamp: new Date(),
          status: 'failed',
          error: result2.reason.message
        });
      }

      // Determine battle winner
      const analysis = generateBattleAnalysis(battleResults, battleType);

      experiment.results = battleResults;
      experiment.analysis = analysis;
      await experiment.save();

      // Track usage
      req.tokensUsed = totalTokens;
      req.costIncurred = totalCost;
      req.modelsUsed = [model1.name, model2.name];

      res.json({
        success: true,
        battle: {
          id: experimentId,
          results: battleResults,
          winner: analysis.comparison.winner,
          analysis,
          usage: {
            totalTokens,
            totalCost: parseFloat(totalCost.toFixed(4))
          }
        }
      });

    } catch (error) {
      console.error('Battle arena error:', error);
      res.status(500).json({
        success: false,
        error: 'Battle failed'
      });
    }
  }
);

// ============================================
// TOOL 3: PROMPT ENGINEERING LAB
// ============================================

router.post('/prompt-engineering/optimize',
  validateSubscription,
  requireFeatureAccess('advanced-tools'),
  trackUsage('promptEngineering'),
  async (req, res) => {
    try {
      const { userId } = req;
      const { basePrompt, model, optimizationGoal = 'clarity' } = req.body;

      if (!basePrompt || !model) {
        return res.status(400).json({
          success: false,
          error: 'Base prompt and model are required'
        });
      }

      const experimentId = `prompt-opt-${uuidv4()}`;

      // Generate prompt variations
      const promptVariations = generatePromptVariations(basePrompt, optimizationGoal);

      const experiment = new AILabExperiment({
        userId,
        experimentId,
        experiment: {
          type: 'prompt-engineering',
          title: `Prompt Optimization - ${optimizationGoal}`,
          description: `Optimizing prompt for ${optimizationGoal}`,
          category: 'advanced'
        },
        input: {
          prompt: basePrompt,
          models: [model],
          testCases: promptVariations,
          configuration: { optimizationGoal }
        },
        results: [],
        metadata: {
          complexity: 'complex'
        }
      });

      // Test each prompt variation
      const results = [];
      let totalTokens = 0;
      let totalCost = 0;

      for (let i = 0; i < promptVariations.length; i++) {
        const variation = promptVariations[i];
        
        try {
          const modelResult = await callModelAPI(model, variation, {});
          const cost = calculateCost(model.id, modelResult.tokens);
          const quality = await calculateQualityScore(modelResult.response, variation);

          totalTokens += modelResult.tokens.total;
          totalCost += cost;

          results.push({
            variationIndex: i,
            prompt: variation,
            output: {
              response: modelResult.response,
              tokens: modelResult.tokens,
              cost,
              latency: modelResult.latency,
              quality
            },
            status: 'completed'
          });

        } catch (error) {
          results.push({
            variationIndex: i,
            prompt: variation,
            output: null,
            status: 'failed',
            error: error.message
          });
        }
      }

      // Find best performing prompt
      const bestResult = results
        .filter(r => r.status === 'completed')
        .sort((a, b) => b.output.quality.overallScore - a.output.quality.overallScore)[0];

      const analysis = {
        bestPrompt: bestResult ? bestResult.prompt : basePrompt,
        bestScore: bestResult ? bestResult.output.quality.overallScore : 0,
        improvements: generatePromptImprovements(basePrompt, bestResult),
        recommendations: generatePromptRecommendations(optimizationGoal)
      };

      experiment.results = results.map(r => ({
        modelId: model.id,
        modelName: model.name,
        output: r.output,
        timestamp: new Date(),
        status: r.status,
        error: r.error
      }));
      experiment.analysis = analysis;

      await experiment.save();

      req.tokensUsed = totalTokens;
      req.costIncurred = totalCost;
      req.modelsUsed = [model.name];

      res.json({
        success: true,
        optimization: {
          id: experimentId,
          originalPrompt: basePrompt,
          bestPrompt: analysis.bestPrompt,
          variations: results,
          analysis,
          usage: {
            totalTokens,
            totalCost: parseFloat(totalCost.toFixed(4))
          }
        }
      });

    } catch (error) {
      console.error('Prompt engineering error:', error);
      res.status(500).json({
        success: false,
        error: 'Prompt optimization failed'
      });
    }
  }
);

// ============================================
// TOOL 4: CODE PLAYGROUND
// ============================================

router.post('/code-playground/execute',
  validateSubscription,
  requireFeatureAccess('code-playground'),
  trackUsage('codePlayground'),
  async (req, res) => {
    try {
      const { userId } = req;
      const { code, language, model, task = 'explain' } = req.body;

      if (!code || !language || !model) {
        return res.status(400).json({
          success: false,
          error: 'Code, language, and model are required'
        });
      }

      const experimentId = `code-${uuidv4()}`;

      // Create code analysis prompt based on task
      const prompts = {
        explain: `Explain this ${language} code in detail:\n\n${code}`,
        optimize: `Optimize this ${language} code for better performance and readability:\n\n${code}`,
        debug: `Find and fix any bugs in this ${language} code:\n\n${code}`,
        convert: `Convert this ${language} code to Python:\n\n${code}`,
        review: `Perform a thorough code review of this ${language} code:\n\n${code}`
      };

      const prompt = prompts[task] || prompts.explain;

      const experiment = new AILabExperiment({
        userId,
        experimentId,
        experiment: {
          type: 'code-playground',
          title: `Code ${task} - ${language}`,
          description: `Code analysis and ${task} using AI`,
          category: 'tools'
        },
        input: {
          prompt,
          models: [model],
          configuration: { code, language, task }
        },
        results: [],
        metadata: {
          complexity: code.length > 1000 ? 'complex' : 'moderate'
        }
      });

      // Process with AI model
      const modelResult = await callModelAPI(model, prompt, {
        temperature: 0.1, // Lower temperature for code tasks
        max_tokens: 2000
      });

      const cost = calculateCost(model.id, modelResult.tokens);
      const quality = await calculateCodeQualityScore(modelResult.response, task);

      const result = {
        modelId: model.id,
        modelName: model.name,
        output: {
          response: modelResult.response,
          tokens: modelResult.tokens,
          cost,
          latency: modelResult.latency,
          quality
        },
        timestamp: new Date(),
        status: 'completed'
      };

      experiment.results = [result];
      experiment.analysis = {
        codeAnalysis: {
          language,
          task,
          complexity: experiment.metadata.complexity,
          suggestions: extractCodeSuggestions(modelResult.response),
          quality: quality.overallScore
        }
      };

      await experiment.save();

      req.tokensUsed = modelResult.tokens.total;
      req.costIncurred = cost;
      req.modelsUsed = [model.name];

      res.json({
        success: true,
        codeAnalysis: {
          id: experimentId,
          task,
          language,
          originalCode: code,
          analysis: modelResult.response,
          quality,
          usage: {
            tokens: modelResult.tokens.total,
            cost: parseFloat(cost.toFixed(4))
          }
        }
      });

    } catch (error) {
      console.error('Code playground error:', error);
      res.status(500).json({
        success: false,
        error: 'Code analysis failed'
      });
    }
  }
);

// ============================================
// TOOL 5: SENTIMENT ANALYSIS LAB
// ============================================

router.post('/sentiment-analysis/analyze',
  validateSubscription,
  requireFeatureAccess('playground'),
  trackUsage('sentimentAnalysis'),
  async (req, res) => {
    try {
      const { userId } = req;
      const { text, models, analysisType = 'basic' } = req.body;

      if (!text || !models || models.length === 0) {
        return res.status(400).json({
          success: false,
          error: 'Text and at least one model are required'
        });
      }

      const experimentId = `sentiment-${uuidv4()}`;

      // Create sentiment analysis prompt
      const prompts = {
        basic: `Analyze the sentiment of this text. Classify as positive, negative, or neutral and provide a confidence score:\n\n"${text}"`,
        detailed: `Perform detailed sentiment analysis on this text. Include sentiment classification, emotional tone, key themes, and confidence scores:\n\n"${text}"`,
        comparative: `Compare different aspects of sentiment in this text. Analyze overall sentiment, emotional undertones, and contextual factors:\n\n"${text}"`
      };

      const prompt = prompts[analysisType] || prompts.basic;

      const experiment = new AILabExperiment({
        userId,
        experimentId,
        experiment: {
          type: 'sentiment-analysis',
          title: `Sentiment Analysis - ${analysisType}`,
          description: 'AI-powered sentiment analysis with multiple models',
          category: 'tools'
        },
        input: {
          prompt,
          models,
          configuration: { text, analysisType }
        },
        results: [],
        metadata: {
          complexity: text.length > 500 ? 'complex' : 'simple'
        }
      });

      // Process with each model
      const results = [];
      let totalTokens = 0;
      let totalCost = 0;

      for (const model of models) {
        try {
          const modelResult = await callModelAPI(model, prompt, {
            temperature: 0.3,
            max_tokens: 500
          });

          const cost = calculateCost(model.id, modelResult.tokens);
          totalTokens += modelResult.tokens.total;
          totalCost += cost;

          // Parse sentiment from response
          const sentiment = parseSentimentResponse(modelResult.response);

          results.push({
            modelId: model.id,
            modelName: model.name,
            output: {
              response: modelResult.response,
              tokens: modelResult.tokens,
              cost,
              latency: modelResult.latency,
              sentiment
            },
            timestamp: new Date(),
            status: 'completed'
          });

        } catch (error) {
          results.push({
            modelId: model.id,
            modelName: model.name,
            output: null,
            timestamp: new Date(),
            status: 'failed',
            error: error.message
          });
        }
      }

      // Generate consensus analysis
      const consensus = generateSentimentConsensus(results);

      experiment.results = results;
      experiment.analysis = {
        consensus,
        agreementScore: calculateAgreementScore(results),
        insights: generateSentimentInsights(results, text)
      };

      await experiment.save();

      req.tokensUsed = totalTokens;
      req.costIncurred = totalCost;
      req.modelsUsed = models.map(m => m.name);

      res.json({
        success: true,
        sentimentAnalysis: {
          id: experimentId,
          text,
          analysisType,
          results,
          consensus,
          usage: {
            totalTokens,
            totalCost: parseFloat(totalCost.toFixed(4))
          }
        }
      });

    } catch (error) {
      console.error('Sentiment analysis error:', error);
      res.status(500).json({
        success: false,
        error: 'Sentiment analysis failed'
      });
    }
  }
);

// ============================================
// UTILITY FUNCTIONS
// ============================================

async function callModelAPI(model, prompt, parameters) {
  try {
    // Initialize AI service if not already done
    if (!global.aiService) {
      global.aiService = new AIService();
    }

    const startTime = Date.now();
    
    // Map model IDs to provider and model names
    const modelMapping = {
      'gpt-4': { provider: 'openai', model: 'gpt-4' },
      'gpt-3.5-turbo': { provider: 'openai', model: 'gpt-3.5-turbo' },
      'claude-3-haiku': { provider: 'anthropic', model: 'claude-3-haiku-20240307' },
      'claude-3-sonnet': { provider: 'anthropic', model: 'claude-3-sonnet-20240229' },
      'gemini-pro': { provider: 'gemini', model: 'gemini-pro' },
      'mistral-large': { provider: 'mistral', model: 'mistral-large-latest' },
      'cohere-command': { provider: 'cohere', model: 'command' },
      'groq-llama2': { provider: 'groq', model: 'llama2-70b-4096' }
    };

    const modelConfig = modelMapping[model.id] || { provider: 'openai', model: 'gpt-3.5-turbo' };
    
    // Prepare messages for chat API
    const messages = [
      {
        role: 'user',
        content: prompt
      }
    ];

    // Call the AI service
    const result = await global.aiService.chat(messages, {
      model: modelConfig.model,
      provider: modelConfig.provider,
      temperature: parameters.temperature || 0.7,
      maxTokens: parameters.maxTokens || 2048,
      stream: false
    });

    const endTime = Date.now();
    const latency = endTime - startTime;

    // Estimate token usage (rough approximation)
    const inputTokens = Math.ceil(prompt.length / 4);
    const outputTokens = Math.ceil(result.response.length / 4);

    return {
      response: result.response,
      tokens: {
        input: inputTokens,
        output: outputTokens,
        total: inputTokens + outputTokens
      },
      latency: latency
    };

  } catch (error) {
    console.error(`AI Service error for model ${model.id}:`, error);
    
    // Fallback to mock response if AI service fails
    const delay = Math.random() * 2000 + 500;
    await new Promise(resolve => setTimeout(resolve, delay));

    const mockResponse = `Error: Failed to generate response from ${model.name}. ${error.message}\n\nThis is a fallback mock response. Please check your API keys and try again.`;
    const inputTokens = Math.ceil(prompt.length / 4);
    const outputTokens = Math.ceil(mockResponse.length / 4);

    return {
      response: mockResponse,
      tokens: {
        input: inputTokens,
        output: outputTokens,
        total: inputTokens + outputTokens
      },
      latency: delay
    };
  }
}

function getModelDisplayName(modelId) {
  const modelNames = {
    'gpt-4': 'GPT-4',
    'gpt-3.5-turbo': 'GPT-3.5 Turbo',
    'claude-3-haiku': 'Claude 3 Haiku',
    'claude-3-sonnet': 'Claude 3 Sonnet',
    'gemini-pro': 'Gemini Pro',
    'mistral-large': 'Mistral Large',
    'cohere-command': 'Cohere Command',
    'groq-llama2': 'Groq Llama2'
  };
  return modelNames[modelId] || modelId;
}

function getModelProvider(modelId) {
  const providers = {
    'gpt-4': 'openai',
    'gpt-3.5-turbo': 'openai',
    'claude-3-haiku': 'anthropic',
    'claude-3-sonnet': 'anthropic',
    'gemini-pro': 'google',
    'mistral-large': 'mistral',
    'cohere-command': 'cohere',
    'groq-llama2': 'groq'
  };
  return providers[modelId] || 'unknown';
}

function calculateCost(modelId, tokens) {
  const costRates = {
    'gpt-4': { input: 0.03, output: 0.06 },
    'gpt-3.5-turbo': { input: 0.0015, output: 0.002 },
    'claude-3-haiku': { input: 0.00025, output: 0.00125 },
    'claude-3-sonnet': { input: 0.003, output: 0.015 }
  };

  const rate = costRates[modelId] || { input: 0.001, output: 0.001 };
  return (tokens.input * rate.input + tokens.output * rate.output) / 1000;
}

async function calculateQualityScore(response, prompt) {
  // Mock quality scoring - implement actual quality metrics
  return {
    coherence: 0.8 + Math.random() * 0.2,
    relevance: 0.7 + Math.random() * 0.3,
    accuracy: 0.75 + Math.random() * 0.25,
    creativity: 0.6 + Math.random() * 0.4,
    overallScore: 0.7 + Math.random() * 0.3
  };
}

function generateAnalysis(results) {
  const successfulResults = results.filter(r => r.status === 'completed' && r.output);
  
  if (successfulResults.length === 0) {
    return { error: 'No successful results to analyze' };
  }

  const bestResult = successfulResults.reduce((best, current) => 
    current.output.quality.overallScore > best.output.quality.overallScore ? current : best
  );

  return {
    bestModel: bestResult.modelName,
    comparison: {
      winner: bestResult.modelName,
      reasoning: `${bestResult.modelName} achieved the highest overall quality score of ${bestResult.output.quality.overallScore.toFixed(3)}`,
      scores: successfulResults.map(r => ({
        model: r.modelName,
        score: r.output.quality.overallScore,
        cost: r.output.cost,
        latency: r.output.latency
      }))
    },
    insights: [
      `Best performing model: ${bestResult.modelName}`,
      `Average response time: ${(successfulResults.reduce((acc, r) => acc + r.output.latency, 0) / successfulResults.length / 1000).toFixed(2)}s`,
      `Total cost: $${successfulResults.reduce((acc, r) => acc + r.output.cost, 0).toFixed(4)}`
    ],
    recommendations: [
      `Consider using ${bestResult.modelName} for similar tasks`,
      'Monitor token usage to optimize costs',
      'Test with different prompt variations for better results'
    ]
  };
}

function generateBattleAnalysis(results, battleType) {
  const [result1, result2] = results;
  
  if (result1.status !== 'completed' || result2.status !== 'completed') {
    return { error: 'Both models must complete successfully for battle analysis' };
  }

  let winner = result1.modelName;
  let reasoning = '';

  switch (battleType) {
    case 'quality':
      winner = result1.output.quality.overallScore > result2.output.quality.overallScore ? 
        result1.modelName : result2.modelName;
      reasoning = `${winner} achieved higher quality score`;
      break;
    case 'speed':
      winner = result1.output.latency < result2.output.latency ? 
        result1.modelName : result2.modelName;
      reasoning = `${winner} responded faster`;
      break;
    case 'cost':
      winner = result1.output.cost < result2.output.cost ? 
        result1.modelName : result2.modelName;
      reasoning = `${winner} was more cost-effective`;
      break;
  }

  return {
    bestModel: winner,
    comparison: {
      winner,
      reasoning,
      scores: {
        [result1.modelName]: {
          quality: result1.output.quality.overallScore,
          speed: result1.output.latency,
          cost: result1.output.cost
        },
        [result2.modelName]: {
          quality: result2.output.quality.overallScore,
          speed: result2.output.latency,
          cost: result2.output.cost
        }
      }
    },
    insights: [
      `Battle type: ${battleType}`,
      `Winner: ${winner}`,
      `Quality difference: ${Math.abs(result1.output.quality.overallScore - result2.output.quality.overallScore).toFixed(3)}`
    ]
  };
}

module.exports = router;