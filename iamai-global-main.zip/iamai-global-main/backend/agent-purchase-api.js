// ============================================
// SIMPLE AGENT PURCHASE API
// One-time purchases with expiration - NO SUBSCRIPTIONS
// ============================================

const express = require('express');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
// Unified AgentPurchase model (supports both legacy + new fields)
const { AgentPurchase } = require('./agent-purchase-models');

const router = express.Router();

// ============================================
// MIDDLEWARE: Authenticate user
// Checks: 1. HttpOnly cookie (preferred), 2. Authorization header (fallback)
// Supports: Both new JWT_SECRET and legacy fallback secret for transition period
// ============================================
const authenticate = (req, res, next) => {
  // Try cookie first (preferred)
  let token = req.cookies?.authToken;
  
  // Fallback to Authorization header (for API clients and redirect scenarios)
  if (!token) {
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
      token = authHeader.substring(7); // Remove 'Bearer ' prefix
    }
  }
  
  if (!token) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  
  const jwt = require('jsonwebtoken');
  
  // Try JWT_SECRET first (new tokens), then fallback secret (legacy tokens from before env fix)
  const secrets = [
    process.env.JWT_SECRET,
    'your-secret-key-change-this'  // Legacy fallback for tokens issued before JWT_SECRET was properly loaded
  ].filter(Boolean);
  
  let decoded = null;
  for (const secret of secrets) {
    try {
      decoded = jwt.verify(token, secret);
      break;
    } catch (err) {
      // Try next secret
    }
  }
  
  if (!decoded) {
    return res.status(401).json({ error: 'Invalid token' });
  }
  
  req.userId = decoded.id || decoded.userId;
  req.userEmail = decoded.email;
  next();
};

// ============================================
// GET: Check if user has active access to agent
// ============================================
router.get('/api/agents/:agentId/access', authenticate, async (req, res) => {
  try {
    const { agentId } = req.params;
    const userId = req.userId;
    const purchase = await AgentPurchase.findActivePurchase(userId, agentId);

    if (purchase) {
      const now = new Date();
      const expiresAtDate = purchase.expiresAt
        ? new Date(purchase.expiresAt)
        : purchase.expirationDate
        ? new Date(purchase.expirationDate)
        : null;
      const daysRemaining = expiresAtDate
        ? Math.max(0, Math.ceil((expiresAtDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)))
        : 0;

      const metaPlan = purchase.metadata?.plan;
      const rawPlan = (
        purchase.plan ||
        metaPlan ||
        purchase.planType ||
        'DAILY'
      )
        .toString()
        .toUpperCase();

      return res.json({
        hasAccess: true,
        plan: rawPlan,
        planName: purchase.planName || purchase.metadata?.planName || rawPlan,
        expiresAt: expiresAtDate,
        daysRemaining,
        hoursRemaining: daysRemaining * 24,
        purchaseDate: purchase.purchaseDate,
        status: purchase.status,
      });
    } else {
      return res.json({
        hasAccess: false,
        message: 'No active purchase found for this agent',
      });
    }
  } catch (error) {
    console.error('Error checking access:', error);
    return res.status(500).json({ error: 'Failed to check access' });
  }
});

// ============================================
// GET: Get all active purchases for user
// ============================================
router.get('/api/purchases/active', authenticate, async (req, res) => {
  try {
    const userId = req.userId;
    const now = new Date();

    const purchases = await AgentPurchase.getUserActivePurchases(userId);

    return res.json({
      success: true,
      count: purchases.length,
      purchases: purchases.map(p => {
        const metaPlan = p.metadata?.plan;
        const rawPlan = (
          p.plan ||
          metaPlan ||
          p.planType ||
          'DAILY'
        )
          .toString()
          .toUpperCase();

        // Safely determine pricing information even for legacy/partial documents
        const metaPricing = (p.metadata && p.metadata.pricing) || {};
        let amount = 0;
        let currency = 'USD';

        if (p.pricing && typeof p.pricing.amount === 'number') {
          amount = p.pricing.amount;
          currency = p.pricing.currency || currency;
        } else if (typeof metaPricing.amount === 'number') {
          amount = metaPricing.amount;
          currency = metaPricing.currency || currency;
        } else if (typeof p.amount === 'number') {
          amount = p.amount;
          currency = p.currency || currency;
        }

        const expiresAtDate = p.expiresAt
          ? new Date(p.expiresAt)
          : p.expirationDate
          ? new Date(p.expirationDate)
          : null;
        const daysRemaining = expiresAtDate
          ? Math.max(0, Math.ceil((expiresAtDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)))
          : 0;

        return {
          id: p._id,
          agentId: p.agentId,
          agentName: p.agentName || p.metadata?.agentName || p.agentId,
          plan: rawPlan,
          planName: p.metadata?.planName || rawPlan,
          amount,
          currency: currency.toString().toUpperCase(),
          purchaseDate: p.purchaseDate,
          expiresAt: expiresAtDate,
          daysRemaining,
          status: (p.status || 'active').toString().toLowerCase(),
        };
      }),
    });
  } catch (error) {
    console.error('Error getting active purchases:', error);
    return res.status(500).json({ error: 'Failed to get active purchases' });
  }
});

// ============================================
// GET: Get current subscription (legacy endpoint for AI Lab)
// ============================================
router.get('/api/subscription/current', authenticate, async (req, res) => {
  try {
    const userId = req.userId;

    const purchases = await AgentPurchase.getUserActivePurchases(userId);

    if (purchases.length === 0) {
      return res.json({
        subscription: null,
        status: 'NONE'
      });
    }

    // Return the first active purchase as the current subscription
    const purchase = purchases[0];

    const metaPlan = purchase.metadata?.plan;
    const rawPlan = (
      purchase.plan ||
      metaPlan ||
      purchase.planType ||
      'DAILY'
    )
      .toString()
      .toUpperCase();

    const currentPeriodEnd = purchase.expiresAt || purchase.expirationDate || purchase.purchaseDate;

    return res.json({
      subscription: {
        plan: rawPlan,
        status: 'ACTIVE',
        billing: {
          currentPeriodEnd,
        },
      },
      status: 'ACTIVE',
    });
  } catch (error) {
    console.error('Error getting current subscription:', error);
    return res.status(500).json({ error: 'Failed to get subscription' });
  }
});

// ============================================
// POST: Purchase agent access via Payment Intent
// NOTE: This endpoint is now namespaced as /api/agents/:agentId/purchase-intent
// to avoid conflicting with the Stripe Checkout-based flow in agent-purchase-routes.js,
// which is what the current frontend uses.
// ============================================
router.post('/api/agents/:agentId/purchase-intent', authenticate, async (req, res) => {
  try {
    const { agentId } = req.params;
    const { plan, planType, agentName } = req.body || {};
    const userId = req.userId;
    const userEmail = req.userEmail;

    // Normalize plan from either `plan` (DAILY/WEEKLY/MONTHLY) or `planType` (daily/weekly/monthly)
    const rawPlan = (plan || planType || '').toString().toUpperCase();

    // Validate plan
    if (!['DAILY', 'WEEKLY', 'MONTHLY'].includes(rawPlan)) {
      return res.status(400).json({ error: 'Invalid plan. Must be DAILY, WEEKLY, or MONTHLY' });
    }

    // Check if user already has active purchase for this agent
    const existingPurchase = await AgentPurchase.findActivePurchase(userId, agentId);
    if (existingPurchase) {
      return res.status(400).json({
        error: 'Already have active access',
        message: `You already have an active ${existingPurchase.planName} for this agent (expires ${existingPurchase.expiresAt.toLocaleDateString()})`,
        existingPurchase: {
          plan: existingPurchase.plan,
          expiresAt: existingPurchase.expiresAt,
          daysRemaining: existingPurchase.daysRemaining,
        },
      });
    }

    // Get plan configuration
    const planConfig = AgentPurchase.getPlanConfig(rawPlan);
    if (!planConfig) {
      return res.status(400).json({ error: 'Invalid plan configuration' });
    }

    // Create Stripe payment intent (one-time payment)
    const paymentIntent = await stripe.paymentIntents.create({
      amount: planConfig.amount * 100, // Convert to cents
      currency: 'usd',
      metadata: {
        userId: userId.toString(),
        agentId,
        plan: rawPlan,
        type: 'agent_purchase',
      },
      description: `${planConfig.name} for ${agentName || agentId}`,
      automatic_payment_methods: {
        enabled: true,
      },
    });

    // Calculate expiration date
    const purchaseDate = new Date();
    const expiresAt = AgentPurchase.calculateExpiration(rawPlan, purchaseDate);

    // Create purchase record
    const purchase = new AgentPurchase({
      userId,
      email: userEmail,
      agentId,
      agentName: agentName || agentId,
      plan: rawPlan,
      planName: planConfig.name,
      pricing: {
        amount: planConfig.amount,
        currency: 'USD',
      },
      purchaseDate,
      expiresAt,
      stripePaymentIntentId: paymentIntent.id,
      stripeCustomerId: paymentIntent.customer,
      paymentMethod: 'CARD',
      paymentStatus: 'PENDING',
      status: 'ACTIVE', // Will be active once payment succeeds
    });

    await purchase.save();

    return res.json({
      success: true,
      message: 'Purchase initiated successfully',
      clientSecret: paymentIntent.client_secret,
      purchase: {
        id: purchase._id,
        agentId: purchase.agentId,
        agentName: purchase.agentName,
        plan: purchase.plan,
        planName: purchase.planName,
        amount: purchase.pricing.amount,
        expiresAt: purchase.expiresAt,
        daysRemaining: purchase.daysRemaining,
      },
    });
  } catch (error) {
    console.error('Error creating purchase:', error);
    return res.status(500).json({ 
      error: 'Failed to create purchase',
      details: error.message 
    });
  }
});

// ============================================
// POST: Cancel active purchase
// ============================================
router.post('/api/purchases/:purchaseId/cancel', authenticate, async (req, res) => {
  try {
    const { purchaseId } = req.params;
    const userId = req.userId;

    const purchase = await AgentPurchase.findOne({
      _id: purchaseId,
      userId,
    });

    if (!purchase) {
      return res.status(404).json({ error: 'Purchase not found' });
    }

    if (purchase.status !== 'ACTIVE') {
      return res.status(400).json({ 
        error: 'Can only cancel active purchases',
        currentStatus: purchase.status 
      });
    }

    await purchase.cancel();

    return res.json({
      success: true,
      message: 'Purchase cancelled successfully',
      purchase: {
        id: purchase._id,
        agentId: purchase.agentId,
        status: purchase.status,
      },
    });
  } catch (error) {
    console.error('Error cancelling purchase:', error);
    return res.status(500).json({ 
      error: 'Failed to cancel purchase',
      details: error.message 
    });
  }
});

// ============================================
// GET: Get purchase history for user
// ============================================
router.get('/api/purchases/history', authenticate, async (req, res) => {
  try {
    const userId = req.userId;
    const { limit = 50, skip = 0 } = req.query;

    const purchases = await AgentPurchase.find({ userId })
      .sort({ purchaseDate: -1 })
      .limit(parseInt(limit))
      .skip(parseInt(skip));

    const total = await AgentPurchase.countDocuments({ userId });

    return res.json({
      success: true,
      total,
      count: purchases.length,
      purchases: purchases.map(p => {
        const metaPricing = (p.metadata && p.metadata.pricing) || {};
        let amount = 0;
        let currency = 'USD';

        if (p.pricing && typeof p.pricing.amount === 'number') {
          amount = p.pricing.amount;
          currency = p.pricing.currency || currency;
        } else if (typeof metaPricing.amount === 'number') {
          amount = metaPricing.amount;
          currency = metaPricing.currency || currency;
        } else if (typeof p.amount === 'number') {
          amount = p.amount;
          currency = p.currency || currency;
        }

        return {
          id: p._id,
          agentId: p.agentId,
          agentName: p.agentName,
          plan: p.plan,
          planName: p.planName,
          amount,
          currency,
          purchaseDate: p.purchaseDate,
          expiresAt: p.expiresAt,
          status: p.status,
          paymentStatus: p.paymentStatus,
        };
      }),
    });
  } catch (error) {
    console.error('Error getting purchase history:', error);
    return res.status(500).json({ error: 'Failed to get purchase history' });
  }
});

// ============================================
// GET: Get purchase stats (admin/analytics)
// ============================================
router.get('/api/purchases/stats', authenticate, async (req, res) => {
  try {
    const userId = req.userId;

    const stats = await AgentPurchase.aggregate([
      { $match: { userId: require('mongoose').Types.ObjectId(userId) } },
      {
        $group: {
          _id: null,
          totalPurchases: { $sum: 1 },
          // Safely sum pricing.amount, treating missing values as 0
          totalSpent: {
            $sum: {
              $cond: [
                { $ifNull: ['$pricing.amount', false] },
                '$pricing.amount',
                0,
              ],
            },
          },
          activePurchases: {
            $sum: {
              $cond: [
                {
                  $and: [
                    { $eq: ['$status', 'ACTIVE'] },
                    { $gt: ['$expiresAt', new Date()] },
                  ],
                },
                1,
                0,
              ],
            },
          },
        },
      },
    ]);

    const result = stats[0] || {
      totalPurchases: 0,
      totalSpent: 0,
      activePurchases: 0,
    };

    return res.json({
      success: true,
      stats: result,
    });
  } catch (error) {
    console.error('Error getting purchase stats:', error);
    return res.status(500).json({ error: 'Failed to get purchase stats' });
  }
});

// ============================================
// WEBHOOK: Stripe payment confirmation
// ============================================
router.post('/api/webhooks/stripe/purchase', express.raw({ type: 'application/json' }), async (req, res) => {
  const sig = req.headers['stripe-signature'];
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

  try {
    const event = stripe.webhooks.constructEvent(req.body, sig, webhookSecret);

    if (event.type === 'payment_intent.succeeded') {
      const paymentIntent = event.data.object;
      
      console.log(`✅ [Payment Intent Webhook] Payment succeeded for intent: ${paymentIntent.id}`);
      
      // Update purchase status
      const updateResult = await AgentPurchase.findOneAndUpdate(
        { stripePaymentIntentId: paymentIntent.id },
        { 
          paymentStatus: 'SUCCESS',
          status: 'ACTIVE',
        }
      );

      if (updateResult) {
        console.log(`✅ [Payment Intent Webhook] Updated purchase ${updateResult._id} to ACTIVE`);
      } else {
        console.log(`❌ [Payment Intent Webhook] No purchase found for payment intent ${paymentIntent.id}`);
      }
    }

    if (event.type === 'payment_intent.payment_failed') {
      const paymentIntent = event.data.object;
      
      // Update purchase status
      await AgentPurchase.findOneAndUpdate(
        { stripePaymentIntentId: paymentIntent.id },
        { 
          paymentStatus: 'FAILED',
          status: 'CANCELLED',
        }
      );

      console.log(`❌ Payment failed for purchase: ${paymentIntent.id}`);
    }

    res.json({ received: true });
  } catch (error) {
    console.error('Webhook error:', error);
    return res.status(400).send(`Webhook Error: ${error.message}`);
  }
});

module.exports = router;
