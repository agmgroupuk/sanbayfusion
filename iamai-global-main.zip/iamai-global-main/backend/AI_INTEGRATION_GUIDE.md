# 🤖 AI Integration Documentation

## Overview

IAMAI Global now has comprehensive AI integration with automatic fallback support and multi-provider capabilities.

## Architecture

### Primary Provider: OpenAI
- **Models**: GPT-4, GPT-3.5-turbo, DALL-E-3
- **Use Cases**: All text generation, chat, image generation
- **Pricing**: Most reliable, best quality

### Fallback Provider 1: Google Gemini
- **Models**: Gemini Pro
- **Automatic Activation**: When OpenAI fails or is unavailable
- **Use Cases**: Text generation, chat

### Fallback Provider 2: Anthropic Claude
- **Models**: Claude 3 Opus, Claude 3 Sonnet
- **Automatic Activation**: When both OpenAI and Gemini fail
- **Use Cases**: Text generation, chat, analysis

### Additional Services (All Agents)
- **Stability AI**: Image generation
- **RunwayML**: Video and advanced media
- **Replicate**: Various open-source models
- **Hugging Face**: Open models and fine-tuning

## Setup Instructions

### 1. Configure API Keys

**Option A: Interactive Setup (Recommended)**
```bash
cd /var/www/iamai-global/backend
./setup-api-keys.sh
```

**Option B: Manual Configuration**
```bash
cd /var/www/iamai-global/backend
nano .env
```

Add your API keys:
```env
# Primary (REQUIRED)
OPENAI_API_KEY=sk-...

# Fallbacks (Optional but recommended)
GOOGLE_AI_API_KEY=AIza...
ANTHROPIC_API_KEY=sk-ant-...

# Additional Services (Optional)
STABILITY_AI_API_KEY=sk-...
REPLICATE_API_TOKEN=r8_...
RUNWAYML_API_KEY=...
HUGGINGFACE_API_KEY=hf_...
```

### 2. Restart Backend
```bash
pm2 restart iamai-backend
```

### 3. Verify Installation
```bash
curl http://localhost:3001/api/ai/stats
```

Expected output:
```json
{
  "providers": {
    "openai": { "calls": 0, "failures": 0 },
    "gemini": { "calls": 0, "failures": 0 },
    "anthropic": { "calls": 0, "failures": 0 }
  },
  "availableProviders": {
    "openai": true,
    "gemini": true,
    "anthropic": true
  },
  "apiKeys": {
    "openai": true,
    "anthropic": true,
    "gemini": true,
    ...
  }
}
```

## API Endpoints

### Chat with Agent
```http
POST /api/agents/:agentId/chat
Content-Type: application/json

{
  "message": "Hello, how can you help me?",
  "conversationId": "optional-conv-id",
  "model": "gpt-4",
  "temperature": 0.7
}
```

**Response:**
```json
{
  "agentId": "agentx",
  "conversationId": "conv_1698345678",
  "message": "AI response here...",
  "provider": "openai",
  "model": "gpt-4-turbo-preview",
  "timestamp": "2025-10-27T13:45:30.000Z",
  "usage": {
    "prompt_tokens": 20,
    "completion_tokens": 50,
    "total_tokens": 70
  },
  "creditsUsed": 1,
  "availableKeys": {
    "openai": "sk-...",
    "gemini": "AIza...",
    ...
  }
}
```

### Stream Chat (Server-Sent Events)
```http
POST /api/agents/:agentId/chat/stream
Content-Type: application/json

{
  "message": "Write a story...",
  "model": "gpt-4"
}
```

**Response Stream:**
```
data: {"content":"Once"}

data: {"content":" upon"}

data: {"content":" a"}

data: [DONE]
```

### Generate Image
```http
POST /api/agents/:agentId/generate-image
Content-Type: application/json

{
  "prompt": "A futuristic AI robot",
  "size": "1024x1024",
  "quality": "hd"
}
```

**Response:**
```json
{
  "agentId": "content-creator",
  "provider": "openai-dalle",
  "images": [
    {
      "url": "https://oaidalleapiprodscus.blob.core.windows.net/...",
      "revisedPrompt": "Enhanced prompt used..."
    }
  ],
  "creditsUsed": 10
}
```

### Get AI Statistics
```http
GET /api/ai/stats
```

### Validate API Keys
```http
GET /api/ai/validate
```

### Get Agent Configuration
```http
GET /api/agents/:agentId/config
```

## Agent Personalities

Each agent has a unique system prompt and personality:

### AgentX
- **Type**: General Assistant
- **Personality**: Professional, helpful, focused on productivity
- **Best For**: Task management, research, general queries

### AI Girlfriend
- **Type**: Companion
- **Personality**: Warm, empathetic, emotionally intelligent
- **Best For**: Conversations, emotional support, companionship

### AutoChat
- **Type**: Customer Service
- **Personality**: Efficient, helpful, professional
- **Best For**: Customer inquiries, FAQs, support tickets

### Content Creator
- **Type**: Creative Assistant
- **Personality**: Creative, imaginative, engaging
- **Best For**: Blog posts, social media, marketing copy

### Code Assistant
- **Type**: Programming Helper
- **Personality**: Technical, precise, educational
- **Best For**: Code generation, debugging, explanations

### ChatRevive
- **Type**: Context Recovery
- **Personality**: Analytical, context-aware
- **Best For**: Recovering conversation context

## Fallback System

The AI service automatically handles failures:

1. **Try OpenAI** (Primary)
   - Fast, reliable, best quality
   - Supports streaming, images, embeddings

2. **Fallback to Gemini** (if OpenAI fails)
   - Google's latest model
   - Good quality, fast

3. **Fallback to Claude** (if Gemini fails)
   - Anthropic's Claude 3
   - Excellent reasoning, long context

4. **Error if all fail**
   - Returns friendly error message
   - Suggests trying again later

## Credits System

Credits are calculated based on token usage:

- **Text Generation**: 1 credit per 1000 tokens
- **Image Generation**: 10 credits per image
- **Streaming**: Same as text generation

## API Keys Management

### Where to Get Keys

**OpenAI** (Required)
- Website: https://platform.openai.com/api-keys
- Cost: Pay-as-you-go, ~$0.01-$0.06 per 1K tokens
- Models: GPT-4, GPT-3.5, DALL-E

**Google AI** (Optional - Fallback 1)
- Website: https://makersuite.google.com/app/apikey
- Cost: Free tier available, then pay-as-you-go
- Models: Gemini Pro

**Anthropic** (Optional - Fallback 2)
- Website: https://console.anthropic.com/
- Cost: Pay-as-you-go, ~$0.015-$0.075 per 1K tokens
- Models: Claude 3 Opus, Sonnet, Haiku

**Stability AI** (Optional)
- Website: https://platform.stability.ai/
- Cost: Credits system
- Use: Image generation

**Replicate** (Optional)
- Website: https://replicate.com/
- Cost: Pay per prediction
- Use: Various open-source models

**Hugging Face** (Optional)
- Website: https://huggingface.co/settings/tokens
- Cost: Free for many models
- Use: Open-source models

## Security Best Practices

1. **Never expose API keys in frontend code**
   - All AI calls go through backend
   - Keys stored in .env file only

2. **Use environment variables**
   - Never commit .env to git
   - Keep .env.example updated

3. **Rate limiting**
   - Already implemented: 100 requests per 15 minutes
   - Adjust in production-server.js if needed

4. **Monitor usage**
   - Check `/api/ai/stats` regularly
   - Set up billing alerts in provider dashboards

5. **Rotate keys regularly**
   - Generate new keys quarterly
   - Revoke old keys after rotation

## Testing

### Test Chat Endpoint
```bash
curl -X POST http://localhost:3001/api/agents/agentx/chat \
  -H "Content-Type: application/json" \
  -d '{"message":"Hello!"}'
```

### Test Public Endpoint (through nginx)
```bash
curl -X POST https://iamai.global/api/agents/agentx/chat \
  -H "Content-Type: application/json" \
  -d '{"message":"Hello!"}'
```

### Test Image Generation
```bash
curl -X POST http://localhost:3001/api/agents/content-creator/generate-image \
  -H "Content-Type: application/json" \
  -d '{"prompt":"A beautiful sunset"}'
```

## Troubleshooting

### No API keys configured
**Error**: "AI service is not available"
**Solution**: Add API keys to .env and restart backend

### OpenAI rate limit
**Error**: Rate limit exceeded
**Solution**: Wait or upgrade OpenAI plan
**Automatic**: Falls back to Gemini/Claude

### All providers fail
**Error**: "All AI providers are unavailable"
**Solution**: 
1. Check API keys are valid
2. Check billing/credits
3. Run `/api/ai/validate` to test connections

### Streaming not working
**Error**: "Streaming requires OpenAI"
**Solution**: Add OpenAI API key (only provider supporting streams)

## Monitoring

### View Logs
```bash
pm2 logs iamai-backend
```

### Check Service Status
```bash
pm2 status
```

### View Real-time Stats
```bash
watch -n 5 'curl -s http://localhost:3001/api/ai/stats | jq'
```

## Performance Optimization

1. **Model Selection**
   - Use GPT-3.5 for simple tasks (faster, cheaper)
   - Use GPT-4 for complex reasoning
   - Use Claude for long documents

2. **Temperature Settings**
   - 0.3-0.5: Factual, consistent responses
   - 0.7-0.9: Creative, varied responses
   - 1.0+: Very creative, less predictable

3. **Token Limits**
   - Set appropriate maxTokens
   - Default: 2000 tokens
   - Adjust based on use case

4. **Caching**
   - Consider implementing response caching
   - Cache common queries
   - Reduce API calls and costs

## Cost Estimation

### OpenAI (Primary)
- GPT-4: ~$0.03-$0.06 per 1K tokens
- GPT-3.5: ~$0.001-$0.002 per 1K tokens
- DALL-E: ~$0.04 per image

### Monthly Estimates
- **Light Usage** (1K messages): $10-20
- **Medium Usage** (10K messages): $50-100  
- **Heavy Usage** (100K messages): $500-1000

Add fallback providers to reduce costs when OpenAI is unavailable.

## Next Steps

1. **Add API Keys** - Configure at least OpenAI key
2. **Test Integration** - Try chat endpoints
3. **Monitor Usage** - Check stats regularly
4. **Optimize Costs** - Adjust models and settings
5. **Scale Up** - Add more agents and features

## Support

- **Documentation**: This file
- **Setup Script**: `./setup-api-keys.sh`
- **Check Status**: `GET /api/ai/stats`
- **Validate Keys**: `GET /api/ai/validate`

---

Last Updated: October 27, 2025
Version: 1.0.0
