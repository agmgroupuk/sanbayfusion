#!/bin/bash

echo "🔧 IAMAI Backend - AI API Keys Configuration"
echo "=============================================="
echo ""
echo "This script will help you configure your AI API keys."
echo "You can add keys now or skip and add them later to .env file"
echo ""

# Check if .env already exists
if [ -f .env ]; then
    echo "⚠️  .env file already exists. Creating backup..."
    cp .env .env.backup.$(date +%Y%m%d_%H%M%S)
fi

# Start with template
cp .env.production.template .env 2>/dev/null || echo "NODE_ENV=production" > .env
echo "PORT=3001" >> .env
echo "FRONTEND_URL=https://iamai.global" >> .env
echo "" >> .env

# Function to ask for API key
ask_for_key() {
    local key_name=$1
    local key_description=$2
    local is_required=$3
    
    echo ""
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "📌 $key_description"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    
    if [ "$is_required" = "true" ]; then
        echo "   Status: ⚠️  REQUIRED"
    else
        echo "   Status: ✓ Optional"
    fi
    
    read -p "   Enter $key_name (or press Enter to skip): " key_value
    
    if [ -n "$key_value" ]; then
        echo "$key_name=$key_value" >> .env
        echo "   ✅ $key_name configured"
    else
        echo "$key_name=" >> .env
        if [ "$is_required" = "true" ]; then
            echo "   ⚠️  Warning: This key is required for full functionality"
        else
            echo "   ℹ️  Skipped - you can add this later"
        fi
    fi
}

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🤖 PRIMARY AI PROVIDER"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

ask_for_key "OPENAI_API_KEY" "OpenAI API Key (GPT-4, GPT-3.5, DALL-E)" "true"

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🔄 FALLBACK AI PROVIDERS"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

ask_for_key "GOOGLE_AI_API_KEY" "Google AI (Gemini Pro) - Fallback 1" "false"
ask_for_key "ANTHROPIC_API_KEY" "Anthropic (Claude 3) - Fallback 2" "false"

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🎨 ADDITIONAL AI SERVICES"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "These keys will be accessible to all agents"
echo ""

ask_for_key "STABILITY_AI_API_KEY" "Stability AI (Image Generation)" "false"
ask_for_key "REPLICATE_API_TOKEN" "Replicate (Various Models)" "false"
ask_for_key "RUNWAYML_API_KEY" "RunwayML (Video/Image AI)" "false"
ask_for_key "HUGGINGFACE_API_KEY" "Hugging Face (Open Models)" "false"

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🔐 SECURITY"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# Generate random JWT secret
JWT_SECRET=$(openssl rand -base64 32)
echo "JWT_SECRET=$JWT_SECRET" >> .env
echo "JWT_EXPIRES_IN=7d" >> .env
echo "✅ JWT secret automatically generated"

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "✅ Configuration Complete!"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "Your .env file has been created at: $(pwd)/.env"
echo ""
echo "📋 Configuration Summary:"
echo ""

# Show which keys are configured
echo "Configured API Keys:"
grep -E "^(OPENAI|GOOGLE|ANTHROPIC|STABILITY|REPLICATE|RUNWAY|HUGGINGFACE)_" .env | while read line; do
    key=$(echo $line | cut -d= -f1)
    value=$(echo $line | cut -d= -f2)
    if [ -n "$value" ]; then
        echo "  ✅ $key"
    else
        echo "  ❌ $key (not configured)"
    fi
done

echo ""
echo "Next steps:"
echo "1. Review your .env file: cat .env"
echo "2. Add any missing API keys: nano .env"
echo "3. Restart the backend: pm2 restart iamai-backend"
echo "4. Check logs: pm2 logs iamai-backend"
echo "5. Test API: curl http://localhost:3001/api/ai/stats"
echo ""
echo "🚀 Happy coding!"
