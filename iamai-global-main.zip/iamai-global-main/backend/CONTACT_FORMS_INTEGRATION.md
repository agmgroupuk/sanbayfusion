# Contact Forms and Support Tickets Integration

## Overview
Complete contact form and support ticket system has been integrated into the IAMAI Global backend with Gmail SMTP email notifications.

## New Database Models

### ContactForm
- Captures contact form submissions from the website
- Fields: name, email, subject, message, phone, company, source, status, priority
- Automatically creates support tickets when requested
- Email notifications to both customer and admin

### SupportTicket
- Full ticket management system with responses and attachments
- Unique ticket number generation (IAMAI-XXXXXX-XXX format)
- Status tracking: OPEN, IN_PROGRESS, WAITING_FOR_CUSTOMER, RESOLVED, CLOSED
- Priority levels: LOW, NORMAL, HIGH, URGENT
- Categories: GENERAL, TECHNICAL, BILLING, FEATURE_REQUEST, BUG_REPORT, ACCOUNT, API, INTEGRATION

### TicketResponse
- Responses to support tickets from users or staff
- Internal/external response types
- Email notifications for new responses

### TicketAttachment
- File attachments for support tickets
- Supports various file types with size limits

## API Endpoints

### Contact Forms
- `POST /api/contact/submit` - Submit contact form (public)
- `GET /api/contact` - List contact forms (admin)
- `GET /api/contact/:id` - Get contact form details (admin)
- `PUT /api/contact/:id/status` - Update contact form status (admin)
- `DELETE /api/contact/:id` - Delete contact form (admin)

### Support Tickets
- `POST /api/tickets` - Create support ticket (authenticated)
- `GET /api/tickets` - List support tickets (authenticated)
- `GET /api/tickets/:id` - Get ticket details (authenticated)
- `PUT /api/tickets/:id` - Update ticket (authenticated)
- `DELETE /api/tickets/:id` - Delete ticket (admin)
- `POST /api/tickets/:id/responses` - Add response to ticket (authenticated)
- `GET /api/tickets/statistics` - Get ticket statistics (admin)

## Email Configuration

### Gmail SMTP Setup
```env
MAIL_HOST=smtp.gmail.com
MAIL_PORT=587
MAIL_SECURE=false
MAIL_USER=onelastai2.0@gmail.com
MAIL_PASS=your_app_password
MAIL_FROM=mail@iamai.global
ADMIN_EMAIL=onelastai2.0@gmail.com
```

### Email Templates
- Customer confirmation emails with ticket numbers
- Admin notification emails for new submissions
- Status update notifications
- Response notifications

## Features

### Contact Form Submission
1. **Public API**: Anyone can submit contact forms
2. **Automatic Ticketing**: Optionally creates support tickets
3. **Email Notifications**: Sends confirmation to customer and notification to admin
4. **Spam Protection**: Status filtering and validation
5. **Source Tracking**: Tracks submission source (website, mobile, API)

### Ticket Management
1. **Unique Ticket Numbers**: Auto-generated format IAMAI-XXXXXX-XXX
2. **Full Lifecycle**: Open → In Progress → Resolved → Closed
3. **Priority Management**: LOW, NORMAL, HIGH, URGENT
4. **Category Organization**: 8 different categories for proper routing
5. **Response System**: Internal and external responses with email notifications

### Admin Features
1. **Dashboard Statistics**: Total tickets, status breakdowns, priority counts
2. **Search and Filtering**: By status, category, priority, user, assigned staff
3. **Bulk Operations**: Status updates, assignments
4. **Email Management**: All communications tracked and logged

## Integration Points

### Frontend Integration
Add contact forms anywhere in the React frontend:

```typescript
// Contact form submission
const submitContactForm = async (formData) => {
  const response = await fetch('/api/contact/submit', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      name: formData.name,
      email: formData.email,
      subject: formData.subject,
      message: formData.message,
      phone: formData.phone,
      company: formData.company,
      createTicket: true // Auto-create support ticket
    })
  });
  return response.json();
};
```

### User Dashboard Integration
- Users can view their support tickets
- Create new tickets directly
- Add responses to existing tickets
- Upload attachments

### Admin Dashboard Integration
- Contact form management interface
- Support ticket dashboard with statistics
- Ticket assignment and status management
- Response and resolution tracking

## Database Migration

Run the following to update your database:

```bash
cd backend
npx prisma db push
npx prisma generate
```

## Email Testing

Test email functionality:
1. Submit a contact form via the API
2. Check email delivery to customer and admin
3. Verify ticket creation and email notifications
4. Test response notifications

## Security Features

1. **Rate Limiting**: Contact form submissions are rate-limited
2. **Input Validation**: All inputs are sanitized and validated
3. **Authentication**: Admin routes require authentication
4. **Permission Checks**: Users can only access their own tickets
5. **Email Security**: Uses app passwords and secure SMTP

## Monitoring

- All contact forms and tickets are logged
- Email delivery status is tracked
- Error handling for failed email sends
- Analytics for form conversion rates

This implementation provides a complete customer support solution with professional email notifications and comprehensive ticket management capabilities.