#!/usr/bin/env node
/**
 * IAMAI Global - Complete System Verification Script
 * Verifies: Backend .env, Frontend .env, Database, Stripe Products/Prices
 */

require('dotenv').config();
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const fs = require('fs');
const path = require('path');

const AGENTS = [
  'AIGirlfriend', 'AgentX', 'AutoChat', 'CVSmash', 'ChatRevive', 
  'ComedyChad', 'CoolKyle', 'EmoAI', 'FlirtyFiona', 'GamerGary',
  'LazyLarry', 'NerdyNeil', 'PDFMind', 'SassySarah', 'TokBoost',
  'YouGen', 'ZenMasterZara'
];

const PLANS = ['DAILY', 'WEEKLY', 'MONTHLY'];

async function main() {
  console.log('\n🔍 IAMAI GLOBAL - COMPLETE SYSTEM VERIFICATION\n');
  console.log('='.repeat(80));
  
  // 1. Verify Backend .env
  console.log('\n📋 STEP 1: Backend .env Verification');
  console.log('-'.repeat(80));
  const backendIssues = verifyBackendEnv();
  
  // 2. Verify Frontend .env
  console.log('\n📋 STEP 2: Frontend .env Verification');
  console.log('-'.repeat(80));
  const frontendIssues = verifyFrontendEnv();
  
  // 3. Verify Stripe Products & Prices
  console.log('\n📋 STEP 3: Stripe Products & Prices Verification');
  console.log('-'.repeat(80));
  const stripeIssues = await verifyStripe();
  
  // 4. Summary
  console.log('\n' + '='.repeat(80));
  console.log('📊 VERIFICATION SUMMARY');
  console.log('='.repeat(80));
  
  const totalIssues = backendIssues + frontendIssues + stripeIssues;
  
  if (totalIssues === 0) {
    console.log('\n✅ ALL SYSTEMS VERIFIED - PRODUCTION READY!');
  } else {
    console.log(`\n⚠️  FOUND ${totalIssues} ISSUES - NEEDS FIXING`);
    console.log('\n📝 Action Items:');
    console.log('   1. Fix missing/incorrect environment variables');
    console.log('   2. Archive old Stripe products (first set)');
    console.log('   3. Update frontend .env to match backend');
    console.log('   4. Re-run this script to verify');
  }
  
  console.log('\n' + '='.repeat(80) + '\n');
}

function verifyBackendEnv() {
  let issues = 0;
  
  // Check required base variables
  const requiredVars = [
    'NODE_ENV', 'PORT', 'API_URL', 'MONGODB_URI', 
    'STRIPE_SECRET_KEY', 'STRIPE_PUBLISHABLE_KEY'
  ];
  
  requiredVars.forEach(v => {
    if (!process.env[v]) {
      console.log(`❌ Missing: ${v}`);
      issues++;
    } else {
      console.log(`✅ Found: ${v}`);
    }
  });
  
  // Check agent-specific Stripe vars
  console.log(`\n   Checking ${AGENTS.length} agents × 3 plans = ${AGENTS.length * 3 * 2} Stripe vars...`);
  
  let missingProducts = 0;
  let missingPrices = 0;
  
  AGENTS.forEach(agent => {
    PLANS.forEach(plan => {
      const productKey = `STRIPE_PRODUCT_${agent.toUpperCase()}_${plan}`;
      const priceKey = `STRIPE_PRICE_${agent.toUpperCase()}_${plan}`;
      
      if (!process.env[productKey]) missingProducts++;
      if (!process.env[priceKey]) missingPrices++;
    });
  });
  
  if (missingProducts === 0) {
    console.log(`   ✅ All ${AGENTS.length * 3} agent products found`);
  } else {
    console.log(`   ❌ Missing ${missingProducts} product IDs`);
    issues += missingProducts;
  }
  
  if (missingPrices === 0) {
    console.log(`   ✅ All ${AGENTS.length * 3} agent prices found`);
  } else {
    console.log(`   ❌ Missing ${missingPrices} price IDs`);
    issues += missingPrices;
  }
  
  return issues;
}

function verifyFrontendEnv() {
  let issues = 0;
  
  const frontendEnvPath = path.join(__dirname, '..', '.env.production');
  
  if (!fs.existsSync(frontendEnvPath)) {
    console.log('❌ Frontend .env.production not found');
    return 1;
  }
  
  const frontendEnv = fs.readFileSync(frontendEnvPath, 'utf8');
  
  // Check VITE_API_URL
  if (frontendEnv.includes('VITE_API_URL=/api')) {
    console.log('✅ VITE_API_URL correctly set to /api');
  } else if (frontendEnv.includes('VITE_API_URL=https://iamai.global/api')) {
    console.log('❌ VITE_API_URL has double /api (should be /api only)');
    issues++;
  } else {
    console.log('⚠️  VITE_API_URL not found or incorrect');
    issues++;
  }
  
  // Check Stripe publishable key
  if (frontendEnv.includes('VITE_STRIPE_PUBLISHABLE_KEY=pk_')) {
    console.log('✅ VITE_STRIPE_PUBLISHABLE_KEY found');
  } else {
    console.log('❌ VITE_STRIPE_PUBLISHABLE_KEY missing');
    issues++;
  }
  
  return issues;
}

async function verifyStripe() {
  let issues = 0;
  
  try {
    // Get all products
    const products = await stripe.products.list({ limit: 200, active: true });
    console.log(`   Found ${products.data.length} active products in Stripe`);
    
    // Count duplicates
    const productNames = {};
    products.data.forEach(p => {
      const name = p.name;
      productNames[name] = (productNames[name] || 0) + 1;
    });
    
    const duplicates = Object.entries(productNames).filter(([_, count]) => count > 1);
    
    if (duplicates.length > 0) {
      console.log(`\n   ⚠️  Found ${duplicates.length} duplicate product names:`);
      duplicates.slice(0, 5).forEach(([name, count]) => {
        console.log(`      - "${name}" appears ${count} times`);
      });
      console.log(`   💡 Recommendation: Archive old products to keep Stripe clean`);
      issues += duplicates.length;
    } else {
      console.log('   ✅ No duplicate products found');
    }
    
    // Get all prices
    const prices = await stripe.prices.list({ limit: 200, active: true });
    console.log(`   Found ${prices.data.length} active prices in Stripe`);
    
    // Verify each agent has products & prices
    console.log(`\n   Verifying ${AGENTS.length} agents have Stripe products...`);
    
    AGENTS.forEach(agent => {
      const agentProducts = products.data.filter(p => 
        p.name.toLowerCase().includes(agent.toLowerCase())
      );
      
      if (agentProducts.length === 0) {
        console.log(`   ❌ ${agent}: No products found in Stripe`);
        issues++;
      } else if (agentProducts.length > 3) {
        console.log(`   ⚠️  ${agent}: ${agentProducts.length} products (expected 3, has duplicates)`);
      } else {
        console.log(`   ✅ ${agent}: ${agentProducts.length} products`);
      }
    });
    
  } catch (error) {
    console.log(`❌ Stripe API Error: ${error.message}`);
    issues++;
  }
  
  return issues;
}

main().catch(console.error);
