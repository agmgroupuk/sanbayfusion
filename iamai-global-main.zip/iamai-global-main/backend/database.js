// MongoDB Database Connection and Configuration
const mongoose = require('mongoose');

// Connection state
let isConnected = false;

// MongoDB connection options
const options = {
  maxPoolSize: 10,
  minPoolSize: 5,
  socketTimeoutMS: 45000,
  serverSelectionTimeoutMS: 5000,
  family: 4, // Use IPv4
  retryWrites: true,
  w: 'majority',
  autoIndex: false, // Don't auto-create indexes (prevents empty collection creation)
  autoCreate: false, // Don't auto-create collections
};

/**
 * Connect to MongoDB
 */
async function connectDB() {
  if (isConnected) {
    return mongoose.connection;
  }

  try {
    const mongoUri = process.env.MONGODB_URI;

    if (!mongoUri) {
      throw new Error('MONGODB_URI is not defined in environment variables');
    }

    const conn = await mongoose.connect(mongoUri, options);

    isConnected = conn.connection.readyState === 1;

    // Handle connection events
    mongoose.connection.on('error', err => {
      console.error('❌ MongoDB connection error:', err);
      isConnected = false;
    });

    mongoose.connection.on('disconnected', () => {
      console.log('⚠️  MongoDB disconnected');
      isConnected = false;
    });

    mongoose.connection.on('reconnected', () => {
      console.log('✅ MongoDB reconnected');
      isConnected = true;
    });

    // Graceful shutdown
    process.on('SIGINT', async () => {
      try {
        await mongoose.connection.close();
        console.log('🛑 MongoDB connection closed through app termination');
        process.exit(0);
      } catch (err) {
        console.error('Error closing MongoDB connection:', err);
        process.exit(1);
      }
    });

    return conn.connection;
  } catch (error) {
    console.error('❌ MongoDB connection error:', error.message);
    isConnected = false;
    throw error;
  }
}

/**
 * Sync indexes for essential models only
 * Call this after connection to ensure indexes exist for collections we use
 */
async function syncEssentialIndexes() {
  try {
    const User = mongoose.model('User');
    const AgentPurchase = mongoose.model('AgentPurchase');
    const ActivityLog = mongoose.model('ActivityLog');
    
    // Sync indexes only for models we actively use
    await User.syncIndexes();
    await AgentPurchase.syncIndexes();
    await ActivityLog.syncIndexes();
    
    console.log('✅ Essential indexes synchronized');
  } catch (error) {
    console.warn('⚠️ Index sync warning:', error.message);
  }
}

/**
 * Disconnect from MongoDB
 */
async function disconnectDB() {
  if (!isConnected) {
    return;
  }

  try {
    await mongoose.connection.close();
    isConnected = false;
    console.log('🛑 MongoDB disconnected');
  } catch (error) {
    console.error('Error disconnecting from MongoDB:', error);
    throw error;
  }
}

/**
 * Get connection status
 */
function getConnectionStatus() {
  return {
    isConnected,
    readyState: mongoose.connection.readyState,
    states: {
      0: 'disconnected',
      1: 'connected',
      2: 'connecting',
      3: 'disconnecting',
    },
  };
}

/**
 * Check if database is healthy
 */
async function checkHealth() {
  try {
    if (!isConnected || mongoose.connection.readyState !== 1) {
      return {
        status: 'unhealthy',
        message: 'Database not connected',
        readyState: mongoose.connection.readyState,
      };
    }

    // Ping database
    await mongoose.connection.db.admin().ping();

    return {
      status: 'healthy',
      message: 'Database connection is healthy',
      database: mongoose.connection.name,
      host: mongoose.connection.host,
      readyState: mongoose.connection.readyState,
    };
  } catch (error) {
    return {
      status: 'unhealthy',
      message: error.message,
      readyState: mongoose.connection.readyState,
    };
  }
}

/**
 * Get database statistics
 */
async function getStats() {
  try {
    if (!isConnected) {
      return { error: 'Database not connected' };
    }

    const stats = await mongoose.connection.db.stats();

    return {
      database: mongoose.connection.name,
      collections: stats.collections,
      dataSize: `${(stats.dataSize / 1024 / 1024).toFixed(2)} MB`,
      storageSize: `${(stats.storageSize / 1024 / 1024).toFixed(2)} MB`,
      indexes: stats.indexes,
      indexSize: `${(stats.indexSize / 1024 / 1024).toFixed(2)} MB`,
      objects: stats.objects,
    };
  } catch (error) {
    return { error: error.message };
  }
}

/**
 * Get all collection names in the database
 */
async function getCollections() {
  try {
    // Check if mongoose is connected
    if (mongoose.connection.readyState !== 1) {
      return { error: 'Database not connected' };
    }

    const collections = await mongoose.connection.db.listCollections().toArray();
    const collectionNames = collections.map(col => col.name).sort();

    return {
      database: mongoose.connection.name,
      collections: collectionNames,
      count: collectionNames.length,
    };
  } catch (error) {
    return { error: error.message };
  }
}

/**
 * Get detailed stats for all collections
 */
async function getCollectionStats() {
  try {
    if (mongoose.connection.readyState !== 1) {
      return { error: 'Database not connected' };
    }

    const collections = await mongoose.connection.db.listCollections().toArray();
    const stats = {};

    for (const collection of collections) {
      try {
        const collStats = await mongoose.connection.db.collection(collection.name).stats();
        stats[collection.name] = {
          count: collStats.count || 0,
          size: collStats.size || 0,
        };
      } catch (error) {
        stats[collection.name] = { error: error.message };
      }
    }

    return {
      database: mongoose.connection.name,
      collections: stats,
      totalCollections: collections.length,
    };
  } catch (error) {
    return { error: error.message };
  }
}

module.exports = {
  connectDB,
  disconnectDB,
  syncEssentialIndexes,
  getConnectionStatus,
  checkHealth,
  getStats,
  getCollections,
  getCollectionStats,
  mongoose,
};
