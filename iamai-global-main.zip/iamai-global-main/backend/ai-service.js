const OpenAI = require('openai');
const Anthropic = require('@anthropic-ai/sdk');
const { GoogleGenerativeAI } = require('@google/generative-ai');
const Groq = require('groq-sdk');

/**
 * AI Service - Multi-provider AI integration
 * Primary: OpenAI (GPT-4, GPT-3.5-turbo, DALL-E)
 * Fallback 1: Google Gemini
 * Fallback 2: Anthropic Claude
 * Additional: Stability AI, Replicate, Hugging Face, RunwayML
 */
class AIService {
  constructor() {
    // Initialize all AI providers
    this.initializeProviders();
    
    // Track usage and failures
    this.providerStats = {
      openai: { calls: 0, failures: 0 },
      anthropic: { calls: 0, failures: 0 },
      groq: { calls: 0, failures: 0 }
    };
  }

  /**
   * Get provider priority based on agent's preferred provider
   */
  getProviderPriority(preferredProvider) {
    if (!preferredProvider) {
      // Default fallback order
      return ['openai', 'anthropic', 'groq'];
    }

    // Put preferred provider first, then others as fallback
    const allProviders = ['openai', 'anthropic', 'groq'];
    const priority = [preferredProvider];
    
    // Add remaining providers in default order
    allProviders.forEach(provider => {
      if (provider !== preferredProvider) {
        priority.push(provider);
      }
    });

    return priority;
  }

  initializeProviders() {
    // OpenAI (Primary)
    if (process.env.OPENAI_API_KEY) {
      this.openai = new OpenAI({
        apiKey: process.env.OPENAI_API_KEY
      });
      console.log('✅ OpenAI initialized');
    } else {
      console.warn('⚠️  OpenAI API key not found');
    }

    // Anthropic Claude (Fallback)
    if (process.env.ANTHROPIC_API_KEY) {
      this.anthropic = new Anthropic({
        apiKey: process.env.ANTHROPIC_API_KEY
      });
      console.log('✅ Anthropic Claude initialized');
    } else {
      console.warn('⚠️  Anthropic API key not found');
    }

    // Groq (Fallback)
    if (process.env.GROQ_API_KEY) {
      this.groq = new Groq({
        apiKey: process.env.GROQ_API_KEY
      });
      console.log('✅ Groq initialized');
    } else {
      console.warn('⚠️  Groq API key not found');
    }

    // Additional API Keys (accessible to all agents)
    this.apiKeys = {
      openai: process.env.OPENAI_API_KEY,
      anthropic: process.env.ANTHROPIC_API_KEY,
      groq: process.env.GROQ_API_KEY,
      huggingface: process.env.HUGGINGFACE_API_KEY,
      replicate: process.env.REPLICATE_API_TOKEN
    };
  }

  /**
   * Get available API keys for agent configuration
   */
  getAvailableKeys() {
    return Object.entries(this.apiKeys)
      .filter(([_, key]) => key && key !== 'your_' && !key.includes('your_'))
      .reduce((acc, [provider, key]) => {
        acc[provider] = key;
        return acc;
      }, {});
  }

  /**
   * Main chat completion with automatic fallback
   */
  async chat(messages, options = {}) {
    const {
      model = 'gpt-4',
      temperature = 0.7,
      maxTokens = 2000,
      agentId = 'default',
      stream = false,
      preferredProvider = null
    } = options;

    // Determine provider priority based on agent's preferredProvider
    const providerPriority = this.getProviderPriority(preferredProvider);

    for (const provider of providerPriority) {
      if (!this[provider]) continue; // Skip if provider not initialized

      try {
        console.log(`🤖 [${agentId}] Using ${provider} (${model})`);
        this.providerStats[provider].calls++;

        switch (provider) {
          case 'openai':
            // Cap maxTokens for OpenAI models (some have lower limits)
            const openaiMaxTokens = Math.min(maxTokens, 4096);
            const openaiCompletion = await this.openai.chat.completions.create({
              model: this.mapModelToProvider(model, 'openai'),
              messages: this.formatMessages(messages, 'openai'),
              temperature,
              max_tokens: openaiMaxTokens,
              stream
            });
            return {
              provider: 'openai',
              model: model,
              content: stream ? openaiCompletion : openaiCompletion.choices[0].message.content,
              usage: openaiCompletion.usage,
              finishReason: openaiCompletion.choices[0].finish_reason
            };

          case 'anthropic':
            // Cap maxTokens based on Claude model limits
            const anthropicModel = this.mapModelToProvider(model, 'anthropic');
            let anthropicMaxTokens = maxTokens;
            if (anthropicModel.includes('claude-3-haiku')) {
              anthropicMaxTokens = Math.min(maxTokens, 4096);
            } else if (anthropicModel.includes('claude-3-sonnet') || anthropicModel.includes('claude-3-5-sonnet')) {
              anthropicMaxTokens = Math.min(maxTokens, 8192);
            } else if (anthropicModel.includes('claude-3-opus')) {
              anthropicMaxTokens = Math.min(maxTokens, 4096); // Opus has lower limits
            }
            
            const anthropicMessage = await this.anthropic.messages.create({
              model: anthropicModel,
              max_tokens: anthropicMaxTokens,
              temperature,
              messages: this.formatMessages(messages, 'anthropic')
            });
            return {
              provider: 'anthropic',
              model: anthropicMessage.model,
              content: anthropicMessage.content[0].text,
              usage: {
                prompt_tokens: anthropicMessage.usage.input_tokens,
                completion_tokens: anthropicMessage.usage.output_tokens,
                total_tokens: anthropicMessage.usage.input_tokens + anthropicMessage.usage.output_tokens
              },
              finishReason: anthropicMessage.stop_reason
            };

          case 'groq':
            const groqModel = this.mapModelToProvider(model, 'groq');
            const groqResponse = await this.groq.chat.completions.create({
              model: groqModel,
              messages: this.formatMessages(messages, 'groq'),
              temperature,
              max_tokens: maxTokens
            });
            return {
              provider: 'groq',
              model: groqResponse.model,
              content: groqResponse.choices[0].message.content,
              usage: {
                prompt_tokens: groqResponse.usage.prompt_tokens,
                completion_tokens: groqResponse.usage.completion_tokens,
                total_tokens: groqResponse.usage.total_tokens
              },
              finishReason: groqResponse.choices[0].finish_reason
            };
        }
      } catch (error) {
        console.error(`❌ ${provider} failed: ${error.message}`);
        this.providerStats[provider].failures++;
        // Continue to next provider
      }
    }

    // All providers failed
    throw new Error('All AI providers are unavailable. Please check your API keys and try again.');
  }

  /**
   * Map generic model names to provider-specific models
   */
  mapModelToProvider(model, provider) {
    const modelMap = {
      openai: {
        'gpt-4': 'gpt-4-turbo-preview',
        'gpt-3.5': 'gpt-3.5-turbo',
        'default': 'gpt-4-turbo-preview'
      },
      anthropic: {
        'gpt-4': 'claude-3-haiku-20240307',
        'gpt-3.5': 'claude-3-haiku-20240307',
        'claude-3-opus': 'claude-3-haiku-20240307',
        'claude-3-sonnet': 'claude-3-haiku-20240307',
        'claude-3-haiku': 'claude-3-haiku-20240307',
        'default': 'claude-3-haiku-20240307'
      },
      groq: {
        'gpt-4': 'llama-3.3-70b-versatile',
        'gpt-3.5': 'llama-3.1-8b-instant',
        'default': 'llama-3.3-70b-versatile'
      }
    };

    return modelMap[provider][model] || modelMap[provider]['default'];
  }

  /**
   * Format messages for different providers
   */
  formatMessages(messages, provider) {
    if (provider === 'openai') {
      return messages;
    }

    if (provider === 'anthropic') {
      // Claude format - remove system messages
      return messages
        .filter(msg => msg.role !== 'system')
        .map(msg => ({
          role: msg.role === 'assistant' ? 'assistant' : 'user',
          content: msg.content
        }));
    }

    if (provider === 'groq') {
      // Groq uses OpenAI-compatible format
      return messages;
    }

    return messages;
  }

  /**
   * Generate image using DALL-E or Stability AI
   */
  async generateImage(prompt, options = {}) {
    const {
      size = '1024x1024',
      quality = 'standard',
      n = 1,
      agentId = 'default'
    } = options;

    // Try OpenAI DALL-E first
    if (this.openai) {
      try {
        console.log(`🎨 [${agentId}] Generating image with DALL-E`);
        
        const response = await this.openai.images.generate({
          model: 'dall-e-3',
          prompt,
          n,
          size,
          quality
        });

        return {
          provider: 'openai-dalle',
          images: response.data.map(img => ({
            url: img.url,
            revisedPrompt: img.revised_prompt
          }))
        };
      } catch (error) {
        console.error(`❌ DALL-E failed: ${error.message}`);
      }
    }

    // Fallback to Stability AI if available
    if (this.apiKeys.stabilityai) {
      console.log(`🎨 [${agentId}] Falling back to Stability AI`);
      // TODO: Implement Stability AI integration
      throw new Error('Stability AI integration pending - DALL-E unavailable');
    }

    throw new Error('No image generation providers available');
  }

  /**
   * Get embeddings for semantic search
   */
  async getEmbeddings(text, model = 'text-embedding-ada-002') {
    if (!this.openai) {
      throw new Error('OpenAI is required for embeddings');
    }

    const response = await this.openai.embeddings.create({
      model,
      input: text
    });

    return {
      embedding: response.data[0].embedding,
      model: response.model,
      usage: response.usage
    };
  }

  /**
   * Agent-specific configuration with all API keys
   */
  getAgentConfig(agentId) {
    const baseConfig = {
      agentId,
      availableKeys: this.getAvailableKeys(),
      providers: {
        primary: this.openai ? 'openai' : (this.gemini ? 'gemini' : 'anthropic'),
        fallbacks: []
      }
    };

    if (this.openai) baseConfig.providers.fallbacks.push('openai');
    if (this.gemini) baseConfig.providers.fallbacks.push('gemini');
    if (this.anthropic) baseConfig.providers.fallbacks.push('anthropic');

    return baseConfig;
  }

  /**
   * Get service statistics
   */
  getStats() {
    return {
      providers: this.providerStats,
      availableProviders: {
        openai: !!this.openai,
        gemini: !!this.gemini,
        anthropic: !!this.anthropic
      },
      apiKeys: Object.entries(this.apiKeys).reduce((acc, [key, val]) => {
        acc[key] = !!val && !val.includes('your_');
        return acc;
      }, {})
    };
  }

  /**
   * Stream chat response (for real-time updates)
   */
  async *streamChat(messages, options = {}) {
    const streamOptions = { ...options, stream: true };
    
    if (!this.openai) {
      throw new Error('Streaming only available with OpenAI');
    }

    const stream = await this.openai.chat.completions.create({
      model: this.mapModelToProvider(options.model || 'gpt-4', 'openai'),
      messages: this.formatMessages(messages, 'openai'),
      temperature: options.temperature || 0.7,
      max_tokens: options.maxTokens || 2000,
      stream: true
    });

    for await (const chunk of stream) {
      const content = chunk.choices[0]?.delta?.content || '';
      if (content) {
        yield content;
      }
    }
  }

  /**
   * Validate and test all API keys
   */
  async validateKeys() {
    const results = {};

    // Test OpenAI
    if (this.openai) {
      try {
        await this.openai.models.list();
        results.openai = { valid: true, message: 'OpenAI connected successfully' };
      } catch (error) {
        results.openai = { valid: false, message: error.message };
      }
    }

    // Test Gemini
    if (this.gemini) {
      try {
        const model = this.gemini.getGenerativeModel({ model: 'gemini-pro' });
        await model.generateContent('test');
        results.gemini = { valid: true, message: 'Gemini connected successfully' };
      } catch (error) {
        results.gemini = { valid: false, message: error.message };
      }
    }

    // Test Anthropic
    if (this.anthropic) {
      try {
        await this.anthropic.messages.create({
          model: 'claude-3-sonnet-20240229',
          max_tokens: 10,
          messages: [{ role: 'user', content: 'test' }]
        });
        results.anthropic = { valid: true, message: 'Anthropic connected successfully' };
      } catch (error) {
        results.anthropic = { valid: false, message: error.message };
      }
    }

    return results;
  }
}

// Singleton instance
let aiServiceInstance = null;

function getAIService() {
  if (!aiServiceInstance) {
    aiServiceInstance = new AIService();
  }
  return aiServiceInstance;
}

module.exports = {
  AIService,
  getAIService
};
