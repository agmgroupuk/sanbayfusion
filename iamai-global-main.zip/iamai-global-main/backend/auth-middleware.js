// Authentication Middleware
const authService = require('./auth-service.js');
const { verifyToken, getUserById } = authService;
const { User } = require('./models');

/**
 * Authenticate JWT token middleware
 */
async function authenticate(req, res, next) {
  try {
    console.log('🔐 Auth middleware started');
    // 🛡️ SECURITY UPGRADE: Get token from HttpOnly cookie (primary) or header (fallback)
    let token = req.cookies?.authToken; // HttpOnly cookie (preferred)

    // Fallback to Authorization header for API compatibility
    if (!token) {
      const authHeader = req.headers.authorization;
      if (authHeader && authHeader.startsWith('Bearer ')) {
        token = authHeader.substring(7); // Remove 'Bearer ' prefix
      }
    }

    console.log(
      '🔐 Auth middleware - Token source:',
      token ? (req.cookies?.authToken ? 'Cookie' : 'Header') : 'None'
    );
    console.log('🍪 Available cookies:', Object.keys(req.cookies || {}));
    console.log('🔑 Authorization header present:', !!req.headers.authorization);

    if (!token) {
      console.log('❌ Auth failed: No token in cookie or header');
      return res.status(401).json({
        error: 'Authentication required',
        message: 'No authentication token provided',
      });
    }

    console.log('🔑 Token extracted, length:', token.length);

    // Verify token
    console.log('🔑 Verifying token...');
    const decoded = verifyToken(token);
    console.log('✅ Token verified, user ID:', decoded.id);

    // Get user from database
    console.log('👤 Fetching user from database...');
    const user = await getUserById(decoded.id);
    console.log('👤 User fetched successfully:', user ? user._id : 'null');

    if (!user || !user.isActive) {
      console.log('❌ Auth failed: User not found or inactive');
      return res.status(401).json({
        error: 'Authentication failed',
        message: 'Invalid or inactive user',
      });
    }

    console.log('✅ Auth successful for user:', user.email);

    // Update session activity (async, don't wait for it)
    updateSessionActivity(user._id, req).catch(err =>
      console.error('Failed to update session activity:', err)
    );

    // Attach user to request (ensure valid user ID for both local and global)
    req.user = user;
    req.userId = user._id;

    // Validate user ID is not null (critical for activity tracking)
    if (!req.userId || req.userId.toString() === 'null') {
      console.error('⚠️ User authenticated but has null ID:', user.email);
    }

    next();
  } catch (error) {
    console.log('❌ Auth error:', error.message);
    return res.status(401).json({
      error: 'Authentication failed',
      message: error.message || 'Invalid token',
    });
  }
}

/**
 * Optional authentication - doesn't fail if no token
 */
async function optionalAuth(req, res, next) {
  try {
    const authHeader = req.headers.authorization;

    if (authHeader && authHeader.startsWith('Bearer ')) {
      const token = authHeader.substring(7);
      const decoded = verifyToken(token);
      const user = await getUserById(decoded.id);

      if (user && user.isActive) {
        req.user = user;
        req.userId = user._id;
      }
    }

    next();
  } catch (error) {
    // Continue without authentication
    next();
  }
}

/**
 * Check if user has required tier
 */
function requireTier(...allowedTiers) {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({
        error: 'Authentication required',
      });
    }

    if (!allowedTiers.includes(req.user.tier)) {
      return res.status(403).json({
        error: 'Insufficient permissions',
        message: `This feature requires ${allowedTiers.join(' or ')} tier`,
        currentTier: req.user.tier,
      });
    }

    next();
  };
}

/**
 * Check if user has enough credits
 */
function requireCredits(minimumCredits) {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({
        error: 'Authentication required',
      });
    }

    if (req.user.credits < minimumCredits) {
      return res.status(403).json({
        error: 'Insufficient credits',
        message: `This action requires ${minimumCredits} credits`,
        currentCredits: req.user.credits,
      });
    }

    next();
  };
}

/**
 * Validate request body fields
 */
function validateFields(requiredFields) {
  return (req, res, next) => {
    const missingFields = [];

    requiredFields.forEach(field => {
      if (!req.body[field]) {
        missingFields.push(field);
      }
    });

    if (missingFields.length > 0) {
      return res.status(400).json({
        error: 'Validation error',
        message: `Missing required fields: ${missingFields.join(', ')}`,
      });
    }

    next();
  };
}

/**
 * Validate email format
 */
function validateEmail(email) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

/**
 * Validate password strength
 */
function validatePassword(password) {
  if (password.length < 8) {
    return { valid: false, message: 'Password must be at least 8 characters long' };
  }

  if (!/[a-z]/.test(password)) {
    return { valid: false, message: 'Password must contain at least one lowercase letter' };
  }

  if (!/[A-Z]/.test(password)) {
    return { valid: false, message: 'Password must contain at least one uppercase letter' };
  }

  if (!/[0-9]/.test(password)) {
    return { valid: false, message: 'Password must contain at least one number' };
  }

  return { valid: true };
}

/**
 * Rate limiting by user
 */
const userRateLimits = new Map();

function rateLimitByUser(maxRequests = 10, windowMs = 60000) {
  return (req, res, next) => {
    if (!req.user) {
      return next();
    }

    const userId = req.user._id.toString();
    const now = Date.now();

    if (!userRateLimits.has(userId)) {
      userRateLimits.set(userId, []);
    }

    const requests = userRateLimits.get(userId);

    // Remove old requests outside the window
    const recentRequests = requests.filter(time => now - time < windowMs);

    if (recentRequests.length >= maxRequests) {
      return res.status(429).json({
        error: 'Too many requests',
        message: `Maximum ${maxRequests} requests per minute`,
        retryAfter: Math.ceil((recentRequests[0] + windowMs - now) / 1000),
      });
    }

    recentRequests.push(now);
    userRateLimits.set(userId, recentRequests);

    next();
  };
}

/**
 * Update session activity for active session tracking
 */
async function updateSessionActivity(userId, req, retryCount = 0) {
  const maxRetries = 3;
  const baseDelay = 100; // 100ms

  try {
    const cookieSessionId = req.cookies?.sessionId;

    // If no sessionId cookie, we can't track the session
    if (!cookieSessionId) {
      return;
    }

    const user = await User.findById(userId);
    if (!user) {
      return;
    }

    if (!user.security) {
      user.security = {};
    }
    if (!Array.isArray(user.security.activeSessions)) {
      user.security.activeSessions = [];
    }

    // Find matching session by sessionId and update lastActive
    let sessionFound = false;
    for (let session of user.security.activeSessions) {
      if (session.sessionId === cookieSessionId) {
        session.lastActive = new Date();
        sessionFound = true;
        break;
      }
    }

    // Only update existing sessions here; new sessions are created on signin
    if (sessionFound) {
      await user.save();
    }
  } catch (error) {
    // Retry on version conflicts
    if (error.name === 'VersionError' && retryCount < maxRetries) {
      const delay = baseDelay * Math.pow(2, retryCount); // Exponential backoff
      console.log(
        `Version conflict detected, retrying in ${delay}ms (attempt ${retryCount + 1}/${maxRetries})`
      );
      await new Promise(resolve => setTimeout(resolve, delay));
      return updateSessionActivity(userId, req, retryCount + 1);
    }

    console.error('Error updating session activity:', error);
  }
}

module.exports = {
  authenticate,
  optionalAuth,
  requireTier,
  requireCredits,
  validateFields,
  validateEmail,
  validatePassword,
  rateLimitByUser,
};
