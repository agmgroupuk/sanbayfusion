/**
 * 🚀 Caching Configuration
 * Multi-layer caching system for improved performance
 */

const NodeCache = require('node-cache');
const redis = require('redis');

// Memory cache for frequently accessed data
const memoryCache = new NodeCache({
  stdTTL: 300, // 5 minutes default TTL
  checkperiod: 60, // Check for expired keys every 60 seconds
  maxKeys: 1000, // Maximum number of keys
});

// Redis cache for distributed caching (if available)
let redisClient = null;

const initializeRedis = async () => {
  if (process.env.REDIS_URL) {
    try {
      redisClient = redis.createClient({
        url: process.env.REDIS_URL,
        socket: {
          connectTimeout: 5000,
          lazyConnect: true,
        },
      });

      await redisClient.connect();
      console.log('✅ Redis cache connected');
    } catch (error) {
      console.warn('⚠️ Redis connection failed, using memory cache only:', error.message);
      redisClient = null;
    }
  }
};

// Cache keys and TTL configurations
const CACHE_KEYS = {
  USER_PROFILE: userId => `user:profile:${userId}`,
  USER_SUBSCRIPTION: userId => `user:subscription:${userId}`,
  USER_USAGE: userId => `user:usage:${userId}`,
  AGENT_LIST: 'agents:list',
  SUBSCRIPTION_PLANS: 'subscription:plans',
  ANALYTICS_DASHBOARD: userId => `analytics:dashboard:${userId}`,
  CHAT_HISTORY: (userId, page) => `chat:history:${userId}:${page}`,
};

const CACHE_TTL = {
  USER_PROFILE: 600, // 10 minutes
  USER_SUBSCRIPTION: 300, // 5 minutes
  USER_USAGE: 180, // 3 minutes
  AGENT_LIST: 3600, // 1 hour
  SUBSCRIPTION_PLANS: 7200, // 2 hours
  ANALYTICS_DASHBOARD: 900, // 15 minutes
  CHAT_HISTORY: 300, // 5 minutes
};

// Cache operations
const cacheOps = {
  // Get data from cache (memory first, then Redis)
  get: async key => {
    // Try memory cache first
    let data = memoryCache.get(key);
    if (data !== undefined) {
      return data;
    }

    // Try Redis if available
    if (redisClient) {
      try {
        const redisData = await redisClient.get(key);
        if (redisData) {
          data = JSON.parse(redisData);
          // Store in memory cache for faster future access
          memoryCache.set(key, data, CACHE_TTL[key.split(':')[0].toUpperCase()] || 300);
          return data;
        }
      } catch (error) {
        console.warn('Redis get error:', error.message);
      }
    }

    return null;
  },

  // Set data in cache
  set: async (key, data, ttl = 300) => {
    // Store in memory cache
    memoryCache.set(key, data, ttl);

    // Store in Redis if available
    if (redisClient) {
      try {
        await redisClient.setEx(key, ttl, JSON.stringify(data));
      } catch (error) {
        console.warn('Redis set error:', error.message);
      }
    }
  },

  // Delete from cache
  del: async key => {
    // Delete from memory cache
    memoryCache.del(key);

    // Delete from Redis if available
    if (redisClient) {
      try {
        await redisClient.del(key);
      } catch (error) {
        console.warn('Redis del error:', error.message);
      }
    }
  },

  // Clear all cache
  flush: async () => {
    // Clear memory cache
    memoryCache.flushAll();

    // Clear Redis if available
    if (redisClient) {
      try {
        await redisClient.flushAll();
      } catch (error) {
        console.warn('Redis flush error:', error.message);
      }
    }
  },

  // Get cache statistics
  stats: () => {
    const memoryStats = memoryCache.getStats();
    return {
      memory: {
        keys: memoryStats.keys,
        hits: memoryStats.hits,
        misses: memoryStats.misses,
        ksize: memoryStats.ksize,
        vsize: memoryStats.vsize,
      },
      redis: redisClient ? 'connected' : 'disabled',
    };
  },
};

// Cache middleware for Express routes
const cacheMiddleware = (keyFn, ttl = 300) => {
  return async (req, res, next) => {
    const key = typeof keyFn === 'function' ? keyFn(req) : keyFn;

    try {
      const cachedData = await cacheOps.get(key);
      if (cachedData) {
        return res.json(cachedData);
      }

      // Store original json method
      const originalJson = res.json;

      // Override json method to cache response
      res.json = function (data) {
        cacheOps.set(key, data, ttl);
        return originalJson.call(this, data);
      };

      next();
    } catch (error) {
      console.warn('Cache middleware error:', error.message);
      next();
    }
  };
};

// Cache invalidation helpers
const cacheInvalidation = {
  // Invalidate user-related cache
  invalidateUser: async userId => {
    const keys = [
      CACHE_KEYS.USER_PROFILE(userId),
      CACHE_KEYS.USER_SUBSCRIPTION(userId),
      CACHE_KEYS.USER_USAGE(userId),
      CACHE_KEYS.ANALYTICS_DASHBOARD(userId),
    ];

    for (const key of keys) {
      await cacheOps.del(key);
    }
  },

  // Invalidate subscription-related cache
  invalidateSubscription: async userId => {
    await cacheOps.del(CACHE_KEYS.USER_SUBSCRIPTION(userId));
    await cacheOps.del(CACHE_KEYS.SUBSCRIPTION_PLANS);
  },

  // Invalidate analytics cache
  invalidateAnalytics: async userId => {
    await cacheOps.del(CACHE_KEYS.ANALYTICS_DASHBOARD(userId));
    await cacheOps.del(CACHE_KEYS.USER_USAGE(userId));
  },
};

module.exports = {
  initializeRedis,
  cacheOps,
  cacheMiddleware,
  cacheInvalidation,
  CACHE_KEYS,
  CACHE_TTL,
};
