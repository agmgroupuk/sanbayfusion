const express = require('express');
const mongoose = require('mongoose');
const { agentDataManager } = require('./agent-data-manager.js');
const { AgentRegistry } = require('./agent-collections.js');

const router = express.Router();

// ============================================
// AGENT COLLECTION MANAGEMENT API
// Serve agents from database with individual collections
// ============================================

// Initialize agent data manager
let managerInitialized = false;
const initializeManager = async () => {
  if (!managerInitialized) {
    await agentDataManager.initialize();
    managerInitialized = true;
  }
};

// =====================================================================
// AGENT DISCOVERY AND DATABASE SERVING
// =====================================================================

// Get all agents from database registry
router.get('/agents', async (req, res) => {
  try {
    await initializeManager();
    
    const agents = await agentDataManager.getAllAgents();
    
    res.json({
      success: true,
      agents: agents.map(agent => ({
        id: agent.agentId,
        name: agent.agentName,
        displayName: agent.displayName,
        description: agent.description,
        category: agent.category,
        collectionName: agent.collectionName,
        
        // Agent Configuration
        personality: agent.config.personality,
        capabilities: agent.config.capabilities,
        pricing: agent.config.pricing,
        
        // Statistics
        stats: {
          totalUsers: agent.stats.totalUsers,
          activeSubscriptions: agent.stats.activeSubscriptions,
          totalMessages: agent.stats.totalMessages,
          totalRevenue: agent.stats.totalRevenue,
          avgRating: agent.stats.avgRating
        },
        
        // Status
        isActive: agent.isActive,
        isAvailable: agent.isAvailable,
        
        // Metadata
        createdAt: agent.metadata.createdAt,
        lastStatsUpdate: agent.stats.lastStatsUpdate
      })),
      totalAgents: agents.length,
      systemNote: "Each agent has its own dedicated MongoDB collection"
    });
    
  } catch (error) {
    console.error('Error fetching agents from database:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Failed to fetch agents from database',
      error: error.message 
    });
  }
});

// Get specific agent details from database
router.get('/agent/:agentId', async (req, res) => {
  try {
    await initializeManager();
    const { agentId } = req.params;
    
    const agent = await AgentRegistry.findOne({ agentId, isActive: true });
    
    if (!agent) {
      return res.status(404).json({ 
        success: false, 
        message: 'Agent not found' 
      });
    }
    
    res.json({
      success: true,
      agent: {
        id: agent.agentId,
        name: agent.agentName,
        displayName: agent.displayName,
        description: agent.description,
        category: agent.category,
        collectionName: agent.collectionName,
        config: agent.config,
        stats: agent.stats,
        isActive: agent.isActive,
        isAvailable: agent.isAvailable,
        metadata: agent.metadata
      }
    });
    
  } catch (error) {
    console.error('Error fetching agent details:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Failed to fetch agent details',
      error: error.message 
    });
  }
});

// =====================================================================
// AGENT COLLECTION DATA MANAGEMENT
// =====================================================================

// Get user's data for specific agent from its collection
router.get('/user/:userId/agent/:agentId/data', async (req, res) => {
  try {
    await initializeManager();
    const { userId, agentId } = req.params;
    
    const userData = await agentDataManager.getUserAgentData(userId, agentId);
    
    res.json({
      success: true,
      userData: {
        userId: userData.userId,
        agentId: userData.agentId,
        subscription: userData.subscription,
        
        // Summary counts
        totalChats: userData.chats.length,
        totalSessions: userData.sessions.length,
        totalActivities: userData.activities.length,
        totalTransactions: userData.transactions.length,
        
        // Recent activity
        recentChats: userData.chats.slice(-5),
        recentSessions: userData.sessions.slice(-3),
        recentActivities: userData.activities.slice(-10),
        
        // Metadata
        createdAt: userData.metadata.createdAt,
        updatedAt: userData.metadata.updatedAt,
        lastActivity: userData.subscription.lastActivity
      },
      collectionName: `${agentId}-data`
    });
    
  } catch (error) {
    console.error('Error fetching user agent data:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Failed to fetch user agent data',
      error: error.message 
    });
  }
});

// Get user's chat history for specific agent
router.get('/user/:userId/agent/:agentId/chats', async (req, res) => {
  try {
    await initializeManager();
    const { userId, agentId } = req.params;
    const { limit = 50, offset = 0 } = req.query;
    
    const userData = await agentDataManager.getUserAgentData(userId, agentId);
    
    const chats = userData.chats
      .sort((a, b) => new Date(b.message.timestamp) - new Date(a.message.timestamp))
      .slice(parseInt(offset), parseInt(offset) + parseInt(limit));
    
    res.json({
      success: true,
      chats,
      totalChats: userData.chats.length,
      pagination: {
        limit: parseInt(limit),
        offset: parseInt(offset),
        hasMore: userData.chats.length > parseInt(offset) + parseInt(limit)
      },
      agentInfo: {
        agentId,
        collectionName: `${agentId}-data`
      }
    });
    
  } catch (error) {
    console.error('Error fetching agent chat history:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Failed to fetch agent chat history',
      error: error.message 
    });
  }
});

// Get user's sessions for specific agent
router.get('/user/:userId/agent/:agentId/sessions', async (req, res) => {
  try {
    await initializeManager();
    const { userId, agentId } = req.params;
    
    const userData = await agentDataManager.getUserAgentData(userId, agentId);
    
    const sessions = userData.sessions
      .sort((a, b) => new Date(b.startTime) - new Date(a.startTime));
    
    res.json({
      success: true,
      sessions,
      totalSessions: sessions.length,
      activeSession: sessions.find(s => s.isActive),
      agentInfo: {
        agentId,
        collectionName: `${agentId}-data`
      }
    });
    
  } catch (error) {
    console.error('Error fetching agent sessions:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Failed to fetch agent sessions',
      error: error.message 
    });
  }
});

// =====================================================================
// AGENT SUBSCRIPTION MANAGEMENT (INDIVIDUAL COLLECTIONS)
// =====================================================================

// Subscribe user to specific agent (creates entry in agent's collection)
router.post('/user/:userId/agent/:agentId/subscribe', async (req, res) => {
  try {
    await initializeManager();
    const { userId, agentId } = req.params;
    const { plan, paymentData } = req.body;
    
    if (!plan || !['daily', 'weekly', 'monthly'].includes(plan)) {
      return res.status(400).json({ 
        success: false, 
        message: 'Valid plan (daily, weekly, monthly) is required' 
      });
    }
    
    // Get pricing
    const pricingMap = {
      daily: { amount: 1, period: 'day' },
      weekly: { amount: 5, period: 'week' },
      monthly: { amount: 19, period: 'month' }
    };
    
    const subscriptionData = {
      plan,
      pricing: pricingMap[plan],
      billing: {
        stripeCustomerId: paymentData?.stripeCustomerId,
        stripeSubscriptionId: paymentData?.stripeSubscriptionId,
        startDate: new Date(),
        currentPeriodStart: new Date(),
        currentPeriodEnd: new Date(Date.now() + (plan === 'daily' ? 24*60*60*1000 : 
                                                 plan === 'weekly' ? 7*24*60*60*1000 : 
                                                 30*24*60*60*1000)),
        nextBillingDate: new Date(Date.now() + (plan === 'daily' ? 24*60*60*1000 : 
                                               plan === 'weekly' ? 7*24*60*60*1000 : 
                                               30*24*60*60*1000))
      },
      limits: {
        messagesPerDay: 100,
        messagesPerWeek: 500,
        messagesPerMonth: 2000,
        features: ['basic-chat', 'personality-mode', 'chat-history']
      }
    };
    
    const userData = await agentDataManager.subscribeToAgent(userId, agentId, subscriptionData);
    
    res.json({
      success: true,
      message: `Successfully subscribed to ${agentId}`,
      subscription: userData.subscription,
      agentCollection: `${agentId}-data`,
      userData: {
        userId: userData.userId,
        agentId: userData.agentId,
        subscriptionId: userData.subscription.id,
        plan: userData.subscription.plan,
        status: userData.subscription.status,
        nextBilling: userData.subscription.billing.nextBillingDate
      }
    });
    
  } catch (error) {
    console.error('Error subscribing to agent:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Failed to subscribe to agent',
      error: error.message 
    });
  }
});

// Get all user subscriptions across all agents
router.get('/user/:userId/subscriptions', async (req, res) => {
  try {
    await initializeManager();
    const { userId } = req.params;
    
    const subscriptions = await agentDataManager.getUserSubscriptions(userId);
    
    const totalSpent = subscriptions.reduce((sum, sub) => 
      sum + (sub.subscription.billing.totalAmountPaid || 0), 0);
    
    res.json({
      success: true,
      subscriptions: subscriptions.map(sub => ({
        agentId: sub.agentId,
        subscription: sub.subscription,
        lastActivity: sub.lastActivity,
        collectionName: `${sub.agentId}-data`
      })),
      summary: {
        totalActiveAgents: subscriptions.length,
        totalSpent: totalSpent,
        activeSubscriptions: subscriptions.filter(s => s.subscription.status === 'active').length
      },
      systemNote: "Each subscription is stored in agent's individual collection"
    });
    
  } catch (error) {
    console.error('Error fetching user subscriptions:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Failed to fetch user subscriptions',
      error: error.message 
    });
  }
});

// =====================================================================
// AGENT ANALYTICS AND STATISTICS
// =====================================================================

// Get agent analytics from its collection
router.get('/agent/:agentId/analytics', async (req, res) => {
  try {
    await initializeManager();
    const { agentId } = req.params;
    const { timeframe = 'daily' } = req.query;
    
    const analytics = await agentDataManager.getAgentAnalytics(agentId, timeframe);
    const agent = await AgentRegistry.findOne({ agentId });
    
    res.json({
      success: true,
      agentId,
      collectionName: `${agentId}-data`,
      analytics,
      stats: agent?.stats || {},
      timeframe,
      totalRecords: analytics.length
    });
    
  } catch (error) {
    console.error('Error fetching agent analytics:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Failed to fetch agent analytics',
      error: error.message 
    });
  }
});

// Get system-wide statistics across all agent collections
router.get('/system/stats', async (req, res) => {
  try {
    await initializeManager();
    
    const agents = await AgentRegistry.find({ isActive: true });
    
    const systemStats = {
      totalAgents: agents.length,
      totalUsers: 0,
      totalActiveSubscriptions: 0,
      totalMessages: 0,
      totalRevenue: 0,
      agentBreakdown: []
    };
    
    for (const agent of agents) {
      systemStats.totalUsers += agent.stats.totalUsers || 0;
      systemStats.totalActiveSubscriptions += agent.stats.activeSubscriptions || 0;
      systemStats.totalMessages += agent.stats.totalMessages || 0;
      systemStats.totalRevenue += agent.stats.totalRevenue || 0;
      
      systemStats.agentBreakdown.push({
        agentId: agent.agentId,
        name: agent.displayName,
        collectionName: agent.collectionName,
        users: agent.stats.totalUsers || 0,
        subscriptions: agent.stats.activeSubscriptions || 0,
        messages: agent.stats.totalMessages || 0,
        revenue: agent.stats.totalRevenue || 0,
        rating: agent.stats.avgRating || 0
      });
    }
    
    res.json({
      success: true,
      systemStats,
      timestamp: new Date(),
      note: "Data aggregated from individual agent collections"
    });
    
  } catch (error) {
    console.error('Error fetching system stats:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Failed to fetch system statistics',
      error: error.message 
    });
  }
});

// =====================================================================
// CHAT INTEGRATION WITH AGENT COLLECTIONS
// =====================================================================

// Add chat message to agent collection (while maintaining existing flow)
router.post('/user/:userId/agent/:agentId/chat', async (req, res) => {
  try {
    await initializeManager();
    const { userId, agentId } = req.params;
    const { message, sessionId, response, metadata } = req.body;
    
    if (!message) {
      return res.status(400).json({ 
        success: false, 
        message: 'Message content is required' 
      });
    }
    
    const chatData = {
      sessionId: sessionId || `session_${Date.now()}`,
      message: {
        content: message,
        role: 'user',
        timestamp: new Date(),
        tokens: metadata?.tokens || {}
      },
      response: response ? {
        content: response,
        timestamp: new Date(),
        processingTime: metadata?.processingTime || 0,
        tokens: metadata?.responseTokens || {}
      } : null,
      metadata: metadata || {}
    };
    
    const userData = await agentDataManager.addChatToAgent(userId, agentId, chatData);
    
    res.json({
      success: true,
      message: 'Chat added to agent collection',
      agentCollection: `${agentId}-data`,
      chatAdded: true,
      userData: {
        userId: userData.userId,
        agentId: userData.agentId,
        totalChats: userData.chats.length,
        messagesUsed: userData.subscription.usage.messagesUsed,
        lastActivity: userData.subscription.lastActivity
      }
    });
    
  } catch (error) {
    console.error('Error adding chat to agent collection:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Failed to add chat to agent collection',
      error: error.message 
    });
  }
});

// =====================================================================
// COLLECTION MANAGEMENT
// =====================================================================

// Get collection information for specific agent
router.get('/agent/:agentId/collection/info', async (req, res) => {
  try {
    await initializeManager();
    const { agentId } = req.params;
    
    const AgentData = agentDataManager.getAgentCollection(agentId);
    const collectionStats = await AgentData.collection.stats();
    
    res.json({
      success: true,
      agentId,
      collectionName: `${agentId}-data`,
      stats: {
        documentCount: collectionStats.count,
        dataSize: collectionStats.size,
        storageSize: collectionStats.storageSize,
        avgDocSize: collectionStats.avgObjSize,
        indexCount: collectionStats.nindexes,
        indexSize: collectionStats.totalIndexSize
      },
      indexes: await AgentData.collection.getIndexes(),
      lastModified: new Date()
    });
    
  } catch (error) {
    console.error('Error fetching collection info:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Failed to fetch collection information',
      error: error.message 
    });
  }
});

// =====================================================================
// HEALTH CHECK
// =====================================================================

router.get('/health', async (req, res) => {
  try {
    await initializeManager();
    
    const agents = await AgentRegistry.countDocuments({ isActive: true });
    
    res.json({
      success: true,
      status: 'healthy',
      agentDataManager: {
        initialized: managerInitialized,
        totalAgents: agents,
        collections: `${agents} individual collections created`
      },
      timestamp: new Date()
    });
    
  } catch (error) {
    res.status(500).json({ 
      success: false, 
      status: 'error',
      error: error.message 
    });
  }
});

module.exports = router;