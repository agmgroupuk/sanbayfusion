// MongoDB Models using Mongoose
const mongoose = require('mongoose');
const { Schema } = mongoose;

// Import external models
const UserSession = require('./models/UserSession');
// Unified AgentPurchase model (supersedes models/AgentPurchase.js)
const { AgentPurchase } = require('./agent-purchase-models');

// ============================================
// USER MODEL
// ============================================
const UserSchema = new Schema(
  {
    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
    },
    name: String,
    password: String, // Hashed with bcrypt
    emailVerified: Date,
    image: String,
    firstName: String,
    lastName: String,
    displayName: String, // Friendly display name for UI
    profileImage: String,
    phone: {
      type: String,
      validate: {
        validator: function (v) {
          // Allow empty or valid phone formats
          if (!v) return true;
          return /^\+?[\d\s\-\(\)]{10,}$/.test(v);
        },
        message: 'Phone number must be in valid format',
      },
    }, // User phone number for profile
    bio: {
      type: String,
      maxlength: [500, 'Bio cannot exceed 500 characters'],
    }, // User bio/description
    avatar: String, // User avatar URL

    // Address Information
    address: String, // Street address
    city: String, // City
    country: String, // Country

    stripeCustomerId: String,
    stripeSubscriptionId: String,
    currentPlan: {
      type: String,
      enum: ['NONE', 'DAILY', 'WEEKLY', 'MONTHLY'],
      default: 'NONE',
    },
    subscriptionStatus: {
      type: String,
      enum: ['NONE', 'ACTIVE', 'CANCELLED', 'PAST_DUE'],
      default: 'NONE',
    },
    subscriptionPeriodEnd: Date,
    tier: {
      type: String,
      enum: ['NONE', 'DAILY', 'WEEKLY', 'MONTHLY'],
      default: 'NONE',
    },
    isActive: {
      type: Boolean,
      default: true,
    },

    // User Preferences (Language, timezone, theme)
    preferences: {
      language: {
        type: String,
        default: 'en',
      },
      timezone: {
        type: String,
        default: 'UTC',
      },
      theme: {
        type: String,
        enum: ['light', 'dark', 'midnight', 'ocean', 'forest', 'sunset', 'cyberpunk', 'system'],
        default: 'dark',
      },
      selectedAgent: {
        type: Schema.Types.Mixed,
        default: null,
      },
    },

    // Notification Settings
    notifications: {
      email: {
        type: Boolean,
        default: true,
      },
      sms: {
        type: Boolean,
        default: false,
      },
      browser: {
        type: Boolean,
        default: true,
      },
      // Specific notification types
      chatMessages: {
        type: Boolean,
        default: true,
      },
      agentUpdates: {
        type: Boolean,
        default: true,
      },
      billingAlerts: {
        type: Boolean,
        default: true,
      },
      systemUpdates: {
        type: Boolean,
        default: false,
      },
      marketingEmails: {
        type: Boolean,
        default: false,
      },
    },

    // Privacy & Data Settings
    privacy: {
      profileVisibility: {
        type: String,
        enum: ['public', 'private'],
        default: 'private',
      },
      dataCollection: {
        type: Boolean,
        default: true,
      },
      searchIndexing: {
        type: Boolean,
        default: false,
      },
    },

    // Account Security Status
    security: {
      isSecured: {
        type: Boolean,
        default: true,
      },
      passwordProtected: {
        type: Boolean,
        default: true,
      },
      dataEncrypted: {
        type: Boolean,
        default: true,
      },
      lastSecurityUpdate: {
        type: Date,
        default: Date.now,
      },
      // Two-Factor Authentication
      twoFactorEnabled: {
        type: Boolean,
        default: false,
      },
      twoFactorSecret: String, // TOTP secret
      tempTwoFactorSecret: String, // Temporary secret during setup
      twoFactorEnabledAt: Date, // When 2FA was enabled
      twoFactorDisabledAt: Date, // When 2FA was last disabled
      backupCodes: [String], // Recovery codes (hashed)

      // Password Management
      lastPasswordChange: Date,
      passwordChangeCount: { type: Number, default: 0 },

      // Email Management
      lastEmailChange: Date,
      emailChangeRequest: {
        newEmail: String,
        token: String,
        expiresAt: Date,
        requestedAt: Date,
      },

      // Notification Settings
      notifications: {
        email: { type: Boolean, default: true },
        sms: { type: Boolean, default: false },
      },

      // Login tracking
      lastLoginAt: Date,
      lastLoginIP: String,
      lastLoginUserAgent: String,
      loginAttempts: [
        {
          ip: String,
          userAgent: String,
          success: Boolean,
          timestamp: { type: Date, default: Date.now },
          location: String, // Optional geolocation
        },
      ],
      // Active Sessions
      activeSessions: [
        {
          sessionId: String,
          ip: String, // Client IP address
          userAgent: String,
          createdAt: { type: Date, default: Date.now },
          lastActive: { type: Date, default: Date.now },
          location: String, // Optional geolocation
        },
      ],
    },

    // App Data (localStorage replacement)
    apiKeys: {
      gemini: { type: String, default: '' },
      openai: { type: String, default: '' },
      anthropic: { type: String, default: '' },
    },

    subscriptions: {
      type: Schema.Types.Mixed,
      default: {},
    },

    customAgents: [
      {
        id: {
          type: String,
          required: true,
        },
        name: {
          type: String,
          required: true,
        },
        role: {
          type: String,
          default: 'Custom Agent',
        },
        description: {
          type: String,
          default: '',
        },
        icon: {
          type: String,
          default: 'fa-solid fa-robot',
        },
        capabilities: {
          type: Schema.Types.Mixed,
          default: {},
        },
        personalityMatrix: {
          type: Schema.Types.Mixed,
          default: {},
        },
        voicePreferences: {
          type: Schema.Types.Mixed,
          default: null,
        },
        tags: [String],
        config: {
          type: Schema.Types.Mixed,
          default: {},
        },
        createdAt: {
          type: Date,
          default: Date.now,
        },
        updatedAt: {
          type: Date,
          default: Date.now,
        },
      },
    ],

    // User Statistics for Dashboard
    totalMessages: {
      type: Number,
      default: 0,
    },
    messagesThisMonth: {
      type: Number,
      default: 0,
    },
    agentsUsed: {
      type: Number,
      default: 0,
    },
    activeAgents: {
      type: Number,
      default: 0,
    },
    totalSessionTime: {
      type: Number,
      default: 0,
    },
    lastActive: {
      type: Date,
      default: Date.now,
    },

    metadata: {
      type: Schema.Types.Mixed,
      default: {},
    },
  },
  {
    timestamps: true,
    collection: 'users',
  }
);

// Password hashing middleware
const bcrypt = require('bcryptjs');

UserSchema.pre('save', async function (next) {
  // Only hash the password if it has been modified (or is new)
  if (!this.isModified('password')) return next();

  try {
    // Hash password with cost of 12
    const hashedPassword = await bcrypt.hash(this.password, 12);
    this.password = hashedPassword;
    next();
  } catch (error) {
    next(error);
  }
});

// Compare password method
UserSchema.methods.comparePassword = async function (candidatePassword) {
  try {
    if (!this.password) return false;
    return await bcrypt.compare(candidatePassword, this.password);
  } catch (error) {
    return false;
  }
};

// Indexes
UserSchema.index({ tier: 1 });
UserSchema.index({ createdAt: -1 });
UserSchema.index({ phone: 1 });
UserSchema.index({ stripeCustomerId: 1 });
UserSchema.index({ isActive: 1 });
UserSchema.index({ 'preferences.language': 1 });
UserSchema.index({ 'preferences.timezone': 1 });
UserSchema.index({ email: 1, isActive: 1 });
UserSchema.index({ tier: 1, createdAt: -1 });

// ============================================
// AGENT MODEL
// ============================================
// Using comprehensive Agent model from ./models/Agent.js
// This model includes full schema for: capabilities, cognition, skills,
// personalityMatrix, aiConfig, voiceConfig, pricing, and metadata
const Agent = require('./models/Agent');

// ============================================
// CHAT/CONVERSATION MODEL
// ============================================
const ChatSchema = new Schema(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      default: null, // Nullable for anonymous users
    },
    sessionId: {
      type: String,
      // index created at schema level
    },
    agentId: {
      type: String,
      required: true,
    },
    title: {
      type: String,
      default: 'New Conversation',
    },
    messages: [
      {
        role: {
          type: String,
          enum: ['user', 'assistant', 'system'],
          required: true,
        },
        content: {
          type: String,
          required: true,
        },
        metadata: {
          model: String,
          provider: String,
          tokens: Number,
          attachments: [Schema.Types.Mixed],
          generationTime: Number,
        },
        createdAt: {
          type: Date,
          default: Date.now,
        },
      },
    ],
    isActive: {
      type: Boolean,
      default: true,
    },
    metadata: {
      type: Schema.Types.Mixed,
      default: {},
    },
  },
  {
    timestamps: true,
    collection: 'chats',
  }
);

// Indexes
ChatSchema.index({ userId: 1, createdAt: -1 });
ChatSchema.index({ sessionId: 1, createdAt: -1 });
ChatSchema.index({ agentId: 1 });
ChatSchema.index({ isActive: 1 });
ChatSchema.index({ 'messages.createdAt': -1 });

// ============================================
// MESSAGE MODEL (Individual messages)
// ============================================
const MessageSchema = new Schema(
  {
    chatId: {
      type: Schema.Types.ObjectId,
      ref: 'Chat',
      required: true,
    },
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },
    sessionId: String,
    agentId: String,
    role: {
      type: String,
      enum: ['user', 'assistant', 'system'],
      required: true,
    },
    content: {
      type: String,
      required: true,
    },
    metadata: {
      model: String,
      provider: String,
      tokens: Number,
      attachments: [Schema.Types.Mixed],
      generationTime: Number,
    },
  },
  {
    timestamps: true,
    collection: 'messages',
  }
);

MessageSchema.index({ chatId: 1, createdAt: -1 });
MessageSchema.index({ userId: 1, createdAt: -1 });
MessageSchema.index({ sessionId: 1 });
MessageSchema.index({ role: 1 });

// ============================================
// CONVERSATION MODEL (Alternative to Chat)
// ============================================
const ConversationSchema = new Schema(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },
    sessionId: String,
    agentId: {
      type: String,
      required: true,
    },
    title: {
      type: String,
      default: 'New Conversation',
    },
    summary: String,
    messageCount: {
      type: Number,
      default: 0,
    },
    isActive: {
      type: Boolean,
      default: true,
    },
    lastMessageAt: Date,
    metadata: {
      type: Schema.Types.Mixed,
      default: {},
    },
  },
  {
    timestamps: true,
    collection: 'conversations',
  }
);

ConversationSchema.index({ userId: 1, createdAt: -1 });
ConversationSchema.index({ sessionId: 1 });
ConversationSchema.index({ agentId: 1 });
ConversationSchema.index({ isActive: 1 });
ConversationSchema.index({ lastMessageAt: -1 });

// ============================================
// TRANSACTION MODEL
// ============================================
const TransactionSchema = new Schema(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    type: {
      type: String,
      enum: ['SUBSCRIPTION', 'REFUND'],
      required: true,
    },
    amount: {
      type: Number,
      required: true,
    },
    currency: {
      type: String,
      default: 'usd',
    },
    provider: {
      type: String,
      enum: ['STRIPE', 'PAYPAL'],
    },
    providerId: String,
    providerTransactionId: String,
    status: {
      type: String,
      enum: ['PENDING', 'COMPLETED', 'FAILED', 'REFUNDED'],
      default: 'PENDING',
    },
    description: String,
    metadata: Schema.Types.Mixed,
  },
  {
    timestamps: true,
    collection: 'transactions',
  }
);

// Indexes
TransactionSchema.index({ userId: 1, createdAt: -1 });
TransactionSchema.index({ status: 1 });
TransactionSchema.index({ type: 1 });

// ============================================
// FILE UPLOAD MODEL
// ============================================
const FileUploadSchema = new Schema(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    filename: String,
    originalName: String,
    mimeType: String,
    size: Number,
    url: String,
    s3Key: String,
    s3Bucket: String,
    metadata: Schema.Types.Mixed,
  },
  {
    timestamps: true,
    collection: 'file_uploads',
  }
);

// Indexes
FileUploadSchema.index({ userId: 1, createdAt: -1 });
FileUploadSchema.index({ s3Key: 1 });

// ============================================
// USAGE ANALYTICS MODEL
// ============================================
const UsageAnalyticsSchema = new Schema(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    date: {
      type: String, // Format: YYYY-MM-DD
      required: true,
    },
    messagesCount: {
      type: Number,
      default: 0,
    },
    agentsUsed: [String],
    totalTokens: {
      type: Number,
      default: 0,
    },
    breakdown: {
      openai: { calls: Number, tokens: Number },
      anthropic: { calls: Number, tokens: Number },
      google: { calls: Number, tokens: Number },
    },
  },
  {
    timestamps: true,
    collection: 'usage_analytics',
  }
);

// Indexes
UsageAnalyticsSchema.index({ userId: 1, date: -1 }, { unique: true });
UsageAnalyticsSchema.index({ date: -1 });

// ============================================
// API KEY MODEL
// ============================================
const ApiKeySchema = new Schema(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    name: String,
    keyHash: {
      type: String,
      required: true,
      unique: true,
    },
    keyPrefix: String, // First 8 chars for display
    lastUsed: Date,
    isActive: {
      type: Boolean,
      default: true,
    },
    expiresAt: Date,
    permissions: {
      scopes: [String],
    },
    metadata: Schema.Types.Mixed,
  },
  {
    timestamps: true,
    collection: 'api_keys',
  }
);

// Indexes
ApiKeySchema.index({ userId: 1 });
ApiKeySchema.index({ isActive: 1 });

// ============================================
// SUPPORT TICKET MODEL
// ============================================
const SupportTicketSchema = new Schema(
  {
    ticketNumber: {
      type: String,
      required: true,
      unique: true,
    },
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
    },
    title: {
      type: String,
      required: true,
    },
    description: {
      type: String,
      required: true,
    },
    status: {
      type: String,
      enum: ['OPEN', 'IN_PROGRESS', 'WAITING_FOR_CUSTOMER', 'RESOLVED', 'CLOSED'],
      default: 'OPEN',
    },
    priority: {
      type: String,
      enum: ['LOW', 'NORMAL', 'HIGH', 'URGENT'],
      default: 'NORMAL',
    },
    category: {
      type: String,
      enum: [
        'GENERAL',
        'TECHNICAL',
        'BILLING',
        'FEATURE_REQUEST',
        'BUG_REPORT',
        'ACCOUNT',
        'API',
        'INTEGRATION',
      ],
      default: 'GENERAL',
    },
    source: {
      type: String,
      default: 'web',
    },
    tags: [String],
    assignedTo: String,
    responses: [
      {
        authorId: Schema.Types.ObjectId,
        authorName: String,
        content: String,
        isInternal: Boolean,
        createdAt: { type: Date, default: Date.now },
      },
    ],
    attachments: [
      {
        filename: String,
        originalName: String,
        mimeType: String,
        size: Number,
        url: String,
        uploadedBy: Schema.Types.ObjectId,
        createdAt: { type: Date, default: Date.now },
      },
    ],
    closedAt: Date,
    metadata: Schema.Types.Mixed,
  },
  {
    timestamps: true,
    collection: 'support_tickets',
  }
);

// Indexes
SupportTicketSchema.index({ userId: 1 });
SupportTicketSchema.index({ status: 1 });
SupportTicketSchema.index({ priority: 1 });

// ============================================
// CONTACT FORM MODEL
// ============================================
const ContactFormSchema = new Schema(
  {
    name: {
      type: String,
      required: true,
    },
    email: {
      type: String,
      required: true,
    },
    subject: String,
    message: {
      type: String,
      required: true,
    },
    phone: String,
    company: String,
    source: {
      type: String,
      default: 'website',
    },
    status: {
      type: String,
      enum: ['NEW', 'IN_PROGRESS', 'RESOLVED', 'SPAM'],
      default: 'NEW',
    },
    priority: {
      type: String,
      enum: ['LOW', 'NORMAL', 'HIGH', 'URGENT'],
      default: 'NORMAL',
    },
    processed: {
      type: Boolean,
      default: false,
    },
    assignedTo: String,
    notes: String,
    metadata: Schema.Types.Mixed,
  },
  {
    timestamps: true,
    collection: 'contact_forms',
  }
);

// Indexes
ContactFormSchema.index({ email: 1 });
ContactFormSchema.index({ status: 1 });
ContactFormSchema.index({ createdAt: -1 });

// ============================================
// WEBHOOK EVENT MODEL
// ============================================
const WebhookEventSchema = new Schema(
  {
    type: {
      type: String,
      required: true,
    },
    provider: {
      type: String,
      enum: ['STRIPE', 'PAYPAL'],
      required: true,
    },
    eventId: String,
    data: {
      type: Schema.Types.Mixed,
      required: true,
    },
    processed: {
      type: Boolean,
      default: false,
    },
    processedAt: Date,
    error: String,
    metadata: Schema.Types.Mixed,
  },
  {
    timestamps: true,
    collection: 'webhook_events',
  }
);

// Indexes
WebhookEventSchema.index({ eventId: 1 }, { unique: true, sparse: true });
WebhookEventSchema.index({ processed: 1 });
WebhookEventSchema.index({ createdAt: -1 });

// ============================================
// ACTIVITY LOG MODEL (Comprehensive Tracking)
// ============================================
const ActivityLogSchema = new Schema(
  {
    // User identification (nullable for anonymous users)
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },
    sessionId: {
      type: String,
      required: true,
      default: function () {
        if (this.userId) {
          return `session_${this.userId.toString()}_${Date.now()}`;
        }
        return `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      },
      // index created at schema level
    },

    // Activity details
    action: {
      type: String,
      required: true,
      enum: [
        // Page navigation
        'PAGE_VIEW',
        'PAGE_LOAD',
        // Authentication
        'SIGNUP_ATTEMPT',
        'SIGNUP_SUCCESS',
        'SIGNUP_FAILED',
        'LOGIN_ATTEMPT',
        'LOGIN_SUCCESS',
        'LOGIN_FAILED',
        'LOGOUT',
        // Chat interactions
        'DEMO_CHAT_START',
        'DEMO_CHAT_MESSAGE',
        'DEMO_CHAT_END',
        'AI_CHAT_START',
        'AI_CHAT_MESSAGE',
        'AI_CHAT_END',
        // Studio usage
        'STUDIO_VISIT',
        'STUDIO_INTERACTION',
        'AGENT_SELECTED',
        // Rule tests
        'RULE_TEST_START',
        'RULE_TEST_EXECUTE',
        'RULE_TEST_COMPLETE',
        // API calls
        'API_CALL',
        'API_ERROR',
        // Profile actions
        'PROFILE_UPDATE',
        'PREFERENCES_UPDATE',
        'PASSWORD_CHANGE',
        // Subscriptions
        'SUBSCRIPTION_VIEW',
        'SUBSCRIPTION_UPGRADE',
        'SUBSCRIPTION_CANCEL',
        // WebSocket
        'WS_CONNECT',
        'WS_DISCONNECT',
        'WS_MESSAGE',
        'WS_ERROR',
        // Security Events
        'SECURITY_EVENT',
        'SECURITY_2FA_ENABLED',
        'SECURITY_2FA_DISABLED',
        'SECURITY_PASSWORD_CHANGED',
        'SECURITY_NOTIFICATIONS_UPDATED',
        'SECURITY_SESSIONS_TERMINATED',
        // General
        'BUTTON_CLICK',
        'FORM_SUBMIT',
        'FILE_UPLOAD',
        'SEARCH',
        'ERROR',
      ],
    },

    // Context
    route: String,
    method: String,
    statusCode: Number,
    ipAddress: String,
    userAgent: String,
    referrer: String,

    // Performance
    responseTime: Number, // milliseconds

    // Metadata (flexible)
    metadata: {
      type: Schema.Types.Mixed,
      default: {},
    },

    // Anonymous user info
    isAnonymous: {
      type: Boolean,
      default: false,
    },

    // Geolocation (optional)
    location: {
      country: String,
      city: String,
      region: String,
    },
  },
  {
    timestamps: true,
    collection: 'activity_logs',
  }
);

// Indexes for efficient querying
ActivityLogSchema.index({ userId: 1, createdAt: -1 });
ActivityLogSchema.index({ sessionId: 1, createdAt: -1 });
ActivityLogSchema.index({ action: 1, createdAt: -1 });
ActivityLogSchema.index({ isAnonymous: 1, createdAt: -1 });
ActivityLogSchema.index({ createdAt: -1 });

// ============================================
// VISITOR MODEL (For Tracking)
// ============================================
const VisitorSchema = new Schema(
  {
    sessionId: {
      type: String,
      required: true,
      // index created at schema level
    },
    ipAddress: {
      type: String,
      required: true,
    },
    userAgent: String,
    device: {
      type: {
        type: String,
        enum: ['desktop', 'mobile', 'tablet'],
        default: 'desktop',
      },
      browser: String,
      os: String,
      version: String,
    },
    location: {
      country: String,
      city: String,
      region: String,
      timezone: String,
      coordinates: {
        latitude: Number,
        longitude: Number,
      },
    },
    pages: [
      {
        url: String,
        title: String,
        visitedAt: {
          type: Date,
          default: Date.now,
        },
        timeSpent: Number, // seconds
        referrer: String,
      },
    ],
    totalVisits: {
      type: Number,
      default: 1,
    },
    totalPageViews: {
      type: Number,
      default: 1,
    },
    firstVisit: {
      type: Date,
      default: Date.now,
    },
    lastVisit: {
      type: Date,
      default: Date.now,
    },
    isReturning: {
      type: Boolean,
      default: false,
    },
    source: {
      type: String,
      enum: ['direct', 'search', 'social', 'referral', 'email', 'ads'],
      default: 'direct',
    },
    campaign: {
      source: String,
      medium: String,
      name: String,
      term: String,
      content: String,
    },
    metadata: {
      type: Schema.Types.Mixed,
      default: {},
    },
  },
  {
    timestamps: true,
    collection: 'visitors',
  }
);

// Indexes
VisitorSchema.index({ sessionId: 1 });
VisitorSchema.index({ ipAddress: 1 });
VisitorSchema.index({ 'location.country': 1 });
VisitorSchema.index({ createdAt: -1 });
VisitorSchema.index({ isReturning: 1 });
VisitorSchema.index({ source: 1 });

// ============================================
// ADDITIONAL MODELS FOR MISSING COLLECTIONS
// ============================================

// User Profiles Schema (separate from main User for better organization)
const UserProfileSchema = new Schema(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    displayName: String,
    bio: String,
    avatar: String,
    website: String,
    location: String,
    personalInfo: {
      firstName: String,
      lastName: String,
      phone: String,
      dateOfBirth: Date,
      gender: {
        type: String,
        enum: ['male', 'female', 'other', 'prefer-not-to-say'],
      },
      occupation: String,
      company: String,
      industry: String,
    },
    socialLinks: {
      twitter: String,
      linkedin: String,
      github: String,
      instagram: String,
      youtube: String,
      website: String,
    },
    skills: [String],
    interests: [String],
    languages: [String],
    experience: [
      {
        title: String,
        company: String,
        duration: String,
        description: String,
      },
    ],
    education: [
      {
        degree: String,
        school: String,
        year: String,
        field: String,
      },
    ],
    achievements: [String],
    metadata: {
      type: Schema.Types.Mixed,
      default: {},
    },
  },
  {
    timestamps: true,
    collection: 'userprofiles',
  }
);

// User Auth Schema (OAuth and authentication data)
const UserAuthSchema = new Schema(
  {
    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
    },
    username: {
      type: String,
      unique: true,
      sparse: true,
    },
    passwordHash: String,
    oauth: {
      google: {
        id: String,
        email: String,
        verified: Boolean,
        accessToken: String,
        refreshToken: String,
      },
      facebook: {
        id: String,
        email: String,
        verified: Boolean,
        accessToken: String,
      },
      github: {
        id: String,
        username: String,
        email: String,
        accessToken: String,
      },
      microsoft: {
        id: String,
        email: String,
        verified: Boolean,
        accessToken: String,
      },
    },
    isActive: {
      type: Boolean,
      default: true,
    },
    isEmailVerified: {
      type: Boolean,
      default: false,
    },
    emailVerificationToken: String,
    emailVerificationExpires: Date,
    passwordResetToken: String,
    passwordResetExpires: Date,
    lastLoginAt: Date,
    loginCount: {
      type: Number,
      default: 0,
    },
    failedLoginAttempts: {
      type: Number,
      default: 0,
    },
    accountLockedUntil: Date,
    metadata: {
      type: Schema.Types.Mixed,
      default: {},
    },
  },
  {
    timestamps: true,
    collection: 'user_auth',
  }
);

// User Profiles (separate collection as shown in your database)
const UserProfilesSchema = new Schema(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    personalInfo: {
      displayName: String,
      bio: String,
    },
    text: String, // For compound text index as shown in MongoDB Compass
    metadata: {
      type: Schema.Types.Mixed,
      default: {},
    },
  },
  {
    timestamps: true,
    collection: 'user_profiles',
  }
);

// Two Factor Auth Schema
const TwoFactorAuthSchema = new Schema(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    secret: String, // TOTP secret
    qrCodeUrl: String,
    backupCodes: [String],
    enabled: {
      type: Boolean,
      default: false,
    },
    enabledAt: Date,
    lastUsed: Date,
    lastUsedBackupCode: Date,
    recoveryEmail: String,
    trustedDevices: [
      {
        deviceId: String,
        deviceName: String,
        trustedAt: Date,
        expiresAt: Date,
        ipAddress: String,
        userAgent: String,
      },
    ],
    metadata: {
      type: Schema.Types.Mixed,
      default: {},
    },
  },
  {
    timestamps: true,
    collection: 'two_factor_auth',
  }
);

// Session tracking is handled by UserSession model in models/UserSession.js

// Email Templates Schema
const EmailTemplateSchema = new Schema(
  {
    templateId: {
      type: String,
      required: true,
      unique: true,
    },
    name: {
      type: String,
      required: true,
    },
    subject: {
      type: String,
      required: true,
    },
    htmlContent: {
      type: String,
      required: true,
    },
    textContent: String,
    variables: [String], // List of variables like {{name}}, {{email}}
    category: {
      type: String,
      enum: ['WELCOME', 'VERIFICATION', 'RESET_PASSWORD', 'NOTIFICATION', 'BILLING', 'MARKETING'],
      required: true,
    },
    isActive: {
      type: Boolean,
      default: true,
    },
    metadata: {
      type: Schema.Types.Mixed,
      default: {},
    },
  },
  {
    timestamps: true,
    collection: 'email_templates',
  }
);

// System Settings Schema
const SystemSettingsSchema = new Schema(
  {
    key: {
      type: String,
      required: true,
      unique: true,
    },
    value: {
      type: Schema.Types.Mixed,
      required: true,
    },
    description: String,
    category: {
      type: String,
      enum: ['GENERAL', 'SECURITY', 'BILLING', 'EMAIL', 'AI', 'API'],
      default: 'GENERAL',
    },
    isPublic: {
      type: Boolean,
      default: false,
    },
    lastModified: {
      type: Date,
      default: Date.now,
    },
    modifiedBy: {
      type: Schema.Types.ObjectId,
      ref: 'User',
    },
  },
  {
    timestamps: true,
    collection: 'system_settings',
  }
);

// Indexes for new schemas
UserProfileSchema.index({ userId: 1 });
UserAuthSchema.index({ 'oauth.google.id': 1 });
UserProfilesSchema.index({ userId: 1 });
UserProfilesSchema.index({ 'personalInfo.displayName': 'text', 'personalInfo.bio': 'text' });
TwoFactorAuthSchema.index({ userId: 1 });
// SessionSchema indexes moved to UserSession model
EmailTemplateSchema.index({ category: 1 });
SystemSettingsSchema.index({ category: 1 });

// ============================================
// EXPORT MODELS
// ============================================
const User = mongoose.model('User', UserSchema);
// Agent model imported from ./models/Agent.js (see line ~365)
const Chat = mongoose.model('Chat', ChatSchema);
// Subscription model REMOVED - replaced by AgentPurchase (one-time purchases only)
const Transaction = mongoose.model('Transaction', TransactionSchema);
const FileUpload = mongoose.model('FileUpload', FileUploadSchema);
const UsageAnalytics = mongoose.model('UsageAnalytics', UsageAnalyticsSchema);
const ApiKey = mongoose.model('ApiKey', ApiKeySchema);
const SupportTicket = mongoose.model('SupportTicket', SupportTicketSchema);
const ContactForm = mongoose.model('ContactForm', ContactFormSchema);
const WebhookEvent = mongoose.model('WebhookEvent', WebhookEventSchema);
const ActivityLog = mongoose.model('ActivityLog', ActivityLogSchema);
const Visitor = mongoose.model('Visitor', VisitorSchema);

// Additional Models
const UserProfile = mongoose.model('UserProfile', UserProfileSchema);
const UserAuth = mongoose.model('UserAuth', UserAuthSchema);
const UserProfiles = mongoose.model('UserProfiles', UserProfilesSchema);
const TwoFactorAuth = mongoose.model('TwoFactorAuth', TwoFactorAuthSchema);
// Session model removed - UserSession in models/UserSession.js handles session tracking
const EmailTemplate = mongoose.model('EmailTemplate', EmailTemplateSchema);
const SystemSettings = mongoose.model('SystemSettings', SystemSettingsSchema);

// ============================================
// MISSING COLLECTIONS - DASHBOARD REQUIREMENTS
// ============================================

// ============================================
// USER PREFERENCES MODEL
// ============================================
const UserPreferencesSchema = new Schema(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    theme: {
      type: String,
      enum: ['light', 'dark', 'auto'],
      default: 'dark',
    },
    language: {
      type: String,
      default: 'en',
    },
    timezone: {
      type: String,
      default: 'UTC',
    },
    emailNotifications: {
      type: Boolean,
      default: true,
    },
    pushNotifications: {
      type: Boolean,
      default: false,
    },
    marketingEmails: {
      type: Boolean,
      default: false,
    },
    dataSharing: {
      type: Boolean,
      default: false,
    },
    autoSave: {
      type: Boolean,
      default: true,
    },
    compactMode: {
      type: Boolean,
      default: false,
    },
    dateFormat: {
      type: String,
      default: 'MM/DD/YYYY',
    },
    timeFormat: {
      type: String,
      enum: ['12h', '24h'],
      default: '12h',
    },
  },
  {
    timestamps: true,
    collection: 'user_preferences',
  }
);

UserPreferencesSchema.index({ userId: 1 }, { unique: true });
UserPreferencesSchema.index({ theme: 1 });
UserPreferencesSchema.index({ language: 1 });
UserPreferencesSchema.index({ timezone: 1 });
UserPreferencesSchema.index({ updatedAt: -1 });

// ============================================
// BILLING HISTORY MODEL
// ============================================
const BillingHistorySchema = new Schema(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    invoiceId: {
      type: String,
      required: true,
    },
    date: {
      type: Date,
      required: true,
    },
    description: {
      type: String,
      required: true,
    },
    amount: {
      type: Number,
      required: true,
    },
    currency: {
      type: String,
      default: 'USD',
    },
    status: {
      type: String,
      enum: ['paid', 'pending', 'failed', 'refunded'],
      default: 'pending',
    },
    paymentMethod: {
      type: String,
    },
    subscriptionId: {
      type: Schema.Types.ObjectId,
      ref: 'Subscription',
    },
    metadata: {
      type: Schema.Types.Mixed,
      default: {},
    },
  },
  {
    timestamps: true,
    collection: 'billing_history',
  }
);

BillingHistorySchema.index({ userId: 1, date: -1 });
BillingHistorySchema.index({ invoiceId: 1 }, { unique: true });
BillingHistorySchema.index({ status: 1 });
BillingHistorySchema.index({ userId: 1, status: 1 });
BillingHistorySchema.index({ subscriptionId: 1 });
BillingHistorySchema.index({ currency: 1 });
BillingHistorySchema.index({ amount: 1 });
BillingHistorySchema.index({ createdAt: -1 });

// ============================================
// PAYMENT METHODS MODEL
// ============================================
const PaymentMethodsSchema = new Schema(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    paymentMethodId: {
      type: String,
      required: true,
    },
    type: {
      type: String,
      enum: ['card', 'bank', 'paypal', 'crypto'],
      default: 'card',
    },
    brand: {
      type: String, // visa, mastercard, etc.
    },
    last4: {
      type: String,
    },
    expiryMonth: {
      type: Number,
    },
    expiryYear: {
      type: Number,
    },
    isDefault: {
      type: Boolean,
      default: false,
    },
    isActive: {
      type: Boolean,
      default: true,
    },
    metadata: {
      type: Schema.Types.Mixed,
      default: {},
    },
  },
  {
    timestamps: true,
    collection: 'payment_methods',
  }
);

PaymentMethodsSchema.index({ userId: 1 });
PaymentMethodsSchema.index({ paymentMethodId: 1 }, { unique: true });
PaymentMethodsSchema.index({ userId: 1, isDefault: 1 });
PaymentMethodsSchema.index({ userId: 1, isActive: 1 });
PaymentMethodsSchema.index({ type: 1 });
PaymentMethodsSchema.index({ brand: 1 });
PaymentMethodsSchema.index({ createdAt: -1 });

// ============================================
// USER SESSIONS MODEL
// ============================================
const UserSessionsSchema = new Schema(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    sessionId: {
      type: String,
      required: true,
    },
    browser: {
      type: String,
    },
    os: {
      type: String,
    },
    device: {
      type: String,
    },
    location: {
      country: String,
      city: String,
      ip: String,
    },
    lastActive: {
      type: Date,
      default: Date.now,
    },
    isCurrent: {
      type: Boolean,
      default: false,
    },
    userAgent: {
      type: String,
    },
    expiresAt: {
      type: Date,
      required: true,
    },
  },
  {
    timestamps: true,
    collection: 'user_sessions',
  }
);

UserSessionsSchema.index({ userId: 1 });
UserSessionsSchema.index({ sessionId: 1 }, { unique: true });
UserSessionsSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 });
UserSessionsSchema.index({ userId: 1, isCurrent: 1 });
UserSessionsSchema.index({ userId: 1, lastActive: -1 });
UserSessionsSchema.index({ 'location.ip': 1 });
UserSessionsSchema.index({ browser: 1 });
UserSessionsSchema.index({ os: 1 });
UserSessionsSchema.index({ createdAt: -1 });

// ============================================
// NOTIFICATION SETTINGS MODEL
// ============================================
const NotificationSettingsSchema = new Schema(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    email: {
      loginAlerts: { type: Boolean, default: true },
      securityAlerts: { type: Boolean, default: true },
      billingAlerts: { type: Boolean, default: true },
      chatNotifications: { type: Boolean, default: true },
      agentUpdates: { type: Boolean, default: false },
      systemUpdates: { type: Boolean, default: false },
      marketingEmails: { type: Boolean, default: false },
    },
    push: {
      enabled: { type: Boolean, default: false },
      chatMessages: { type: Boolean, default: false },
      securityAlerts: { type: Boolean, default: true },
      billingAlerts: { type: Boolean, default: true },
    },
    sms: {
      enabled: { type: Boolean, default: false },
      securityAlerts: { type: Boolean, default: false },
      loginAlerts: { type: Boolean, default: false },
    },
    inApp: {
      enabled: { type: Boolean, default: true },
      chatMessages: { type: Boolean, default: true },
      systemAlerts: { type: Boolean, default: true },
    },
  },
  {
    timestamps: true,
    collection: 'notification_settings',
  }
);

NotificationSettingsSchema.index({ userId: 1 }, { unique: true });
NotificationSettingsSchema.index({ 'email.loginAlerts': 1 });
NotificationSettingsSchema.index({ 'push.enabled': 1 });
NotificationSettingsSchema.index({ 'sms.enabled': 1 });
NotificationSettingsSchema.index({ updatedAt: -1 });

// ============================================
// ACHIEVEMENTS MODEL
// ============================================
const AchievementsSchema = new Schema(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    achievementId: {
      type: String,
      required: true,
    },
    name: {
      type: String,
      required: true,
    },
    description: {
      type: String,
    },
    category: {
      type: String,
      enum: ['usage', 'social', 'time', 'feature', 'milestone'],
    },
    progress: {
      current: { type: Number, default: 0 },
      target: { type: Number, required: true },
    },
    isCompleted: {
      type: Boolean,
      default: false,
    },
    completedAt: {
      type: Date,
    },
    reward: {
      type: String,
    },
    metadata: {
      type: Schema.Types.Mixed,
      default: {},
    },
  },
  {
    timestamps: true,
    collection: 'achievements',
  }
);

AchievementsSchema.index({ userId: 1 });
AchievementsSchema.index({ achievementId: 1 });
AchievementsSchema.index({ category: 1 });
AchievementsSchema.index({ userId: 1, achievementId: 1 }, { unique: true });
AchievementsSchema.index({ userId: 1, isCompleted: 1 });
AchievementsSchema.index({ userId: 1, completedAt: -1 });
AchievementsSchema.index({ 'progress.current': 1 });
AchievementsSchema.index({ 'progress.target': 1 });
AchievementsSchema.index({ createdAt: -1 });

// ============================================
// SECURITY LOGS MODEL
// ============================================
const SecurityLogsSchema = new Schema(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
    },
    action: {
      type: String,
      required: true,
      enum: [
        'LOGIN_SUCCESS',
        'LOGIN_FAILED',
        'PASSWORD_CHANGE',
        'EMAIL_CHANGE',
        'TWO_FACTOR_ENABLED',
        'TWO_FACTOR_DISABLED',
        'SESSION_TERMINATED',
        'SUSPICIOUS_ACTIVITY',
        'ACCOUNT_LOCKED',
        'ACCOUNT_UNLOCKED',
      ],
    },
    severity: {
      type: String,
      enum: ['low', 'medium', 'high', 'critical'],
      default: 'low',
    },
    ipAddress: {
      type: String,
    },
    userAgent: {
      type: String,
    },
    location: {
      country: String,
      city: String,
    },
    success: {
      type: Boolean,
      default: true,
    },
    details: {
      type: Schema.Types.Mixed,
      default: {},
    },
    sessionId: {
      type: String,
    },
  },
  {
    timestamps: true,
    collection: 'security_logs',
  }
);

SecurityLogsSchema.index({ userId: 1, createdAt: -1 });
SecurityLogsSchema.index({ action: 1 });
SecurityLogsSchema.index({ severity: 1 });
SecurityLogsSchema.index({ userId: 1, action: 1 });
SecurityLogsSchema.index({ userId: 1, severity: 1 });
SecurityLogsSchema.index({ ipAddress: 1 });
SecurityLogsSchema.index({ sessionId: 1 });
SecurityLogsSchema.index({ success: 1 });
SecurityLogsSchema.index({ 'location.country': 1 });
SecurityLogsSchema.index({ createdAt: -1 });

// ============================================
// AGENT ANALYTICS MODEL
// ============================================
const AgentAnalyticsSchema = new Schema(
  {
    agentId: {
      type: String,
      required: true,
    },
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    date: {
      type: String, // YYYY-MM-DD format
      required: true,
    },
    metrics: {
      totalMessages: { type: Number, default: 0 },
      averageResponseTime: { type: Number, default: 0 },
      successRate: { type: Number, default: 100 },
      errorCount: { type: Number, default: 0 },
      sessionDuration: { type: Number, default: 0 },
      userSatisfaction: { type: Number, default: 0 },
    },
    performance: {
      responseTime: [Number], // Array of response times
      messageLength: [Number], // Array of message lengths
      sessionCount: { type: Number, default: 0 },
      uniqueUsers: { type: Number, default: 0 },
    },
    lastActive: {
      type: Date,
      default: Date.now,
    },
  },
  {
    timestamps: true,
    collection: 'agent_analytics',
  }
);

AgentAnalyticsSchema.index({ agentId: 1, date: -1 });
AgentAnalyticsSchema.index({ userId: 1, date: -1 });
AgentAnalyticsSchema.index({ agentId: 1, userId: 1, date: 1 }, { unique: true });
AgentAnalyticsSchema.index({ 'metrics.totalMessages': -1 });
AgentAnalyticsSchema.index({ 'metrics.averageResponseTime': 1 });
AgentAnalyticsSchema.index({ 'metrics.successRate': -1 });
AgentAnalyticsSchema.index({ 'performance.sessionCount': -1 });
AgentAnalyticsSchema.index({ lastActive: -1 });
AgentAnalyticsSchema.index({ createdAt: -1 });

// ============================================
// USER AGENTS MODEL (User-specific agent customizations)
// ============================================
const UserAgentsSchema = new Schema(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    agentId: {
      type: String,
      required: true,
    },
    customizations: {
      name: String,
      personality: Schema.Types.Mixed,
      preferences: Schema.Types.Mixed,
      customInstructions: String,
      voiceSettings: Schema.Types.Mixed,
    },
    usage: {
      totalMessages: { type: Number, default: 0 },
      lastUsed: { type: Date },
      favoriteLevel: { type: Number, default: 0 },
    },
    isActive: {
      type: Boolean,
      default: true,
    },
    metadata: {
      type: Schema.Types.Mixed,
      default: {},
    },
  },
  {
    timestamps: true,
    collection: 'user_agents',
  }
);

UserAgentsSchema.index({ userId: 1 });
UserAgentsSchema.index({ agentId: 1 });
UserAgentsSchema.index({ userId: 1, agentId: 1 }, { unique: true });
UserAgentsSchema.index({ userId: 1, isActive: 1 });
UserAgentsSchema.index({ 'usage.totalMessages': -1 });
UserAgentsSchema.index({ 'usage.lastUsed': -1 });
UserAgentsSchema.index({ 'usage.favoriteLevel': -1 });
UserAgentsSchema.index({ 'customizations.name': 1 });
UserAgentsSchema.index({ createdAt: -1 });

// ============================================
// PRIVACY SETTINGS MODEL
// ============================================
const PrivacySettingsSchema = new Schema(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    profileVisibility: {
      type: String,
      enum: ['public', 'private', 'friends'],
      default: 'private',
    },
    dataCollection: {
      analytics: { type: Boolean, default: true },
      performance: { type: Boolean, default: true },
      marketing: { type: Boolean, default: false },
      personalization: { type: Boolean, default: true },
    },
    sharing: {
      searchEngineIndexing: { type: Boolean, default: false },
      thirdPartyIntegrations: { type: Boolean, default: false },
      dataExport: { type: Boolean, default: true },
    },
    retention: {
      chatHistory: {
        type: String,
        enum: ['forever', '1year', '6months', '3months', '1month'],
        default: '1year',
      },
      activityLogs: {
        type: String,
        enum: ['forever', '1year', '6months', '3months'],
        default: '1year',
      },
    },
    cookies: {
      essential: { type: Boolean, default: true },
      functional: { type: Boolean, default: true },
      analytics: { type: Boolean, default: true },
      marketing: { type: Boolean, default: false },
    },
  },
  {
    timestamps: true,
    collection: 'privacy_settings',
  }
);

PrivacySettingsSchema.index({ userId: 1 }, { unique: true });
PrivacySettingsSchema.index({ profileVisibility: 1 });
PrivacySettingsSchema.index({ 'dataCollection.analytics': 1 });
PrivacySettingsSchema.index({ 'dataCollection.marketing': 1 });
PrivacySettingsSchema.index({ 'sharing.searchEngineIndexing': 1 });
PrivacySettingsSchema.index({ 'retention.chatHistory': 1 });
PrivacySettingsSchema.index({ 'cookies.marketing': 1 });
PrivacySettingsSchema.index({ updatedAt: -1 });

// ============================================
// ACTIVITY CATEGORIES MODEL
// ============================================
const ActivityCategoriesSchema = new Schema(
  {
    categoryId: {
      type: String,
      required: true,
    },
    name: {
      type: String,
      required: true,
    },
    description: {
      type: String,
    },
    actions: [String], // Array of action types in this category
    color: {
      type: String,
      default: '#6366f1',
    },
    icon: {
      type: String,
    },
    isActive: {
      type: Boolean,
      default: true,
    },
    sortOrder: {
      type: Number,
      default: 0,
    },
  },
  {
    timestamps: true,
    collection: 'activity_categories',
  }
);

ActivityCategoriesSchema.index({ categoryId: 1 }, { unique: true });
ActivityCategoriesSchema.index({ isActive: 1 });
ActivityCategoriesSchema.index({ sortOrder: 1 });
ActivityCategoriesSchema.index({ name: 1 });
ActivityCategoriesSchema.index({ actions: 1 });
ActivityCategoriesSchema.index({ createdAt: -1 });

// ============================================
// DOCUMENT ANALYTICS MODEL
// ============================================
const DocumentAnalyticsSchema = new Schema(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    documentId: {
      type: String,
      required: true,
    },
    fileName: {
      type: String,
    },
    fileType: {
      type: String,
    },
    fileSize: {
      type: Number,
    },
    processingTime: {
      type: Number, // milliseconds
    },
    analytics: {
      pagesProcessed: { type: Number, default: 0 },
      wordsExtracted: { type: Number, default: 0 },
      questionsAnswered: { type: Number, default: 0 },
      accuracy: { type: Number, default: 0 },
    },
    agents: [String], // Which agents processed this document
    processedAt: {
      type: Date,
      default: Date.now,
    },
    metadata: {
      type: Schema.Types.Mixed,
      default: {},
    },
  },
  {
    timestamps: true,
    collection: 'document_analytics',
  }
);

DocumentAnalyticsSchema.index({ userId: 1 });
DocumentAnalyticsSchema.index({ documentId: 1 });
DocumentAnalyticsSchema.index({ userId: 1, documentId: 1 }, { unique: true });
DocumentAnalyticsSchema.index({ fileType: 1 });
DocumentAnalyticsSchema.index({ 'analytics.pagesProcessed': -1 });
DocumentAnalyticsSchema.index({ 'analytics.wordsExtracted': -1 });
DocumentAnalyticsSchema.index({ 'analytics.questionsAnswered': -1 });
DocumentAnalyticsSchema.index({ 'analytics.accuracy': -1 });
DocumentAnalyticsSchema.index({ agents: 1 });
DocumentAnalyticsSchema.index({ processedAt: -1 });
DocumentAnalyticsSchema.index({ processingTime: 1 });
DocumentAnalyticsSchema.index({ createdAt: -1 });

// ============================================
// AGENT SETTINGS MODEL
// ============================================
const AgentSettingsSchema = new Schema(
  {
    agentId: {
      type: String,
      required: true,
    },
    globalSettings: {
      enabled: { type: Boolean, default: true },
      maxConcurrentUsers: { type: Number, default: 100 },
      rateLimit: { type: Number, default: 60 }, // requests per minute
      maintenanceMode: { type: Boolean, default: false },
    },
    performance: {
      maxResponseTime: { type: Number, default: 5000 }, // milliseconds
      maxTokens: { type: Number, default: 2000 },
      temperature: { type: Number, default: 0.7 },
      model: { type: String, default: 'gpt-3.5-turbo' },
    },
    features: {
      fileUpload: { type: Boolean, default: true },
      voiceChat: { type: Boolean, default: false },
      imageGeneration: { type: Boolean, default: false },
      webSearch: { type: Boolean, default: false },
    },
    security: {
      contentFiltering: { type: Boolean, default: true },
      rateLimitEnabled: { type: Boolean, default: true },
      logConversations: { type: Boolean, default: true },
    },
    metadata: {
      type: Schema.Types.Mixed,
      default: {},
    },
  },
  {
    timestamps: true,
    collection: 'agent_settings',
  }
);

AgentSettingsSchema.index({ agentId: 1 }, { unique: true });
AgentSettingsSchema.index({ 'globalSettings.enabled': 1 });
AgentSettingsSchema.index({ 'globalSettings.maintenanceMode': 1 });
AgentSettingsSchema.index({ 'performance.model': 1 });
AgentSettingsSchema.index({ 'features.fileUpload': 1 });
AgentSettingsSchema.index({ 'features.voiceChat': 1 });
AgentSettingsSchema.index({ 'security.contentFiltering': 1 });
AgentSettingsSchema.index({ updatedAt: -1 });

// ============================================
// ACTIVITY EXPORTS MODEL
// ============================================
const ActivityExportsSchema = new Schema(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    exportId: {
      type: String,
      required: true,
    },
    type: {
      type: String,
      enum: ['activity_logs', 'chat_history', 'user_data', 'analytics'],
      required: true,
    },
    format: {
      type: String,
      enum: ['json', 'csv', 'pdf'],
      default: 'json',
    },
    dateRange: {
      from: { type: Date },
      to: { type: Date },
    },
    status: {
      type: String,
      enum: ['requested', 'processing', 'completed', 'failed', 'expired'],
      default: 'requested',
    },
    fileUrl: {
      type: String, // URL to download the export file
    },
    fileSize: {
      type: Number, // Size in bytes
    },
    expiresAt: {
      type: Date,
      required: true,
    },
    metadata: {
      recordCount: Number,
      processingTime: Number,
      error: String,
    },
  },
  {
    timestamps: true,
    collection: 'activity_exports',
  }
);

ActivityExportsSchema.index({ userId: 1 });
ActivityExportsSchema.index({ exportId: 1 }, { unique: true });
ActivityExportsSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 });
ActivityExportsSchema.index({ userId: 1, type: 1 });
ActivityExportsSchema.index({ userId: 1, status: 1 });
ActivityExportsSchema.index({ userId: 1, createdAt: -1 });
ActivityExportsSchema.index({ status: 1 });
ActivityExportsSchema.index({ type: 1 });
ActivityExportsSchema.index({ format: 1 });
ActivityExportsSchema.index({ 'dateRange.from': 1 });
ActivityExportsSchema.index({ 'dateRange.to': 1 });
ActivityExportsSchema.index({ fileSize: 1 });
ActivityExportsSchema.index({ createdAt: -1 });

// ============================================
// INDIVIDUAL AGENT SYSTEM SCHEMAS
// ============================================

// Individual Agent Configuration Schema
const IndividualAgentConfigurationSchema = new Schema(
  {
    agentId: {
      type: String,
      required: true,
    },
    info: {
      displayName: { type: String, required: true },
      category: { type: String, required: true },
      description: { type: String, required: true },
      role: { type: String, required: true },
      isActive: { type: Boolean, default: true },
      version: { type: String, default: '1.0.0' },
      tags: [{ type: String }],
    },
    personality: {
      behavioralTraits: {
        assertiveness: { type: Number, min: 1, max: 10, default: 5 },
        creativity: { type: Number, min: 1, max: 10, default: 5 },
        empathy: { type: Number, min: 1, max: 10, default: 5 },
        enthusiasm: { type: Number, min: 1, max: 10, default: 5 },
        formality: { type: Number, min: 1, max: 10, default: 5 },
        humor: { type: Number, min: 1, max: 10, default: 5 },
        patience: { type: Number, min: 1, max: 10, default: 5 },
        verbosity: { type: Number, min: 1, max: 10, default: 5 },
      },
      communicationStyle: { type: String, default: 'balanced' },
      expertise: [{ type: String }],
    },
    capabilities: {
      canAttachFiles: { type: Boolean, default: false },
      canUseVoice: { type: Boolean, default: false },
      maxFileSize: { type: Number, default: 10 }, // MB
      supportedFormats: [{ type: String }],
    },
    limits: {
      daily: {
        messages: { type: Number, default: 100 },
        tokens: { type: Number, default: 10000 },
        sessions: { type: Number, default: 10 },
      },
      weekly: {
        messages: { type: Number, default: 500 },
        tokens: { type: Number, default: 50000 },
        sessions: { type: Number, default: 50 },
      },
      monthly: {
        messages: { type: Number, default: 2000 },
        tokens: { type: Number, default: 200000 },
        sessions: { type: Number, default: 200 },
      },
    },
    pricing: {
      daily: { type: Number, default: 1 },
      weekly: { type: Number, default: 5 },
      monthly: { type: Number, default: 19 },
    },
    metadata: {
      createdBy: { type: String, default: 'system' },
      lastUpdated: { type: Date, default: Date.now },
      version: { type: String, default: '1.0.0' },
    },
  },
  {
    timestamps: true,
    collection: 'individual_agent_configurations',
  }
);

IndividualAgentConfigurationSchema.index({ agentId: 1 }, { unique: true });
IndividualAgentConfigurationSchema.index({ 'info.isActive': 1 });
IndividualAgentConfigurationSchema.index({ 'info.category': 1 });

// ❌ DELETED: IndividualAgentSubscription schema removed (deprecated)
// Replaced by AgentPurchase model - see agent-purchase-models.js

// Individual Agent Activity Log Schema
const IndividualAgentActivityLogSchema = new Schema(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    agentId: {
      type: String,
      required: true,
    },
    subscriptionId: {
      type: Schema.Types.ObjectId,
      ref: 'AgentPurchase', // Updated to use AgentPurchase
    },
    activity: {
      type: {
        type: String,
        enum: [
          'SUBSCRIPTION_CREATED',
          'SUBSCRIPTION_ACTIVATED',
          'SUBSCRIPTION_CANCELLED',
          'SUBSCRIPTION_EXPIRED',
          'PAYMENT_FAILED',
          'MESSAGE_SENT',
          'SESSION_STARTED',
          'USAGE_UPDATED',
        ],
        required: true,
      },
      description: { type: String, required: true },
      metadata: { type: Schema.Types.Mixed },
      timestamp: { type: Date, default: Date.now },
    },
    ipAddress: { type: String },
    userAgent: { type: String },
  },
  {
    timestamps: true,
    collection: 'individual_agent_activity_logs',
  }
);

IndividualAgentActivityLogSchema.index({ userId: 1, createdAt: -1 });
IndividualAgentActivityLogSchema.index({ agentId: 1, createdAt: -1 });
IndividualAgentActivityLogSchema.index({ subscriptionId: 1 });

// Individual Agent Session Schema
const IndividualAgentSessionSchema = new Schema(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    agentId: {
      type: String,
      required: true,
    },
    subscriptionId: {
      type: Schema.Types.ObjectId,
      ref: 'AgentPurchase', // Updated to use AgentPurchase
      required: true,
    },
    sessionId: {
      type: String,
      required: true,
    },
    startTime: { type: Date, default: Date.now },
    endTime: { type: Date },
    duration: { type: Number }, // in seconds
    status: {
      type: String,
      enum: ['active', 'completed', 'terminated'],
      default: 'active',
    },
    metadata: {
      source: { type: String, default: 'web' },
      device: { type: String },
      browser: { type: String },
    },
  },
  {
    timestamps: true,
    collection: 'individual_agent_sessions',
  }
);

IndividualAgentSessionSchema.index({ userId: 1, agentId: 1 });
IndividualAgentSessionSchema.index({ subscriptionId: 1 });
IndividualAgentSessionSchema.index({ sessionId: 1 }, { unique: true });
IndividualAgentSessionSchema.index({ status: 1 });

// Individual Agent Chat History Schema
const IndividualAgentChatHistorySchema = new Schema(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    agentId: {
      type: String,
      required: true,
    },
    subscriptionId: {
      type: Schema.Types.ObjectId,
      ref: 'AgentPurchase', // Updated to use AgentPurchase
      required: true,
    },
    sessionId: {
      type: String,
      required: true,
    },
    message: {
      role: {
        type: String,
        enum: ['user', 'assistant'],
        required: true,
      },
      content: { type: String, required: true },
      timestamp: { type: Date, default: Date.now },
    },
    interaction: {
      satisfaction: { type: Number, min: 1, max: 5 },
      responseTime: { type: Number }, // in milliseconds
      tokensUsed: { type: Number },
    },
    metadata: {
      messageId: { type: String },
      attachments: [{ type: String }],
      context: { type: Schema.Types.Mixed },
    },
  },
  {
    timestamps: true,
    collection: 'individual_agent_chat_history',
  }
);

IndividualAgentChatHistorySchema.index({ userId: 1, agentId: 1, createdAt: -1 });
IndividualAgentChatHistorySchema.index({ subscriptionId: 1 });
IndividualAgentChatHistorySchema.index({ sessionId: 1 });
IndividualAgentChatHistorySchema.index({ 'message.role': 1 });

// ============================================
// CANVAS APP SCHEMAS
// ============================================

// Canvas Project Schema
const CanvasProjectSchema = new Schema(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    projectId: {
      type: String,
      required: true,
    },
    name: {
      type: String,
      required: true,
    },
    description: {
      type: String,
    },
    code: {
      type: String,
      required: true,
    },
    template: {
      type: String, // Template ID used
    },
    provider: {
      type: String,
      enum: ['openai', 'anthropic', 'gemini'],
    },
    model: {
      type: String,
    },
    metadata: {
      lastGenerated: Date,
      generationCount: { type: Number, default: 0 },
      totalTokens: { type: Number, default: 0 },
      estimatedCost: { type: Number, default: 0 },
    },
    isPublic: {
      type: Boolean,
      default: false,
    },
    tags: [String],
    thumbnail: String, // URL to thumbnail image
  },
  {
    timestamps: true,
    collection: 'canvas_projects',
  }
);

// Canvas Template Schema
const CanvasTemplateSchema = new Schema(
  {
    templateId: {
      type: String,
      required: true,
    },
    name: {
      type: String,
      required: true,
    },
    description: {
      type: String,
      required: true,
    },
    category: {
      type: String,
      enum: [
        'landing-page',
        'dashboard',
        'portfolio',
        'ecommerce',
        'blog',
        'chat-app',
        'business',
        'utility',
      ],
      default: 'utility',
    },
    prompt: {
      type: String,
      required: true,
    },
    previewImage: String,
    difficulty: {
      type: String,
      enum: ['beginner', 'intermediate', 'advanced'],
      default: 'beginner',
    },
    estimatedTokens: {
      type: Number,
      default: 1000,
    },
    isActive: {
      type: Boolean,
      default: true,
    },
    usageCount: {
      type: Number,
      default: 0,
    },
    tags: [String],
  },
  {
    timestamps: true,
    collection: 'canvas_templates',
  }
);

// Indexes for Canvas schemas
CanvasProjectSchema.index({ userId: 1, createdAt: -1 });
CanvasProjectSchema.index({ projectId: 1 }, { unique: true });
CanvasProjectSchema.index({ userId: 1, isPublic: 1 });
CanvasProjectSchema.index({ template: 1 });
CanvasProjectSchema.index({ tags: 1 });
CanvasProjectSchema.index({ provider: 1 });
CanvasProjectSchema.index({ model: 1 });

CanvasTemplateSchema.index({ templateId: 1 }, { unique: true });
CanvasTemplateSchema.index({ category: 1 });
CanvasTemplateSchema.index({ isActive: 1 });
CanvasTemplateSchema.index({ difficulty: 1 });
CanvasTemplateSchema.index({ usageCount: -1 });
CanvasTemplateSchema.index({ tags: 1 });

// Create Canvas models
const CanvasProject = mongoose.model('CanvasProject', CanvasProjectSchema);
const CanvasTemplate = mongoose.model('CanvasTemplate', CanvasTemplateSchema);

// Create models for all new collections
const UserPreferences = mongoose.model('UserPreferences', UserPreferencesSchema);
const BillingHistory = mongoose.model('BillingHistory', BillingHistorySchema);
const PaymentMethods = mongoose.model('PaymentMethods', PaymentMethodsSchema);
const UserSessions = mongoose.model('UserSessions', UserSessionsSchema);
const NotificationSettings = mongoose.model('NotificationSettings', NotificationSettingsSchema);
const Achievements = mongoose.model('Achievements', AchievementsSchema);
const SecurityLogs = mongoose.model('SecurityLogs', SecurityLogsSchema);
const AgentAnalytics = mongoose.model('AgentAnalytics', AgentAnalyticsSchema);
const UserAgents = mongoose.model('UserAgents', UserAgentsSchema);
const PrivacySettings = mongoose.model('PrivacySettings', PrivacySettingsSchema);
const ActivityCategories = mongoose.model('ActivityCategories', ActivityCategoriesSchema);
const DocumentAnalytics = mongoose.model('DocumentAnalytics', DocumentAnalyticsSchema);
const AgentSettings = mongoose.model('AgentSettings', AgentSettingsSchema);
const ActivityExports = mongoose.model('ActivityExports', ActivityExportsSchema);

// Individual Agent System Models
const IndividualAgentConfiguration = mongoose.model(
  'IndividualAgentConfiguration',
  IndividualAgentConfigurationSchema
);
// ❌ DELETED: IndividualAgentSubscription model removed (deprecated)
// Use AgentPurchase from agent-purchase-models.js instead
const IndividualAgentActivityLog = mongoose.model(
  'IndividualAgentActivityLog',
  IndividualAgentActivityLogSchema
);
const IndividualAgentSession = mongoose.model(
  'IndividualAgentSession',
  IndividualAgentSessionSchema
);
const IndividualAgentChatHistory = mongoose.model(
  'IndividualAgentChatHistory',
  IndividualAgentChatHistorySchema
);

// Create models for existing schemas
const Message = mongoose.model('Message', MessageSchema);
const Conversation = mongoose.model('Conversation', ConversationSchema);

module.exports = {
  // Existing Models
  User,
  Agent,
  Chat,
  Message,
  Conversation,
  // Subscription, // REMOVED - replaced by AgentPurchase (one-time purchases, no subscriptions)
  Transaction,
  FileUpload,
  UsageAnalytics,
  ApiKey,
  SupportTicket,
  ContactForm,
  WebhookEvent,
  ActivityLog,
  Visitor,
  UserProfile,
  UserAuth,
  UserProfiles,
  TwoFactorAuth,
  UserSession,
  EmailTemplate,
  SystemSettings,

  // New Dashboard Collections
  UserPreferences,
  BillingHistory,
  PaymentMethods,
  UserSessions,
  NotificationSettings,
  Achievements,
  SecurityLogs,
  AgentAnalytics,
  UserAgents,
  PrivacySettings,
  ActivityCategories,
  DocumentAnalytics,
  AgentSettings,
  ActivityExports,

  // Canvas App Models
  CanvasProject,
  CanvasTemplate,

  // Individual Agent System Models
  IndividualAgentConfiguration,
  // IndividualAgentSubscription, // ❌ DELETED - Use AgentPurchase instead
  IndividualAgentActivityLog,
  IndividualAgentSession,
  IndividualAgentChatHistory,

  // One-Time Purchase System
  AgentPurchase,
};
