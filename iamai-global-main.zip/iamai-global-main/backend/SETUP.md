# IAMAI Global Backend Setup Guide

This guide will walk you through setting up the complete backend infrastructure for the IAMAI Global multi-agent AI platform.

## 🎯 Overview

The backend consists of:
- **Node.js/Express API** with TypeScript
- **PostgreSQL database** with Prisma ORM
- **MongoDB database** for Auth.js sessions
- **Redis cache** for sessions and rate limiting
- **Multiple AI providers** (OpenAI, Anthropic, Google AI, etc.)
- **Payment processing** (Stripe, PayPal)
- **Authentication** via Auth.js v5 (passwordless + password-based)
- **Nginx reverse proxy**
- **AWS EC2 deployment**

## 📋 Prerequisites

### Required Accounts & API Keys

1. **AWS Account** (for hosting)
2. **Email Provider** (Gmail, SendGrid, etc. for Auth.js magic links)
3. **MongoDB** (for Auth.js user & session storage)
4. **Stripe Account** (payment processing)
5. **PayPal Business Account** (payment processing)
6. **AI Provider Accounts**:
   - OpenAI API key
   - Anthropic API key
   - Google AI API key
   - RunwayML API key
   - Stability AI API key
   - Replicate API token

### Domain Requirements
- Primary domain: `iamai.global`
- API subdomain: `api.iamai.global`

## 🛠️ Local Development Setup

### 1. Clone and Install

```bash
# Navigate to the backend directory
cd iamai-global/backend

# Install dependencies
npm install
```

### 2. Environment Configuration

```bash
# Copy the example environment file
cp .env.example .env

# Edit the .env file with your actual values
nano .env
```

### 3. Database Setup

```bash
# Install and start PostgreSQL locally
# Windows: Download from https://www.postgresql.org/download/windows/
# macOS: brew install postgresql
# Linux: sudo apt-get install postgresql

# Install and start Redis locally  
# Windows: Download from https://redis.io/download
# macOS: brew install redis
# Linux: sudo apt-get install redis-server

# Generate Prisma client
npx prisma generate

# Run database migrations
npx prisma migrate dev

# Seed the database (optional)
npx prisma db seed
```

### 4. Start Development Server

```bash
# Start the development server
npm run dev

# The API will be available at http://localhost:3001
```

## 🚀 Production Deployment on AWS EC2

### 1. Launch EC2 Instance

1. **Go to AWS EC2 Console**
2. **Launch Instance**:
   - AMI: Ubuntu Server 20.04 LTS
   - Instance Type: t3.medium (minimum recommended)
   - Storage: 20GB SSD (minimum)
   - Security Group: Allow HTTP (80), HTTPS (443), SSH (22)
3. **Create/Download Key Pair** for SSH access

### 2. Configure Domain DNS

1. **In your domain registrar**, set these DNS records:
   ```
   Type: A
   Name: @
   Value: [Your EC2 Instance IP]
   
   Type: A
   Name: api
   Value: [Your EC2 Instance IP]
   
   Type: CNAME
   Name: www
   Value: iamai.global
   ```

### 3. Connect to EC2 and Deploy

```bash
# Connect to your EC2 instance
ssh -i your-key.pem ubuntu@your-ec2-ip

# Clone the repository
git clone https://github.com/yourusername/iamai-backend.git
cd iamai-backend

# Make deployment script executable
chmod +x scripts/deploy.sh

# Run the deployment script
./scripts/deploy.sh
```

### 4. Configure Environment Variables

```bash
# Edit the production environment file
nano .env

# Add all your production API keys and configuration
```

## 🔧 Configuration Details

### Environment Variables (.env)

```env
# Server Configuration
NODE_ENV=production
PORT=3001

# Database (AWS RDS recommended for production)
DATABASE_URL="postgresql://username:password@your-rds-endpoint:5432/iamai_db?schema=public"

# JWT Configuration
JWT_SECRET=your_super_long_random_secret_key_here
JWT_EXPIRES_IN=7d

# AI Provider API Keys
OPENAI_API_KEY=sk-...
ANTHROPIC_API_KEY=sk-ant-...
GOOGLE_AI_API_KEY=AIza...
RUNWAYML_API_KEY=your_runwayml_key
STABILITY_AI_API_KEY=sk-...
REPLICATE_API_TOKEN=r8_...
HUGGINGFACE_API_KEY=hf_...

# Auth.js Configuration
NEXTAUTH_URL=https://yourdomain.com
NEXTAUTH_URL_INTERNAL=http://localhost:3001
NEXTAUTH_SECRET=your_super_secret_nextauth_key_here
EMAIL_FROM=noreply@yourdomain.com
EMAIL_SERVER_HOST=smtp.gmail.com
EMAIL_SERVER_PORT=587
EMAIL_SERVER_USER=your_email@gmail.com
EMAIL_SERVER_PASSWORD=your_email_app_password

# MongoDB (for Auth.js)
MONGODB_URI=mongodb://localhost:27017/iamai_auth

# Payment Processing
STRIPE_SECRET_KEY=sk_live_...
STRIPE_WEBHOOK_SECRET=whsec_...
PAYPAL_CLIENT_ID=your_paypal_client_id
PAYPAL_CLIENT_SECRET=your_paypal_client_secret
PAYPAL_WEBHOOK_ID=your_paypal_webhook_id

# Redis (ElastiCache recommended for production)
REDIS_URL=redis://your-redis-endpoint:6379

# AWS Configuration
AWS_REGION=us-east-1
AWS_ACCESS_KEY_ID=your_aws_access_key
AWS_SECRET_ACCESS_KEY=your_aws_secret_key
S3_BUCKET_NAME=iamai-uploads

# Email Configuration (SES recommended)
SMTP_HOST=email-smtp.us-east-1.amazonaws.com
SMTP_PORT=587
SMTP_USER=your_ses_smtp_user
SMTP_PASS=your_ses_smtp_password

# Application URLs
FRONTEND_URL=https://iamai.global
BACKEND_URL=https://api.iamai.global

# Rate Limiting
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100

# File Upload Limits
MAX_FILE_SIZE=10485760
ALLOWED_FILE_TYPES=image/jpeg,image/png,image/gif,application/pdf,text/plain
```

## 🗄️ Database Setup (AWS RDS)

### 1. Create RDS Instance

1. **Go to AWS RDS Console**
2. **Create Database**:
   - Engine: PostgreSQL
   - Version: 14.x or later
   - Instance Class: db.t3.micro (for testing) or db.t3.small (production)
   - Storage: 20GB minimum
   - Multi-AZ: Yes (for production)
   - VPC: Same as your EC2 instance

### 2. Configure Security Groups

```bash
# Allow EC2 to connect to RDS
# In RDS security group, add inbound rule:
Type: PostgreSQL
Port: 5432
Source: [EC2 Security Group ID]
```

### 3. Run Migrations

```bash
# SSH into your EC2 instance
ssh -i your-key.pem ubuntu@your-ec2-ip

# Navigate to application directory
cd /var/www/iamai-backend

# Run database migrations
npx prisma migrate deploy
```

## 💰 Payment Setup

### Stripe Configuration

1. **Create Stripe Account** at https://stripe.com
2. **Get API Keys** from Dashboard > Developers > API keys
3. **Create Products and Prices**:
   ```bash
   # Pro Plan
   stripe products create --name="Pro Plan" --description="Monthly pro subscription"
   stripe prices create --unit-amount=2999 --currency=usd --recurring[interval]=month --product=[PRODUCT_ID]
   
   # Enterprise Plan
   stripe products create --name="Enterprise Plan" --description="Monthly enterprise subscription"
   stripe prices create --unit-amount=9999 --currency=usd --recurring[interval]=month --product=[PRODUCT_ID]
   ```
4. **Set up Webhooks**:
   - Endpoint URL: `https://api.iamai.global/api/payments/webhook`
   - Events: `invoice.payment_succeeded`, `customer.subscription.updated`, `customer.subscription.deleted`

### PayPal Configuration

1. **Create PayPal Business Account**
2. **Create App** in PayPal Developer Dashboard
3. **Create Subscription Plans**:
   - Pro Plan: $29.99/month
   - Enterprise Plan: $99.99/month
4. **Set up Webhooks**:
   - Webhook URL: `https://api.iamai.global/api/payments/webhook`
   - Events: Billing subscription events

## 🔐 Authentication Setup (Auth.js v5)

### 1. Configure Auth.js Environment Variables

Add the following to your `.env` file:

```bash
# Auth.js Configuration
NEXTAUTH_URL=http://localhost:3000
NEXTAUTH_URL_INTERNAL=http://localhost:3001
NEXTAUTH_SECRET=your_super_secret_nextauth_key_here

# Email Configuration (for magic links)
EMAIL_FROM=noreply@yourdomain.com
EMAIL_SERVER_HOST=smtp.gmail.com
EMAIL_SERVER_PORT=587
EMAIL_SERVER_USER=your_email@gmail.com
EMAIL_SERVER_PASSWORD=your_email_app_password

# MongoDB (for Auth.js sessions & user storage)
MONGODB_URI=mongodb://localhost:27017/iamai_auth
```

### 2. Generate NEXTAUTH_SECRET

```bash
# Generate a secure random secret
openssl rand -base64 32
```

### 3. Email Provider Setup (Gmail Example)

1. **Enable 2FA** on your Gmail account
2. **Create App Password**:
   - Go to Google Account → Security → 2-Step Verification → App passwords
   - Generate password for "Mail"
3. **Add to .env**: Use the 16-character password as `EMAIL_SERVER_PASSWORD`

### 4. MongoDB Setup (for Auth.js)

```bash
# Install MongoDB (if not already installed)
# macOS
brew install mongodb-community

# Ubuntu
sudo apt-get install mongodb

# Start MongoDB
mongod --dbpath /path/to/data
```

### 5. Auth.js Features

The Auth.js configuration includes:
- ✅ **Passwordless Authentication**: Magic link emails for secure login
- ✅ **Password-Based Login**: Traditional email/password with bcrypt hashing
- ✅ **JWT Sessions**: Secure 24-hour sessions
- ✅ **MongoDB Adapter**: Persistent user & session storage
- ✅ **Email Templates**: Professional HTML email templates
- ✅ **Password Reset**: Secure token-based password recovery
- ✅ **Account Protection**: Rate limiting and security measures

### 6. Test Authentication

```bash
# Start backend server
npm run dev

# Test endpoints
curl -X POST http://localhost:3001/api/auth/signup -H "Content-Type: application/json" -d '{"email":"test@example.com","password":"SecurePass123!","name":"Test User"}'
```

## 🤖 AI Provider Setup

### OpenAI
1. Create account at https://platform.openai.com
2. Generate API key
3. Set usage limits and billing

### Anthropic
1. Create account at https://console.anthropic.com
2. Generate API key
3. Request access to Claude models

### Google AI
1. Create project at https://makersuite.google.com
2. Enable Generative AI API
3. Generate API key

### Additional Providers
- **RunwayML**: https://runwayml.com
- **Stability AI**: https://stability.ai
- **Replicate**: https://replicate.com

## 📊 Monitoring & Logging

### Application Monitoring

```bash
# View real-time logs with PM2
pm2 logs iamai-backend

# Check service status
pm2 list

# Monitor system resources
htop
```

### Database Monitoring

```bash
# Connect to database
psql -U iamai_user -d iamai_db -h localhost

# Check database size
SELECT pg_size_pretty(pg_database_size('iamai_db'));

# Check active connections
SELECT count(*) FROM pg_stat_activity;
```

### Backup Strategy

```bash
# Set up automated backups (cron job)
crontab -e

# Add this line for daily backups at 2 AM
0 2 * * * /var/www/iamai-backend/scripts/backup.sh
```

## 🔧 Maintenance

### Regular Updates

```bash
# Update application code
cd /var/www/iamai-global
git pull origin main
npm install && npm run build
cd backend && npm install && npm run build && cd ..
pm2 restart all

# Update system packages
sudo apt update && sudo apt upgrade -y

# Update SSL certificates (automated with cron)
sudo certbot renew --dry-run
```

### Performance Optimization

1. **Database Optimization**:
   - Add indexes for frequently queried fields
   - Regular VACUUM and ANALYZE
   - Monitor slow queries

2. **Redis Optimization**:
   - Set appropriate memory limits
   - Configure eviction policies
   - Monitor memory usage

3. **Application Optimization**:
   - Enable compression in Nginx
   - Optimize PM2 process management
   - Use CDN for static assets

## 🚨 Troubleshooting

### Common Issues

1. **Database Connection Issues**:
   ```bash
   # Check database connectivity
   npx prisma db pull
   
   # Restart PostgreSQL
   sudo systemctl restart postgresql
   ```

2. **SSL Certificate Issues**:
   ```bash
   # Manually renew certificates
   sudo certbot renew --force-renewal
   
   # Check certificate status
   sudo certbot certificates
   ```

3. **High Memory Usage**:
   ```bash
   # Check PM2 processes
   pm2 monit
   
   # Restart services
   pm2 restart all
   ```

### Getting Help

- **Email Support**: support@iamai.global
- **Documentation**: https://docs.iamai.global
- **GitHub Issues**: Create an issue with logs and error details

## ✅ Final Checklist

- [ ] EC2 instance running
- [ ] Domain DNS configured
- [ ] SSL certificates installed
- [ ] Database migrations completed
- [ ] All environment variables set
- [ ] AI provider APIs tested
- [ ] Payment webhooks configured
- [ ] Authentication working
- [ ] Monitoring set up
- [ ] Backups configured
- [ ] Health checks passing

## 🎉 Success!

Your IAMAI Global backend is now running in production! The API should be available at `https://api.iamai.global` with full functionality including:

- Multi-AI agent conversations
- User authentication with Auth.js (passwordless magic links + password login)
- Subscription management with Stripe/PayPal
- Real-time WebSocket connections
- Comprehensive analytics and monitoring

---

For additional support or questions, contact the development team at support@iamai.global.