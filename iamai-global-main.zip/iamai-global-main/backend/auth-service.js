// Authentication Service - JWT & User Management
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { User } = require('./models');

// Configuration
const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-this';
const JWT_EXPIRY = process.env.JWT_EXPIRY || '7d';
const BCRYPT_ROUNDS = parseInt(process.env.BCRYPT_ROUNDS) || 12;

/**
 * Generate JWT token
 */
function generateToken(user) {
  const payload = {
    id: user._id.toString(),
    email: user.email,
    tier: user.tier,
  };

  return jwt.sign(payload, JWT_SECRET, {
    expiresIn: JWT_EXPIRY,
  });
}

/**
 * Verify JWT token
 * Supports both new JWT_SECRET and legacy fallback secret for transition period
 */
function verifyToken(token) {
  // Try JWT_SECRET first (new tokens), then fallback secret (legacy tokens)
  const secrets = [
    JWT_SECRET,
    'your-secret-key-change-this', // Legacy fallback for tokens issued before JWT_SECRET was properly loaded
  ].filter(Boolean);

  let lastError = null;
  for (const secret of secrets) {
    try {
      return jwt.verify(token, secret);
    } catch (error) {
      lastError = error;
      // Try next secret
    }
  }

  throw new Error('Invalid or expired token');
}

/**
 * Hash password
 */
async function hashPassword(password) {
  return await bcrypt.hash(password, BCRYPT_ROUNDS);
}

/**
 * Compare password
 */
async function comparePassword(password, hashedPassword) {
  return await bcrypt.compare(password, hashedPassword);
}

/**
 * Register new user
 */
async function register(userData) {
  try {
    const { email, password, name, firstName, lastName } = userData;

    // Validate input
    if (!email || !password) {
      throw new Error('Email and password are required');
    }

    if (password.length < 8) {
      throw new Error('Password must be at least 8 characters long');
    }

    // Check if user already exists
    const existingUser = await User.findOne({ email: email.toLowerCase() });
    if (existingUser) {
      throw new Error('User with this email already exists');
    }

    // Create user (password will be hashed by pre-save hook)
    const user = await User.create({
      email: email.toLowerCase(),
      password: password, // Plain password - will be hashed by model pre-save hook
      name: name || email.split('@')[0],
      firstName: firstName || '',
      lastName: lastName || '',
      tier: 'NONE',
      isActive: true,
    });

    // Generate token
    const token = generateToken(user);

    // Return user data (without password)
    return {
      success: true,
      message: 'Account created successfully',
      user: {
        id: user._id,
        email: user.email,
        name: user.name,
        firstName: user.firstName,
        lastName: user.lastName,
        phone: user.phone,
        profileImage: user.profileImage,
        tier: user.tier,
        preferences: user.preferences || { language: 'en', timezone: 'UTC', theme: 'dark' },
        notifications: user.notifications || { email: true, sms: false, browser: true },
        createdAt: user.createdAt,
      },
      token,
    };
  } catch (error) {
    console.error('Registration error:', error);
    throw error;
  }
}

/**
 * Sign in user
 */
async function signin(credentials) {
  try {
    const { email, password } = credentials;

    // Validate input
    if (!email || !password) {
      throw new Error('Email and password are required');
    }

    // Find user
    const user = await User.findOne({ email: email.toLowerCase() });
    if (!user) {
      throw new Error('Invalid email or password');
    }

    // Check if account is active
    if (!user.isActive) {
      throw new Error('Account is deactivated. Please contact support.');
    }

    // Verify password
    const isValidPassword = await comparePassword(password, user.password);

    if (!isValidPassword) {
      throw new Error('Invalid email or password');
    }

    // Generate token
    const token = generateToken(user);

    // Return user data (without password)
    return {
      success: true,
      message: 'Sign in successful',
      user: {
        id: user._id,
        email: user.email,
        name: user.name,
        firstName: user.firstName,
        lastName: user.lastName,
        phone: user.phone,
        tier: user.tier,
        profileImage: user.profileImage,
        preferences: user.preferences || { language: 'en', timezone: 'UTC', theme: 'dark' },
        notifications: user.notifications || { email: true, sms: false, browser: true },
        createdAt: user.createdAt,
      },
      token,
    };
  } catch (error) {
    console.error('Sign in error:', error);
    throw error;
  }
}

/**
 * Get user by ID
 */
async function getUserById(userId) {
  try {
    const user = await User.findById(userId).select('-password').maxTimeMS(10000);
    if (!user) {
      throw new Error('User not found');
    }
    return user;
  } catch (error) {
    throw new Error('User not found');
  }
}

/**
 * Get user by email
 */
async function getUserByEmail(email) {
  try {
    const user = await User.findOne({ email: email.toLowerCase() }).select('-password');
    return user;
  } catch (error) {
    return null;
  }
}

/**
 * Update user profile
 */
async function updateProfile(userId, updates) {
  try {
    const allowedUpdates = [
      'name',
      'firstName',
      'lastName',
      'profileImage',
      'phone',
      'bio',
      'email',
    ];
    const filteredUpdates = {};

    allowedUpdates.forEach(field => {
      if (updates[field] !== undefined) {
        filteredUpdates[field] = updates[field];
      }
    });

    const user = await User.findByIdAndUpdate(userId, filteredUpdates, {
      new: true,
      runValidators: true,
    }).select('-password');

    if (!user) {
      throw new Error('User not found');
    }

    return {
      success: true,
      message: 'Profile updated successfully',
      user,
    };
  } catch (error) {
    throw error;
  }
}

/**
 * Change password
 */
async function changePassword(userId, oldPassword, newPassword) {
  try {
    // Validate new password
    if (newPassword.length < 8) {
      throw new Error('New password must be at least 8 characters long');
    }

    // Get user with password
    const user = await User.findById(userId);
    if (!user) {
      throw new Error('User not found');
    }

    // Verify old password
    const isValidPassword = await comparePassword(oldPassword, user.password);
    if (!isValidPassword) {
      throw new Error('Current password is incorrect');
    }

    // Hash new password
    const hashedPassword = await hashPassword(newPassword);

    // Update password
    user.password = hashedPassword;
    await user.save();

    return {
      success: true,
      message: 'Password changed successfully',
    };
  } catch (error) {
    throw error;
  }
}

/**
 * Update user credits
 */
async function updateCredits(userId, credits) {
  try {
    const user = await User.findByIdAndUpdate(
      userId,
      { $inc: { credits: credits } },
      { new: true }
    ).select('-password');

    if (!user) {
      throw new Error('User not found');
    }

    return user;
  } catch (error) {
    throw error;
  }
}

/**
 * Deduct credits
 */
async function deductCredits(userId, amount) {
  try {
    const user = await User.findById(userId);

    if (!user) {
      throw new Error('User not found');
    }

    if (user.credits < amount) {
      throw new Error('Insufficient credits');
    }

    user.credits -= amount;
    await user.save();

    return {
      success: true,
      creditsRemaining: user.credits,
    };
  } catch (error) {
    throw error;
  }
}

/**
 * Get user statistics
 */
async function getUserStats(userId) {
  try {
    const { Chat, UsageAnalytics } = require('./models');

    const user = await User.findById(userId).select('-password');
    if (!user) {
      throw new Error('User not found');
    }

    // Get chat count
    const chatCount = await Chat.countDocuments({ userId, isActive: true });

    // Get today's usage
    const today = new Date().toISOString().split('T')[0];
    const todayUsage = await UsageAnalytics.findOne({ userId, date: today });

    return {
      user: {
        id: user._id,
        email: user.email,
        name: user.name,
        phone: user.phone,
        firstName: user.firstName,
        lastName: user.lastName,
        profileImage: user.profileImage,
        tier: user.tier,
        createdAt: user.createdAt,
        updatedAt: user.updatedAt,
      },
      stats: {
        totalChats: chatCount,
        todayMessages: todayUsage?.messagesCount || 0,
      },
    };
  } catch (error) {
    throw error;
  }
}

module.exports = {
  generateToken,
  verifyToken,
  hashPassword,
  comparePassword,
  register,
  signin,
  getUserById,
  getUserByEmail,
  updateProfile,
  changePassword,
  updateCredits,
  deductCredits,
  getUserStats,
};
