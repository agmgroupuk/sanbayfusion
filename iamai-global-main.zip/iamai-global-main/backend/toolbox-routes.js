const express = require('express');
const router = express.Router();
const axios = require('axios');
const dns = require('dns').promises;
const ping = require('ping');
const whois = require('whois');
const crypto = require('crypto');
const { authenticate } = require('./auth-middleware');
const { validateToolboxSubscription, trackToolboxUsage } = require('./ai-lab-auth');
const { ToolboxAccess, ToolboxUsageAnalytics } = require('./ai-lab-models');

// Simple toolbox access validation middleware
const validateToolboxAccess = async (req, res, next) => {
  try {
    const userId = req.userId || req.user?._id;

    if (!userId) {
      return res.status(401).json({
        success: false,
        error: 'Authentication required',
      });
    }

    // For now, allow all authenticated users to access toolbox
    // TODO: Add subscription validation later
    req.userId = userId;
    next();
  } catch (error) {
    console.error('Toolbox access validation error:', error);
    res.status(500).json({
      success: false,
      error: 'Internal server error',
    });
  }
};

// ============================================
// TOOLBOX DASHBOARD & STATUS
// ============================================

// Get toolbox dashboard data (requires any active IAMAI subscription)
router.get('/dashboard', validateToolboxSubscription, async (req, res) => {
  try {
    const userId = req.userId;

    // Get today's analytics
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const todayAnalytics = await ToolboxUsageAnalytics.findOne({
      userId,
      'usage.date': { $gte: today },
    });

    // Get weekly analytics
    const weekAgo = new Date();
    weekAgo.setDate(weekAgo.getDate() - 7);

    const weeklyAnalytics = await ToolboxUsageAnalytics.find({
      userId,
      'usage.date': { $gte: weekAgo },
    });

    // Default toolbox permissions for authenticated users
    const defaultPermissions = {
      maxToolUsagePerDay: 100,
      maxToolUsagePerMonth: 1000,
      allowedTools: ['dns', 'ping', 'whois', 'ssl', 'headers', 'ip-info'],
      premiumTools: ['threat-intel', 'domain-research'],
      canExportData: true,
      canUseBulkOperations: false,
    };

    // Default subscription info
    const defaultSubscription = {
      type: 'FREE',
      expiresAt: null,
      isActive: true,
    };

    res.json({
      success: true,
      data: {
        subscription: defaultSubscription,
        permissions: defaultPermissions,
        usage: {
          today: {
            toolUsage: todayAnalytics?.usage?.totalUsage || 0,
            limit: defaultPermissions.maxToolUsagePerDay,
            toolsUsed: todayAnalytics?.usage?.toolsUsed || [],
            breakdown: todayAnalytics?.usage?.breakdown || {},
          },
          total: {
            toolUsage: 0, // Will be calculated from analytics
            favoriteTools: [],
            allToolsUsed: [],
          },
          weekly: weeklyAnalytics.map(analytics => ({
            date: analytics.usage.date,
            queries: analytics.usage.totalQueries,
            tools: analytics.usage.toolsUsed.length,
          })),
        },
      },
    });
  } catch (error) {
    console.error('Toolbox dashboard error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to load toolbox dashboard',
    });
  }
});

// ============================================
// NETWORK TOOLS
// ============================================

// IP Information Lookup
router.post(
  '/network/ip-info',
  validateToolboxSubscription,
  trackToolboxUsage('networkTools'),
  async (req, res) => {
    try {
      const { ip } = req.body;

      if (!ip) {
        return res.status(400).json({
          success: false,
          error: 'IP address is required',
        });
      }

      const response = await axios.get(
        `http://ip-api.com/json/${ip}?fields=status,message,continent,continentCode,country,countryCode,region,regionName,city,zip,lat,lon,timezone,offset,currency,isp,org,as,asname,reverse,mobile,proxy,hosting,query`
      );

      res.json({
        success: true,
        data: response.data,
        toolUsed: 'ip-info',
        usageCount: req.toolboxAccess.usage.todayToolUsage + 1,
      });
    } catch (error) {
      console.error('IP Info error:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to lookup IP information',
      });
    }
  }
);

// DNS Lookup
router.post(
  '/network/dns-lookup',
  validateToolboxSubscription,
  trackToolboxUsage('networkTools'),
  async (req, res) => {
    try {
      const { domain, recordType } = req.body;

      if (!domain) {
        return res.status(400).json({
          success: false,
          error: 'Domain is required',
        });
      }

      let result = {};

      try {
        switch (recordType) {
          case 'A':
            result.A = await dns.resolve4(domain);
            break;
          case 'AAAA':
            result.AAAA = await dns.resolve6(domain);
            break;
          case 'MX':
            result.MX = await dns.resolveMx(domain);
            break;
          case 'TXT':
            result.TXT = await dns.resolveTxt(domain);
            break;
          case 'NS':
            result.NS = await dns.resolveNs(domain);
            break;
          case 'CNAME':
            result.CNAME = await dns.resolveCname(domain);
            break;
          default:
            // Get all records
            const [a, aaaa, mx, txt, ns] = await Promise.allSettled([
              dns.resolve4(domain).catch(() => []),
              dns.resolve6(domain).catch(() => []),
              dns.resolveMx(domain).catch(() => []),
              dns.resolveTxt(domain).catch(() => []),
              dns.resolveNs(domain).catch(() => []),
            ]);

            result = {
              A: a.status === 'fulfilled' ? a.value : [],
              AAAA: aaaa.status === 'fulfilled' ? aaaa.value : [],
              MX: mx.status === 'fulfilled' ? mx.value : [],
              TXT: txt.status === 'fulfilled' ? txt.value : [],
              NS: ns.status === 'fulfilled' ? ns.value : [],
            };
        }
      } catch (dnsError) {
        result.error = dnsError.message;
      }

      res.json({
        success: true,
        data: {
          domain,
          recordType: recordType || 'ALL',
          records: result,
        },
        toolUsed: 'dns-lookup',
        usageCount: req.toolboxAccess.usage.todayToolUsage + 1,
      });
    } catch (error) {
      console.error('DNS Lookup error:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to perform DNS lookup',
      });
    }
  }
);

// Ping Tool
router.post(
  '/network/ping',
  validateToolboxSubscription,
  trackToolboxUsage('networkTools'),
  async (req, res) => {
    try {
      const { host, count = 4 } = req.body;

      if (!host) {
        return res.status(400).json({
          success: false,
          error: 'Host is required',
        });
      }

      const results = [];

      for (let i = 0; i < Math.min(count, 10); i++) {
        try {
          const result = await ping.promise.probe(host, {
            timeout: 5,
            extra: ['-c', '1'],
          });
          results.push({
            seq: i + 1,
            time: result.time,
            alive: result.alive,
          });
        } catch (pingError) {
          results.push({
            seq: i + 1,
            error: pingError.message,
            alive: false,
          });
        }
      }

      res.json({
        success: true,
        data: {
          host,
          results,
          summary: {
            packetsTransmitted: results.length,
            packetsReceived: results.filter(r => r.alive).length,
            packetLoss:
              (
                ((results.length - results.filter(r => r.alive).length) / results.length) *
                100
              ).toFixed(1) + '%',
            avgTime:
              results
                .filter(r => r.alive && r.time)
                .reduce((sum, r) => sum + parseFloat(r.time), 0) /
                results.filter(r => r.alive && r.time).length || 0,
          },
        },
        toolUsed: 'ping',
        usageCount: req.toolboxAccess.usage.todayToolUsage + 1,
      });
    } catch (error) {
      console.error('Ping error:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to ping host',
      });
    }
  }
);

// ============================================
// DOMAIN TOOLS
// ============================================

// WHOIS Lookup
router.post(
  '/domain/whois',
  validateToolboxSubscription,
  trackToolboxUsage('domainTools'),
  async (req, res) => {
    try {
      const { domain } = req.body;

      if (!domain) {
        return res.status(400).json({
          success: false,
          error: 'Domain is required',
        });
      }

      const whoisResult = await new Promise((resolve, reject) => {
        whois.lookup(domain, (err, data) => {
          if (err) reject(err);
          else resolve(data);
        });
      });

      res.json({
        success: true,
        data: {
          domain,
          whoisData: whoisResult,
        },
        toolUsed: 'whois',
        usageCount: req.toolboxAccess.usage.todayToolUsage + 1,
      });
    } catch (error) {
      console.error('WHOIS error:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to perform WHOIS lookup',
      });
    }
  }
);

// ============================================
// SECURITY TOOLS (Premium)
// ============================================

// SSL Certificate Checker
router.post(
  '/security/ssl-check',
  validateToolboxSubscription,
  (req, res, next) => {
    if (!req.toolboxAccess.permissions.canAccessSecurityTools) {
      return res.status(403).json({
        success: false,
        error: 'SSL tools require a weekly subscription or higher',
        code: 'FEATURE_LOCKED',
        upgradeRequired: true,
      });
    }
    next();
  },
  trackToolboxUsage('securityTools'),
  async (req, res) => {
    try {
      const { domain } = req.body;

      if (!domain) {
        return res.status(400).json({
          success: false,
          error: 'Domain is required',
        });
      }

      const https = require('https');

      const sslInfo = await new Promise((resolve, reject) => {
        const options = {
          hostname: domain,
          port: 443,
          method: 'HEAD',
          timeout: 10000,
        };

        const req = https.request(options, res => {
          const cert = res.connection.getPeerCertificate();
          resolve({
            valid: res.connection.authorized,
            issuer: cert.issuer,
            subject: cert.subject,
            validFrom: cert.valid_from,
            validTo: cert.valid_to,
            fingerprint: cert.fingerprint,
            serialNumber: cert.serialNumber,
          });
        });

        req.on('error', reject);
        req.on('timeout', () => reject(new Error('SSL check timeout')));
        req.end();
      });

      res.json({
        success: true,
        data: {
          domain,
          ssl: sslInfo,
        },
        toolUsed: 'ssl-check',
        usageCount: req.toolboxAccess.usage.todayToolUsage + 1,
      });
    } catch (error) {
      console.error('SSL Check error:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to check SSL certificate',
      });
    }
  }
);

// ============================================
// UTILITY TOOLS
// ============================================

// URL Shortener
router.post(
  '/utility/url-shortener',
  validateToolboxSubscription,
  trackToolboxUsage('utilityTools'),
  async (req, res) => {
    try {
      const { url } = req.body;

      if (!url) {
        return res.status(400).json({
          success: false,
          error: 'URL is required',
        });
      }

      // Generate short code
      const shortCode = crypto.randomBytes(4).toString('hex');
      const shortUrl = `https://short.ly/${shortCode}`;

      res.json({
        success: true,
        data: {
          originalUrl: url,
          shortUrl,
          shortCode,
          createdAt: new Date(),
        },
        toolUsed: 'url-shortener',
        usageCount: req.toolboxAccess.usage.todayToolUsage + 1,
      });
    } catch (error) {
      console.error('URL Shortener error:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to shorten URL',
      });
    }
  }
);

// Base64 Encoder/Decoder
router.post(
  '/utility/base64',
  validateToolboxSubscription,
  trackToolboxUsage('utilityTools'),
  async (req, res) => {
    try {
      const { text, operation } = req.body;

      if (!text || !operation) {
        return res.status(400).json({
          success: false,
          error: 'Text and operation (encode/decode) are required',
        });
      }

      let result;

      if (operation === 'encode') {
        result = Buffer.from(text, 'utf8').toString('base64');
      } else if (operation === 'decode') {
        result = Buffer.from(text, 'base64').toString('utf8');
      } else {
        return res.status(400).json({
          success: false,
          error: 'Operation must be either "encode" or "decode"',
        });
      }

      res.json({
        success: true,
        data: {
          operation,
          input: text,
          result,
        },
        toolUsed: 'base64',
        usageCount: req.toolboxAccess.usage.todayToolUsage + 1,
      });
    } catch (error) {
      console.error('Base64 error:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to process Base64 operation',
      });
    }
  }
);

// ============================================
// WEB TOOLS (Weekly+)
// ============================================

// Meta Tags Extractor
router.post(
  '/web/meta-tags',
  validateToolboxSubscription,
  (req, res, next) => {
    if (!req.toolboxAccess.permissions.canAccessWebTools) {
      return res.status(403).json({
        success: false,
        error: 'Web tools require a weekly subscription or higher',
        code: 'FEATURE_LOCKED',
        upgradeRequired: true,
      });
    }
    next();
  },
  trackToolboxUsage('webTools'),
  async (req, res) => {
    try {
      const { url } = req.body;

      if (!url) {
        return res.status(400).json({
          success: false,
          error: 'URL is required',
        });
      }

      const cheerio = require('cheerio');
      const response = await axios.get(url, {
        timeout: 10000,
        headers: {
          'User-Agent': 'Mozilla/5.0 (compatible; ToolboxBot/1.0)',
        },
      });

      const $ = cheerio.load(response.data);

      const metaTags = {
        title: $('title').text(),
        description: $('meta[name="description"]').attr('content'),
        keywords: $('meta[name="keywords"]').attr('content'),
        author: $('meta[name="author"]').attr('content'),
        viewport: $('meta[name="viewport"]').attr('content'),
        robots: $('meta[name="robots"]').attr('content'),

        // Open Graph
        ogTitle: $('meta[property="og:title"]').attr('content'),
        ogDescription: $('meta[property="og:description"]').attr('content'),
        ogImage: $('meta[property="og:image"]').attr('content'),
        ogUrl: $('meta[property="og:url"]').attr('content'),
        ogType: $('meta[property="og:type"]').attr('content'),

        // Twitter Card
        twitterCard: $('meta[name="twitter:card"]').attr('content'),
        twitterTitle: $('meta[name="twitter:title"]').attr('content'),
        twitterDescription: $('meta[name="twitter:description"]').attr('content'),
        twitterImage: $('meta[name="twitter:image"]').attr('content'),
      };

      res.json({
        success: true,
        data: {
          url,
          metaTags: Object.fromEntries(
            Object.entries(metaTags).filter(([_, value]) => value !== undefined)
          ),
        },
        toolUsed: 'meta-tags',
        usageCount: req.toolboxAccess.usage.todayToolUsage + 1,
      });
    } catch (error) {
      console.error('Meta Tags error:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to extract meta tags',
      });
    }
  }
);

// ============================================
// DEVELOPMENT TOOLS (Weekly+)
// ============================================

// API Tester
router.post(
  '/development/api-test',
  validateToolboxSubscription,
  (req, res, next) => {
    if (!req.toolboxAccess.permissions.canAccessDevelopmentTools) {
      return res.status(403).json({
        success: false,
        error: 'Development tools require a weekly subscription or higher',
        code: 'FEATURE_LOCKED',
        upgradeRequired: true,
      });
    }
    next();
  },
  trackToolboxUsage('developmentTools'),
  async (req, res) => {
    try {
      const { url, method = 'GET', headers = {}, body } = req.body;

      if (!url) {
        return res.status(400).json({
          success: false,
          error: 'URL is required',
        });
      }

      const config = {
        url,
        method: method.toLowerCase(),
        headers,
        timeout: 10000,
      };

      if (body && ['post', 'put', 'patch'].includes(method.toLowerCase())) {
        config.data = body;
      }

      const startTime = Date.now();
      const response = await axios(config);
      const responseTime = Date.now() - startTime;

      res.json({
        success: true,
        data: {
          request: {
            url,
            method,
            headers,
            body,
          },
          response: {
            status: response.status,
            statusText: response.statusText,
            headers: response.headers,
            data: response.data,
            responseTime: `${responseTime}ms`,
          },
        },
        toolUsed: 'api-test',
        usageCount: req.toolboxAccess.usage.todayToolUsage + 1,
      });
    } catch (error) {
      const responseTime = Date.now() - (error.config?.metadata?.startTime || Date.now());

      res.json({
        success: false,
        data: {
          request: req.body,
          error: {
            message: error.message,
            status: error.response?.status,
            statusText: error.response?.statusText,
            data: error.response?.data,
            responseTime: `${responseTime}ms`,
          },
        },
        toolUsed: 'api-test',
        usageCount: req.toolboxAccess.usage.todayToolUsage + 1,
      });
    }
  }
);

// ============================================
// MONITORING TOOLS (Monthly+)
// ============================================

// Website Uptime Checker
router.post(
  '/monitoring/uptime-check',
  validateToolboxSubscription,
  (req, res, next) => {
    if (!req.toolboxAccess.permissions.canAccessMonitoringTools) {
      return res.status(403).json({
        success: false,
        error: 'Monitoring tools require a monthly subscription or higher',
        code: 'FEATURE_LOCKED',
        upgradeRequired: true,
      });
    }
    next();
  },
  trackToolboxUsage('monitoringTools'),
  async (req, res) => {
    try {
      const { url } = req.body;

      if (!url) {
        return res.status(400).json({
          success: false,
          error: 'URL is required',
        });
      }

      const startTime = Date.now();

      try {
        const response = await axios.get(url, {
          timeout: 30000,
          validateStatus: () => true, // Accept any status code
        });

        const responseTime = Date.now() - startTime;

        res.json({
          success: true,
          data: {
            url,
            status: 'up',
            statusCode: response.status,
            responseTime: `${responseTime}ms`,
            headers: response.headers,
            checkedAt: new Date(),
          },
          toolUsed: 'uptime-check',
          usageCount: req.toolboxAccess.usage.todayToolUsage + 1,
        });
      } catch (error) {
        const responseTime = Date.now() - startTime;

        res.json({
          success: true,
          data: {
            url,
            status: 'down',
            error: error.message,
            responseTime: `${responseTime}ms`,
            checkedAt: new Date(),
          },
          toolUsed: 'uptime-check',
          usageCount: req.toolboxAccess.usage.todayToolUsage + 1,
        });
      }
    } catch (error) {
      console.error('Uptime Check error:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to check website uptime',
      });
    }
  }
);

module.exports = router;
