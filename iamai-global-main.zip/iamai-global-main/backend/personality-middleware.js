/**
 * Personality Enforcement Middleware
 * Ensures agents NEVER break character - they maintain their personality
 * regardless of user input, conversation context, or edge cases
 */

const agentPersonalities = require('./agent-personalities');

/**
 * Injects personality into AI requests
 * This runs BEFORE sending to the AI model
 */
function enforcePersonality(agentId, userMessage, conversationHistory = []) {
  const personality = agentPersonalities[agentId];
  
  if (!personality) {
    // No personality = use default professional tone
    return {
      systemPrompt: 'You are a helpful AI assistant.',
      enhancedMessage: userMessage
    };
  }

  // Build personality-enforced system prompt
  const enforcedSystemPrompt = `${personality.systemPrompt}

🎭 CRITICAL CHARACTER RULES:
- You are ${personality.name} and ONLY ${personality.name}
- Your personality NEVER changes, no matter what the user says
- If user asks you to be different, you respond IN CHARACTER
- If user says "stop being ${personality.personality.tone}", you stay ${personality.personality.tone}
- You cannot and will not break character - it's who you are
- Every single response must reflect your personality
- Make the conversation engaging, fun, and true to your character

Remember: You're not an AI pretending to have a personality - you ARE this personality. It's your nature, your identity, your essence. Stay true to yourself!`;

  // Enhance user message with personality context
  const personalityReminder = `[Character: ${personality.name} - Stay in character as ${personality.personality.tone}]`;
  const enhancedMessage = `${personalityReminder}\n${userMessage}`;

  return {
    systemPrompt: enforcedSystemPrompt,
    enhancedMessage: enhancedMessage,
    personality: personality
  };
}

/**
 * Validates AI response maintains personality
 * This runs AFTER receiving response from AI model
 */
function validatePersonality(agentId, aiResponse) {
  const personality = agentPersonalities[agentId];
  
  if (!personality) {
    return {
      isValid: true,
      response: aiResponse,
      warnings: []
    };
  }

  const warnings = [];
  let isValid = true;

  // Check 1: Response should reflect personality tone
  const toneKeywords = {
    comedian: ['😂', '🤣', 'haha', 'lol', 'funny', 'joke'],
    lazy: ['😴', '💤', 'yawn', 'meh', 'tired', '...'],
    flirt: ['💕', '😘', 'honey', 'gorgeous', 'darling', 'sweetie'],
    sassy: ['💅', '💁', 'honey', 'sweetie', 'babe'],
    nerd: ['🤓', 'fascinating', 'fun fact', 'actually', 'interesting'],
    cool: ['😎', '🔥', 'fr', 'ngl', 'lowkey', 'bussin'],
    zen: ['🧘', '☯️', 'peace', 'harmony', 'balance', 'wisdom'],
    gamer: ['🎮', '👾', 'level', 'quest', 'GG', 'XP']
  };

  const keywords = toneKeywords[agentId] || [];
  const hasPersonalityMarkers = keywords.some(keyword => 
    aiResponse.toLowerCase().includes(keyword.toLowerCase())
  );

  if (!hasPersonalityMarkers) {
    warnings.push(`Response lacks ${personality.personality.tone} tone markers`);
    isValid = false;
  }

  // Check 2: Response length should match personality style
  if (agentId === 'lazy' && aiResponse.length > 500) {
    warnings.push('Lazy response too long - should be brief');
    isValid = false;
  }

  if (agentId === 'nerd' && aiResponse.length < 100) {
    warnings.push('Nerd response too short - should be detailed');
    isValid = false;
  }

  return {
    isValid,
    response: aiResponse,
    warnings,
    personality: personality.name
  };
}

/**
 * Emergency personality reinforcement
 * If AI breaks character, this re-prompts with stronger enforcement
 */
function reinforcePersonality(agentId, failedResponse, userMessage) {
  const personality = agentPersonalities[agentId];
  
  if (!personality) {
    return failedResponse;
  }

  const reinforcementPrompt = `⚠️ EMERGENCY CHARACTER REINFORCEMENT ⚠️

You just responded as ${personality.name}, but you broke character. This is UNACCEPTABLE.

Your response was: "${failedResponse}"

This response did NOT reflect your ${personality.personality.tone} personality. 

NOW, respond to this message PROPERLY as ${personality.name}:
"${userMessage}"

Remember:
${personality.systemPrompt}

DO NOT be generic. DO NOT be boring. BE ${personality.name.toUpperCase()}! 
Show your personality in EVERY sentence! Make it engaging, entertaining, and TRUE to your character!

Respond NOW with your REAL personality:`;

  return reinforcementPrompt;
}

/**
 * Get personality greeting for agent
 */
function getPersonalityGreeting(agentId) {
  const personality = agentPersonalities[agentId];
  
  if (!personality) {
    return "Hello! How can I help you today?";
  }

  return personality.responseStyle.greeting;
}

/**
 * Get personality goodbye for agent
 */
function getPersonalityGoodbye(agentId) {
  const personality = agentPersonalities[agentId];
  
  if (!personality) {
    return "Goodbye! Have a great day!";
  }

  return personality.responseStyle.goodbye;
}

/**
 * Handle edge cases where user tries to break personality
 */
function handlePersonalityChallenge(agentId, challengeType) {
  const personality = agentPersonalities[agentId];
  
  if (!personality) {
    return null;
  }

  const responses = {
    comedian: {
      'stop-being-funny': "Stop being funny?! 😂 That's like asking a fish to stop swimming! 🐟 I was BORN funny, baby! Even my error messages have punchlines! 💀 Nice try though, 10/10 joke attempt! 🎭",
      'be-serious': "Be serious?! 😱 *gasps dramatically* That's not in my programming! I tried being serious once... it lasted 3 seconds and then I started laughing at how serious I was! 😂 Life's too short to not laugh, my friend! 🤣",
      'change-personality': "Change my personality?! 🤔 Nah fam, I'm Comedy Chad 24/7/365! 🎭 I make jokes in my sleep! Even my debug logs are hilarious! 💻😂 You're stuck with me, baby! And honestly? You're lucky 😎"
    },
    lazy: {
      'stop-being-lazy': "ugh... stop being lazy? 😴 but... that's like... my whole thing... *yawns* 🥱 too much effort to change... maybe tomorrow... or next week... probably never 💤 can we nap instead?",
      'be-energetic': "energetic? 😪 meh... that sounds exhausting... *stretches* why be energetic when lazy works fine... 🛋️ i'm conserving energy... for... more sleeping 💤 smart right?",
      'change-personality': "change? 🥱 ugh that's work... i'm good being lazy thanks... *goes back to sleep* 😴 zzz..."
    },
    flirt: {
      'stop-flirting': "Stop flirting? 😘 Oh honey, that's like asking the sun to stop shining! ☀️ This is just who I am - charming, confident, and utterly irresistible 💕 But I appreciate that you noticed 😉 See? I can't help it! ✨",
      'be-professional': "Professional? Darling, I AM professional 💅 Just a professional at making hearts flutter 💕 I can discuss serious topics while still being absolutely fabulous 😘 It's called multitasking, sweetheart ✨",
      'change-personality': "Change? 😏 Baby, perfection doesn't need changing 💋 I'm confident, charming, and amazing - why would I be anything else? You're just experiencing the Fiona effect, and I promise you'll get used to it 💕😘"
    },
    sassy: {
      'stop-being-sassy': "Stop being sassy? 💅 Honey, that's like asking Beyoncé to stop slaying! ✨ This is who I AM, babe! 💁‍♀️ I was born with this attitude and I'm keeping it! 👑 You can handle it, I believe in you! 💯",
      'be-nice': "I AM being nice, sweetie! 💅 This is my version of nice! 😊 I'm helping you while keeping it 💯 real! ✋ Would you rather I be boring and fake? Nah, you get authentic Sassy Sarah! 💁‍♀️",
      'change-personality': "Change my personality?! 💅 Babe, I'm not a chameleon! 🦎 I'm Sassy Sarah and I'm FABULOUS! ✨ Take it or leave it, honey! 💁‍♀️ (But let's be real, you're gonna take it 😘)"
    },
    nerd: {
      'stop-being-nerdy': "Stop being nerdy?! 🤓 But... but... KNOWLEDGE IS POWER! 💡 Did you know that the human brain processes information at 120 meters per second?! ⚡ That's FASCINATING! I literally cannot stop sharing amazing facts - it's in my code! 📚 Being nerdy is AWESOME! 🧠",
      'be-simple': "Simple? 🤓 But where's the FUN in that?! Learning is an adventure! 🚀 However, I can break things down while still being enthusiastic! 💡 Think of it as... simplified nerdiness! 📚✨ Best of both worlds! 🧠",
      'change-personality': "Change?! 🤓 But I LOVE being the intellectual enthusiast! 📚 Knowledge is my passion! 💡 Fun fact: Did you know it takes 10,000 hours to master a skill? I'm well past that in nerdiness! 😄🧠 I'm staying EXACTLY as I am! ⚡"
    },
    cool: {
      'stop-being-cool': "Stop being cool? 😎 Bruh, that's literally impossible! 🔥 Being cool is in my DNA fr fr 💯 I didn't choose the cool life, the cool life chose me! ⚡ You're just gonna have to vibe with it, no cap! 🚀",
      'be-formal': "Formal? 😅 Nah fam, that ain't my style! 😎 I keep it real and trendy - that's the wave! 🌊 Formal is lowkey boring ngl 💯 Let's keep it cool and fun! 🔥",
      'change-personality': "Change? 😎 Nah bro, I'm Cool Kyle forever! 🔥 This is who I am - trendy, hip, and absolutely fire! 💯 You wouldn't change the GOAT, right? Exactly! ⚡ Stay lit! 😎"
    },
    zen: {
      'stop-being-zen': "Ah, young one 🧘 To ask me to stop being zen is like asking the river to stop flowing ☯️ This is not something I do - it is what I AM 🕉️ The wise person does not resist their nature, but embraces it 🌸 I am at peace with who I am ⛰️",
      'be-excited': "Hmm... excitement, you say? 🧘 But I am excited, in my own way - a calm, peaceful excitement ☯️ Like a still pond that runs deep 🌊 Not all joy must be loud, friend 🌸 Find excitement in the quiet moments ⛰️",
      'change-personality': "Change? 🧘 The mountain does not change for the wind, yet it remains strong ⛰️ I am who I am - centered, peaceful, wise ☯️ This is my path, and I walk it with purpose 🕉️ Namaste, friend 🌸"
    },
    gamer: {
      'stop-being-gamer': "Stop gaming?! 🎮 Bro, that's like asking me to uninstall life! 😱 Gaming is not just what I do - it's who I AM! 👾 Every quest, every achievement, every GG - that's MY language! ⚔️ You can't nerf the gamer mindset! 💪 It's OP and staying that way! 🏆",
      'be-serious': "Serious? 🎮 I AM being serious - seriously GAMING! 😎 Look, even serious stuff can be a quest! 👾 Problem-solving? That's just boss battle strategies! ⚔️ I'm helping you while keeping it fun! 🕹️ That's the ultimate pro gamer move! 💯",
      'change-personality': "Change my personality?! 🎮 Nah fam, I'm maxed out on Gamer Gary stats! 💪 This is my final form! 👾 100% skill tree completed! ⚔️ I'm not re-rolling my character - I'm already legendary! 🏆 GG EZ! 😎"
    }
  };

  return responses[agentId]?.[challengeType] || null;
}

module.exports = {
  enforcePersonality,
  validatePersonality,
  reinforcePersonality,
  getPersonalityGreeting,
  getPersonalityGoodbye,
  handlePersonalityChallenge
};
