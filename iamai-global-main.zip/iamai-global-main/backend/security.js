// Advanced Security System for IAMAI Global
// Features: Rate limiting, DDoS protection, security monitoring, threat detection, encryption

const express = require('express');
const rateLimit = require('express-rate-limit');
const slowDown = require('express-slow-down');
const helmet = require('helmet');
const crypto = require('crypto');
const logger = require('./logger.js');
const cacheManager = require('./cache.js');

// Security configuration
const securityConfig = {
  rateLimit: {
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100, // limit each IP to 100 requests per windowMs
    message: {
      error: 'Too many requests from this IP, please try again later.',
      retryAfter: '15 minutes'
    },
    standardHeaders: true,
    legacyHeaders: false,
    skip: (req) => {
      // Skip rate limiting for health checks
      return req.path === '/health' || req.path === '/metrics';
    }
  },
  strictRateLimit: {
    windowMs: 60 * 1000, // 1 minute
    max: 10, // limit each IP to 10 requests per minute
    message: {
      error: 'Too many requests, please slow down.',
      retryAfter: '1 minute'
    }
  },
  authRateLimit: {
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 5, // limit each IP to 5 auth attempts per windowMs
    message: {
      error: 'Too many authentication attempts, please try again later.',
      retryAfter: '15 minutes'
    }
  }
};

// Threat detection patterns
const threatPatterns = {
  sqlInjection: [
    /(\bUNION\b|\bSELECT\b|\bINSERT\b|\bUPDATE\b|\bDELETE\b|\bDROP\b|\bCREATE\b|\bALTER\b)/i,
    /('|(\\x27)|(\\x2D\\x2D)|(\\#)|(\%27)|(\%23))/i,
    /('|(\\x27)|(\\x2D\\x2D)|(\\#)|(\%27)|(\%23)|(\;)|(\%3B))/i
  ],
  xss: [
    /<script[^>]*>.*?<\/script>/gi,
    /javascript:/gi,
    /on\w+\s*=/gi,
    /<iframe[^>]*>.*?<\/iframe>/gi
  ],
  pathTraversal: [
    /\.\.\//g,
    /\.\\/g,
    /%2e%2e%2f/gi,
    /%2e%2e\\/gi
  ],
  commandInjection: [
    /[\;\|\&\$\`\(\)\{\}\[\]\<\>]/g,
    /\|/g,
    /\;/g,
    /\&\&/g,
    /\|\|/g
  ]
};

// IP reputation and blocking
class IPReputationManager {
  constructor() {
    this.blockedIPs = new Set();
    this.suspiciousIPs = new Map();
    this.whitelistedIPs = new Set();
    this.reputationScores = new Map();
  }

  async checkIP(ip) {
    // Check if IP is blocked
    if (this.blockedIPs.has(ip)) {
      return { status: 'blocked', reason: 'IP is blocked' };
    }

    // Check if IP is whitelisted
    if (this.whitelistedIPs.has(ip)) {
      return { status: 'allowed', reason: 'IP is whitelisted' };
    }

    // Get reputation score
    const score = this.reputationScores.get(ip) || 0;

    if (score > 100) {
      this.blockedIPs.add(ip);
      logger.security('IP blocked due to high reputation score', { ip, score });
      return { status: 'blocked', reason: 'High reputation score' };
    }

    if (score > 50) {
      return { status: 'suspicious', reason: 'Elevated reputation score' };
    }

    return { status: 'allowed', reason: 'Normal reputation' };
  }

  increaseReputation(ip, points = 1, reason = 'unknown') {
    const currentScore = this.reputationScores.get(ip) || 0;
    const newScore = currentScore + points;
    this.reputationScores.set(ip, newScore);

    logger.security('IP reputation increased', { ip, oldScore: currentScore, newScore, reason });

    // Auto-block if score gets too high
    if (newScore > 100) {
      this.blockedIPs.add(ip);
      logger.security('IP automatically blocked', { ip, score: newScore });
    }
  }

  decreaseReputation(ip, points = 1, reason = 'unknown') {
    const currentScore = this.reputationScores.get(ip) || 0;
    const newScore = Math.max(0, currentScore - points);
    this.reputationScores.set(ip, newScore);

    logger.security('IP reputation decreased', { ip, oldScore: currentScore, newScore, reason });
  }

  blockIP(ip, reason = 'manual') {
    this.blockedIPs.add(ip);
    logger.security('IP manually blocked', { ip, reason });
  }

  unblockIP(ip) {
    this.blockedIPs.delete(ip);
    this.reputationScores.delete(ip);
    logger.security('IP unblocked', { ip });
  }

  whitelistIP(ip) {
    this.whitelistedIPs.add(ip);
    this.blockedIPs.delete(ip);
    logger.security('IP whitelisted', { ip });
  }

  getReputationStats() {
    return {
      blockedCount: this.blockedIPs.size,
      whitelistedCount: this.whitelistedIPs.size,
      suspiciousCount: Array.from(this.reputationScores.values()).filter(score => score > 50).length,
      totalTracked: this.reputationScores.size
    };
  }
}

// DDoS protection
class DDoSProtection {
  constructor() {
    this.requestCounts = new Map();
    this.blockedIPs = new Set();
    this.suspiciousPatterns = new Map();
  }

  checkRequest(req) {
    const ip = req.ip;
    const now = Date.now();
    const windowStart = now - 60000; // 1 minute window

    // Clean old entries
    for (const [key, timestamps] of this.requestCounts) {
      this.requestCounts.set(key, timestamps.filter(ts => ts > windowStart));
      if (this.requestCounts.get(key).length === 0) {
        this.requestCounts.delete(key);
      }
    }

    // Get current request count for this IP
    const timestamps = this.requestCounts.get(ip) || [];
    timestamps.push(now);
    this.requestCounts.set(ip, timestamps);

    const requestCount = timestamps.length;

    // Check for DDoS patterns
    if (requestCount > 1000) { // More than 1000 requests per minute
      this.blockedIPs.add(ip);
      logger.security('IP blocked for DDoS protection', { ip, requestCount });
      return { blocked: true, reason: 'DDoS protection - too many requests' };
    }

    if (requestCount > 500) { // More than 500 requests per minute
      logger.security('Suspicious activity detected', { ip, requestCount });
      return { blocked: false, suspicious: true, reason: 'High request rate' };
    }

    return { blocked: false, suspicious: false };
  }

  isBlocked(ip) {
    return this.blockedIPs.has(ip);
  }

  unblockIP(ip) {
    this.blockedIPs.delete(ip);
    logger.security('IP unblocked from DDoS protection', { ip });
  }

  getStats() {
    return {
      blockedIPs: this.blockedIPs.size,
      trackedIPs: this.requestCounts.size,
      totalRequests: Array.from(this.requestCounts.values()).reduce((sum, arr) => sum + arr.length, 0)
    };
  }
}

// Input sanitization and validation
class InputSanitizer {
  static sanitizeString(input) {
    if (typeof input !== 'string') return input;

    return input
      .replace(/<script[^>]*>.*?<\/script>/gi, '')
      .replace(/javascript:/gi, '')
      .replace(/on\w+\s*=/gi, '')
      .replace(/<iframe[^>]*>.*?<\/iframe>/gi, '')
      .trim();
  }

  static detectThreats(input, type = 'general') {
    if (typeof input !== 'string') return [];

    const threats = [];
    const patterns = threatPatterns[type] || [];

    for (const pattern of patterns) {
      if (pattern.test(input)) {
        threats.push({
          type,
          pattern: pattern.toString(),
          severity: this.getThreatSeverity(type)
        });
      }
    }

    return threats;
  }

  static getThreatSeverity(type) {
    const severityMap = {
      sqlInjection: 'critical',
      xss: 'high',
      pathTraversal: 'high',
      commandInjection: 'critical'
    };
    return severityMap[type] || 'medium';
  }

  static sanitizeObject(obj) {
    if (typeof obj !== 'object' || obj === null) return obj;

    const sanitized = Array.isArray(obj) ? [] : {};

    for (const [key, value] of Object.entries(obj)) {
      if (typeof value === 'string') {
        sanitized[key] = this.sanitizeString(value);
      } else if (typeof value === 'object') {
        sanitized[key] = this.sanitizeObject(value);
      } else {
        sanitized[key] = value;
      }
    }

    return sanitized;
  }
}

// Encryption utilities
class EncryptionManager {
  constructor() {
    this.algorithm = 'aes-256-gcm';
    this.keyLength = 32;
    this.ivLength = 16;
    this.tagLength = 16;
  }

  generateKey() {
    return crypto.randomBytes(this.keyLength);
  }

  encrypt(text, key) {
    const iv = crypto.randomBytes(this.ivLength);
    const cipher = crypto.createCipher(this.algorithm, key);

    let encrypted = cipher.update(text, 'utf8', 'hex');
    encrypted += cipher.final('hex');

    const tag = cipher.getAuthTag();

    return {
      encrypted,
      iv: iv.toString('hex'),
      tag: tag.toString('hex')
    };
  }

  decrypt(encryptedData, key) {
    const decipher = crypto.createDecipher(this.algorithm, key);
    decipher.setAuthTag(Buffer.from(encryptedData.tag, 'hex'));

    let decrypted = decipher.update(encryptedData.encrypted, 'hex', 'utf8');
    decrypted += decipher.final('utf8');

    return decrypted;
  }

  hashPassword(password) {
    const salt = crypto.randomBytes(16);
    const hash = crypto.pbkdf2Sync(password, salt, 100000, 64, 'sha512');

    return {
      hash: hash.toString('hex'),
      salt: salt.toString('hex')
    };
  }

  verifyPassword(password, storedHash, salt) {
    const hash = crypto.pbkdf2Sync(password, Buffer.from(salt, 'hex'), 100000, 64, 'sha512');
    return hash.toString('hex') === storedHash;
  }

  generateToken() {
    return crypto.randomBytes(32).toString('hex');
  }

  hashData(data) {
    return crypto.createHash('sha256').update(data).digest('hex');
  }
}

// Security middleware
export const securityMiddleware = (req, res, next) => {
  const ip = req.ip || req.connection.remoteAddress;

  // Check IP reputation
  const ipCheck = ipReputationManager.checkIP(ip);
  if (ipCheck.status === 'blocked') {
    logger.security('Blocked request from bad IP', { ip, reason: ipCheck.reason });
    return res.status(403).json({
      error: 'Access denied',
      reason: ipCheck.status === 'blocked' ? 'IP blocked' : 'Suspicious activity'
    });
  }

  // DDoS protection
  const ddosCheck = ddosProtection.checkRequest(req);
  if (ddosCheck.blocked) {
    logger.security('Request blocked by DDoS protection', { ip, reason: ddosCheck.reason });
    return res.status(429).json({
      error: 'Too many requests',
      reason: 'DDoS protection activated'
    });
  }

  // Threat detection
  const threats = InputSanitizer.detectThreats(JSON.stringify(req.body));
  if (threats.length > 0) {
    const criticalThreats = threats.filter(t => t.severity === 'critical');
    if (criticalThreats.length > 0) {
      ipReputationManager.increaseReputation(ip, 50, 'critical threat detected');
      logger.security('Critical threat detected', { ip, threats: criticalThreats });
      return res.status(403).json({
        error: 'Request blocked',
        reason: 'Security threat detected'
      });
    }

    ipReputationManager.increaseReputation(ip, 10, 'threat detected');
    logger.security('Threat detected', { ip, threats });
  }

  // Sanitize input
  if (req.body) {
    req.body = InputSanitizer.sanitizeObject(req.body);
  }

  // Add security headers
  res.set({
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'X-XSS-Protection': '1; mode=block',
    'Strict-Transport-Security': 'max-age=31536000; includeSubDomains',
    'Content-Security-Policy': "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'"
  });

  next();
};

// Rate limiting middleware
export const createRateLimit = (config) => {
  return rateLimit({
    ...config,
    onLimitReached: (req, res) => {
      const ip = req.ip;
      ipReputationManager.increaseReputation(ip, 5, 'rate limit exceeded');
      logger.security('Rate limit exceeded', { ip, path: req.path });
    }
  });
};

// Slow down middleware for brute force protection
export const createSlowDown = (config = {}) => {
  return slowDown({
    windowMs: 15 * 60 * 1000, // 15 minutes
    delayAfter: 5, // allow 5 requests per window without delay
    delayMs: 500, // add 500ms of delay per request after delayAfter
    ...config,
    onLimitReached: (req, res) => {
      const ip = req.ip;
      ipReputationManager.increaseReputation(ip, 2, 'slow down triggered');
      logger.security('Slow down triggered', { ip, path: req.path });
    }
  });
};

// Helmet configuration
export const helmetConfig = helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", "data:", "https:"],
    },
  },
  hsts: {
    maxAge: 31536000,
    includeSubDomains: true,
    preload: true
  }
});

// Security monitoring middleware
export const securityMonitoring = (req, res, next) => {
  const start = Date.now();
  const originalSend = res.send;

  res.send = function(data) {
    const duration = Date.now() - start;

    // Log security events
    if (res.statusCode >= 400) {
      logger.security('Security event: Error response', {
        ip: req.ip,
        method: req.method,
        path: req.path,
        statusCode: res.statusCode,
        duration,
        userAgent: req.get('User-Agent')
      });
    }

    // Monitor for unusual patterns
    if (duration > 10000) { // Requests taking longer than 10 seconds
      logger.security('Slow request detected', {
        ip: req.ip,
        method: req.method,
        path: req.path,
        duration
      });
    }

    originalSend.call(this, data);
  };

  next();
};

// Initialize security components
const ipReputationManager = new IPReputationManager();
const ddosProtection = new DDoSProtection();
const encryptionManager = new EncryptionManager();

// Security dashboard data
export const getSecurityStats = () => {
  return {
    ipReputation: ipReputationManager.getReputationStats(),
    ddosProtection: ddosProtection.getStats(),
    timestamp: new Date()
  };
};

// Security API routes
export const securityRouter = express.Router();

securityRouter.get('/security/stats', (req, res) => {
  res.json(getSecurityStats());
});

securityRouter.post('/security/block-ip', (req, res) => {
  const { ip, reason } = req.body;
  if (!ip) return res.status(400).json({ error: 'IP address required' });

  ipReputationManager.blockIP(ip, reason || 'manual');
  res.json({ success: true, message: `IP ${ip} blocked` });
});

securityRouter.post('/security/unblock-ip', (req, res) => {
  const { ip } = req.body;
  if (!ip) return res.status(400).json({ error: 'IP address required' });

  ipReputationManager.unblockIP(ip);
  res.json({ success: true, message: `IP ${ip} unblocked` });
});

securityRouter.post('/security/whitelist-ip', (req, res) => {
  const { ip } = req.body;
  if (!ip) return res.status(400).json({ error: 'IP address required' });

  ipReputationManager.whitelistIP(ip);
  res.json({ success: true, message: `IP ${ip} whitelisted` });
});

// Export security components
module.exports = {
  ipReputationManager,
  ddosProtection,
  InputSanitizer,
  encryptionManager,
  securityConfig
};