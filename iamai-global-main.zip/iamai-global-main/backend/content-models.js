// Content Management Models for IAMAI Platform
// This file contains models for all content collections (22 missing models)

const mongoose = require('mongoose');
const { Schema } = mongoose;

// ============================================
// BLOG SYSTEM MODELS
// ============================================

const BlogPostSchema = new Schema(
  {
    title: {
      type: String,
      required: true,
      trim: true,
    },
    slug: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      // schema-level index also exists - unique already creates index
    },
    content: {
      type: String,
      required: true,
    },
    excerpt: {
      type: String,
      maxlength: 300,
    },
    author: {
      type: String,
      required: true,
    },
    authorId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
    },
    featuredImage: String,
    tags: [String],
    category: {
      type: String,
      enum: ['Technology', 'AI', 'Product Updates', 'Tutorials', 'Industry News'],
      default: 'Technology',
    },
    status: {
      type: String,
      enum: ['draft', 'published', 'archived'],
      default: 'draft',
    },
    publishedAt: Date,
    viewCount: {
      type: Number,
      default: 0,
    },
    likes: {
      type: Number,
      default: 0,
    },
    metadata: {
      readTime: Number,
      seoTitle: String,
      seoDescription: String,
      seoKeywords: [String],
    },
  },
  {
    timestamps: true,
    collection: 'blog_posts',
  }
);

// ============================================
// FAQ SYSTEM MODEL
// ============================================

const FaqSchema = new Schema(
  {
    question: {
      type: String,
      required: true,
      trim: true,
    },
    answer: {
      type: String,
      required: true,
    },
    category: {
      type: String,
      enum: ['General', 'Billing', 'Technical', 'AI Agents', 'Account', 'Security'],
      default: 'General',
    },
    order: {
      type: Number,
      default: 0,
    },
    isPublished: {
      type: Boolean,
      default: true,
    },
    helpfulCount: {
      type: Number,
      default: 0,
    },
    notHelpfulCount: {
      type: Number,
      default: 0,
    },
    tags: [String],
    lastUpdatedBy: {
      type: Schema.Types.ObjectId,
      ref: 'User',
    },
  },
  {
    timestamps: true,
    collection: 'faqs',
  }
);

// ============================================
// DOCUMENTATION MODEL
// ============================================

const DocumentationSchema = new Schema(
  {
    title: {
      type: String,
      required: true,
    },
    slug: {
      type: String,
      required: true,
      unique: true,
      // schema-level index also exists - unique already creates index
    },
    content: {
      type: String,
      required: true,
    },
    section: {
      type: String,
      enum: ['Getting Started', 'API Reference', 'Guides', 'Tutorials', 'FAQ'],
      required: true,
    },
    subsection: String,
    order: {
      type: Number,
      default: 0,
    },
    version: {
      type: String,
      default: '1.0',
    },
    isPublished: {
      type: Boolean,
      default: true,
    },
    lastReviewedAt: Date,
    reviewedBy: {
      type: Schema.Types.ObjectId,
      ref: 'User',
    },
    tags: [String],
    relatedPages: [String],
    codeExamples: [
      {
        language: String,
        code: String,
        title: String,
      },
    ],
  },
  {
    timestamps: true,
    collection: 'documentation',
  }
);

// ============================================
// TUTORIAL MODEL
// ============================================

const TutorialSchema = new Schema(
  {
    title: {
      type: String,
      required: true,
    },
    description: String,
    content: {
      type: String,
      required: true,
    },
    difficulty: {
      type: String,
      enum: ['Beginner', 'Intermediate', 'Advanced'],
      default: 'Beginner',
    },
    duration: {
      type: Number, // minutes
      required: true,
    },
    category: {
      type: String,
      enum: ['AI Agents', 'API Usage', 'Tools', 'Integration', 'Best Practices'],
      required: true,
    },
    steps: [
      {
        title: String,
        content: String,
        code: String,
        image: String,
        order: Number,
      },
    ],
    prerequisites: [String],
    tags: [String],
    videoUrl: String,
    githubRepo: String,
    isPublished: {
      type: Boolean,
      default: false,
    },
    completionCount: {
      type: Number,
      default: 0,
    },
    rating: {
      average: { type: Number, default: 0 },
      count: { type: Number, default: 0 },
    },
  },
  {
    timestamps: true,
    collection: 'tutorials',
  }
);

// ============================================
// TEMPLATE MODEL
// ============================================

const TemplateSchema = new Schema(
  {
    name: {
      type: String,
      required: true,
    },
    description: String,
    category: {
      type: String,
      enum: ['Chatbot', 'API Integration', 'Workflow', 'Analytics', 'Custom'],
      required: true,
    },
    template: {
      type: Schema.Types.Mixed,
      required: true,
    },
    variables: [
      {
        name: String,
        type: String,
        description: String,
        required: Boolean,
        defaultValue: String,
      },
    ],
    instructions: String,
    previewImage: String,
    tags: [String],
    difficulty: {
      type: String,
      enum: ['Beginner', 'Intermediate', 'Advanced'],
      default: 'Beginner',
    },
    isPublished: {
      type: Boolean,
      default: false,
    },
    downloads: {
      type: Number,
      default: 0,
    },
    rating: {
      average: { type: Number, default: 0 },
      count: { type: Number, default: 0 },
    },
    author: {
      type: Schema.Types.ObjectId,
      ref: 'User',
    },
  },
  {
    timestamps: true,
    collection: 'templates',
  }
);

// ============================================
// NEWS MODEL
// ============================================

const NewsSchema = new Schema(
  {
    title: {
      type: String,
      required: true,
    },
    content: {
      type: String,
      required: true,
    },
    summary: {
      type: String,
      maxlength: 200,
    },
    category: {
      type: String,
      enum: ['Product Updates', 'Company News', 'Industry News', 'Feature Release', 'Maintenance'],
      default: 'Company News',
    },
    priority: {
      type: String,
      enum: ['Low', 'Normal', 'High', 'Critical'],
      default: 'Normal',
    },
    isPublished: {
      type: Boolean,
      default: false,
    },
    publishedAt: Date,
    author: {
      type: Schema.Types.ObjectId,
      ref: 'User',
    },
    tags: [String],
    featuredImage: String,
    viewCount: {
      type: Number,
      default: 0,
    },
  },
  {
    timestamps: true,
    collection: 'news',
  }
);

// ============================================
// ABOUT SECTION MODEL
// ============================================

const AboutSectionSchema = new Schema(
  {
    section: {
      type: String,
      enum: ['Mission', 'Vision', 'Values', 'History', 'Team', 'Culture'],
      required: true,
    },
    title: String,
    content: {
      type: String,
      required: true,
    },
    order: {
      type: Number,
      default: 0,
    },
    isPublished: {
      type: Boolean,
      default: true,
    },
    lastUpdatedBy: {
      type: Schema.Types.ObjectId,
      ref: 'User',
    },
    images: [String],
    metadata: {
      type: Schema.Types.Mixed,
      default: {},
    },
  },
  {
    timestamps: true,
    collection: 'about_sections',
  }
);

// ============================================
// TEAM MEMBER MODEL
// ============================================

const TeamMemberSchema = new Schema(
  {
    name: {
      type: String,
      required: true,
    },
    position: {
      type: String,
      required: true,
    },
    bio: String,
    photo: String,
    email: String,
    linkedin: String,
    twitter: String,
    github: String,
    department: {
      type: String,
      enum: ['Engineering', 'Product', 'Marketing', 'Sales', 'Operations', 'Leadership'],
      default: 'Engineering',
    },
    joinDate: Date,
    isActive: {
      type: Boolean,
      default: true,
    },
    order: {
      type: Number,
      default: 0,
    },
    skills: [String],
    achievements: [String],
  },
  {
    timestamps: true,
    collection: 'team_members',
  }
);

// ============================================
// JOB POSTING MODEL
// ============================================

const JobPostingSchema = new Schema(
  {
    title: {
      type: String,
      required: true,
    },
    department: {
      type: String,
      required: true,
    },
    location: {
      type: String,
      required: true,
    },
    type: {
      type: String,
      enum: ['Full-time', 'Part-time', 'Contract', 'Internship'],
      default: 'Full-time',
    },
    remote: {
      type: String,
      enum: ['No', 'Yes', 'Hybrid'],
      default: 'No',
    },
    description: {
      type: String,
      required: true,
    },
    requirements: [String],
    responsibilities: [String],
    benefits: [String],
    salaryRange: {
      min: Number,
      max: Number,
      currency: { type: String, default: 'USD' },
    },
    isActive: {
      type: Boolean,
      default: true,
    },
    applicationDeadline: Date,
    postedBy: {
      type: Schema.Types.ObjectId,
      ref: 'User',
    },
    applicationCount: {
      type: Number,
      default: 0,
    },
  },
  {
    timestamps: true,
    collection: 'job_postings',
  }
);

// ============================================
// PARTNER MODEL
// ============================================

const PartnerSchema = new Schema(
  {
    name: {
      type: String,
      required: true,
    },
    logo: String,
    website: String,
    description: String,
    type: {
      type: String,
      enum: ['Technology', 'Integration', 'Reseller', 'Strategic', 'Investor'],
      default: 'Technology',
    },
    status: {
      type: String,
      enum: ['Active', 'Pending', 'Inactive'],
      default: 'Active',
    },
    contactPerson: {
      name: String,
      email: String,
      phone: String,
    },
    partnershipDate: Date,
    isPublic: {
      type: Boolean,
      default: false,
    },
    order: {
      type: Number,
      default: 0,
    },
  },
  {
    timestamps: true,
    collection: 'partners',
  }
);

// ============================================
// LEGAL DOCUMENT MODEL
// ============================================

const LegalDocumentSchema = new Schema(
  {
    title: {
      type: String,
      required: true,
    },
    type: {
      type: String,
      enum: [
        'Terms of Service',
        'Privacy Policy',
        'Cookie Policy',
        'Data Processing Agreement',
        'SLA',
      ],
      required: true,
    },
    content: {
      type: String,
      required: true,
    },
    version: {
      type: String,
      required: true,
    },
    effectiveDate: {
      type: Date,
      required: true,
    },
    previousVersion: {
      type: Schema.Types.ObjectId,
      ref: 'LegalDocument',
    },
    isActive: {
      type: Boolean,
      default: true,
    },
    approvedBy: {
      type: Schema.Types.ObjectId,
      ref: 'User',
    },
    reviewDate: Date,
    changes: [String],
  },
  {
    timestamps: true,
    collection: 'legal_documents',
  }
);

// ============================================
// REPORT MODEL
// ============================================

const ReportSchema = new Schema(
  {
    title: {
      type: String,
      required: true,
    },
    type: {
      type: String,
      enum: ['Usage Analytics', 'Financial', 'Performance', 'User Activity', 'Security', 'Custom'],
      required: true,
    },
    period: {
      start: Date,
      end: Date,
    },
    data: {
      type: Schema.Types.Mixed,
      required: true,
    },
    summary: String,
    generatedBy: {
      type: Schema.Types.ObjectId,
      ref: 'User',
    },
    format: {
      type: String,
      enum: ['JSON', 'CSV', 'PDF', 'Excel'],
      default: 'JSON',
    },
    isPublic: {
      type: Boolean,
      default: false,
    },
    downloadCount: {
      type: Number,
      default: 0,
    },
    fileUrl: String,
    metadata: {
      type: Schema.Types.Mixed,
      default: {},
    },
  },
  {
    timestamps: true,
    collection: 'reports',
  }
);

// ============================================
// DEVELOPER RESOURCE MODEL
// ============================================

const DeveloperResourceSchema = new Schema(
  {
    title: {
      type: String,
      required: true,
    },
    type: {
      type: String,
      enum: ['SDK', 'API Documentation', 'Code Sample', 'Library', 'Tool', 'Guide'],
      required: true,
    },
    description: String,
    content: String,
    downloadUrl: String,
    githubUrl: String,
    language: String,
    version: String,
    category: {
      type: String,
      enum: ['JavaScript', 'Python', 'REST API', 'GraphQL', 'Mobile', 'Web'],
      default: 'REST API',
    },
    isPublished: {
      type: Boolean,
      default: false,
    },
    downloadCount: {
      type: Number,
      default: 0,
    },
    rating: {
      average: { type: Number, default: 0 },
      count: { type: Number, default: 0 },
    },
    tags: [String],
    maintainer: {
      type: Schema.Types.ObjectId,
      ref: 'User',
    },
  },
  {
    timestamps: true,
    collection: 'developer_resources',
  }
);

// ============================================
// EDUCATION CONTENT MODEL
// ============================================

const EducationContentSchema = new Schema(
  {
    title: {
      type: String,
      required: true,
    },
    type: {
      type: String,
      enum: ['Course', 'Lesson', 'Workshop', 'Webinar', 'Certification'],
      required: true,
    },
    description: String,
    content: String,
    level: {
      type: String,
      enum: ['Beginner', 'Intermediate', 'Advanced'],
      default: 'Beginner',
    },
    duration: Number, // minutes
    category: {
      type: String,
      enum: ['AI Fundamentals', 'API Development', 'Best Practices', 'Case Studies'],
      default: 'AI Fundamentals',
    },
    instructor: {
      name: String,
      bio: String,
      avatar: String,
    },
    modules: [
      {
        title: String,
        content: String,
        duration: Number,
        order: Number,
      },
    ],
    isPublished: {
      type: Boolean,
      default: false,
    },
    enrollmentCount: {
      type: Number,
      default: 0,
    },
    completionRate: {
      type: Number,
      default: 0,
    },
  },
  {
    timestamps: true,
    collection: 'education_content',
  }
);

// ============================================
// SYSTEM STATUS MODEL
// ============================================

const SystemStatusSchema = new Schema(
  {
    service: {
      type: String,
      required: true,
    },
    status: {
      type: String,
      enum: ['Operational', 'Degraded Performance', 'Partial Outage', 'Major Outage'],
      default: 'Operational',
    },
    description: String,
    incidentId: String,
    startTime: Date,
    endTime: Date,
    affectedComponents: [String],
    updates: [
      {
        timestamp: { type: Date, default: Date.now },
        message: String,
        status: String,
      },
    ],
    isResolved: {
      type: Boolean,
      default: false,
    },
    reportedBy: {
      type: Schema.Types.ObjectId,
      ref: 'User',
    },
  },
  {
    timestamps: true,
    collection: 'system_status',
  }
);

// ============================================
// CHAT SESSION MODEL (Extended)
// ============================================

const ChatSessionSchema = new Schema(
  {
    sessionId: {
      type: String,
      required: true,
      unique: true,
    },
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
    },
    agentId: {
      type: String,
      required: true,
    },
    // Session display and state info
    title: String,
    sessionInfo: {
      agentName: String,
      agentDisplayName: String,
      title: String,
      description: String,
      isActive: { type: Boolean, default: true },
    },
    isActive: {
      type: Boolean,
      default: true,
    },
    metadata: {
      userAgent: String,
      ipAddress: String,
      source: String,
      referrer: String,
    },
    // Message storage (kept inline to match existing route writes)
    messages: [
      {
        messageId: { type: String, required: true },
        role: { type: String, enum: ['user', 'assistant', 'system'], default: 'user' },
        content: { type: String, required: true },
        timestamp: { type: Date, default: Date.now },
        metadata: Schema.Types.Mixed,
        attachments: [
          {
            url: String,
            type: String,
            filename: String,
            mimeType: String,
            size: Number,
          },
        ],
        reactions: [
          {
            reactionType: String,
            userId: { type: Schema.Types.ObjectId, ref: 'User' },
            timestamp: { type: Date, default: Date.now },
          },
        ],
        status: {
          delivered: { type: Boolean, default: true },
          read: { type: Boolean, default: false },
        },
      },
    ],
    // Session statistics used by routes
    sessionStats: {
      totalMessages: { type: Number, default: 0 },
      userMessages: { type: Number, default: 0 },
      assistantMessages: { type: Number, default: 0 },
      lastMessageAt: Date,
    },
    // Legacy counters kept for backwards compatibility with existing data
    messageCount: {
      type: Number,
      default: 0,
    },
    lastMessageAt: Date,
    totalCreditsUsed: {
      type: Number,
      default: 0,
    },
    rating: {
      score: Number,
      feedback: String,
    },
  },
  {
    timestamps: true,
    collection: 'chat_sessions',
  }
);

// ============================================
// MESSAGE REACTION MODEL
// ============================================

const MessageReactionSchema = new Schema(
  {
    messageId: {
      type: String,
      required: true,
    },
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    reactionType: {
      type: String,
      required: true,
      enum: ['like', 'dislike', 'love', 'laugh', 'angry', 'sad'],
    },
    sessionId: String,
    createdAt: {
      type: Date,
      default: Date.now,
    },
  },
  {
    collection: 'message_reactions',
  }
);

MessageReactionSchema.index({ messageId: 1, userId: 1 }, { unique: true });
MessageReactionSchema.index({ userId: 1, createdAt: -1 });

// ============================================
// CONVERSATION ANALYTICS MODEL
// ============================================

const ConversationAnalyticsSchema = new Schema(
  {
    sessionId: {
      type: String,
      required: true,
      unique: true,
    },
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    agentId: String,
    analytics: {
      totalMessages: { type: Number, default: 0 },
      userMessages: { type: Number, default: 0 },
      assistantMessages: { type: Number, default: 0 },
      averageResponseTime: Number,
      totalTokensUsed: Number,
      conversationDuration: Number,
      userSatisfaction: Number,
      topics: [String],
      sentiment: {
        overall: String,
        user: String,
        assistant: String,
      },
    },
    metadata: Schema.Types.Mixed,
  },
  {
    timestamps: true,
    collection: 'conversation_analytics',
  }
);

ConversationAnalyticsSchema.index({ sessionId: 1 });
ConversationAnalyticsSchema.index({ userId: 1, createdAt: -1 });

// ============================================
// REWARD MODEL
// ============================================

const RewardSchema = new Schema(
  {
    name: {
      type: String,
      required: true,
    },
    description: String,
    type: {
      type: String,
      enum: ['Credits', 'Badge', 'Feature Access', 'Discount', 'Physical'],
      required: true,
    },
    value: {
      amount: Number,
      unit: String, // credits, percentage, days
    },
    criteria: {
      type: String,
      required: true,
    },
    isActive: {
      type: Boolean,
      default: true,
    },
    icon: String,
    color: String,
    rarity: {
      type: String,
      enum: ['Common', 'Uncommon', 'Rare', 'Epic', 'Legendary'],
      default: 'Common',
    },
    maxClaims: Number,
    currentClaims: {
      type: Number,
      default: 0,
    },
  },
  {
    timestamps: true,
    collection: 'rewards',
  }
);

// ============================================
// USER REWARD MODEL
// ============================================

const UserRewardSchema = new Schema(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    rewardId: {
      type: Schema.Types.ObjectId,
      ref: 'Reward',
      required: true,
    },
    earnedAt: {
      type: Date,
      default: Date.now,
    },
    claimedAt: Date,
    isClaimed: {
      type: Boolean,
      default: false,
    },
    metadata: {
      triggerAction: String,
      value: Schema.Types.Mixed,
    },
  },
  {
    timestamps: true,
    collection: 'user_rewards',
  }
);

// ============================================
// CHAT MESSAGE MODEL (Detailed)
// ============================================

const ChatMessageSchema = new Schema(
  {
    sessionId: {
      type: String,
      required: true,
    },
    chatId: {
      type: Schema.Types.ObjectId,
      ref: 'Chat',
    },
    role: {
      type: String,
      enum: ['user', 'assistant', 'system'],
      required: true,
    },
    content: {
      type: String,
      required: true,
    },
    metadata: {
      model: String,
      provider: String,
      tokens: {
        prompt: Number,
        completion: Number,
        total: Number,
      },
      credits: Number,
      processingTime: Number,
      attachments: [
        {
          type: String,
          url: String,
          filename: String,
        },
      ],
    },
    isEdited: {
      type: Boolean,
      default: false,
    },
    editHistory: [
      {
        content: String,
        editedAt: Date,
      },
    ],
    reactions: [
      {
        userId: { type: Schema.Types.ObjectId, ref: 'User' },
        type: String, // like, dislike, helpful
        timestamp: { type: Date, default: Date.now },
      },
    ],
  },
  {
    timestamps: true,
    collection: 'chat_messages',
  }
);

// ============================================
// TICKET RESPONSE MODEL
// ============================================

const TicketResponseSchema = new Schema(
  {
    ticketId: {
      type: Schema.Types.ObjectId,
      ref: 'SupportTicket',
      required: true,
    },
    authorId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
    },
    authorName: String,
    content: {
      type: String,
      required: true,
    },
    isInternal: {
      type: Boolean,
      default: false,
    },
    type: {
      type: String,
      enum: ['Reply', 'Note', 'Status Update', 'Assignment'],
      default: 'Reply',
    },
    attachments: [
      {
        filename: String,
        originalName: String,
        mimeType: String,
        size: Number,
        url: String,
      },
    ],
    metadata: {
      source: String,
      ipAddress: String,
      userAgent: String,
    },
  },
  {
    timestamps: true,
    collection: 'ticket_responses',
  }
);

// ============================================
// TICKET ATTACHMENT MODEL
// ============================================

const TicketAttachmentSchema = new Schema(
  {
    ticketId: {
      type: Schema.Types.ObjectId,
      ref: 'SupportTicket',
      required: true,
    },
    responseId: {
      type: Schema.Types.ObjectId,
      ref: 'TicketResponse',
    },
    filename: {
      type: String,
      required: true,
    },
    originalName: {
      type: String,
      required: true,
    },
    mimeType: String,
    size: Number,
    url: String,
    s3Key: String,
    uploadedBy: {
      type: Schema.Types.ObjectId,
      ref: 'User',
    },
    isPublic: {
      type: Boolean,
      default: false,
    },
    scanResults: {
      isClean: Boolean,
      scanDate: Date,
      threats: [String],
    },
  },
  {
    timestamps: true,
    collection: 'ticket_attachments',
  }
);

// ============================================
// CREATE INDEXES
// ============================================

// Blog Post Indexes
// BlogPostSchema.index({ slug: 1 }); // Removed: unique: true already creates index
BlogPostSchema.index({ status: 1, publishedAt: -1 });
BlogPostSchema.index({ category: 1, publishedAt: -1 });
BlogPostSchema.index({ tags: 1 });
BlogPostSchema.index({ author: 1 });

// FAQ Indexes
FaqSchema.index({ category: 1, order: 1 });
FaqSchema.index({ isPublished: 1 });

// Documentation Indexes
// DocumentationSchema.index({ slug: 1 }); // Removed: unique: true already creates index
DocumentationSchema.index({ section: 1, order: 1 });
DocumentationSchema.index({ isPublished: 1 });

// Tutorial Indexes
TutorialSchema.index({ category: 1, difficulty: 1 });
TutorialSchema.index({ isPublished: 1 });
TutorialSchema.index({ tags: 1 });

// Template Indexes
TemplateSchema.index({ category: 1, difficulty: 1 });
TemplateSchema.index({ isPublished: 1 });
TemplateSchema.index({ tags: 1 });

// News Indexes
NewsSchema.index({ isPublished: 1, publishedAt: -1 });
NewsSchema.index({ category: 1, publishedAt: -1 });
NewsSchema.index({ priority: 1 });

// Chat Session Indexes
ChatSessionSchema.index({ sessionId: 1 });
ChatSessionSchema.index({ userId: 1, createdAt: -1 });
ChatSessionSchema.index({ agentId: 1 });

// Chat Message Indexes
ChatMessageSchema.index({ sessionId: 1, createdAt: 1 });
ChatMessageSchema.index({ chatId: 1, createdAt: 1 });

// Reward Indexes
RewardSchema.index({ isActive: 1 });
RewardSchema.index({ type: 1 });

// User Reward Indexes
UserRewardSchema.index({ userId: 1, earnedAt: -1 });
UserRewardSchema.index({ rewardId: 1 });
UserRewardSchema.index({ isClaimed: 1 });

// Ticket Response Indexes
TicketResponseSchema.index({ ticketId: 1, createdAt: 1 });

// Ticket Attachment Indexes
TicketAttachmentSchema.index({ ticketId: 1 });
TicketAttachmentSchema.index({ responseId: 1 });

// ============================================
// EXPORT MODELS
// ============================================

// Safe model compilation to prevent OverwriteModelError
const BlogPost = mongoose.models.BlogPost || mongoose.model('BlogPost', BlogPostSchema);
const Faq = mongoose.models.Faq || mongoose.model('Faq', FaqSchema);
const Documentation =
  mongoose.models.Documentation || mongoose.model('Documentation', DocumentationSchema);
const Tutorial = mongoose.models.Tutorial || mongoose.model('Tutorial', TutorialSchema);
const Template = mongoose.models.Template || mongoose.model('Template', TemplateSchema);
const News = mongoose.models.News || mongoose.model('News', NewsSchema);
const AboutSection =
  mongoose.models.AboutSection || mongoose.model('AboutSection', AboutSectionSchema);
const TeamMember = mongoose.models.TeamMember || mongoose.model('TeamMember', TeamMemberSchema);
const JobPosting = mongoose.models.JobPosting || mongoose.model('JobPosting', JobPostingSchema);
const Partner = mongoose.models.Partner || mongoose.model('Partner', PartnerSchema);
const LegalDocument =
  mongoose.models.LegalDocument || mongoose.model('LegalDocument', LegalDocumentSchema);
const Report = mongoose.models.Report || mongoose.model('Report', ReportSchema);
const DeveloperResource =
  mongoose.models.DeveloperResource || mongoose.model('DeveloperResource', DeveloperResourceSchema);
const EducationContent =
  mongoose.models.EducationContent || mongoose.model('EducationContent', EducationContentSchema);
const SystemStatus =
  mongoose.models.SystemStatus || mongoose.model('SystemStatus', SystemStatusSchema);
const ChatSession = mongoose.models.ChatSession || mongoose.model('ChatSession', ChatSessionSchema);
const MessageReaction =
  mongoose.models.MessageReaction || mongoose.model('MessageReaction', MessageReactionSchema);
const ConversationAnalytics =
  mongoose.models.ConversationAnalytics ||
  mongoose.model('ConversationAnalytics', ConversationAnalyticsSchema);
const Reward = mongoose.models.Reward || mongoose.model('Reward', RewardSchema);
const UserReward = mongoose.models.UserReward || mongoose.model('UserReward', UserRewardSchema);
const ChatMessage = mongoose.models.ChatMessage || mongoose.model('ChatMessage', ChatMessageSchema);
const TicketResponse =
  mongoose.models.TicketResponse || mongoose.model('TicketResponse', TicketResponseSchema);
const TicketAttachment =
  mongoose.models.TicketAttachment || mongoose.model('TicketAttachment', TicketAttachmentSchema);

// CommonJS exports - all content models
module.exports = {
  // Blog Models
  BlogPost,
  // News Models
  News,
  // About Page Models
  AboutSection,
  TeamMember,
  // Career Models
  JobPosting,
  // Partnership Models
  Partner,
  // Legal Document Models
  LegalDocument,
  // Report Models
  Report,
  // Developer Resource Models
  DeveloperResource,
  // Education Content Models
  EducationContent,
  // System Status Models
  SystemStatus,
  // Support Models
  ChatSession,
  MessageReaction,
  ConversationAnalytics,
  ChatMessage,
  TicketResponse,
  TicketAttachment,
  // Reward Models
  Reward,
  UserReward,
  // Template Models
  Template,
  // Documentation Models
  Documentation,
  Tutorial,
  //FAQ Models
  Faq,
};
