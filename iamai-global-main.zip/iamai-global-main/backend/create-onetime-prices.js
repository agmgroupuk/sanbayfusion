#!/usr/bin/env node
/**
 * Create One-Time Stripe Prices
 * Replaces recurring subscriptions with one-time payments
 */

require('dotenv').config();
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

const agents = [
  'AIGirlfriend', 'AgentX', 'AutoChat', 'CVSmash', 'ChatRevive',
  'ComedyChad', 'CoolKyle', 'EmoAI', 'FlirtyFiona', 'GamerGary',
  'LazyLarry', 'NerdyNeil', 'PDFMind', 'SassySarah', 'TokBoost',
  'YouGen', 'ZenMasterZara'
];

const plans = {
  Daily: { amount: 100, duration: 1 },    // $1.00 for 1 day (example pricing)
  Weekly: { amount: 500, duration: 7 },   // $5.00 for 7 days
  Monthly: { amount: 1500, duration: 30 } // $15.00 for 30 days
};

async function createOneTimePrices() {
  console.log('🔧 Creating One-Time Payment Prices\n');
  
  const newPrices = {};
  
  for (const agent of agents) {
    for (const [planType, config] of Object.entries(plans)) {
      const productName = `${agent} ${planType} Access`;
      
      try {
        // Find existing product
        const products = await stripe.products.search({
          query: `name:"${productName}" AND active:"true"`,
          limit: 1
        });
        
        if (products.data.length === 0) {
          console.log(`❌ Product not found: ${productName}`);
          continue;
        }
        
        const product = products.data[0];
        
        // Create ONE-TIME price
        const price = await stripe.prices.create({
          product: product.id,
          unit_amount: config.amount,
          currency: 'usd',
          billing_scheme: 'per_unit',
          // NO recurring object - this makes it one-time!
        });
        
        const envVarName = `STRIPE_PRICE_${agent.toUpperCase()}_${planType.toUpperCase()}`;
        newPrices[envVarName] = price.id;
        
        console.log(`✅ ${productName}`);
        console.log(`   Product: ${product.id}`);
        console.log(`   Price: ${price.id} ($${config.amount/100})`);
        console.log(`   Duration: ${config.duration} days\n`);
        
        // Small delay to avoid rate limits
        await new Promise(resolve => setTimeout(resolve, 200));
        
      } catch (error) {
        console.log(`❌ Error for ${productName}: ${error.message}\n`);
      }
    }
  }
  
  console.log('\n📋 New Environment Variables:\n');
  Object.entries(newPrices).forEach(([key, value]) => {
    console.log(`${key}=${value}`);
  });
  
  console.log(`\n✅ Created ${Object.keys(newPrices).length} one-time prices`);
}

createOneTimePrices().catch(console.error);
