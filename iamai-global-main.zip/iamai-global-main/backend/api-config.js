/**
 * 🌐 Standardized API Configuration
 * Centralized API URL management and routing configuration
 */

const API_BASE_PATH = '/api';

// Standardized API endpoints with consistent naming
const API_ENDPOINTS = {
  // Authentication endpoints
  AUTH: {
    SIGNIN: `${API_BASE_PATH}/auth/signin`,
    SIGNUP: `${API_BASE_PATH}/auth/signup`,
    SIGNOUT: `${API_BASE_PATH}/auth/signout`,
    REFRESH: `${API_BASE_PATH}/auth/refresh`,
    VERIFY_EMAIL: `${API_BASE_PATH}/auth/verify-email`,
    FORGOT_PASSWORD: `${API_BASE_PATH}/auth/forgot-password`,
    RESET_PASSWORD: `${API_BASE_PATH}/auth/reset-password`,
    VERIFY_TOKEN: `${API_BASE_PATH}/auth/verify-token`,
  },

  // User management
  USERS: {
    PROFILE: `${API_BASE_PATH}/users/profile`,
    SETTINGS: `${API_BASE_PATH}/users/settings`,
    PREFERENCES: `${API_BASE_PATH}/users/preferences`,
    SECURITY: `${API_BASE_PATH}/users/security`,
    ACTIVITY: `${API_BASE_PATH}/users/activity`,
    USAGE: `${API_BASE_PATH}/users/usage`,
    DASHBOARD: `${API_BASE_PATH}/users/dashboard`,
  },

  // Chat and messaging
  CHAT: {
    SESSIONS: `${API_BASE_PATH}/chat/sessions`,
    MESSAGES: `${API_BASE_PATH}/chat/messages`,
    CREATE_SESSION: `${API_BASE_PATH}/chat/create`,
    DELETE_SESSION: `${API_BASE_PATH}/chat/delete`,
    STREAM: `${API_BASE_PATH}/chat/stream`,
    HISTORY: `${API_BASE_PATH}/chat/history`,
  },

  // AI Agents
  AGENTS: {
    LIST: `${API_BASE_PATH}/agents`,
    DETAIL: `${API_BASE_PATH}/agents/detail`,
    INDIVIDUAL: `${API_BASE_PATH}/agents/individual`,
    COLLECTIONS: `${API_BASE_PATH}/agents/collections`,
    CONFIGURATIONS: `${API_BASE_PATH}/agents/configurations`,
  },

  // Subscriptions and billing
  SUBSCRIPTIONS: {
    PLANS: `${API_BASE_PATH}/subscriptions/plans`,
    CURRENT: `${API_BASE_PATH}/subscriptions/current`,
    CREATE: `${API_BASE_PATH}/subscriptions/create`,
    UPDATE: `${API_BASE_PATH}/subscriptions/update`,
    CANCEL: `${API_BASE_PATH}/subscriptions/cancel`,
    BILLING: `${API_BASE_PATH}/subscriptions/billing`,
    HISTORY: `${API_BASE_PATH}/subscriptions/history`,
  },

  // Payments and webhooks
  PAYMENTS: {
    WEBHOOK: `${API_BASE_PATH}/payments/webhook`,
    CREATE_SESSION: `${API_BASE_PATH}/payments/create-session`,
    CONFIRM_PAYMENT: `${API_BASE_PATH}/payments/confirm`,
    METHODS: `${API_BASE_PATH}/payments/methods`,
  },

  // Analytics and reporting
  ANALYTICS: {
    TRACK: `${API_BASE_PATH}/analytics/track`,
    DASHBOARD: `${API_BASE_PATH}/analytics/dashboard`,
    USAGE: `${API_BASE_PATH}/analytics/usage`,
    REPORTS: `${API_BASE_PATH}/analytics/reports`,
    METRICS: `${API_BASE_PATH}/analytics/metrics`,
  },

  // File management
  FILES: {
    UPLOAD: `${API_BASE_PATH}/files/upload`,
    DOWNLOAD: `${API_BASE_PATH}/files/download`,
    DELETE: `${API_BASE_PATH}/files/delete`,
    LIST: `${API_BASE_PATH}/files/list`,
    METADATA: `${API_BASE_PATH}/files/metadata`,
  },

  // API Keys and integrations
  API_KEYS: {
    LIST: `${API_BASE_PATH}/api-keys`,
    CREATE: `${API_BASE_PATH}/api-keys/create`,
    UPDATE: `${API_BASE_PATH}/api-keys/update`,
    DELETE: `${API_BASE_PATH}/api-keys/delete`,
    REGENERATE: `${API_BASE_PATH}/api-keys/regenerate`,
  },

  // Administrative endpoints
  ADMIN: {
    USERS: `${API_BASE_PATH}/admin/users`,
    ANALYTICS: `${API_BASE_PATH}/admin/analytics`,
    SETTINGS: `${API_BASE_PATH}/admin/settings`,
    LOGS: `${API_BASE_PATH}/admin/logs`,
    BACKUP: `${API_BASE_PATH}/admin/backup`,
  },

  // Support and communication
  SUPPORT: {
    TICKETS: `${API_BASE_PATH}/support/tickets`,
    CONTACT: `${API_BASE_PATH}/support/contact`,
    FAQ: `${API_BASE_PATH}/support/faq`,
    LIVE_CHAT: `${API_BASE_PATH}/support/live-chat`,
  },

  // Tools and utilities
  TOOLS: {
    DNS_LOOKUP: `${API_BASE_PATH}/tools/dns-lookup`,
    WHOIS: `${API_BASE_PATH}/tools/whois`,
    PING: `${API_BASE_PATH}/tools/ping`,
    VALIDATOR: `${API_BASE_PATH}/tools/validator`,
  },

  // Health and monitoring
  HEALTH: {
    STATUS: `${API_BASE_PATH}/health/status`,
    METRICS: `${API_BASE_PATH}/health/metrics`,
    DATABASE: `${API_BASE_PATH}/health/database`,
    CACHE: `${API_BASE_PATH}/health/cache`,
  },
};

// API versioning helper
const getVersionedEndpoint = (endpoint, version = 'v1') => {
  return endpoint.replace('/api/', `/api/${version}/`);
};

// Helper to get all endpoints for a category
const getCategoryEndpoints = category => {
  return API_ENDPOINTS[category] || {};
};

// Helper to validate endpoint exists
const isValidEndpoint = endpoint => {
  const allEndpoints = Object.values(API_ENDPOINTS).flatMap(category =>
    typeof category === 'object' ? Object.values(category) : [category]
  );
  return allEndpoints.includes(endpoint);
};

export {
  API_ENDPOINTS,
  API_BASE_PATH,
  getVersionedEndpoint,
  getCategoryEndpoints,
  isValidEndpoint,
};
