#!/bin/bash
#
# ⚠️  IMPORTANT DEPLOYMENT PATHS (EC2 Production):
#   BACKEND:  /home/ubuntu/iamai-global/backend/  (where PM2 runs from, has node_modules)
#   FRONTEND: /var/www/iamai-global/              (static files only, served by nginx)
#   NEVER deploy backend to /var/www/iamai-global/backend/ - it won't work!
#

# Kill any existing Node processes on port 3001
echo "🔍 Checking for existing processes on port 3001..."
lsof -ti:3001 | xargs kill -9 2>/dev/null || echo "No existing process found"

# Wait a moment
sleep 1

# Start the production server
echo "🚀 Starting production server..."
cd /Users/onelastai/Downloads/iamai-global/backend
NODE_ENV=production node production-server.js
