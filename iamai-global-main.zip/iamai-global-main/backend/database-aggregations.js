// Database Aggregations for User Analytics
// Provides aggregation pipelines for user data analysis

const mongoose = require('mongoose');

// User Analytics Aggregations
class UserAnalytics {

  // Get user registration trends by date
  static getUserRegistrationTrends() {
    return [
      {
        $group: {
          _id: {
            $dateToString: {
              format: "%Y-%m-%d",
              date: "$createdAt"
            }
          },
          count: { $sum: 1 }
        }
      },
      {
        $sort: { "_id": 1 }
      },
      {
        $project: {
          date: "$_id",
          registrations: "$count",
          _id: 0
        }
      }
    ];
  }

  // Get user distribution by tier
  static getUserTierDistribution() {
    return [
      {
        $group: {
          _id: "$tier",
          count: { $sum: 1 },
          totalCredits: { $sum: "$credits" }
        }
      },
      {
        $sort: { count: -1 }
      },
      {
        $project: {
          tier: "$_id",
          userCount: "$count",
          averageCredits: { $divide: ["$totalCredits", "$count"] },
          _id: 0
        }
      }
    ];
  }

  // Get active users by preferences
  static getUsersByPreferences() {
    return [
      {
        $group: {
          _id: {
            language: "$preferences.language",
            theme: "$preferences.theme"
          },
          count: { $sum: 1 }
        }
      },
      {
        $sort: { count: -1 }
      },
      {
        $project: {
          preferences: "$_id",
          userCount: "$count",
          _id: 0
        }
      }
    ];
  }

  // Get user engagement metrics
  static getUserEngagementMetrics() {
    return [
      {
        $match: { isActive: true }
      },
      {
        $group: {
          _id: null,
          totalUsers: { $sum: 1 },
          totalCredits: { $sum: "$credits" },
          averageCredits: { $avg: "$credits" },
          usersWithPhone: {
            $sum: { $cond: [{ $ne: ["$phone", null] }, 1, 0] }
          },
          usersWithBio: {
            $sum: { $cond: [{ $ne: ["$bio", null] }, 1, 0] }
          }
        }
      },
      {
        $project: {
          totalActiveUsers: "$totalUsers",
          totalCreditsInSystem: "$totalCredits",
          averageCreditsPerUser: { $round: ["$averageCredits", 2] },
          phoneCompletionRate: {
            $multiply: [
              { $divide: ["$usersWithPhone", "$totalUsers"] },
              100
            ]
          },
          bioCompletionRate: {
            $multiply: [
              { $divide: ["$usersWithBio", "$totalUsers"] },
              100
            ]
          },
          _id: 0
        }
      }
    ];
  }

  // Get subscription analytics
  static getSubscriptionAnalytics() {
    return [
      {
        $match: {
          subscriptionStatus: { $ne: "NONE" }
        }
      },
      {
        $group: {
          _id: {
            status: "$subscriptionStatus",
            tier: "$tier"
          },
          count: { $sum: 1 },
          totalCredits: { $sum: "$credits" }
        }
      },
      {
        $sort: { count: -1 }
      },
      {
        $project: {
          subscriptionStatus: "$_id.status",
          tier: "$_id.tier",
          userCount: "$count",
          averageCredits: { $divide: ["$totalCredits", "$count"] },
          _id: 0
        }
      }
    ];
  }

  // Get user activity summary
  static getUserActivitySummary() {
    return [
      {
        $facet: {
          totalUsers: [
            { $count: "count" }
          ],
          activeUsers: [
            { $match: { isActive: true } },
            { $count: "count" }
          ],
          usersByTier: [
            {
              $group: {
                _id: "$tier",
                count: { $sum: 1 }
              }
            },
            { $sort: { count: -1 } }
          ],
          recentRegistrations: [
            {
              $match: {
                createdAt: {
                  $gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) // Last 30 days
                }
              }
            },
            { $count: "count" }
          ]
        }
      }
    ];
  }
}

// Chat Analytics Aggregations
class ChatAnalytics {

  // Get chat statistics
  static getChatStatistics() {
    return [
      {
        $group: {
          _id: null,
          totalChats: { $sum: 1 },
          activeChats: {
            $sum: { $cond: [{ $eq: ["$isActive", true] }, 1, 0] }
          },
          anonymousChats: {
            $sum: { $cond: [{ $eq: ["$isAnonymous", true] }, 1, 0] }
          },
          totalMessages: { $sum: { $size: "$messages" } }
        }
      },
      {
        $project: {
          totalChats: "$totalChats",
          activeChats: "$activeChats",
          anonymousChats: "$anonymousChats",
          totalMessages: "$totalMessages",
          averageMessagesPerChat: {
            $cond: {
              if: { $eq: ["$totalChats", 0] },
              then: 0,
              else: { $divide: ["$totalMessages", "$totalChats"] }
            }
          },
          _id: 0
        }
      }
    ];
  }

  // Get chats by agent
  static getChatsByAgent() {
    return [
      {
        $group: {
          _id: "$agentId",
          chatCount: { $sum: 1 },
          messageCount: { $sum: { $size: "$messages" } },
          activeChats: {
            $sum: { $cond: [{ $eq: ["$isActive", true] }, 1, 0] }
          }
        }
      },
      {
        $sort: { chatCount: -1 }
      },
      {
        $project: {
          agentId: "$_id",
          chatCount: "$chatCount",
          messageCount: "$messageCount",
          activeChats: "$activeChats",
          averageMessagesPerChat: {
            $cond: {
              if: { $eq: ["$chatCount", 0] },
              then: 0,
              else: { $divide: ["$messageCount", "$chatCount"] }
            }
          },
          _id: 0
        }
      }
    ];
  }
}

module.exports = {
  UserAnalytics,
  ChatAnalytics
};