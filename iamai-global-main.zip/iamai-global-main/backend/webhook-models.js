// Webhook Management and API Integration Models
// Complete webhook tracking, API callbacks, and third-party integrations

const mongoose = require('mongoose');

// ============================================
// 1. WEBHOOK LOG MODEL
// ============================================

const WebhookLogSchema = new mongoose.Schema({
  // Webhook Identification
  webhookId: {
    type: String,
    required: true,
    unique: true,
    default: function() {
      return `wh_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    }
  },
  
  // Event Information
  event: {
    type: {
      type: String,
      required: true,
      enum: [
        // Stripe Events
        'payment_intent.succeeded',
        'payment_intent.failed',
        'invoice.payment_succeeded',
        'invoice.payment_failed',
        'customer.subscription.created',
        'customer.subscription.updated',
        'customer.subscription.deleted',
        'charge.succeeded',
        'charge.failed',
        'charge.dispute.created',
        
        // PayPal Events
        'payment.capture.completed',
        'payment.capture.denied',
        'billing.subscription.activated',
        'billing.subscription.cancelled',
        
        // Custom Events
        'user.created',
        'user.updated',
        'user.deleted',
        'subscription.upgraded',
        'subscription.downgraded',
        'agent.assigned',
        'ticket.created',
        'ticket.resolved',
        'system.maintenance',
        'security.alert',
        
        // Generic
        'other'
      ]
    },
    
    name: {
      type: String,
      required: true
    },
    
    version: {
      type: String,
      default: '1.0'
    },
    
    source: {
      type: String,
      required: true,
      enum: [
        'stripe',
        'paypal', 
        'square',
        'razorpay',
        'internal',
        'api',
        'system',
        'manual',
        'scheduler',
        'other'
      ]
    }
  },
  
  // Webhook Source Details
  source: {
    // External service details
    service: {
      name: String,
      version: String,
      environment: {
        type: String,
        enum: ['production', 'staging', 'development', 'test']
      }
    },
    
    // Webhook endpoint that received this
    endpoint: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'WebhookEndpoint'
    },
    
    // Source IP and security
    ipAddress: String,
    userAgent: String,
    
    // Authentication
    authenticated: {
      type: Boolean,
      default: false
    },
    
    signature: {
      provided: String,
      verified: Boolean,
      algorithm: String // hmac-sha256, etc.
    }
  },
  
  // Request Details
  request: {
    // HTTP details
    method: {
      type: String,
      enum: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'],
      default: 'POST'
    },
    
    url: {
      type: String,
      required: true
    },
    
    headers: {
      type: Map,
      of: String,
      default: new Map()
    },
    
    // Request body
    body: {
      raw: String,          // Raw request body
      parsed: mongoose.Schema.Types.Mixed,  // Parsed JSON
      size: Number,         // Body size in bytes
      contentType: String
    },
    
    // Query parameters
    queryParams: {
      type: Map,
      of: String,
      default: new Map()
    },
    
    // Timing
    receivedAt: {
      type: Date,
      required: true,
      default: Date.now
    },
    
    processingStartedAt: Date,
    processingCompletedAt: Date,
    
    // Request validation
    validation: {
      isValid: Boolean,
      errors: [String],
      warnings: [String]
    }
  },
  
  // Processing Information
  processing: {
    status: {
      type: String,
      required: true,
      enum: [
        'pending',
        'processing', 
        'completed',
        'failed',
        'timeout',
        'cancelled',
        'retrying',
        'skipped'
      ],
      default: 'pending'
    },
    
    // Processing results
    result: {
      success: Boolean,
      message: String,
      errorCode: String,
      errorDetails: String,
      stackTrace: String
    },
    
    // Timing metrics
    metrics: {
      processingTime: Number, // milliseconds
      queueTime: Number,      // time in queue
      totalTime: Number,      // total end-to-end time
      retryDelay: Number,     // delay before retry
      
      // Performance metrics
      memoryUsage: Number,    // MB
      cpuUsage: Number,       // percentage
      dbQueries: Number,      // number of DB queries
      apiCalls: Number        // external API calls made
    },
    
    // Retry information
    retry: {
      attempt: {
        type: Number,
        default: 0
      },
      maxAttempts: {
        type: Number,
        default: 3
      },
      nextAttemptAt: Date,
      backoffMultiplier: {
        type: Number,
        default: 2
      },
      lastError: String
    }
  },
  
  // Response Details
  response: {
    // HTTP response
    statusCode: {
      type: Number,
      required: true,
      default: 200
    },
    
    statusMessage: String,
    
    headers: {
      type: Map,
      of: String,
      default: new Map()
    },
    
    body: {
      raw: String,
      parsed: mongoose.Schema.Types.Mixed,
      size: Number,
      contentType: String
    },
    
    // Response timing
    sentAt: Date,
    deliveredAt: Date,
    
    // Delivery confirmation
    delivered: {
      type: Boolean,
      default: false
    },
    
    deliveryAttempts: {
      type: Number,
      default: 0
    }
  },
  
  // Related Data
  related: {
    // User context
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    
    // Related business objects
    subscriptionId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Subscription'
    },
    
    paymentId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Payment'
    },
    
    invoiceId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Invoice'
    },
    
    ticketId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'SupportTicket'
    },
    
    agentId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Agent'
    },
    
    // External references
    externalId: String,        // External service ID (Stripe payment ID, etc.)
    externalCustomerId: String,
    externalSubscriptionId: String,
    
    // Parent webhook (for related events)
    parentWebhookId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'WebhookLog'
    },
    
    // Correlation ID for tracing
    correlationId: String,
    traceId: String
  },
  
  // Actions Taken
  actions: [{
    type: {
      type: String,
      enum: [
        'user_created',
        'user_updated',
        'payment_processed',
        'subscription_activated',
        'subscription_cancelled',
        'invoice_generated',
        'email_sent',
        'notification_sent',
        'agent_assigned',
        'ticket_created',
        'data_synced',
        'cache_cleared',
        'webhook_forwarded',
        'manual_intervention_required',
        'other'
      ]
    },
    
    description: String,
    
    // Action timing
    performedAt: {
      type: Date,
      default: Date.now
    },
    
    // Action results
    result: {
      success: Boolean,
      message: String,
      data: mongoose.Schema.Types.Mixed
    },
    
    // Action metadata
    metadata: {
      type: Map,
      of: mongoose.Schema.Types.Mixed
    }
  }],
  
  // Security and Compliance
  security: {
    // Risk assessment
    riskLevel: {
      type: String,
      enum: ['low', 'medium', 'high', 'critical'],
      default: 'low'
    },
    
    // Security flags
    flags: [{
      type: String,
      description: String,
      severity: {
        type: String,
        enum: ['info', 'warning', 'error', 'critical']
      },
      raisedAt: {
        type: Date,
        default: Date.now
      }
    }],
    
    // Data classification
    dataClassification: {
      type: String,
      enum: ['public', 'internal', 'confidential', 'restricted'],
      default: 'internal'
    },
    
    // PII detection
    containsPII: {
      type: Boolean,
      default: false
    },
    
    piiFields: [String],
    
    // Compliance requirements
    compliance: {
      gdpr: {
        applicable: Boolean,
        consent: Boolean,
        dataProcessingBasis: String
      },
      
      pci: {
        applicable: Boolean,
        level: String
      },
      
      hipaa: {
        applicable: Boolean,
        covered: Boolean
      }
    }
  },
  
  // Debugging Information
  debug: {
    // Environment context
    environment: {
      nodeVersion: String,
      platform: String,
      hostname: String,
      processId: Number,
      workerId: String
    },
    
    // Application context
    application: {
      name: String,
      version: String,
      buildId: String,
      deploymentId: String
    },
    
    // Request context
    requestId: String,
    sessionId: String,
    
    // Debug logs
    logs: [{
      level: {
        type: String,
        enum: ['debug', 'info', 'warn', 'error']
      },
      message: String,
      timestamp: {
        type: Date,
        default: Date.now
      },
      metadata: mongoose.Schema.Types.Mixed
    }],
    
    // Performance profiling
    profiling: {
      enabled: Boolean,
      samples: [{
        timestamp: Date,
        memoryUsage: Number,
        cpuUsage: Number,
        eventLoopLag: Number
      }]
    }
  },
  
  // Metadata and Tags
  metadata: {
    tags: [String],
    
    // Custom fields for extensibility
    customFields: {
      type: Map,
      of: mongoose.Schema.Types.Mixed,
      default: new Map()
    },
    
    // Integration-specific data
    integration: {
      name: String,
      version: String,
      config: mongoose.Schema.Types.Mixed
    },
    
    // Business context
    business: {
      department: String,
      team: String,
      project: String,
      costCenter: String
    },
    
    // Data retention
    retention: {
      policy: String,
      deleteAfter: Date,
      archived: {
        type: Boolean,
        default: false
      },
      archivedAt: Date
    }
  }
}, {
  timestamps: true
});

// Indexes for performance and querying
// WebhookLogSchema.index({ webhookId: 1 }); // Removed: unique: true already creates index
WebhookLogSchema.index({ 'event.type': 1, createdAt: -1 });
WebhookLogSchema.index({ 'event.source': 1, createdAt: -1 });
WebhookLogSchema.index({ 'processing.status': 1 });
WebhookLogSchema.index({ 'related.userId': 1, createdAt: -1 });
WebhookLogSchema.index({ 'related.externalId': 1 });
WebhookLogSchema.index({ 'request.receivedAt': -1 });
WebhookLogSchema.index({ 'security.riskLevel': 1 });
WebhookLogSchema.index({ 'metadata.retention.deleteAfter': 1 });

// Compound indexes for common queries
WebhookLogSchema.index({ 
  'event.source': 1, 
  'processing.status': 1, 
  createdAt: -1 
});

WebhookLogSchema.index({ 
  'related.userId': 1, 
  'event.type': 1, 
  createdAt: -1 
});

// Calculate processing metrics before saving
WebhookLogSchema.pre('save', function(next) {
  if (this.request.processingStartedAt && this.request.processingCompletedAt) {
    this.processing.metrics.processingTime = 
      this.request.processingCompletedAt - this.request.processingStartedAt;
  }
  
  if (this.request.receivedAt && this.request.processingStartedAt) {
    this.processing.metrics.queueTime = 
      this.request.processingStartedAt - this.request.receivedAt;
  }
  
  if (this.request.receivedAt && this.request.processingCompletedAt) {
    this.processing.metrics.totalTime = 
      this.request.processingCompletedAt - this.request.receivedAt;
  }
  
  next();
});

// Method to mark as processed
WebhookLogSchema.methods.markAsProcessed = function(success, message, result = null) {
  this.processing.status = success ? 'completed' : 'failed';
  this.processing.result.success = success;
  this.processing.result.message = message;
  
  if (result) {
    this.processing.result = { ...this.processing.result, ...result };
  }
  
  this.request.processingCompletedAt = new Date();
  
  return this.save();
};

// Method to add debug log
WebhookLogSchema.methods.addDebugLog = function(level, message, metadata = null) {
  this.debug.logs.push({
    level,
    message,
    timestamp: new Date(),
    metadata
  });
  
  return this.save();
};

const WebhookLog = mongoose.model('WebhookLog', WebhookLogSchema);

// ============================================
// 2. WEBHOOK ENDPOINT MODEL
// ============================================

const WebhookEndpointSchema = new mongoose.Schema({
  // Endpoint Identification
  name: {
    type: String,
    required: true,
    trim: true
  },
  
  description: {
    type: String,
    maxlength: 500
  },
  
  // URL Configuration
  url: {
    type: String,
    required: true,
    trim: true,
    validate: {
      validator: function(v) {
        return /^https?:\/\/.+/.test(v);
      },
      message: 'URL must be a valid HTTP or HTTPS URL'
    }
  },
  
  // Endpoint Status
  isActive: {
    type: Boolean,
    default: true
  },
  
  isHealthy: {
    type: Boolean,
    default: true
  },
  
  // Event Configuration
  events: [{
    type: String,
    enum: [
      'payment_intent.succeeded',
      'payment_intent.failed',
      'invoice.payment_succeeded',
      'invoice.payment_failed',
      'customer.subscription.created',
      'customer.subscription.updated',
      'customer.subscription.deleted',
      'user.created',
      'user.updated',
      'subscription.upgraded',
      'agent.assigned',
      'ticket.created',
      'all'
    ]
  }],
  
  // Security Configuration
  security: {
    // Authentication
    authMethod: {
      type: String,
      enum: ['none', 'basic', 'bearer', 'api_key', 'signature'],
      default: 'signature'
    },
    
    // Secret for signature verification
    secret: {
      type: String,
      required: function() {
        return this.security.authMethod === 'signature';
      }
    },
    
    // API key authentication
    apiKey: String,
    
    // Bearer token
    bearerToken: String,
    
    // Basic auth
    username: String,
    password: String,
    
    // Signature algorithm
    signatureAlgorithm: {
      type: String,
      enum: ['hmac-sha256', 'hmac-sha1', 'md5'],
      default: 'hmac-sha256'
    },
    
    // IP whitelist
    allowedIPs: [String],
    
    // SSL/TLS requirements
    requireSSL: {
      type: Boolean,
      default: true
    }
  },
  
  // Delivery Configuration
  delivery: {
    // Retry policy
    retryPolicy: {
      maxAttempts: {
        type: Number,
        default: 3,
        min: 1,
        max: 10
      },
      
      backoffStrategy: {
        type: String,
        enum: ['fixed', 'linear', 'exponential'],
        default: 'exponential'
      },
      
      initialDelay: {
        type: Number,
        default: 1000, // milliseconds
        min: 100
      },
      
      maxDelay: {
        type: Number,
        default: 300000, // 5 minutes
        min: 1000
      },
      
      backoffMultiplier: {
        type: Number,
        default: 2,
        min: 1
      }
    },
    
    // Timeout settings
    timeout: {
      type: Number,
      default: 30000, // 30 seconds
      min: 1000,
      max: 300000
    },
    
    // Rate limiting
    rateLimit: {
      enabled: {
        type: Boolean,
        default: false
      },
      
      requestsPerMinute: {
        type: Number,
        default: 60,
        min: 1
      },
      
      burstLimit: {
        type: Number,
        default: 10,
        min: 1
      }
    },
    
    // Batching
    batching: {
      enabled: {
        type: Boolean,
        default: false
      },
      
      batchSize: {
        type: Number,
        default: 10,
        min: 1,
        max: 100
      },
      
      batchTimeout: {
        type: Number,
        default: 5000, // 5 seconds
        min: 1000
      }
    }
  },
  
  // Health Monitoring
  health: {
    // Last successful delivery
    lastSuccessfulDelivery: Date,
    
    // Consecutive failures
    consecutiveFailures: {
      type: Number,
      default: 0
    },
    
    // Health check configuration
    healthCheck: {
      enabled: {
        type: Boolean,
        default: true
      },
      
      interval: {
        type: Number,
        default: 300000, // 5 minutes
        min: 60000
      },
      
      timeout: {
        type: Number,
        default: 10000, // 10 seconds
        min: 1000
      },
      
      expectedStatus: {
        type: Number,
        default: 200
      },
      
      lastCheck: Date,
      lastResult: {
        success: Boolean,
        statusCode: Number,
        responseTime: Number,
        error: String
      }
    },
    
    // Circuit breaker
    circuitBreaker: {
      enabled: {
        type: Boolean,
        default: true
      },
      
      failureThreshold: {
        type: Number,
        default: 5
      },
      
      recoveryTimeout: {
        type: Number,
        default: 300000 // 5 minutes
      },
      
      state: {
        type: String,
        enum: ['closed', 'open', 'half-open'],
        default: 'closed'
      },
      
      lastStateChange: Date
    }
  },
  
  // Statistics
  statistics: {
    // Delivery stats
    totalDeliveries: {
      type: Number,
      default: 0
    },
    
    successfulDeliveries: {
      type: Number,
      default: 0
    },
    
    failedDeliveries: {
      type: Number,
      default: 0
    },
    
    // Performance metrics
    averageResponseTime: {
      type: Number,
      default: 0
    },
    
    // Event type breakdown
    eventStats: [{
      eventType: String,
      count: {
        type: Number,
        default: 0
      },
      lastDelivered: Date
    }],
    
    // Recent delivery history
    recentDeliveries: [{
      timestamp: Date,
      success: Boolean,
      responseTime: Number,
      statusCode: Number,
      eventType: String
    }],
    
    // Reset statistics
    lastReset: Date
  },
  
  // Metadata
  metadata: {
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    
    tags: [String],
    
    // Environment
    environment: {
      type: String,
      enum: ['production', 'staging', 'development', 'test'],
      default: 'production'
    },
    
    // Integration context
    integration: {
      name: String,
      version: String,
      provider: String
    },
    
    // Custom fields
    customFields: {
      type: Map,
      of: mongoose.Schema.Types.Mixed,
      default: new Map()
    }
  }
}, {
  timestamps: true
});

// Indexes
WebhookEndpointSchema.index({ url: 1 });
WebhookEndpointSchema.index({ isActive: 1, isHealthy: 1 });
WebhookEndpointSchema.index({ events: 1 });
WebhookEndpointSchema.index({ 'metadata.environment': 1 });

// Method to record delivery attempt
WebhookEndpointSchema.methods.recordDelivery = function(success, responseTime, statusCode, eventType) {
  this.statistics.totalDeliveries += 1;
  
  if (success) {
    this.statistics.successfulDeliveries += 1;
    this.health.lastSuccessfulDelivery = new Date();
    this.health.consecutiveFailures = 0;
    this.isHealthy = true;
  } else {
    this.statistics.failedDeliveries += 1;
    this.health.consecutiveFailures += 1;
    
    // Check circuit breaker
    if (this.health.circuitBreaker.enabled && 
        this.health.consecutiveFailures >= this.health.circuitBreaker.failureThreshold) {
      this.health.circuitBreaker.state = 'open';
      this.health.circuitBreaker.lastStateChange = new Date();
      this.isHealthy = false;
    }
  }
  
  // Update average response time
  const totalTime = (this.statistics.averageResponseTime * (this.statistics.totalDeliveries - 1)) + responseTime;
  this.statistics.averageResponseTime = totalTime / this.statistics.totalDeliveries;
  
  // Add to recent deliveries (keep last 10)
  this.statistics.recentDeliveries.unshift({
    timestamp: new Date(),
    success,
    responseTime,
    statusCode,
    eventType
  });
  
  if (this.statistics.recentDeliveries.length > 10) {
    this.statistics.recentDeliveries = this.statistics.recentDeliveries.slice(0, 10);
  }
  
  // Update event stats
  let eventStat = this.statistics.eventStats.find(es => es.eventType === eventType);
  if (eventStat) {
    eventStat.count += 1;
    eventStat.lastDelivered = new Date();
  } else {
    this.statistics.eventStats.push({
      eventType,
      count: 1,
      lastDelivered: new Date()
    });
  }
  
  return this.save();
};

const WebhookEndpoint = mongoose.model('WebhookEndpoint', WebhookEndpointSchema);

// Export webhook models
module.exports = {
  WebhookLog,
  WebhookEndpoint
};