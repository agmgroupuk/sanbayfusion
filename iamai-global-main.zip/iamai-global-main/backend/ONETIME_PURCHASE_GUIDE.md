# 🎯 One-Time Purchase Implementation Guide

## Overview
Converting from recurring subscriptions to one-time purchases with time-based access.

---

## ✅ What You Clarified

### Business Logic:
1. **One-time payment** - Not recurring subscriptions
2. **Per-agent purchases** - Each agent purchased separately  
3. **Single active purchase** - One active plan per agent at a time
4. **Duration-based access**: 
   - Daily = 1 day access ($X)
   - Weekly = 7 days access ($Y)
   - Monthly = 30 days access ($Z)
5. **No upgrades/downgrades** - Only cancel option
6. **Re-purchase** - Only after expiration or cancellation
7. **Multiple agents** - User can have different agents active simultaneously

---

## 🔧 Implementation Steps

### **STEP 1: Update Stripe Prices** ⚠️ CRITICAL FIRST

**Current problem:**
- All 51 prices are set as `recurring` subscriptions
- Creates auto-renewal logic

**Solution:**
```bash
cd /Users/onelastai/Downloads/iamai-global/backend
node create-onetime-prices.js
```

This will:
- Create 51 NEW one-time prices
- Output new price IDs for .env
- Keep old prices active temporarily

**Then update backend/.env:**
Replace all 51 `STRIPE_PRICE_*` variables with new one-time price IDs.

---

### **STEP 2: Update Database Schema**

**Unified collection: `agent_purchases`**

Model: `backend/agent-purchase-models.js` (exports `AgentPurchase`)

**Key fields (unified):**
- `userId` - Who purchased
- `agentId` - Which agent (aigirlfriend, agentx, etc.)
- `plan` - DAILY/WEEKLY/MONTHLY
- `planName` - Human readable name (Daily Access, Weekly Pro, Monthly Unlimited)
- `pricing` - `{ amount, currency }`
- `purchaseDate` - When purchased
- `expiresAt` - When access ends
- `status` - ACTIVE/EXPIRED/CANCELLED/REFUNDED
- `stripePaymentIntentId` - One-time payment ID

**Legacy compatibility fields (still supported but not required):**
- `planType` - daily/weekly/monthly
- `expirationDate` - Legacy expiration field
- `amount`, `currency` - Legacy pricing

**Helper methods (on AgentPurchase):**
- `hasActiveAccess(userId, agentId)` - Check if user can access agent
- `findActivePurchase(userId, agentId)` - Get active purchase details
- `getUserActivePurchases(userId)` - List all active purchases
- `getPlanConfig(plan)` - Get plan pricing/config
- `calculateExpiration(plan)` - Auto-calc expiration date
- `purchase.cancel()` - Cancel access immediately

---

### **STEP 3: Backend API Endpoints**

**Required new endpoints:**

#### **1. Purchase Agent Access**
```javascript
POST /api/agents/:agentId/purchase
Body: { planType: "daily" | "weekly" | "monthly" }

Logic:
1. Check if user already has active access → reject if yes
2. Get Stripe price ID for agent + plan
3. Create Stripe Checkout Session (one-time payment mode)
4. Return checkout URL
```

#### **2. Handle Payment Success (Webhook)**
```javascript
POST /api/webhooks/stripe

On checkout.session.completed:
1. Get payment details
2. Calculate expiration date
3. Create AgentPurchase record with status="active"
4. Grant user access
```

#### **3. Check Access**
```javascript
GET /api/agents/:agentId/access

Returns:
{
  hasAccess: true/false,
  purchase: {
    planType: "monthly",
    expiresAt: "2025-01-15T10:00:00Z",
    daysRemaining: 25
  }
}
```

#### **4. Cancel Access**
```javascript
POST /api/agents/:agentId/cancel

Logic:
1. Find active purchase
2. Set status = "cancelled"
3. Set expirationDate = now
4. Return success
```

#### **5. List My Purchases**
```javascript
GET /api/purchases/my-purchases

Returns array:
[
  {
    agentId: "aigirlfriend",
    planType: "monthly",
    purchaseDate: "2024-12-01",
    expiresAt: "2024-12-31",
    status: "active"
  },
  ...
]
```

---

### **STEP 4: Frontend Updates**

**Terminology changes everywhere:**
```
"Subscribe" → "Purchase" / "Buy Access"
"Subscription" → "Access" / "Purchase"  
"Cancel Subscription" → "Cancel Access"
"Next Billing" → "Expires On"
"Manage Subscriptions" → "My Purchases"
```

**Purchase button logic:**
```javascript
// Check if user has active access
const { hasAccess } = await fetch(`/api/agents/${agentId}/access`);

if (hasAccess) {
  button.disabled = true;
  button.text = "Already Purchased";
} else {
  button.text = "Purchase Access";
  button.onClick = () => purchaseAgent(agentId, planType);
}
```

**Agent access page:**
```javascript
<AgentCard>
  {hasAccess ? (
    <div>
      <Badge>Active</Badge>
      <p>Expires: {expirationDate}</p>
      <p>Days remaining: {daysLeft}</p>
      <Button onClick={cancelAccess}>Cancel Access</Button>
    </div>
  ) : (
    <div>
      <Button onClick={() => purchase('daily')}>1 Day - $1</Button>
      <Button onClick={() => purchase('weekly')}>7 Days - $5</Button>
      <Button onClick={() => purchase('monthly')}>30 Days - $15</Button>
    </div>
  )}
</AgentCard>
```

**Remove completely:**
- Upgrade/downgrade buttons
- Change plan modal
- Subscription management complexity
- Auto-renewal toggles

---

## 🔄 Migration Path

### **For existing users with subscriptions:**

**Option A: Grandfather existing subscriptions**
- Let current subscriptions run until they expire
- New purchases use one-time system
- Eventually all migrate to new system

**Option B: Force migration**
1. Cancel all Stripe subscriptions
2. Grant users equivalent access based on remaining time
3. Create AgentPurchase records with matching expiration
4. Notify users of system change

**Recommended:** Option A (less disruptive)

---

## 📊 Database Migration Script

```javascript
// Convert existing subscriptions to purchases
async function migrateSubscriptionsToPurchases() {
  const subscriptions = await OldSubscriptionModel.find({ status: 'active' });
  
  for (const sub of subscriptions) {
    const purchase = new AgentPurchase({
      userId: sub.userId,
      agentId: sub.agentId,
      planType: sub.planType,
      purchaseDate: sub.createdAt,
      expirationDate: calculateMigrationExpiration(sub),
      status: 'active',
      stripePaymentIntentId: `migrated_${sub._id}`,
      amount: sub.amount,
      currency: 'usd'
    });
    
    await purchase.save();
  }
}
```

---

## ✅ Verification Checklist

### **Stripe:**
- [ ] All 51 prices are `type: "one_time"`
- [ ] Old recurring prices archived
- [ ] backend/.env has new price IDs

### **Database:**
- [ ] AgentPurchase model created
- [ ] Indexes added
- [ ] Test data created

### **Backend:**
- [ ] Purchase endpoint blocks duplicate purchases
- [ ] Expiration calculation correct
- [ ] Cancel sets expiration to now
- [ ] Access check validates expiration date
- [ ] Webhook handles checkout.session.completed

### **Frontend:**
- [ ] All "subscription" text changed to "purchase"
- [ ] Purchase button disabled if has active access
- [ ] Expiration date displayed
- [ ] No upgrade/downgrade options
- [ ] Cancel button works

### **Testing:**
- [ ] Purchase agent access (all 3 plans)
- [ ] Try to purchase same agent twice (should fail)
- [ ] Cancel access (expires immediately)
- [ ] Re-purchase after cancellation (should work)
- [ ] Purchase different agents (should work)
- [ ] Access expires after duration

---

## 🚨 Breaking Changes

1. **Stripe webhook payload changes** - Now receives `checkout.session.completed` instead of `customer.subscription.created`
2. **Database schema incompatible** - Old subscription records won't work
3. **Frontend API calls different** - New endpoint structure
4. **No backward compatibility** - Clean break from old system

---

## 💡 Recommendations

1. **Set clear pricing** - Update amounts in create-onetime-prices.js
2. **Add purchase limits** - Max X purchases per day per user (prevent abuse)
3. **Email notifications** - Send receipt + expiration reminders
4. **Auto-expire job** - Cron job to set expired purchases to "expired" status
5. **Analytics** - Track which plans sell best per agent

---

## 📝 Next Steps

1. **Run Stripe price creation script**
2. **Update backend/.env with new prices**
3. **Deploy AgentPurchase model**
4. **Implement API endpoints**
5. **Update frontend UI**
6. **Test thoroughly**
7. **Deploy to production**

---

## 🔗 Files Created

- `/backend/create-onetime-prices.js` - Script to create Stripe prices
- `/backend/models/AgentPurchase.js` - Database model
- `/backend/ONETIME_PURCHASE_GUIDE.md` - This guide

---

## ❓ Questions to Answer

1. **Pricing:** What should each plan cost?
   - Daily: $__
   - Weekly: $__
   - Monthly: $__

2. **Grace period:** Allow access for X hours after expiration?

3. **Refunds:** Allow refunds within X days?

4. **Trial period:** Offer free trial before purchase?

5. **Bulk discounts:** Discount for buying multiple agents?

---

This is MUCH simpler than subscriptions! 🎉
