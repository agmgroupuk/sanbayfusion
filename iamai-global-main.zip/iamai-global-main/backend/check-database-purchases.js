// Check database collections and purchases
require("dotenv").config();
const mongoose = require("mongoose");

async function checkDatabase() {
  try {
    console.log("🔌 Connecting to MongoDB...");
    await mongoose.connect(process.env.MONGODB_URI);
    console.log("✅ Connected\n");
    
    const db = mongoose.connection.db;
    
    // List all collections
    console.log("📚 ALL COLLECTIONS:");
    const collections = await db.listCollections().toArray();
    collections.forEach(c => console.log("  -", c.name));
    
    // Check agent_purchases collection
    console.log("\n📦 agent_purchases collection:");
    const totalPurchases = await db.collection("agent_purchases").countDocuments();
    console.log("  Total documents:", totalPurchases);
    
    const purchases = await db.collection("agent_purchases").find({}).sort({createdAt: -1}).limit(5).toArray();
    console.log("  Latest 5 purchases:");
    purchases.forEach((p, i) => {
      console.log(`\n  [${i+1}] ID: ${p._id}`);
      console.log(`      userId: ${p.userId}`);
      console.log(`      agentId: ${p.agentId}`);
      console.log(`      status: ${p.status}`);
      console.log(`      paymentStatus: ${p.paymentStatus}`);
      console.log(`      plan: ${p.plan || p.planType}`);
      console.log(`      stripeSessionId: ${p.stripeCheckoutSessionId || 'N/A'}`);
      console.log(`      createdAt: ${p.createdAt}`);
    });
    
    // Check for PENDING purchases
    const pending = await db.collection("agent_purchases").find({
      status: { $in: ["PENDING", "pending"] }
    }).toArray();
    console.log("\n⏳ PENDING purchases:", pending.length);
    pending.forEach(p => {
      console.log(`  - ${p.agentId} for user ${p.userId} (session: ${p.stripeCheckoutSessionId})`);
    });
    
    // Check for ACTIVE purchases
    const active = await db.collection("agent_purchases").find({
      status: { $in: ["ACTIVE", "active"] }
    }).toArray();
    console.log("\n✅ ACTIVE purchases:", active.length);
    active.forEach(p => {
      console.log(`  - ${p.agentId} for user ${p.userId} (expires: ${p.expiresAt || p.expirationDate})`);
    });
    
    // Check purchases in last 24 hours
    const recent = await db.collection("agent_purchases").find({
      createdAt: { $gte: new Date(Date.now() - 24*60*60*1000) }
    }).toArray();
    console.log("\n🕐 Purchases in last 24 hours:", recent.length);
    
    // Check if there are any schema/model issues
    console.log("\n🔍 Checking for potential issues...");
    
    // Check for documents with missing required fields
    const missingUserId = await db.collection("agent_purchases").countDocuments({ userId: { $exists: false } });
    const missingAgentId = await db.collection("agent_purchases").countDocuments({ agentId: { $exists: false } });
    const missingStatus = await db.collection("agent_purchases").countDocuments({ status: { $exists: false } });
    
    console.log(`  Missing userId: ${missingUserId}`);
    console.log(`  Missing agentId: ${missingAgentId}`);
    console.log(`  Missing status: ${missingStatus}`);
    
    // Check unique constraint issues
    const indexes = await db.collection("agent_purchases").indexes();
    console.log("\n📋 Current indexes:");
    indexes.forEach(idx => {
      const unique = idx.unique ? " (UNIQUE)" : "";
      console.log(`  - ${idx.name}: ${JSON.stringify(idx.key)}${unique}`);
    });
    
    process.exit(0);
  } catch (error) {
    console.error("❌ Error:", error);
    process.exit(1);
  }
}

checkDatabase();
