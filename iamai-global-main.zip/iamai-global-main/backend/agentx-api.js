// ============================================
// AGENT X - INDIVIDUAL API ENDPOINTS
// ============================================

const express = require('express');
const router = express.Router();
const models = require('./models');
const { AgentPurchase } = require('./agent-purchase-models');
const { checkAgentPurchase } = require('./middleware/purchaseValidation');

// ============================================
// AGENT X PURCHASE MANAGEMENT (NEW SIMPLE SYSTEM)
// ============================================

// Get Agent X purchase for user
router.get('/agentx/purchase/:userId', async (req, res) => {
  try {
    const purchase = await AgentPurchase.findOne({
      userId: req.params.userId,
      agentId: 'agentx',
      status: 'ACTIVE',
      expiresAt: { $gt: new Date() }
    }).populate('userId', 'username email');

    if (!purchase) {
      return res.status(404).json({ error: 'Agent X purchase not found' });
    }

    res.json({
      ...purchase.toObject(),
      daysRemaining: purchase.daysRemaining,
      hoursRemaining: purchase.hoursRemaining
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Create Agent X purchase (REDIRECTS TO NEW PURCHASE API)
router.post('/agentx/purchase', checkAgentPurchase, async (req, res) => {
  try {
    const { userId, plan, paymentMethodId } = req.body;

    // Check if user already has Agent X purchase
    const existing = await AgentPurchase.findActivePurchase(userId, 'agentx');

    if (existing) {
      return res.status(400).json({ 
        error: 'User already has active Agent X access',
        expiresAt: existing.expiresAt,
        daysRemaining: existing.daysRemaining
      });
    }

    const pricing = {
      DAILY: { amount: 1, interval: 'day', limit: 50 },
      WEEKLY: { amount: 5, interval: 'week', limit: 400 },
      MONTHLY: { amount: 19, interval: 'month', limit: 2000 },
    };

    const planUpper = plan.toUpperCase();
    const planConfig = pricing[planUpper];

    // Use per-agent price ID from .env (assuming agentId is 'agentx')
    const priceId = process.env[`STRIPE_PRICE_AGENTX_${planUpper}`];
    if (!priceId) {
      return res.status(500).json({ error: 'Price configuration not found for AgentX and plan' });
    }
    const now = new Date();
    // Redirect to new purchase API
    return res.status(301).json({
      message: 'Please use the new purchase API',
      redirectTo: '/api/agents/agentx/purchase',
      body: { plan, agentName: 'Agent X' }
    });

    await subscription.save();

    // Log activity
    await new AgentXModels.AgentXActivity({
      userId,
      agentId: 'agent-x',
      activity: {
        type: 'SUBSCRIPTION_STARTED',
        description: `Started ${plan} subscription for Agent X`,
        metadata: { plan, amount: planConfig.amount },
      },
    }).save();

    res.json(subscription);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Simple One-Time Purchase - No plan changes allowed
// User must cancel current purchase and buy again after expiration
router.put('/agentx/purchase/:userId/cancel', async (req, res) => {
  try {
    const purchase = await AgentPurchase.findOne({
      userId: req.params.userId,
      agentId: 'agentx',
      status: 'ACTIVE',
      expiresAt: { $gt: new Date() }
    });

    if (!purchase) {
      return res.status(404).json({ error: 'No active Agent X purchase found' });
    }

    // Cancel the purchase
    await purchase.cancel();

    res.json({ success: true, message: 'Purchase cancelled successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ============================================
// AGENT X CHAT MANAGEMENT
// ============================================

// Get Agent X chat history
router.get('/agentx/chats/:userId', async (req, res) => {
  try {
    const { page = 1, limit = 20 } = req.query;
    const skip = (page - 1) * limit;

    const chats = await AgentXModels.AgentXChat.find({
      userId: req.params.userId,
      agentId: 'agent-x',
    })
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit));

    const total = await AgentXModels.AgentXChat.countDocuments({
      userId: req.params.userId,
      agentId: 'agent-x',
    });

    res.json({ chats, total, page: parseInt(page), totalPages: Math.ceil(total / limit) });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Create Agent X chat message
router.post('/agentx/chat', checkAgentPurchase, async (req, res) => {
  try {
    const { userId, sessionId, userMessage, agentResponse } = req.body;

    // NOTE: Purchase system - one-time purchases grant unlimited access
    // No message limits - all paid plans have unlimited messages
    
    // Create chat record
    const chat = new models.AgentXChat({
      userId,
      sessionId,
      agentId: 'agent-x',
      conversationId: `conv_${sessionId}_${Date.now()}`,
      messageId: `msg_${sessionId}_${Date.now()}`,
      userMessage,
      agentResponse,
      interaction: {
        mode: 'standard', // Default mode
        responseDepth: 'detailed',
      },
    });

    await chat.save();

    res.json(chat);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ============================================
// AGENT X ANALYTICS
// ============================================

// Get Agent X usage analytics
router.get('/agentx/analytics/:userId', async (req, res) => {
  try {
    const { period = 'daily', days = 7 } = req.query;
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    const analytics = await AgentXModels.AgentXAnalytics.find({
      userId: req.params.userId,
      agentId: 'agent-x',
      date: { $gte: startDate },
    }).sort({ date: -1 });

    // Get current purchase
    const purchase = await AgentPurchase.findActivePurchase(req.params.userId, 'agentx');

    // Calculate totals
    const totals = analytics.reduce(
      (acc, day) => ({
        conversationsStarted: acc.conversationsStarted + day.daily.conversationsStarted,
        messagesExchanged: acc.messagesExchanged + day.daily.messagesExchanged,
        tokensConsumed: acc.tokensConsumed + day.daily.tokensConsumed,
        sessionDuration: acc.sessionDuration + day.daily.sessionDuration,
        complexQueriesHandled: acc.complexQueriesHandled + day.daily.complexQueriesHandled,
        codeSnippetsGenerated: acc.codeSnippetsGenerated + day.daily.codeSnippetsGenerated,
      }),
      {
        conversationsStarted: 0,
        messagesExchanged: 0,
        tokensConsumed: 0,
        sessionDuration: 0,
        complexQueriesHandled: 0,
        codeSnippetsGenerated: 0,
      }
    );

    res.json({ analytics, totals, subscription });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }purchase
});

// ============================================
// AGENT X ACTIVITY LOGS
// ============================================

// Get Agent X activity logs
router.get('/agentx/activities/:userId', async (req, res) => {
  try {
    const { page = 1, limit = 50 } = req.query;
    const skip = (page - 1) * limit;

    const activities = await AgentXModels.AgentXActivity.find({
      userId: req.params.userId,
      agentId: 'agent-x',
    })
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit));

    const total = await AgentXModels.AgentXActivity.countDocuments({
      userId: req.params.userId,
      agentId: 'agent-x',
    });

    res.json({ activities, total, page: parseInt(page), totalPages: Math.ceil(total / limit) });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ============================================
// AGENT X TRANSACTIONS
// ============================================

// Get Agent X transaction history
router.get('/agentx/transactions/:userId', async (req, res) => {
  try {
    const transactions = await AgentXModels.AgentXTransaction.find({
      userId: req.params.userId,
      agentId: 'agent-x',
    })
      .sort({ createdAt: -1 })
      .populate('subscriptionId');

    const totalSpent = transactions
      .filter(tx => tx.transaction.type === 'PAYMENT')
      .reduce((sum, tx) => sum + tx.transaction.amount, 0);

    res.json({ transactions, totalSpent });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
