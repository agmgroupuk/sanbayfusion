# IAMAI Global Platform

A comprehensive multi-agent AI platform with 17+ intelligent agents, 30+ developer tools, and enterprise-grade features.

## 🚀 Platform Overview

**IAMAI Global** is a complete AI-powered platform offering:
- **17 Specialized AI Agents** for different tasks and personalities
- **30+ Network & Developer Tools** for professionals
- **Real-time Multi-Agent Communication** with WebSocket support
- **Enterprise Security & Analytics** built-in
- **Payment Processing** for Pro/Enterprise features
- **Voice & Image AI** capabilities

## 🤖 AI Agents (17 Total)

### Personal & Professional Agents
1. **Hope** - Empathetic assistant, emotional intelligence
2. **Dr. Carter** - Medical expertise, health guidance
3. **Marcus** - Professional life & career coaching
4. **Elena** - Learning & education specialist
5. **Zen** - Wellness, meditation, mindfulness
6. **Luna** - Creative & artistic guidance
7. **Atlas** - Travel & exploration planning

### Technical & Business Agents
8. **CodeMaster** - Programming & development expert
9. **DataWiz** - Data science & analytics specialist
10. **SecuritySage** - Cybersecurity & network security
11. **CloudArchitect** - Cloud infrastructure & DevOps
12. **FinanceGuru** - Financial planning & investment
13. **LegalEagle** - Legal advice & compliance
14. **MarketingMaven** - Marketing strategy & content

### Entertainment & Lifestyle
15. **Chef** - Culinary arts & recipe guidance
16. **SportsPro** - Sports training & fitness
17. **TechTrends** - Technology news & trends

## 🛠️ Developer Toolbox (30+ Tools)

### Network & IP Tools
- **IP Geolocation** - Locate any IP address with map visualization
- **IP Netblocks** - Discover network ranges and CIDR information
- **WHOIS Lookup** - Domain registration and ownership details
- **DNS Lookup** - Query all DNS record types (A, AAAA, CNAME, MX, NS, SOA, SRV, TXT)
- **Reverse DNS** - IP to hostname resolution
- **Ping Test** - Real-time WebSocket-based ping testing
- **Port Scanner** - Check open ports and services
- **Traceroute** - Network path visualization

### Domain & Security Tools
- **Domain Availability** - Check domain registration status with pricing
- **Domain Research Suite** - Comprehensive domain intelligence
- **Domain Reputation** - Security risk analysis and threat detection
- **SSL Certificate Checker** - Certificate validation and expiry monitoring
- **HTTP Headers Analyzer** - Security headers analysis with scoring
- **Website Categorization** - Intelligent AI-powered site classification
- **Threat Intelligence** - Real-time security threat monitoring

### Developer & Validation Tools
- **Email Verification** - Validate email addresses (format, SMTP, MX records)
- **MAC Address Lookup** - Hardware vendor identification
- **Screenshot API** - Website screenshot generation
- **API Tester** - RESTful API testing with authentication
- **JSON Formatter** - Format and validate JSON data
- **Base64 Encoder/Decoder** - Data encoding utilities
- **Hash Generator** - MD5, SHA-1, SHA-256, SHA-512
- **UUID Generator** - Generate unique identifiers
- **QR Code Generator** - Create QR codes for any data
- **Color Picker** - Design and development color tools
- **Regex Tester** - Regular expression validation
- **Code Beautifier** - Format code (JS, HTML, CSS, JSON)
- **Text Diff Checker** - Compare text differences
- **Password Generator** - Secure password creation

## 🎯 Key Features

## 🎯 Key Features

### AI & Intelligence
- **Multi-AI Provider Support**: OpenAI, Anthropic, Google AI, RunwayML, Stability AI, Replicate
- **17 Specialized Agents**: Each with unique personality and expertise
- **Real-time Streaming**: WebSocket-based live responses
- **Context Management**: Persistent conversation memory
- **Voice Synthesis**: Text-to-speech with emotional tone
- **Image Generation**: AI-powered image creation
- **Intelligent Categorization**: AI-powered website/domain analysis

### Developer Tools & Network Services
- **30+ Professional Tools**: Network, security, validation, development
- **Real-time Monitoring**: Live ping tests, port scanning, traceroute
- **DNS & WHOIS**: Complete domain intelligence
- **Security Analysis**: Threat detection, SSL validation, reputation scoring
- **API Integration**: RESTful testing, webhook support
- **Data Validation**: Email, MAC address, JSON, regex testing

### Authentication & Security
- **User Authentication**: Auth.js v5 with JWT tokens (passwordless + password-based)
- **Role-Based Access**: Free, Pro, Enterprise tiers
- **Security Headers**: Helmet.js protection with CSP
- **Rate Limiting**: IP-based and user-based throttling
- **API Key Management**: Secure backend key storage
- **CORS Protection**: Configured for authorized domains
- **SSL/TLS**: Let's Encrypt certificates

### Payment & Subscriptions
- **Payment Processing**: Stripe and PayPal integration
- **Subscription Tiers**: Free, Pro ($9.99/mo), Enterprise ($49.99/mo)
- **Usage Tracking**: Monitor API calls and tool usage
- **Billing Management**: Automatic renewals and invoicing

### Database & Caching
- **Database**: PostgreSQL with Prisma ORM + MongoDB for sessions
- **Caching**: Redis for session management and rate limiting
- **Real-time Sync**: WebSocket connection state management
- **Data Persistence**: Conversation history, user preferences, analytics

### Monitoring & Analytics
- **Health Checks**: Real-time system status monitoring
- **Winston Logging**: Comprehensive error and access logs
- **Usage Analytics**: Daily/monthly statistics dashboard
- **Performance Tracking**: Response time and uptime monitoring
- **Error Tracking**: Automatic error reporting and alerts

### Production Infrastructure
- **PM2 Process Management**: Cluster mode with 2 instances
- **Nginx Reverse Proxy**: Load balancing and SSL termination
- **AWS EC2 Deployment**: Ubuntu 20.04 LTS on t3.medium
- **Auto-scaling**: Ready for horizontal scaling
- **Backup & Recovery**: Automated database backups
- **CI/CD**: Git-based deployment pipeline

## 🏗️ Architecture

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Frontend      │    │   Nginx         │    │   Backend API   │
│   (React)       │───▶│   Reverse Proxy │───▶│   (Node.js)     │
└─────────────────┘    └─────────────────┘    └─────────────────┘
                                                       │
                       ┌─────────────────┐            │
                       │   Redis Cache   │◀───────────┤
                       └─────────────────┘            │
                                                       │
                       ┌─────────────────┐            │
                       │   PostgreSQL    │◀───────────┘
                       └─────────────────┘
```

## 🛠️ Tech Stack

- **Runtime**: Node.js 18+
- **Framework**: Express.js
- **Language**: TypeScript
- **Database**: PostgreSQL + MongoDB
- **ORM**: Prisma
- **Cache**: Redis
- **Authentication**: Auth.js v5 (passwordless + password)
- **Payments**: Stripe, PayPal
- **AI Providers**: OpenAI, Anthropic, Google AI, RunwayML, etc.
- **WebSockets**: Socket.IO
- **Process Management**: PM2
- **Reverse Proxy**: Nginx
- **Monitoring**: Winston, Health checks

## 📋 Prerequisites

- Node.js 18+
- PostgreSQL 14+ (local or hosted)
- Redis 6+ (local or hosted)
- MongoDB (for Auth.js sessions)
- npm or yarn
- PM2 (for production)
- AWS Account (for deployment)
- Domain name (iamai.global)

## 🚀 Quick Start

### Local Development

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd iamai-global/backend
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment variables**
   ```bash
   cp .env.example .env
   # Edit .env with your configuration
   ```

4. **Start PostgreSQL and Redis**
   ```bash
   # Install and start PostgreSQL (Ubuntu/Debian)
   sudo apt-get install postgresql postgresql-contrib
   sudo systemctl start postgresql
   
   # Install and start Redis
   sudo apt-get install redis-server
   sudo systemctl start redis
   
   # Or use hosted services (recommended for production)
   ```

5. **Run database migrations**
   ```bash
   npx prisma migrate dev
   ```

6. **Start development server**
   ```bash
   npm run dev
   ```

### Production Deployment (AWS EC2)

1. **Launch EC2 instance**
   - Ubuntu 20.04 LTS
   - t3.medium or larger
   - Security groups: HTTP (80), HTTPS (443), SSH (22)

2. **Run deployment script**
   ```bash
   chmod +x scripts/deploy.sh
   ./scripts/deploy.sh
   ```

3. **Configure DNS**
   - Point api.iamai.global to your EC2 IP
   - Point iamai.global to your EC2 IP (if serving frontend)

## 🔧 Configuration

### Environment Variables

```env
# Database
DATABASE_URL=postgresql://username:password@localhost:5432/iamai_db

# JWT
JWT_SECRET=your_super_secret_jwt_key

# AI Providers
OPENAI_API_KEY=your_openai_key
ANTHROPIC_API_KEY=your_anthropic_key
GOOGLE_AI_API_KEY=your_google_ai_key
RUNWAYML_API_KEY=your_runwayml_key
STABILITY_AI_API_KEY=your_stability_key
REPLICATE_API_TOKEN=your_replicate_token

# Authentication (Auth.js v5)
NEXTAUTH_URL=http://localhost:3000
NEXTAUTH_URL_INTERNAL=http://localhost:3001
NEXTAUTH_SECRET=your_super_secret_nextauth_key_here
EMAIL_FROM=noreply@yourdomain.com
EMAIL_SERVER_HOST=smtp.gmail.com
EMAIL_SERVER_PORT=587
EMAIL_SERVER_USER=your_email@gmail.com
EMAIL_SERVER_PASSWORD=your_email_app_password

# MongoDB (for Auth.js)
MONGODB_URI=mongodb://localhost:27017/iamai_auth

# Payments
STRIPE_SECRET_KEY=your_stripe_secret
STRIPE_WEBHOOK_SECRET=your_stripe_webhook_secret
PAYPAL_CLIENT_ID=your_paypal_client_id
PAYPAL_CLIENT_SECRET=your_paypal_secret

# Redis
REDIS_URL=redis://localhost:6379

# URLs
FRONTEND_URL=https://iamai.global
BACKEND_URL=https://api.iamai.global
```

## 📚 API Documentation

### Authentication
- `POST /api/auth/signup` - Register new user (password-based)
- `POST /api/auth/signin` - Login (magic link or password)
- `POST /api/auth/forgot-password` - Request password reset
- `POST /api/auth/reset-password` - Reset password with token
- `GET /api/auth/session` - Get current session
- `POST /api/auth/logout` - End user session

### Agents (17 AI Personalities)
- `GET /api/agents` - List all 17 agents with capabilities
- `GET /api/agents/:id` - Get specific agent details
- `POST /api/agents/:id/chat` - Chat with specific agent
- `GET /api/agents/:id/personality` - Get agent personality traits
- `POST /api/agents/custom` - Create custom agent (Enterprise)

### Chat & Conversations
- `GET /api/chat` - List user chat sessions
- `POST /api/chat` - Create new chat session
- `POST /api/chat/:id/message` - Send message to agent
- `GET /api/chat/:id/history` - Get conversation history
- `DELETE /api/chat/:id` - Delete chat session
- `PUT /api/chat/:id/title` - Update chat title

### Developer Tools (30+ Endpoints)

#### Network Tools
- `GET /api/tools/ip-geolocation?ip=` - Get IP location data
- `GET /api/tools/ip-netblocks?ip=` - Get network block info
- `GET /api/tools/whois?domain=` - WHOIS domain lookup
- `GET /api/tools/dns?domain=&type=` - DNS record lookup
- `GET /api/tools/reverse-dns?ip=` - Reverse DNS lookup
- `GET /api/tools/headers?url=` - HTTP headers analysis
- `WebSocket /tools:ping:start` - Real-time ping test
- `WebSocket /tools:ping:stop` - Stop ping test

#### Security & Domain Tools
- `GET /api/tools/domain-availability?domain=` - Check domain availability
- `GET /api/tools/domain-reputation?domain=` - Domain reputation check
- `GET /api/tools/ssl-check?domain=` - SSL certificate validation
- `GET /api/tools/website-categorization?url=` - AI-powered site categorization
- `GET /api/tools/threat-intelligence?indicator=` - Threat analysis

#### Validation & Development Tools
- `POST /api/tools/email-verify` - Email address verification
- `GET /api/tools/mac-lookup?mac=` - MAC address vendor lookup
- `POST /api/tools/screenshot` - Generate website screenshot
- `POST /api/tools/api-test` - Test REST API endpoints
- `POST /api/tools/json-validate` - Validate JSON structure
- `POST /api/tools/hash-generate` - Generate cryptographic hashes

### Payments & Subscriptions
- `POST /api/payments/create-subscription` - Create new subscription
- `POST /api/payments/cancel-subscription` - Cancel active subscription
- `POST /api/payments/update-payment-method` - Update payment details
- `GET /api/payments/invoices` - Get billing history
- `POST /api/payments/webhook` - Stripe/PayPal webhooks
- `GET /api/payments/plans` - Available subscription plans

### Users & Profile
- `GET /api/users/profile` - Get user profile with subscription
- `PUT /api/users/profile` - Update profile information
- `GET /api/users/usage` - Get usage statistics and limits
- `GET /api/users/preferences` - Get user preferences
- `PUT /api/users/preferences` - Update preferences
- `GET /api/users/api-keys` - Manage API keys (Enterprise)

### Analytics & Monitoring
- `GET /api/analytics/dashboard` - Usage dashboard data
- `GET /api/analytics/agents` - Agent usage statistics
- `GET /api/analytics/tools` - Tool usage analytics
- `GET /health` - System health check endpoint
- `GET /api/status` - Platform status and uptime

## 🔒 Security Features

- **Authentication**: JWT tokens with Auth.js v5 (passwordless + password)
- **Authorization**: Role-based access control
- **Password Security**: bcrypt hashing (10+ rounds)
- **Rate Limiting**: IP-based and user-based limits
- **Input Validation**: Request validation with Joi
- **Security Headers**: Helmet.js protection
- **CORS**: Configured for frontend domains
- **SSL/TLS**: Let's Encrypt certificates
- **API Keys**: Secure API access for integrations

## 📊 Monitoring & Analytics

- **Health Checks**: `/health` endpoint
- **Logging**: Winston with log rotation
- **Usage Analytics**: Daily/monthly user statistics
- **Error Tracking**: Comprehensive error logging
- **Performance Monitoring**: Response time tracking

## 🗄️ Database Schema

The application uses PostgreSQL (Prisma) + MongoDB (Auth.js). Key entities:

- **Users**: User accounts with Auth.js authentication
- **Sessions**: JWT-based sessions with MongoDB
- **Agents**: AI agents with different providers/models
- **Chats**: Conversation sessions
- **Messages**: Individual chat messages
- **Subscriptions**: Payment subscriptions
- **Transactions**: Payment transactions
- **Analytics**: Usage analytics data

## 🔄 Deployment

### PM2 Production Deployment
```bash
# Install PM2 globally
npm install -g pm2

# Build application
npm run build

# Run migrations
npx prisma migrate deploy

# Start with PM2
pm2 start ecosystem.config.js

# View logs
pm2 logs

# Monitor
pm2 monit
```

See `PRODUCTION_DEPLOYMENT_GUIDE.md` for complete deployment instructions.

## 🧪 Testing

```bash
# Run tests
npm test

# Run tests in watch mode
npm run test:watch

# Run test coverage
npm run test:coverage
```

## 📝 Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm start` - Start production server
- `npm run migrate` - Run database migrations
- `npm test` - Run tests
- `./scripts/deploy.sh` - Deploy to production
- `./scripts/backup.sh` - Backup database

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License.

## 🆘 Support

For support and questions:
- Email: support@iamai.global
- Documentation: https://docs.iamai.global
- Issues: GitHub Issues

## 🔄 Version History

- **1.0.0** - Initial release with core features
- **1.1.0** - Added payment processing
- **1.2.0** - Enhanced AI provider support
- **1.3.0** - WebSocket real-time features

---

Built with ❤️ by the IAMAI Global team