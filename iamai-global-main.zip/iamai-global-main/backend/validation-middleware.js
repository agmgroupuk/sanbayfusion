/**
 * 🔒 Input Validation Middleware
 * Comprehensive input validation for API endpoints
 */

const Joi = require('joi');

// Validation Schemas
const validationSchemas = {
  // Auth schemas
  login: Joi.object({
    email: Joi.string().email().required().messages({
      'string.email': 'Please provide a valid email address',
      'any.required': 'Email is required'
    }),
    password: Joi.string().min(8).max(128).required().messages({
      'string.min': 'Password must be at least 8 characters long',
      'string.max': 'Password cannot exceed 128 characters',
      'any.required': 'Password is required'
    })
  }),

  register: Joi.object({
    email: Joi.string().email().required(),
    password: Joi.string().min(8).max(128)
      .pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]/)
      .required()
      .messages({
        'string.pattern.base': 'Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character'
      }),
    name: Joi.string().min(2).max(50).required(),
    acceptTerms: Joi.boolean().valid(true).required().messages({
      'any.only': 'You must accept the terms and conditions'
    })
  }),

  // Chat schemas
  createChat: Joi.object({
    agentId: Joi.string().required(),
    title: Joi.string().min(1).max(100).required(),
    initialMessage: Joi.string().max(2000).optional()
  }),

  sendMessage: Joi.object({
    message: Joi.string().min(1).max(4000).required().messages({
      'string.min': 'Message cannot be empty',
      'string.max': 'Message cannot exceed 4000 characters'
    }),
    sessionId: Joi.string().required(),
    agentId: Joi.string().required()
  }),

  // User schemas
  updateProfile: Joi.object({
    name: Joi.string().min(2).max(50).optional(),
    email: Joi.string().email().optional(),
    preferences: Joi.object({
      theme: Joi.string().valid('light', 'dark', 'auto').optional(),
      language: Joi.string().min(2).max(5).optional(),
      notifications: Joi.boolean().optional()
    }).optional()
  }),

  // File upload schemas
  uploadFile: Joi.object({
    file: Joi.object({
      mimetype: Joi.string().valid('image/jpeg', 'image/png', 'image/gif', 'application/pdf').required(),
      size: Joi.number().max(10 * 1024 * 1024).required() // 10MB max
    }).required()
  }),

  // Subscription schemas
  createSubscription: Joi.object({
    planId: Joi.string().required(),
    paymentMethodId: Joi.string().required()
  }),

  // Contact form schemas
  contactForm: Joi.object({
    name: Joi.string().min(2).max(50).required(),
    email: Joi.string().email().required(),
    subject: Joi.string().min(5).max(100).required(),
    message: Joi.string().min(10).max(1000).required()
  })
};

// Validation middleware factory
const validateRequest = (schema, property = 'body') => {
  return (req, res, next) => {
    const { error } = schema.validate(req[property], { abortEarly: false });

    if (error) {
      const errors = error.details.map(detail => ({
        field: detail.path.join('.'),
        message: detail.message
      }));

      return res.status(400).json({
        success: false,
        error: 'Validation failed',
        details: errors
      });
    }

    next();
  };
};

// Sanitization middleware
const sanitizeInput = (req, res, next) => {
  // Recursively sanitize strings in request body
  const sanitize = (obj) => {
    if (typeof obj === 'string') {
      return obj.trim().replace(/[<>]/g, '');
    }
    if (Array.isArray(obj)) {
      return obj.map(sanitize);
    }
    if (obj && typeof obj === 'object') {
      const sanitized = {};
      for (const [key, value] of Object.entries(obj)) {
        sanitized[key] = sanitize(value);
      }
      return sanitized;
    }
    return obj;
  };

  if (req.body) {
    req.body = sanitize(req.body);
  }
  if (req.query) {
    req.query = sanitize(req.query);
  }

  next();
};

// Rate limiting configurations
const rateLimitConfigs = {
  // General API rate limiting
  general: {
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 500, // 500 requests per window
    message: {
      success: false,
      error: 'Too many requests',
      retryAfter: 900 // 15 minutes in seconds
    },
    standardHeaders: true,
    legacyHeaders: false
  },

  // Authentication endpoints
  auth: {
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 10, // 10 login attempts per window
    message: {
      success: false,
      error: 'Too many authentication attempts',
      retryAfter: 900
    }
  },

  // Chat endpoints (higher limit for active users)
  chat: {
    windowMs: 60 * 1000, // 1 minute
    max: 60, // 60 messages per minute
    message: {
      success: false,
      error: 'Too many messages',
      retryAfter: 60
    }
  },

  // File uploads
  uploads: {
    windowMs: 60 * 60 * 1000, // 1 hour
    max: 20, // 20 uploads per hour
    message: {
      success: false,
      error: 'Too many file uploads',
      retryAfter: 3600
    }
  },

  // API keys (for external integrations)
  apiKeys: {
    windowMs: 60 * 1000, // 1 minute
    max: 100, // 100 requests per minute
    message: {
      success: false,
      error: 'API rate limit exceeded',
      retryAfter: 60
    }
  }
};

module.exports = {
  validationSchemas,
  validateRequest,
  sanitizeInput,
  rateLimitConfigs
};