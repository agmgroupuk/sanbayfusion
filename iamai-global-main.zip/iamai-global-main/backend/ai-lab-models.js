const mongoose = require('mongoose');

// Toolbox Usage Analytics Schema
const toolboxUsageAnalyticsSchema = new mongoose.Schema(
  {
    userId: {
      type: String,
      required: true,
      index: true,
    },
    usage: {
      date: {
        type: Date,
        default: Date.now,
      },
      totalUsage: {
        type: Number,
        default: 0,
      },
      totalQueries: {
        type: Number,
        default: 0,
      },
      toolsUsed: [
        {
          type: String,
        },
      ],
      breakdown: {
        type: Map,
        of: Number,
        default: {},
      },
    },
  },
  {
    timestamps: true,
  }
);

// Toolbox Access Schema
const toolboxAccessSchema = new mongoose.Schema(
  {
    userId: {
      type: String,
      required: true,
      unique: true,
    },
    permissions: {
      maxToolUsagePerDay: {
        type: Number,
        default: 100,
      },
      maxToolUsagePerMonth: {
        type: Number,
        default: 1000,
      },
      allowedTools: [
        {
          type: String,
          default: ['dns', 'ping', 'whois', 'ssl', 'headers', 'ip-info'],
        },
      ],
      premiumTools: [
        {
          type: String,
          default: ['threat-intel', 'domain-research'],
        },
      ],
      canExportData: {
        type: Boolean,
        default: true,
      },
      canUseBulkOperations: {
        type: Boolean,
        default: false,
      },
      canAccessSecurityTools: {
        type: Boolean,
        default: true,
      },
      canAccessWebTools: {
        type: Boolean,
        default: true,
      },
      canAccessDevelopmentTools: {
        type: Boolean,
        default: true,
      },
      canAccessMonitoringTools: {
        type: Boolean,
        default: true,
      },
    },
    usage: {
      todayToolUsage: {
        type: Number,
        default: 0,
      },
      totalToolUsage: {
        type: Number,
        default: 0,
      },
      favoriteTools: [
        {
          type: String,
        },
      ],
      toolsUsed: [
        {
          type: String,
        },
      ],
      lastUsed: {
        type: Date,
        default: Date.now,
      },
    },
    subscription: {
      type: {
        type: String,
        enum: ['FREE', 'BASIC', 'PRO', 'ENTERPRISE'],
        default: 'FREE',
      },
      expiresAt: {
        type: Date,
        default: null,
      },
      isActive: {
        type: Boolean,
        default: true,
      },
    },
  },
  {
    timestamps: true,
  }
);

// AI Lab Access Schema (placeholder)
const aiLabAccessSchema = new mongoose.Schema(
  {
    userId: {
      type: String,
      required: true,
      unique: true,
    },
    subscriptionStatus: {
      subscriptionType: {
        type: String,
        enum: ['FREE', 'DAILY', 'WEEKLY', 'MONTHLY', 'ANNUAL'],
        default: 'FREE',
      },
      hasActiveSubscription: {
        type: Boolean,
        default: false,
      },
      expiresAt: {
        type: Date,
        default: null,
      },
    },
  },
  {
    timestamps: true,
  }
);

// AI Lab Experiment Schema
const aiLabExperimentSchema = new mongoose.Schema(
  {
    userId: {
      type: String,
      required: true,
      index: true,
    },
    experimentId: {
      type: String,
      required: true,
      unique: true,
    },
    experiment: {
      type: Object,
      required: true,
    },
    input: {
      type: Object,
      required: true,
    },
    results: {
      type: Array,
      default: [],
    },
    analysis: {
      type: Object,
      default: {},
    },
  },
  {
    timestamps: true,
  }
);

// Create models
const ToolboxAccess = mongoose.model('ToolboxAccess', toolboxAccessSchema);
const ToolboxUsageAnalytics = mongoose.model('ToolboxUsageAnalytics', toolboxUsageAnalyticsSchema);
const AILabAccess = mongoose.model('AILabAccess', aiLabAccessSchema);
const AILabExperiment = mongoose.model('AILabExperiment', aiLabExperimentSchema);

module.exports = {
  ToolboxAccess,
  ToolboxUsageAnalytics,
  AILabAccess,
  AILabExperiment,
};
