# Files to Clean - Subscription References

## Backend Files with Subscription Code:

1. ✅ agentx-api.js - CLEANED (4 references fixed)
2. ❌ universal-agent-api.js - 30+ references  
3. ❌ individual-agent-api.js - 40+ references
4. ❌ ai-lab-auth.js - 1 reference
5. ❌ routes/app-data.js - 1 reference

## Strategy:

Since universal-agent-api.js and individual-agent-api.js have 70+ combined references, 
and they're essentially doing the same thing (managing agent subscriptions),
we should:

**OPTION 1: Comment Out Entire Files** (Quick)
- Comment out these agent-specific APIs
- Redirect all requests to new /api/agents/:agentId/purchase
- Keep files for reference

**OPTION 2: Full Rewrite** (Time-consuming)
- Replace all 70+ references
- Risk breaking existing functionality
- 2-3 hours of work

**RECOMMENDATION:** Option 1 - Deprecate old agent APIs, use new unified purchase API
