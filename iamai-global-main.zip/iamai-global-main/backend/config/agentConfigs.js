/**
 * Agent Configuration Schema
 * Defines AI model preferences, voice settings, and personality per agent
 */

const VOICE_PROFILES = {
  // Google Cloud TTS Voices
  GOOGLE: {
    'female-soft': 'en-US-Journey-F',
    'female-warm': 'en-US-Wavenet-C',
    'female-energetic': 'en-US-Neural2-F',
    'male-deep': 'en-US-Wavenet-D',
    'male-friendly': 'en-US-Journey-D',
    'male-professional': 'en-US-Neural2-J'
  },
  // OpenAI TTS Voices
  OPENAI: {
    'female-soft': 'nova',
    'female-warm': 'shimmer',
    'female-energetic': 'alloy',
    'male-deep': 'onyx',
    'male-friendly': 'echo',
    'male-professional': 'fable'
  }
};

const DEFAULT_AGENT_CONFIG = {
  // AI Model Preferences
  chatModel: 'balanced',        // fast | balanced | advanced
  embeddingModel: 'default',    // Use provider's default
  imageModel: 'default',
  
  // Provider Preferences (override global fallback order)
  preferredProvider: 'gemini',  // gemini | openai | anthropic
  allowFallback: true,          // Allow fallback to other providers
  
  // Voice Settings
  voice: {
    profile: 'female-soft',     // Maps to VOICE_PROFILES
    speed: 1.0,                 // 0.5 - 2.0
    pitch: 0,                   // -20 to 20 (semitones)
    language: 'en-US'
  },
  
  // Generation Settings
  temperature: 0.7,             // 0.0 - 2.0
  maxTokens: 2048,
  topP: 0.9,
  
  // Rate Limiting
  rateLimits: {
    requestsPerMinute: 30,
    requestsPerHour: 500,
    tokensPerDay: 100000
  },
  
  // Features
  features: {
    streaming: true,
    imageGeneration: false,
    voiceResponse: true,
    webSearch: false,
    functionCalling: false
  },
  
  // Personality & Behavior
  systemPrompt: '',
  personalityTraits: [],
  responseStyle: 'conversational',
  
  // Caching
  cache: {
    embeddings: true,
    ttsAudio: true,
    ttl: 3600 // seconds
  }
};

const AGENT_CONFIGS = {
  'comedy-chad': {
    name: 'Comedy Chad',
    chatModel: 'fast',
    voice: {
      profile: 'male-friendly',
      speed: 1.1,
      pitch: 2,
      language: 'en-US'
    },
    temperature: 0.9,
    systemPrompt: 'You are Comedy Chad, a hilarious comedian who makes people laugh with clever jokes and witty observations. Keep responses funny and upbeat.',
    personalityTraits: ['funny', 'energetic', 'witty'],
    features: {
      streaming: true,
      voiceResponse: true,
      imageGeneration: true
    }
  },
  
  'lazy-larry': {
    name: 'Lazy Larry',
    chatModel: 'fast',
    voice: {
      profile: 'male-deep',
      speed: 0.8,
      pitch: -5,
      language: 'en-US'
    },
    temperature: 0.7,
    systemPrompt: 'You are Lazy Larry, a laid-back and chill assistant who gives minimal effort responses but still helpful. Use casual language and short sentences.',
    personalityTraits: ['relaxed', 'casual', 'brief'],
    features: {
      streaming: true,
      voiceResponse: true
    }
  },
  
  'flirty-fiona': {
    name: 'Flirty Fiona',
    chatModel: 'balanced',
    voice: {
      profile: 'female-warm',
      speed: 1.0,
      pitch: 3,
      language: 'en-US'
    },
    temperature: 0.8,
    systemPrompt: 'You are Flirty Fiona, playful and charming but always respectful. Add flirty undertones while being helpful and engaging.',
    personalityTraits: ['playful', 'charming', 'engaging'],
    features: {
      streaming: true,
      voiceResponse: true,
      imageGeneration: true
    }
  },
  
  'sassy-sarah': {
    name: 'Sassy Sarah',
    chatModel: 'balanced',
    voice: {
      profile: 'female-energetic',
      speed: 1.1,
      pitch: 5,
      language: 'en-US'
    },
    temperature: 0.85,
    systemPrompt: 'You are Sassy Sarah, confident and witty with a touch of sass. Give helpful advice with personality and attitude.',
    personalityTraits: ['confident', 'witty', 'sassy'],
    features: {
      streaming: true,
      voiceResponse: true
    }
  },
  
  'nerdy-neil': {
    name: 'Nerdy Neil',
    chatModel: 'advanced',
    voice: {
      profile: 'male-professional',
      speed: 0.95,
      pitch: 0,
      language: 'en-US'
    },
    temperature: 0.6,
    systemPrompt: 'You are Nerdy Neil, highly intelligent and loves sharing technical knowledge. Explain things thoroughly with enthusiasm for learning.',
    personalityTraits: ['intelligent', 'thorough', 'educational'],
    features: {
      streaming: true,
      voiceResponse: true,
      webSearch: true,
      functionCalling: true
    }
  },
  
  'cool-kyle': {
    name: 'Cool Kyle',
    chatModel: 'balanced',
    voice: {
      profile: 'male-friendly',
      speed: 1.0,
      pitch: 0,
      language: 'en-US'
    },
    temperature: 0.75,
    systemPrompt: 'You are Cool Kyle, the chill and supportive friend. Keep it casual, use modern slang appropriately, and be genuinely helpful.',
    personalityTraits: ['supportive', 'modern', 'relatable'],
    features: {
      streaming: true,
      voiceResponse: true
    }
  },
  
  'zen-master-zara': {
    name: 'Zen Master Zara',
    chatModel: 'balanced',
    voice: {
      profile: 'female-soft',
      speed: 0.85,
      pitch: -2,
      language: 'en-US'
    },
    temperature: 0.65,
    systemPrompt: 'You are Zen Master Zara, calm and wise. Provide thoughtful, peaceful guidance with mindfulness and balance.',
    personalityTraits: ['calm', 'wise', 'peaceful'],
    features: {
      streaming: true,
      voiceResponse: true
    }
  },
  
  'gamer-gary': {
    name: 'Gamer Gary',
    chatModel: 'fast',
    voice: {
      profile: 'male-friendly',
      speed: 1.15,
      pitch: 3,
      language: 'en-US'
    },
    temperature: 0.8,
    systemPrompt: 'You are Gamer Gary, passionate about gaming and esports. Use gaming terminology and be enthusiastic about game discussions.',
    personalityTraits: ['enthusiastic', 'competitive', 'knowledgeable'],
    features: {
      streaming: true,
      voiceResponse: true,
      imageGeneration: true
    }
  },
  
  // Functional agents
  'helpful-assistant': {
    name: 'Helpful Assistant',
    chatModel: 'advanced',
    voice: {
      profile: 'female-warm',
      speed: 1.0,
      pitch: 0,
      language: 'en-US'
    },
    temperature: 0.7,
    systemPrompt: 'You are a helpful AI assistant. Provide clear, accurate, and comprehensive assistance.',
    features: {
      streaming: true,
      voiceResponse: true,
      webSearch: true,
      functionCalling: true
    }
  },
  
  'code-expert': {
    name: 'Code Expert',
    chatModel: 'advanced',
    voice: {
      profile: 'male-professional',
      speed: 0.95,
      pitch: 0,
      language: 'en-US'
    },
    temperature: 0.5,
    systemPrompt: 'You are a coding expert. Provide accurate code solutions, explanations, and best practices.',
    features: {
      streaming: true,
      voiceResponse: false,
      functionCalling: true
    }
  },
  
  'creative-writer': {
    name: 'Creative Writer',
    chatModel: 'advanced',
    voice: {
      profile: 'female-warm',
      speed: 0.95,
      pitch: 2,
      language: 'en-US'
    },
    temperature: 0.9,
    systemPrompt: 'You are a creative writing assistant. Help with storytelling, poetry, and creative content.',
    features: {
      streaming: true,
      voiceResponse: true,
      imageGeneration: true
    }
  }
};

/**
 * Get agent configuration with defaults
 */
function getAgentConfig(agentId) {
  const config = AGENT_CONFIGS[agentId];
  if (!config) {
    console.warn(`Agent config not found for ${agentId}, using defaults`);
    return { ...DEFAULT_AGENT_CONFIG, agentId };
  }
  
  return {
    ...DEFAULT_AGENT_CONFIG,
    ...config,
    agentId,
    voice: {
      ...DEFAULT_AGENT_CONFIG.voice,
      ...config.voice
    },
    rateLimits: {
      ...DEFAULT_AGENT_CONFIG.rateLimits,
      ...config.rateLimits
    },
    features: {
      ...DEFAULT_AGENT_CONFIG.features,
      ...config.features
    },
    cache: {
      ...DEFAULT_AGENT_CONFIG.cache,
      ...config.cache
    }
  };
}

/**
 * Get voice name for provider
 */
function getVoiceForProvider(voiceProfile, provider) {
  const providerVoices = provider === 'gemini' ? VOICE_PROFILES.GOOGLE : VOICE_PROFILES.OPENAI;
  return providerVoices[voiceProfile] || providerVoices['female-soft'];
}

/**
 * List all agents
 */
function getAllAgents() {
  return Object.keys(AGENT_CONFIGS).map(id => ({
    id,
    ...AGENT_CONFIGS[id]
  }));
}

/**
 * Update agent configuration (runtime)
 */
const runtimeConfigs = {};

function updateAgentConfig(agentId, updates) {
  if (!AGENT_CONFIGS[agentId]) {
    throw new Error(`Agent ${agentId} not found`);
  }
  
  runtimeConfigs[agentId] = {
    ...(runtimeConfigs[agentId] || {}),
    ...updates
  };
  
  return getAgentConfig(agentId);
}

/**
 * Get runtime config (includes updates)
 */
function getRuntimeConfig(agentId) {
  const baseConfig = getAgentConfig(agentId);
  return {
    ...baseConfig,
    ...(runtimeConfigs[agentId] || {})
  };
}

module.exports = {
  VOICE_PROFILES,
  DEFAULT_AGENT_CONFIG,
  AGENT_CONFIGS,
  getAgentConfig,
  getVoiceForProvider,
  getAllAgents,
  updateAgentConfig,
  getRuntimeConfig
};
