// Environment Configuration Validator
// Ensures all required environment variables are present and secure

const requiredEnvVars = {
  // Application
  NODE_ENV: { required: true, values: ['development', 'production', 'test'] },
  PORT: { required: true, type: 'number' },
  API_URL: { required: true, type: 'url' },

  // Security
  JWT_SECRET: { required: true, minLength: 32 },
  NEXTAUTH_SECRET: { required: true, minLength: 32 },

  // Database
  MONGODB_URI: { required: true, type: 'url' },

  // Payment (Production)
  STRIPE_SECRET_KEY: { required: process.env.NODE_ENV === 'production', secure: true },
  STRIPE_PUBLISHABLE_KEY: { required: process.env.NODE_ENV === 'production' },

  // AI Providers (At least one required)
  OPENAI_API_KEY: { required: false, secure: true },
  ANTHROPIC_API_KEY: { required: false, secure: true },
  GEMINI_API_KEY: { required: false, secure: true },
};

class EnvironmentValidator {
  constructor() {
    this.errors = [];
    this.warnings = [];
  }

  validate() {
    console.log('🔍 Validating environment configuration...');

    // Check for required variables
    for (const [key, config] of Object.entries(requiredEnvVars)) {
      const value = process.env[key];

      if (config.required && !value) {
        this.errors.push(`Missing required environment variable: ${key}`);
        continue;
      }

      if (!value) continue;

      // Type validation
      if (config.type === 'number' && isNaN(Number(value))) {
        this.errors.push(`${key} must be a valid number`);
      }

      if (config.type === 'url' && !this.isValidUrl(value)) {
        this.errors.push(`${key} must be a valid URL`);
      }

      // Length validation
      if (config.minLength && value.length < config.minLength) {
        this.errors.push(`${key} must be at least ${config.minLength} characters long`);
      }

      // Security validation
      if (config.secure && this.isInsecureValue(value)) {
        this.errors.push(`${key} appears to be using a default or insecure value`);
      }
    }

    // Check for AI provider availability
    const aiProviders = ['OPENAI_API_KEY', 'ANTHROPIC_API_KEY', 'GEMINI_API_KEY'];
    const hasAiProvider = aiProviders.some(key => process.env[key]);

    if (!hasAiProvider) {
      this.warnings.push('No AI provider configured. At least one is recommended.');
    }

    // Report results
    if (this.errors.length > 0) {
      console.error('❌ Environment validation failed:');
      this.errors.forEach(error => console.error(`  - ${error}`));
      throw new Error('Environment validation failed');
    }

    if (this.warnings.length > 0) {
      console.warn('⚠️  Environment warnings:');
      this.warnings.forEach(warning => console.warn(`  - ${warning}`));
    }

    console.log('✅ Environment validation passed');
    return true;
  }

  isValidUrl(string) {
    try {
      new URL(string);
      return true;
    } catch {
      return false;
    }
  }

  isInsecureValue(value) {
    const insecurePatterns = [
      'your-secret-key-change-this',
      'dummy',
      'test',
      'example',
      'placeholder',
      '123456',
    ];

    return insecurePatterns.some(pattern => value.toLowerCase().includes(pattern.toLowerCase()));
  }
}

// Auto-validate on import (except in test environments)
// In production we log failures but do not hard-exit, to avoid
// taking down the entire API if some non-critical env is missing.
if (process.env.NODE_ENV !== 'test') {
  try {
    new EnvironmentValidator().validate();
  } catch (error) {
    console.error('Environment validation failed:', error.message);

    // Only exit when explicit strict mode is enabled
    if (
      process.env.NODE_ENV === 'production' &&
      process.env.STRICT_ENV_VALIDATION === 'true'
    ) {
      process.exit(1);
    }
  }
}

module.exports = { EnvironmentValidator };
