/**
 * ============================================
 * IAMAI-GLOBAL COMPLETE DATA FLOW MAP
 * ============================================
 * 
 * PROFESSIONAL TRACKING SYSTEM
 * Every page, every click, every action → Database
 * 
 * Created: December 29, 2025
 * ============================================
 */

// ============================================
// MASTER DATA FLOW CONFIGURATION
// ============================================

const IAMAI_DATA_FLOW = {
  
  // ============================================
  // SECTION 1: VISITOR JOURNEY (Anonymous Users)
  // ============================================
  VISITOR_JOURNEY: {
    // First Touch
    SITE_ENTRY: {
      trigger: 'User lands on any page',
      collection: 'visitors',
      action: 'CREATE',
      data: {
        sessionId: 'Generated UUID',
        visitorId: 'Fingerprint or cookie ID',
        firstVisit: 'Date.now()',
        landingPage: 'Current URL',
        referrer: 'document.referrer',
        'device.type': 'desktop/mobile/tablet',
        'device.browser': 'Chrome/Safari/Firefox',
        'device.os': 'Windows/macOS/iOS/Android',
        'device.screenResolution': '1920x1080',
        'location.country': 'From IP lookup',
        'location.city': 'From IP lookup',
        'campaign.source': 'UTM source',
        'campaign.medium': 'UTM medium',
        'campaign.campaign': 'UTM campaign',
      },
      relatedLogs: ['activity_logs'],
    },
    
    // Page Navigation
    PAGE_VIEW: {
      trigger: 'Every page change',
      collection: 'visitors',
      action: 'UPDATE (push to pageViews array)',
      data: {
        'pageViews[]': {
          path: '/current-page',
          timestamp: 'Date.now()',
          duration: 'Time on previous page',
          scrollDepth: 'Max scroll percentage',
        },
        totalPageViews: 'Increment +1',
        lastVisit: 'Date.now()',
      },
      relatedLogs: ['activity_logs'],
    },
    
    // Exit
    SESSION_END: {
      trigger: 'Tab close / navigate away',
      collection: 'visitors',
      action: 'UPDATE',
      data: {
        exitPage: 'Last page URL',
        sessionDuration: 'Total time in seconds',
        bounced: 'true if only 1 pageview',
      },
    },
  },
  
  // ============================================
  // SECTION 2: AUTHENTICATION FLOW
  // ============================================
  AUTHENTICATION: {
    // Registration
    USER_REGISTER: {
      trigger: 'User clicks "Sign Up" submit',
      collection: 'users',
      action: 'CREATE',
      requiredData: {
        email: 'User email',
        password: 'Hashed password',
        name: 'Full name',
        createdAt: 'Date.now()',
        isVerified: false,
        isActive: true,
        role: 'user',
        tier: 'free',
        'preferences.theme': 'dark',
        'preferences.language': 'en',
        'statistics.totalMessages': 0,
        'statistics.totalSessions': 0,
      },
      relatedCollections: {
        notification_settings: {
          action: 'CREATE',
          data: {
            userId: 'New user ID',
            'email.enabled': true,
            'email.marketing': true,
            'push.enabled': true,
            'inApp.enabled': true,
          },
        },
        activity_logs: {
          action: 'CREATE',
          data: {
            action: 'REGISTER',
            category: 'auth',
            result: 'success',
          },
        },
        visitors: {
          action: 'UPDATE',
          data: {
            userId: 'Link visitor to new user',
            isConverted: true,
            conversionDate: 'Date.now()',
          },
        },
      },
      endpoint: 'POST /api/auth/register',
      frontendFile: 'components/SignupPage.tsx',
    },
    
    // Login
    USER_LOGIN: {
      trigger: 'User clicks "Login" submit',
      collection: 'users',
      action: 'UPDATE',
      updatedData: {
        'security.lastLoginAt': 'Date.now()',
        'security.lastLoginIP': 'Client IP',
        'security.activeSessions[]': {
          sessionId: 'New session UUID',
          device: 'Device info',
          location: 'IP location',
          createdAt: 'Date.now()',
          lastActivity: 'Date.now()',
        },
        'security.failedLoginAttempts': 'Reset to 0 on success',
      },
      relatedCollections: {
        activity_logs: {
          action: 'CREATE',
          data: {
            action: 'LOGIN',
            category: 'auth',
            result: 'success/failure',
            details: {
              method: 'password/2fa/oauth',
              device: 'Device info',
              location: 'IP location',
            },
          },
        },
        visitors: {
          action: 'UPDATE',
          data: { userId: 'Link session to user' },
        },
      },
      endpoint: 'POST /api/auth/login',
      frontendFile: 'components/LoginPage.tsx',
    },
    
    // Failed Login
    LOGIN_FAILED: {
      trigger: 'Invalid credentials',
      collection: 'users',
      action: 'UPDATE',
      updatedData: {
        'security.failedLoginAttempts': 'Increment +1',
        'security.lastFailedLogin': 'Date.now()',
      },
      relatedCollections: {
        activity_logs: {
          action: 'CREATE',
          data: {
            action: 'LOGIN_FAILED',
            category: 'security',
            result: 'failure',
            severity: 'medium',
          },
        },
        security_logs: {
          action: 'CREATE',
          data: {
            event: 'FAILED_LOGIN',
            ipAddress: 'Client IP',
            attempts: 'Current count',
          },
        },
      },
    },
    
    // Logout
    USER_LOGOUT: {
      trigger: 'User clicks "Logout"',
      collection: 'users',
      action: 'UPDATE',
      updatedData: {
        'security.activeSessions': 'Remove current session',
      },
      relatedCollections: {
        activity_logs: {
          action: 'CREATE',
          data: {
            action: 'LOGOUT',
            category: 'auth',
          },
        },
      },
      endpoint: 'POST /api/auth/logout',
    },
    
    // Password Reset Request
    PASSWORD_RESET_REQUEST: {
      trigger: 'User submits forgot password form',
      collection: 'users',
      action: 'UPDATE',
      updatedData: {
        'security.passwordResetToken': 'Generated token',
        'security.passwordResetExpires': 'Date.now() + 1 hour',
      },
      relatedCollections: {
        activity_logs: {
          action: 'CREATE',
          data: {
            action: 'PASSWORD_RESET_REQUEST',
            category: 'security',
          },
        },
      },
      endpoint: 'POST /api/auth/forgot-password',
      frontendFile: 'components/pages/ForgotPasswordPage.tsx',
    },
    
    // Password Change
    PASSWORD_CHANGE: {
      trigger: 'User changes password in settings',
      collection: 'users',
      action: 'UPDATE',
      updatedData: {
        password: 'New hashed password',
        'security.lastPasswordChange': 'Date.now()',
        'security.activeSessions': 'Clear all except current',
      },
      relatedCollections: {
        activity_logs: {
          action: 'CREATE',
          data: {
            action: 'PASSWORD_CHANGE',
            category: 'security',
            severity: 'high',
          },
        },
        security_logs: {
          action: 'CREATE',
          data: {
            event: 'PASSWORD_CHANGED',
            ipAddress: 'Client IP',
          },
        },
      },
      endpoint: 'POST /api/users/security/password',
      frontendFile: 'components/settings/SecuritySettings.tsx',
    },
    
    // Email Change
    EMAIL_CHANGE: {
      trigger: 'User requests email change',
      collection: 'users',
      action: 'UPDATE',
      updatedData: {
        'security.emailChangeRequest': {
          newEmail: 'New email',
          token: 'Verification token',
          requestedAt: 'Date.now()',
          expiresAt: 'Date.now() + 24 hours',
        },
      },
      relatedCollections: {
        activity_logs: {
          action: 'CREATE',
          data: {
            action: 'EMAIL_CHANGE_REQUEST',
            category: 'security',
          },
        },
      },
      endpoint: 'POST /api/users/security/email',
    },
    
    // 2FA Setup
    '2FA_ENABLE': {
      trigger: 'User enables 2FA',
      collection: 'users',
      action: 'UPDATE',
      updatedData: {
        'security.twoFactorEnabled': true,
        'security.twoFactorSecret': 'Encrypted secret',
        'security.backupCodes': ['Array of 10 backup codes'],
      },
      relatedCollections: {
        activity_logs: {
          action: 'CREATE',
          data: {
            action: '2FA_ENABLED',
            category: 'security',
            severity: 'high',
          },
        },
        security_logs: {
          action: 'CREATE',
          data: {
            event: '2FA_ENABLED',
          },
        },
      },
      endpoint: 'POST /api/users/security/2fa/enable',
    },
    
    // 2FA Disable
    '2FA_DISABLE': {
      trigger: 'User disables 2FA',
      collection: 'users',
      action: 'UPDATE',
      updatedData: {
        'security.twoFactorEnabled': false,
        'security.twoFactorSecret': null,
        'security.backupCodes': [],
      },
      relatedCollections: {
        activity_logs: {
          action: 'CREATE',
          data: {
            action: '2FA_DISABLED',
            category: 'security',
            severity: 'high',
          },
        },
      },
      endpoint: 'POST /api/users/security/2fa/disable',
    },
  },
  
  // ============================================
  // SECTION 3: AGENT PURCHASE FLOW (CRITICAL!)
  // ============================================
  AGENT_PURCHASES: {
    // View Agent Page
    AGENT_PAGE_VIEW: {
      trigger: 'User views agent detail page',
      collection: 'activity_logs',
      action: 'CREATE',
      data: {
        action: 'AGENT_VIEW',
        category: 'agent',
        resource: 'agent:{agentId}',
        details: {
          agentId: 'Agent ID',
          agentName: 'Agent name',
          fromPage: 'Previous page',
        },
      },
      relatedUpdates: {
        agents: {
          field: 'stats.viewCount',
          action: 'INCREMENT',
        },
      },
    },
    
    // Click Purchase Button
    PURCHASE_INITIATED: {
      trigger: 'User clicks "Buy Now" on any plan',
      collection: 'agent_purchases',
      action: 'CREATE',
      requiredData: {
        userId: 'User ID',
        email: 'User email',
        agentId: 'Agent ID (lowercase)',
        agentName: 'Agent display name',
        plan: 'DAILY/WEEKLY/MONTHLY',
        planName: 'Daily/Weekly/Monthly',
        'pricing.amount': '1/5/19',
        'pricing.currency': 'USD',
        status: 'PENDING',
        paymentStatus: 'PENDING',
        purchaseDate: 'Date.now()',
        expiresAt: 'Calculated based on plan',
        stripeCheckoutSessionId: 'Stripe session ID',
        paymentMethod: 'CARD',
        metadata: {
          source: 'checkout_initiated',
          userAgent: 'Browser info',
          ipAddress: 'Client IP',
        },
      },
      relatedCollections: {
        activity_logs: {
          action: 'CREATE',
          data: {
            action: 'PURCHASE_INITIATED',
            category: 'subscription',
            details: {
              agentId: 'Agent ID',
              plan: 'Plan type',
              amount: 'Price',
            },
          },
        },
      },
      endpoint: 'POST /api/agents/:agentId/purchase',
      frontendFile: 'components/modals/PurchaseModal.tsx',
    },
    
    // Stripe Webhook - Payment Success
    PURCHASE_COMPLETED: {
      trigger: 'Stripe webhook: checkout.session.completed',
      collection: 'agent_purchases',
      action: 'UPDATE (find by stripeCheckoutSessionId)',
      updatedData: {
        status: 'ACTIVE',
        paymentStatus: 'SUCCESS',
        stripePaymentIntentId: 'From webhook',
        stripeCustomerId: 'From webhook',
        'metadata.completedAt': 'Date.now()',
        'metadata.webhookEventId': 'Stripe event ID',
      },
      relatedCollections: {
        transactions: {
          action: 'CREATE',
          data: {
            userId: 'User ID',
            type: 'PURCHASE',
            amount: 'Plan price',
            currency: 'USD',
            status: 'completed',
            stripePaymentIntentId: 'From webhook',
            agentId: 'Agent ID',
            description: 'Agent purchase: {agentName} - {plan}',
          },
        },
        webhook_events: {
          action: 'CREATE',
          data: {
            source: 'stripe',
            eventType: 'checkout.session.completed',
            eventId: 'Stripe event ID',
            payload: 'Full webhook payload',
            status: 'processed',
            processedAt: 'Date.now()',
          },
        },
        activity_logs: {
          action: 'CREATE',
          data: {
            action: 'PURCHASE_COMPLETED',
            category: 'subscription',
            result: 'success',
          },
        },
        agents: {
          action: 'UPDATE',
          updates: {
            'stats.totalUsers': 'INCREMENT +1',
            'stats.totalRevenue': 'INCREMENT +amount',
          },
        },
        users: {
          action: 'UPDATE',
          updates: {
            'statistics.totalPurchases': 'INCREMENT +1',
            'statistics.totalSpent': 'INCREMENT +amount',
          },
        },
      },
      endpoint: 'POST /api/webhooks/stripe',
      backendFile: 'backend/routes/webhooks.js',
    },
    
    // Access Check
    ACCESS_CHECK: {
      trigger: 'Every time user tries to chat with agent',
      collection: 'agent_purchases',
      action: 'READ',
      query: {
        userId: 'Current user ID',
        agentId: 'Agent being accessed',
        status: { $in: ['ACTIVE', 'active'] },
        $or: [
          { expiresAt: { $gt: 'new Date()' } },
          { expirationDate: { $gt: 'new Date()' } },
        ],
      },
      response: 'Boolean: hasAccess',
      endpoint: 'GET /api/agents/:agentId/access',
    },
    
    // Purchase Cancel
    PURCHASE_CANCELLED: {
      trigger: 'User cancels active purchase',
      collection: 'agent_purchases',
      action: 'UPDATE',
      updatedData: {
        status: 'CANCELLED',
        cancelledAt: 'Date.now()',
        cancelReason: 'User provided reason',
      },
      relatedCollections: {
        activity_logs: {
          action: 'CREATE',
          data: {
            action: 'PURCHASE_CANCELLED',
            category: 'subscription',
          },
        },
      },
      endpoint: 'POST /api/agents/:agentId/cancel',
    },
    
    // Purchase Expire (Cron Job)
    PURCHASE_EXPIRED: {
      trigger: 'Cron job or on-access check',
      collection: 'agent_purchases',
      action: 'UPDATE (bulk)',
      query: {
        status: { $in: ['ACTIVE', 'active'] },
        $or: [
          { expiresAt: { $lte: 'new Date()' } },
          { expirationDate: { $lte: 'new Date()' } },
        ],
      },
      updatedData: {
        status: 'EXPIRED',
      },
    },
  },
  
  // ============================================
  // SECTION 4: CHAT & CONVERSATIONS
  // ============================================
  CHAT_SYSTEM: {
    // Start New Chat
    CHAT_START: {
      trigger: 'User opens chat with agent',
      collection: 'chats',
      action: 'CREATE or FIND existing',
      requiredData: {
        participants: ['userId'],
        agentType: 'Agent ID',
        title: 'Chat with {agentName}',
        isActive: true,
        createdAt: 'Date.now()',
        lastMessageAt: 'Date.now()',
        messages: [],
      },
      relatedCollections: {
        individual_agent_sessions: {
          action: 'CREATE',
          data: {
            userId: 'User ID',
            agentId: 'Agent ID',
            sessionToken: 'Generated UUID',
            isActive: true,
            messageCount: 0,
            tokensUsed: 0,
            startedAt: 'Date.now()',
            lastActivityAt: 'Date.now()',
          },
        },
        activity_logs: {
          action: 'CREATE',
          data: {
            action: 'CHAT_START',
            category: 'agent',
            resource: 'agent:{agentId}',
          },
        },
        agent_purchases: {
          action: 'UPDATE',
          updates: {
            'currentUsage.lastMessageAt': 'Date.now()',
          },
        },
      },
      endpoint: 'POST /api/chat/start',
      frontendFile: 'components/universal-chat/UniversalAgentChat.tsx',
    },
    
    // Send Message
    MESSAGE_SEND: {
      trigger: 'User sends message',
      collection: 'chats',
      action: 'UPDATE (push to messages)',
      updatedData: {
        'messages[]': {
          id: 'Generated UUID',
          sender: 'user',
          content: 'Message text',
          timestamp: 'Date.now()',
          type: 'text/image/file',
        },
        lastMessageAt: 'Date.now()',
      },
      relatedCollections: {
        individual_agent_chat_histories: {
          action: 'UPDATE (push)',
          data: {
            'messages[]': {
              role: 'user',
              content: 'Message text',
              timestamp: 'Date.now()',
              tokens: 'Token count',
            },
            totalMessages: 'INCREMENT +1',
            totalTokens: 'INCREMENT +tokens',
          },
        },
        individual_agent_sessions: {
          action: 'UPDATE',
          updates: {
            messageCount: 'INCREMENT +1',
            lastActivityAt: 'Date.now()',
          },
        },
        agent_purchases: {
          action: 'UPDATE',
          updates: {
            'currentUsage.messagesUsed': 'INCREMENT +1',
            'currentUsage.lastMessageAt': 'Date.now()',
          },
        },
        activity_logs: {
          action: 'CREATE',
          data: {
            action: 'MESSAGE_SENT',
            category: 'agent',
          },
        },
        users: {
          action: 'UPDATE',
          updates: {
            'statistics.totalMessages': 'INCREMENT +1',
          },
        },
        agents: {
          action: 'UPDATE',
          updates: {
            'stats.totalMessages': 'INCREMENT +1',
          },
        },
      },
      endpoint: 'POST /api/chat/message',
    },
    
    // Receive AI Response
    MESSAGE_RECEIVE: {
      trigger: 'AI generates response',
      collection: 'chats',
      action: 'UPDATE (push to messages)',
      updatedData: {
        'messages[]': {
          id: 'Generated UUID',
          sender: 'assistant',
          content: 'AI response text',
          timestamp: 'Date.now()',
          type: 'text',
          metadata: {
            model: 'gemini/openai/anthropic',
            tokens: 'Token count',
            latency: 'Response time ms',
          },
        },
        lastMessageAt: 'Date.now()',
      },
      relatedCollections: {
        individual_agent_chat_histories: {
          action: 'UPDATE (push)',
          data: {
            'messages[]': {
              role: 'assistant',
              content: 'AI response',
              timestamp: 'Date.now()',
              tokens: 'Token count',
            },
          },
        },
        individual_agent_sessions: {
          action: 'UPDATE',
          updates: {
            tokensUsed: 'INCREMENT +tokens',
          },
        },
      },
    },
    
    // Load Chat History
    CHAT_HISTORY_LOAD: {
      trigger: 'User opens existing chat',
      collection: 'chats',
      action: 'READ',
      query: {
        participants: 'userId',
        agentType: 'agentId',
      },
      endpoint: 'GET /api/chat/history/:agentId',
    },
    
    // End Chat Session
    CHAT_END: {
      trigger: 'User closes chat / navigates away',
      collection: 'individual_agent_sessions',
      action: 'UPDATE',
      updatedData: {
        isActive: false,
        endedAt: 'Date.now()',
      },
      relatedCollections: {
        activity_logs: {
          action: 'CREATE',
          data: {
            action: 'CHAT_END',
            category: 'agent',
            details: {
              duration: 'Session duration',
              messagesCount: 'Total messages',
            },
          },
        },
      },
    },
  },
  
  // ============================================
  // SECTION 5: USER DASHBOARD
  // ============================================
  DASHBOARD: {
    // View Dashboard
    DASHBOARD_VIEW: {
      trigger: 'User navigates to /dashboard',
      collection: 'activity_logs',
      action: 'CREATE',
      data: {
        action: 'DASHBOARD_VIEW',
        category: 'profile',
      },
      dataFetched: {
        users: 'User profile data',
        agent_purchases: 'Active subscriptions',
        chats: 'Recent conversations',
        transactions: 'Recent billing',
        activity_logs: 'Recent activity',
      },
    },
    
    // Profile Update
    PROFILE_UPDATE: {
      trigger: 'User saves profile changes',
      collection: 'users',
      action: 'UPDATE',
      updatedData: {
        name: 'Updated name',
        username: 'Updated username',
        bio: 'Updated bio',
        'profile.website': 'Website URL',
        'profile.social': 'Social links',
        updatedAt: 'Date.now()',
      },
      relatedCollections: {
        activity_logs: {
          action: 'CREATE',
          data: {
            action: 'PROFILE_UPDATE',
            category: 'profile',
          },
        },
      },
      endpoint: 'PUT /api/users/profile',
      frontendFile: 'components/user/dashboard/ProfileSection.tsx',
    },
    
    // Avatar Upload
    AVATAR_UPLOAD: {
      trigger: 'User uploads new avatar',
      collection: 'users',
      action: 'UPDATE',
      updatedData: {
        avatar: 'S3 URL or base64',
      },
      relatedCollections: {
        file_uploads: {
          action: 'CREATE',
          data: {
            userId: 'User ID',
            filename: 'avatar_{userId}.png',
            originalName: 'Original filename',
            mimeType: 'image/png',
            size: 'File size bytes',
            storageProvider: 's3/local',
            storageKey: 'S3 key',
            url: 'Public URL',
            context: 'avatar',
          },
        },
        activity_logs: {
          action: 'CREATE',
          data: {
            action: 'AVATAR_UPLOAD',
            category: 'profile',
          },
        },
      },
      endpoint: 'POST /api/users/avatar',
    },
    
    // Preferences Update
    PREFERENCES_UPDATE: {
      trigger: 'User changes theme/language/timezone',
      collection: 'users',
      action: 'UPDATE',
      updatedData: {
        'preferences.theme': 'dark/light/system',
        'preferences.language': 'en/es/fr/...',
        'preferences.timezone': 'America/New_York',
      },
      relatedCollections: {
        activity_logs: {
          action: 'CREATE',
          data: {
            action: 'PREFERENCES_UPDATE',
            category: 'profile',
          },
        },
      },
      endpoint: 'PUT /api/users/preferences',
    },
    
    // Notification Settings
    NOTIFICATION_SETTINGS_UPDATE: {
      trigger: 'User toggles notification preferences',
      collection: 'notification_settings',
      action: 'UPDATE or UPSERT',
      updatedData: {
        userId: 'User ID',
        'email.enabled': true,
        'email.marketing': false,
        'email.productUpdates': true,
        'email.securityAlerts': true,
        'push.enabled': true,
        'push.newMessages': true,
        'sms.enabled': false,
        'inApp.enabled': true,
      },
      endpoint: 'PUT /api/notifications/settings',
    },
  },
  
  // ============================================
  // SECTION 6: BILLING & TRANSACTIONS
  // ============================================
  BILLING: {
    // View Billing History
    BILLING_VIEW: {
      trigger: 'User opens billing page',
      collection: 'transactions',
      action: 'READ',
      query: {
        userId: 'Current user ID',
      },
      sortBy: { createdAt: -1 },
      endpoint: 'GET /api/billing/history',
      frontendFile: 'components/settings/BillingSettings.tsx',
    },
    
    // View Invoice Detail
    INVOICE_VIEW: {
      trigger: 'User clicks on invoice',
      collection: 'transactions',
      action: 'READ',
      query: {
        _id: 'Invoice ID',
        userId: 'Current user ID',
      },
      relatedCollections: {
        activity_logs: {
          action: 'CREATE',
          data: {
            action: 'INVOICE_VIEW',
            category: 'subscription',
          },
        },
      },
    },
    
    // Download Invoice
    INVOICE_DOWNLOAD: {
      trigger: 'User downloads invoice PDF',
      collection: 'activity_logs',
      action: 'CREATE',
      data: {
        action: 'INVOICE_DOWNLOAD',
        category: 'subscription',
        resource: 'invoice:{invoiceId}',
      },
    },
  },
  
  // ============================================
  // SECTION 7: SUPPORT SYSTEM
  // ============================================
  SUPPORT: {
    // Create Ticket
    TICKET_CREATE: {
      trigger: 'User submits support ticket',
      collection: 'support_tickets',
      action: 'CREATE',
      requiredData: {
        userId: 'User ID',
        subject: 'Ticket subject',
        description: 'Ticket description',
        category: 'general/billing/technical/bug_report',
        priority: 'low/medium/high/urgent',
        status: 'open',
        createdAt: 'Date.now()',
        responses: [],
        attachments: [],
      },
      relatedCollections: {
        activity_logs: {
          action: 'CREATE',
          data: {
            action: 'TICKET_CREATE',
            category: 'system',
          },
        },
      },
      endpoint: 'POST /api/support/tickets',
      frontendFile: 'components/pages/SupportTicketPage.tsx',
    },
    
    // Reply to Ticket
    TICKET_REPLY: {
      trigger: 'User or admin replies',
      collection: 'support_tickets',
      action: 'UPDATE (push to responses)',
      updatedData: {
        'responses[]': {
          responder: 'User/Admin ID',
          responderRole: 'user/support/admin',
          message: 'Reply message',
          createdAt: 'Date.now()',
        },
        status: 'Updated status',
        updatedAt: 'Date.now()',
      },
      endpoint: 'POST /api/support/tickets/:id/reply',
    },
    
    // Close Ticket
    TICKET_CLOSE: {
      trigger: 'User or admin closes ticket',
      collection: 'support_tickets',
      action: 'UPDATE',
      updatedData: {
        status: 'closed',
        closedAt: 'Date.now()',
        closedBy: 'User/Admin ID',
      },
    },
    
    // Contact Form
    CONTACT_SUBMIT: {
      trigger: 'Visitor submits contact form',
      collection: 'contact_forms',
      action: 'CREATE',
      requiredData: {
        name: 'Visitor name',
        email: 'Email address',
        phone: 'Optional phone',
        subject: 'Subject',
        message: 'Message content',
        type: 'general/support/sales/partnership',
        status: 'new',
        source: 'Page URL',
        ipAddress: 'Client IP',
        userAgent: 'Browser info',
        createdAt: 'Date.now()',
      },
      relatedCollections: {
        activity_logs: {
          action: 'CREATE',
          data: {
            action: 'CONTACT_SUBMIT',
            category: 'system',
            isAnonymous: 'true if not logged in',
          },
        },
      },
      endpoint: 'POST /api/contact',
      frontendFile: 'components/pages/ContactUsPage.tsx',
    },
    
    // Live Support Chat
    LIVE_SUPPORT_START: {
      trigger: 'User starts live support chat',
      collection: 'support_tickets',
      action: 'CREATE',
      data: {
        type: 'live_chat',
        status: 'active',
        isLiveChat: true,
      },
      endpoint: 'POST /api/support/live/start',
      frontendFile: 'components/pages/LiveSupportPage.tsx',
    },
  },
  
  // ============================================
  // SECTION 8: AI LAB
  // ============================================
  AI_LAB: {
    // Playground Session
    PLAYGROUND_SESSION: {
      trigger: 'User starts AI playground',
      collection: 'ai_lab_experiments',
      action: 'CREATE',
      data: {
        userId: 'User ID',
        type: 'playground',
        model: 'Selected model',
        prompt: 'User prompt',
        parameters: {
          temperature: 0.7,
          maxTokens: 2048,
          topP: 1,
        },
        startedAt: 'Date.now()',
      },
      frontendFile: 'components/lab/AILabPlaygroundPage.tsx',
    },
    
    // Playground Response
    PLAYGROUND_RESPONSE: {
      trigger: 'AI generates response in playground',
      collection: 'ai_lab_experiments',
      action: 'UPDATE',
      updatedData: {
        response: 'AI response',
        completedAt: 'Date.now()',
        metrics: {
          latency: 'Response time ms',
          tokens: 'Token count',
          cost: 'Estimated cost',
        },
      },
      relatedCollections: {
        activity_logs: {
          action: 'CREATE',
          data: {
            action: 'AI_LAB_EXPERIMENT',
            category: 'analytics',
          },
        },
      },
    },
    
    // Model Battle
    MODEL_BATTLE: {
      trigger: 'User runs model comparison',
      collection: 'ai_lab_experiments',
      action: 'CREATE',
      data: {
        userId: 'User ID',
        type: 'battle',
        prompt: 'Test prompt',
        models: ['model1', 'model2'],
        results: [],
      },
      frontendFile: 'components/lab/AILabBattlePage.tsx',
    },
    
    // Sentiment Analysis
    SENTIMENT_ANALYSIS: {
      trigger: 'User analyzes text sentiment',
      collection: 'ai_lab_experiments',
      action: 'CREATE',
      data: {
        type: 'sentiment',
        inputText: 'Text to analyze',
        result: {
          sentiment: 'positive/negative/neutral',
          confidence: 0.95,
          emotions: {},
        },
      },
      frontendFile: 'components/lab/AILabSentimentAnalyzerPage.tsx',
    },
    
    // Cost Calculator
    COST_CALCULATION: {
      trigger: 'User calculates AI costs',
      collection: 'ai_lab_experiments',
      action: 'CREATE',
      data: {
        type: 'cost_calculation',
        inputs: {
          model: 'Model name',
          inputTokens: 1000,
          outputTokens: 2000,
          requestsPerDay: 100,
        },
        results: {
          dailyCost: 0.50,
          monthlyCost: 15.00,
        },
      },
      frontendFile: 'components/lab/AILabCostCalculatorPage.tsx',
    },
    
    // Code Playground
    CODE_EXECUTION: {
      trigger: 'User runs code in AI code playground',
      collection: 'ai_lab_experiments',
      action: 'CREATE',
      data: {
        type: 'code',
        language: 'python/javascript',
        code: 'Code content',
        output: 'Execution result',
        executedAt: 'Date.now()',
      },
      frontendFile: 'components/lab/AILabCodePlaygroundPage.tsx',
    },
    
    // Prompt Templates
    PROMPT_TEMPLATE_SAVE: {
      trigger: 'User saves prompt template',
      collection: 'prompt_templates',
      action: 'CREATE',
      data: {
        userId: 'User ID',
        name: 'Template name',
        prompt: 'Template content',
        category: 'Category',
        isPublic: false,
        createdAt: 'Date.now()',
      },
      frontendFile: 'components/lab/AILabTemplatesPage.tsx',
    },
    
    // Experiment History
    EXPERIMENT_HISTORY: {
      trigger: 'User views experiment history',
      collection: 'ai_lab_experiments',
      action: 'READ',
      query: {
        userId: 'Current user ID',
      },
      sortBy: { createdAt: -1 },
      frontendFile: 'components/lab/AILabHistoryPage.tsx',
    },
  },
  
  // ============================================
  // SECTION 9: TOOLBOX
  // ============================================
  TOOLBOX: {
    // IP Info Lookup
    IP_LOOKUP: {
      trigger: 'User looks up IP info',
      collection: 'tool_usage',
      action: 'CREATE',
      data: {
        userId: 'User ID (if logged in)',
        tool: 'ip_info',
        input: 'IP address',
        result: 'Lookup result',
        timestamp: 'Date.now()',
      },
      relatedCollections: {
        activity_logs: {
          action: 'CREATE',
          data: {
            action: 'TOOL_USE',
            category: 'analytics',
            details: { tool: 'ip_info' },
          },
        },
      },
      endpoint: 'GET /api/tools/ip/:ip',
      frontendFile: 'components/pages/IPInfoPage.tsx',
    },
    
    // DNS Lookup
    DNS_LOOKUP: {
      trigger: 'User performs DNS lookup',
      collection: 'tool_usage',
      data: {
        tool: 'dns_lookup',
        input: 'Domain name',
        recordType: 'A/AAAA/MX/TXT',
        result: 'DNS records',
      },
      frontendFile: 'components/pages/DNSLookupPage.tsx',
    },
    
    // Whois Lookup
    WHOIS_LOOKUP: {
      trigger: 'User performs WHOIS lookup',
      collection: 'tool_usage',
      data: {
        tool: 'whois',
        input: 'Domain name',
        result: 'WHOIS data',
      },
      frontendFile: 'components/pages/WhoisLookupPage.tsx',
    },
    
    // SSL Checker
    SSL_CHECK: {
      trigger: 'User checks SSL certificate',
      collection: 'tool_usage',
      data: {
        tool: 'ssl_checker',
        input: 'Domain name',
        result: 'Certificate details',
      },
      frontendFile: 'components/pages/SSLCheckerPage.tsx',
    },
    
    // Port Scanner
    PORT_SCAN: {
      trigger: 'User scans ports',
      collection: 'tool_usage',
      data: {
        tool: 'port_scanner',
        input: 'Host/IP',
        ports: 'Port range',
        result: 'Open ports',
      },
      frontendFile: 'components/pages/PortScannerPage.tsx',
    },
    
    // Ping Test
    PING_TEST: {
      trigger: 'User runs ping test',
      collection: 'tool_usage',
      data: {
        tool: 'ping',
        input: 'Host/IP',
        result: 'Ping results',
      },
      frontendFile: 'components/pages/PingTestPage.tsx',
    },
    
    // URL Encoder/Decoder
    URL_ENCODE: {
      trigger: 'User encodes/decodes URL',
      collection: 'tool_usage',
      data: {
        tool: 'url_encoder',
        input: 'Input string',
        operation: 'encode/decode',
        result: 'Output string',
      },
      frontendFile: 'components/pages/URLEncoderPage.tsx',
    },
    
    // API Tester
    API_TEST: {
      trigger: 'User tests API endpoint',
      collection: 'tool_usage',
      data: {
        tool: 'api_tester',
        method: 'GET/POST/PUT/DELETE',
        url: 'API URL',
        headers: 'Request headers',
        body: 'Request body',
        response: 'API response',
        statusCode: 200,
        latency: 'Response time',
      },
      frontendFile: 'components/pages/APITesterPage.tsx',
    },
    
    // Screenshot API
    SCREENSHOT_CAPTURE: {
      trigger: 'User captures website screenshot',
      collection: 'tool_usage',
      data: {
        tool: 'screenshot',
        url: 'Target URL',
        viewport: 'Desktop/Mobile',
        result: 'Screenshot URL',
      },
      frontendFile: 'components/pages/ScreenshotAPIPage.tsx',
    },
    
    // Domain Research Suite
    DOMAIN_RESEARCH: {
      trigger: 'User researches domain',
      collection: 'tool_usage',
      data: {
        tool: 'domain_research',
        domain: 'Domain name',
        result: {
          availability: 'Available/Taken',
          reputation: 'Score',
          categorization: 'Categories',
          threatLevel: 'Safe/Suspicious',
        },
      },
      frontendFile: 'components/pages/DomainResearchSuitePage.tsx',
    },
  },
  
  // ============================================
  // SECTION 10: API KEYS
  // ============================================
  API_KEYS: {
    // Create API Key
    API_KEY_CREATE: {
      trigger: 'User creates API key',
      collection: 'api_keys',
      action: 'CREATE',
      data: {
        userId: 'User ID',
        key: 'Hashed key',
        keyPreview: 'Last 4 chars',
        name: 'Key name',
        permissions: ['read', 'write'],
        rateLimit: 1000,
        isActive: true,
        createdAt: 'Date.now()',
      },
      relatedCollections: {
        activity_logs: {
          action: 'CREATE',
          data: {
            action: 'API_KEY_CREATE',
            category: 'security',
          },
        },
      },
      endpoint: 'POST /api/users/api-keys',
    },
    
    // Revoke API Key
    API_KEY_REVOKE: {
      trigger: 'User revokes API key',
      collection: 'api_keys',
      action: 'UPDATE',
      updatedData: {
        isActive: false,
        revokedAt: 'Date.now()',
      },
      relatedCollections: {
        activity_logs: {
          action: 'CREATE',
          data: {
            action: 'API_KEY_REVOKE',
            category: 'security',
          },
        },
      },
      endpoint: 'DELETE /api/users/api-keys/:id',
    },
    
    // API Key Usage
    API_KEY_USE: {
      trigger: 'External API call with key',
      collection: 'api_keys',
      action: 'UPDATE',
      updatedData: {
        lastUsedAt: 'Date.now()',
        usageCount: 'INCREMENT +1',
      },
    },
  },
  
  // ============================================
  // SECTION 11: ADMIN OPERATIONS
  // ============================================
  ADMIN: {
    // View Admin Dashboard
    ADMIN_DASHBOARD: {
      trigger: 'Admin views dashboard',
      collection: 'activity_logs',
      action: 'CREATE',
      data: {
        action: 'ADMIN_ACCESS',
        category: 'system',
        severity: 'high',
      },
    },
    
    // User Management
    ADMIN_USER_UPDATE: {
      trigger: 'Admin updates user',
      collection: 'users',
      action: 'UPDATE',
      relatedCollections: {
        activity_logs: {
          action: 'CREATE',
          data: {
            action: 'ADMIN_USER_UPDATE',
            category: 'system',
            severity: 'high',
            details: {
              targetUserId: 'User being updated',
              changes: 'What was changed',
            },
          },
        },
      },
    },
    
    // System Settings
    ADMIN_SYSTEM_SETTINGS: {
      trigger: 'Admin changes system settings',
      collection: 'system_settings',
      action: 'UPDATE',
      relatedCollections: {
        activity_logs: {
          action: 'CREATE',
          data: {
            action: 'SYSTEM_SETTINGS_CHANGE',
            category: 'system',
            severity: 'critical',
          },
        },
      },
    },
  },
};

// ============================================
// COLLECTIONS SUMMARY
// ============================================

const REQUIRED_COLLECTIONS = {
  // Core User Data
  users: {
    purpose: 'User accounts, authentication, preferences, security',
    criticalFields: ['email', 'password', 'security', 'preferences', 'statistics'],
  },
  
  // Visitor Tracking
  visitors: {
    purpose: 'Anonymous and logged-in visitor sessions',
    criticalFields: ['sessionId', 'device', 'location', 'pageViews'],
  },
  
  // Activity Logging
  activity_logs: {
    purpose: 'ALL user actions and system events',
    criticalFields: ['userId', 'action', 'category', 'createdAt'],
    ttl: '1 year',
  },
  
  // Agents
  agents: {
    purpose: 'AI agent definitions and configurations',
    criticalFields: ['agentId', 'name', 'category', 'pricing', 'isActive'],
  },
  
  // Purchases (CRITICAL!)
  agent_purchases: {
    purpose: 'One-time agent purchases (DAILY/WEEKLY/MONTHLY)',
    criticalFields: ['userId', 'agentId', 'plan', 'status', 'expiresAt', 'stripeCheckoutSessionId'],
  },
  
  // Transactions
  transactions: {
    purpose: 'Payment records for billing history',
    criticalFields: ['userId', 'type', 'amount', 'status', 'stripePaymentIntentId'],
  },
  
  // Webhooks
  webhook_events: {
    purpose: 'Stripe/PayPal webhook event logs',
    criticalFields: ['source', 'eventType', 'eventId', 'payload', 'status'],
  },
  
  // Chat System
  chats: {
    purpose: 'Chat conversations with embedded messages',
    criticalFields: ['participants', 'agentType', 'messages', 'lastMessageAt'],
  },
  
  // Agent-Specific Data
  individual_agent_configurations: {
    purpose: 'Per-agent custom configurations',
    criticalFields: ['agentId', 'personality', 'capabilities', 'pricing'],
  },
  
  individual_agent_sessions: {
    purpose: 'Active chat sessions per agent',
    criticalFields: ['userId', 'agentId', 'isActive', 'messageCount'],
  },
  
  individual_agent_chat_histories: {
    purpose: 'Full message history per user/agent',
    criticalFields: ['userId', 'agentId', 'messages'],
  },
  
  // Support
  support_tickets: {
    purpose: 'Customer support tickets',
    criticalFields: ['userId', 'subject', 'status', 'responses'],
  },
  
  contact_forms: {
    purpose: 'Contact form submissions',
    criticalFields: ['email', 'message', 'status'],
  },
  
  // Settings
  notification_settings: {
    purpose: 'User notification preferences',
    criticalFields: ['userId', 'email', 'push', 'sms', 'inApp'],
  },
  
  // File Storage
  file_uploads: {
    purpose: 'File upload references (avatars, attachments)',
    criticalFields: ['userId', 'filename', 'storageKey', 'url'],
  },
  
  // API Access
  api_keys: {
    purpose: 'User-generated API keys',
    criticalFields: ['userId', 'key', 'permissions', 'isActive'],
  },
  
  // AI Lab
  ai_lab_experiments: {
    purpose: 'AI Lab experiment history',
    criticalFields: ['userId', 'type', 'prompt', 'result'],
  },
  
  // Tool Usage
  tool_usage: {
    purpose: 'Toolbox tool usage tracking',
    criticalFields: ['userId', 'tool', 'input', 'result', 'timestamp'],
  },
  
  // Security
  security_logs: {
    purpose: 'Security-specific events (failed logins, 2FA changes)',
    criticalFields: ['userId', 'event', 'ipAddress', 'timestamp'],
  },
};

module.exports = {
  IAMAI_DATA_FLOW,
  REQUIRED_COLLECTIONS,
};
