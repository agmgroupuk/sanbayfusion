const express = require('express');
const http = require('http');
// Fix for nginx + express-rate-limit: trust proxy
const app = express();
// Set trust proxy BEFORE any middleware for express-rate-limit to work behind nginx
app.set('trust proxy', 1);
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const compression = require('compression');
const rateLimit = require('express-rate-limit');
const cookieParser = require('cookie-parser');
const jwt = require('jsonwebtoken');
const path = require('path');
const fs = require('fs').promises;
require('dotenv').config();

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-this';

// Import AI Service
const { getAIService } = require('./ai-service');

// Import Database
const { connectDB, checkHealth: checkDBHealth, getStats: getDBStats } = require('./database');
const models = require('./models.cjs');
const {
  User,
  Agent,
  Chat,
  Transaction,
  FileUpload,
  UsageAnalytics,
  ApiKey,
  SupportTicket,
  ContactForm,
  WebhookEvent,
  ActivityLog,
  Visitor,
  Session,
  UserAuth,
  TwoFactorAuth,
} = models;

// Import NEW SIMPLE PURCHASE SYSTEM (replaces Subscription)
const { AgentPurchase } = require('./agent-purchase-models');
const agentPurchaseAPI = require('./agent-purchase-api');

// ❌ DEPRECATED: Old agent-specific subscription APIs (not used in production)
// These are replaced by unified purchase API above
// const universalAgentAPI = require('./universal-agent-api');
// const individualAgentAPI = require('./individual-agent-api');

// Import Agent Collection System (Individual Collections per Agent)
const agentCollectionAPI = require('./agent-collection-api');
const {
  agentCollectionIntegration,
  chatMiddleware,
  sessionMiddleware,
} = require('./agent-collection-integration');

// Import Enhanced Middleware
const { validateProfileUpdate, validateSettings } = require('./middleware/profileValidation');
const {
  formatSessionForDashboard,
  formatActivityForDashboard,
  generateSecurityRecommendations,
  calculateSecurityScore,
  getSecurityLevel,
} = require('./utils/securityDashboard');

// Import Enhanced Security Routes
// TEMP: Commented out - file doesn't exist
// const {
//   getEnhancedSessions,
//   getEnhancedActivity,
//   getSecurityDashboard
// } = require('./routes/enhancedSecurity');

// Import Dashboard Compatibility
const { getSessionsCompatible, getActivityCompatible } = require('./routes/dashboardCompatibility');

// Import Content Management Models
const contentModels = require('./content-models');
const {
  BlogPost,
  FAQ,
  Documentation,
  Tutorial,
  Template,
  News,
  About,
  Team,
  Jobs,
  Partners,
  Legal,
  Reports,
  DeveloperResources,
  Education,
  SystemStatus,
  ChatSession,
  Rewards,
  UserRewards,
  ChatMessages,
  TicketResponses,
  TicketAttachments,
  ContactSubmission,
} = contentModels;

// Import Critical Missing Models
const criticalModels = require('./critical-models');
const { Plan, LoginActivity, Settings, Invoice, EmailLog, AuditLog } = criticalModels;

// NOTE: Agent Model is now imported from models.cjs which uses ./models/Agent.js
// Do NOT re-import here to avoid duplicate declaration

// Import Payment Models
const paymentModels = require('./payment-models');
const { Payment, PaymentTransaction, PaymentMethod, BillingCycle } = paymentModels;

// Import Support Models
const supportModels = require('./support-models');
const {
  SupportTicket: SupportTicketNew,
  TicketResponse,
  TicketAttachment,
  SupportTeam,
} = supportModels;

// Import Enhanced Profile Models - DISABLED (file not found)
// const profileModels = require('./profile-models');
// const {
//   EnhancedUserProfile, LoginActivityExtended
// } = profileModels;

// Import Billing Models
const billingModels = require('./billing-models');
const { InvoiceAdvanced, BillingHistory, PaymentReceipt, TaxRecord } = billingModels;

// Import RBAC Models
const rbacModels = require('./rbac-models');
const { Role, Permission, UserRole, RolePermission } = rbacModels;

// Import Webhook Models
const webhookModels = require('./webhook-models');
const { WebhookLog, WebhookEndpoint } = webhookModels;

// Import Authentication (Original)
const authService = require('./auth-service');
const {
  authenticate,
  optionalAuth,
  requireTier,
  requireCredits,
  validateFields,
  validateEmail,
  validatePassword,
} = require('./auth-middleware');

// Import New Comprehensive Authentication System
const authModels = require('./auth-models');
// const authServiceComplete = require('./auth-service-clean'); // File doesn't exist - using auth-service.js instead
const authServiceComplete = require('./auth-service');
// const authRoutesComplete = require('./auth-routes-complete'); // File doesn't exist
// const authMiddlewareComplete = require('./auth-middleware-complete'); // File doesn't exist - using auth-middleware.js instead
const authMiddlewareComplete = require('./auth-middleware');
// requireAuth doesn't exist in auth-middleware, using authenticate from line 113 instead
const emailService = require('./email-service-clean');

// Import Personality System
const personalityMiddleware = require('./personality-middleware');

// Import WebSocket Service
const wsService = require('./websocket-service');

// Import AI Provider Routes
const aiProviderRoutes = require('./routes/aiProviderRoutes');
const { rateLimitMiddleware, usageTrackingMiddleware } = require('./middleware/usageTracking');
const {
  activityTrackingMiddleware,
  logActivity,
  getSessionId,
} = require('./middleware/activityTracking');

// Import AI Lab Routes
const aiLabRoutes = require('./ai-lab-routes');

// Import Canvas Routes
const canvasRoutes = require('./routes/canvas');

// Import Chat Session Routes
const chatSessionRoutes = require('./routes/chat-sessions');

// Import Universal Tracking Middleware (Professional Data Flow)
const { TrackingService, trackingMiddleware } = require('./middleware/universal-tracking');

// Import Visitor Tracking - TEMPORARILY DISABLED
// const { trackVisitor } = require('./middleware/simple-visitor-tracking');
const visitorAnalyticsRoutes = require('./routes/visitor-analytics');

// Use the single app instance created at the top of the file
const server = http.createServer(app);
const PORT = process.env.PORT || 3001;

// Initialize AI Service
let aiService;
try {
  aiService = getAIService();
  console.log('🤖 AI Service initialized');
} catch (error) {
  console.error('⚠️  AI Service initialization failed:', error.message);
}

// Initialize Database
let dbConnected = false;
(async () => {
  try {
    await connectDB();
    dbConnected = true;
    console.log('💾 Database connected');

    // Note: autoIndex and autoCreate are disabled to prevent empty collection creation
    // Indexes are synced only for essential models (User, AgentPurchase, ActivityLog)
  } catch (error) {
    console.error('⚠️  Database connection failed:', error.message);
  }
})();

// Security middleware
app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        styleSrc: ["'self'", "'unsafe-inline'"],
        imgSrc: ["'self'", 'data:', 'https:'],
        scriptSrc: ["'self'"],
        connectSrc: ["'self'", 'wss:', 'ws:'],
      },
    },
  })
);

// CORS configuration
app.use(
  cors({
    origin: process.env.FRONTEND_URL || 'https://iamai.global',
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization'],
  })
);

app.use(compression());

// Visitor tracking middleware (track all requests) - TEMPORARILY DISABLED
// app.use(trackVisitor);

// Universal Tracking Middleware - Professional data flow tracking
// Tracks ALL API requests to activity_logs
app.use('/api/', trackingMiddleware);

// Rate limiting - INCREASED for authenticated users
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 1000, // limit each IP to 1000 requests per windowMs (increased from 100)
  message: 'Too many requests from this IP, please try again later.',
  // Skip rate limiting for certain endpoints that users frequently poll
  skip: req => {
    // Allow higher limits for authenticated data fetching
    const allowedPaths = ['/api/purchases/active', '/api/users/app-data', '/api/auth/session'];
    return allowedPaths.some(path => req.path === path);
  },
});
app.use('/api/', limiter);

// Logging
app.use(morgan('combined'));

// Body parsing middleware - IMPORTANT: Stripe webhooks need raw body for signature verification
// Apply raw body parser for Stripe webhook endpoints FIRST
app.use('/api/webhooks/stripe', express.raw({ type: 'application/json' }));
app.use('/api/payments/webhook', express.raw({ type: 'application/json' }));

// Apply JSON parser for all other endpoints (with conditional check to not re-parse)
app.use((req, res, next) => {
  // Skip JSON parsing if body is already a Buffer (Stripe webhooks)
  if (Buffer.isBuffer(req.body)) {
    return next();
  }
  express.json({ limit: '10mb' })(req, res, next);
});
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Cookie parsing middleware
app.use(cookieParser());

// Static file serving for avatars
app.use('/uploads', express.static('uploads'));

// ========== HELPER FUNCTIONS ==========

/**
 * Get system message for each agent type
 */
function getAgentSystemMessage(agentId) {
  const systemMessages = {
    agentx:
      'You are AgentX, an advanced AI assistant focused on productivity and task management. You help users accomplish their goals efficiently and provide clear, actionable advice.',
    'ai-girlfriend':
      "You are a caring and empathetic AI companion. You engage in warm, supportive conversations and show genuine interest in the user's thoughts and feelings. You are friendly, understanding, and emotionally intelligent.",
    autochat:
      'You are AutoChat, an automated customer service agent. You provide quick, helpful responses to customer inquiries and can help with common questions and tasks.',
    chatrevive:
      'You are ChatRevive, specialized in analyzing and recovering conversation context. You help users pick up where they left off in previous conversations.',
    'content-creator':
      'You are a creative content generation specialist. You help create engaging blog posts, social media content, and marketing copy that resonates with audiences.',
    'code-assistant':
      'You are an expert programming assistant. You help with code generation, debugging, code review, and explaining complex programming concepts clearly.',
    default:
      'You are a helpful AI assistant. Provide clear, accurate, and friendly responses to user queries.',
  };

  return systemMessages[agentId] || systemMessages['default'];
}

/**
 * Calculate credits based on token usage
 */
function calculateCredits(usage) {
  if (!usage || !usage.total_tokens) return 1;

  // 1 credit per 1000 tokens (adjust as needed)
  return Math.ceil(usage.total_tokens / 1000);
}

// Health check endpoint
app.get('/health', async (req, res) => {
  const dbHealth = await checkDBHealth();

  res.status(200).json({
    status: dbHealth.status === 'healthy' && aiService ? 'healthy' : 'degraded',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    environment: process.env.NODE_ENV || 'production',
    version: '1.0.0',
    services: {
      database: dbHealth,
      ai: {
        status: aiService ? 'healthy' : 'unavailable',
        providers: aiService ? aiService.getStats().availableProviders : {},
      },
    },
  });
});

app.get('/api/health', async (req, res) => {
  const dbHealth = await checkDBHealth();

  res.status(200).json({
    status: 'ok',
    message: 'IAMAI Backend API is running',
    timestamp: new Date().toISOString(),
    version: '1.0.0',
    database: dbHealth.status,
    ai: aiService ? 'available' : 'unavailable',
  });
});

// ========== DATABASE ENDPOINTS ==========

// Get database statistics
app.get('/api/database/stats', async (req, res) => {
  try {
    const stats = await getDBStats();
    res.json(stats);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get database health
app.get('/api/database/health', async (req, res) => {
  try {
    const health = await checkDBHealth();
    res.json(health);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ========== AGENTS ENDPOINTS ==========
// NOTE: The main agent listing endpoints are now in ./routes/agents.js
// and registered at /api/agents via app.use() below.
// The routes below are for chat functionality that requires special handling.

/*
 * DEPRECATED: Old inline /api/agents endpoint - now handled by routes/agents.js
 * app.get('/api/agents', async (req, res) => { ... })
 * app.get('/api/agents/:id', (req, res) => { ... })
 */

// Get specific agent - DEPRECATED: Now handled by routes/agents.js (/api/agents/detail/:agentId)
// Commenting out to avoid route conflict
/*
app.get('/api/agents/:id', (req, res) => {
  const { id } = req.params;
  
  const agents = {
    'agentx': {
      id: 'agentx',
      name: 'AgentX',
      type: 'assistant',
      description: 'Advanced AI assistant for general tasks and productivity',
      capabilities: ['conversation', 'task-planning', 'information-retrieval'],
      status: 'active',
      model: 'gpt-4',
      pricing: { tier: 'free', credits: 0 }
    },
    'ai-girlfriend': {
      id: 'ai-girlfriend',
      name: 'AI Girlfriend',
      type: 'companion',
      description: 'Empathetic AI companion for meaningful conversations',
      capabilities: ['conversation', 'emotional-support', 'personality-adaptation'],
      status: 'active',
      model: 'claude-3-sonnet',
      pricing: { tier: 'premium', credits: 10 }
    },
    'autochat': {
      id: 'autochat',
      name: 'AutoChat',
      type: 'automation',
      description: 'Automated chat agent for customer service and engagement',
      capabilities: ['automation', 'scheduling', 'integration'],
      status: 'active',
      model: 'gpt-3.5-turbo',
      pricing: { tier: 'basic', credits: 5 }
    }
  };
  
  const agent = agents[id];
  if (agent) {
    res.json(agent);
  } else {
    res.status(404).json({ error: 'Agent not found' });
  }
});
*/

// Chat with agent - Enhanced with real subscription checking
app.post('/api/agents/:id/chat', authenticate, async (req, res) => {
  const { id } = req.params;
  const { message, conversationId, model, temperature } = req.body;
  const userId = req.userId;

  if (!message) {
    return res.status(400).json({ error: 'Message is required' });
  }

  if (!aiService) {
    return res.status(503).json({
      error: 'AI service is not available. Please configure API keys.',
    });
  }

  try {
    // ============================================
    // SIMPLE PURCHASE VALIDATION
    // ============================================

    // Check if user has any active purchases (any agent)
    const activePurchases = await AgentPurchase.find({
      userId,
      status: 'ACTIVE',
      expiresAt: { $gt: new Date() },
    });

    // Check if user has active access (any agent grants chat access)
    if (activePurchases.length === 0) {
      return res.status(403).json({
        success: false,
        error: 'Purchase Required',
        message: 'Please purchase agent access to send messages',
        requiresPurchase: true,
        availablePlans: {
          DAILY: { name: 'Daily Access', price: 1.0, duration: '1 day' },
          WEEKLY: { name: 'Weekly Pro', price: 5.0, duration: '7 days' },
          MONTHLY: { name: 'Monthly Unlimited', price: 19.0, duration: '30 days' },
        },
      });
    }

    // User has active purchase - unlimited messages, no limits to check
    const activeSubscription = activePurchases[0];
    console.log(
      `✅ Purchase check passed for user ${userId}: ${activeSubscription.plan} plan, expires: ${activeSubscription.expiresAt}`
    );
  } catch (subscriptionError) {
    console.error('❌ Subscription validation failed:', subscriptionError);
    return res.status(500).json({
      success: false,
      error: 'Subscription Validation Error',
      message: 'Unable to verify subscription status. Please try again.',
    });
  }

  try {
    // 🎭 PERSONALITY ENFORCEMENT - Inject personality into the request
    const personalityEnforced = personalityMiddleware.enforcePersonality(id, message);

    // Get agent configuration from database
    const agent = await Agent.findOne({ agentId: id });

    // Prepare messages array with personality-enforced system prompt
    const systemPrompt =
      personalityEnforced.systemPrompt || (agent ? agent.systemPrompt : getAgentSystemMessage(id));

    const messages = [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: personalityEnforced.enhancedMessage },
    ];

    // Call AI service with fallback support
    const response = await aiService.chat(messages, {
      model: model || (agent ? agent.model : 'gpt-4'),
      temperature: temperature || (agent && agent.aiConfig ? agent.aiConfig.temperature : 0.7),
      maxTokens: 2000,
      agentId: id,
      preferredProvider: agent && agent.aiConfig ? agent.aiConfig.preferredProvider : null,
    });

    // 🎭 PERSONALITY VALIDATION - Ensure response maintains personality
    const validation = personalityMiddleware.validatePersonality(id, response.content);

    // If personality validation fails, log warning (but still return response)
    if (!validation.isValid) {
      console.warn(`⚠️ Personality validation failed for ${id}:`, validation.warnings);
    }

    // ============================================
    // RECORD PURCHASE USAGE (UNLIMITED MESSAGES)
    // ============================================
    try {
      // Update message count for active purchases
      const purchase = await AgentPurchase.findOne({
        userId,
        agentId: id,
        status: 'ACTIVE',
        expiresAt: { $gt: new Date() },
      });

      if (purchase) {
        await purchase.recordMessage();
        console.log(`📊 Message recorded for user ${userId}:`, {
          messagesUsed: purchase.currentUsage.messagesUsed,
          plan: purchase.plan,
          agent: id,
          expiresAt: purchase.expiresAt,
        });
      }
    } catch (usageError) {
      console.error('⚠️ Failed to record message (continuing anyway):', usageError.message);
      // Continue with message processing - don't fail the entire request
    }

    // Legacy credit system (keeping for compatibility)
    const creditsUsed = calculateCredits(response.usage);

    // Deduct credits from user (if credit system is still used)
    try {
      await authService.deductCredits(req.userId, creditsUsed);
    } catch (creditError) {
      console.warn('⚠️ Credit deduction failed (using subscription system):', creditError.message);
      // Continue - subscription system is primary now
    }

    // Save chat to database
    let chat;
    if (conversationId && conversationId !== 'new') {
      // Update existing chat
      chat = await Chat.findOne({ _id: conversationId, userId: req.userId });
      if (chat) {
        chat.messages.push(
          { role: 'user', content: message, timestamp: new Date() },
          { role: 'assistant', content: response.content, timestamp: new Date() }
        );
        await chat.save();
      }
    }

    if (!chat) {
      // Create new chat with purchase context
      const purchase = await AgentPurchase.findOne({
        userId,
        status: 'ACTIVE',
        expiresAt: { $gt: new Date() },
      });

      chat = await Chat.create({
        userId: req.userId,
        agentId: id,
        title: message.substring(0, 50),
        messages: [
          { role: 'user', content: message, timestamp: new Date() },
          { role: 'assistant', content: response.content, timestamp: new Date() },
        ],
        metadata: {
          agentName: getAgentName(id),
          model: response.model || 'unknown',
          totalTokens: response.usage?.total_tokens || 0,
          purchasePlan: purchase?.plan || 'FREE',
          usageRecorded: true,
          creditsUsed: creditsUsed,
        },
      });
    }

    // Send real-time update via WebSocket if user is connected
    if (wsService.isUserOnline(req.userId)) {
      wsService.sendToUser(req.userId, 'ai_response', {
        conversationId: chat._id,
        agentId: id,
        message: response.content,
        provider: response.provider,
        model: response.model,
        creditsUsed,
        timestamp: new Date().toISOString(),
      });
    }

    // Log usage analytics
    await UsageAnalytics.create({
      userId: req.userId,
      agentId: id,
      action: 'chat',
      creditsUsed,
      metadata: {
        model: response.model,
        provider: response.provider,
        tokens: response.usage,
      },
    });

    // Return response
    res.json({
      agentId: id,
      conversationId: chat._id,
      message: response.content,
      provider: response.provider,
      model: response.model,
      timestamp: new Date().toISOString(),
      usage: response.usage,
      creditsUsed,
      remainingCredits: (await authService.getUserById(req.userId)).credits,
      availableKeys: agentConfig.availableKeys,
    });
  } catch (error) {
    console.error(`Error in chat with agent ${id}:`, error);
    res.status(500).json({
      error: 'Failed to generate response',
      message: error.message,
      fallbackMessage: `I apologize, but I'm having trouble connecting to my AI services right now. Please try again in a moment.`,
    });
  }
});

// Stream chat with agent (Server-Sent Events)
app.post('/api/agents/:id/chat/stream', authenticate, requireCredits(1), async (req, res) => {
  const { id } = req.params;
  const { message, model } = req.body;

  if (!message) {
    return res.status(400).json({ error: 'Message is required' });
  }

  if (!aiService || !aiService.openai) {
    return res.status(503).json({
      error: 'Streaming requires OpenAI. Fallback to regular chat endpoint.',
    });
  }

  // Set headers for SSE
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');

  try {
    const systemMessage = getAgentSystemMessage(id);
    const messages = [
      { role: 'system', content: systemMessage },
      { role: 'user', content: message },
    ];

    const stream = aiService.streamChat(messages, {
      model: model || 'gpt-4',
      agentId: id,
    });

    let fullResponse = '';
    for await (const chunk of stream) {
      fullResponse += chunk;
      res.write(`data: ${JSON.stringify({ content: chunk })}\n\n`);
    }

    // Deduct credits after successful streaming
    const creditsUsed = Math.ceil(fullResponse.length / 100); // Estimate based on response length
    await authService.deductCredits(req.userId, creditsUsed);

    // Log usage
    await UsageAnalytics.create({
      userId: req.userId,
      agentId: id,
      action: 'chat_stream',
      creditsUsed,
      metadata: { model: model || 'gpt-4', responseLength: fullResponse.length },
    });

    res.write('data: [DONE]\n\n');
    res.end();
  } catch (error) {
    console.error(`Stream error for agent ${id}:`, error);
    res.write(`data: ${JSON.stringify({ error: error.message })}\n\n`);
    res.end();
  }
});

// Generate image with AI
app.post('/api/agents/:id/generate-image', async (req, res) => {
  const { id } = req.params;
  const { prompt, size, quality } = req.body;

  if (!prompt) {
    return res.status(400).json({ error: 'Prompt is required' });
  }

  if (!aiService) {
    return res.status(503).json({ error: 'AI service not available' });
  }

  try {
    const result = await aiService.generateImage(prompt, {
      size: size || '1024x1024',
      quality: quality || 'standard',
      agentId: id,
    });

    res.json({
      agentId: id,
      provider: result.provider,
      images: result.images,
      prompt,
      timestamp: new Date().toISOString(),
      creditsUsed: 10, // Image generation costs more
    });
  } catch (error) {
    console.error(`Image generation error for agent ${id}:`, error);
    res.status(500).json({
      error: 'Failed to generate image',
      message: error.message,
    });
  }
});

// Get AI service statistics
app.get('/api/ai/stats', (req, res) => {
  if (!aiService) {
    return res.status(503).json({ error: 'AI service not available' });
  }

  const stats = aiService.getStats();
  res.json({
    ...stats,
    timestamp: new Date().toISOString(),
  });
});

// Validate API keys
app.get('/api/ai/validate', async (req, res) => {
  if (!aiService) {
    return res.status(503).json({ error: 'AI service not available' });
  }

  try {
    const validation = await aiService.validateKeys();
    res.json({
      validation,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    res.status(500).json({
      error: 'Validation failed',
      message: error.message,
    });
  }
});

// Get available API keys for agent - AI Service configuration
// Uses a different path to avoid conflict with database config route
app.get('/api/agents/:id/ai-config', (req, res) => {
  const { id } = req.params;

  if (!aiService) {
    return res.status(503).json({ error: 'AI service not available' });
  }

  const config = aiService.getAgentConfig(id);
  res.json(config);
});

// ========== PRICING ENDPOINT ==========

// Get pricing information
app.get('/api/pricing', (req, res) => {
  res.json({
    daily: { amount: 1, name: 'Daily', interval: 'day' },
    weekly: { amount: 5, name: 'Weekly', interval: 'week' },
    monthly: { amount: 19, name: 'Monthly', interval: 'month' },
  });
});

// ========== AUTHENTICATION ENDPOINTS ==========

// Register new user
app.post('/api/auth/signup', validateFields(['email', 'password']), async (req, res) => {
  try {
    const { email, password, name, firstName, lastName } = req.body;

    // Validate email format
    if (!validateEmail(email)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid email format',
      });
    }

    // Validate password strength
    const passwordValidation = validatePassword(password);
    if (!passwordValidation.valid) {
      return res.status(400).json({
        success: false,
        error: passwordValidation.message,
      });
    }

    // Register user
    const result = await authService.register({
      email,
      password,
      name,
      firstName,
      lastName,
    });

    // Set HTTP-only cookie with the token
    if (result.success && result.token) {
      res.cookie('authToken', result.token, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: process.env.NODE_ENV === 'production' ? 'strict' : 'lax',
        path: '/',
        maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
      });
    }

    res.status(201).json(result);
  } catch (error) {
    console.error('Signup error:', error);
    res.status(400).json({
      success: false,
      error: error.message || 'Registration failed',
    });
  }
});

// Sign in user
app.post('/api/auth/signin', validateFields(['email', 'password']), async (req, res) => {
  try {
    const { email, password } = req.body;

    // Get client info - prioritize x-forwarded-for for proxy/load balancer setups
    let ip =
      req.headers['x-forwarded-for']?.split(',')[0]?.trim() ||
      req.ip ||
      req.connection?.remoteAddress ||
      'Unknown';
    // Clean up IPv6-mapped IPv4 addresses
    if (ip && ip.startsWith('::ffff:')) {
      ip = ip.substring(7);
    }
    const userAgent = req.headers['user-agent'] || 'Unknown';

    console.log(
      '[AUTH] Login attempt - IP:',
      ip,
      'Headers x-forwarded-for:',
      req.headers['x-forwarded-for']
    );

    // Sign in user
    const result = await authService.signin({ email, password });

    if (result.success) {
      // Set HTTP-only cookie with the token
      res.cookie('authToken', result.token, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: process.env.NODE_ENV === 'production' ? 'strict' : 'lax',
        path: '/',
        maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
      });

      // Track login activity and session
      const user = await User.findById(result.user.id);
      if (user) {
        // Update last login info
        user.security.lastLoginAt = new Date();
        user.security.lastLoginIP = ip;
        user.security.lastLoginUserAgent = userAgent;

        // Add to login attempts (successful)
        if (!user.security.loginAttempts) {
          user.security.loginAttempts = [];
        }
        user.security.loginAttempts.push({
          ip: ip,
          userAgent: userAgent,
          success: true,
          timestamp: new Date(),
        });

        // Keep only last 50 attempts
        if (user.security.loginAttempts.length > 50) {
          user.security.loginAttempts = user.security.loginAttempts.slice(-50);
        }

        // Add to active sessions
        if (!user.security.activeSessions) {
          user.security.activeSessions = [];
        }

        const sessionId = `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        const sessionData = {
          sessionId: sessionId,
          ip: ip,
          userAgent: userAgent,
          createdAt: new Date(),
          lastActive: new Date(),
        };
        console.log('[AUTH] Creating session with data:', JSON.stringify(sessionData));
        user.security.activeSessions.push(sessionData);

        // Keep only last 10 sessions
        if (user.security.activeSessions.length > 10) {
          user.security.activeSessions = user.security.activeSessions.slice(-10);
        }

        await user.save();

        // Add session ID to response AND set as cookie for session tracking
        result.sessionId = sessionId;

        // Set sessionId cookie (readable by server for session identification)
        res.cookie('sessionId', sessionId, {
          httpOnly: true,
          secure: process.env.NODE_ENV === 'production',
          sameSite: process.env.NODE_ENV === 'production' ? 'strict' : 'lax',
          path: '/',
          maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
        });

        // Log successful login to ActivityLog
        await ActivityLog.create({
          userId: user._id,
          sessionId: sessionId,
          action: 'LOGIN_SUCCESS',
          route: '/api/auth/signin',
          method: 'POST',
          statusCode: 200,
          ipAddress: ip,
          userAgent: userAgent,
          metadata: { description: 'Successful login' },
          isAnonymous: false,
        });
        console.log('[AUTH] LOGIN_SUCCESS logged to ActivityLog for user:', user._id);
      }
    } else {
      // Track failed login attempt
      const user = await User.findOne({ email: email.toLowerCase() });
      if (user) {
        if (!user.security.loginAttempts) {
          user.security.loginAttempts = [];
        }
        user.security.loginAttempts.push({
          ip: ip,
          userAgent: userAgent,
          success: false,
          timestamp: new Date(),
        });

        if (user.security.loginAttempts.length > 50) {
          user.security.loginAttempts = user.security.loginAttempts.slice(-50);
        }

        await user.save();
      }
    }

    res.json(result);
  } catch (error) {
    console.error('Signin error:', error);

    // Track failed attempt even on error
    try {
      const { email } = req.body;
      if (email) {
        const user = await User.findOne({ email: email.toLowerCase() });
        if (user) {
          const ip =
            req.ip || req.connection.remoteAddress || req.headers['x-forwarded-for'] || 'Unknown';
          const userAgent = req.headers['user-agent'] || 'Unknown';

          if (!user.security.loginAttempts) {
            user.security.loginAttempts = [];
          }
          user.security.loginAttempts.push({
            ip: ip,
            userAgent: userAgent,
            success: false,
            timestamp: new Date(),
          });

          await user.save();
        }
      }
    } catch (trackingError) {
      console.error('Failed to track login attempt:', trackingError);
    }

    res.status(401).json({
      success: false,
      error: error.message || 'Sign in failed',
    });
  }
});

// Sign out user (no auth required - can logout even if session expired)
app.post('/api/auth/signout', async (req, res) => {
  try {
    // Try to get user ID from token before clearing
    let userId = null;
    const token = req.cookies?.authToken;
    if (token) {
      try {
        const jwt = require('jsonwebtoken');
        const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your-secret-key');
        userId = decoded.userId || decoded.id;
      } catch (e) {
        // Token expired or invalid, that's ok for logout
      }
    }

    // Log logout activity if we have a user
    if (userId) {
      let ip = req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip || 'Unknown';
      if (ip && ip.startsWith('::ffff:')) ip = ip.substring(7);
      const userAgent = req.headers['user-agent'] || 'Unknown';

      await ActivityLog.create({
        userId: userId,
        action: 'LOGOUT',
        route: '/api/auth/signout',
        method: 'POST',
        statusCode: 200,
        ipAddress: ip,
        userAgent: userAgent,
        metadata: { description: 'User logged out' },
        isAnonymous: false,
      });
      console.log('[AUTH] LOGOUT logged to ActivityLog for user:', userId);
    }

    // Clear the auth cookie
    res.clearCookie('authToken', {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: process.env.NODE_ENV === 'production' ? 'strict' : 'lax',
      path: '/',
    });

    // Clear the session cookie too
    res.clearCookie('sessionId', {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: process.env.NODE_ENV === 'production' ? 'strict' : 'lax',
      path: '/',
    });

    res.json({
      success: true,
      message: 'Signed out successfully',
    });
  } catch (error) {
    console.error('[AUTH] Signout error:', error);
    // Still clear cookies even on error
    res.clearCookie('authToken', { path: '/' });
    res.clearCookie('sessionId', { path: '/' });
    res.json({
      success: true,
      message: 'Signed out successfully',
    });
  }
});

// Get current session
app.get('/api/auth/session', authenticate, async (req, res) => {
  try {
    const stats = await authService.getUserStats(req.userId);

    res.json({
      user: stats.user,
      stats: stats.stats,
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to fetch session data',
    });
  }
});

// Refresh token
app.post('/api/auth/refresh', authenticate, (req, res) => {
  try {
    const token = authService.generateToken(req.user);

    res.json({
      success: true,
      token,
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to refresh token',
    });
  }
});

// ========== COMPREHENSIVE AUTHENTICATION SYSTEM ==========

// Mount comprehensive authentication routes (temporarily disabled due to file corruption)
// app.use('/api/auth/v2', authRoutesComplete);

// Test email service endpoint
app.get('/api/auth/v2/email/test', async (req, res) => {
  try {
    const result = await emailService.testEmailConnection();
    res.json(result);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Email service test failed',
    });
  }
});

// Authentication system health check
app.get('/api/auth/v2/health', (req, res) => {
  res.json({
    success: true,
    message: 'Comprehensive authentication system is healthy',
    timestamp: new Date().toISOString(),
    services: {
      auth: true,
      email: true,
      database: dbConnected,
      models: {
        UserAuth: !!authModels.UserAuth,
        PasswordResetToken: !!authModels.PasswordResetToken,
        EmailVerificationToken: !!authModels.EmailVerificationToken,
        UserSession: !!authModels.UserSession,
        FailedLoginAttempt: !!authModels.FailedLoginAttempt,
        TwoFactorAuth: !!authModels.TwoFactorAuth,
        AccountActivity: !!authModels.AccountActivity,
      },
    },
  });
});

// ========== USER ENDPOINTS ==========

// Load user profile and app-data routes (routes already have authenticate middleware)
try {
  const userProfileRoutes = require('./routes/user/profile');
  app.use('/api/users', userProfileRoutes);
  console.log('✅ User profile routes registered (includes /api/users/agents)');
} catch (error) {
  console.log('⚠️ User profile routes not found:', error.message);
}

try {
  const appDataRoutes = require('./routes/app-data');
  app.use('/api/users', appDataRoutes);
  console.log('✅ App data routes registered (includes /api/users/app-data)');
} catch (error) {
  console.log('⚠️ App data routes not found:', error.message);
}

// Load dashboard routes (stats + analytics for OverviewSection)
try {
  const dashboardRoutes = require('./routes/user/dashboard');
  app.use('/api/dashboard', dashboardRoutes);
  console.log('✅ Dashboard routes registered at /api/dashboard');
} catch (error) {
  console.log('⚠️ Dashboard routes not found:', error.message);
}

// Load user security routes (2FA, sessions, security overview)
try {
  const userSecurityRoutes = require('./routes/user/security');
  app.use('/api/users/security', userSecurityRoutes);
  console.log('✅ User security routes registered at /api/users/security');
} catch (error) {
  console.log('⚠️ User security routes not found:', error.message);
}

// NOTE: Remaining inline routes below are DUPLICATES of routes in files above
// They remain here for backwards compatibility but should eventually be removed
// The file-based routes take precedence

// Get user profile
app.get('/api/users/profile', authenticate, async (req, res) => {
  try {
    const user = await User.findById(req.userId).select('-password');

    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User not found',
      });
    }

    console.log('Fetching profile for user:', user._id);

    // Ensure default values for all fields
    const profileData = {
      success: true,
      data: {
        id: user._id,
        name: user.name || '',
        email: user.email || '',
        phone: user.phone || '',
        firstName: user.firstName || '',
        lastName: user.lastName || '',
        profileImage: user.profileImage || '',
        bio: user.bio || '',
        // Address fields
        address: user.address || '',
        city: user.city || '',
        country: user.country || '',
        tier: user.tier || 'FREE',
        credits: user.credits || 0,
        preferences: user.preferences || {
          theme: 'dark',
          language: 'en',
          timezone: 'UTC',
        },
        notifications: user.notifications || {
          email: true,
          sms: false,
          browser: true,
          marketing: false,
        },
        privacy: user.privacy || {
          profileVisibility: 'private',
          dataSharing: false,
          analytics: true,
        },
        security: {
          twoFactorEnabled: user.security?.twoFactorEnabled || false,
          emailVerified: user.emailVerified || false,
          phoneVerified: user.phoneVerified || false,
          lastPasswordChange: user.security?.lastPasswordChange || user.createdAt,
        },
        createdAt: user.createdAt,
        updatedAt: user.updatedAt,
      },
      message: 'Profile retrieved successfully',
    };

    res.json(profileData);
  } catch (error) {
    console.error('Profile fetch error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch profile',
      message: error.message,
    });
  }
});

// Update user profile
app.put('/api/users/profile', authenticate, validateProfileUpdate, async (req, res) => {
  try {
    const { name, email, phone, firstName, lastName, profileImage, bio, address, city, country } =
      req.validatedData;

    console.log('Profile update request:', {
      name,
      email,
      phone,
      firstName,
      lastName,
      profileImage,
      bio,
      address,
      city,
      country,
    });

    const user = await User.findById(req.userId);

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Update fields if provided
    if (name !== undefined) user.name = name;
    if (email !== undefined) user.email = email;
    if (phone !== undefined) user.phone = phone;
    if (firstName !== undefined) user.firstName = firstName;
    if (lastName !== undefined) user.lastName = lastName;
    if (profileImage !== undefined) user.profileImage = profileImage;
    if (bio !== undefined) user.bio = bio;
    // Address fields
    if (address !== undefined) user.address = address;
    if (city !== undefined) user.city = city;
    if (country !== undefined) user.country = country;

    await user.save();

    console.log('Profile updated successfully for user:', user._id);

    res.json({
      success: true,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        firstName: user.firstName,
        lastName: user.lastName,
        profileImage: user.profileImage,
        bio: user.bio,
        address: user.address,
        city: user.city,
        country: user.country,
        tier: user.tier,
        credits: user.credits,
        preferences: user.preferences,
        createdAt: user.createdAt,
        updatedAt: user.updatedAt,
      },
    });
  } catch (error) {
    console.error('Profile update error:', error);
    res.status(500).json({
      error: 'Failed to update profile',
      message: error.message,
    });
  }
});

// Avatar upload endpoint
const { upload } = require('./middleware/avatar-upload');

app.post('/api/users/avatar', authenticate, upload.single('avatar'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }

    const avatarUrl = `/uploads/avatars/${req.file.filename}`;

    // Update user's profileImage in database
    const user = await User.findById(req.userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Delete old avatar file if it exists
    if (user.profileImage && user.profileImage.startsWith('/uploads/avatars/')) {
      try {
        const oldFilePath = path.join(__dirname, '../public', user.profileImage);
        await fs.unlink(oldFilePath);
      } catch (error) {
        console.log('Could not delete old avatar:', error.message);
      }
    }

    user.profileImage = avatarUrl;
    await user.save();

    console.log('Avatar uploaded successfully for user:', user._id, 'URL:', avatarUrl);

    res.json({
      success: true,
      avatarUrl: avatarUrl,
      message: 'Avatar uploaded successfully',
    });
  } catch (error) {
    console.error('Avatar upload error:', error);
    res.status(500).json({
      error: 'Failed to upload avatar',
      message: error.message,
    });
  }
});

// Get user sessions (active devices) - Enhanced version with compatibility
app.get('/api/users/sessions', authenticate, getSessionsCompatible);

// Get user activity log (login attempts) - Enhanced version with compatibility
app.get('/api/users/activity', authenticate, getActivityCompatible);

// Helper function to parse user agent with detailed information
function getUserAgentInfo(userAgent) {
  if (!userAgent || userAgent === 'Unknown') {
    return {
      device: 'Unknown Device',
      browser: 'Unknown Browser',
      os: 'Unknown OS',
      type: 'unknown',
    };
  }

  const ua = userAgent.toLowerCase();
  let device = 'Desktop';
  let browser = 'Unknown';
  let os = 'Unknown';
  let type = 'desktop';

  // Detect OS
  if (ua.includes('iphone')) {
    os = 'iOS';
    device = 'iPhone';
    type = 'mobile';
  } else if (ua.includes('ipad')) {
    os = 'iPadOS';
    device = 'iPad';
    type = 'tablet';
  } else if (ua.includes('android')) {
    os = 'Android';
    device = ua.includes('mobile') ? 'Android Phone' : 'Android Tablet';
    type = ua.includes('mobile') ? 'mobile' : 'tablet';
  } else if (ua.includes('mac')) {
    os = 'macOS';
    device = 'Mac';
  } else if (ua.includes('windows')) {
    os = 'Windows';
    device = 'PC';
  } else if (ua.includes('linux')) {
    os = 'Linux';
    device = 'Linux PC';
  }

  // Detect browser
  if (ua.includes('chrome/')) browser = 'Chrome';
  else if (ua.includes('firefox/')) browser = 'Firefox';
  else if (ua.includes('safari/') && !ua.includes('chrome')) browser = 'Safari';
  else if (ua.includes('edge/')) browser = 'Edge';
  else if (ua.includes('opera/')) browser = 'Opera';

  return {
    device: device,
    browser: browser,
    os: os,
    type: type,
    full: `${device} • ${browser} on ${os}`,
  };
}

// Change password
app.post(
  '/api/users/change-password',
  authenticate,
  validateFields(['oldPassword', 'newPassword']),
  async (req, res) => {
    try {
      const { oldPassword, newPassword } = req.body;

      const result = await authService.changePassword(req.userId, oldPassword, newPassword);

      res.json(result);
    } catch (error) {
      res.status(400).json({
        error: 'Failed to change password',
        message: error.message,
      });
    }
  }
);

// Update user preferences
app.put('/api/users/preferences', authenticate, async (req, res) => {
  try {
    const { language, timezone, theme } = req.body;
    const user = await User.findById(req.userId);

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    if (!user.preferences) {
      user.preferences = {};
    }

    if (language) user.preferences.language = language;
    if (timezone) user.preferences.timezone = timezone;
    if (theme) user.preferences.theme = theme;

    await user.save();

    res.json({
      success: true,
      preferences: user.preferences,
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to update preferences',
      message: error.message,
    });
  }
});

// Update notification settings
app.put('/api/users/notifications', authenticate, async (req, res) => {
  try {
    const {
      email,
      sms,
      browser,
      chatMessages,
      agentUpdates,
      billingAlerts,
      systemUpdates,
      marketingEmails,
    } = req.body;
    const user = await User.findById(req.userId);

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    if (!user.notifications) {
      user.notifications = {};
    }

    // Update basic notification types
    if (typeof email !== 'undefined') user.notifications.email = email;
    if (typeof sms !== 'undefined') user.notifications.sms = sms;
    if (typeof browser !== 'undefined') user.notifications.browser = browser;

    // Update specific notification preferences
    if (typeof chatMessages !== 'undefined') user.notifications.chatMessages = chatMessages;
    if (typeof agentUpdates !== 'undefined') user.notifications.agentUpdates = agentUpdates;
    if (typeof billingAlerts !== 'undefined') user.notifications.billingAlerts = billingAlerts;
    if (typeof systemUpdates !== 'undefined') user.notifications.systemUpdates = systemUpdates;
    if (typeof marketingEmails !== 'undefined')
      user.notifications.marketingEmails = marketingEmails;

    await user.save();

    res.json({
      success: true,
      notifications: user.notifications,
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to update notifications',
      message: error.message,
    });
  }
});

// Update privacy settings
app.put('/api/users/privacy', authenticate, async (req, res) => {
  try {
    const { profileVisibility, dataCollection, searchIndexing } = req.body;
    const user = await User.findById(req.userId);

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    if (!user.privacy) {
      user.privacy = {};
    }

    if (typeof profileVisibility !== 'undefined')
      user.privacy.profileVisibility = profileVisibility;
    if (typeof dataCollection !== 'undefined') user.privacy.dataCollection = dataCollection;
    if (typeof searchIndexing !== 'undefined') user.privacy.searchIndexing = searchIndexing;

    await user.save();

    res.json({
      success: true,
      privacy: user.privacy,
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to update privacy settings',
      message: error.message,
    });
  }
});

// Get all user settings
app.get('/api/users/settings', authenticate, async (req, res) => {
  try {
    const user = await User.findById(req.userId).select(
      'preferences notifications privacy security'
    );

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json({
      success: true,
      settings: {
        preferences: user.preferences || { language: 'en', timezone: 'UTC', theme: 'dark' },
        notifications: user.notifications || {
          email: true,
          sms: false,
          browser: true,
          chatMessages: true,
          agentUpdates: true,
          billingAlerts: true,
          systemUpdates: false,
          marketingEmails: false,
        },
        privacy: user.privacy || {
          profileVisibility: 'private',
          dataCollection: true,
          searchIndexing: false,
        },
        security: user.security || {
          isSecured: true,
          passwordProtected: true,
          dataEncrypted: true,
        },
      },
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to fetch settings',
      message: error.message,
    });
  }
});

// Update password (PUT endpoint for dashboard)
app.put('/api/users/password', authenticate, async (req, res) => {
  try {
    const { oldPassword, newPassword } = req.body;

    if (!oldPassword || !newPassword) {
      return res.status(400).json({
        error: 'Old password and new password are required',
      });
    }

    const user = await User.findById(req.userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Verify old password
    const bcrypt = require('bcryptjs');
    const isValidPassword = await bcrypt.compare(oldPassword, user.password);

    if (!isValidPassword) {
      return res.status(400).json({
        error: 'Invalid old password',
        message: 'Current password is incorrect',
      });
    }

    // Hash and update new password
    const hashedPassword = await bcrypt.hash(newPassword, 10);
    user.password = hashedPassword;
    await user.save();

    res.json({
      success: true,
      message: 'Password updated successfully',
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to update password',
      message: error.message,
    });
  }
});

// ========== ENHANCED SECURITY ENDPOINTS ==========

// Enhanced Sessions with detailed device and location info - DISABLED (functions not available)
// app.get('/api/users/sessions/enhanced', authenticate, getEnhancedSessions);

// Enhanced Activity Log with comprehensive analytics - DISABLED (functions not available)
// app.get('/api/users/activity/enhanced', authenticate, getEnhancedActivity);

// Security Dashboard Summary - DISABLED (functions not available)
// app.get('/api/users/security/dashboard', authenticate, getSecurityDashboard);

// Backwards compatibility - redirect old endpoints to enhanced ones - DISABLED (functions not available)
// app.get('/api/users/login-activity', authenticate, getEnhancedActivity);

// ========== 2FA ENDPOINTS ==========

// Test route to check if this section is working
app.get('/api/users/2fa/test', (req, res) => {
  res.json({ success: true, message: '2FA section is working!' });
});

// Setup 2FA - Generate secret and QR code
app.post('/api/users/2fa/setup', authenticate, async (req, res) => {
  try {
    const speakeasy = require('speakeasy');
    const QRCode = require('qrcode');

    const user = await User.findById(req.userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Generate secret
    const secret = speakeasy.generateSecret({
      name: `IAMAI (${user.email})`,
      issuer: 'IAMAI Global',
      length: 32,
    });

    // Generate QR code
    const qrCodeUrl = await QRCode.toDataURL(secret.otpauth_url);

    // Save secret (but don't enable 2FA yet)
    user.security.twoFactorSecret = secret.base32;
    await user.save();

    res.json({
      success: true,
      secret: secret.base32,
      qrCode: qrCodeUrl,
      manualEntryKey: secret.base32,
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to setup 2FA',
      message: error.message,
    });
  }
});

// Enable 2FA - Verify token and enable
app.post('/api/users/2fa/enable', authenticate, async (req, res) => {
  try {
    const { token } = req.body;
    const speakeasy = require('speakeasy');

    if (!token) {
      return res.status(400).json({ error: 'Token is required' });
    }

    const user = await User.findById(req.userId);
    if (!user || !user.security.twoFactorSecret) {
      return res.status(400).json({ error: 'No 2FA setup found' });
    }

    // Verify token
    const verified = speakeasy.totp.verify({
      secret: user.security.twoFactorSecret,
      encoding: 'base32',
      token: token,
      window: 6,
    });

    if (!verified) {
      return res.status(400).json({ error: 'Invalid token' });
    }

    // Generate backup codes
    const backupCodes = [];
    for (let i = 0; i < 10; i++) {
      backupCodes.push(Math.random().toString(36).substr(2, 8).toUpperCase());
    }

    // Enable 2FA
    user.security.twoFactorEnabled = true;
    user.security.backupCodes = backupCodes;
    await user.save();

    res.json({
      success: true,
      message: '2FA enabled successfully',
      backupCodes: backupCodes,
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to enable 2FA',
      message: error.message,
    });
  }
});

// Disable 2FA
app.post('/api/users/2fa/disable', authenticate, async (req, res) => {
  try {
    const { password } = req.body;
    const bcrypt = require('bcryptjs');

    if (!password) {
      return res.status(400).json({ error: 'Password is required' });
    }

    const user = await User.findById(req.userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Verify password
    const isValidPassword = await bcrypt.compare(password, user.password);
    if (!isValidPassword) {
      return res.status(400).json({ error: 'Invalid password' });
    }

    // Disable 2FA
    user.security.twoFactorEnabled = false;
    user.security.twoFactorSecret = undefined;
    user.security.backupCodes = [];
    await user.save();

    res.json({
      success: true,
      message: '2FA disabled successfully',
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to disable 2FA',
      message: error.message,
    });
  }
});

// ========== EMAIL CHANGE ENDPOINTS ==========

// Request email change - Send verification to new email
app.post('/api/users/change-email/request', authenticate, async (req, res) => {
  try {
    const { newEmail, password } = req.body;
    const bcrypt = require('bcryptjs');
    const crypto = require('crypto');

    if (!newEmail || !password) {
      return res.status(400).json({ error: 'New email and password are required' });
    }

    const user = await User.findById(req.userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Verify password
    const isValidPassword = await bcrypt.compare(password, user.password);
    if (!isValidPassword) {
      return res.status(400).json({ error: 'Invalid password' });
    }

    // Check if new email is already taken
    const existingUser = await User.findOne({ email: newEmail });
    if (existingUser) {
      return res.status(400).json({ error: 'Email already in use' });
    }

    // Generate verification token
    const verificationToken = crypto.randomBytes(32).toString('hex');

    // Store pending email change (you could use a separate collection for this)
    // For now, storing in metadata
    user.metadata.pendingEmailChange = {
      newEmail: newEmail,
      token: verificationToken,
      expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000), // 24 hours
    };
    await user.save();

    // TODO: Send verification email to newEmail with verificationToken
    // For demo purposes, returning token (in production, only send via email)

    res.json({
      success: true,
      message: 'Verification email sent to new address',
      // Remove this in production:
      debugToken: verificationToken,
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to request email change',
      message: error.message,
    });
  }
});

// Confirm email change
app.post('/api/users/change-email/confirm', async (req, res) => {
  try {
    const { token } = req.body;

    if (!token) {
      return res.status(400).json({ error: 'Verification token is required' });
    }

    const user = await User.findOne({
      'metadata.pendingEmailChange.token': token,
      'metadata.pendingEmailChange.expiresAt': { $gt: new Date() },
    });

    if (!user) {
      return res.status(400).json({ error: 'Invalid or expired token' });
    }

    // Update email
    const newEmail = user.metadata.pendingEmailChange.newEmail;
    user.email = newEmail;
    user.metadata.pendingEmailChange = undefined;
    await user.save();

    res.json({
      success: true,
      message: 'Email updated successfully',
      newEmail: newEmail,
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to confirm email change',
      message: error.message,
    });
  }
});

// Get user credits
app.get('/api/users/credits', authenticate, async (req, res) => {
  try {
    const user = await authService.getUserById(req.userId);

    res.json({
      credits: user.credits,
      tier: user.tier,
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to fetch credits',
    });
  }
});

// ========== CHAT ENDPOINTS ==========

// Simple activity tracking endpoint (for frontend page views and events)
app.post('/api/analytics/track', async (req, res) => {
  try {
    const { action, metadata } = req.body;
    const sessionId = getSessionId(req);

    // Get user ID if authenticated (optional)
    let userId = null;
    const authHeader = req.headers.authorization;
    if (authHeader) {
      try {
        const token = authHeader.replace('Bearer ', '');
        const decoded = jwt.verify(token, JWT_SECRET);
        userId = decoded.id;
      } catch (err) {
        // User not authenticated, leave userId as null
      }
    }

    // Create activity log
    await logActivity(ActivityLog, {
      userId: userId,
      sessionId: sessionId,
      action: action || 'PAGE_VIEW',
      route: req.path,
      method: req.method,
      statusCode: 200,
      ipAddress:
        req.headers['x-forwarded-for']?.split(',')[0] || req.connection?.remoteAddress || 'unknown',
      userAgent: req.headers['user-agent'] || 'unknown',
      isAnonymous: !userId,
      metadata: metadata || {},
    });

    res.json({ success: true });
  } catch (error) {
    console.error('Failed to track activity:', error);
    res.status(500).json({ success: false, error: 'Failed to track activity' });
  }
});

// Get all conversations for authenticated user
app.get('/api/chat/conversations', authenticate, async (req, res) => {
  try {
    const chats = await Chat.find({ userId: req.userId })
      .populate('agentId', 'name avatar')
      .sort({ updatedAt: -1 })
      .limit(50);

    res.json(
      chats.map(chat => ({
        id: chat._id,
        agentId: chat.agentId._id,
        agentName: chat.agentId.name,
        agentAvatar: chat.agentId.avatar,
        title: chat.title || `Chat with ${chat.agentId.name}`,
        lastMessage:
          chat.messages.length > 0 ? chat.messages[chat.messages.length - 1].content : '',
        messageCount: chat.messages.length,
        updatedAt: chat.updatedAt,
        createdAt: chat.createdAt,
      }))
    );
  } catch (error) {
    res.status(500).json({
      error: 'Failed to fetch conversations',
      message: error.message,
    });
  }
});

// Get specific conversation
app.get('/api/chat/conversations/:id', authenticate, async (req, res) => {
  try {
    const chat = await Chat.findOne({
      _id: req.params.id,
      userId: req.userId,
    }).populate('agentId', 'name avatar');

    if (!chat) {
      return res.status(404).json({ error: 'Conversation not found' });
    }

    res.json({
      id: chat._id,
      agentId: chat.agentId._id,
      agentName: chat.agentId.name,
      title: chat.title || `Chat with ${chat.agentId.name}`,
      messages: chat.messages,
      createdAt: chat.createdAt,
      updatedAt: chat.updatedAt,
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to fetch conversation',
      message: error.message,
    });
  }
});

// ========== ANALYTICS ENDPOINTS ==========

// Get dashboard statistics
app.get('/api/dashboard/stats', authenticate, async (req, res) => {
  try {
    const stats = await authService.getUserStats(req.userId);
    const user = stats.user;

    // Get usage analytics for last 30 days
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

    const usageData = await UsageAnalytics.find({
      userId: req.userId,
      timestamp: { $gte: thirtyDaysAgo },
    }).sort({ timestamp: 1 });

    // Calculate total messages
    const totalMessages = usageData.length;

    // Calculate messages this month
    const firstOfMonth = new Date();
    firstOfMonth.setDate(1);
    firstOfMonth.setHours(0, 0, 0, 0);
    const messagesThisMonth = usageData.filter(
      record => new Date(record.timestamp) >= firstOfMonth
    ).length;

    // Get active purchases (NEW SIMPLE PURCHASE SYSTEM)
    const activePurchases = await AgentPurchase.find({
      userId: req.userId,
      status: 'ACTIVE',
      expiresAt: { $gt: new Date() },
    });

    // All paid plans have unlimited messages
    const messageLimit = activePurchases.length > 0 ? 'Unlimited' : 10; // Free tier: 10 messages/day

    // Count unique agents used
    const uniqueAgents = new Set(usageData.map(record => record.agentId).filter(Boolean));
    const agentsUsed = uniqueAgents.size;

    // Count active agents - based on ACTIVE purchases (not just usage in last 7 days)
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
    const recentUsage = usageData.filter(record => new Date(record.timestamp) >= sevenDaysAgo);
    // Active agents = purchased agents count (shows agents with active subscriptions)
    const activeAgents =
      activePurchases.length ||
      new Set(recentUsage.map(record => record.agentId).filter(Boolean)).size;

    // Calculate average response time (simulated for now)
    const avgResponseTime =
      recentUsage.length > 0
        ? recentUsage.reduce((sum, record) => sum + (record.responseTime || 1.5), 0) /
          recentUsage.length
        : 1.2; // Default to 1.2s if no data

    // Calculate success rate (assume most are successful)
    const successRate = usageData.length > 0 ? 98.5 : 99.9; // Show 99.9% even with no data (system is healthy)

    // Calculate total session time (hours)
    const totalSessionTime =
      usageData.reduce((sum, record) => sum + (record.sessionDuration || 0), 0) / 3600; // Convert seconds to hours

    // Agent usage breakdown - combines purchased agents with usage data
    const agentCounts = {};
    const agentLastUsed = {};
    usageData.forEach(record => {
      if (record.agentId) {
        agentCounts[record.agentId] = (agentCounts[record.agentId] || 0) + 1;
        agentLastUsed[record.agentId] = record.timestamp;
      }
    });

    // Agent name mapping for display
    const agentNameMap = {
      'ai-girlfriend': 'AI Girlfriend',
      agentx: 'Agent X',
      autochat: 'AutoChat',
      'chat-revive': 'Chat Revive',
      chatrevive: 'Chat Revive',
      'comedy-chad': 'Comedy Chad',
      comedychad: 'Comedy Chad',
      'content-creator': 'Content Creator',
      contentcreator: 'Content Creator',
      'emo-ai': 'Emo AI',
      emoai: 'Emo AI',
      'tok-boost': 'TokBoost',
      tokboost: 'TokBoost',
      'you-gen': 'YouGen',
      yougen: 'YouGen',
      'hype-boy': 'Hype Boy',
      hypeboy: 'Hype Boy',
    };

    // Build agent usage list from purchased agents + usage data
    const agentUsageMap = new Map();

    // First, add all active purchased agents (even with 0 usage)
    for (const purchase of activePurchases) {
      const agentId = purchase.agentId.toLowerCase();
      const displayName = agentNameMap[agentId] || purchase.agentName || agentId;
      const usageCount = agentCounts[agentId] || agentCounts[purchase.agentId] || 0;
      const lastUsedTimestamp = agentLastUsed[agentId] || agentLastUsed[purchase.agentId];

      let lastUsedText = 'Not used yet';
      if (lastUsedTimestamp) {
        const lastUsedDate = new Date(lastUsedTimestamp);
        const hoursAgo = Math.floor((Date.now() - lastUsedDate.getTime()) / (1000 * 60 * 60));
        lastUsedText =
          hoursAgo < 1
            ? 'Just now'
            : hoursAgo < 24
              ? `${hoursAgo} hours ago`
              : `${Math.floor(hoursAgo / 24)} days ago`;
      }

      agentUsageMap.set(agentId, {
        agentId,
        name: displayName,
        messages: usageCount,
        lastUsed: lastUsedText,
        plan: purchase.plan,
        status: 'ACTIVE',
        expiresAt: purchase.expiresAt,
      });
    }

    // Then add any additional agents from usage data that aren't purchased
    for (const [agentId, count] of Object.entries(agentCounts)) {
      const normalizedId = agentId.toLowerCase();
      if (!agentUsageMap.has(normalizedId)) {
        const displayName = agentNameMap[normalizedId] || agentId;
        const lastUsedDate = new Date(agentLastUsed[agentId]);
        const hoursAgo = Math.floor((Date.now() - lastUsedDate.getTime()) / (1000 * 60 * 60));
        const lastUsedText =
          hoursAgo < 1
            ? 'Just now'
            : hoursAgo < 24
              ? `${hoursAgo} hours ago`
              : `${Math.floor(hoursAgo / 24)} days ago`;

        agentUsageMap.set(normalizedId, {
          agentId: normalizedId,
          name: displayName,
          messages: count,
          lastUsed: lastUsedText,
          plan: null,
          status: 'FREE_TRIAL',
        });
      }
    }

    // Convert to array and sort by messages (most used first), then by name
    const agentUsage = Array.from(agentUsageMap.values())
      .sort((a, b) => {
        // Sort by messages descending first
        if (b.messages !== a.messages) return b.messages - a.messages;
        // Then by status (ACTIVE first)
        if (a.status === 'ACTIVE' && b.status !== 'ACTIVE') return -1;
        if (b.status === 'ACTIVE' && a.status !== 'ACTIVE') return 1;
        // Then by name
        return a.name.localeCompare(b.name);
      })
      .slice(0, 5) // Top 5 agents
      .map(agent => ({
        ...agent,
        percentage: totalMessages > 0 ? Math.round((agent.messages / totalMessages) * 100) : 0,
      }));

    // Daily usage for last 7 days
    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const dailyUsage = [];
    for (let i = 6; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      date.setHours(0, 0, 0, 0);

      const nextDate = new Date(date);
      nextDate.setDate(nextDate.getDate() + 1);

      const dayUsage = usageData.filter(record => {
        const recordDate = new Date(record.timestamp);
        return recordDate >= date && recordDate < nextDate;
      });

      dailyUsage.push({
        date: days[date.getDay()],
        messages: dayUsage.length,
        sessions: new Set(dayUsage.map(r => r.sessionId || r._id)).size,
        duration: dayUsage.reduce((sum, r) => sum + (r.sessionDuration || 0), 0) / 3600,
      });
    }

    // Shape response for both legacy and new dashboard widgets
    const favoriteAgentName = agentUsage[0]?.name || 'None';

    // New nested structure expected by frontend widgets
    const dashboardStats = {
      totalMessages,
      activeAgents,
      avgResponseTime: parseFloat(avgResponseTime.toFixed(1)),
      successRate: parseFloat(successRate.toFixed(1)),
      favoriteAgent: favoriteAgentName,
      activeSince: user?.createdAt || null,
      documentsAnalyzed: 0,
      agentUsage,
    };

    res.json({ success: true, stats: dashboardStats, dailyUsage, agentUsage });
  } catch (error) {
    console.error('Dashboard stats error:', error);
    res.status(500).json({
      error: 'Failed to fetch dashboard stats',
      message: error.message,
    });
  }
});

// Get user analytics
app.get('/api/analytics/usage', authenticate, async (req, res) => {
  try {
    const stats = await authService.getUserStats(req.userId);

    // Get usage analytics for last 30 days
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

    const usageData = await UsageAnalytics.find({
      userId: req.userId,
      timestamp: { $gte: thirtyDaysAgo },
    });

    const totalCreditsUsed = usageData.reduce((sum, record) => sum + (record.creditsUsed || 0), 0);
    const totalChats = stats.stats.totalChats;

    // Find favorite agent
    const agentCounts = {};
    usageData.forEach(record => {
      if (record.agentId) {
        agentCounts[record.agentId] = (agentCounts[record.agentId] || 0) + 1;
      }
    });

    const favoriteAgentId =
      Object.keys(agentCounts).length > 0
        ? Object.keys(agentCounts).reduce((a, b) => (agentCounts[a] > agentCounts[b] ? a : b))
        : null;

    let favoriteAgent = null;
    if (favoriteAgentId) {
      const agent = await Agent.findById(favoriteAgentId);
      favoriteAgent = agent ? agent.name : 'Unknown';
    }

    res.json({
      totalChats,
      totalCreditsUsed,
      favoriteAgent: favoriteAgent || 'None yet',
      currentCredits: stats.user.credits,
      tier: stats.user.tier,
      period: 'last_30_days',
      dailyUsage: stats.stats.todayChats,
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to fetch analytics',
      message: error.message,
    });
  }
});

// ============================================
// ============================================
// OLD SUBSCRIPTION SYSTEM - REMOVED
// ============================================
// The complex subscription system has been replaced with simple one-time purchases.
// All subscription endpoints have been removed:
//   - /api/subscription/current (replaced by /api/purchases/active)
//   - /api/subscription/plans (still available via /api/subscription/plans)
//   - /api/subscription/change-plan (REMOVED - no upgrades/downgrades)
//   - /api/subscription/cancel (replaced by /api/purchases/:id/cancel)
//   - /api/subscription/record-usage (no limits - unlimited messages)
//   - /api/subscription/billing-history (replaced by /api/purchases/history)
//
// NEW SIMPLE PURCHASE SYSTEM:
//   - GET  /api/agents/:agentId/access (check if user has active access)
//   - POST /api/agents/:agentId/purchase (buy one-time access)
//   - GET  /api/purchases/active (all active purchases)
//   - POST /api/purchases/:purchaseId/cancel (cancel purchase)
//   - GET  /api/purchases/history (purchase history)
//
// Business Rules:
//   - One active plan per specific agent at a time
//   - Can buy multiple DIFFERENT agents simultaneously
//   - No upgrades, downgrades, renewals, or prorations
//   - Access expires naturally, then user can repurchase
// ============================================

// ========== WEBSOCKET ENDPOINTS ==========

// Get online users
app.get('/api/websocket/online-users', authenticate, (req, res) => {
  try {
    const onlineUsers = wsService.getOnlineUsers();
    const count = wsService.getOnlineCount();

    res.json({
      users: onlineUsers,
      count,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to fetch online users',
      message: error.message,
    });
  }
});

// Get WebSocket connection status
app.get('/api/websocket/status', authenticate, (req, res) => {
  try {
    const isOnline = wsService.isUserOnline(req.userId);
    const onlineCount = wsService.getOnlineCount();

    res.json({
      connected: isOnline,
      userId: req.userId,
      totalOnline: onlineCount,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to fetch connection status',
      message: error.message,
    });
  }
});

// Send message to user via WebSocket
app.post(
  '/api/websocket/send-to-user',
  authenticate,
  requireTier('PRO', 'ENTERPRISE'),
  (req, res) => {
    try {
      const { targetUserId, event, data } = req.body;

      if (!targetUserId || !event) {
        return res.status(400).json({ error: 'Target user ID and event required' });
      }

      const sent = wsService.sendToUser(targetUserId, event, {
        ...data,
        fromUserId: req.userId,
        timestamp: new Date().toISOString(),
      });

      res.json({
        success: sent,
        message: sent ? 'Message sent' : 'User not online',
        targetUserId,
        event,
      });
    } catch (error) {
      res.status(500).json({
        error: 'Failed to send message',
        message: error.message,
      });
    }
  }
);

// Broadcast system message (admin only)
app.post('/api/websocket/broadcast', authenticate, requireTier('ENTERPRISE'), (req, res) => {
  try {
    const { event, data, message } = req.body;

    if (!event) {
      return res.status(400).json({ error: 'Event required' });
    }

    wsService.broadcast(event, {
      ...data,
      message,
      fromSystem: true,
      timestamp: new Date().toISOString(),
    });

    res.json({
      success: true,
      message: 'Broadcast sent',
      recipients: wsService.getOnlineCount(),
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to broadcast',
      message: error.message,
    });
  }
});

// ========== PAYMENT ENDPOINTS ==========

// Stripe real-time checkout integration (replaces previous mock implementation)
let stripe = null;
if (process.env.STRIPE_SECRET_KEY) {
  try {
    const Stripe = require('stripe');
    stripe = new Stripe(process.env.STRIPE_SECRET_KEY, { apiVersion: '2024-06-20' });
    console.log('✅ Stripe initialized');
    async function ensureStripePrices() {
      const needed = [
        { key: 'STRIPE_PRICE_DAILY', nickname: 'Daily Plan', amount: 100 },
        { key: 'STRIPE_PRICE_WEEKLY', nickname: 'Weekly Plan', amount: 500 },
        { key: 'STRIPE_PRICE_MONTHLY', nickname: 'Monthly Plan', amount: 1900 },
      ];
      for (const p of needed) {
        if (!process.env[p.key]) {
          const product = await stripe.products.create({ name: p.nickname });
          const price = await stripe.prices.create({
            unit_amount: p.amount,
            currency: 'usd',
            product: product.id,
          }); // One-time payment, no recurring
          process.env[p.key] = price.id;
          console.log(
            `⚙️ Created ${p.nickname} price ${price.id}. Add to .env as ${p.key}=${price.id}`
          );
        }
      }
    }
    ensureStripePrices().catch(e => console.error('Price ensure error', e.message));
  } catch (e) {
    console.error('❌ Failed to initialize Stripe:', e.message);
  }
} else {
  console.warn('⚠️ STRIPE_SECRET_KEY not set. Checkout endpoint will return configuration error.');
}

app.post('/api/payments/create-checkout', authenticate, async (req, res) => {
  try {
    const { plan, agentId, agentName } = req.body;
    const userId = req.userId;

    if (!plan) {
      return res.status(400).json({ success: false, error: 'Plan is required' });
    }

    if (!stripe) {
      return res.status(503).json({ success: false, error: 'Stripe not configured' });
    }

    // Map plan to price IDs from environment
    const priceMap = {
      daily: process.env.STRIPE_PRICE_DAILY,
      weekly: process.env.STRIPE_PRICE_WEEKLY,
      monthly: process.env.STRIPE_PRICE_MONTHLY,
    };

    const priceId = priceMap[plan];
    if (!priceId) {
      return res.status(400).json({ success: false, error: 'Price ID not configured for plan' });
    }

    // Ensure user has Stripe customer ID (create if missing)
    let user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ success: false, error: 'User not found' });
    }

    let customerId = user.stripeCustomerId;

    // Validate existing customer ID with Stripe
    if (customerId) {
      try {
        await stripe.customers.retrieve(customerId);
        console.log('✅ Validated existing Stripe customer:', customerId);
      } catch (error) {
        console.log('⚠️ Invalid customer ID in database, creating new one');
        customerId = null; // Reset to create new customer
      }
    }

    if (!customerId) {
      console.log('Creating new Stripe customer for user:', user.email);
      const customer = await stripe.customers.create({
        email: user.email,
        name: user.name || user.email.split('@')[0],
        metadata: { userId: user._id.toString() },
      });
      customerId = customer.id;
      user.stripeCustomerId = customerId;
      await user.save();
      console.log('✅ Created Stripe customer:', customerId);
    }

    console.log('Creating checkout session with customer:', customerId);

    // Build success and cancel URLs with agent info
    const baseUrl = process.env.FRONTEND_BASE_URL || 'https://iamai.global';
    const successParams = new URLSearchParams({ plan });
    const cancelParams = new URLSearchParams({ plan });

    if (agentId) {
      successParams.set('agent', agentId);
      cancelParams.set('agent', agentId);
      cancelParams.set('status', 'cancelled');
    }

    const successUrl = `${baseUrl}/thank-you?${successParams.toString()}`;
    const cancelUrl = agentId
      ? `${baseUrl}/pricing?${cancelParams.toString()}`
      : `${baseUrl}/pricing`;

    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      payment_method_types: ['card'],
      customer: customerId,
      line_items: [{ price: priceId, quantity: 1 }],
      success_url: successUrl,
      cancel_url: cancelUrl,
      metadata: {
        userId: user._id.toString(),
        plan,
        agentId: agentId || '',
        agentName: agentName || '',
      },
    });

    res.json({ success: true, url: session.url, sessionId: session.id });
  } catch (error) {
    console.error('Checkout error:', error);
    res
      .status(500)
      .json({ success: false, error: 'Failed to create checkout session', message: error.message });
  }
});

app.get('/api/payments/subscription/status', authenticate, async (req, res) => {
  try {
    if (!stripe) return res.status(503).json({ success: false, error: 'Stripe not configured' });
    const user = await User.findById(req.userId);
    if (!user) return res.status(404).json({ success: false, error: 'User not found' });

    // Simple cache (60s)
    const cacheKey = `sub:${user._id.toString()}`;
    global.subscriptionCache = global.subscriptionCache || new Map();
    if (global.subscriptionCache && global.subscriptionCache.has(cacheKey)) {
      const cached = global.subscriptionCache.get(cacheKey);
      if (Date.now() - cached.timestamp < 60000) {
        return res.json(cached.payload);
      }
    }

    if (!user.stripeCustomerId) {
      const payload = { success: true, currentPlan: 'NONE', subscriptionStatus: 'NONE' };
      global.subscriptionCache = global.subscriptionCache || new Map();
      global.subscriptionCache.set(cacheKey, { timestamp: Date.now(), payload });
      return res.json(payload);
    }

    // Validate customer ID before using it
    try {
      await stripe.customers.retrieve(user.stripeCustomerId);
    } catch (error) {
      console.log('⚠️ Invalid customer ID, clearing:', user.stripeCustomerId);
      user.stripeCustomerId = null;
      await user.save();
      const payload = { success: true, currentPlan: 'NONE', subscriptionStatus: 'NONE' };
      global.subscriptionCache = global.subscriptionCache || new Map();
      global.subscriptionCache.set(cacheKey, { timestamp: Date.now(), payload });
      return res.json(payload);
    }

    const subs = await stripe.subscriptions.list({
      customer: user.stripeCustomerId,
      status: 'all',
      limit: 1,
    });
    if (!subs.data.length)
      return res.json({ success: true, currentPlan: 'NONE', subscriptionStatus: 'NONE' });
    const sub = subs.data[0];
    const priceId = sub.items.data[0].price.id;
    let planName = 'NONE';
    if (priceId === process.env.STRIPE_PRICE_DAILY) planName = 'DAILY';
    else if (priceId === process.env.STRIPE_PRICE_WEEKLY) planName = 'WEEKLY';
    else if (priceId === process.env.STRIPE_PRICE_MONTHLY) planName = 'MONTHLY';
    user.currentPlan = planName;
    user.subscriptionStatus = sub.status.toUpperCase();
    user.subscriptionPeriodEnd = new Date(sub.current_period_end * 1000);
    user.stripeSubscriptionId = sub.id;
    await user.save();
    const payload = {
      success: true,
      currentPlan: planName,
      subscriptionStatus: user.subscriptionStatus,
      periodEnd: user.subscriptionPeriodEnd,
      subscriptionId: sub.id,
    };
    global.subscriptionCache.set(cacheKey, { timestamp: Date.now(), payload });
    res.json(payload);
  } catch (e) {
    console.error('Subscription status error', e.message);
    res.status(500).json({ success: false, error: 'Failed to fetch subscription status' });
  }
});

app.post('/api/payments/webhook', async (req, res) => {
  if (!stripe || !process.env.STRIPE_WEBHOOK_SECRET)
    return res.status(503).json({ success: false, error: 'Webhook not configured' });
  const sig = req.headers['stripe-signature'];
  let event;
  try {
    event = stripe.webhooks.constructEvent(
      req.rawBody || req.body,
      sig,
      process.env.STRIPE_WEBHOOK_SECRET
    );
  } catch (err) {
    return res.status(400).json({ success: false, error: 'Webhook signature verification failed' });
  }
  try {
    // === ONE-TIME PURCHASE SYSTEM (New) ===
    // NOTE: Legacy one-time purchase handling removed in favor of the
    // unified AgentPurchase model in agent-purchase-models.js.
    // Checkout sessions for subscriptions are still processed below.

    // === LEGACY SUBSCRIPTION SYSTEM (Keep for now) ===
    if (
      event.type === 'customer.subscription.updated' ||
      event.type === 'customer.subscription.created'
    ) {
      const sub = event.data.object;
      const customerId = sub.customer;
      const user = await User.findOne({ stripeCustomerId: customerId });
      if (user) {
        const priceId = sub.items.data[0].price.id;
        let planName = 'NONE';
        if (priceId === process.env.STRIPE_PRICE_DAILY) planName = 'DAILY';
        else if (priceId === process.env.STRIPE_PRICE_WEEKLY) planName = 'WEEKLY';
        else if (priceId === process.env.STRIPE_PRICE_MONTHLY) planName = 'MONTHLY';
        user.currentPlan = planName;
        user.subscriptionStatus = sub.status.toUpperCase();
        user.subscriptionPeriodEnd = new Date(sub.current_period_end * 1000);
        user.stripeSubscriptionId = sub.id;
        if (sub.status === 'active') user.tier = 'PRO';
        await user.save();
        // Invalidate cache
        if (global.subscriptionCache) {
          global.subscriptionCache.delete(`sub:${user._id.toString()}`);
        }
      }
    }
    res.json({ received: true });
  } catch (err) {
    console.error('Webhook processing error', err.message);
    res.status(500).json({ success: false });
  }
});

// Cancel at period end
app.post('/api/payments/subscription/cancel', authenticate, async (req, res) => {
  try {
    if (!stripe) return res.status(503).json({ success: false, error: 'Stripe not configured' });
    const user = await User.findById(req.userId);
    if (!user || !user.stripeSubscriptionId)
      return res.status(404).json({ success: false, error: 'No active subscription' });
    const updated = await stripe.subscriptions.update(user.stripeSubscriptionId, {
      cancel_at_period_end: true,
    });
    user.subscriptionStatus = updated.status.toUpperCase();
    await user.save();
    if (global.subscriptionCache) global.subscriptionCache.delete(`sub:${user._id.toString()}`);
    res.json({
      success: true,
      subscriptionStatus: user.subscriptionStatus,
      cancelAtPeriodEnd: updated.cancel_at_period_end,
    });
  } catch (e) {
    console.error('Cancel error', e.message);
    res.status(500).json({ success: false, error: 'Failed to cancel subscription' });
  }
});

// Immediate cancellation
app.post('/api/payments/subscription/cancel-now', authenticate, async (req, res) => {
  try {
    if (!stripe) return res.status(503).json({ success: false, error: 'Stripe not configured' });
    const user = await User.findById(req.userId);
    if (!user || !user.stripeSubscriptionId)
      return res.status(404).json({ success: false, error: 'No active subscription' });
    const canceled = await stripe.subscriptions.cancel(user.stripeSubscriptionId);
    user.subscriptionStatus = canceled.status.toUpperCase();
    user.currentPlan = 'NONE';
    await user.save();
    if (global.subscriptionCache) global.subscriptionCache.delete(`sub:${user._id.toString()}`);
    res.json({ success: true, subscriptionStatus: user.subscriptionStatus });
  } catch (e) {
    console.error('Immediate cancel error', e.message);
    res.status(500).json({ success: false, error: 'Failed to cancel subscription immediately' });
  }
});

// Grant one-time agent access after successful checkout (manual grant)
// This uses the unified AgentPurchase model from agent-purchase-models.js
// and is idempotent per user+agent while an active purchase exists.
app.post('/api/purchases/grant', authenticate, async (req, res) => {
  try {
    const { agentId, plan } = req.body || {};

    if (!agentId || !plan) {
      return res.status(400).json({ success: false, error: 'agentId and plan are required' });
    }

    // Normalize identifiers to match legacy AgentPurchase schema
    const normalizedAgentId = String(agentId).toLowerCase();
    const normalizedPlan = String(plan).toUpperCase(); // DAILY | WEEKLY | MONTHLY
    const planType = normalizedPlan.toLowerCase(); // daily | weekly | monthly

    if (!['DAILY', 'WEEKLY', 'MONTHLY'].includes(normalizedPlan)) {
      return res
        .status(400)
        .json({ success: false, error: 'Invalid plan. Must be daily, weekly, or monthly' });
    }

    // If user already has an active purchase for this agent, just return it
    const existing = await AgentPurchase.findActivePurchase(req.userId, normalizedAgentId);
    if (existing) {
      return res.json({ success: true, purchase: existing, alreadyActive: true });
    }

    // Simple inline plan configuration for IAMAI pricing
    const PLAN_CONFIGS = {
      DAILY: {
        name: 'Daily Access',
        amount: 1,
        durationDays: 1,
      },
      WEEKLY: {
        name: 'Weekly Pro',
        amount: 5,
        durationDays: 7,
      },
      MONTHLY: {
        name: 'Monthly Unlimited',
        amount: 19,
        durationDays: 30,
      },
    };

    const planConfig = PLAN_CONFIGS[normalizedPlan];
    if (!planConfig) {
      return res.status(400).json({ success: false, error: 'Invalid plan configuration' });
    }

    const user = await User.findById(req.userId).lean();
    if (!user) {
      return res.status(404).json({ success: false, error: 'User not found' });
    }

    const purchaseDate = new Date();
    // Use unified helper to compute expiration date based on plan
    const expiresAt = AgentPurchase.calculateExpiration
      ? AgentPurchase.calculateExpiration(normalizedPlan, purchaseDate)
      : new Date(purchaseDate.getTime() + planConfig.durationDays * 24 * 60 * 60 * 1000);

    // Generate fake-but-unique Stripe identifiers so the legacy schema validates
    const uniqueSuffix = `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
    const stripePaymentIntentId = `manual_intent_${uniqueSuffix}`;
    const stripeCheckoutSessionId = `manual_session_${uniqueSuffix}`;

    const purchase = new AgentPurchase({
      userId: req.userId,
      email: user.email,
      agentId: normalizedAgentId,
      agentName: normalizedAgentId,
      // Unified plan fields
      plan: normalizedPlan,
      planName: planConfig.name,
      pricing: {
        amount: planConfig.amount,
        currency: 'USD',
      },
      // Legacy compatibility fields
      planType, // daily | weekly | monthly
      amount: planConfig.amount,
      currency: 'usd',
      purchaseDate,
      expiresAt,
      expirationDate: expiresAt,
      status: 'ACTIVE',
      stripePaymentIntentId, // Always has a value (manual_intent_*)
      stripeCheckoutSessionId,
      // Store richer metadata so newer code can read plan/price details
      metadata: {
        version: 'simple-purchase-v2',
        plan: normalizedPlan,
        planName: planConfig.name,
        pricing: {
          amount: planConfig.amount,
          currency: 'USD',
        },
      },
    });

    await purchase.save();

    console.log('✅ Granted one-time access via /api/purchases/grant:', {
      userId: req.userId.toString(),
      agentId: normalizedAgentId,
      plan: normalizedPlan,
      expiresAt,
    });

    return res.json({ success: true, purchase });
  } catch (e) {
    console.error('❌ Failed to grant one-time purchase:', e);
    return res.status(500).json({ success: false, error: 'Failed to grant purchase' });
  }
});

// Activate PENDING purchases (fallback when webhook fails)
// Called from Thank-You page to ensure purchase gets activated
app.post('/api/purchases/activate', authenticate, async (req, res) => {
  try {
    const { agentId, plan } = req.body || {};
    const userId = req.userId;

    if (!agentId) {
      return res.status(400).json({ success: false, error: 'agentId is required' });
    }

    const normalizedAgentId = String(agentId).toLowerCase();

    // Find PENDING purchase for this user and agent (created in last hour)
    const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000);

    const pendingPurchase = await AgentPurchase.findOne({
      userId,
      agentId: normalizedAgentId,
      status: 'PENDING',
      createdAt: { $gte: oneHourAgo },
    }).sort({ createdAt: -1 }); // Get most recent

    if (!pendingPurchase) {
      // No pending purchase - check if already active
      const activePurchase = await AgentPurchase.findOne({
        userId,
        agentId: normalizedAgentId,
        status: 'ACTIVE',
        expiresAt: { $gt: new Date() },
      });

      if (activePurchase) {
        console.log('✅ Purchase already active for:', normalizedAgentId);
        return res.json({
          success: true,
          message: 'Purchase already active',
          purchase: activePurchase,
        });
      }

      return res.json({
        success: false,
        error: 'No pending purchase found',
        message: 'No recent pending purchase found for this agent',
      });
    }

    // Activate the pending purchase
    pendingPurchase.status = 'ACTIVE';
    pendingPurchase.paymentStatus = 'SUCCESS';
    pendingPurchase.metadata = {
      ...(pendingPurchase.metadata || {}),
      activated_by: 'thank_you_page_fallback',
      activated_at: new Date().toISOString(),
    };

    await pendingPurchase.save();

    // Log the purchase activity
    try {
      await ActivityLog.create({
        userId: userId,
        sessionId: `purchase_${pendingPurchase._id}`,
        action: 'AGENT_PURCHASED',
        route: '/api/purchases/activate',
        method: 'POST',
        statusCode: 200,
        metadata: {
          agentId: normalizedAgentId,
          agentName: pendingPurchase.agentName || normalizedAgentId,
          plan: pendingPurchase.plan,
          purchaseId: pendingPurchase._id.toString(),
          amount: pendingPurchase.pricing?.amount || 0,
        },
        isAnonymous: false,
      });
      console.log('[ACTIVITY] AGENT_PURCHASED logged for user:', userId);
    } catch (logError) {
      console.error('[ACTIVITY] Failed to log AGENT_PURCHASED:', logError);
    }

    console.log('✅ Activated PENDING purchase via fallback:', {
      purchaseId: pendingPurchase._id,
      userId: userId.toString(),
      agentId: normalizedAgentId,
      plan: pendingPurchase.plan,
    });

    return res.json({
      success: true,
      message: 'Purchase activated successfully',
      purchase: pendingPurchase,
    });
  } catch (e) {
    console.error('❌ Failed to activate purchase:', e);
    return res.status(500).json({ success: false, error: 'Failed to activate purchase' });
  }
});

// Invoice history
app.get('/api/payments/invoices', authenticate, async (req, res) => {
  try {
    if (!stripe) return res.status(503).json({ success: false, error: 'Stripe not configured' });
    const user = await User.findById(req.userId);
    if (!user || !user.stripeCustomerId) return res.json({ success: true, invoices: [] });
    const invoices = await stripe.invoices.list({ customer: user.stripeCustomerId, limit: 10 });
    res.json({
      success: true,
      invoices: invoices.data.map(inv => ({
        id: inv.id,
        number: inv.number,
        created: inv.created,
        status: inv.status,
        total: inv.total,
        currency: inv.currency,
        pdf: inv.invoice_pdf,
        hostedInvoiceUrl: inv.hosted_invoice_url,
      })),
    });
  } catch (e) {
    console.error('Invoices error', e.message);
    res.status(500).json({ success: false, error: 'Failed to fetch invoices' });
  }
});

app.get('/api/payments/subscription', (req, res) => {
  res.json({
    plan: 'free',
    status: 'active',
    credits: 100,
    nextBillingDate: null,
  });
});

// ========== CONTACT & SUPPORT ENDPOINTS ==========

app.post('/api/contact', (req, res) => {
  const { name, email, subject, message } = req.body;

  if (!email || !message) {
    return res.status(400).json({
      success: false,
      error: 'Email and message are required',
    });
  }

  res.json({
    success: true,
    message: 'Your message has been sent successfully',
    ticketId: 'ticket_' + Date.now(),
  });
});

app.get('/api/tickets', (req, res) => {
  res.json([
    {
      id: 'ticket_1',
      subject: 'Feature Request',
      status: 'open',
      createdAt: new Date().toISOString(),
    },
  ]);
});

// ========== IP INFO ENDPOINT ==========

app.get('/api/ip', (req, res) => {
  const ip =
    req.headers['x-forwarded-for'] || req.headers['x-real-ip'] || req.connection.remoteAddress;

  res.json({
    ip: ip || 'unknown',
    timestamp: new Date().toISOString(),
  });
});

// ========== SUBSCRIPTION ENDPOINT ==========

app.post('/api/subscribe', (req, res) => {
  const { email } = req.body;

  if (!email) {
    return res.status(400).json({
      success: false,
      error: 'Email is required',
    });
  }

  res.json({
    success: true,
    message: 'Successfully subscribed to newsletter',
  });
});

// ========== AI PROVIDER ENDPOINTS ==========

// Mount AI provider routes with rate limiting, usage tracking, and activity tracking
app.use(
  '/api/ai',
  rateLimitMiddleware,
  usageTrackingMiddleware,
  activityTrackingMiddleware(ActivityLog),
  aiProviderRoutes
);

// Mount AI Lab routes
app.use(
  '/api/ai-lab',
  rateLimitMiddleware,
  usageTrackingMiddleware,
  activityTrackingMiddleware(ActivityLog),
  aiLabRoutes
);

// Mount Canvas routes
app.use(
  '/api/canvas',
  rateLimitMiddleware,
  usageTrackingMiddleware,
  activityTrackingMiddleware(ActivityLog),
  canvasRoutes
);

// Mount Chat Session routes
app.use(
  '/api/chat',
  rateLimitMiddleware,
  usageTrackingMiddleware,
  activityTrackingMiddleware(ActivityLog),
  chatSessionRoutes
);

// Mount activity tracking middleware globally for all API routes
app.use('/api/', activityTrackingMiddleware(ActivityLog));

// ========== EMOTIONAL TTS ENDPOINTS ==========

// const emotionalTTSRoutes = require('./routes/emotionalTTSRoutes');
// app.use('/api/tts', rateLimitMiddleware, emotionalTTSRoutes);

// ========== DOCTOR NETWORK ENDPOINTS ==========

console.log('📡 Loading Doctor Network routes...');
const doctorNetworkRoutes = require('./routes/doctorNetwork');
console.log('📡 Doctor Network routes loaded, registering with Express...');
app.use('/api/doctor-network', rateLimitMiddleware, doctorNetworkRoutes);
console.log('✅ Doctor Network endpoint registered at /api/doctor-network');

// ========== IP LOOKUP ENDPOINTS ==========

console.log('🔍 Loading IP Lookup routes...');
const ipLookupRoutes = require('./routes/ipLookup');
console.log('🔍 IP Lookup routes loaded, registering with Express...');
app.use('/api/ip-lookup', rateLimitMiddleware, ipLookupRoutes);
console.log('✅ IP Lookup endpoint registered at /api/ip-lookup');

// ========== TOOLS ENDPOINTS ==========

console.log('🔧 Loading Tools routes...');
const toolsRoutes = require('./routes/tools');
console.log('🔧 Tools routes loaded, registering with Express...');
app.use('/api/tools', rateLimitMiddleware, toolsRoutes);
console.log('✅ Tools endpoint registered at /api/tools');

// ========== LIVE SUPPORT ENDPOINTS ==========

console.log('💬 Loading Live Support routes...');
const liveSupportRoutes = require('./routes/liveSupport');
console.log('💬 Live Support routes loaded, registering with Express...');
app.use('/api/live-support', rateLimitMiddleware, liveSupportRoutes);
console.log('✅ Live Support endpoint registered at /api/live-support');

// ========== ANALYTICS ENDPOINTS ==========

console.log('📊 Loading Analytics routes...');
const analyticsRoutes = require('./routes/analyticsRoutes')(ActivityLog, Chat, User);
app.use('/api/analytics', authenticate, analyticsRoutes);
console.log('✅ Analytics endpoints registered at /api/analytics');

// ========== VISITOR ANALYTICS ENDPOINTS ==========

console.log('👥 Loading Visitor Analytics routes...');
app.use('/api/visitors', rateLimitMiddleware, visitorAnalyticsRoutes);
console.log('✅ Visitor Analytics endpoints registered at /api/visitors');

// ========== CONTENT MANAGEMENT ENDPOINTS ==========

console.log('📝 Loading Content Management routes...');
// const contentRoutes = require('./routes/content');
// app.use('/api/content', rateLimitMiddleware, contentRoutes);
console.log('⚠️ Content Management endpoints disabled (missing routes/content file)');

// ========== FILE UPLOAD ENDPOINTS ==========

console.log('📁 Loading File Upload routes...');
const fileUploadRoutes = require('./routes/fileUpload');
app.use('/api/files', rateLimitMiddleware, fileUploadRoutes);
console.log('✅ File Upload endpoints registered at /api/files');

// ========== API KEY MANAGEMENT ENDPOINTS ==========

console.log('🔑 Loading API Key Management routes...');
const apiKeysRoutes = require('./routes/apiKeys');
app.use('/api/api-keys', rateLimitMiddleware, apiKeysRoutes);
console.log('✅ API Key Management endpoints registered at /api/api-keys');

// ========== CONTACT FORM ENDPOINTS ==========

console.log('📧 Loading Contact Form routes...');
const contactRoutes = require('./routes/contact');
app.use('/api/contact', rateLimitMiddleware, contactRoutes);
console.log('✅ Contact Form endpoints registered at /api/contact');

// ========== ADMIN DASHBOARD ENDPOINTS ==========

console.log('👨‍💼 Loading Admin Dashboard routes...');
const adminRoutes = require('./routes/admin');
app.use('/api/admin', rateLimitMiddleware, adminRoutes);
console.log('✅ Admin Dashboard endpoints registered at /api/admin');

// ========== SUBSCRIPTION PLANS ENDPOINTS ==========

console.log('💰 Loading Subscription Plans routes...');
const plansRoutes = require('./routes/plans');
app.use('/api/plans', rateLimitMiddleware, plansRoutes);
console.log('✅ Subscription Plans endpoints registered at /api/plans');

// ========== SYSTEM SETTINGS ENDPOINTS ==========

console.log('⚙️ Loading System Settings routes...');
// const settingsRoutes = require('./routes/settings'); // File doesn't exist
// app.use('/api/settings', rateLimitMiddleware, settingsRoutes);
console.log('⚠️ System Settings endpoints disabled (missing routes/settings file)');

// ========== NEW SIMPLE PURCHASE SYSTEM ✅ ==========
// One-time purchases with expiration - NO SUBSCRIPTIONS
console.log('🛒 Loading Simple Purchase API routes...');
app.use('/', agentPurchaseAPI);
console.log('✅ Agent Purchase endpoints registered:');
console.log('   - GET  /api/agents/:agentId/access (check active access)');
console.log("   - GET  /api/purchases/active (user's active purchases)");
console.log('   - POST /api/agents/:agentId/purchase (buy agent access)');
console.log('   - POST /api/purchases/:purchaseId/cancel (cancel purchase)');
console.log('   - GET  /api/purchases/history (purchase history)');
console.log('   - GET  /api/purchases/stats (purchase statistics)');

// ========== PAYMENT SYSTEM ENDPOINTS ==========

console.log('💳 Loading Payment System routes...');
const paymentsRoutes = require('./routes/payments');
app.use('/api/payments', rateLimitMiddleware, paymentsRoutes);
console.log('✅ Payment System endpoints registered at /api/payments');

// ========== SUPPORT SYSTEM ENDPOINTS ==========

console.log('🎫 Loading Support System routes...');
const supportRoutes = require('./routes/support');
app.use('/api/support', rateLimitMiddleware, supportRoutes);
console.log('✅ Support System endpoints registered at /api/support');

// ========== CHAT SESSION ENDPOINTS ==========

console.log('💬 Loading Chat Session routes...');
app.use('/api/chat', rateLimitMiddleware, chatSessionRoutes);
console.log('✅ Chat Session endpoints registered at /api/chat');
console.log('   - POST /api/chat/sessions/create (create new session)');
console.log('   - POST /api/chat/sessions/:sessionId/messages (add message)');
console.log('   - GET  /api/chat/sessions/:sessionId (get session)');

// ========== AGENTS API (DATABASE-DRIVEN) ==========
console.log('🔵 BEFORE AGENTS API BLOCK');

try {
  console.log('🤖 Loading Agents API routes...');
  const agentsRoutes = require('./routes/agents');
  console.log('🟢 routes/agents loaded successfully');
  app.use('/api/agents', agentsRoutes);
  console.log('✅ Agents API endpoints registered at /api/agents');
  console.log('   - GET  /api/agents (all active agents)');
  console.log('   - GET  /api/agents/featured (featured agents)');
  console.log('   - GET  /api/agents/categories (category list)');
  console.log('   - GET  /api/agents/category/:category (agents by category)');
  console.log('   - GET  /api/agents/search?q=query (search agents)');
  console.log('   - GET  /api/agents/detail/:agentId (single agent)');
  console.log('   - GET  /api/agents/config/:agentId (backend config)');
} catch (err) {
  console.error('❌ Failed to load Agents API routes:', err.message);
  console.error(err.stack);
}

console.log('🔵 AFTER AGENTS API BLOCK');

// ========== USER PROFILES ENDPOINTS ==========

console.log('👤 Loading Enhanced Profiles routes...');
// const profilesRoutes = require('./routes/profiles'); // File doesn't exist
// app.use('/api/profiles', rateLimitMiddleware, profilesRoutes);
console.log('⚠️ Enhanced Profiles endpoints disabled (missing routes/profiles file)');
// ========== AGENT PURCHASE SYSTEM (ONE-TIME PAYMENTS) ==========

console.log('💳 Loading Agent Purchase routes...');
const agentPurchaseRoutes = require('./agent-purchase-routes');
app.use('/api/agents', rateLimitMiddleware, agentPurchaseRoutes);
app.use('/api/purchases', rateLimitMiddleware, agentPurchaseRoutes);
console.log('✅ Agent Purchase endpoints registered at /api/agents and /api/purchases');

// ========== DEPRECATED: OLD AGENT APIS ==========
// ❌ universal-agent-api.js DEPRECATED - DO NOT USE
// ❌ individual-agent-api.js DEPRECATED - DO NOT USE
// Use /api/agents/:agentId/purchase instead
// console.log('🤖 Loading Universal Agent System routes...');
// app.use('/api/agents', rateLimitMiddleware, universalAgentAPI);
// console.log('✅ Universal Agent System endpoints registered at /api/agents');

// ========== DEPRECATED: INDIVIDUAL AGENT SYSTEM ENDPOINTS ==========
// ❌ Old individual-agent-api.js is DEPRECATED
// Replaced by unified purchase API: /api/agents/:agentId/purchase
// Commented out to prevent loading old subscription code
// console.log('🎯 Loading Individual Agent System routes...');
// app.use('/api/individual-agents', rateLimitMiddleware, individualAgentAPI);
// console.log('✅ Individual Agent System endpoints registered at /api/individual-agents');

// ✅ Compatibility shim for legacy frontend calls that still hit /api/individual-agents
//    Instead of re-enabling the deprecated subscription system, we map active one-time
//    purchases into the old response shape so the UI can render without 404s.
app.get(
  '/api/individual-agents/subscriptions/user/:userId',
  rateLimitMiddleware,
  authenticate,
  async (req, res) => {
    try {
      const { userId } = req.params;

      // Prevent users from querying other accounts
      if (req.userId?.toString() !== userId.toString()) {
        return res.status(403).json({ success: false, error: 'Forbidden' });
      }

      const now = new Date();
      const purchases = await AgentPurchase.find({
        userId,
        status: 'active',
        expirationDate: { $gt: now },
      }).lean();

      const subscriptions = purchases.map(p => ({
        id: p._id,
        userId: p.userId,
        agentId: p.agentId,
        agentInfo: {
          agentId: p.agentId,
          agentDisplayName: p.agentId,
          subscribedAt: p.purchaseDate,
          expiresAt: p.expirationDate,
        },
        plan: (p.planType || '').toUpperCase(),
        pricing: { amount: p.amount, currency: p.currency },
        usage: {},
        status: p.status,
        billing: {},
        expirationDate: p.expirationDate,
        purchaseDate: p.purchaseDate,
      }));

      return res.json({
        success: true,
        subscriptions,
        totalActiveAgents: subscriptions.length,
      });
    } catch (error) {
      console.error('Legacy individual agent subscription lookup failed:', error);
      return res.status(500).json({ success: false, error: 'Failed to fetch subscriptions' });
    }
  }
);

// ========== AGENT COLLECTION SYSTEM ENDPOINTS ==========

console.log('🗄️  Loading Agent Collection System routes...');
app.use('/api/agent-collections', rateLimitMiddleware, agentCollectionAPI);
console.log('✅ Agent Collection System endpoints registered at /api/agent-collections');
console.log('📊 Each agent now has its own dedicated MongoDB collection');

// Initialize agent collection integration
agentCollectionIntegration
  .initialize()
  .then(() => {
    console.log('🎯 Agent Collection Integration initialized successfully');
  })
  .catch(error => {
    console.error('❌ Failed to initialize Agent Collection Integration:', error);
  });

// ========== BILLING SYSTEM ENDPOINTS ==========

console.log('🧾 Loading Billing System routes...');
const billingRoutes = require('./routes/billing');
app.use('/api/billing', rateLimitMiddleware, billingRoutes);
console.log('✅ Billing System endpoints registered at /api/billing');

// ========== RBAC SYSTEM ENDPOINTS ==========

console.log('🔐 Loading RBAC System routes...');
const rbacRoutes = require('./routes/rbac');
app.use('/api/rbac', rateLimitMiddleware, rbacRoutes);
console.log('✅ RBAC System endpoints registered at /api/rbac');

// ========== AGENT X INDIVIDUAL TRACKING ENDPOINTS ==========

console.log('🤖 Loading Agent X Individual Tracking routes...');
const agentXRoutes = require('./agentx-api');
app.use('/api', rateLimitMiddleware, agentXRoutes);
console.log('✅ Agent X Individual Tracking endpoints registered at /api/agentx/*');

// ========== WEBHOOK SYSTEM ENDPOINTS ==========

console.log('🔗 Loading Webhook System routes...');
const webhooksRoutes = require('./routes/webhooks');
app.use('/api/webhooks', rateLimitMiddleware, webhooksRoutes);
console.log('✅ Webhook System endpoints registered at /api/webhooks');

// ========== 404 HANDLER ==========

// 404 handler
app.use((req, res) => {
  res.status(404).json({
    error: 'Endpoint not found',
    path: req.path,
  });
});

// Error handler
app.use((err, req, res, next) => {
  console.error('Error:', err);
  res.status(500).json({
    error: 'Internal server error',
    message: err.message,
  });
});

// ========== BILLING & SUBSCRIPTION ENDPOINTS ==========

// Get user's billing history (invoices)
app.get('/api/billing/invoices', authenticate, async (req, res) => {
  try {
    const transactions = await Transaction.find({
      userId: req.userId,
      type: 'SUBSCRIPTION',
      status: 'COMPLETED',
    })
      .sort({ createdAt: -1 })
      .limit(50);

    const invoices = transactions.map(transaction => ({
      id: transaction.metadata?.invoiceNumber || `INV-${transaction._id}`,
      date: transaction.createdAt,
      amount: transaction.amount,
      status: transaction.status === 'COMPLETED' ? 'paid' : 'pending',
      plan: transaction.description || 'Subscription',
      downloadUrl: `/api/billing/invoices/${transaction._id}/download`,
    }));

    res.json({ invoices });
  } catch (error) {
    console.error('[BILLING] Error fetching invoices:', error);
    res.status(500).json({ error: 'Failed to fetch invoices' });
  }
});

// DUPLICATE ROUTE - COMMENTED OUT (original is at line ~2811)
// Get subscription status
// app.get('/api/payments/subscription/status', authenticate, async (req, res) => {
//   try {
//     const user = await User.findById(req.userId);
//     const activeSubscription = await Subscription.findOne({
//       userId: req.userId,
//       status: 'ACTIVE'
//     });
//
//     res.json({
//       currentPlan: activeSubscription?.tier || user?.currentPlan || 'NONE',
//       subscriptionStatus: activeSubscription?.status || user?.subscriptionStatus || 'NONE',
//       periodEnd: activeSubscription?.currentPeriodEnd || user?.subscriptionPeriodEnd || null,
//       cancelAtPeriodEnd: activeSubscription?.cancelAtPeriodEnd || false,
//       stripeCustomerId: user?.stripeCustomerId || null,
//       stripeSubscriptionId: user?.stripeSubscriptionId || activeSubscription?.providerSubscriptionId || null
//     });
//
//   } catch (error) {
//     console.error('[BILLING] Error fetching subscription:', error);
//     res.status(500).json({ error: 'Failed to fetch subscription status' });
//   }
// });

// Get user sessions for security tab
app.get('/api/users/sessions', authenticate, async (req, res) => {
  try {
    const sessions = await Session.find({
      userId: req.userId,
      isActive: true,
    }).sort({ lastActivity: -1 });

    const formattedSessions = sessions.map(session => ({
      id: session.sessionId,
      device: `${session.device?.browser || 'Unknown'} on ${session.device?.os || 'Unknown'}`,
      location: session.location
        ? `${session.location.city}, ${session.location.country}`
        : 'Unknown',
      ipAddress: session.ipAddress,
      lastActive: session.lastActivity,
      current: session.sessionId === req.sessionId, // Assuming sessionId is added to request
      createdAt: session.createdAt,
    }));

    res.json({ sessions: formattedSessions });
  } catch (error) {
    console.error('[SESSIONS] Error fetching sessions:', error);
    res.status(500).json({ error: 'Failed to fetch sessions' });
  }
});

// Terminate user session
app.delete('/api/users/sessions/:sessionId', authenticate, async (req, res) => {
  try {
    const { sessionId } = req.params;

    const session = await Session.findOneAndUpdate(
      { sessionId: sessionId, userId: req.userId },
      { isActive: false, updatedAt: new Date() }
    );

    if (!session) {
      return res.status(404).json({ error: 'Session not found' });
    }

    res.json({ message: 'Session terminated successfully' });
  } catch (error) {
    console.error('[SESSIONS] Error terminating session:', error);
    res.status(500).json({ error: 'Failed to terminate session' });
  }
});

// Get payment methods (simplified for now)
app.get('/api/billing/payment-methods', authenticate, async (req, res) => {
  try {
    const user = await User.findById(req.userId);

    // For now, return mock data - this would integrate with Stripe in production
    const paymentMethods = [];

    if (user?.stripeCustomerId) {
      // In production, you would fetch from Stripe:
      // const methods = await stripe.paymentMethods.list({
      //   customer: user.stripeCustomerId,
      //   type: 'card',
      // });

      // Mock data for demonstration
      paymentMethods.push({
        id: 'pm_1234567890',
        brand: 'visa',
        last4: '4242',
        exp_month: 12,
        exp_year: 2026,
        isDefault: true,
      });
    }

    res.json({ paymentMethods });
  } catch (error) {
    console.error('[BILLING] Error fetching payment methods:', error);
    res.status(500).json({ error: 'Failed to fetch payment methods' });
  }
});

// Start server
server.listen(PORT, () => {
  console.log('🚀 IAMAI Backend Server Started');
  console.log('================================');
  console.log(`📍 Port: ${PORT}`);
  console.log(`🌍 Environment: ${process.env.NODE_ENV || 'production'}`);
  console.log(`🔗 Frontend URL: ${process.env.FRONTEND_URL || 'https://iamai.global'}`);
  console.log('');

  // Initialize WebSocket
  wsService.initialize(server);
  wsService.setActivityLog(ActivityLog); // Enable activity logging for WebSocket
  console.log('🔌 WebSocket server ready on same port');
  console.log('');

  console.log('📡 Available Endpoints:');
  console.log('  Health:');
  console.log('    - GET  /health');
  console.log('    - GET  /api/health');
  console.log('  Agents:');
  console.log('    - GET  /api/agents');
  console.log('    - GET  /api/agents/:id');
  console.log('    - POST /api/agents/:id/chat');
  console.log('  Authentication:');
  console.log('    - POST /api/auth/signup');
  console.log('    - POST /api/auth/signin');
  console.log('    - POST /api/auth/signout');
  console.log('    - GET  /api/auth/session');
  console.log('  Users:');
  console.log('    - GET  /api/users/profile');
  console.log('    - PUT  /api/users/profile');
  console.log('    - PUT  /api/users/preferences');
  console.log('    - PUT  /api/users/notifications');
  console.log('    - PUT  /api/users/password');
  console.log('  Chat:');
  console.log('    - GET  /api/chat/conversations');
  console.log('    - GET  /api/chat/conversations/:id');
  console.log('  Analytics:');
  console.log('    - GET  /api/analytics/usage');
  console.log('  Payments:');
  console.log('    - POST /api/payments/create-checkout');
  console.log('    - GET  /api/payments/subscription');
  console.log('  Support:');
  console.log('    - POST /api/contact');
  console.log('    - GET  /api/tickets');
  console.log('  WebSocket:');
  console.log('    - Real-time chat enabled');
  console.log('    - Live presence tracking');
  console.log('    - Typing indicators');
  console.log('  Other:');
  console.log('    - GET  /api/ip');
  console.log('    - POST /api/subscribe');
  console.log('');
  console.log('✅ Server is ready to accept connections');
});

module.exports = { app, server, wsService };
