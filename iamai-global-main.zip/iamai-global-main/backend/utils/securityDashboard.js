/**
 * Enhanced Security Dashboard Utilities
 * Provides real security data for dashboard display
 */

const geoip = require('geoip-lite');
const UAParser = require('ua-parser-js');

/**
 * Parse user agent string into device information
 */
function parseUserAgent(userAgent) {
  if (!userAgent || userAgent === 'Unknown') {
    return {
      browser: 'Unknown Browser',
      device: 'Unknown Device',
      os: 'Unknown OS',
      type: 'unknown'
    };
  }
  
  const parser = new UAParser(userAgent);
  const result = parser.getResult();
  
  return {
    browser: `${result.browser.name || 'Unknown'} ${result.browser.version || ''}`.trim(),
    device: result.device.model || result.device.type || 'Desktop',
    os: `${result.os.name || 'Unknown'} ${result.os.version || ''}`.trim(),
    type: result.device.type || 'desktop'
  };
}

/**
 * Get location information from IP address
 */
function getLocationFromIP(ip) {
  if (!ip || ip === 'Unknown' || ip === '127.0.0.1' || ip === '::1') {
    return {
      country: 'Unknown',
      city: 'Unknown',
      region: 'Unknown',
      flag: '🌍'
    };
  }
  
  try {
    const geo = geoip.lookup(ip);
    if (!geo) {
      return {
        country: 'Unknown',
        city: 'Unknown', 
        region: 'Unknown',
        flag: '🌍'
      };
    }
    
    // Get flag emoji for country
    const countryFlags = {
      'US': '🇺🇸', 'CA': '🇨🇦', 'GB': '🇬🇧', 'DE': '🇩🇪', 'FR': '🇫🇷',
      'JP': '🇯🇵', 'AU': '🇦🇺', 'BR': '🇧🇷', 'IN': '🇮🇳', 'CN': '🇨🇳',
      'MX': '🇲🇽', 'IT': '🇮🇹', 'ES': '🇪🇸', 'NL': '🇳🇱', 'RU': '🇷🇺',
      'KR': '🇰🇷', 'SE': '🇸🇪', 'NO': '🇳🇴', 'DK': '🇩🇰', 'FI': '🇫🇮'
    };
    
    return {
      country: geo.country,
      city: geo.city,
      region: geo.region,
      flag: countryFlags[geo.country] || '🌍'
    };
  } catch (error) {
    return {
      country: 'Unknown',
      city: 'Unknown',
      region: 'Unknown', 
      flag: '🌍'
    };
  }
}

/**
 * Format session data for dashboard display
 */
function formatSessionForDashboard(session) {
  const device = parseUserAgent(session.userAgent);
  const location = getLocationFromIP(session.ip);
  
  return {
    id: session.sessionId,
    device: {
      type: device.type,
      name: device.device,
      browser: device.browser,
      os: device.os,
      icon: getDeviceIcon(device.type)
    },
    location: {
      display: `${location.city}, ${location.country}`,
      country: location.country,
      city: location.city,
      flag: location.flag
    },
    ip: session.ip,
    lastActive: session.lastActive,
    createdAt: session.createdAt,
    isCurrent: false // Will be set by calling function
  };
}

/**
 * Get device icon based on device type
 */
function getDeviceIcon(deviceType) {
  const icons = {
    'mobile': '📱',
    'tablet': '📋', 
    'desktop': '💻',
    'tv': '📺',
    'wearable': '⌚',
    'embedded': '🔌',
    'console': '🎮'
  };
  
  return icons[deviceType] || '💻';
}

/**
 * Format login activity for dashboard display
 */
function formatActivityForDashboard(activity) {
  const device = parseUserAgent(activity.userAgent);
  const location = getLocationFromIP(activity.ip);
  
  return {
    id: activity.id || `${activity.timestamp}_${Math.random()}`,
    type: activity.success ? 'LOGIN_SUCCESS' : 'LOGIN_FAILED',
    timestamp: activity.timestamp,
    device: {
      type: device.type,
      name: device.device,
      browser: device.browser,
      os: device.os,
      icon: getDeviceIcon(device.type)
    },
    location: {
      display: `${location.city}, ${location.country}`,
      country: location.country,
      city: location.city,
      flag: location.flag
    },
    ip: activity.ip,
    success: activity.success,
    riskLevel: activity.success ? 'low' : 'medium',
    details: activity.success ? 'Successful login' : (activity.reason || 'Login failed')
  };
}

/**
 * Generate security recommendations based on user data
 */
function generateSecurityRecommendations(user, sessions, activities) {
  const recommendations = [];
  
  // 2FA recommendation
  if (!user.security?.twoFactorEnabled) {
    recommendations.push({
      type: 'security',
      priority: 'high',
      title: 'Enable Two-Factor Authentication',
      description: 'Add an extra layer of security to your account',
      action: 'setup_2fa'
    });
  }
  
  // Multiple failed login attempts
  const recentFailures = activities.filter(a => 
    !a.success && 
    new Date(a.timestamp) > new Date(Date.now() - 24 * 60 * 60 * 1000)
  );
  
  if (recentFailures.length > 3) {
    recommendations.push({
      type: 'warning',
      priority: 'high',
      title: 'Multiple Failed Login Attempts',
      description: `${recentFailures.length} failed login attempts in the last 24 hours`,
      action: 'review_security'
    });
  }
  
  // Too many active sessions
  if (sessions.length > 5) {
    recommendations.push({
      type: 'info',
      priority: 'medium',
      title: 'Multiple Active Sessions',
      description: `You have ${sessions.length} active sessions across different devices`,
      action: 'manage_sessions'
    });
  }
  
  // No recent password change
  const lastPasswordChange = user.security?.lastPasswordChange;
  if (!lastPasswordChange || 
      new Date(lastPasswordChange) < new Date(Date.now() - 90 * 24 * 60 * 60 * 1000)) {
    recommendations.push({
      type: 'info', 
      priority: 'medium',
      title: 'Consider Updating Password',
      description: 'Your password hasn\'t been changed in over 90 days',
      action: 'change_password'
    });
  }
  
  return recommendations;
}

/**
 * Calculate security score based on various factors
 */
function calculateSecurityScore(user, sessions, activities) {
  let score = 50; // Base score
  
  // 2FA enabled (+30 points)
  if (user.security?.twoFactorEnabled) {
    score += 30;
  }
  
  // Email verified (+10 points)
  if (user.emailVerified) {
    score += 10;
  }
  
  // Phone verified (+5 points)
  if (user.phoneVerified) {
    score += 5;
  }
  
  // Recent password change (+5 points)
  const lastPasswordChange = user.security?.lastPasswordChange;
  if (lastPasswordChange && 
      new Date(lastPasswordChange) > new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)) {
    score += 5;
  }
  
  // Deduct points for security issues
  const recentFailures = activities.filter(a => 
    !a.success && 
    new Date(a.timestamp) > new Date(Date.now() - 24 * 60 * 60 * 1000)
  );
  
  // Deduct for failed attempts (-2 per failure, max -20)
  score -= Math.min(recentFailures.length * 2, 20);
  
  // Deduct for too many sessions (-1 per extra session over 3)
  if (sessions.length > 3) {
    score -= (sessions.length - 3);
  }
  
  // Ensure score is between 0 and 100
  return Math.max(0, Math.min(100, score));
}

/**
 * Get security score color and level
 */
function getSecurityLevel(score) {
  if (score >= 90) return { level: 'Excellent', color: '#22c55e', icon: '🛡️' };
  if (score >= 75) return { level: 'Good', color: '#3b82f6', icon: '🔒' };
  if (score >= 60) return { level: 'Fair', color: '#f59e0b', icon: '⚠️' };
  if (score >= 40) return { level: 'Poor', color: '#ef4444', icon: '🚨' };
  return { level: 'Critical', color: '#dc2626', icon: '💥' };
}

module.exports = {
  parseUserAgent,
  getLocationFromIP,
  formatSessionForDashboard,
  formatActivityForDashboard,
  generateSecurityRecommendations,
  calculateSecurityScore,
  getSecurityLevel,
  getDeviceIcon
};