/**
 * AI Usage Tracking & Rate Limiting
 * Track API usage, costs, and enforce per-agent/per-user limits
 */

const { createHash } = require('crypto');

// In-memory usage store (use Redis in production)
const usageStore = new Map();
const rateLimitStore = new Map();

// Cost per 1K tokens (approximate, update with actual pricing)
const TOKEN_COSTS = {
  gemini: {
    'gemini-2.0-flash-exp': { input: 0.0001, output: 0.0003 },
    'gemini-1.5-pro': { input: 0.0035, output: 0.0105 },
    'text-embedding-004': { input: 0.00001, output: 0 }
  },
  openai: {
    'gpt-4o': { input: 0.005, output: 0.015 },
    'gpt-4o-mini': { input: 0.00015, output: 0.0006 },
    'text-embedding-3-large': { input: 0.00013, output: 0 },
    'dall-e-3': { perImage: 0.04 },
    'tts-1-hd': { per1MChars: 15.0 },
    'whisper-1': { perMinute: 0.006 }
  },
  anthropic: {
    'claude-3-5-sonnet-20241022': { input: 0.003, output: 0.015 },
    'claude-3-haiku-20240307': { input: 0.00025, output: 0.00125 }
  }
};

/**
 * Track API usage
 */
function trackUsage({ 
  userId, 
  agentId, 
  operation, 
  provider, 
  model, 
  inputTokens = 0, 
  outputTokens = 0,
  metadata = {} 
}) {
  const timestamp = Date.now();
  const key = `${userId}:${agentId}:${operation}`;
  
  if (!usageStore.has(key)) {
    usageStore.set(key, []);
  }
  
  // Calculate cost
  const cost = calculateCost(provider, model, inputTokens, outputTokens, metadata);
  
  const record = {
    timestamp,
    userId,
    agentId,
    operation,
    provider,
    model,
    inputTokens,
    outputTokens,
    totalTokens: inputTokens + outputTokens,
    cost,
    metadata
  };
  
  usageStore.get(key).push(record);
  
  // Log to console (replace with database insert in production)
  console.log('Usage:', JSON.stringify(record));
  
  return record;
}

/**
 * Calculate cost based on provider and model
 */
function calculateCost(provider, model, inputTokens, outputTokens, metadata) {
  const pricing = TOKEN_COSTS[provider]?.[model];
  
  if (!pricing) {
    console.warn(`No pricing data for ${provider}/${model}`);
    return 0;
  }
  
  if (pricing.perImage) {
    return pricing.perImage;
  }
  
  if (pricing.per1MChars) {
    const chars = metadata.characters || 0;
    return (chars / 1000000) * pricing.per1MChars;
  }
  
  if (pricing.perMinute) {
    const minutes = metadata.durationSeconds ? metadata.durationSeconds / 60 : 0;
    return minutes * pricing.perMinute;
  }
  
  // Token-based pricing
  const inputCost = (inputTokens / 1000) * (pricing.input || 0);
  const outputCost = (outputTokens / 1000) * (pricing.output || 0);
  
  return inputCost + outputCost;
}

/**
 * Get usage summary
 */
function getUsageSummary(userId, agentId = null, timeframe = 'day') {
  const now = Date.now();
  const timeframes = {
    hour: 60 * 60 * 1000,
    day: 24 * 60 * 60 * 1000,
    week: 7 * 24 * 60 * 60 * 1000,
    month: 30 * 24 * 60 * 60 * 1000
  };
  
  const cutoff = now - (timeframes[timeframe] || timeframes.day);
  
  let totalCost = 0;
  let totalTokens = 0;
  let requestCount = 0;
  const byOperation = {};
  const byProvider = {};
  
  for (const [key, records] of usageStore.entries()) {
    if (!key.startsWith(userId)) continue;
    if (agentId && !key.includes(agentId)) continue;
    
    for (const record of records) {
      if (record.timestamp < cutoff) continue;
      
      totalCost += record.cost;
      totalTokens += record.totalTokens;
      requestCount++;
      
      // Group by operation
      if (!byOperation[record.operation]) {
        byOperation[record.operation] = { count: 0, cost: 0, tokens: 0 };
      }
      byOperation[record.operation].count++;
      byOperation[record.operation].cost += record.cost;
      byOperation[record.operation].tokens += record.totalTokens;
      
      // Group by provider
      if (!byProvider[record.provider]) {
        byProvider[record.provider] = { count: 0, cost: 0, tokens: 0 };
      }
      byProvider[record.provider].count++;
      byProvider[record.provider].cost += record.cost;
      byProvider[record.provider].tokens += record.totalTokens;
    }
  }
  
  return {
    timeframe,
    totalCost: totalCost.toFixed(4),
    totalTokens,
    requestCount,
    byOperation,
    byProvider
  };
}

/**
 * Rate limiting middleware
 */
function rateLimitMiddleware(req, res, next) {
  try {
    const userId = req.user?.id || req.ip;
    const agentId = req.body?.agentId || req.params?.agentId;
    
    if (!agentId) {
      return next(); // Skip if no agent specified
    }
    
    // Get agent config
    const { getRuntimeConfig } = require('../config/agentConfigs.js');
    const agentConfig = getRuntimeConfig(agentId);
    
    if (!agentConfig.rateLimits) {
      return next();
    }
    
    const limits = agentConfig.rateLimits;
    const now = Date.now();
    const key = `${userId}:${agentId}`;
    
    if (!rateLimitStore.has(key)) {
      rateLimitStore.set(key, {
        minute: [],
        hour: [],
        day: []
      });
    }
    
    const userLimits = rateLimitStore.get(key);
    
    // Clean old entries
    userLimits.minute = userLimits.minute.filter(t => now - t < 60000);
    userLimits.hour = userLimits.hour.filter(t => now - t < 3600000);
    userLimits.day = userLimits.day.filter(t => now - t < 86400000);
    
    // Check limits
    if (limits.requestsPerMinute && userLimits.minute.length >= limits.requestsPerMinute) {
      return res.status(429).json({
        error: 'Rate limit exceeded',
        limit: 'requestsPerMinute',
        max: limits.requestsPerMinute,
        retryAfter: 60
      });
    }
    
    if (limits.requestsPerHour && userLimits.hour.length >= limits.requestsPerHour) {
      return res.status(429).json({
        error: 'Rate limit exceeded',
        limit: 'requestsPerHour',
        max: limits.requestsPerHour,
        retryAfter: 3600
      });
    }
    
    // Add current request
    userLimits.minute.push(now);
    userLimits.hour.push(now);
    userLimits.day.push(now);
    
    // Add rate limit headers
    res.setHeader('X-RateLimit-Limit-Minute', limits.requestsPerMinute || 'unlimited');
    res.setHeader('X-RateLimit-Remaining-Minute', Math.max(0, (limits.requestsPerMinute || 999) - userLimits.minute.length));
    res.setHeader('X-RateLimit-Limit-Hour', limits.requestsPerHour || 'unlimited');
    res.setHeader('X-RateLimit-Remaining-Hour', Math.max(0, (limits.requestsPerHour || 999) - userLimits.hour.length));
    
    next();
  } catch (error) {
    console.error('Rate limit middleware error:', error);
    next(); // Continue on error
  }
}

/**
 * Usage tracking middleware
 */
function usageTrackingMiddleware(req, res, next) {
  // Wrap res.json to track after response
  const originalJson = res.json.bind(res);
  
  res.json = function(data) {
    try {
      if (data.usage && req.body?.agentId) {
        trackUsage({
          userId: req.user?.id || req.ip,
          agentId: req.body.agentId,
          operation: req.path.split('/').pop(),
          provider: data.provider,
          model: data.model,
          inputTokens: data.usage?.promptTokens || data.usage?.input_tokens || 0,
          outputTokens: data.usage?.completionTokens || data.usage?.output_tokens || 0,
          metadata: {
            latency: data.latency,
            finishReason: data.finishReason
          }
        });
      }
    } catch (error) {
      console.error('Usage tracking error:', error);
    }
    
    return originalJson(data);
  };
  
  next();
}

/**
 * Export usage data (for billing/analytics)
 */
function exportUsageData(userId, startDate, endDate) {
  const records = [];
  
  for (const [key, usageRecords] of usageStore.entries()) {
    if (!key.startsWith(userId)) continue;
    
    for (const record of usageRecords) {
      if (startDate && record.timestamp < startDate) continue;
      if (endDate && record.timestamp > endDate) continue;
      records.push(record);
    }
  }
  
  return records;
}

/**
 * Clear old usage data (run periodically)
 */
function cleanupUsageData(olderThanDays = 30) {
  const cutoff = Date.now() - (olderThanDays * 24 * 60 * 60 * 1000);
  let cleaned = 0;
  
  for (const [key, records] of usageStore.entries()) {
    const filtered = records.filter(r => r.timestamp >= cutoff);
    cleaned += records.length - filtered.length;
    
    if (filtered.length === 0) {
      usageStore.delete(key);
    } else {
      usageStore.set(key, filtered);
    }
  }
  
  console.log(`Cleaned ${cleaned} old usage records`);
  return cleaned;
}

// Schedule cleanup every 24 hours
setInterval(() => cleanupUsageData(30), 24 * 60 * 60 * 1000);

// Export all functions
module.exports = {
  trackUsage,
  getUsageSummary,
  rateLimitMiddleware,
  usageTrackingMiddleware,
  exportUsageData,
  cleanupUsageData
};
