const geoip = require('geoip-lite');
const UAParser = require('ua-parser-js');
const mongoose = require('mongoose');

// Visitor Schema
const visitorSchema = new mongoose.Schema({
  sessionId: { type: String, required: true, unique: true },
  ipAddress: { type: String, required: true },
  userAgent: { type: String, required: true },
  
  // Geographic Data
  country: String,
  region: String,
  city: String,
  timezone: String,
  coordinates: {
    lat: Number,
    lng: Number
  },
  
  // Device Information
  device: {
    type: String,        // mobile, tablet, desktop
    brand: String,
    model: String
  },
  browser: {
    name: String,
    version: String
  },
  os: {
    name: String,
    version: String
  },
  
  // Visit Information
  firstVisit: { type: Date, default: Date.now },
  lastVisit: { type: Date, default: Date.now },
  totalVisits: { type: Number, default: 1 },
  totalPageViews: { type: Number, default: 1 },
  
  // Page Tracking
  pages: [{
    url: String,
    title: String,
    timestamp: { type: Date, default: Date.now },
    timeSpent: Number, // seconds
    referrer: String
  }],
  
  // Referrer Information
  referrer: String,
  referrerDomain: String,
  utmSource: String,
  utmMedium: String,
  utmCampaign: String,
  
  // Status
  isActive: { type: Boolean, default: true },
  lastActivity: { type: Date, default: Date.now }
});

const Visitor = mongoose.models.Visitor || mongoose.model('Visitor', visitorSchema);

// Visitor Tracking Middleware
const trackVisitor = async (req, res, next) => {
  try {
    const sessionId = req.sessionID || req.headers['x-session-id'] || `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const ipAddress = req.ip || req.connection.remoteAddress || req.headers['x-forwarded-for']?.split(',')[0];
    const userAgent = req.headers['user-agent'] || '';
    
    // Parse User Agent
    const parser = new UAParser(userAgent);
    const uaResult = parser.getResult();
    
    // Get Geographic Information
    const geo = geoip.lookup(ipAddress);
    
    // Parse URL parameters for UTM tracking
    const utmSource = req.query.utm_source;
    const utmMedium = req.query.utm_medium;
    const utmCampaign = req.query.utm_campaign;
    const referrer = req.headers.referer || req.headers.referrer;
    
    // Current page info
    const currentPage = {
      url: req.originalUrl,
      title: req.headers['page-title'] || req.originalUrl,
      timestamp: new Date(),
      referrer: referrer
    };
    
    // Check if visitor exists
    let visitor = await Visitor.findOne({ sessionId });
    
    if (visitor) {
      // Update existing visitor
      visitor.lastVisit = new Date();
      visitor.lastActivity = new Date();
      visitor.totalVisits += 1;
      visitor.totalPageViews += 1;
      visitor.pages.push(currentPage);
      
      // Keep only last 100 page views per visitor
      if (visitor.pages.length > 100) {
        visitor.pages = visitor.pages.slice(-100);
      }
      
      await visitor.save();
    } else {
      // Create new visitor
      visitor = new Visitor({
        sessionId,
        ipAddress,
        userAgent,
        
        // Geographic data
        country: geo?.country || 'Unknown',
        region: geo?.region || 'Unknown',
        city: geo?.city || 'Unknown',
        timezone: geo?.timezone || 'Unknown',
        coordinates: geo ? { lat: geo.ll[0], lng: geo.ll[1] } : null,
        
        // Device information
        device: {
          type: uaResult.device.type || 'desktop',
          brand: uaResult.device.vendor || 'Unknown',
          model: uaResult.device.model || 'Unknown'
        },
        browser: {
          name: uaResult.browser.name || 'Unknown',
          version: uaResult.browser.version || 'Unknown'
        },
        os: {
          name: uaResult.os.name || 'Unknown',
          version: uaResult.os.version || 'Unknown'
        },
        
        // Initial page
        pages: [currentPage],
        
        // Referrer information
        referrer: referrer,
        referrerDomain: referrer ? new URL(referrer).hostname : null,
        utmSource,
        utmMedium,
        utmCampaign
      });
      
      await visitor.save();
    }
    
    // Add visitor info to request for use in routes
    req.visitor = visitor;
    
    // Log activity
    await logActivity({
      type: 'page_view',
      userId: req.user?.id,
      sessionId: sessionId,
      details: {
        page: req.originalUrl,
        userAgent: userAgent.substring(0, 200),
        ipAddress: ipAddress,
        country: geo?.country || 'Unknown'
      }
    });
    
    next();
  } catch (error) {
    console.error('Visitor tracking error:', error);
    next(); // Continue even if tracking fails
  }
};

// Activity Logging Function
const logActivity = async (activityData) => {
  try {
    const ActivityLog = mongoose.model('ActivityLog', new mongoose.Schema({
      type: String,
      userId: String,
      sessionId: String,
      details: mongoose.Schema.Types.Mixed,
      timestamp: { type: Date, default: Date.now },
      ipAddress: String,
      userAgent: String
    }));
    
    await ActivityLog.create({
      sessionId: activityData.sessionId || 'anonymous',
      action: 'PAGE_VIEW',
      route: activityData.route || req.path,
      method: req.method,
      ipAddress: activityData.ipAddress,
      userAgent: activityData.userAgent,
      metadata: activityData.details || {}
    });
  } catch (error) {
    console.error('Activity logging error:', error);
  }
};

// Analytics Functions
const getVisitorAnalytics = async (timeframe = '24h') => {
  const now = new Date();
  let startDate;
  
  switch (timeframe) {
    case '1h':
      startDate = new Date(now.getTime() - (60 * 60 * 1000));
      break;
    case '24h':
      startDate = new Date(now.getTime() - (24 * 60 * 60 * 1000));
      break;
    case '7d':
      startDate = new Date(now.getTime() - (7 * 24 * 60 * 60 * 1000));
      break;
    case '30d':
      startDate = new Date(now.getTime() - (30 * 24 * 60 * 60 * 1000));
      break;
    default:
      startDate = new Date(now.getTime() - (24 * 60 * 60 * 1000));
  }
  
  const [
    totalVisitors,
    uniqueVisitors,
    topCountries,
    topPages,
    deviceStats,
    browserStats
  ] = await Promise.all([
    // Total visitors
    Visitor.countDocuments({ lastActivity: { $gte: startDate } }),
    
    // Unique visitors by IP
    Visitor.aggregate([
      { $match: { lastActivity: { $gte: startDate } } },
      { $group: { _id: '$ipAddress' } },
      { $count: 'uniqueVisitors' }
    ]),
    
    // Top countries
    Visitor.aggregate([
      { $match: { lastActivity: { $gte: startDate } } },
      { $group: { _id: '$country', count: { $sum: 1 } } },
      { $sort: { count: -1 } },
      { $limit: 10 }
    ]),
    
    // Top pages
    Visitor.aggregate([
      { $match: { lastActivity: { $gte: startDate } } },
      { $unwind: '$pages' },
      { $match: { 'pages.timestamp': { $gte: startDate } } },
      { $group: { _id: '$pages.url', count: { $sum: 1 } } },
      { $sort: { count: -1 } },
      { $limit: 10 }
    ]),
    
    // Device statistics
    Visitor.aggregate([
      { $match: { lastActivity: { $gte: startDate } } },
      { $group: { _id: '$device.type', count: { $sum: 1 } } },
      { $sort: { count: -1 } }
    ]),
    
    // Browser statistics
    Visitor.aggregate([
      { $match: { lastActivity: { $gte: startDate } } },
      { $group: { _id: '$browser.name', count: { $sum: 1 } } },
      { $sort: { count: -1 } }
    ])
  ]);
  
  return {
    timeframe,
    totalVisitors,
    uniqueVisitors: uniqueVisitors[0]?.uniqueVisitors || 0,
    topCountries,
    topPages,
    deviceStats,
    browserStats,
    generatedAt: new Date()
  };
};

// Real-time visitor count
const getCurrentActiveVisitors = async () => {
  const fiveMinutesAgo = new Date(Date.now() - (5 * 60 * 1000));
  return await Visitor.countDocuments({ 
    lastActivity: { $gte: fiveMinutesAgo } 
  });
};

module.exports = {
  trackVisitor,
  logActivity,
  getVisitorAnalytics,
  getCurrentActiveVisitors,
  Visitor
};