// Enhanced visitor tracking with GeoIP and User Agent parsing
const mongoose = require('mongoose');
const geoip = require('geoip-lite');
const UAParser = require('ua-parser-js');

// Import Visitor model from models.js
const { Visitor } = require('../models');

// Enhanced User Agent Parser using ua-parser-js
function parseUserAgent(userAgent) {
  const parser = new UAParser(userAgent);
  const result = parser.getResult();

  return {
    deviceType: result.device.type || 'desktop',
    browser: result.browser.name || 'Unknown',
    os: result.os.name || 'Unknown',
  };
}

// Get geographic info from IP using geoip-lite
function getGeoFromIP(ip) {
  // Handle local/private IPs
  if (
    ip.startsWith('192.168') ||
    ip.startsWith('10.') ||
    ip.startsWith('172.') ||
    ip === '::1' ||
    ip === '127.0.0.1'
  ) {
    return {
      country: 'Local',
      region: 'Local',
      city: 'Local',
      timezone: 'Local',
      coordinates: null,
    };
  }

  const geo = geoip.lookup(ip);
  if (geo) {
    return {
      country: geo.country,
      region: geo.region,
      city: geo.city,
      timezone: geo.timezone,
      coordinates: { latitude: geo.ll[0], longitude: geo.ll[1] },
    };
  }

  return {
    country: 'Unknown',
    region: 'Unknown',
    city: 'Unknown',
    timezone: 'Unknown',
    coordinates: null,
  };
}

// Visitor Tracking Middleware
const trackVisitor = async (req, res, next) => {
  try {
    // Generate or get session ID
    const sessionId =
      req.sessionID ||
      req.headers['x-session-id'] ||
      req.cookies?.sessionId ||
      `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

    // Get visitor information
    const ipAddress =
      req.ip ||
      req.connection.remoteAddress ||
      req.headers['x-forwarded-for']?.split(',')[0] ||
      req.headers['x-real-ip'] ||
      'unknown';

    const userAgent = req.headers['user-agent'] || '';
    const referrer = req.headers.referer || req.headers.referrer;

    // Parse device info and geographic data
    const { deviceType, browser, os } = parseUserAgent(userAgent);
    const geoData = getGeoFromIP(ipAddress);

    // Parse UTM parameters
    const utmSource = req.query.utm_source;
    const utmMedium = req.query.utm_medium;
    const utmCampaign = req.query.utm_campaign;

    // Current page info
    const currentPage = {
      url: req.originalUrl,
      title: req.headers['page-title'] || req.originalUrl,
      visitedAt: new Date(),
      referrer: referrer,
    };

    // Check if visitor exists
    let visitor = await Visitor.findOne({ sessionId });

    if (visitor) {
      // Update existing visitor
      visitor.lastVisit = new Date();
      visitor.totalVisits += 1;
      visitor.totalPageViews += 1;
      visitor.pages.push(currentPage);

      // Keep only last 50 page views per visitor to avoid bloat
      if (visitor.pages.length > 50) {
        visitor.pages = visitor.pages.slice(-50);
      }

      await visitor.save();
    } else {
      // Create new visitor
      visitor = new Visitor({
        sessionId,
        ipAddress,
        userAgent: userAgent.substring(0, 500), // Limit length

        location: {
          country: geoData.country,
          city: geoData.city,
          region: geoData.region,
          timezone: geoData.timezone,
          coordinates: geoData.coordinates,
        },

        device: {
          type: deviceType,
          browser: browser,
          os: os,
        },

        pages: [currentPage],

        referrer: referrer,
        campaign: {
          source: utmSource,
          medium: utmMedium,
          name: utmCampaign,
        },
      });

      await visitor.save();
    }

    // Add visitor info to request
    req.visitor = visitor;

    // Log activity in activity_logs collection
    await logVisitorActivity({
      type: 'page_view',
      sessionId: sessionId,
      details: {
        page: req.originalUrl,
        userAgent: userAgent.substring(0, 200),
        ipAddress: ipAddress,
        country: geoData.country,
        city: geoData.city,
        device: deviceType,
        browser: browser,
      },
    });

    // Set session cookie for future visits
    if (!req.cookies?.sessionId) {
      res.cookie('sessionId', sessionId, {
        maxAge: 30 * 24 * 60 * 60 * 1000, // 30 days
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
      });
    }

    next();
  } catch (error) {
    console.error('Visitor tracking error:', error);
    next(); // Continue even if tracking fails
  }
};

// Activity Logging Function
const logVisitorActivity = async activityData => {
  try {
    const ActivityLog = mongoose.model('ActivityLog');

    await ActivityLog.create({
      sessionId: activityData.sessionId || 'anonymous',
      action: 'PAGE_VIEW',
      route: activityData.route,
      method: activityData.method || 'GET',
      ipAddress: activityData.details?.ipAddress,
      userAgent: activityData.details?.userAgent,
      metadata: activityData.details || {},
    });
  } catch (error) {
    console.error('Activity logging error:', error);
  }
};

// Analytics Functions
const getVisitorAnalytics = async (timeframe = '24h') => {
  const now = new Date();
  let startDate;

  switch (timeframe) {
    case '1h':
      startDate = new Date(now.getTime() - 60 * 60 * 1000);
      break;
    case '24h':
      startDate = new Date(now.getTime() - 24 * 60 * 60 * 1000);
      break;
    case '7d':
      startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      break;
    case '30d':
      startDate = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
      break;
    default:
      startDate = new Date(now.getTime() - 24 * 60 * 60 * 1000);
  }

  try {
    const [totalVisitors, uniqueVisitors, topCountries, topPages, deviceStats, browserStats] =
      await Promise.all([
        // Total visitors
        Visitor.countDocuments({ lastVisit: { $gte: startDate } }),

        // Unique visitors by IP
        Visitor.aggregate([
          { $match: { lastVisit: { $gte: startDate } } },
          { $group: { _id: '$ipAddress' } },
          { $count: 'uniqueVisitors' },
        ]),

        // Top countries
        Visitor.aggregate([
          { $match: { lastVisit: { $gte: startDate } } },
          { $group: { _id: '$location.country', count: { $sum: 1 } } },
          { $sort: { count: -1 } },
          { $limit: 10 },
        ]),

        // Top pages
        Visitor.aggregate([
          { $match: { lastVisit: { $gte: startDate } } },
          { $unwind: '$pages' },
          { $match: { 'pages.visitedAt': { $gte: startDate } } },
          { $group: { _id: '$pages.url', count: { $sum: 1 } } },
          { $sort: { count: -1 } },
          { $limit: 10 },
        ]),

        // Device statistics
        Visitor.aggregate([
          { $match: { lastVisit: { $gte: startDate } } },
          { $group: { _id: '$device.type', count: { $sum: 1 } } },
          { $sort: { count: -1 } },
        ]),

        // Browser statistics
        Visitor.aggregate([
          { $match: { lastVisit: { $gte: startDate } } },
          { $group: { _id: '$device.browser', count: { $sum: 1 } } },
          { $sort: { count: -1 } },
        ]),
      ]);

    return {
      timeframe,
      totalVisitors,
      uniqueVisitors: uniqueVisitors[0]?.uniqueVisitors || 0,
      topCountries,
      topPages,
      deviceStats,
      browserStats,
      generatedAt: new Date(),
    };
  } catch (error) {
    console.error('Analytics query error:', error);
    return {
      timeframe,
      totalVisitors: 0,
      uniqueVisitors: 0,
      topCountries: [],
      topPages: [],
      deviceStats: [],
      browserStats: [],
      error: error.message,
    };
  }
};

// Get current active visitors (last 5 minutes)
const getCurrentActiveVisitors = async () => {
  try {
    const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000);
    return await Visitor.countDocuments({
      lastVisit: { $gte: fiveMinutesAgo },
    });
  } catch (error) {
    console.error('Active visitors error:', error);
    return 0;
  }
};

// Get recent visitors
const getRecentVisitors = async (limit = 50) => {
  try {
    const twentyFourHoursAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);

    return await Visitor.find({
      lastVisit: { $gte: twentyFourHoursAgo },
    })
      .select('location device firstVisit lastVisit totalVisits totalPageViews ipAddress sessionId')
      .sort({ lastVisit: -1 })
      .limit(limit);
  } catch (error) {
    console.error('Recent visitors error:', error);
    return [];
  }
};

module.exports = {
  trackVisitor,
  getVisitorAnalytics,
  getCurrentActiveVisitors,
  getRecentVisitors,
  Visitor,
  logVisitorActivity,
};
