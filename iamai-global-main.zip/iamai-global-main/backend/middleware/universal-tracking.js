/**
 * ============================================
 * IAMAI-GLOBAL UNIVERSAL TRACKING MIDDLEWARE
 * ============================================
 *
 * Automatically tracks ALL user actions across the platform
 * Every page view, every click, every action → Database
 *
 * This is the PROFESSIONAL way to do it!
 * ============================================
 */

const mongoose = require('mongoose');

// ============================================
// MODELS (Create if not exist)
// ============================================

// Tool Usage Schema
const toolUsageSchema = new mongoose.Schema(
  {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', sparse: true },
    sessionId: { type: String },
    tool: { type: String, required: true },
    input: { type: mongoose.Schema.Types.Mixed },
    result: { type: mongoose.Schema.Types.Mixed },
    error: { type: String },
    success: { type: Boolean, default: true },
    latency: { type: Number }, // ms
    ipAddress: { type: String },
    userAgent: { type: String },
    timestamp: { type: Date, default: Date.now },
  },
  { collection: 'tool_usage' }
);

toolUsageSchema.index({ userId: 1, tool: 1, timestamp: -1 });
toolUsageSchema.index({ tool: 1, timestamp: -1 });

// AI Lab Experiments Schema
const aiLabExperimentSchema = new mongoose.Schema(
  {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    type: {
      type: String,
      required: true,
      enum: [
        'playground',
        'battle',
        'sentiment',
        'cost_calculation',
        'code',
        'latency',
        'transformers',
      ],
    },
    model: { type: String },
    models: [{ type: String }], // For battle mode
    prompt: { type: String },
    parameters: {
      temperature: { type: Number },
      maxTokens: { type: Number },
      topP: { type: Number },
    },
    response: { type: String },
    results: [{ type: mongoose.Schema.Types.Mixed }], // For battle mode
    metrics: {
      latency: { type: Number },
      tokens: { type: Number },
      cost: { type: Number },
    },
    inputText: { type: String }, // For sentiment
    sentimentResult: { type: mongoose.Schema.Types.Mixed },
    code: { type: String }, // For code playground
    language: { type: String },
    output: { type: String },
    startedAt: { type: Date, default: Date.now },
    completedAt: { type: Date },
    status: { type: String, enum: ['pending', 'completed', 'failed'], default: 'pending' },
  },
  {
    collection: 'ai_lab_experiments',
    timestamps: true,
  }
);

aiLabExperimentSchema.index({ userId: 1, type: 1, createdAt: -1 });

// Security Logs Schema
const securityLogSchema = new mongoose.Schema(
  {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', sparse: true },
    event: {
      type: String,
      required: true,
      enum: [
        'LOGIN_SUCCESS',
        'LOGIN_FAILED',
        'LOGOUT',
        'PASSWORD_CHANGE',
        'PASSWORD_RESET_REQUEST',
        'PASSWORD_RESET_COMPLETE',
        'EMAIL_CHANGE',
        'EMAIL_VERIFIED',
        '2FA_ENABLED',
        '2FA_DISABLED',
        '2FA_VERIFIED',
        '2FA_FAILED',
        'SESSION_CREATED',
        'SESSION_REVOKED',
        'ALL_SESSIONS_REVOKED',
        'ACCOUNT_LOCKED',
        'ACCOUNT_UNLOCKED',
        'API_KEY_CREATED',
        'API_KEY_REVOKED',
        'SUSPICIOUS_ACTIVITY',
        'RATE_LIMIT_EXCEEDED',
      ],
    },
    ipAddress: { type: String },
    userAgent: { type: String },
    location: {
      country: { type: String },
      city: { type: String },
      coordinates: { type: [Number] },
    },
    details: { type: mongoose.Schema.Types.Mixed },
    severity: {
      type: String,
      enum: ['low', 'medium', 'high', 'critical'],
      default: 'low',
    },
    timestamp: { type: Date, default: Date.now },
  },
  { collection: 'security_logs' }
);

securityLogSchema.index({ userId: 1, event: 1, timestamp: -1 });
securityLogSchema.index({ severity: 1, timestamp: -1 });
securityLogSchema.index({ ipAddress: 1, timestamp: -1 });

// Prompt Templates Schema
const promptTemplateSchema = new mongoose.Schema(
  {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    name: { type: String, required: true },
    prompt: { type: String, required: true },
    category: { type: String },
    tags: [{ type: String }],
    isPublic: { type: Boolean, default: false },
    usageCount: { type: Number, default: 0 },
    lastUsedAt: { type: Date },
  },
  {
    collection: 'prompt_templates',
    timestamps: true,
  }
);

promptTemplateSchema.index({ userId: 1, category: 1 });
promptTemplateSchema.index({ isPublic: 1, usageCount: -1 });

// Export models
const ToolUsage = mongoose.models.ToolUsage || mongoose.model('ToolUsage', toolUsageSchema);
const AILabExperiment =
  mongoose.models.AILabExperiment || mongoose.model('AILabExperiment', aiLabExperimentSchema);
const SecurityLog = mongoose.models.SecurityLog || mongoose.model('SecurityLog', securityLogSchema);
const PromptTemplate =
  mongoose.models.PromptTemplate || mongoose.model('PromptTemplate', promptTemplateSchema);

// ============================================
// TRACKING SERVICE
// ============================================

class TrackingService {
  // Get models (import existing ones if available)
  static async getModels() {
    const { User, ActivityLog, Chat } = require('../models.cjs');
    const { AgentPurchase } = require('../agent-purchase-models');

    // Try to get existing models
    let Visitor,
      Transaction,
      WebhookEvent,
      NotificationSettings,
      SupportTicket,
      ContactForm,
      FileUpload,
      ApiKey;

    try {
      Visitor = mongoose.models.Visitor || require('../models.cjs').Visitor;
    } catch (e) {
      Visitor = mongoose.model(
        'Visitor',
        new mongoose.Schema({}, { strict: false, collection: 'visitors' })
      );
    }

    try {
      Transaction = mongoose.models.Transaction || require('../models.cjs').Transaction;
    } catch (e) {
      Transaction = mongoose.model(
        'Transaction',
        new mongoose.Schema({}, { strict: false, collection: 'transactions' })
      );
    }

    try {
      WebhookEvent = mongoose.models.WebhookEvent || require('../models.cjs').WebhookEvent;
    } catch (e) {
      WebhookEvent = mongoose.model(
        'WebhookEvent',
        new mongoose.Schema({}, { strict: false, collection: 'webhook_events' })
      );
    }

    try {
      NotificationSettings =
        mongoose.models.NotificationSettings || require('../models.cjs').NotificationSettings;
    } catch (e) {
      NotificationSettings = mongoose.model(
        'NotificationSettings',
        new mongoose.Schema({}, { strict: false, collection: 'notification_settings' })
      );
    }

    try {
      SupportTicket = mongoose.models.SupportTicket || require('../models.cjs').SupportTicket;
    } catch (e) {
      SupportTicket = mongoose.model(
        'SupportTicket',
        new mongoose.Schema({}, { strict: false, collection: 'support_tickets' })
      );
    }

    try {
      ContactForm = mongoose.models.ContactForm || require('../models.cjs').ContactForm;
    } catch (e) {
      ContactForm = mongoose.model(
        'ContactForm',
        new mongoose.Schema({}, { strict: false, collection: 'contact_forms' })
      );
    }

    try {
      FileUpload = mongoose.models.FileUpload || require('../models.cjs').FileUpload;
    } catch (e) {
      FileUpload = mongoose.model(
        'FileUpload',
        new mongoose.Schema({}, { strict: false, collection: 'file_uploads' })
      );
    }

    try {
      ApiKey = mongoose.models.ApiKey || require('../models.cjs').ApiKey;
    } catch (e) {
      ApiKey = mongoose.model(
        'ApiKey',
        new mongoose.Schema({}, { strict: false, collection: 'api_keys' })
      );
    }

    return {
      User,
      ActivityLog,
      Chat,
      AgentPurchase,
      Visitor,
      Transaction,
      WebhookEvent,
      NotificationSettings,
      SupportTicket,
      ContactForm,
      FileUpload,
      ApiKey,
      ToolUsage,
      AILabExperiment,
      SecurityLog,
      PromptTemplate,
    };
  }

  // ============================================
  // ACTIVITY LOGGING
  // ============================================

  static async logActivity(data) {
    try {
      const { ActivityLog } = await this.getModels();

      const log = new ActivityLog({
        userId: data.userId || null,
        sessionId: data.sessionId,
        isAnonymous: !data.userId,
        action: data.action,
        category: data.category || 'system',
        resource: data.resource,
        details: data.details || {},
        result: data.result || 'success',
        errorMessage: data.errorMessage,
        ipAddress: data.ipAddress,
        userAgent: data.userAgent,
        referrer: data.referrer,
        metadata: data.metadata || {},
        severity: data.severity || 'low',
        createdAt: new Date(),
      });

      await log.save();
      return log;
    } catch (error) {
      console.error('[TRACKING] Failed to log activity:', error.message);
      return null;
    }
  }

  // ============================================
  // VISITOR TRACKING
  // ============================================

  static async trackVisitor(data) {
    try {
      const { Visitor } = await this.getModels();

      // Find or create visitor
      let visitor = await Visitor.findOne({ sessionId: data.sessionId });

      if (!visitor) {
        visitor = new Visitor({
          sessionId: data.sessionId,
          visitorId: data.visitorId,
          userId: data.userId || null,
          firstVisit: new Date(),
          lastVisit: new Date(),
          landingPage: data.page,
          referrer: data.referrer,
          device: data.device || {},
          location: data.location || {},
          campaign: data.campaign || {},
          pageViews: [
            {
              path: data.page,
              timestamp: new Date(),
            },
          ],
          totalPageViews: 1,
        });
      } else {
        // Update existing visitor
        visitor.lastVisit = new Date();
        visitor.totalPageViews += 1;
        visitor.pageViews.push({
          path: data.page,
          timestamp: new Date(),
          duration: data.duration,
        });

        // Link to user if they logged in
        if (data.userId && !visitor.userId) {
          visitor.userId = data.userId;
          visitor.isConverted = true;
          visitor.conversionDate = new Date();
        }
      }

      await visitor.save();
      return visitor;
    } catch (error) {
      console.error('[TRACKING] Failed to track visitor:', error.message);
      return null;
    }
  }

  // ============================================
  // SECURITY LOGGING
  // ============================================

  static async logSecurityEvent(data) {
    try {
      const log = new SecurityLog({
        userId: data.userId,
        event: data.event,
        ipAddress: data.ipAddress,
        userAgent: data.userAgent,
        location: data.location,
        details: data.details,
        severity: data.severity || 'low',
        timestamp: new Date(),
      });

      await log.save();

      // Also log to activity_logs for unified view
      await this.logActivity({
        userId: data.userId,
        action: data.event,
        category: 'security',
        ipAddress: data.ipAddress,
        userAgent: data.userAgent,
        details: data.details,
        severity: data.severity,
      });

      return log;
    } catch (error) {
      console.error('[TRACKING] Failed to log security event:', error.message);
      return null;
    }
  }

  // ============================================
  // TOOL USAGE TRACKING
  // ============================================

  static async trackToolUsage(data) {
    try {
      const usage = new ToolUsage({
        userId: data.userId,
        sessionId: data.sessionId,
        tool: data.tool,
        input: data.input,
        result: data.result,
        error: data.error,
        success: !data.error,
        latency: data.latency,
        ipAddress: data.ipAddress,
        userAgent: data.userAgent,
        timestamp: new Date(),
      });

      await usage.save();

      // Also log to activity_logs
      await this.logActivity({
        userId: data.userId,
        sessionId: data.sessionId,
        action: 'TOOL_USE',
        category: 'analytics',
        resource: `tool:${data.tool}`,
        details: {
          tool: data.tool,
          success: !data.error,
          latency: data.latency,
        },
        ipAddress: data.ipAddress,
        userAgent: data.userAgent,
      });

      return usage;
    } catch (error) {
      console.error('[TRACKING] Failed to track tool usage:', error.message);
      return null;
    }
  }

  // ============================================
  // AI LAB EXPERIMENT TRACKING
  // ============================================

  static async trackExperiment(data) {
    try {
      const experiment = new AILabExperiment({
        userId: data.userId,
        type: data.type,
        model: data.model,
        models: data.models,
        prompt: data.prompt,
        parameters: data.parameters,
        response: data.response,
        results: data.results,
        metrics: data.metrics,
        inputText: data.inputText,
        sentimentResult: data.sentimentResult,
        code: data.code,
        language: data.language,
        output: data.output,
        startedAt: data.startedAt || new Date(),
        completedAt: data.completedAt,
        status: data.status || 'pending',
      });

      await experiment.save();

      // Log to activity
      await this.logActivity({
        userId: data.userId,
        action: 'AI_LAB_EXPERIMENT',
        category: 'analytics',
        resource: `experiment:${data.type}`,
        details: {
          type: data.type,
          model: data.model || data.models,
          status: data.status,
        },
      });

      return experiment;
    } catch (error) {
      console.error('[TRACKING] Failed to track experiment:', error.message);
      return null;
    }
  }

  // ============================================
  // TRANSACTION RECORDING
  // ============================================

  static async recordTransaction(data) {
    try {
      const { Transaction } = await this.getModels();

      const transaction = new Transaction({
        userId: data.userId,
        type: data.type, // 'PURCHASE', 'REFUND', 'CREDIT'
        amount: data.amount,
        currency: data.currency || 'USD',
        status: data.status || 'completed',
        description: data.description,
        stripePaymentIntentId: data.stripePaymentIntentId,
        stripeInvoiceId: data.stripeInvoiceId,
        paymentMethod: data.paymentMethod,
        agentId: data.agentId,
        purchaseId: data.purchaseId,
        metadata: data.metadata || {},
        createdAt: new Date(),
      });

      await transaction.save();

      // Log to activity
      await this.logActivity({
        userId: data.userId,
        action: 'TRANSACTION',
        category: 'subscription',
        resource: `transaction:${transaction._id}`,
        details: {
          type: data.type,
          amount: data.amount,
          currency: data.currency,
        },
      });

      return transaction;
    } catch (error) {
      console.error('[TRACKING] Failed to record transaction:', error.message);
      return null;
    }
  }

  // ============================================
  // WEBHOOK EVENT RECORDING
  // ============================================

  static async recordWebhookEvent(data) {
    try {
      const { WebhookEvent } = await this.getModels();

      const event = new WebhookEvent({
        source: data.source, // 'stripe', 'paypal'
        eventType: data.eventType,
        eventId: data.eventId,
        payload: data.payload,
        status: data.status || 'received',
        error: data.error,
        processingTime: data.processingTime,
        retryCount: data.retryCount || 0,
        createdAt: new Date(),
        processedAt: data.processedAt,
      });

      await event.save();
      return event;
    } catch (error) {
      console.error('[TRACKING] Failed to record webhook event:', error.message);
      return null;
    }
  }

  // ============================================
  // CHAT MESSAGE TRACKING
  // ============================================

  static async trackChatMessage(data) {
    try {
      const { Chat, AgentPurchase, User } = await this.getModels();
      const Agent = mongoose.models.Agent;

      // Find or create chat
      let chat = await Chat.findOne({
        participants: data.userId,
        agentType: data.agentId,
      });

      if (!chat) {
        chat = new Chat({
          participants: [data.userId],
          agentType: data.agentId,
          title: `Chat with ${data.agentName || data.agentId}`,
          isActive: true,
          messages: [],
          createdAt: new Date(),
        });
      }

      // Add message
      chat.messages.push({
        sender: data.role, // 'user' or 'assistant'
        content: data.content,
        timestamp: new Date(),
        type: data.type || 'text',
        metadata: data.metadata || {},
      });

      chat.lastMessageAt = new Date();
      await chat.save();

      // Update purchase usage
      if (data.userId) {
        await AgentPurchase.updateOne(
          { userId: data.userId, agentId: data.agentId, status: { $in: ['ACTIVE', 'active'] } },
          {
            $inc: { 'currentUsage.messagesUsed': 1 },
            $set: { 'currentUsage.lastMessageAt': new Date() },
          }
        );
      }

      // Update user stats
      if (data.userId && data.role === 'user') {
        await User.updateOne({ _id: data.userId }, { $inc: { 'statistics.totalMessages': 1 } });
      }

      // Update agent stats
      if (Agent) {
        await Agent.updateOne({ agentId: data.agentId }, { $inc: { 'stats.totalMessages': 1 } });
      }

      // Log activity
      await this.logActivity({
        userId: data.userId,
        action: data.role === 'user' ? 'MESSAGE_SENT' : 'MESSAGE_RECEIVED',
        category: 'agent',
        resource: `agent:${data.agentId}`,
        details: {
          agentId: data.agentId,
          messageType: data.type || 'text',
        },
      });

      return chat;
    } catch (error) {
      console.error('[TRACKING] Failed to track chat message:', error.message);
      return null;
    }
  }

  // ============================================
  // NOTIFICATION SETTINGS
  // ============================================

  static async ensureNotificationSettings(userId) {
    try {
      const { NotificationSettings } = await this.getModels();

      let settings = await NotificationSettings.findOne({ userId });

      if (!settings) {
        settings = new NotificationSettings({
          userId,
          email: {
            enabled: true,
            marketing: true,
            productUpdates: true,
            securityAlerts: true,
            weeklyDigest: false,
          },
          push: {
            enabled: true,
            newMessages: true,
            agentResponses: true,
          },
          sms: {
            enabled: false,
            phoneNumber: null,
          },
          inApp: {
            enabled: true,
            sounds: true,
          },
          createdAt: new Date(),
        });

        await settings.save();
      }

      return settings;
    } catch (error) {
      console.error('[TRACKING] Failed to ensure notification settings:', error.message);
      return null;
    }
  }
}

// ============================================
// EXPRESS MIDDLEWARE
// ============================================

/**
 * Universal tracking middleware
 * Automatically tracks all API requests
 */
const trackingMiddleware = async (req, res, next) => {
  const startTime = Date.now();

  // Store original end to intercept response
  const originalEnd = res.end;

  res.end = function (...args) {
    const duration = Date.now() - startTime;

    // Don't track health checks or static files
    const skipPaths = ['/health', '/api/health', '/favicon.ico', '/static'];
    if (skipPaths.some(p => req.path.startsWith(p))) {
      return originalEnd.apply(res, args);
    }

    // Track the request asynchronously (don't block response)
    setImmediate(async () => {
      try {
        const userId = req.userId || req.session?.userId || null;
        const sessionId = req.sessionId || req.session?.id || req.headers['x-session-id'];

        // Determine action from route
        const action = getActionFromRoute(req.method, req.path);
        const category = getCategoryFromRoute(req.path);

        await TrackingService.logActivity({
          userId,
          sessionId,
          action,
          category,
          resource: req.path,
          details: {
            method: req.method,
            path: req.path,
            query: req.query,
            statusCode: res.statusCode,
            duration,
          },
          result: res.statusCode < 400 ? 'success' : 'failure',
          ipAddress: req.ip || req.connection?.remoteAddress,
          userAgent: req.headers['user-agent'],
          referrer: req.headers['referer'],
        });
      } catch (error) {
        console.error('[TRACKING MIDDLEWARE] Error:', error.message);
      }
    });

    return originalEnd.apply(res, args);
  };

  next();
};

// Helper to determine action from route
function getActionFromRoute(method, path) {
  // Auth routes
  if (path.includes('/auth/register')) return 'REGISTER';
  if (path.includes('/auth/login')) return 'LOGIN';
  if (path.includes('/auth/logout')) return 'LOGOUT';
  if (path.includes('/auth/forgot-password')) return 'PASSWORD_RESET_REQUEST';

  // Security routes
  if (path.includes('/security/password')) return 'PASSWORD_CHANGE';
  if (path.includes('/security/email')) return 'EMAIL_CHANGE';
  if (path.includes('/security/2fa')) return '2FA_ACTION';

  // Purchase routes
  if (path.includes('/purchase') && method === 'POST') return 'PURCHASE_INITIATED';
  if (path.includes('/access') && method === 'GET') return 'ACCESS_CHECK';
  if (path.includes('/cancel')) return 'PURCHASE_CANCELLED';

  // Chat routes
  if (path.includes('/chat/message')) return 'CHAT_MESSAGE';
  if (path.includes('/chat/start')) return 'CHAT_START';
  if (path.includes('/chat/history')) return 'CHAT_HISTORY_LOAD';

  // Support routes
  if (path.includes('/support/tickets') && method === 'POST') return 'TICKET_CREATE';
  if (path.includes('/contact') && method === 'POST') return 'CONTACT_SUBMIT';

  // Tool routes
  if (path.includes('/tools/')) return 'TOOL_USE';

  // AI Lab routes
  if (path.includes('/ai-lab/')) return 'AI_LAB_EXPERIMENT';

  // Default
  if (method === 'GET') return 'DATA_READ';
  if (method === 'POST') return 'DATA_CREATE';
  if (method === 'PUT' || method === 'PATCH') return 'DATA_UPDATE';
  if (method === 'DELETE') return 'DATA_DELETE';

  return 'API_REQUEST';
}

// Helper to determine category from route
function getCategoryFromRoute(path) {
  if (path.includes('/auth/')) return 'auth';
  if (path.includes('/security/')) return 'security';
  if (path.includes('/agents/') || path.includes('/chat/')) return 'agent';
  if (path.includes('/profile') || path.includes('/users/')) return 'profile';
  if (path.includes('/purchase') || path.includes('/billing')) return 'subscription';
  if (path.includes('/upload') || path.includes('/file')) return 'file';
  if (path.includes('/analytics') || path.includes('/tools/')) return 'analytics';
  return 'system';
}

// ============================================
// EXPORTS
// ============================================

module.exports = {
  TrackingService,
  trackingMiddleware,

  // Models
  ToolUsage,
  AILabExperiment,
  SecurityLog,
  PromptTemplate,
};
