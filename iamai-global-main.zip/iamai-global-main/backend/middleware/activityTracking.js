/**
 * Comprehensive Activity Tracking Middleware
 * Logs all user interactions - logged in, anonymous, demo chats, studio usage, etc.
 */

const { v4: uuidv4 } = require('uuid');

/**
 * Generate or retrieve session ID from request
 */
function getSessionId(req) {
  // Check session from various sources
  return (
    req.sessionId ||
    req.headers['x-session-id'] ||
    req.cookies?.sessionId ||
    req.query.sessionId ||
    `anon_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
  );
}

/**
 * Get user ID from authenticated request
 */
function getUserId(req) {
  const mongoose = require('mongoose');

  // Try multiple ways to get user ID
  const userId = req.userId || req.user?._id || req.user?.id;

  // Validate it's not null and convert to ObjectId
  if (userId && userId.toString() !== 'null') {
    try {
      // Ensure it's a valid ObjectId
      return new mongoose.Types.ObjectId(userId);
    } catch (error) {
      console.warn('⚠️ Invalid userId format:', userId);
      return null;
    }
  }

  return null;
}

/**
 * Determine if user is anonymous
 */
function isAnonymous(req) {
  return !getUserId(req);
}

/**
 * Map route to action type and category
 */
function mapRouteToAction(method, path) {
  const normalizedPath = path || '';

  // Authentication
  if (path.includes('/auth/signup')) return { action: 'SIGNUP_ATTEMPT', category: 'auth' };
  if (path.includes('/auth/signin') || path.includes('/auth/login'))
    return { action: 'LOGIN_ATTEMPT', category: 'auth' };
  if (path.includes('/auth/logout')) return { action: 'LOGOUT', category: 'auth' };

  // Chat
  if (normalizedPath.includes('/ai/chat'))
    return { action: 'DEMO_CHAT_MESSAGE', category: 'agent' };
  if (normalizedPath.includes('/chat')) return { action: 'AI_CHAT_MESSAGE', category: 'agent' };

  // Studio
  if (normalizedPath.includes('/studio')) return { action: 'STUDIO_VISIT', category: 'agent' };
  if (normalizedPath.includes('/api/users/agents'))
    return { action: 'CUSTOM_AGENT_LIST', category: 'agent' };
  if (normalizedPath.includes('/agents')) return { action: 'AGENT_SELECTED', category: 'agent' };

  // Profile
  if (normalizedPath.includes('/profile')) return { action: 'PROFILE_UPDATE', category: 'profile' };
  if (normalizedPath.includes('/preferences'))
    return { action: 'PREFERENCES_UPDATE', category: 'profile' };
  if (normalizedPath.includes('/password'))
    return { action: 'PASSWORD_CHANGE', category: 'security' };

  // Subscriptions
  if (normalizedPath.includes('/subscription'))
    return { action: 'SUBSCRIPTION_VIEW', category: 'subscription' };

  // General API
  return { action: 'API_CALL', category: 'system' };
}

/**
 * Extract client IP address
 */
function getClientIP(req) {
  return (
    req.headers['x-forwarded-for']?.split(',')[0] ||
    req.headers['x-real-ip'] ||
    req.connection?.remoteAddress ||
    req.socket?.remoteAddress ||
    'unknown'
  );
}

/**
 * Activity Tracking Middleware
 */
function activityTrackingMiddleware(ActivityLog) {
  return async (req, res, next) => {
    const startTime = Date.now();

    // Get session and user info
    const sessionId = getSessionId(req);
    const userId = getUserId(req);
    const anonymous = isAnonymous(req);

    // Attach session to request for downstream use
    req.sessionId = sessionId;
    req.isAnonymous = anonymous;

    // Store original end function
    const originalEnd = res.end;
    const originalJson = res.json;

    let activityLogged = false;

    // Override res.end to capture response
    res.end = function (chunk, encoding) {
      if (!activityLogged) {
        logActivity();
      }
      originalEnd.call(this, chunk, encoding);
    };

    // Override res.json to capture response
    res.json = function (data) {
      if (!activityLogged) {
        logActivity(data);
      }
      return originalJson.call(this, data);
    };

    // Log activity function
    async function logActivity(responseData) {
      if (activityLogged) return;
      activityLogged = true;

      const responseTime = Date.now() - startTime;
      const actionInfo = mapRouteToAction(req.method, req.originalUrl || req.path);

      try {
        // Re-check user authentication at logging time (after auth middleware has run)
        const finalUserId = getUserId(req);
        const finalAnonymous = isAnonymous(req);

        // Debug log for troubleshooting
        if (req.path.startsWith('/api/') && !finalAnonymous && !finalUserId) {
          console.warn('⚠️ Activity tracking: Authenticated request but no userId found', {
            path: req.path,
            hasUser: !!req.user,
            reqUserId: req.userId,
            userIdFromUser: req.user?._id,
          });
        }

        // Determine if action was successful
        const isSuccess = res.statusCode >= 200 && res.statusCode < 400;

        // Adjust action based on response status for auth routes
        let finalAction = actionInfo.action;
        if (actionInfo.action === 'SIGNUP_ATTEMPT') {
          finalAction = isSuccess ? 'SIGNUP_SUCCESS' : 'SIGNUP_FAILED';
        } else if (actionInfo.action === 'LOGIN_ATTEMPT') {
          finalAction = isSuccess ? 'LOGIN_SUCCESS' : 'LOGIN_FAILED';
        }

        // Create activity log
        const activityData = {
          userId: finalUserId,
          sessionId: sessionId,
          action: finalAction,
          category: actionInfo.category,
          route: req.path,
          method: req.method,
          statusCode: res.statusCode,
          ipAddress: getClientIP(req),
          userAgent: req.headers['user-agent'] || 'unknown',
          referrer: req.headers['referer'] || req.headers['referrer'],
          responseTime: responseTime,
          isAnonymous: finalAnonymous,
          metadata: {
            query: req.query,
            body: sanitizeBody(req.body),
            response: sanitizeResponse(responseData),
            headers: {
              origin: req.headers['origin'],
              host: req.headers['host'],
            },
          },
        };

        // Save to database (non-blocking)
        await ActivityLog.create(activityData);

        console.log(
          `📊 Activity logged: ${finalAction} by ${finalAnonymous ? 'anonymous' : 'user'} (${sessionId.substring(0, 8)}...) - ${responseTime}ms`
        );
      } catch (error) {
        console.error('❌ Failed to log activity:', error.message);
      }
    }

    next();
  };
}

/**
 * Sanitize request body (remove sensitive data)
 */
function sanitizeBody(body) {
  if (!body || typeof body !== 'object') return body;

  const sanitized = { ...body };
  const sensitiveFields = ['password', 'token', 'secret', 'apiKey', 'creditCard'];

  for (const field of sensitiveFields) {
    if (sanitized[field]) {
      sanitized[field] = '***REDACTED***';
    }
  }

  return sanitized;
}

/**
 * Sanitize response data (remove sensitive data)
 */
function sanitizeResponse(response) {
  if (!response || typeof response !== 'object') return response;

  const sanitized = { ...response };
  const sensitiveFields = ['password', 'token', 'secret', 'apiKey'];

  for (const field of sensitiveFields) {
    if (sanitized[field]) {
      sanitized[field] = '***REDACTED***';
    }
  }

  // Limit response size in logs
  const str = JSON.stringify(sanitized);
  if (str.length > 500) {
    return { truncated: true, length: str.length, preview: str.substring(0, 500) + '...' };
  }

  return sanitized;
}

/**
 * Log specific activity (for manual logging)
 */
async function logActivity(ActivityLog, data) {
  try {
    await ActivityLog.create(data);
    console.log(`📊 Manual activity logged: ${data.action}`);
  } catch (error) {
    console.error('❌ Failed to log manual activity:', error.message);
  }
}

module.exports = {
  activityTrackingMiddleware,
  logActivity,
  getSessionId,
  getUserId,
  isAnonymous,
};
