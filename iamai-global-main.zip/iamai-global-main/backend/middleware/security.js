// Enhanced Security Middleware
const rateLimit = require('express-rate-limit');
const slowDown = require('express-slow-down');
const validator = require('validator');
const { APIError } = require('./errorHandling');

// Input sanitization middleware
const sanitizeInput = (req, res, next) => {
  const sanitizeObject = obj => {
    for (let key in obj) {
      if (typeof obj[key] === 'string') {
        // Remove potential XSS attacks
        obj[key] = validator.escape(obj[key]);

        // Remove SQL injection attempts
        obj[key] = obj[key].replace(/['";\\]/g, '');

        // Limit string length
        if (obj[key].length > 10000) {
          obj[key] = obj[key].substring(0, 10000);
        }
      } else if (typeof obj[key] === 'object' && obj[key] !== null) {
        sanitizeObject(obj[key]);
      }
    }
  };

  if (req.body && typeof req.body === 'object') {
    sanitizeObject(req.body);
  }

  if (req.query && typeof req.query === 'object') {
    sanitizeObject(req.query);
  }

  next();
};

// Request validation middleware
const validateRequest = (req, res, next) => {
  // Check content length
  const contentLength = parseInt(req.get('content-length') || '0');
  if (contentLength > 10 * 1024 * 1024) {
    // 10MB limit
    return next(new APIError('Request payload too large', 413, 'PAYLOAD_TOO_LARGE'));
  }

  // Validate Content-Type for POST/PUT requests
  if (['POST', 'PUT', 'PATCH'].includes(req.method)) {
    const contentType = req.get('content-type');
    if (
      !contentType ||
      (!contentType.includes('application/json') && !contentType.includes('multipart/form-data'))
    ) {
      return next(new APIError('Invalid content type', 400, 'INVALID_CONTENT_TYPE'));
    }
  }

  next();
};

// API key validation for certain routes
const validateApiKey = (req, res, next) => {
  const apiKey = req.headers['x-api-key'];
  const validApiKeys = process.env.VALID_API_KEYS?.split(',') || [];

  if (req.path.startsWith('/api/public') || req.path === '/health') {
    return next();
  }

  if (!apiKey || !validApiKeys.includes(apiKey)) {
    return next(new APIError('Invalid or missing API key', 401, 'INVALID_API_KEY'));
  }

  next();
};

// IP-based rate limiting for auth endpoints
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5, // 5 attempts per window
  message: {
    error: 'Too many authentication attempts, please try again later',
    retryAfter: '15 minutes',
  },
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: req => req.ip + ':' + (req.body.email || 'anonymous'),
});

// Slow down repeated requests
const speedLimiter = slowDown({
  windowMs: 15 * 60 * 1000, // 15 minutes
  delayAfter: 2, // allow 2 requests per windowMs at full speed
  delayMs: 500, // add 500ms delay per request after delayAfter
  maxDelayMs: 20000, // max delay of 20 seconds
});

// Security headers middleware
const securityHeaders = (req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'geolocation=(), microphone=(), camera=()');

  next();
};

// Combined security middleware
const securityMiddleware = [securityHeaders, sanitizeInput, validateRequest, speedLimiter];

module.exports = {
  securityMiddleware,
  sanitizeInput,
  validateRequest,
  validateApiKey,
  authLimiter,
  speedLimiter,
  securityHeaders,
};
