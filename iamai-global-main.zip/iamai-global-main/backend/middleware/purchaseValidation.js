// Purchase Validation Middleware - One-Time Payment System
const { AgentPurchase } = require('../models.cjs');

/**
 * Check if user has active access to an agent
 * Replaces old subscription validation for one-time purchase system
 */
const checkAgentPurchase = async (req, res, next) => {
  try {
    const userId = req.user?.id || req.user?._id;
    const agentId = req.params.agentId || req.body.agentId;

    if (!userId) {
      return res.status(401).json({ 
        error: 'Unauthorized',
        message: 'User authentication required'
      });
    }

    if (!agentId) {
      return res.status(400).json({ 
        error: 'Bad Request',
        message: 'Agent ID is required'
      });
    }

    // Check if user has active purchase for this agent
    const hasAccess = await AgentPurchase.hasActiveAccess(userId, agentId);

    if (!hasAccess) {
      return res.status(403).json({ 
        error: 'Access Denied',
        message: 'No active purchase found for this agent. Please purchase access first.',
        agentId,
        purchaseRequired: true
      });
    }

    // Get active purchase details for request context
    const activePurchase = await AgentPurchase.findOne({
      userId,
      agentId,
      status: 'active',
      expirationDate: { $gt: new Date() }
    }).sort({ expirationDate: -1 });

    // Attach purchase info to request
    req.agentPurchase = activePurchase;

    next();
  } catch (error) {
    console.error('Purchase validation error:', error);
    res.status(500).json({ 
      error: 'Validation Error',
      message: 'Failed to validate agent access'
    });
  }
};

/**
 * Check if user has active purchase (backwards compatibility)
 * Alias for checkAgentPurchase
 */
const checkAgentSubscription = checkAgentPurchase;

/**
 * Optional purchase check - continues even if no access
 * Useful for endpoints that work differently with/without access
 */
const optionalPurchaseCheck = async (req, res, next) => {
  try {
    const userId = req.user?.id || req.user?._id;
    const agentId = req.params.agentId || req.body.agentId;

    if (userId && agentId) {
      const hasAccess = await AgentPurchase.hasActiveAccess(userId, agentId);
      const activePurchase = hasAccess ? await AgentPurchase.findOne({
        userId,
        agentId,
        status: 'active',
        expirationDate: { $gt: new Date() }
      }).sort({ expirationDate: -1 }) : null;

      req.agentPurchase = activePurchase;
      req.hasAgentAccess = hasAccess;
    }

    next();
  } catch (error) {
    console.error('Optional purchase check error:', error);
    // Don't block request on error
    next();
  }
};

module.exports = {
  checkAgentPurchase,
  checkAgentSubscription, // Backwards compatibility alias
  optionalPurchaseCheck
};
