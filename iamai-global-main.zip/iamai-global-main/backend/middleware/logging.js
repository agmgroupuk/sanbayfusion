// Enhanced Logging Middleware
const morgan = require('morgan');
const { v4: uuidv4 } = require('uuid');
const logger = require('../logger');

// Add request ID for tracing
const addRequestId = (req, res, next) => {
  req.id = uuidv4();
  res.setHeader('X-Request-ID', req.id);
  next();
};

// Custom morgan format for structured logging
const morganFormat =
  process.env.NODE_ENV === 'production'
    ? 'combined'
    : ':method :url :status :res[content-length] - :response-time ms';

// Morgan stream that writes to our logger
const morganStream = {
  write: message => {
    logger.info('HTTP', { message: message.trim() });
  },
};

// Request/Response logging middleware
const requestLogger = (req, res, next) => {
  const startTime = Date.now();

  // Log request
  logger.info('Request Started', {
    id: req.id,
    method: req.method,
    url: req.originalUrl,
    ip: req.ip,
    userAgent: req.get('User-Agent'),
    contentLength: req.get('content-length'),
    referer: req.get('Referer'),
  });

  // Override res.json to log response
  const originalJson = res.json;
  res.json = function (data) {
    const duration = Date.now() - startTime;

    // Log response
    logger.info('Request Completed', {
      id: req.id,
      method: req.method,
      url: req.originalUrl,
      statusCode: res.statusCode,
      duration,
      contentLength: JSON.stringify(data).length,
    });

    return originalJson.call(this, data);
  };

  next();
};

// Error logging middleware
const errorLogger = (err, req, res, next) => {
  logger.error('Request Error', {
    id: req.id,
    method: req.method,
    url: req.originalUrl,
    error: {
      name: err.name,
      message: err.message,
      stack: err.stack,
      statusCode: err.statusCode || 500,
    },
    ip: req.ip,
    userAgent: req.get('User-Agent'),
  });

  next(err);
};

// Performance monitoring middleware
const performanceLogger = (req, res, next) => {
  const start = process.hrtime.bigint();

  res.on('finish', () => {
    const end = process.hrtime.bigint();
    const duration = Number(end - start) / 1000000; // Convert to milliseconds

    // Log slow requests (> 1 second)
    if (duration > 1000) {
      logger.warn('Slow Request', {
        id: req.id,
        method: req.method,
        url: req.originalUrl,
        duration: `${duration.toFixed(2)}ms`,
        statusCode: res.statusCode,
      });
    }

    // Log memory usage for heavy requests
    const memUsage = process.memoryUsage();
    if (memUsage.heapUsed > 100 * 1024 * 1024) {
      // > 100MB
      logger.warn('High Memory Usage', {
        id: req.id,
        memoryUsage: {
          rss: `${(memUsage.rss / 1024 / 1024).toFixed(2)}MB`,
          heapTotal: `${(memUsage.heapTotal / 1024 / 1024).toFixed(2)}MB`,
          heapUsed: `${(memUsage.heapUsed / 1024 / 1024).toFixed(2)}MB`,
        },
      });
    }
  });

  next();
};

// Combined logging middleware
const loggingMiddleware = [
  addRequestId,
  morgan(morganFormat, { stream: morganStream }),
  requestLogger,
  performanceLogger,
];

module.exports = {
  loggingMiddleware,
  addRequestId,
  requestLogger,
  errorLogger,
  performanceLogger,
};
