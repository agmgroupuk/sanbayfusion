/**
 * Enhanced Profile Validation Middleware
 * Provides comprehensive validation for user profile updates
 */

const validator = require('validator');

/**
 * Validate email format and availability
 */
async function validateEmailUpdate(email, currentUserId, User) {
  if (!email) return { isValid: false, error: 'Email is required' };
  
  if (!validator.isEmail(email)) {
    return { isValid: false, error: 'Invalid email format' };
  }
  
  // Check if email is already taken by another user
  const existingUser = await User.findOne({ 
    email: email.toLowerCase(),
    _id: { $ne: currentUserId }
  });
  
  if (existingUser) {
    return { isValid: false, error: 'Email is already taken' };
  }
  
  return { isValid: true };
}

/**
 * Validate phone number format
 */
function validatePhone(phone) {
  if (!phone) return { isValid: true }; // Phone is optional
  
  // Remove all non-digit characters for validation
  const cleanPhone = phone.replace(/\D/g, '');
  
  if (cleanPhone.length < 10 || cleanPhone.length > 15) {
    return { isValid: false, error: 'Phone number must be 10-15 digits' };
  }
  
  return { isValid: true };
}

/**
 * Validate name fields
 */
function validateName(name, fieldName = 'Name') {
  if (!name) return { isValid: false, error: `${fieldName} is required` };
  
  if (name.length < 2) {
    return { isValid: false, error: `${fieldName} must be at least 2 characters` };
  }
  
  if (name.length > 50) {
    return { isValid: false, error: `${fieldName} cannot exceed 50 characters` };
  }
  
  // Check for valid characters (letters, spaces, hyphens, apostrophes)
  const nameRegex = /^[a-zA-Z\s\-']+$/;
  if (!nameRegex.test(name)) {
    return { isValid: false, error: `${fieldName} contains invalid characters` };
  }
  
  return { isValid: true };
}

/**
 * Validate bio content
 */
function validateBio(bio) {
  if (!bio) return { isValid: true }; // Bio is optional
  
  if (bio.length > 500) {
    return { isValid: false, error: 'Bio cannot exceed 500 characters' };
  }
  
  // Check for potential harmful content (basic XSS prevention)
  const dangerousPatterns = [/<script/i, /javascript:/i, /on\w+=/i];
  if (dangerousPatterns.some(pattern => pattern.test(bio))) {
    return { isValid: false, error: 'Bio contains potentially harmful content' };
  }
  
  return { isValid: true };
}

/**
 * Comprehensive profile validation middleware
 */
async function validateProfileUpdate(req, res, next) {
  try {
    const { name, email, phone, firstName, lastName, bio, address, city, country } = req.body;
    const errors = [];
    
    // Validate required fields
    if (name) {
      const nameValidation = validateName(name, 'Full name');
      if (!nameValidation.isValid) errors.push(nameValidation.error);
    }
    
    if (firstName) {
      const firstNameValidation = validateName(firstName, 'First name');
      if (!firstNameValidation.isValid) errors.push(firstNameValidation.error);
    }
    
    if (lastName) {
      const lastNameValidation = validateName(lastName, 'Last name');
      if (!lastNameValidation.isValid) errors.push(lastNameValidation.error);
    }
    
    // Validate email if provided
    if (email && email !== req.user.email) {
      const { User } = require('../models');
      const emailValidation = await validateEmailUpdate(email, req.userId, User);
      if (!emailValidation.isValid) errors.push(emailValidation.error);
    }
    
    // Validate phone
    if (phone) {
      const phoneValidation = validatePhone(phone);
      if (!phoneValidation.isValid) errors.push(phoneValidation.error);
    }
    
    // Validate bio
    if (bio) {
      const bioValidation = validateBio(bio);
      if (!bioValidation.isValid) errors.push(bioValidation.error);
    }
    
    // If there are validation errors, return them
    if (errors.length > 0) {
      return res.status(400).json({
        success: false,
        error: 'Validation failed',
        details: errors,
        message: errors[0] // First error for simple display
      });
    }
    
    // Sanitize and prepare data for next middleware
    req.validatedData = {
      name: name?.trim(),
      email: email?.toLowerCase().trim(),
      phone: phone?.trim(),
      firstName: firstName?.trim(),
      lastName: lastName?.trim(),
      bio: bio?.trim(),
      // Address fields
      address: address?.trim(),
      city: city?.trim(),
      country: country?.trim()
    };
    
    next();
  } catch (error) {
    console.error('Profile validation error:', error);
    res.status(500).json({
      success: false,
      error: 'Validation error',
      message: 'Failed to validate profile data'
    });
  }
}

/**
 * Settings validation middleware
 */
function validateSettings(req, res, next) {
  try {
    const { preferences, notifications, privacy } = req.body;
    const errors = [];
    
    // Validate preferences
    if (preferences) {
      const { theme, language, timezone } = preferences;
      
      if (theme && !['light', 'dark', 'auto'].includes(theme)) {
        errors.push('Invalid theme selection');
      }
      
      if (language && typeof language !== 'string') {
        errors.push('Invalid language setting');
      }
      
      if (timezone && typeof timezone !== 'string') {
        errors.push('Invalid timezone setting');
      }
    }
    
    // Validate notifications
    if (notifications) {
      const { email, sms, browser, marketing } = notifications;
      
      if (email !== undefined && typeof email !== 'boolean') {
        errors.push('Invalid email notification setting');
      }
      
      if (sms !== undefined && typeof sms !== 'boolean') {
        errors.push('Invalid SMS notification setting');
      }
      
      if (browser !== undefined && typeof browser !== 'boolean') {
        errors.push('Invalid browser notification setting');
      }
      
      if (marketing !== undefined && typeof marketing !== 'boolean') {
        errors.push('Invalid marketing notification setting');
      }
    }
    
    // Validate privacy
    if (privacy) {
      const { profileVisibility, dataSharing, analytics } = privacy;
      
      if (profileVisibility && !['public', 'private', 'friends'].includes(profileVisibility)) {
        errors.push('Invalid profile visibility setting');
      }
      
      if (dataSharing !== undefined && typeof dataSharing !== 'boolean') {
        errors.push('Invalid data sharing setting');
      }
      
      if (analytics !== undefined && typeof analytics !== 'boolean') {
        errors.push('Invalid analytics setting');
      }
    }
    
    if (errors.length > 0) {
      return res.status(400).json({
        success: false,
        error: 'Settings validation failed',
        details: errors,
        message: errors[0]
      });
    }
    
    req.validatedSettings = { preferences, notifications, privacy };
    next();
  } catch (error) {
    console.error('Settings validation error:', error);
    res.status(500).json({
      success: false,
      error: 'Settings validation error',
      message: 'Failed to validate settings'
    });
  }
}

module.exports = {
  validateProfileUpdate,
  validateSettings,
  validateEmailUpdate,
  validatePhone,
  validateName,
  validateBio
};