// IAMAI Global Email Service - Cloudflare/iCloud Configuration
// Handles all email functionality with specific email addresses and authentication

const nodemailer = require('nodemailer');

// ============================================
// EMAIL CONFIGURATION - Cloudflare/iCloud
// ============================================

const createTransporter = () => {
  return nodemailer.createTransport({
    host: process.env.EMAIL_HOST || 'smtp.mail.me.com',
    port: parseInt(process.env.EMAIL_PORT) || 587,
    secure: process.env.EMAIL_SECURE === 'true' || false, // true for 465, false for other ports
    auth: {
      user: process.env.EMAIL_USERNAME || 'reset-password@iamai.global',
      pass: process.env.EMAIL_PASSWORD || '1UsaJohnny'
    },
    tls: {
      rejectUnauthorized: false
    }
  });
};

const transporter = createTransporter();

// ============================================
// EMAIL TEMPLATES
// ============================================

const getEmailTemplate = (type, data) => {
  const baseUrl = process.env.FRONTEND_URL || 'https://iamai.global';
  const companyName = process.env.EMAIL_FROM_NAME || 'IAMAI Global';
  
  const baseStyles = `
    <style>
      .email-container { 
        max-width: 600px; 
        margin: 0 auto; 
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        line-height: 1.6;
        color: #333;
      }
      .email-header { 
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 30px;
        text-align: center;
        border-radius: 8px 8px 0 0;
      }
      .email-body { 
        background: white;
        padding: 30px;
        border: 1px solid #e1e5e9;
      }
      .email-footer { 
        background: #f8f9fa;
        padding: 20px;
        text-align: center;
        border-radius: 0 0 8px 8px;
        font-size: 14px;
        color: #666;
      }
      .button {
        display: inline-block;
        padding: 12px 30px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        text-decoration: none;
        border-radius: 6px;
        font-weight: bold;
        margin: 20px 0;
      }
      .alert {
        background: #fff3cd;
        border: 1px solid #ffeaa7;
        color: #856404;
        padding: 15px;
        border-radius: 6px;
        margin: 20px 0;
      }
      .security-info {
        background: #f8f9fa;
        border-left: 4px solid #667eea;
        padding: 15px;
        margin: 20px 0;
      }
    </style>
  `;

  switch (type) {
    case 'welcome':
      return {
        subject: `Welcome to \${companyName}! 🚀`,
        html: `
          <!DOCTYPE html>
          <html>
          <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <title>Welcome to \${companyName}</title>
            \${baseStyles}
          </head>
          <body>
            <div class="email-container">
              <div class="email-header">
                <h1>Welcome to \${companyName}! 🎉</h1>
              </div>
              
              <div class="email-body">
                <p>Hi \${data.firstName},</p>
                
                <p>Welcome to the future of AI! We're thrilled to have you join the \${companyName} community.</p>
                
                <p>To get started, please verify your email address by clicking the button below:</p>
                
                <div style="text-align: center;">
                  <a href="\${baseUrl}/verify-email/\${data.token}" class="button">
                    Verify Email Address
                  </a>
                </div>
                
                <p>Once verified, you'll have access to:</p>
                <ul>
                  <li>🤖 17 Advanced AI Agents</li>
                  <li>🧪 AI Laboratory Tools</li>
                  <li>⚔️ AI Battle Arena</li>
                  <li>📊 Analytics Dashboard</li>
                  <li>🎯 Personalized AI Experiences</li>
                </ul>
                
                <div class="security-info">
                  <strong>Security Note:</strong> This verification link will expire in 24 hours. If you didn't create this account, please ignore this email.
                </div>
                
                <p>Questions? Our team is here to help at <a href="mailto:support@iamai.global">support@iamai.global</a></p>
                
                <p>Best regards,<br>The \${companyName} Team</p>
              </div>
              
              <div class="email-footer">
                <p>&copy; 2024 \${companyName}. All rights reserved.</p>
                <p><a href="\${baseUrl}/privacy">Privacy Policy</a> | <a href="\${baseUrl}/terms">Terms of Service</a></p>
              </div>
            </div>
          </body>
          </html>
        `
      };

    case 'password-reset':
      return {
        subject: `Reset Your \${companyName} Password`,
        html: `
          <!DOCTYPE html>
          <html>
          <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <title>Password Reset - \${companyName}</title>
            \${baseStyles}
          </head>
          <body>
            <div class="email-container">
              <div class="email-header">
                <h1>Password Reset Request 🔑</h1>
              </div>
              
              <div class="email-body">
                <p>Hi \${data.firstName},</p>
                
                <p>You recently requested to reset your password for your \${companyName} account. Click the button below to reset it:</p>
                
                <div style="text-align: center;">
                  <a href="\${baseUrl}/reset-password/\${data.token}" class="button">
                    Reset Password
                  </a>
                </div>
                
                <div class="alert">
                  <strong>Important:</strong> This password reset link will expire in 1 hour for security reasons.
                </div>
                
                <div class="security-info">
                  <p><strong>Security Information:</strong></p>
                  <ul>
                    <li>Request Time: \${new Date().toLocaleString()}</li>
                    <li>IP Address: \${data.ipAddress || 'Unknown'}</li>
                    <li>Browser: \${data.userAgent ? data.userAgent.split(' ')[0] : 'Unknown'}</li>
                  </ul>
                </div>
                
                <p>If you didn't request this password reset, please ignore this email or contact our support team at <a href="mailto:support@iamai.global">support@iamai.global</a></p>
                
                <p>For security, we recommend using a strong, unique password that you haven't used elsewhere.</p>
                
                <p>Best regards,<br>The \${companyName} Security Team</p>
              </div>
              
              <div class="email-footer">
                <p>&copy; 2024 \${companyName}. All rights reserved.</p>
                <p>Need help? Contact us at <a href="mailto:support@iamai.global">support@iamai.global</a></p>
              </div>
            </div>
          </body>
          </html>
        `
      };

    default:
      throw new Error(`Unknown email template type: \${type}`);
  }
};

// ============================================
// EMAIL SENDING FUNCTIONS
// ============================================

const sendEmail = async (to, subject, html, from = null, emailType = 'general') => {
  try {
    // Select appropriate from address based on email type
    let fromAddress = from;
    if (!fromAddress) {
      switch (emailType) {
        case 'welcome':
          fromAddress = process.env.EMAIL_FROM_WELCOME || 'welcome@iamai.global';
          break;
        case 'reset':
          fromAddress = process.env.EMAIL_FROM_RESET || 'reset-password@iamai.global';
          break;
        case 'support':
          fromAddress = process.env.EMAIL_FROM_SUPPORT || 'support@iamai.global';
          break;
        default:
          fromAddress = process.env.EMAIL_FROM_RESET || 'reset-password@iamai.global';
      }
    }
    
    const companyName = process.env.EMAIL_FROM_NAME || 'IAMAI Global';
    
    const mailOptions = {
      from: `"\${companyName}" <\${fromAddress}>`,
      to,
      subject,
      html,
      // Add text version for better compatibility
      text: html.replace(/<[^>]*>/g, '').replace(/\\s+/g, ' ').trim()
    };
    
    const result = await transporter.sendMail(mailOptions);
    
    console.log(`📧 Email sent successfully from \${fromAddress} to \${to}:`, result.messageId);
    
    return { success: true, messageId: result.messageId };
    
  } catch (error) {
    console.error('❌ Email sending failed:', error);
    return { success: false, error: error.message };
  }
};

// ============================================
// SPECIFIC EMAIL FUNCTIONS
// ============================================

const sendWelcomeEmail = async (email, firstName, verificationToken) => {
  const template = getEmailTemplate('welcome', { firstName, token: verificationToken });
  return await sendEmail(email, template.subject, template.html, null, 'welcome');
};

const sendPasswordResetEmail = async (email, firstName, resetToken, ipAddress = null, userAgent = null) => {
  const template = getEmailTemplate('password-reset', { 
    firstName, 
    token: resetToken, 
    ipAddress, 
    userAgent 
  });
  return await sendEmail(email, template.subject, template.html, null, 'reset');
};

const sendVerificationEmail = async (email, firstName, verificationToken) => {
  const template = getEmailTemplate('email-verification', { firstName, token: verificationToken });
  return await sendEmail(email, template.subject, template.html, null, 'welcome');
};

const sendPasswordChangedEmail = async (email, firstName, ipAddress = null, userAgent = null) => {
  const template = getEmailTemplate('password-reset', { 
    firstName, 
    ipAddress, 
    userAgent 
  });
  return await sendEmail(email, template.subject, template.html, null, 'reset');
};

// ============================================
// EMAIL SERVICE HEALTH CHECK
// ============================================

const testEmailConnection = async () => {
  try {
    await transporter.verify();
    console.log('✅ Email service connected successfully (Cloudflare/iCloud)');
    return { success: true, message: 'Email service is healthy' };
  } catch (error) {
    console.error('❌ Email service connection failed:', error);
    return { success: false, error: error.message };
  }
};

// ============================================
// EXPORTS
// ============================================

module.exports = {
  // Main sending function
  sendEmail,
  
  // Authentication emails
  sendWelcomeEmail,
  sendPasswordResetEmail,
  sendVerificationEmail,
  sendPasswordChangedEmail,
  
  // Utilities
  testEmailConnection,
  getEmailTemplate
};
