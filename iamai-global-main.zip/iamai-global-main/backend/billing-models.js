// Billing History and Invoicing Models
// Complete billing management, invoice generation, and financial tracking

const mongoose = require('mongoose');

// ============================================
// 1. INVOICE MODEL
// ============================================

const InvoiceSchema = new mongoose.Schema(
  {
    // Invoice Identification
    invoiceNumber: {
      type: String,
      required: true,
      unique: true,
      // Format: INV-YYYY-MM-XXXXXX
      default: function () {
        const date = new Date();
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const random = Math.floor(Math.random() * 900000) + 100000;
        return `INV-${year}-${month}-${random}`;
      },
    },

    // Customer Information
    customer: {
      userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true,
      },
      email: {
        type: String,
        required: true,
        lowercase: true,
      },
      name: {
        type: String,
        required: true,
      },
      company: String,
      taxId: String, // VAT/Tax ID for businesses

      // Billing Address
      billingAddress: {
        street: String,
        city: String,
        state: String,
        zipCode: String,
        country: String,
        countryCode: String,
      },
    },

    // Invoice Details
    details: {
      issueDate: {
        type: Date,
        required: true,
        default: Date.now,
      },
      dueDate: {
        type: Date,
        required: true,
        default: function () {
          return new Date(Date.now() + 30 * 24 * 60 * 60 * 1000); // 30 days from now
        },
      },
      paidDate: Date,

      // Invoice Period
      periodStart: Date,
      periodEnd: Date,
      billingCycle: {
        type: String,
        enum: ['daily', 'weekly', 'monthly', 'quarterly', 'yearly', 'one-time'],
        default: 'monthly',
      },
    },

    // Line Items
    lineItems: [
      {
        description: {
          type: String,
          required: true,
        },
        quantity: {
          type: Number,
          required: true,
          min: 0,
        },
        unitPrice: {
          type: Number,
          required: true,
          min: 0,
        },
        totalPrice: {
          type: Number,
          required: true,
          min: 0,
        },

        // Product/Service Details
        productId: {
          type: mongoose.Schema.Types.ObjectId,
          ref: 'Plan',
        },
        agentId: {
          type: mongoose.Schema.Types.ObjectId,
          ref: 'Agent',
        },
        subscriptionId: {
          type: mongoose.Schema.Types.ObjectId,
          ref: 'Subscription',
        },

        // Pricing Details
        currency: {
          type: String,
          default: 'USD',
          enum: ['USD', 'EUR', 'GBP', 'JPY', 'CNY', 'INR', 'BRL', 'CAD', 'AUD'],
        },
        taxRate: {
          type: Number,
          default: 0,
          min: 0,
          max: 1, // Percentage as decimal (0.20 = 20%)
        },
        taxAmount: {
          type: Number,
          default: 0,
          min: 0,
        },
        discountRate: {
          type: Number,
          default: 0,
          min: 0,
          max: 1,
        },
        discountAmount: {
          type: Number,
          default: 0,
          min: 0,
        },

        // Usage-based billing
        usage: {
          tokens: Number,
          requests: Number,
          storage: Number, // in MB
          bandwidth: Number, // in MB
          features: [String],
        },

        // Metadata
        metadata: {
          type: Map,
          of: mongoose.Schema.Types.Mixed,
        },
      },
    ],

    // Financial Totals
    totals: {
      subtotal: {
        type: Number,
        required: true,
        min: 0,
      },
      totalTax: {
        type: Number,
        default: 0,
        min: 0,
      },
      totalDiscount: {
        type: Number,
        default: 0,
        min: 0,
      },
      totalAmount: {
        type: Number,
        required: true,
        min: 0,
      },
      amountPaid: {
        type: Number,
        default: 0,
        min: 0,
      },
      amountDue: {
        type: Number,
        default: 0,
        min: 0,
      },

      // Currency
      currency: {
        type: String,
        required: true,
        default: 'USD',
      },
      exchangeRate: {
        type: Number,
        default: 1,
      },
    },

    // Invoice Status
    status: {
      type: String,
      required: true,
      enum: [
        'draft',
        'pending',
        'sent',
        'viewed',
        'paid',
        'partial_paid',
        'overdue',
        'cancelled',
        'refunded',
        'disputed',
      ],
      default: 'draft',
    },

    // Payment Information
    payment: {
      method: {
        type: String,
        enum: ['stripe', 'paypal', 'bank_transfer', 'crypto', 'manual', 'other'],
      },
      transactionId: String,
      paymentIntentId: String, // Stripe Payment Intent
      chargeId: String, // Stripe Charge ID
      paymentDate: Date,

      // Payment Links
      paymentLink: String,
      hostedInvoiceUrl: String, // Stripe hosted invoice
      invoicePdf: String, // PDF download URL

      // Auto-collection settings
      autoAdvance: {
        type: Boolean,
        default: true,
      },
      collectionMethod: {
        type: String,
        enum: ['charge_automatically', 'send_invoice'],
        default: 'charge_automatically',
      },
    },

    // Tax Information
    tax: {
      // Tax calculation
      taxCalculation: {
        type: String,
        enum: ['inclusive', 'exclusive'],
        default: 'exclusive',
      },

      // Tax exemption
      taxExempt: {
        type: Boolean,
        default: false,
      },
      taxExemptReason: String,

      // Regional tax info
      taxRegion: String,
      vatNumber: String,
      reversedCharge: Boolean, // EU reverse charge

      // Tax breakdown
      taxBreakdown: [
        {
          name: String, // VAT, GST, Sales Tax, etc.
          rate: Number,
          amount: Number,
          jurisdiction: String,
        },
      ],
    },

    // Delivery & Communication
    delivery: {
      emailSent: {
        type: Boolean,
        default: false,
      },
      emailSentAt: Date,
      emailViewedAt: Date,
      remindersSent: {
        type: Number,
        default: 0,
      },
      lastReminderAt: Date,

      // Delivery preferences
      deliveryMethod: {
        type: String,
        enum: ['email', 'postal', 'both'],
        default: 'email',
      },
      language: {
        type: String,
        default: 'en',
      },
    },

    // Business Information
    business: {
      name: {
        type: String,
        default: 'IAMAI Global',
      },
      address: {
        street: String,
        city: String,
        state: String,
        zipCode: String,
        country: String,
      },
      taxId: String,
      registrationNumber: String,
      website: String,
      email: String,
      phone: String,

      // Branding
      logo: String,
      brandColor: String,
      footerText: String,
    },

    // Notes and Attachments
    notes: {
      internal: String, // Internal notes for staff
      customer: String, // Notes visible to customer
      terms: String, // Terms and conditions
      paymentInstructions: String,
    },

    attachments: [
      {
        filename: String,
        url: String,
        size: Number,
        mimeType: String,
        uploadedAt: {
          type: Date,
          default: Date.now,
        },
      },
    ],

    // Audit Trail
    audit: {
      createdBy: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
      },
      updatedBy: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
      },
      statusHistory: [
        {
          status: String,
          changedAt: {
            type: Date,
            default: Date.now,
          },
          changedBy: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'User',
          },
          reason: String,
          metadata: mongoose.Schema.Types.Mixed,
        },
      ],

      // API tracking
      webhooksDelivered: [
        {
          event: String,
          url: String,
          status: Number,
          deliveredAt: Date,
          response: String,
        },
      ],
    },

    // Recurring Invoice Settings
    recurring: {
      isRecurring: {
        type: Boolean,
        default: false,
      },
      interval: {
        type: String,
        enum: ['daily', 'weekly', 'monthly', 'quarterly', 'yearly'],
      },
      intervalCount: {
        type: Number,
        default: 1,
      },
      nextInvoiceDate: Date,
      endDate: Date,
      maxInvoices: Number,
      invoicesGenerated: {
        type: Number,
        default: 0,
      },
      parentInvoiceId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Invoice',
      },
    },

    // Metadata and Custom Fields
    metadata: {
      source: {
        type: String,
        enum: ['subscription', 'manual', 'api', 'import'],
        default: 'subscription',
      },
      tags: [String],
      customFields: {
        type: Map,
        of: mongoose.Schema.Types.Mixed,
      },
      integrationData: {
        stripeInvoiceId: String,
        quickbooksId: String,
        xeroId: String,
        freshbooksId: String,
      },
    },
  },
  {
    timestamps: true,
  }
);

// Indexes
// InvoiceSchema.index({ invoiceNumber: 1 }); // Removed: unique: true already creates index
InvoiceSchema.index({ 'customer.userId': 1, createdAt: -1 });
InvoiceSchema.index({ 'customer.email': 1 });
InvoiceSchema.index({ status: 1, 'details.dueDate': 1 });
InvoiceSchema.index({ 'details.issueDate': 1 });
InvoiceSchema.index({ 'payment.transactionId': 1 });

// Calculate totals before saving
InvoiceSchema.pre('save', function (next) {
  if (this.isModified('lineItems')) {
    let subtotal = 0;
    let totalTax = 0;
    let totalDiscount = 0;

    this.lineItems.forEach(item => {
      subtotal += item.totalPrice;
      totalTax += item.taxAmount || 0;
      totalDiscount += item.discountAmount || 0;
    });

    this.totals.subtotal = subtotal;
    this.totals.totalTax = totalTax;
    this.totals.totalDiscount = totalDiscount;
    this.totals.totalAmount = subtotal + totalTax - totalDiscount;
    this.totals.amountDue = this.totals.totalAmount - (this.totals.amountPaid || 0);
  }
  next();
});

const InvoiceAdvanced = mongoose.model('InvoiceAdvanced', InvoiceSchema);

// ============================================
// 2. BILLING HISTORY MODEL
// ============================================

const BillingHistorySchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },

    // Transaction Information
    transaction: {
      id: {
        type: String,
        required: true,
        unique: true,
      },
      type: {
        type: String,
        required: true,
        enum: [
          'subscription_payment',
          'one_time_payment',
          'refund',
          'partial_refund',
          'chargeback',
          'adjustment',
          'credit',
          'bonus',
          'penalty',
          'tax_adjustment',
          'currency_conversion',
        ],
      },
      description: {
        type: String,
        required: true,
      },
    },

    // Financial Details
    amount: {
      gross: {
        type: Number,
        required: true,
      },
      net: {
        type: Number,
        required: true,
      },
      fee: {
        type: Number,
        default: 0,
      },
      tax: {
        type: Number,
        default: 0,
      },
      currency: {
        type: String,
        required: true,
        default: 'USD',
      },
    },

    // Related Records
    references: {
      invoiceId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Invoice',
      },
      subscriptionId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Subscription',
      },
      planId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Plan',
      },
      paymentId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Payment',
      },
      originalTransactionId: String, // For refunds/adjustments
    },

    // Payment Method
    paymentMethod: {
      type: {
        type: String,
        enum: ['card', 'bank_account', 'paypal', 'crypto', 'wallet', 'manual'],
        required: true,
      },
      last4: String,
      brand: String, // visa, mastercard, etc.
      expiryMonth: Number,
      expiryYear: Number,
      fingerprint: String,
    },

    // Status and Processing
    status: {
      type: String,
      required: true,
      enum: ['pending', 'processing', 'completed', 'failed', 'cancelled', 'disputed', 'refunded'],
      default: 'pending',
    },

    // Billing Period
    billingPeriod: {
      start: Date,
      end: Date,
      cycle: {
        type: String,
        enum: ['daily', 'weekly', 'monthly', 'quarterly', 'yearly', 'one-time'],
      },
    },

    // Processing Details
    processing: {
      processor: {
        type: String,
        enum: ['stripe', 'paypal', 'square', 'manual', 'internal'],
      },
      processorTransactionId: String,
      processingFee: Number,
      processingTime: Number, // milliseconds
      retryCount: {
        type: Number,
        default: 0,
      },
      lastRetryAt: Date,
      failureReason: String,
      webhookDelivered: Boolean,
    },

    // Balance Impact
    balance: {
      previousBalance: Number,
      newBalance: Number,
      creditUsed: Number,
      creditRemaining: Number,
    },

    // Metadata
    metadata: {
      userAgent: String,
      ipAddress: String,
      location: {
        country: String,
        region: String,
        city: String,
      },
      source: String, // web, mobile, api
      campaign: String,
      referrer: String,
      tags: [String],
    },
  },
  {
    timestamps: true,
  }
);

// Indexes
BillingHistorySchema.index({ userId: 1, createdAt: -1 });
BillingHistorySchema.index({ 'transaction.id': 1 });
BillingHistorySchema.index({ 'references.subscriptionId': 1 });
BillingHistorySchema.index({ status: 1 });
BillingHistorySchema.index({ 'processing.processor': 1 });

// NOTE: BillingHistory model is defined in models.js to avoid duplicate model error

// ============================================
// 3. PAYMENT RECEIPT MODEL
// ============================================

const PaymentReceiptSchema = new mongoose.Schema(
  {
    // Receipt Identification
    receiptNumber: {
      type: String,
      required: true,
      unique: true,
      default: function () {
        const date = new Date();
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const random = Math.floor(Math.random() * 900000) + 100000;
        return `RCP-${year}-${month}-${random}`;
      },
    },

    // Customer and Payment Information
    customer: {
      userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true,
      },
      email: {
        type: String,
        required: true,
      },
      name: {
        type: String,
        required: true,
      },
    },

    // Payment Details
    payment: {
      amount: {
        type: Number,
        required: true,
        min: 0,
      },
      currency: {
        type: String,
        required: true,
        default: 'USD',
      },
      method: {
        type: String,
        required: true,
        enum: ['card', 'bank_transfer', 'paypal', 'crypto', 'manual'],
      },

      // Payment Method Details
      methodDetails: {
        last4: String,
        brand: String,
        expiryMonth: Number,
        expiryYear: Number,
        bankName: String,
        accountType: String,
      },

      // Transaction Information
      transactionId: {
        type: String,
        required: true,
      },
      processorTransactionId: String,
      authorizationCode: String,

      // Timing
      paymentDate: {
        type: Date,
        required: true,
        default: Date.now,
      },
      processedAt: Date,
      settledAt: Date,
    },

    // Related Records
    related: {
      invoiceId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Invoice',
      },
      subscriptionId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Subscription',
      },
      billingHistoryId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'BillingHistory',
      },
    },

    // Services/Products Paid For
    items: [
      {
        description: String,
        quantity: Number,
        unitPrice: Number,
        totalPrice: Number,
        agentId: {
          type: mongoose.Schema.Types.ObjectId,
          ref: 'Agent',
        },
        planId: {
          type: mongoose.Schema.Types.ObjectId,
          ref: 'Plan',
        },
      },
    ],

    // Financial Breakdown
    breakdown: {
      subtotal: Number,
      tax: Number,
      fees: Number,
      discount: Number,
      total: Number,
    },

    // Receipt Status
    status: {
      type: String,
      enum: ['issued', 'sent', 'viewed', 'downloaded'],
      default: 'issued',
    },

    // Delivery Information
    delivery: {
      emailSent: {
        type: Boolean,
        default: false,
      },
      emailSentAt: Date,
      downloadCount: {
        type: Number,
        default: 0,
      },
      lastDownloadAt: Date,
      pdfUrl: String,
    },

    // Metadata
    metadata: {
      processor: String,
      ipAddress: String,
      userAgent: String,
      source: String,
    },
  },
  {
    timestamps: true,
  }
);

// Indexes
// PaymentReceiptSchema.index({ receiptNumber: 1 }); // Removed: unique: true already creates index
PaymentReceiptSchema.index({ 'customer.userId': 1, createdAt: -1 });
PaymentReceiptSchema.index({ 'payment.transactionId': 1 });

const PaymentReceipt = mongoose.model('PaymentReceipt', PaymentReceiptSchema);

// ============================================
// 4. TAX RECORD MODEL
// ============================================

const TaxRecordSchema = new mongoose.Schema(
  {
    // Tax Year and Period
    taxYear: {
      type: Number,
      required: true,
    },
    quarter: {
      type: Number,
      min: 1,
      max: 4,
    },
    month: {
      type: Number,
      min: 1,
      max: 12,
    },

    // Business Information
    business: {
      name: String,
      taxId: String,
      address: {
        street: String,
        city: String,
        state: String,
        zipCode: String,
        country: String,
      },
    },

    // Customer Information (for B2B transactions)
    customer: {
      userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
      },
      businessName: String,
      taxId: String,
      country: String,
      isEUMember: Boolean,
      vatExempt: Boolean,
    },

    // Tax Details
    tax: {
      type: {
        type: String,
        required: true,
        enum: ['sales', 'vat', 'gst', 'income', 'withholding', 'other'],
      },
      region: String, // US-CA, EU-DE, etc.
      rate: {
        type: Number,
        required: true,
        min: 0,
        max: 1,
      },

      // Amounts
      taxableAmount: {
        type: Number,
        required: true,
        min: 0,
      },
      taxAmount: {
        type: Number,
        required: true,
        min: 0,
      },
      currency: {
        type: String,
        required: true,
        default: 'USD',
      },
    },

    // Transaction References
    transactions: [
      {
        invoiceId: {
          type: mongoose.Schema.Types.ObjectId,
          ref: 'Invoice',
        },
        paymentId: {
          type: mongoose.Schema.Types.ObjectId,
          ref: 'Payment',
        },
        transactionId: String,
        amount: Number,
        taxAmount: Number,
        date: Date,
      },
    ],

    // Reporting Information
    reporting: {
      filingRequired: {
        type: Boolean,
        default: true,
      },
      filingDate: Date,
      filedBy: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
      },
      confirmationNumber: String,
      status: {
        type: String,
        enum: ['pending', 'filed', 'accepted', 'rejected', 'amended'],
        default: 'pending',
      },
    },

    // Compliance
    compliance: {
      threshold: Number, // Minimum amount requiring filing
      exemptionReason: String,
      specialRules: [String],
      documentation: [
        {
          type: String,
          url: String,
          uploadedAt: Date,
        },
      ],
    },
  },
  {
    timestamps: true,
  }
);

// Indexes
TaxRecordSchema.index({ taxYear: 1, quarter: 1 });
TaxRecordSchema.index({ 'customer.userId': 1, taxYear: 1 });
TaxRecordSchema.index({ 'tax.type': 1, 'tax.region': 1 });

const TaxRecord = mongoose.model('TaxRecord', TaxRecordSchema);

// Export billing models (BillingHistory exported from models.js to avoid conflicts)
module.exports = {
  InvoiceAdvanced,
  PaymentReceipt,
  TaxRecord,
};
