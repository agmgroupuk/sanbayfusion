const mongoose = require('mongoose');
const { Schema } = mongoose;

// ============================================
// AGENT-SPECIFIC COLLECTIONS SYSTEM
// Each agent has its own dedicated collection
// ============================================

// List of all 17 agents for collection creation
const AGENT_LIST = [
  'agent-x', 'ai-girlfriend', 'comedy-chad', 'gamer-gary', 'pdf-mind',
  'fitness-fury', 'cool-kyle', 'smart-susan', 'math-monster', 'travel-tom',
  'chef-charlie', 'music-mike', 'art-angel', 'chat-revive', 'lazy-larry',
  'code-crusher', 'data-dynamo'
];

// Base schema for agent data collections
const AgentDataSchema = new Schema({
  // User Information
  userId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  userEmail: String,
  userName: String,

  // Agent Information
  agentId: { type: String, required: true },
  agentName: String,
  agentDisplayName: String,

  // Subscription Data (Central Hub)
  subscription: {
    id: Schema.Types.ObjectId,
    plan: { type: String, enum: ['daily', 'weekly', 'monthly'] },
    status: { type: String, enum: ['active', 'inactive', 'cancelled', 'expired'], default: 'active' },
    
    // Pricing & Billing
    pricing: {
      amount: { type: Number, required: true },
      currency: { type: String, default: 'USD' },
      period: { type: String, required: true } // daily, weekly, monthly
    },
    
    billing: {
      stripeSubscriptionId: String,
      stripeCustomerId: String,
      startDate: { type: Date, default: Date.now },
      currentPeriodStart: Date,
      currentPeriodEnd: Date,
      nextBillingDate: Date,
      totalAmountPaid: { type: Number, default: 0 },
      lastPaymentDate: Date
    },

    // Usage Limits & Tracking
    limits: {
      messagesPerDay: { type: Number, default: 100 },
      messagesPerWeek: { type: Number, default: 500 },
      messagesPerMonth: { type: Number, default: 2000 },
      features: [String] // Available features for this plan
    },

    usage: {
      messagesUsed: { type: Number, default: 0 },
      lastResetDate: { type: Date, default: Date.now },
      dailyUsage: { type: Number, default: 0 },
      weeklyUsage: { type: Number, default: 0 },
      monthlyUsage: { type: Number, default: 0 }
    },

    subscribedAt: { type: Date, default: Date.now },
    lastActivity: { type: Date, default: Date.now }
  },

  // Chat History (Agent-Specific)
  chats: [{
    chatId: Schema.Types.ObjectId,
    sessionId: String,
    message: {
      content: String,
      role: { type: String, enum: ['user', 'assistant'] },
      timestamp: { type: Date, default: Date.now },
      tokens: { input: Number, output: Number, total: Number },
      model: String,
      mood: String,
      sentiment: String
    },
    response: {
      content: String,
      timestamp: { type: Date, default: Date.now },
      processingTime: Number,
      tokens: { input: Number, output: Number, total: Number },
      model: String,
      mood: String,
      personality: String
    },
    metadata: {
      userAgent: String,
      ipAddress: String,
      location: String,
      device: String,
      platform: String
    }
  }],

  // Sessions (Agent-Specific)
  sessions: [{
    sessionId: { type: String, unique: true },
    startTime: { type: Date, default: Date.now },
    endTime: Date,
    duration: Number, // in seconds
    messageCount: { type: Number, default: 0 },
    
    // Session Analytics
    analytics: {
      avgResponseTime: Number,
      totalTokensUsed: Number,
      userSatisfaction: Number, // 1-5 rating
      topTopics: [String],
      mood: String,
      sentiment: String
    },

    // Session Metadata
    metadata: {
      userAgent: String,
      ipAddress: String,
      location: String,
      device: String,
      platform: String,
      referrer: String
    },

    isActive: { type: Boolean, default: true },
    lastActivity: { type: Date, default: Date.now }
  }],

  // Analytics & Metrics (Agent-Specific)
  analytics: [{
    date: { type: Date, default: Date.now },
    type: { type: String, required: true }, // 'daily', 'weekly', 'monthly'
    
    // Usage Metrics
    usage: {
      messagesCount: { type: Number, default: 0 },
      sessionCount: { type: Number, default: 0 },
      totalTokens: { type: Number, default: 0 },
      avgSessionDuration: { type: Number, default: 0 },
      avgResponseTime: { type: Number, default: 0 }
    },

    // Engagement Metrics
    engagement: {
      userSatisfaction: { type: Number, default: 0 }, // Average rating
      responseAccuracy: { type: Number, default: 0 },
      conversationFlow: { type: Number, default: 0 },
      userRetention: { type: Number, default: 0 }
    },

    // Performance Metrics
    performance: {
      uptime: { type: Number, default: 100 }, // Percentage
      errorRate: { type: Number, default: 0 }, // Percentage
      avgProcessingTime: { type: Number, default: 0 },
      peakHours: [String] // Hours of highest activity
    },

    // Topic Analysis
    topics: [{
      name: String,
      frequency: Number,
      sentiment: String,
      successRate: Number
    }],

    // Revenue Metrics
    revenue: {
      subscriptionFees: { type: Number, default: 0 },
      totalEarnings: { type: Number, default: 0 },
      conversionRate: { type: Number, default: 0 }
    }
  }],

  // Activity Logs (Agent-Specific)
  activities: [{
    timestamp: { type: Date, default: Date.now },
    type: { type: String, required: true }, // 'subscription', 'chat', 'session', 'payment'
    action: String, // 'created', 'updated', 'cancelled', 'message_sent', etc.
    description: String,
    
    // Activity Data
    data: {
      messageId: Schema.Types.ObjectId,
      sessionId: String,
      subscriptionId: Schema.Types.ObjectId,
      amount: Number,
      previousValue: Schema.Types.Mixed,
      newValue: Schema.Types.Mixed
    },

    // Context
    context: {
      userAgent: String,
      ipAddress: String,
      location: String,
      device: String
    },

    severity: { type: String, enum: ['info', 'warning', 'error', 'critical'], default: 'info' }
  }],

  // Transactions (Agent-Specific)
  transactions: [{
    transactionId: { type: String },
    type: { type: String, enum: ['subscription', 'renewal', 'upgrade', 'refund'], required: true },
    
    // Payment Details
    payment: {
      amount: { type: Number, required: true },
      currency: { type: String, default: 'USD' },
      method: String, // 'stripe', 'paypal', etc.
      stripePaymentIntentId: String,
      stripeChargeId: String,
      paypalTransactionId: String
    },

    // Transaction Status
    status: { type: String, enum: ['pending', 'completed', 'failed', 'refunded'], default: 'pending' },
    processedAt: { type: Date, default: Date.now },
    
    // Related Data
    subscriptionId: Schema.Types.ObjectId,
    planDetails: {
      plan: String,
      period: String,
      features: [String]
    },

    // Transaction Metadata
    metadata: {
      userAgent: String,
      ipAddress: String,
      location: String,
      notes: String
    }
  }],

  // Agent Configuration & Preferences
  agentConfig: {
    personality: {
      tone: String,
      style: String,
      specialties: [String],
      responsePatterns: [String]
    },
    
    preferences: {
      maxTokensPerResponse: { type: Number, default: 1000 },
      temperature: { type: Number, default: 0.7 },
      model: { type: String, default: 'gpt-4' },
      language: { type: String, default: 'en' },
      customInstructions: String
    },

    capabilities: {
      features: [String],
      integrations: [String],
      tools: [String]
    }
  },

  // Data Management
  metadata: {
    createdAt: { type: Date, default: Date.now },
    updatedAt: { type: Date, default: Date.now },
    lastSyncedAt: Date,
    version: { type: String, default: '1.0.0' },
    
    // Data Quality
    dataIntegrity: {
      lastVerified: Date,
      checksumChats: String,
      checksumSessions: String,
      checksumAnalytics: String
    },

    // Backup & Archive
    backup: {
      lastBackupDate: Date,
      backupLocation: String,
      archiveStatus: String
    }
  }
}, {
  timestamps: true,
  collection: function() { return `${this.agentId}-data`; } // Dynamic collection name
});

// Indexes for performance
AgentDataSchema.index({ userId: 1, agentId: 1 });
AgentDataSchema.index({ 'subscription.status': 1 });
AgentDataSchema.index({ 'subscription.billing.nextBillingDate': 1 });
AgentDataSchema.index({ 'chats.message.timestamp': -1 });
AgentDataSchema.index({ 'sessions.sessionId': 1 });
AgentDataSchema.index({ 'sessions.startTime': -1 });
AgentDataSchema.index({ 'analytics.date': -1 });
AgentDataSchema.index({ 'activities.timestamp': -1 });
// Index for transactions.transactionId - will be created manually when needed
// AgentDataSchema.index({ 'transactions.transactionId': 1 }, { sparse: true });

// Methods for agent data operations
AgentDataSchema.methods.addChat = function(chatData) {
  this.chats.push(chatData);
  this.subscription.usage.messagesUsed++;
  this.subscription.lastActivity = new Date();
  this.metadata.updatedAt = new Date();
  return this.save();
};

AgentDataSchema.methods.createSession = function(sessionData) {
  this.sessions.push(sessionData);
  this.subscription.lastActivity = new Date();
  this.metadata.updatedAt = new Date();
  return this.save();
};

AgentDataSchema.methods.addAnalytics = function(analyticsData) {
  this.analytics.push(analyticsData);
  this.metadata.updatedAt = new Date();
  return this.save();
};

AgentDataSchema.methods.logActivity = function(activityData) {
  this.activities.push(activityData);
  this.metadata.updatedAt = new Date();
  return this.save();
};

AgentDataSchema.methods.addTransaction = function(transactionData) {
  this.transactions.push(transactionData);
  this.subscription.billing.totalAmountPaid += transactionData.payment.amount;
  this.subscription.billing.lastPaymentDate = new Date();
  this.metadata.updatedAt = new Date();
  return this.save();
};

// Static method to get agent collection
AgentDataSchema.statics.getAgentCollection = function(agentId) {
  const collectionName = `${agentId}-data`;
  return mongoose.model(collectionName, AgentDataSchema, collectionName);
};

// Function to create all agent collections
const createAgentCollections = () => {
  const agentCollections = {};
  
  AGENT_LIST.forEach(agentId => {
    const collectionName = `${agentId}-data`;
    agentCollections[agentId] = mongoose.model(collectionName, AgentDataSchema, collectionName);
  });
  
  return agentCollections;
};

// Master agent registry collection
const AgentRegistrySchema = new Schema({
  agentId: { type: String, unique: true, required: true },
  agentName: String,
  displayName: String,
  description: String,
  category: String,
  
  // Collection Info
  collectionName: String,
  collectionCreated: { type: Date, default: Date.now },
  
  // Agent Status
  isActive: { type: Boolean, default: true },
  isAvailable: { type: Boolean, default: true },
  
  // Statistics
  stats: {
    totalUsers: { type: Number, default: 0 },
    activeSubscriptions: { type: Number, default: 0 },
    totalMessages: { type: Number, default: 0 },
    totalRevenue: { type: Number, default: 0 },
    avgRating: { type: Number, default: 0 }
  },
  
  // Configuration
  config: {
    personality: Schema.Types.Mixed,
    capabilities: Schema.Types.Mixed,
    pricing: Schema.Types.Mixed,
    limits: Schema.Types.Mixed
  },
  
  // Metadata
  metadata: {
    createdAt: { type: Date, default: Date.now },
    updatedAt: { type: Date, default: Date.now },
    lastStatsUpdate: Date
  }
}, {
  timestamps: true
});

const AgentRegistry = mongoose.model('AgentRegistry', AgentRegistrySchema);

// Export everything
module.exports = {
  AgentDataSchema,
  AgentRegistry,
  AGENT_LIST,
  createAgentCollections,
  
  // Helper functions
  getAgentData: (agentId) => {
    const collectionName = `${agentId}-data`;
    return mongoose.model(collectionName, AgentDataSchema, collectionName);
  },
  
  getAllAgentCollections: createAgentCollections
};