// ============================================
// UNIFIED AGENT PURCHASE MODEL
// One-time purchases with expiration - NO SUBSCRIPTIONS
// Supersedes the legacy AgentPurchase model in
// backend/models/AgentPurchase.js while remaining
// backwards compatible with existing documents.
// ============================================

const mongoose = require('mongoose');
const { Schema } = mongoose;

// ============================================
// AGENT PURCHASE SCHEMA (UNIFIED)
// ============================================

const AgentPurchaseSchema = new Schema(
  {
    // User identification - REQUIRED
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    email: {
      type: String,
      required: false, // Made optional to support legacy purchases
      lowercase: true,
    },

    // Agent identification
    agentId: {
      type: String,
      required: true,
    },
    agentName: {
      type: String,
      required: false, // Made optional to support legacy purchases
    },

    // Plan details - IAMAI simple pricing (new unified fields)
    plan: {
      type: String,
      enum: ['DAILY', 'WEEKLY', 'MONTHLY'],
      required: false,
    },
    planName: {
      type: String,
      enum: ['Daily', 'Weekly', 'Monthly', 'Daily Access', 'Weekly Pro', 'Monthly Unlimited'], // Support both old and new names
      required: false,
    },

    // Pricing - EXACT IAMAI prices (unified)
    pricing: {
      amount: {
        type: Number,
        required: false,
        min: 0,
      },
      currency: {
        type: String,
        default: 'USD',
        enum: ['USD', 'EUR', 'GBP'],
      },
    },

    // Purchase lifecycle - SIMPLE (allow legacy + unified values)
    status: {
      type: String,
      enum: [
        'ACTIVE',
        'EXPIRED',
        'CANCELLED',
        'REFUNDED',
        'PENDING',
        'active',
        'expired',
        'cancelled',
        'pending',
      ],
      required: true,
      default: 'PENDING',
    },

    // Time-based access
    purchaseDate: {
      type: Date,
      required: true,
      default: Date.now,
    },
    // Unified expiration field (preferred)
    expiresAt: {
      type: Date,
      required: false,
    },

    // Legacy one-time purchase fields (backwards compatible)
    planType: {
      type: String,
      enum: ['daily', 'weekly', 'monthly'],
      lowercase: true,
    },
    expirationDate: {
      type: Date,
    },
    amount: {
      type: Number,
    },
    currency: {
      type: String,
      default: 'usd',
    },

    // Payment provider integration
    stripePaymentIntentId: {
      type: String,
      sparse: true,
    },
    stripeCheckoutSessionId: {
      type: String,
    },
    stripeCustomerId: {
      type: String,
    },

    // Payment tracking
    paymentMethod: {
      type: String,
      enum: ['CARD', 'PAYPAL', 'BANK_TRANSFER', 'CRYPTOCURRENCY'],
      default: 'CARD',
    },
    paymentStatus: {
      type: String,
      enum: ['SUCCESS', 'FAILED', 'PENDING', 'REFUNDED'],
      default: 'PENDING',
    },

    // Usage analytics
    currentUsage: {
      messagesUsed: {
        type: Number,
        default: 0,
      },
      lastMessageAt: Date,
    },

    // Metadata
    metadata: {
      type: Schema.Types.Mixed,
      default: {},
    },

    // Cancellation tracking
    cancelReason: {
      type: String,
    },
    cancelledAt: {
      type: Date,
    },
  },
  {
    timestamps: true,
    collection: 'agent_purchases',
  }
);

// ============================================
// INDEXES FOR PERFORMANCE
// ============================================

// Compound indexes for critical queries
AgentPurchaseSchema.index({ userId: 1, agentId: 1, status: 1 }); // User's active purchases per agent
AgentPurchaseSchema.index({ userId: 1, status: 1, expiresAt: -1 }); // User's active purchases (unified)
AgentPurchaseSchema.index({ expirationDate: 1, status: 1 }); // Legacy expiration processing
AgentPurchaseSchema.index({ agentId: 1, status: 1, purchaseDate: -1 }); // Agent analytics
AgentPurchaseSchema.index({ stripeCustomerId: 1, status: 1 }); // Stripe integration

// TTL index for cleanup (30 days after expiration)
AgentPurchaseSchema.index(
  { expiresAt: 1 },
  {
    expireAfterSeconds: 30 * 24 * 60 * 60, // 30 days
    partialFilterExpression: { status: 'EXPIRED' },
  }
);

// ============================================
// VIRTUAL PROPERTIES
// ============================================

// Check if purchase is currently active
AgentPurchaseSchema.virtual('isActive').get(function () {
  const now = new Date();
  if (this.status === 'ACTIVE' && this.expiresAt) {
    return now < this.expiresAt;
  }
  if (this.status === 'active' && this.expirationDate) {
    return now < this.expirationDate;
  }
  return false;
});

// Days remaining until expiration
AgentPurchaseSchema.virtual('daysRemaining').get(function () {
  const now = new Date();
  const end = this.expiresAt || this.expirationDate;
  if (!end) return 0;
  return Math.max(0, Math.ceil((end - now) / (1000 * 60 * 60 * 24)));
});

// Hours remaining until expiration
AgentPurchaseSchema.virtual('hoursRemaining').get(function () {
  const now = new Date();
  const end = this.expiresAt || this.expirationDate;
  if (!end) return 0;
  return Math.max(0, Math.ceil((end - now) / (1000 * 60 * 60)));
});

// ============================================
// INSTANCE METHODS
// ============================================

// Check if user can access agent
AgentPurchaseSchema.methods.canAccess = function () {
  return this.isActive;
};

// Record message usage
AgentPurchaseSchema.methods.recordMessage = async function () {
  this.currentUsage.messagesUsed += 1;
  this.currentUsage.lastMessageAt = new Date();
  return this.save();
};

// Cancel purchase (before expiration)
AgentPurchaseSchema.methods.cancel = async function () {
  if (!this.isActive) {
    throw new Error('Can only cancel active purchases');
  }
  // Use findByIdAndUpdate to avoid triggering full schema validation on legacy data
  const cancelledStatus = this.status === 'active' ? 'cancelled' : 'CANCELLED';
  const updated = await this.constructor.findByIdAndUpdate(
    this._id,
    {
      status: cancelledStatus,
      cancelledAt: new Date(),
    },
    { new: true, runValidators: false } // Skip validation to support legacy data
  );
  // Update current instance
  this.status = cancelledStatus;
  this.cancelledAt = new Date();
  return updated || this;
};

// Mark as expired (automated process)
AgentPurchaseSchema.methods.markExpired = async function () {
  const end = this.expiresAt || this.expirationDate;
  if (end && new Date() >= end && (this.status === 'ACTIVE' || this.status === 'active')) {
    this.status = this.status === 'active' ? 'expired' : 'EXPIRED';
    return this.save();
  }
  return this;
};

// ============================================
// STATIC METHODS
// ============================================

// Get plan configuration
AgentPurchaseSchema.statics.getPlanConfig = function (planName) {
  const configs = {
    DAILY: {
      name: 'Daily',
      amount: 1,
      duration: { days: 1 },
      features: ['Unlimited Messages', 'Full Agent Access', 'Email Support'],
    },
    WEEKLY: {
      name: 'Weekly',
      amount: 5,
      duration: { days: 7 },
      features: ['Unlimited Messages', 'Full Agent Access', 'Priority Support'],
    },
    MONTHLY: {
      name: 'Monthly',
      amount: 19,
      duration: { days: 30 },
      features: ['Unlimited Messages', 'Full Agent Access', '24/7 Priority Support', 'API Access'],
    },
  };
  return configs[planName];
};

// Find active purchase for user + agent (handles legacy + unified)
AgentPurchaseSchema.statics.findActivePurchase = async function (userId, agentId) {
  const now = new Date();
  const purchase = await this.findOne({
    userId,
    agentId,
    $or: [
      { status: 'ACTIVE', expiresAt: { $gt: now } },
      { status: 'active', expirationDate: { $gt: now } },
    ],
  }).maxTimeMS(10000); // 10 second timeout
  return purchase;
};

// Check if user has active access to agent
AgentPurchaseSchema.statics.hasActiveAccess = async function (userId, agentId) {
  const purchase = await this.findActivePurchase(userId, agentId);
  return !!purchase;
};

// Get all active purchases for user (handles legacy + unified)
AgentPurchaseSchema.statics.getUserActivePurchases = async function (userId) {
  const now = new Date();
  return this.find({
    userId,
    $or: [
      { status: 'ACTIVE', expiresAt: { $gt: now } },
      { status: 'active', expirationDate: { $gt: now } },
    ],
  }).sort({ expiresAt: 1, expirationDate: 1 });
};

// Calculate expiration date based on plan
AgentPurchaseSchema.statics.calculateExpiration = function (plan, startDate = new Date()) {
  const durations = {
    DAILY: 1,
    WEEKLY: 7,
    MONTHLY: 30,
  };

  const days = durations[plan];
  if (!days) throw new Error(`Invalid plan: ${plan}`);

  const expiresAt = new Date(startDate);
  expiresAt.setDate(expiresAt.getDate() + days);
  return expiresAt;
};

// Process expired purchases (cron job helper)
AgentPurchaseSchema.statics.processExpired = async function () {
  const now = new Date();
  const result = await this.updateMany(
    {
      $or: [
        { status: 'ACTIVE', expiresAt: { $lte: now } },
        { status: 'active', expirationDate: { $lte: now } },
      ],
    },
    {
      $set: { status: 'EXPIRED' },
    }
  );
  return result.modifiedCount;
};

// ============================================
// PRE-SAVE HOOKS
// ============================================

AgentPurchaseSchema.pre('save', function (next) {
  const end = this.expiresAt || this.expirationDate;
  if ((this.status === 'ACTIVE' || this.status === 'active') && end && new Date() >= end) {
    this.status = this.status === 'active' ? 'expired' : 'EXPIRED';
  }
  next();
});

// ============================================
// EXPORT MODEL
// ============================================

// Check if model already exists (avoid OverwriteModelError)
const AgentPurchase =
  mongoose.models.AgentPurchase || mongoose.model('AgentPurchase', AgentPurchaseSchema);

module.exports = {
  AgentPurchase,
  AgentPurchaseSchema,
};
