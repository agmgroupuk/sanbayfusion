// Payments and Financial Models
// Complete payment processing, transactions, and billing models

const mongoose = require('mongoose');

// ============================================
// 1. PAYMENTS MODEL
// ============================================

const PaymentSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  subscriptionId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Subscription',
    default: null
  },
  planId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Plan',
    required: true
  },
  agentId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Agent',
    required: true // Which agent this payment is for
  },
  
  // Payment Details
  paymentId: {
    type: String,
    required: true,
    unique: true // Internal payment ID
  },
  
  // Gateway Information
  gateway: {
    provider: {
      type: String,
      required: true,
      enum: ['stripe', 'paypal', 'razorpay', 'manual']
    },
    transactionId: {
      type: String,
      required: true // Gateway's transaction ID
    },
    paymentIntentId: String, // Stripe payment intent ID
    chargeId: String, // Stripe charge ID
    invoiceId: String, // Gateway invoice ID
    customerId: String // Gateway customer ID
  },
  
  // Amount Details
  amount: {
    subtotal: {
      type: Number,
      required: true,
      min: 0
    },
    tax: {
      type: Number,
      default: 0,
      min: 0
    },
    discount: {
      type: Number,
      default: 0,
      min: 0
    },
    total: {
      type: Number,
      required: true,
      min: 0
    },
    currency: {
      type: String,
      required: true,
      default: 'USD'
    }
  },
  
  // Payment Status
  status: {
    type: String,
    required: true,
    enum: [
      'pending',
      'processing', 
      'succeeded',
      'failed',
      'canceled',
      'refunded',
      'partially_refunded',
      'disputed',
      'chargeback'
    ],
    default: 'pending'
  },
  
  // Payment Method
  paymentMethod: {
    type: {
      type: String,
      required: true,
      enum: ['card', 'bank_transfer', 'wallet', 'crypto', 'manual']
    },
    card: {
      last4: String,
      brand: String, // visa, mastercard, etc.
      expMonth: Number,
      expYear: Number,
      fingerprint: String
    },
    bankAccount: {
      last4: String,
      bankName: String,
      accountType: String
    }
  },
  
  // Timing
  paidAt: Date,
  refundedAt: Date,
  failedAt: Date,
  expiresAt: Date, // For pending payments
  
  // Subscription Period
  subscriptionPeriod: {
    start: {
      type: Date,
      required: true
    },
    end: {
      type: Date,
      required: true
    }
  },
  
  // Failure Information
  failureReason: {
    code: String,
    message: String,
    decline_code: String // For card declines
  },
  
  // Refund Information
  refunds: [{
    refundId: String,
    amount: Number,
    reason: String,
    refundedAt: Date,
    status: {
      type: String,
      enum: ['pending', 'succeeded', 'failed', 'canceled']
    }
  }],
  
  // Receipt Information
  receipt: {
    receiptNumber: String,
    receiptUrl: String,
    downloadUrl: String,
    emailSent: {
      type: Boolean,
      default: false
    },
    emailSentAt: Date
  },
  
  // Metadata
  metadata: {
    ipAddress: String,
    userAgent: String,
    source: {
      type: String,
      enum: ['web', 'mobile', 'api', 'admin'],
      default: 'web'
    },
    promoCode: String,
    referralCode: String,
    notes: String
  }
}, {
  timestamps: true
});

// Indexes
PaymentSchema.index({ userId: 1, createdAt: -1 });
// PaymentSchema.index({ paymentId: 1 }); // Removed: unique: true already creates index
PaymentSchema.index({ 'gateway.transactionId': 1 });
PaymentSchema.index({ status: 1 });
PaymentSchema.index({ agentId: 1, userId: 1 });
PaymentSchema.index({ 'subscriptionPeriod.start': 1, 'subscriptionPeriod.end': 1 });

const Payment = mongoose.model('Payment', PaymentSchema);

// ============================================
// 2. TRANSACTIONS MODEL (GENERAL)
// ============================================

const TransactionSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  
  // Transaction Details
  transactionId: {
    type: String,
    required: true,
    unique: true
  },
  type: {
    type: String,
    required: true,
    enum: [
      'payment',
      'refund',
      'credit',
      'debit',
      'bonus',
      'penalty',
      'adjustment',
      'commission'
    ]
  },
  category: {
    type: String,
    required: true,
    enum: [
      'subscription',
      'agent_access',
      'addon',
      'credit_purchase',
      'refund',
      'bonus',
      'adjustment'
    ]
  },
  
  // Amount
  amount: {
    type: Number,
    required: true
  },
  currency: {
    type: String,
    required: true,
    default: 'USD'
  },
  
  // Status
  status: {
    type: String,
    required: true,
    enum: ['pending', 'completed', 'failed', 'canceled'],
    default: 'pending'
  },
  
  // Related Records
  paymentId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Payment',
    default: null
  },
  subscriptionId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Subscription',
    default: null
  },
  agentId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Agent',
    default: null
  },
  
  // Description
  description: {
    type: String,
    required: true
  },
  notes: String,
  
  // Processing Information
  processedAt: Date,
  processedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    default: null
  },
  
  // Balance Tracking
  balanceBefore: {
    type: Number,
    default: 0
  },
  balanceAfter: {
    type: Number,
    default: 0
  },
  
  // Metadata
  metadata: {
    source: String,
    reference: String,
    batchId: String
  }
}, {
  timestamps: true
});

// Indexes
TransactionSchema.index({ userId: 1, createdAt: -1 });
// TransactionSchema.index({ transactionId: 1 }); // Removed: unique: true already creates index
TransactionSchema.index({ type: 1, status: 1 });
TransactionSchema.index({ paymentId: 1 });
TransactionSchema.index({ agentId: 1, userId: 1 });

const PaymentTransaction = mongoose.model('PaymentTransaction', TransactionSchema);

// ============================================
// 3. PAYMENT METHODS MODEL
// ============================================

const PaymentMethodSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  
  // Gateway Information
  gateway: {
    provider: {
      type: String,
      required: true,
      enum: ['stripe', 'paypal', 'razorpay']
    },
    paymentMethodId: String, // Gateway's payment method ID
    customerId: String // Gateway's customer ID
  },
  
  // Payment Method Type
  type: {
    type: String,
    required: true,
    enum: ['card', 'bank_account', 'wallet']
  },
  
  // Card Details (if type is card)
  card: {
    last4: String,
    brand: String,
    expMonth: Number,
    expYear: Number,
    fingerprint: String,
    funding: String, // credit, debit, prepaid
    country: String
  },
  
  // Bank Account Details (if type is bank_account)
  bankAccount: {
    last4: String,
    bankName: String,
    accountType: String,
    routingNumber: String
  },
  
  // Billing Details
  billingDetails: {
    name: String,
    email: String,
    phone: String,
    address: {
      line1: String,
      line2: String,
      city: String,
      state: String,
      postalCode: String,
      country: String
    }
  },
  
  // Status
  isDefault: {
    type: Boolean,
    default: false
  },
  isActive: {
    type: Boolean,
    default: true
  },
  isVerified: {
    type: Boolean,
    default: false
  },
  verifiedAt: Date,
  
  // Usage
  lastUsedAt: Date,
  usageCount: {
    type: Number,
    default: 0
  },
  
  // Metadata
  nickname: String, // User's custom name for this method
  metadata: {
    addedVia: {
      type: String,
      enum: ['web', 'mobile', 'api'],
      default: 'web'
    }
  }
}, {
  timestamps: true
});

// Indexes
PaymentMethodSchema.index({ userId: 1, isActive: 1 });
PaymentMethodSchema.index({ userId: 1, isDefault: 1 });
PaymentMethodSchema.index({ 'gateway.paymentMethodId': 1 });

const PaymentMethod = mongoose.model('PaymentMethod', PaymentMethodSchema);

// ============================================
// 4. SUBSCRIPTION BILLING CYCLES MODEL
// ============================================

const BillingCycleSchema = new mongoose.Schema({
  subscriptionId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Subscription',
    required: true
  },
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  agentId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Agent',
    required: true
  },
  planId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Plan',
    required: true
  },
  
  // Billing Period
  periodStart: {
    type: Date,
    required: true
  },
  periodEnd: {
    type: Date,
    required: true
  },
  
  // Billing Status
  status: {
    type: String,
    required: true,
    enum: [
      'upcoming',
      'pending',
      'paid',
      'failed',
      'canceled',
      'refunded'
    ],
    default: 'upcoming'
  },
  
  // Payment Information
  paymentId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Payment',
    default: null
  },
  
  // Amounts
  amount: {
    subtotal: Number,
    tax: Number,
    discount: Number,
    total: Number,
    currency: String
  },
  
  // Billing Dates
  billingDate: {
    type: Date,
    required: true
  },
  paidDate: Date,
  dueDate: Date,
  
  // Retry Information (for failed payments)
  retryCount: {
    type: Number,
    default: 0
  },
  nextRetryAt: Date,
  
  // Usage Tracking (if applicable)
  usage: {
    tokensUsed: Number,
    chatsCount: Number,
    filesUploaded: Number
  },
  
  // Prorations and Adjustments
  prorations: [{
    description: String,
    amount: Number,
    reason: String
  }],
  
  // Notes
  notes: String,
  
  // Metadata
  metadata: {
    cycleNumber: Number, // 1st cycle, 2nd cycle, etc.
    isFirstCycle: Boolean,
    isLastCycle: Boolean
  }
}, {
  timestamps: true
});

// Indexes
BillingCycleSchema.index({ subscriptionId: 1, periodStart: 1 });
BillingCycleSchema.index({ userId: 1, billingDate: 1 });
BillingCycleSchema.index({ status: 1, billingDate: 1 });
BillingCycleSchema.index({ agentId: 1, userId: 1 });

const BillingCycle = mongoose.model('BillingCycle', BillingCycleSchema);

// Export all payment models
module.exports = {
  Payment,
  PaymentTransaction,
  PaymentMethod,
  BillingCycle
};