// Create ONE-TIME Stripe prices for all monthly plans
// Run this script to fix the recurring price issue

require("dotenv").config();
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const fs = require('fs');

async function createOneTimePrices() {
  console.log("🚀 Creating ONE-TIME monthly prices for all agents\n");
  
  const agents = [
    { name: "AI Girlfriend", key: "AIGIRLFRIEND" },
    { name: "Agent X", key: "AGENTX" },
    { name: "Auto Chat", key: "AUTOCHAT" },
    { name: "CV Smash", key: "CVSMASH" },
    { name: "Chat Revive", key: "CHATREVIVE" },
    { name: "Comedy Chad", key: "COMEDYCHAD" },
    { name: "Cool Kyle", key: "COOLKYLE" },
    { name: "Emo AI", key: "EMOAI" },
    { name: "Flirty Fiona", key: "FLIRTYFIONA" },
    { name: "Gamer Gary", key: "GAMERGARY" },
    { name: "Lazy Larry", key: "LAZYLARRY" },
    { name: "Nerdy Neil", key: "NERDYNEIL" },
    { name: "PDF Mind", key: "PDFMIND" },
    { name: "Sassy Sarah", key: "SASSYSARAH" },
    { name: "Tok Boost", key: "TOKBOOST" },
    { name: "You Gen", key: "YOUGEN" },
    { name: "Zen Master Zara", key: "ZENMASTERZARA" },
    // Missing agents
    { name: "Data Dynamo", key: "DATADYNAMO" },
    { name: "Fitness Fury", key: "FITNESSFURY" },
    { name: "Math Monster", key: "MATHMONSTER" },
    { name: "Chef Charlie", key: "CHEFCHARLIE" },
    { name: "Travel Tom", key: "TRAVELTOM" },
    { name: "Music Mike", key: "MUSICMIKE" },
    { name: "Art Angel", key: "ARTANGEL" },
    { name: "Smart Susan", key: "SMARTSUSAN" },
    { name: "Code Crusher", key: "CODECRUSHER" },
  ];
  
  const prices = {
    DAILY: { amount: 100, name: "Daily Access" },      // $1
    WEEKLY: { amount: 500, name: "Weekly Access" },    // $5
    MONTHLY: { amount: 1900, name: "Monthly Access" }, // $19
  };
  
  const newPriceIds = [];
  
  for (const agent of agents) {
    console.log(`\n📦 Creating prices for ${agent.name}...`);
    
    for (const [planType, config] of Object.entries(prices)) {
      const envKey = `STRIPE_PRICE_${agent.key}_${planType}`;
      const existingPriceId = process.env[envKey];
      
      // Check if we need to create new price
      let needsNew = false;
      
      if (!existingPriceId) {
        needsNew = true;
        console.log(`   ${planType}: Missing, will create`);
      } else {
        try {
          const existingPrice = await stripe.prices.retrieve(existingPriceId);
          if (existingPrice.type === 'recurring') {
            needsNew = true;
            console.log(`   ${planType}: Is recurring, will create one-time`);
          } else {
            console.log(`   ${planType}: ✅ Already one-time`);
            continue;
          }
        } catch (err) {
          needsNew = true;
          console.log(`   ${planType}: Error checking, will create`);
        }
      }
      
      if (needsNew) {
        try {
          // First create or get a product
          const products = await stripe.products.search({
            query: `name~"${agent.name}"`,
          });
          
          let productId;
          if (products.data.length > 0) {
            productId = products.data[0].id;
          } else {
            // Create new product
            const product = await stripe.products.create({
              name: `${agent.name} - ${config.name}`,
              description: `${agent.name} AI Agent - ${config.name}`,
            });
            productId = product.id;
          }
          
          // Create one-time price
          const newPrice = await stripe.prices.create({
            unit_amount: config.amount,
            currency: 'usd',
            product: productId,
            metadata: {
              agent: agent.key,
              planType: planType,
              duration: planType === 'DAILY' ? '1 day' : planType === 'WEEKLY' ? '7 days' : '30 days',
            },
          });
          
          newPriceIds.push(`${envKey}=${newPrice.id}`);
          console.log(`   ✅ Created: ${newPrice.id}`);
        } catch (err) {
          console.error(`   ❌ Error creating ${planType}: ${err.message}`);
        }
      }
    }
  }
  
  console.log("\n\n📋 ==========================================");
  console.log("   NEW PRICE IDS TO ADD TO .env");
  console.log("   ==========================================\n");
  
  if (newPriceIds.length > 0) {
    newPriceIds.forEach(line => console.log(line));
    
    // Also write to a file
    fs.writeFileSync('new-price-ids.txt', newPriceIds.join('\n'));
    console.log("\n✅ Also saved to new-price-ids.txt");
  } else {
    console.log("No new prices needed!");
  }
}

createOneTimePrices().catch(console.error);
