require('dotenv').config({ path: './backend/.env' });
const mongoose = require('mongoose');
const fs = require('fs');
const path = require('path');

// Import all model files to check what's defined
const modelsCjs = require('./backend/models.cjs');
const contentModels = require('./backend/content-models.js');
const agentPurchaseModels = require('./backend/agent-purchase-models.js');
const supportModels = require('./backend/support-models.js');
const rbacModels = require('./backend/rbac-models.js');
const paymentModels = require('./backend/payment-models.js');

async function audit() {
  await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/iamai-global');
  const db = mongoose.connection.db;

  console.log('🔍 COMPREHENSIVE MODEL AUDIT REPORT');
  console.log('====================================');
  console.log('Date:', new Date().toISOString());
  console.log('');

  // Get database collections
  const dbCollections = await db.listCollections().toArray();
  const dbCollectionNames = dbCollections.map(c => c.name).sort();

  // Collect all defined models from all files
  const allDefinedModels = {};

  // From models.cjs
  Object.keys(modelsCjs).forEach(key => {
    if (typeof modelsCjs[key] === 'function' && modelsCjs[key].modelName) {
      allDefinedModels[modelsCjs[key].modelName] = {
        modelName: modelsCjs[key].modelName,
        collection: modelsCjs[key].collection.name,
        source: 'models.cjs'
      };
    }
  });

  // From content-models.js
  Object.keys(contentModels).forEach(key => {
    if (typeof contentModels[key] === 'function' && contentModels[key].modelName) {
      allDefinedModels[contentModels[key].modelName] = {
        modelName: contentModels[key].modelName,
        collection: contentModels[key].collection.name,
        source: 'content-models.js'
      };
    }
  });

  // From agent-purchase-models.js
  Object.keys(agentPurchaseModels).forEach(key => {
    if (typeof agentPurchaseModels[key] === 'function' && agentPurchaseModels[key].modelName) {
      allDefinedModels[agentPurchaseModels[key].modelName] = {
        modelName: agentPurchaseModels[key].modelName,
        collection: agentPurchaseModels[key].collection.name,
        source: 'agent-purchase-models.js'
      };
    }
  });

  // From support-models.js
  Object.keys(supportModels).forEach(key => {
    if (typeof supportModels[key] === 'function' && supportModels[key].modelName) {
      allDefinedModels[supportModels[key].modelName] = {
        modelName: supportModels[key].modelName,
        collection: supportModels[key].collection.name,
        source: 'support-models.js'
      };
    }
  });

  // From rbac-models.js
  Object.keys(rbacModels).forEach(key => {
    if (typeof rbacModels[key] === 'function' && rbacModels[key].modelName) {
      allDefinedModels[rbacModels[key].modelName] = {
        modelName: rbacModels[key].modelName,
        collection: rbacModels[key].collection.name,
        source: 'rbac-models.js'
      };
    }
  });

  // From payment-models.js
  Object.keys(paymentModels).forEach(key => {
    if (typeof paymentModels[key] === 'function' && paymentModels[key].modelName) {
      allDefinedModels[paymentModels[key].modelName] = {
        modelName: paymentModels[key].modelName,
        collection: paymentModels[key].collection.name,
        source: 'payment-models.js'
      };
    }
  });

  console.log('📋 MODELS DEFINED IN CODEBASE:');
  console.log('==============================');
  Object.values(allDefinedModels).sort((a,b) => a.modelName.localeCompare(b.modelName)).forEach(model => {
    console.log(`• ${model.modelName} (${model.collection}) - ${model.source}`);
  });

  console.log(`\n📊 TOTAL MODELS DEFINED: ${Object.keys(allDefinedModels).length}`);

  console.log(`\n📊 DATABASE COLLECTIONS: ${dbCollectionNames.length}`);

  // Check for missing collections
  const definedCollections = Object.values(allDefinedModels).map(m => m.collection);
  const missingCollections = definedCollections.filter(col => !dbCollectionNames.includes(col));
  const extraCollections = dbCollectionNames.filter(col => !definedCollections.includes(col));

  console.log(`\n❌ MISSING COLLECTIONS (defined but not in DB):`);
  console.log('================================================');
  if (missingCollections.length === 0) {
    console.log('✅ All defined collections exist in database');
  } else {
    missingCollections.forEach(col => {
      const model = Object.values(allDefinedModels).find(m => m.collection === col);
      console.log(`• ${col} (${model ? model.modelName : 'unknown model'})`);
    });
  }

  console.log(`\n⚠️  EXTRA COLLECTIONS (in DB but not defined in models):`);
  console.log('=======================================================');
  if (extraCollections.length === 0) {
    console.log('✅ All database collections are defined in models');
  } else {
    extraCollections.forEach(col => console.log(`• ${col}`));
  }

  // Check for models referenced but not found
  console.log(`\n🔍 MODELS REFERENCED IN CODE BUT NOT FOUND:`);
  console.log('=============================================');

  const foundModels = Object.keys(allDefinedModels);
  const potentiallyMissing = [];

  // Search for model references in code
  function searchFiles(dir, pattern) {
    try {
      const files = fs.readdirSync(dir);
      for (const file of files) {
        const filePath = path.join(dir, file);
        const stat = fs.statSync(filePath);

        if (stat.isDirectory() && !file.startsWith('.') && file !== 'node_modules') {
          searchFiles(filePath, pattern);
        } else if ((file.endsWith('.js') || file.endsWith('.cjs')) && !file.includes('node_modules')) {
          try {
            const content = fs.readFileSync(filePath, 'utf8');
            const matches = content.match(pattern);
            if (matches) {
              matches.forEach(match => {
                const modelName = match.replace(/Model|Schema|\.model|\.models|require|\(|\)|'|"/g, '').trim();
                if (modelName && modelName.length > 2 && !foundModels.includes(modelName) && !potentiallyMissing.includes(modelName)) {
                  // Filter out common non-model words
                  if (!['function', 'const', 'let', 'var', 'if', 'for', 'while', 'return', 'export', 'import'].includes(modelName.toLowerCase())) {
                    potentiallyMissing.push(modelName);
                  }
                }
              });
            }
          } catch (e) {}
        }
      }
    } catch (e) {}
  }

  searchFiles('./backend', /\b[A-Z][a-zA-Z]*Model\b/g);
  searchFiles('./backend', /\b[A-Z][a-zA-Z]*Schema\b/g);

  if (potentiallyMissing.length > 0) {
    potentiallyMissing.sort().forEach(model => console.log(`• ${model}`));
  } else {
    console.log('✅ No obvious missing model references found');
  }

  console.log(`\n🎯 AUDIT SUMMARY:`);
  console.log('================');
  console.log(`Defined Models: ${Object.keys(allDefinedModels).length}`);
  console.log(`Database Collections: ${dbCollectionNames.length}`);
  console.log(`Missing Collections: ${missingCollections.length}`);
  console.log(`Extra Collections: ${extraCollections.length}`);
  console.log(`Potentially Missing Models: ${potentiallyMissing.length}`);

  if (missingCollections.length === 0 && extraCollections.length === 0) {
    console.log(`\n✅ AUDIT STATUS: COMPLETE - All models properly implemented`);
  } else {
    console.log(`\n⚠️  AUDIT STATUS: ISSUES FOUND - Review missing/extra items above`);
  }

  await mongoose.connection.close();
}

audit().catch(console.error);