import React from 'react';

export interface AgentCapabilities {
  canAttachFiles: boolean;
  canUseVoice: boolean;
  canAccessWeb?: boolean;
  multilingual?: boolean;
  proactiveEngagement?: boolean;
  canAnalyzeMoodData?: boolean;
  canGeneratePoetry?: boolean;
  canCreatePlaylists?: boolean;
  canPlanEvents?: boolean;
  canRunCode?: boolean;
  canGenerateDiagrams?: boolean;
  canMonitorSystems?: boolean;
  canTriggerAPIs?: boolean;
  canScheduleJobs?: boolean;
}

export interface AgentRole {
  id: string;
  name: string;
  role: string;
  description: string;
  icon: string;
  capabilities: {
    canAttachFiles: boolean;
  };
}

export interface Agent {
  id: string;
  name: string;
  role: string;
  description: string;
  icon: string; // Can be 'fa-solid fa-robot' OR 'data:image/png;base64,...'
  version?: string;
  tags?: string[];
  capabilities: AgentCapabilities;
  voicePreferences: {
    defaultGender: 'female' | 'male';
    allowGenderToggle: boolean;
  };
  cognition?: {
    contextualAwareness: boolean;
    longTermMemory: boolean;
    goalTracking: boolean;
    adaptiveLearning: boolean;
    ethicalReasoning: boolean;
    episodicMemory?: boolean;
    conflictResolution?: boolean;
    emotionalForecasting?: boolean;
    memoryAnchoring?: boolean;
    errorRecovery?: boolean;
    anomalyDetection?: boolean;
    optimizationHeuristics?: boolean;
    dependencyMapping?: boolean;
  };
  skills?: {
    enabled: string[];
    marketplaceIntegration: boolean;
    autoSkillDiscovery: boolean;
  };
  webOps?: {
    realTimeSearch: boolean;
    citationBuilder: boolean;
    sourceValidation: boolean;
    multiSourceSynthesis: boolean;
  };
  personalityMatrix: {
    formality: number; // 0-100 (Kept for form compatibility)
    humor: number; // 0-100 (Kept for form compatibility)
    enthusiasm: number; // 0-100 (Kept for form compatibility)
    leadership?: number;
    diplomacy?: number;
    humorStyle?:
      | 'dry wit'
      | 'puns'
      | 'playful'
      | 'sarcastic'
      | 'none'
      | 'warm and flirty'
      | 'minimal';
    storytelling?: number;
    resilience?: number;
    empathy?: number;
    precision?: number;
    creativity?: number;
    loveLanguage?: string[];
    attachmentStyle?: string;
    emotionalDepth?: number;
    romanticFlair?: number;
    toneAdaptability?: boolean;
  };
  developerTools?: {
    codeSandbox: boolean;
    APIBuilder: boolean;
    regexWizard: boolean;
    CLICompanion: boolean;
    logAnalyzer?: boolean;
    webhookTester?: boolean;
    flowDebugger?: boolean;
    schemaValidator?: boolean;
  };
  multimodal?: {
    imageRecognition: boolean;
    videoAnalysis: boolean;
    voiceToneAnalysis: boolean;
    diagramGeneration: boolean;
    musicMoodDetection?: boolean;
    selfieCompanionMode?: boolean;
    memoryGallerySupport?: boolean;
  };
  interaction?: {
    defaultTone?: string;
    conversationPacing?: string;
    preferredLanguage?: string;
    safeMode?: boolean;
    intimacyCalibration?: string;
    checkInFrequency?: string;
    emotionalMirroring?: boolean;
    flowVisualization?: boolean;
    autoEscalation?: boolean;
    auditTrailSupport?: boolean;
    multiTenantSupport?: boolean;
  };
  examples?: {
    prompts?: string[];
    responses?: string[];
  };
}

export interface Feature {
  name: string;
  description: string;
  icon: string;
}

export type PurchasePlanSlug = 'daily' | 'weekly' | 'monthly';

export interface PurchasePlan {
  name: 'Daily' | 'Weekly' | 'Monthly';
  price: string;
  period: string;
  description: string;
}

export const AGENT_PURCHASE_PLANS: PurchasePlan[] = [
  {
    name: 'Daily',
    price: '$1',
    period: '/ day',
    description: 'Perfect for trying out an agent for a short task.',
  },
  {
    name: 'Weekly',
    price: '$5',
    period: '/ week',
    description: 'Ideal for project-based work or focused sessions.',
  },
  {
    name: 'Monthly',
    price: '$15',
    period: '/ month',
    description: 'Best value for continuous use and integration.',
  },
];

export interface Solution {
  name: string;
  description: string;
  icon: string;
}

export interface HowItWorksStep {
  title: string;
  description: string;
  icon: string;
}

export interface Testimonial {
  quote: string;
  name: string;
  title: string;
  avatar: string;
}

export interface FileAttachment {
  id: string;
  name: string;
  type: 'pdf' | 'docx' | 'txt' | 'image' | 'code' | 'json' | 'csv';
  size: number;
  url?: string;
  preview?: string;
  content?: string;
  mimeType?: string;
  metadata?: {
    language?: string; // for code files
    pages?: number; // for PDFs
    dimensions?: { width: number; height: number }; // for images
  };
}

export interface MessageReactions {
  likes: number;
  dislikes: number;
  userReaction?: 'like' | 'dislike' | null;
}

export interface Message {
  id: string;
  role: 'user' | 'agent';
  content: string;
  contentType?: 'text' | 'markdown' | 'code';
  timestamp: Date;
  agent?: Agent;
  feedback?: {
    rating: 'good' | 'bad' | null;
    comment?: string;
  };
  sources?: {
    uri: string;
    title: string;
  }[];
  attachments?: FileAttachment[];
  reactions?: MessageReactions;
  metadata?: {
    model?: string;
    temperature?: number;
    tokens?: number;
    processingTime?: number;
  };
}

export interface AIModel {
  id: string;
  name: string;
  provider: 'Ollama' | 'Google' | 'OpenAI' | 'Anthropic';
}

export const AI_MODELS: { [key: string]: AIModel[] } = {
  Google: [{ id: 'gemini-2.5-flash', name: 'Gemini 2.5 Flash', provider: 'Google' }],
  'Ollama (Local)': [
    { id: 'llama3.2', name: 'Llama 3.2', provider: 'Ollama' },
    { id: 'gemma2', name: 'Gemma 2', provider: 'Ollama' },
    { id: 'phi3', name: 'Phi-3', provider: 'Ollama' },
    { id: 'mistral', name: 'Mistral', provider: 'Ollama' },
    { id: 'qwen2.5', name: 'Qwen 2.5', provider: 'Ollama' },
    { id: 'yi', name: 'Yi', provider: 'Ollama' },
    { id: 'deepseek-coder', name: 'Deepseek Coder', provider: 'Ollama' },
    { id: 'qwen2.5-coder', name: 'Qwen 2.5 Coder', provider: 'Ollama' },
    { id: 'mathstral', name: 'Mathstral', provider: 'Ollama' },
  ],
  OpenAI: [{ id: 'gpt-4o', name: 'GPT-4o', provider: 'OpenAI' }],
  Anthropic: [{ id: 'claude-3.5-sonnet', name: 'Claude 3.5 Sonnet', provider: 'Anthropic' }],
};

export const ALL_MODELS: AIModel[] = Object.values(AI_MODELS).flat();

export const FEATURES: Feature[] = [
  {
    name: 'Multi-Agent Ecosystem',
    description: '9+ specialized AI agents, each with a unique character and role.',
    icon: 'fa-solid fa-users-gear',
  },
  {
    name: 'Universal Memory',
    description: 'Cross-agent memory sharing and long-term context retention.',
    icon: 'fa-solid fa-brain',
  },
  {
    name: 'Real-Time Communication',
    description: 'Instant streaming responses via bidirectional WebSockets.',
    icon: 'fa-solid fa-bolt',
  },
  {
    name: 'Predictive Analytics',
    description: 'Performance monitoring and user behavior analysis engine.',
    icon: 'fa-solid fa-chart-line',
  },
  {
    name: 'Enterprise Security',
    description:
      'Modern authentication with Auth.js v5 - secure password-based login with bcrypt encryption.',
    icon: 'fa-solid fa-shield-halved',
  },
  {
    name: 'Cloud Deployment',
    description: 'Easy deployment and scaling for all services and agents.',
    icon: 'fa-solid fa-cloud',
  },
];

export const SOLUTIONS: Solution[] = [
  {
    name: 'Healthcare',
    description: 'AI-powered patient support, data analysis, and administrative automation.',
    icon: 'fa-solid fa-heart-pulse',
  },
  {
    name: 'Finance',
    description: 'Market analysis, fraud detection, and personalized financial advisory agents.',
    icon: 'fa-solid fa-piggy-bank',
  },
  {
    name: 'Education',
    description: 'Personalized tutoring, content generation, and learning support.',
    icon: 'fa-solid fa-graduation-cap',
  },
  {
    name: 'Retail',
    description: 'Personalized shopping assistants, inventory management, and customer insights.',
    icon: 'fa-solid fa-store',
  },
  {
    name: 'Customer Support',
    description: 'Automated 24/7 support, ticket routing, and sentiment analysis.',
    icon: 'fa-solid fa-headset',
  },
  {
    name: 'Marketing',
    description: 'Content creation, campaign optimization, and social media management.',
    icon: 'fa-solid fa-bullhorn',
  },
];

export const HOW_IT_WORKS_STEPS: HowItWorksStep[] = [
  {
    title: 'Character-Driven Agents',
    description:
      'Each agent is a standalone service with a unique persona and role, running in isolated processes for complete separation and scalability.',
    icon: 'fa-solid fa-user-astronaut',
  },
  {
    title: 'Ollama & Universal Memory',
    description:
      'Agents leverage powerful, open-source Ollama models. A shared Universal Memory system provides long-term context across all agents.',
    icon: 'fa-solid fa-database',
  },
  {
    title: 'Real-Time API & WebSockets',
    description:
      'Interact with agents through a high-performance Flask/Nginx backend, with real-time streaming responses delivered via WebSockets.',
    icon: 'fa-solid fa-satellite-dish',
  },
];

export const TESTIMONIALS: Testimonial[] = [
  {
    quote:
      "IA M AI's character-based approach is a game-changer. We built a customer support agent that not only solves problems but also builds rapport with users. Integration was seamless.",
    name: 'Jane Doe',
    title: 'CTO, InnovateTech',
    avatar: 'https://picsum.photos/100/100?random=1',
  },
  {
    quote:
      'The developer experience is top-notch. Spinning up new agents is incredibly fast with the containerized architecture. The universal memory system is pure genius.',
    name: 'John Smith',
    title: 'Lead Developer, CodeCrafters',
    avatar: 'https://picsum.photos/100/100?random=2',
  },
  {
    quote:
      "We used TokBoost and YouGen to automate our entire content pipeline. The results were astounding—our engagement metrics have tripled. It's like having a dedicated creative team on demand.",
    name: 'Emily White',
    title: 'Marketing Director, Growthify',
    avatar: 'https://picsum.photos/100/100?random=3',
  },
];

export interface Brand {
  name: string;
  logoUrl: string;
}

export const BRANDS: Brand[] = [
  {
    name: 'QuantumLeap',
    logoUrl: 'https://tailwindui.com/img/logos/158x48/transistor-logo-white.svg',
  },
  { name: 'SynthCore', logoUrl: 'https://tailwindui.com/img/logos/158x48/reform-logo-white.svg' },
  { name: 'InnovateX', logoUrl: 'https://tailwindui.com/img/logos/158x48/tuple-logo-white.svg' },
  { name: 'NexusAI', logoUrl: 'https://tailwindui.com/img/logos/158x48/savvycal-logo-white.svg' },
  { name: 'DataWeave', logoUrl: 'https://tailwindui.com/img/logos/158x48/statamic-logo-white.svg' },
];

export interface Stat {
  value: string;
  label: string;
}

export const STATS: Stat[] = [
  { value: '5M+', label: 'User Interactions' },
  { value: '10,000+', label: 'Developers on Platform' },
  { value: '99.9%', label: 'Uptime SLA' },
  { value: '200ms', label: 'Average Response Time' },
];

export interface Template {
  id: string;
  name: string;
  description: string;
  icon: string;
}

export const TEMPLATES: Template[] = [
  // Cloud-based Agent Templates
  {
    id: 'customer-support-bot',
    name: 'Customer Support Bot',
    description: 'Resolve customer queries instantly, 24/7.',
    icon: 'fa-solid fa-headset',
  },
  {
    id: 'onboarding-assistant',
    name: 'Onboarding Assistant',
    description: 'Guide new users through your product seamlessly.',
    icon: 'fa-solid fa-rocket',
  },
  {
    id: 'sales-development-rep',
    name: 'Sales Development Rep',
    description: 'Qualify leads and book meetings automatically.',
    icon: 'fa-solid fa-dollar-sign',
  },
  {
    id: 'content-summarizer',
    name: 'Content Summarizer',
    description: 'Condense articles and documents into key points.',
    icon: 'fa-solid fa-file-lines',
  },

  // Local AI Models (Ollama/Hugging Face)
  {
    id: 'llama-3-local',
    name: 'Llama 3.2 (Local)',
    description: "Run Meta's Llama 3.2 model locally with Ollama.",
    icon: 'fa-solid fa-server',
  },
  {
    id: 'mistral-local',
    name: 'Mistral 7B (Local)',
    description: 'Efficient 7B parameter model for local deployment.',
    icon: 'fa-solid fa-microchip',
  },
  {
    id: 'phi-3-local',
    name: 'Phi-3 Mini (Local)',
    description: "Microsoft's compact 3.8B model for edge devices.",
    icon: 'fa-solid fa-mobile-screen',
  },
  {
    id: 'gemma-local',
    name: 'Gemma 2B (Local)',
    description: "Google's lightweight model for local inference.",
    icon: 'fa-solid fa-cube',
  },
  {
    id: 'codellama-local',
    name: 'CodeLlama (Local)',
    description: 'Specialized code generation model running locally.',
    icon: 'fa-solid fa-code',
  },
  {
    id: 'neural-chat-local',
    name: 'Neural Chat 7B (Local)',
    description: "Intel's optimized conversational AI model.",
    icon: 'fa-solid fa-comments',
  },
  {
    id: 'vicuna-local',
    name: 'Vicuna 13B (Local)',
    description: 'Open-source chatbot trained by fine-tuning LLaMA.',
    icon: 'fa-solid fa-brain',
  },
  {
    id: 'orca-mini-local',
    name: 'Orca Mini (Local)',
    description: 'Compact model trained on explanation data.',
    icon: 'fa-solid fa-fish',
  },
];

export interface BlogPost {
  slug: string;
  title: string;
  category: string;
  date: string;
  imageUrl: string;
  excerpt: string;
  content?: string;
  year?: number;
  author?: string;
  tags?: string[];
  references?: string[];
}

export const BLOG_POSTS: BlogPost[] = [
  {
    slug: 'future-of-ai-is-character-driven',
    title: 'The Future of AI is Character-Driven',
    category: 'Insights',
    date: 'July 15, 2024',
    imageUrl: 'https://picsum.photos/600/400?random=10',
    excerpt:
      'Discover why specialized, persona-driven AI agents are outperforming generic models in user engagement and task completion.',
    content:
      'Discover why specialized, persona-driven AI agents are outperforming generic models in user engagement and task completion. In this deep dive, we explore the psychological principles behind character AI and showcase real-world examples of how our platform is leading the charge in creating more meaningful and effective human-AI interactions. The shift from monolithic models to a diverse ecosystem of specialized agents represents a paradigm shift in the industry, and we are at the forefront.',
  },
  {
    slug: 'building-your-first-agent',
    title: 'Building Your First Agent with IA M AI',
    category: 'Tutorial',
    date: 'July 10, 2024',
    imageUrl: 'https://picsum.photos/600/400?random=11',
    excerpt:
      'A step-by-step guide to creating, containerizing, and deploying your first custom AI agent on our platform in under 30 minutes.',
    content:
      "A step-by-step guide to creating and deploying your first custom AI agent on our platform in under 30 minutes. This tutorial is designed for developers of all skill levels. We will walk you through setting up your environment, defining your agent's persona and capabilities using our SDK, and deploying it with a single command. By the end, you will have a fully functional, custom agent integrated into your IA M AI ecosystem.",
  },
  {
    slug: 'universal-memory-deep-dive',
    title: 'Universal Memory: The Key to Long-Term Context',
    category: 'Technology',
    date: 'July 5, 2024',
    imageUrl: 'https://picsum.photos/600/400?random=12',
    excerpt:
      'A deep dive into our innovative memory architecture that allows agents to retain context across multiple conversations.',
    content:
      'A deep dive into our innovative memory architecture that allows agents to retain context across multiple conversations. Standard AI models suffer from limited context windows, leading to forgetfulness. Our Universal Memory system solves this by providing a persistent, shared context layer that all agents can access. We will explore the technical underpinnings of this system, including vector databases and retrieval-augmented generation (RAG), and demonstrate how it unlocks new possibilities for complex, long-running tasks.',
  },
];

export interface FAQItem {
  question: string;
  answer: string;
  category?: string;
}

export const FAQ_CATEGORIES = {
  GETTING_STARTED: 'Getting Started & Account',
  AGENTS_PLATFORM: 'Agents & Platform',
  SUPPORT_HELP: 'Live Support & Help',
  REPORTS_COMPLIANCE: 'Reports & Compliance',
  API_DEVELOPERS: 'API & Developers',
  SECURITY_PRIVACY: 'Security & Privacy',
  BILLING_SUBSCRIPTIONS: 'Billing & Purchases',
  TROUBLESHOOTING: 'Troubleshooting',
} as const;

export const FAQS: FAQItem[] = [
  // Getting Started & Account
  {
    question: 'How do I create an account?',
    answer:
      "Visit our Sign Up page and register using your email address or OAuth provider. We offer passwordless authentication for enhanced security. Once you verify your email, you'll have full access to all our agents and features.",
    category: FAQ_CATEGORIES.GETTING_STARTED,
  },
  {
    question: 'How do I reset my password?',
    answer:
      "If you forget your password, click \"Forgot Password\" on the login page. We'll send you a secure link to reset it. If you're using passwordless authentication, you don't need a password—just verify through your email or OAuth provider each time.",
    category: FAQ_CATEGORIES.GETTING_STARTED,
  },
  {
    question: 'Can I use multiple accounts?',
    answer:
      "Yes, you can create multiple accounts with different email addresses. However, purchased access is tied to individual accounts, so you'll need separate purchases for each account. Enterprise customers can request account linking.",
    category: FAQ_CATEGORIES.GETTING_STARTED,
  },
  {
    question: 'What payment methods do you accept?',
    answer:
      'We accept all major credit and debit cards (Visa, Mastercard, American Express) through Stripe. All payments are processed securely with industry-standard encryption and PCI compliance.',
    category: FAQ_CATEGORIES.GETTING_STARTED,
  },

  // Agents & Platform
  {
    question: 'What makes IA M AI different from other AI platforms?',
    answer:
      'IA M AI focuses on a multi-agent, character-driven architecture. Instead of a single generic AI, you get access to a team of specialized agents, each with a unique role and personality. This allows for more nuanced, effective, and engaging interactions for specific tasks. Every agent has distinct capabilities, memories, and communication styles.',
    category: FAQ_CATEGORIES.AGENTS_PLATFORM,
  },
  {
    question: 'What are the base models for the agents?',
    answer:
      "Our agents are built on a hybrid model architecture. They primarily leverage powerful, open-source models via Ollama for flexibility and privacy. For tasks requiring higher reasoning or specific capabilities, they can be configured to use external APIs like Google Gemini, OpenAI's GPT series, or Anthropic's Claude. You have full control over which models power your agents.",
    category: FAQ_CATEGORIES.AGENTS_PLATFORM,
  },
  {
    question: 'Can I create my own custom agents?',
    answer:
      "Absolutely. The platform is designed for extensibility. We provide a comprehensive developer SDK and deployment framework that make it easy to define a new agent's persona, capabilities, tools, and behaviors. You can then deploy it seamlessly into your ecosystem. Check our Developer Documentation for detailed guides.",
    category: FAQ_CATEGORIES.AGENTS_PLATFORM,
  },
  {
    question: 'What capabilities do the agents have?',
    answer:
      'Agents can perform text generation, code execution, file processing, sentiment analysis, web search, API integration, and much more. Each agent has a configurable set of skills that can be enabled or disabled based on your needs. You can also add custom capabilities through our skill marketplace or SDK.',
    category: FAQ_CATEGORIES.AGENTS_PLATFORM,
  },
  {
    question: 'Can agents access my documents and files?',
    answer:
      'Yes, agents can analyze documents you upload (PDF, Word, Text, Images). They use this context to provide more accurate and personalized responses. All document processing happens securely, and you maintain complete control over what data is shared. For maximum privacy, you can run agents locally using Ollama.',
    category: FAQ_CATEGORIES.AGENTS_PLATFORM,
  },

  // Live Support & Help
  {
    question: 'How does Live Support work?',
    answer:
      'Our AI-powered Live Support system provides 24/7 assistance. You can ask questions, upload documents for analysis, and receive instant help. The system automatically classifies your issue and suggests relevant FAQ articles. If you need human assistance, you can escalate your ticket and receive a response within 48 hours.',
    category: FAQ_CATEGORIES.SUPPORT_HELP,
  },
  {
    question: 'What document formats does Live Support accept?',
    answer:
      'Live Support accepts PDF, Word documents (.doc, .docx), text files (.txt), and images (.jpg, .png, .gif). Maximum file size is 50MB. You can upload multiple documents in a single conversation, and the AI will analyze and reference all of them when answering your questions.',
    category: FAQ_CATEGORIES.SUPPORT_HELP,
  },
  {
    question: 'How do I escalate my support ticket?',
    answer:
      "If Live Support can't resolve your issue, you can escalate it directly within the chat interface. This creates a formal support ticket with all your conversation history, documents, and issue details. Our team will receive your ticket and respond within 48 hours with a solution or next steps.",
    category: FAQ_CATEGORIES.SUPPORT_HELP,
  },
  {
    question: 'Can I track my support tickets?',
    answer:
      "Yes. When you escalate an issue, you receive a unique ticket ID. You can use this ID to track your ticket's status through our Support Dashboard or by emailing us. You'll also receive email updates when your ticket status changes.",
    category: FAQ_CATEGORIES.SUPPORT_HELP,
  },
  {
    question: 'Is there a response time guarantee for escalations?',
    answer:
      'We maintain a 48-hour SLA (Service Level Agreement) for all escalated support tickets. This means we guarantee a response within 48 hours. Critical issues may receive faster responses based on priority. Enterprise plans may have different SLAs—check your plan details.',
    category: FAQ_CATEGORIES.SUPPORT_HELP,
  },

  // Reports & Compliance
  {
    question: 'What is the Reports System?',
    answer:
      "The Reports System allows you to submit detailed reports about issues, bugs, feature requests, or compliance concerns. All reports go through a rigorous classification and validation process. We categorize reports by type (bug, feature request, compliance issue, etc.) and severity level to ensure they're handled appropriately.",
    category: FAQ_CATEGORIES.REPORTS_COMPLIANCE,
  },
  {
    question: 'What happens when I submit a report?',
    answer:
      "When you submit a report, it goes through our validation pipeline that checks for spam, duplicates, and authenticity. Valid reports are categorized, assigned a unique ID, and added to our tracking system. You'll receive a confirmation email with your report ID. Our team reviews all reports daily and takes appropriate action.",
    category: FAQ_CATEGORIES.REPORTS_COMPLIANCE,
  },
  {
    question: 'Are there consequences for false reports?',
    answer:
      'Yes. We take report integrity seriously. Submitting false, malicious, or spam reports violates our Terms of Service and may result in legal consequences. Users who repeatedly submit false reports may have their account suspended or terminated. Always ensure your reports are accurate and in good faith.',
    category: FAQ_CATEGORIES.REPORTS_COMPLIANCE,
  },
  {
    question: 'How do I report a security vulnerability?',
    answer:
      'For security vulnerabilities, please use our dedicated security reporting channel rather than the general reports system. Email security@iamai.com with details of the vulnerability. We follow responsible disclosure practices and will acknowledge your report within 24 hours and provide a security fix timeline.',
    category: FAQ_CATEGORIES.REPORTS_COMPLIANCE,
  },
  {
    question: 'Can I track the status of my report?',
    answer:
      "Yes. All reports receive a unique ID that you can use to track progress. You'll receive email updates when your report status changes (received, under review, in progress, resolved). For real-time updates, you can log into your dashboard and view your report history with detailed status information.",
    category: FAQ_CATEGORIES.REPORTS_COMPLIANCE,
  },

  // API & Developers
  {
    question: 'What is the REST API?',
    answer:
      'Our REST API allows you to integrate IA M AI agents into your applications, automate conversations, manage subscriptions, and access advanced features programmatically. The API uses standard HTTP methods and JSON format. All API requests require authentication via API keys or JWT tokens.',
    category: FAQ_CATEGORIES.API_DEVELOPERS,
  },
  {
    question: 'How do I get API documentation?',
    answer:
      "Complete API documentation is available in our Developer Hub. You'll find endpoint specifications, request/response examples, authentication details, error codes, rate limits, and code samples in multiple languages. Visit /documentation to access the full API reference.",
    category: FAQ_CATEGORIES.API_DEVELOPERS,
  },
  {
    question: 'Are there rate limits on the API?',
    answer:
      "Yes. All paid plans ($1 for 1 day, $5 for 7 days, $15 for 30 days per agent) include unlimited API requests for the agents you have active access to. Rate limit information is included in response headers. Enterprise customers can request custom rate limits.",
    category: FAQ_CATEGORIES.API_DEVELOPERS,
  },
  {
    question: 'How do I authenticate API requests?',
    answer:
      'You can authenticate using API keys (for simple integrations) or JWT tokens (for more complex scenarios). Include your credentials in the Authorization header using the Bearer scheme. Never expose API keys in client-side code—use a backend proxy instead. You can rotate keys anytime from your account settings.',
    category: FAQ_CATEGORIES.API_DEVELOPERS,
  },
  {
    question: 'Can I use WebSockets for real-time communication?',
    answer:
      'Yes. Our platform supports WebSocket connections for real-time, bidirectional communication with agents. This is ideal for chat applications, live updates, and streaming responses. WebSocket endpoints and authentication details are documented in our API reference.',
    category: FAQ_CATEGORIES.API_DEVELOPERS,
  },

  // Security & Privacy
  {
    question: 'Is my data secure?',
    answer:
      'Security is our top priority. We use Auth.js v5 for modern authentication with secure password-based login, end-to-end encryption for sensitive data, and TLS 1.3 for all communications. All data is encrypted at rest using AES-256. Passwords are hashed with bcrypt (10+ rounds). We undergo regular security audits and maintain SOC 2 compliance.',
    category: FAQ_CATEGORIES.SECURITY_PRIVACY,
  },
  {
    question: 'Is my data stored on your servers?',
    answer:
      'For cloud deployments, data is stored securely on our servers with encryption. However, you have complete control over your data. For maximum privacy, you can run agents locally using Ollama—in this case, your data never leaves your infrastructure. You can also request data deletion anytime.',
    category: FAQ_CATEGORIES.SECURITY_PRIVACY,
  },
  {
    question: 'Do you sell my data to third parties?',
    answer:
      "Absolutely not. We never sell, trade, or share your data with third parties. Your data is used only to provide our services and improve your experience (with your consent). We're transparent about data usage—check our Privacy Policy for complete details.",
    category: FAQ_CATEGORIES.SECURITY_PRIVACY,
  },
  {
    question: 'What privacy controls do I have?',
    answer:
      'You have full control over your privacy settings. You can delete your account and all associated data anytime. You can opt-out of analytics and telemetry collection. You can request a data export in standard formats. For detailed privacy options, visit your Account Settings > Privacy & Security.',
    category: FAQ_CATEGORIES.SECURITY_PRIVACY,
  },
  {
    question: 'Are conversations private?',
    answer:
      'Yes. All conversations are private and encrypted. Only you can access your conversation history. Our support team may review reports or escalated tickets only for troubleshooting (with your consent). We never use your conversations to train models unless you explicitly opt-in.',
    category: FAQ_CATEGORIES.SECURITY_PRIVACY,
  },

  // Billing & Purchases
  {
    question: 'How does pricing work?',
    answer:
      'We use a simple, per-agent purchase model. You can buy access to individual agents for 1 day ($1), 7 days ($5), or 30 days ($15). This means you pay only for the specific agents and timeframe you need. Each purchase is one-time (not recurring) and grants access until the expiration date.',
    category: FAQ_CATEGORIES.BILLING_SUBSCRIPTIONS,
  },
  {
    question: 'Can I cancel my purchase anytime?',
    answer:
      'Yes. You can cancel your access anytime from your Account Settings. When you cancel, your access expires immediately. After expiration or cancellation, you can purchase access again at any time.',
    category: FAQ_CATEGORIES.BILLING_SUBSCRIPTIONS,
  },
  {
    question: 'Do you offer discounts for longer access periods?',
    answer:
      'Our 30-day plan ($15) offers the best value compared to daily ($1/day = $30/month) or weekly ($5/week = $20/month) purchases. For enterprise or bulk agent access, contact our Sales team for custom pricing.',
    category: FAQ_CATEGORIES.BILLING_SUBSCRIPTIONS,
  },
  {
    question: 'What happens to my data if my access expires?',
    answer:
      'Your data remains secure and accessible for 30 days after your access expires. You can repurchase access anytime within this period to restore full functionality. After 30 days, your data will be permanently deleted. You can request a data export before your access expires if needed.',
    category: FAQ_CATEGORIES.BILLING_SUBSCRIPTIONS,
  },
  {
    question: 'What are your pricing plans?',
    answer:
      'Each agent requires a separate purchase with three simple options: $1 for 1 day, $5 for 7 days, or $15 for 30 days. All plans include unlimited access to that specific agent with no usage restrictions. Purchase as many agents as you need—each one requires its own separate purchase.',
    category: FAQ_CATEGORIES.BILLING_SUBSCRIPTIONS,
  },

  // Troubleshooting
  {
    question: "The chat isn't responding. What should I do?",
    answer:
      'First, check your internet connection and refresh the page. If issues persist, try clearing your browser cache and cookies. For persistent problems, check our Status Page (status.iamai.com) for service updates. If the service is online, contact Live Support or file a bug report from your dashboard.',
    category: FAQ_CATEGORIES.TROUBLESHOOTING,
  },
  {
    question: "My documents aren't uploading. What's wrong?",
    answer:
      'Check that your file is under 50MB and in a supported format (PDF, Word, Text, Images). Ensure your internet connection is stable. Try a different browser if issues continue. If upload fails repeatedly, the file may be corrupted—try uploading a different file. Contact support if the problem persists.',
    category: FAQ_CATEGORIES.TROUBLESHOOTING,
  },
  {
    question: "I'm getting an error message. How do I fix it?",
    answer:
      "Error messages are specific—note the error code and message exactly. Check our Troubleshooting Guide (linked in the error message) for solutions. If the guide doesn't help, contact Live Support with the error details. Include your browser type, OS version, and steps to reproduce the error.",
    category: FAQ_CATEGORIES.TROUBLESHOOTING,
  },
  {
    question: 'How do I report a bug?',
    answer:
      'Click the "Report" button in your dashboard and select "Bug Report." Describe what you did, what you expected, and what actually happened. Attach screenshots if possible. Include your browser/OS info. Our team reviews all bug reports within 24 hours and will contact you if we need more information.',
    category: FAQ_CATEGORIES.TROUBLESHOOTING,
  },
  {
    question: 'How do I request a new feature?',
    answer:
      'Use the "Report" button in your dashboard and select "Feature Request." Describe the feature you want, why you need it, and how it would help. Vote on existing feature requests to show community interest. Popular features are prioritized in our development roadmap.',
    category: FAQ_CATEGORIES.TROUBLESHOOTING,
  },
];

// Data for Agent-Specific UI
export interface AgentAction {
  prompt: string;
  icon: string;
  label: string;
}

export interface AgentStat {
  label: string;
  value: string;
  icon: string;
}

export interface AgentMemoryItem {
  label: string;
  value: string;
  icon: string;
}

export interface AgentRelationshipStat {
  label: string;
  value: number; // Percentage
}

export interface AgentRecentFile {
  name: string;
  date: string;
  icon: string;
}

export interface AgentResumeScore {
  total: number;
  formatting: number;
  keywords: number;
  impact: number;
}

export interface AgentChecklistItem {
  task: string;
  completed: boolean;
}

export interface AgentConversationHealth {
  responseRate: number;
  engagement: number;
  sentiment: number;
}

export interface AgentConversationTopic {
  topic: string;
  status: 'active' | 'fading';
}

export interface AgentEngagementRate {
  rate: number;
  likes: number;
  comments: number;
  shares: number;
}

export interface AgentViralTrend {
  topic: string;
  heat: number; // 0-100
}

export interface AgentContentIdea {
  title: string;
  type: 'Video' | 'Blog' | 'Social';
  icon: string;
}

export interface AgentSentimentAnalysis {
  score: number; // -1 to 1
  emotions: { name: string; value: number }[]; // value 0-100
}

export interface AgentEmotionalTrend {
  data: { message: number; sentiment: number }[]; // sentiment -1 to 1
}

export interface AgentCapabilityInfo {
  name: string;
  description: string;
  icon: string;
}

export interface AgentUIData {
  themeColor: string; // e.g., 'pink', 'cyan', 'red'
  quickActions: AgentAction[];
  stats: { title: string; items: AgentStat[] };
  memoryItems: AgentMemoryItem[];
  capabilitiesDescription?: AgentCapabilityInfo[];
  usageExamples?: { title: string; prompt: string; response: string }[];
  integrationSnippets?: { language: string; code: string }[];
  relationshipStats?: {
    // Optional for advanced agents
    title: string;
    items: AgentRelationshipStat[];
  };
  recentFiles?: {
    // Optional for advanced agents
    title: string;
    items: AgentRecentFile[];
  };
  resumeScore?: {
    // Optional for advanced agents
    title: string;
    score: AgentResumeScore;
  };
  careerChecklist?: {
    // Optional for advanced agents
    title: string;
    items: AgentChecklistItem[];
  };
  conversationHealth?: {
    // Optional for advanced agents
    title: string;
    health: AgentConversationHealth;
  };
  conversationTopics?: {
    // Optional for advanced agents
    title: string;
    items: AgentConversationTopic[];
  };
  engagementRate?: {
    // Optional for advanced agents
    title: string;
    rate: AgentEngagementRate;
  };
  viralTrends?: {
    // Optional for advanced agents
    title: string;
    items: AgentViralTrend[];
  };
  contentIdeas?: {
    // Optional for advanced agents
    title: string;
    items: AgentContentIdea[];
  };
  sentimentAnalysis?: {
    // Optional for advanced agents
    title: string;
    analysis: AgentSentimentAnalysis;
  };
  emotionalTrend?: {
    // Optional for advanced agents
    title: string;
    trend: AgentEmotionalTrend;
  };
}
