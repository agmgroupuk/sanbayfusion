// PM2 Ecosystem Configuration for IAMAI Production
module.exports = {
  apps: [
    {
      name: 'iamai-backend',
      script: 'production-server.js',
      cwd: './backend',
      instances: 'max',
      exec_mode: 'cluster',
      env: {
        NODE_ENV: 'production',
        PORT: 3001,
      },
      env_file: '.env',
      error_file: './logs/error.log',
      out_file: './logs/out.log',
      log_file: './logs/combined.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      merge_logs: true,
      time: true,
      watch: false,
      max_memory_restart: '1G',
      kill_timeout: 5000,
      min_uptime: '10s',
      max_restarts: 10,
    }
  ]
};