import React, { useState } from 'react';
import { Agent, AGENT_PURCHASE_PLANS, PurchasePlan } from '../constants';

interface SubscriptionPageProps {
  agent: Agent;
  onSubscribe: (agentName: string, planName: string) => void;
  onNavigate: (page: 'home') => void;
}

const SubscriptionCard: React.FC<{
  plan: PurchasePlan;
  onSelect: () => void;
  agentName: string;
  isLoading: boolean;
}> = ({ plan, onSelect, agentName, isLoading }) => (
  <div className="border rounded-2xl p-8 flex flex-col bg-gray-900/50 border-gray-800 hover:border-cyan-500/50 transition-all duration-300">
    <h3 className="text-lg font-semibold text-cyan-400">{plan.name}</h3>
    <div className="mt-4 flex items-baseline">
      <span className="text-4xl font-bold text-white">{plan.price}</span>
      <span className="ml-1 text-gray-400">{plan.period}</span>
    </div>
    <p className="mt-4 text-gray-400 h-12">{plan.description}</p>
    <button
      onClick={onSelect}
      disabled={isLoading}
      title={`Subscribe to the ${plan.name} plan for ${agentName}`}
      className={`w-full text-center mt-8 block px-6 py-3 rounded-lg font-semibold transition-colors ${
        isLoading
          ? 'bg-gray-600 text-gray-400 cursor-not-allowed'
          : 'bg-cyan-500 text-black hover:bg-cyan-400'
      }`}
    >
      {isLoading ? 'Processing...' : 'Subscribe Now'}
    </button>
  </div>
);

const SubscriptionPage: React.FC<SubscriptionPageProps> = ({ agent, onSubscribe, onNavigate }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubscribe = async (planName: string) => {
    setIsLoading(true);
    setError(null);

    try {
      // Get user info and auth token from localStorage
      const authData = localStorage.getItem('iamai_auth');
      if (!authData) {
        setError('Please log in to subscribe');
        setIsLoading(false);
        return;
      }

      const parsed = JSON.parse(authData);
      const user = parsed.user || parsed;
      const token = parsed.token;

      console.log('Auth check:', {
        hasUser: !!user,
        hasToken: !!token,
        userEmail: user?.email,
        tokenLength: token?.length,
      });

      if (!user || !user.email) {
        setError('User information not found. Please log in again.');
        setIsLoading(false);
        return;
      }

      if (!token) {
        setError('Authentication token not found. Please log in again.');
        setIsLoading(false);
        return;
      }

      // Map plan names to Stripe plan IDs
      const planMapping: Record<string, string> = {
        daily: 'daily',
        weekly: 'weekly',
        monthly: 'monthly',
      };

      const stripePlanId = planMapping[planName.toLowerCase()];
      if (!stripePlanId) {
        throw new Error('Invalid plan selected');
      }

      // Create Stripe checkout session
      console.log('Making request to create checkout with plan:', stripePlanId);

      const API_BASE =
        window.location.hostname === 'localhost'
          ? 'http://localhost:3001'
          : `https://api.${window.location.hostname}`;

      const response = await fetch(`${API_BASE}/api/payments/create-checkout`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          plan: stripePlanId,
          userId: user.id || user.email,
          userEmail: user.email,
          agentId: agent.id, // Include agent ID for tracking
          successUrl: `${window.location.origin}/thank-you?agent=${agent.id}&plan=${stripePlanId}`,
          cancelUrl: `${window.location.origin}/subscribe?agent=${agent.id}&plan=${stripePlanId}&status=cancelled`,
        }),
      });

      console.log('Response status:', response.status);

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ error: 'Unknown error' }));
        console.error('Checkout error:', errorData);
        throw new Error(
          errorData.error || errorData.message || 'Failed to create checkout session'
        );
      }

      const { url } = await response.json();

      // Redirect to Stripe Checkout
      window.location.href = url;
    } catch (err: any) {
      console.error('Subscription error:', err);
      setError(err.message || 'Failed to start checkout. Please try again.');
      setIsLoading(false);
    }
  };

  return (
    <section className="py-20 md:py-28 bg-black">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <div className="inline-block w-20 h-20 flex items-center justify-center rounded-2xl bg-gray-800 mb-6 mx-auto text-cyan-400">
              {agent.icon && agent.icon.startsWith('data:image') ? (
                <img
                  src={agent.icon}
                  alt={`${agent.name} icon`}
                  className="w-full h-full object-cover rounded-2xl"
                />
              ) : (
                <i className={`${agent.icon} text-6xl`}></i>
              )}
            </div>
            <h1 className="text-3xl md:text-4xl font-bold text-white">Subscribe to {agent.name}</h1>
            <p className="max-w-2xl mx-auto mt-4 text-gray-400">
              {agent.role}: {agent.description}
            </p>
          </div>

          {error && (
            <div className="mb-8 p-4 bg-red-500/10 border border-red-500/50 rounded-lg text-red-400 text-center">
              {error}
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {AGENT_PURCHASE_PLANS.map(plan => (
              <SubscriptionCard
                key={plan.name}
                plan={plan}
                agentName={agent.name}
                isLoading={isLoading}
                onSelect={() => handleSubscribe(plan.name.toLowerCase())}
              />
            ))}
          </div>

          <div className="text-center mt-12">
            <button
              onClick={() => onNavigate('home')}
              disabled={isLoading}
              title="Return to dashboard"
              className={`transition-colors ${
                isLoading ? 'text-gray-600 cursor-not-allowed' : 'text-gray-400 hover:text-cyan-400'
              }`}
            >
              &larr; Back to dashboard
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SubscriptionPage;
