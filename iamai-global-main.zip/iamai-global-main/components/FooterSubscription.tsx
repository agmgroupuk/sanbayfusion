import React, { useState } from 'react';
import { getApiUrl } from '../config/api';

const FooterSubscription: React.FC = () => {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!email.trim()) {
      setError('Please enter your email address');
      return;
    }

    // Basic email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      setError('Please enter a valid email address');
      return;
    }

    setLoading(true);
    setError('');
    setMessage('');

    try {
      // Integrate with backend API for email subscriptions
      // Newsletter / marketing subscription uses /api/subscribe backend route
      const response = await fetch(getApiUrl('/subscribe'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email })
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || 'Failed to subscribe. Please try again.');
      }

      setSubmitted(true);
      setMessage(`✓ Welcome! Check your email (${email}) to confirm your subscription.`);
      setEmail('');

      // Reset form after 5 seconds
      setTimeout(() => {
        setSubmitted(false);
        setMessage('');
      }, 5000);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to subscribe. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubscribe} className="space-y-4">
      <div className="flex flex-col sm:flex-row gap-3">
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Enter your email"
          className="flex-1 px-4 py-3 bg-gray-800/50 border border-gray-600 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500/50 transition-all"
          disabled={loading || submitted}
        />
        <button
          type="submit"
          disabled={loading || submitted}
          className="px-6 py-3 bg-cyan-500 hover:bg-cyan-600 text-black font-semibold rounded-lg transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap hover:shadow-lg hover:shadow-cyan-500/50"
        >
          {loading ? '⏳ Subscribing...' : submitted ? '✓ Subscribed!' : '→ Subscribe'}
        </button>
      </div>

      {/* Error Message */}
      {error && (
        <div className="p-3 bg-red-500/20 border border-red-500/50 rounded-lg text-red-400 text-sm">
          ⚠️ {error}
        </div>
      )}

      {/* Success Message */}
      {message && (
        <div className="p-3 bg-green-500/20 border border-green-500/50 rounded-lg text-green-400 text-sm">
          {message}
        </div>
      )}

      {submitted && (
        <div className="text-center text-gray-400 text-sm">
          🎉 Thank you for subscribing! You'll receive updates about new features and exclusive early access.
        </div>
      )}
    </form>
  );
};

export default FooterSubscription;
