/**
 * 🔔 Notifications Component
 * Display and manage user notifications
 */

import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { useNotifications } from '../../hooks/useNotifications';
import {
  Bell,
  BellOff,
  Check,
  X,
  Filter,
  Settings,
  Trash2,
  Eye,
  EyeOff,
  Calendar,
  CheckCheck,
  AlertCircle,
  Info,
  Zap,
} from 'lucide-react';

interface NotificationsProps {
  className?: string;
}

const NotificationIcon = ({ type }: { type: string }) => {
  switch (type) {
    case 'system':
      return <AlertCircle className="w-4 h-4" />;
    case 'billing':
      return <Zap className="w-4 h-4" />;
    case 'security':
      return <Eye className="w-4 h-4" />;
    default:
      return <Info className="w-4 h-4" />;
  }
};

const Notifications: React.FC<NotificationsProps> = ({ className = '' }) => {
  const [filter, setFilter] = useState('all');
  const [showSettings, setShowSettings] = useState(false);

  const {
    notifications,
    unreadCount,
    preferences,
    loading,
    error,
    fetchNotifications,
    markAsRead,
    markAllAsRead,
    deleteNotification,
    updatePreferences,
    subscribeToNotifications,
    unsubscribeFromNotifications,
  } = useNotifications();

  useEffect(() => {
    fetchNotifications();
    // Subscribe to real-time notifications
    const unsubscribe = subscribeToNotifications();
    return () => unsubscribe();
  }, [fetchNotifications, subscribeToNotifications]);

  const filteredNotifications = notifications.filter(notification => {
    if (filter === 'unread') return !notification.read;
    if (filter !== 'all') return notification.type === filter;
    return true;
  });

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 1) return 'Just now';
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    return `${days}d ago`;
  };

  const handleMarkAsRead = async (notificationId: string) => {
    try {
      await markAsRead(notificationId);
    } catch (error) {
      console.error('Failed to mark as read:', error);
    }
  };

  const handleMarkAllAsRead = async () => {
    try {
      await markAllAsRead();
    } catch (error) {
      console.error('Failed to mark all as read:', error);
    }
  };

  const handleDelete = async (notificationId: string) => {
    try {
      await deleteNotification(notificationId);
    } catch (error) {
      console.error('Failed to delete notification:', error);
    }
  };

  const handlePreferenceToggle = async (type: string, enabled: boolean) => {
    try {
      await updatePreferences({
        ...preferences,
        [type]: { ...preferences[type], enabled },
      });
    } catch (error) {
      console.error('Failed to update preferences:', error);
    }
  };

  if (loading) {
    return (
      <div className={`flex items-center justify-center h-64 ${className}`}>
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className={`text-center py-8 ${className}`}>
        <p className="text-red-600 mb-4">{error}</p>
        <Button onClick={fetchNotifications} variant="outline">
          Try Again
        </Button>
      </div>
    );
  }

  return (
    <div className={`space-y-6 ${className}`}>
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex items-center gap-3">
          <Bell className="w-6 h-6" />
          <h2 className="text-2xl font-bold">Notifications</h2>
          {unreadCount > 0 && (
            <Badge variant="destructive" className="rounded-full">
              {unreadCount}
            </Badge>
          )}
        </div>

        <div className="flex gap-2">
          <Select value={filter} onValueChange={setFilter}>
            <SelectTrigger className="w-32">
              <Filter className="w-4 h-4 mr-2" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All</SelectItem>
              <SelectItem value="unread">Unread</SelectItem>
              <SelectItem value="system">System</SelectItem>
              <SelectItem value="billing">Billing</SelectItem>
              <SelectItem value="security">Security</SelectItem>
              <SelectItem value="feature">Features</SelectItem>
            </SelectContent>
          </Select>

          <Button variant="outline" size="sm" onClick={() => setShowSettings(!showSettings)}>
            <Settings className="w-4 h-4" />
          </Button>

          {unreadCount > 0 && (
            <Button size="sm" onClick={handleMarkAllAsRead}>
              <CheckCheck className="w-4 h-4 mr-2" />
              Mark All Read
            </Button>
          )}
        </div>
      </div>

      {/* Settings Panel */}
      {showSettings && (
        <Card>
          <CardHeader>
            <CardTitle>Notification Preferences</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {['system', 'billing', 'security', 'feature'].map(type => (
                <div key={type} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <NotificationIcon type={type} />
                    <span className="capitalize">{type} Notifications</span>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant={preferences[type]?.email ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => handlePreferenceToggle(type, !preferences[type]?.email)}
                    >
                      Email
                    </Button>
                    <Button
                      variant={preferences[type]?.push ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => handlePreferenceToggle(type, !preferences[type]?.push)}
                    >
                      Push
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Notifications List */}
      <div className="space-y-2">
        {filteredNotifications.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <BellOff className="w-12 h-12 mx-auto mb-4 text-gray-400" />
              <h3 className="text-lg font-medium mb-2">No notifications</h3>
              <p className="text-gray-500">
                {filter === 'unread' ? 'No unread notifications' : "You're all caught up!"}
              </p>
            </CardContent>
          </Card>
        ) : (
          filteredNotifications.map(notification => (
            <Card
              key={notification._id}
              className={`${!notification.read ? 'border-l-4 border-l-blue-500 bg-blue-50' : ''}`}
            >
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-2">
                      <NotificationIcon type={notification.type} />
                      <Badge
                        variant={notification.priority === 'high' ? 'destructive' : 'secondary'}
                      >
                        {notification.type}
                      </Badge>
                      {!notification.read && (
                        <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                      )}
                    </div>

                    <h4 className="font-medium mb-1">{notification.title}</h4>
                    <p className="text-gray-600 text-sm mb-2">{notification.message}</p>

                    <div className="flex items-center gap-4 text-xs text-gray-500">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        {formatTimeAgo(new Date(notification.createdAt))}
                      </span>
                      {notification.metadata?.source && (
                        <span>from {notification.metadata.source}</span>
                      )}
                    </div>

                    {notification.actionUrl && (
                      <Button
                        size="sm"
                        className="mt-2"
                        onClick={() => window.open(notification.actionUrl, '_blank')}
                      >
                        View Details
                      </Button>
                    )}
                  </div>

                  <div className="flex flex-col gap-1">
                    {!notification.read && (
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleMarkAsRead(notification._id)}
                      >
                        <Check className="w-4 h-4" />
                      </Button>
                    )}
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleDelete(notification._id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Load More */}
      {filteredNotifications.length >= 10 && (
        <div className="text-center">
          <Button
            variant="outline"
            onClick={() => fetchNotifications(filteredNotifications.length)}
          >
            Load More
          </Button>
        </div>
      )}
    </div>
  );
};

export default Notifications;
