
import React from 'react';
import { HOW_IT_WORKS_STEPS, HowItWorksStep } from '../constants';

const StepCard: React.FC<{ step: HowItWorksStep; index: number }> = ({ step, index }) => (
    <div className="relative flex flex-col items-center text-center p-6 bg-gray-900/50 border border-gray-800 rounded-2xl">
        <div className="w-16 h-16 mb-4 flex items-center justify-center rounded-full bg-cyan-900/50 border border-cyan-500/30 text-cyan-400 text-3xl">
            <i className={step.icon}></i>
        </div>
        <h3 className="text-xl font-bold text-white">{step.title}</h3>
        <p className="mt-2 text-gray-400">{step.description}</p>
    </div>
);

const HowItWorksSection: React.FC = () => {
  return (
    <section id="how-it-works" className="py-20 md:py-28 bg-black">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white">The Architecture of Intelligence</h2>
          <p className="max-w-2xl mx-auto mt-4 text-gray-400">
            A transparent look at our robust, scalable, and developer-friendly platform architecture.
          </p>
        </div>
        <div className="relative">
          <div className="hidden lg:block absolute top-1/2 left-0 w-full h-0.5 bg-gray-800 -translate-y-1/2" style={{ top: '30%' }}></div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 lg:gap-16 relative">
            {HOW_IT_WORKS_STEPS.map((step, index) => (
              <StepCard key={step.title} step={step} index={index} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorksSection;