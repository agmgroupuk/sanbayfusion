import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { requiresAuth, requiresAdmin, ROUTES } from './appRoutes';

interface AuthGuardProps {
  children: React.ReactNode;
}

interface AdminGuardProps {
  children: React.ReactNode;
}

interface GuestGuardProps {
  children: React.ReactNode;
}

// Auth Guard - Protects routes that require authentication
export const AuthGuard: React.FC<AuthGuardProps> = ({ children }) => {
  const { isAuthenticated, isLoading } = useAuth();
  const location = useLocation();

  // Show loading spinner while checking auth state
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  // Redirect to login if not authenticated and route requires auth
  if (!isAuthenticated && requiresAuth(location.pathname)) {
    return <Navigate to={ROUTES.LOGIN} state={{ from: location.pathname }} replace />;
  }

  return <>{children}</>;
};

// Admin Guard - Protects admin-only routes
export const AdminGuard: React.FC<AdminGuardProps> = ({ children }) => {
  const { user, isAuthenticated, isLoading } = useAuth();
  const location = useLocation();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  // Redirect to login if not authenticated
  if (!isAuthenticated) {
    return <Navigate to={ROUTES.LOGIN} state={{ from: location.pathname }} replace />;
  }

  // Redirect to forbidden if not admin and route requires admin
  if (requiresAdmin(location.pathname) && user?.role !== 'admin') {
    return <Navigate to={ROUTES.FORBIDDEN} replace />;
  }

  return <>{children}</>;
};

// Guest Guard - Protects routes that should only be accessed by non-authenticated users
export const GuestGuard: React.FC<GuestGuardProps> = ({ children }) => {
  const { isAuthenticated, isLoading } = useAuth();
  const location = useLocation();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  // Redirect to dashboard if authenticated and trying to access guest-only routes
  if (isAuthenticated && [ROUTES.LOGIN, ROUTES.REGISTER].includes(location.pathname as any)) {
    const from = (location.state as any)?.from || ROUTES.DASHBOARD;
    return <Navigate to={from} replace />;
  }

  return <>{children}</>;
};

// Route Permission Checker
export const useRoutePermissions = () => {
  const { user, isAuthenticated } = useAuth();
  const location = useLocation();

  const canAccess = (path: string): boolean => {
    // Public routes are always accessible
    if (!requiresAuth(path)) {
      return true;
    }

    // Authenticated routes require user to be logged in
    if (!isAuthenticated) {
      return false;
    }

    // Admin routes require admin role
    if (requiresAdmin(path)) {
      return user?.role === 'admin';
    }

    return true;
  };

  const getCurrentPermissions = () => {
    return {
      canAccess: canAccess(location.pathname),
      requiresAuth: requiresAuth(location.pathname),
      requiresAdmin: requiresAdmin(location.pathname),
      isAuthenticated,
      isAdmin: user?.role === 'admin',
    };
  };

  return {
    canAccess,
    getCurrentPermissions,
  };
};
