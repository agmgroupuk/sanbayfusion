export interface LoginFormState {
  email: string;
  password: string;
  rememberMe: boolean;
  isLoading: boolean;
  errors: LoginFormErrors;
  showPassword: boolean;
}

export interface LoginFormErrors {
  email?: string;
  password?: string;
  general?: string;
}

export interface LoginFormOptions {
  enableRememberMe: boolean;
  enableSocialLogin: boolean;
  minPasswordLength: number;
}

export class LoginFormService {
  private listeners: Set<(state: LoginFormState) => void> = new Set();
  private state: LoginFormState;
  private options: LoginFormOptions;

  constructor(options: LoginFormOptions) {
    this.options = options;
    this.state = {
      email: '',
      password: '',
      rememberMe: false,
      isLoading: false,
      errors: {},
      showPassword: false,
    };

    this.loadRememberedCredentials();
  }

  private loadRememberedCredentials(): void {
    try {
      const remembered = localStorage.getItem('remember_me_email');
      if (remembered) {
        this.updateState({
          ...this.state,
          email: remembered,
          rememberMe: true,
        });
      }
    } catch (error) {
      console.error('Failed to load remembered credentials:', error);
    }
  }

  setEmail(email: string): void {
    this.updateState({
      ...this.state,
      email,
      errors: { ...this.state.errors, email: undefined, general: undefined },
    });
  }

  setPassword(password: string): void {
    this.updateState({
      ...this.state,
      password,
      errors: { ...this.state.errors, password: undefined, general: undefined },
    });
  }

  setRememberMe(rememberMe: boolean): void {
    this.updateState({ ...this.state, rememberMe });
  }

  togglePasswordVisibility(): void {
    this.updateState({ ...this.state, showPassword: !this.state.showPassword });
  }

  validateForm(): boolean {
    const errors: LoginFormErrors = {};

    // Email validation
    if (!this.state.email.trim()) {
      errors.email = 'Email is required';
    } else if (!this.isValidEmail(this.state.email)) {
      errors.email = 'Please enter a valid email address';
    }

    // Password validation
    if (!this.state.password) {
      errors.password = 'Password is required';
    } else if (this.state.password.length < this.options.minPasswordLength) {
      errors.password = `Password must be at least ${this.options.minPasswordLength} characters`;
    }

    this.updateState({ ...this.state, errors });
    return Object.keys(errors).length === 0;
  }

  private isValidEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  async submitLogin(): Promise<{ success: boolean; data?: any; error?: string }> {
    if (!this.validateForm()) {
      return { success: false, error: 'Please fix the form errors' };
    }

    this.updateState({ ...this.state, isLoading: true, errors: {} });

    try {
      // This would typically call an authentication service
      const response = await this.performLogin(this.state.email, this.state.password);

      if (response.success) {
        // Handle remember me
        if (this.state.rememberMe) {
          localStorage.setItem('remember_me_email', this.state.email);
        } else {
          localStorage.removeItem('remember_me_email');
        }

        this.updateState({ ...this.state, isLoading: false });
        return response;
      } else {
        this.updateState({
          ...this.state,
          isLoading: false,
          errors: { general: response.error || 'Login failed' },
        });
        return response;
      }
    } catch (error) {
      console.error('Login error:', error);
      this.updateState({
        ...this.state,
        isLoading: false,
        errors: { general: 'An unexpected error occurred' },
      });
      return { success: false, error: 'An unexpected error occurred' };
    }
  }

  private async performLogin(
    email: string,
    password: string
  ): Promise<{ success: boolean; data?: any; error?: string }> {
    // Mock API call - replace with actual authentication service
    return new Promise(resolve => {
      setTimeout(() => {
        // Mock successful login for demo
        if (email && password) {
          resolve({
            success: true,
            data: {
              user: { email, name: 'Demo User' },
              token: 'mock_jwt_token',
            },
          });
        } else {
          resolve({
            success: false,
            error: 'Invalid email or password',
          });
        }
      }, 1500);
    });
  }

  async loginWithProvider(
    provider: 'google' | 'github' | 'apple'
  ): Promise<{ success: boolean; data?: any; error?: string }> {
    this.updateState({ ...this.state, isLoading: true, errors: {} });

    try {
      // Mock social login
      const response = await this.performSocialLogin(provider);
      this.updateState({ ...this.state, isLoading: false });
      return response;
    } catch (error) {
      console.error(`${provider} login error:`, error);
      this.updateState({
        ...this.state,
        isLoading: false,
        errors: { general: `${provider} login failed` },
      });
      return { success: false, error: `${provider} login failed` };
    }
  }

  private async performSocialLogin(
    provider: string
  ): Promise<{ success: boolean; data?: any; error?: string }> {
    // Mock social login - replace with actual OAuth implementation
    return new Promise(resolve => {
      setTimeout(() => {
        resolve({
          success: true,
          data: {
            user: { email: `user@${provider}.com`, name: `${provider} User` },
            token: `mock_${provider}_token`,
          },
        });
      }, 2000);
    });
  }

  clearForm(): void {
    this.updateState({
      ...this.state,
      email: this.state.rememberMe ? this.state.email : '',
      password: '',
      errors: {},
      showPassword: false,
    });
  }

  setError(error: string): void {
    this.updateState({
      ...this.state,
      errors: { general: error },
      isLoading: false,
    });
  }

  clearErrors(): void {
    this.updateState({ ...this.state, errors: {} });
  }

  getState(): LoginFormState {
    return { ...this.state };
  }

  subscribe(listener: (state: LoginFormState) => void): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private updateState(newState: LoginFormState): void {
    this.state = newState;
    this.listeners.forEach(listener => listener(this.state));
  }

  destroy(): void {
    this.listeners.clear();
  }
}
