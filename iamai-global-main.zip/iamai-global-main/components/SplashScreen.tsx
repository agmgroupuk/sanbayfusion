import React, { useEffect, useState } from 'react';
import './SplashScreen.css';

interface SplashScreenProps {
  onFinished: () => void;
  minDisplayTime?: number; // minimum time to show splash in milliseconds
}

const SplashScreen: React.FC<SplashScreenProps> = ({ 
  onFinished, 
  minDisplayTime = 2000 // default to 2 seconds minimum display
}) => {
  const [canDismiss, setCanDismiss] = useState(false);
  const [logoLoaded, setLogoLoaded] = useState(false);

  useEffect(() => {
    // Preload the logo image
    const logoImage = new Image();
    logoImage.src = "/assets/iamai-logo.png";
    logoImage.onload = () => setLogoLoaded(true);
    
    // Ensure the splash screen shows for at least minDisplayTime
    const timer = setTimeout(() => {
      setCanDismiss(true);
    }, minDisplayTime);

    return () => clearTimeout(timer);
  }, [minDisplayTime]);

  // Call onFinished when animation ends and minimum display time has passed
  const handleAnimationEnd = () => {
    if (canDismiss && logoLoaded) {
      onFinished();
    }
  };

  return (
    <div className="splash-screen" onAnimationEnd={handleAnimationEnd}>
      <div className="splash-content">
        <img 
          src="/assets/iamai-logo.png" 
          alt="IA M AI Logo" 
          className="splash-logo"
          onLoad={() => setLogoLoaded(true)}
        />
        <h1 className="splash-title">IA M AI</h1>
        <p className="splash-tagline">Powered By AI Digital Friend Zone</p>
        <div className="splash-loader">
          <div className="splash-loader-bar"></div>
        </div>
      </div>
    </div>
  );
};

export default SplashScreen;