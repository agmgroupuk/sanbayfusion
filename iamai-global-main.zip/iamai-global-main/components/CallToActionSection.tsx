

import React from 'react';
import { Page } from '../App';

interface CallToActionSectionProps {
  onNavigate: (page: Page) => void;
}

const CallToActionSection: React.FC<CallToActionSectionProps> = ({ onNavigate }) => {
  return (
    <section className="py-20 md:py-28 bg-black">
      <div className="container mx-auto px-6">
        <div className="bg-gradient-to-r from-cyan-500 to-purple-500 rounded-2xl p-10 md:p-16 text-center">
            <h2 className="text-3xl md:text-4xl font-bold text-black">Ready to Build with IA M AI?</h2>
            <p className="max-w-2xl mx-auto mt-4 text-gray-800">
                Join the platform and start building with character-driven AI agents today.
                Sign up for free, no credit card required.
            </p>
            <div className="mt-8">
                <button
                    onClick={() => onNavigate('signup')}
                    title="Sign up for a free account"
                    className="bg-black text-white font-semibold px-8 py-3 rounded-full hover:bg-gray-800 transition-all duration-300 transform hover:scale-105"
                >
                    Get Started Now
                </button>
            </div>
        </div>
      </div>
    </section>
  );
};

export default CallToActionSection;