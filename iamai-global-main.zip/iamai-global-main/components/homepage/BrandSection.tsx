import React from 'react';
import { BRANDS } from '../../constants';

const BrandSection: React.FC = () => (
  <div className="py-16 bg-black">
    <div className="container mx-auto px-6">
      <div className="text-center">
        <p className="text-sm font-semibold text-gray-400 uppercase tracking-wider">Trusted by the world's best companies</p>
        <div className="mt-8 flex flex-wrap justify-center items-center gap-x-8 gap-y-6 md:gap-x-16">
          {BRANDS.map(brand => (
            <img key={brand.name} src={brand.logoUrl} alt={brand.name} className="h-8 md:h-9 object-contain grayscale opacity-60 hover:opacity-100 hover:grayscale-0 transition-all duration-300" />
          ))}
        </div>
      </div>
    </div>
  </div>
);

export default BrandSection;
