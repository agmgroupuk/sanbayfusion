import React from 'react';
import { ALL_AGENTS } from '../../agents';
import { Agent } from '../../constants';
import type { Page } from '../../App';

interface FeaturedAgentCardProps {
  agent: Agent;
  onNavigate: (page: Page) => void;
}

const FeaturedAgentCard: React.FC<FeaturedAgentCardProps> = ({ agent, onNavigate }) => (
  <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6 flex flex-col items-start space-y-4 hover:border-cyan-500/50 hover:bg-gray-900 transition-all duration-300 transform hover:-translate-y-1">
    <div className="w-12 h-12 flex items-center justify-center rounded-lg bg-gray-800 text-cyan-400">
      {agent.icon && agent.icon.startsWith('data:image') ? (
        <img src={agent.icon} alt={`${agent.name} icon`} className="w-full h-full object-cover rounded-lg" />
      ) : (
        <i className={`${agent.icon} text-3xl`}></i>
      )}
    </div>
    <h3 className="text-xl font-bold text-white">{agent.name}</h3>
    <p className="text-cyan-400 text-sm font-medium">{agent.role}</p>
    <p className="text-gray-400 flex-grow">{agent.description}</p>
    
    {/* Action Buttons */}
    <div className="mt-auto w-full flex gap-3 pt-2">
      <button 
        onClick={() => onNavigate('documentation')} 
        title="View documentation"
        className="flex-1 text-cyan-400 font-semibold hover:text-cyan-300 transition-colors px-4 py-2 rounded-lg border border-gray-700 hover:border-cyan-500/50 text-sm"
      >
        📚 Docs
      </button>
      <button 
        onClick={() => onNavigate('tutorials')} 
        title="View tutorials"
        className="flex-1 text-cyan-400 font-semibold hover:text-cyan-300 transition-colors px-4 py-2 rounded-lg border border-gray-700 hover:border-cyan-500/50 text-sm"
      >
        🎓 Tutorials
      </button>
    </div>
  </div>
);

interface FeaturedAgentSectionProps {
  onNavigate: (page: Page) => void;
}

const FeaturedAgentSection: React.FC<FeaturedAgentSectionProps> = ({ onNavigate }) => {
  return (
    <section id="featured-agents" className="py-20 md:py-28 bg-black">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-white">Meet Your Power Players</h2>
          <p className="max-w-2xl mx-auto mt-4 text-gray-400">
            Get a closer look at our most popular agents designed to tackle specific, high-impact tasks.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {ALL_AGENTS.map((agent) => (
            <FeaturedAgentCard key={agent.name} agent={agent} onNavigate={onNavigate} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturedAgentSection;