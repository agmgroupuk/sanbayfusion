import React from 'react';
import { TEMPLATES, Template } from '../../constants';
import { Page } from '../../App';

interface TemplateCardProps {
  template: Template;
  onNavigate: (page: Page) => void;
}

const TemplateCard: React.FC<TemplateCardProps> = ({ template, onNavigate }) => {
  const handleClick = () => {
    const templatePage = `template-${template.id}` as Page;
    onNavigate(templatePage);
  };

  return (
    <div 
      onClick={handleClick}
      className="bg-gray-900/50 p-6 rounded-lg text-center border border-gray-800 hover:border-cyan-500/30 transition-colors duration-300 transform hover:-translate-y-1 cursor-pointer"
    >
        <i className={`${template.icon} text-3xl text-cyan-400`}></i>
        <h3 className="mt-4 font-semibold text-white">{template.name}</h3>
        <p className="mt-2 text-sm text-gray-400">{template.description}</p>
    </div>
  );
};

interface TemplatesSectionProps {
    onNavigate: (page: Page) => void;
}

const TemplatesSection: React.FC<TemplatesSectionProps> = ({ onNavigate }) => {
  return (
    <section id="templates" className="py-20 md:py-28 bg-black">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-white">Start with a Template</h2>
          <p className="max-w-2xl mx-auto mt-4 text-gray-400">
            Jumpstart your project with pre-built agent templates for common use cases.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {TEMPLATES.map((template) => (
            <TemplateCard key={template.name} template={template} onNavigate={onNavigate} />
          ))}
        </div>
        <div className="text-center mt-12">
            <button onClick={() => onNavigate('templates')} title="Explore all available agent templates" className="text-cyan-400 font-semibold hover:text-cyan-300 transition-colors">
                Explore all templates &rarr;
            </button>
        </div>
      </div>
    </section>
  );
};

export default TemplatesSection;