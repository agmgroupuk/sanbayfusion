import React, { useState, useEffect } from 'react';
import { ALL_AGENTS } from '../../agents';

// Enhanced color scheme for different message types
const getStatusColor = (status: string) => {
  switch (status) {
    case 'INITIATING': return 'text-blue-400';
    case 'STATUS': return 'text-purple-400';
    case 'AUTHENTICATING': return 'text-yellow-400';
    case 'CONNECTING': return 'text-orange-400';
    case 'SUCCESS': return 'text-green-400';
    case 'COMPLETE': return 'text-cyan-400';
    default: return 'text-gray-300';
  }
};

// Generate activation sequence for all agents
const generateActivationScript = () => {
  const script: Array<{ type: 'prompt' | 'output'; text: string; status?: string }> = [
    { type: 'prompt', text: 'iamai@terminal$iamai --activate-all-agents' },
    { type: 'output', text: '[INITIATING] IA M AI Agent Activation System...', status: 'INITIATING' },
    { type: 'output', text: '[STATUS] System ready. Beginning multi-agent initialization sequence.', status: 'STATUS' },
  ];

  // Add activation sequence for each agent
  ALL_AGENTS.forEach((agent, index) => {
    script.push(
      { type: 'output', text: `\n[${index + 1}/${ALL_AGENTS.length}] Initiating ${agent.name}...`, status: 'INITIATING' },
      { type: 'output', text: `[AUTHENTICATING] ${agent.name} - Verifying credentials...`, status: 'AUTHENTICATING' },
      { type: 'output', text: `[CONNECTING] ${agent.name} - Establishing secure connection...`, status: 'CONNECTING' },
      { type: 'output', text: `✓ [SUCCESS] ${agent.name} activated successfully. Role: ${agent.role}`, status: 'SUCCESS' }
    );
  });

  script.push(
    { type: 'output', text: '\n[COMPLETE] All agents activated and ready for deployment.', status: 'COMPLETE' },
    { type: 'output', text: '[STATUS] Multi-agent system fully operational.', status: 'SUCCESS' }
  );

  return script;
};

const SCRIPT = generateActivationScript();

const TerminalPrompt: React.FC = () => (
    <span className="shrink-0 flex items-center">
        <span className="text-cyan-400 font-bold animate-pulse">iamai</span>
        <span className="text-gray-500">@</span>
        <span className="text-purple-400 font-bold">terminal</span>
        <span className="text-gray-500">$</span>
        <span className="ml-1"></span>
    </span>
);

const TerminalSection: React.FC = () => {
    const [lines, setLines] = useState<(typeof SCRIPT[0])[]>([]);
    const [currentLineIndex, setCurrentLineIndex] = useState(0);
    const [currentText, setCurrentText] = useState('');
    const terminalContentRef = React.useRef<HTMLDivElement>(null);

    // Auto-scroll to bottom when new content is added
    useEffect(() => {
        if (terminalContentRef.current) {
            terminalContentRef.current.scrollTop = terminalContentRef.current.scrollHeight;
        }
    }, [lines, currentText]);

    useEffect(() => {
        if (currentLineIndex >= SCRIPT.length) {
            setTimeout(() => {
                setLines([]);
                setCurrentLineIndex(0);
                setCurrentText('');
            }, 3000);
            return;
        };

        const currentLine = SCRIPT[currentLineIndex];
        const isPrompt = currentLine.type === 'prompt';
        const delay = isPrompt ? 50 : 25;

        const typingInterval = setInterval(() => {
            setCurrentText(prev => {
                if (prev.length < currentLine.text.length) {
                    return currentLine.text.slice(0, prev.length + 1);
                } else {
                    clearInterval(typingInterval);
                    setLines(prevLines => [...prevLines, currentLine]);
                    setCurrentText('');
                    setTimeout(() => setCurrentLineIndex(prev => prev + 1), isPrompt ? 800 : 300);
                    return prev;
                }
            });
        }, delay);

        return () => clearInterval(typingInterval);
    }, [currentLineIndex]);
    
    return (
        <section className="py-12 md:py-16 bg-black relative overflow-hidden">
            {/* Enhanced Background Effects */}
            <div className="absolute inset-0 bg-grid-gray-900 [mask-image:linear-gradient(to_bottom,transparent,white_50%,white_50%,transparent)]"></div>
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[400px] bg-gradient-to-r from-cyan-500/10 via-purple-500/10 to-pink-500/10 rounded-full blur-3xl animate-pulse"></div>
            <div className="absolute top-1/4 left-1/4 w-[300px] h-[300px] bg-cyan-500/5 rounded-full blur-2xl animate-pulse" style={{ animationDelay: '1s' }}></div>
            <div className="absolute bottom-1/4 right-1/4 w-[300px] h-[300px] bg-purple-500/5 rounded-full blur-2xl animate-pulse" style={{ animationDelay: '2s' }}></div>

            <div className="container mx-auto px-6 relative z-10">
                <div className="max-w-5xl mx-auto">
                    {/* Enhanced Header */}
                    <div className="text-center mb-6">
                        <div className="inline-flex items-center justify-center p-2.5 bg-gradient-to-br from-cyan-500/20 to-purple-500/20 rounded-2xl border border-cyan-500/30 mb-3 backdrop-blur-sm">
                            <svg className="w-6 h-6 text-cyan-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 9l3 3-3 3m5 0h3M5 20h14a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                            </svg>
                        </div>
                        <h2 className="text-3xl md:text-4xl font-extrabold mb-2 bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400">
                            IA M AI Terminal
                        </h2>
                        <p className="text-gray-400 text-base">Watch all agents activate in real-time</p>
                    </div>

                    {/* Enhanced Terminal Window */}
                    <div className="relative">
                        {/* Glow Effect */}
                        <div className="absolute -inset-0.5 bg-gradient-to-r from-cyan-500 via-purple-500 to-pink-500 rounded-xl opacity-20 blur animate-pulse"></div>
                        
                        <div className="relative bg-gradient-to-br from-gray-900 to-black border border-gray-800 rounded-xl shadow-2xl shadow-cyan-500/20 overflow-hidden">
                            {/* Terminal Header */}
                            <div className="flex items-center justify-between px-5 py-3 border-b border-gray-700/50 bg-gradient-to-r from-gray-900/95 via-gray-800/95 to-gray-900/95 backdrop-blur-sm">
                                <div className="flex space-x-2.5">
                                    <div className="w-3 h-3 bg-red-500 rounded-full shadow-lg shadow-red-500/50 hover:shadow-red-500/80 transition-shadow cursor-pointer"></div>
                                    <div className="w-3 h-3 bg-yellow-500 rounded-full shadow-lg shadow-yellow-500/50 hover:shadow-yellow-500/80 transition-shadow cursor-pointer"></div>
                                    <div className="w-3 h-3 bg-green-500 rounded-full shadow-lg shadow-green-500/50 hover:shadow-green-500/80 transition-shadow cursor-pointer"></div>
                                </div>
                                <div className="flex items-center space-x-2">
                                    <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse shadow-lg shadow-green-400/50"></div>
                                    <p className="text-xs text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-400 font-mono font-bold tracking-wide">
                                        IA M AI Multi-Agent Activation
                                    </p>
                                </div>
                                <div className="flex space-x-2 opacity-50">
                                    <div className="w-4 h-1 bg-gray-600 rounded"></div>
                                    <div className="w-4 h-4 border border-gray-600 rounded"></div>
                                    <div className="w-4 h-4 bg-gray-600 rounded"></div>
                                </div>
                            </div>
                            
                            {/* Terminal Content */}
                            <div 
                                ref={terminalContentRef}
                                className="p-6 font-mono text-sm h-[400px] overflow-y-auto bg-[#0a0e14] scrollbar-thin scrollbar-thumb-cyan-900/50 scrollbar-track-gray-900/50 hover:scrollbar-thumb-cyan-700/70 transition-colors"
                            >
                                {lines.map((line, index) => (
                                    <div key={index} className="flex items-start mb-1.5 group animate-fadeIn">
                                        {line.type === 'prompt' && <TerminalPrompt />}
                                        <p className={`flex-1 whitespace-pre-wrap ${line.status ? getStatusColor(line.status) : 'text-gray-300'} group-hover:translate-x-1 transition-transform`}>
                                            {line.text}
                                        </p>
                                    </div>
                                ))}
                                <div className="flex items-start">
                                    {SCRIPT[currentLineIndex]?.type === 'prompt' && <TerminalPrompt />}
                                    <p className={`flex-1 whitespace-pre-wrap ${SCRIPT[currentLineIndex]?.status ? getStatusColor(SCRIPT[currentLineIndex].status!) : 'text-gray-300'}`}>
                                        {currentText}
                                        <span className="inline-block w-2 h-4 ml-1 bg-gradient-to-r from-cyan-400 to-purple-400 animate-pulse shadow-lg shadow-cyan-400/50"></span>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default TerminalSection;