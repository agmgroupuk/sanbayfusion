import React, { useState } from 'react';
import { FAQS, FAQItem } from '../../constants';

interface FAQCardProps {
  item: FAQItem;
  isOpen: boolean;
  onClick: () => void;
}

const FAQCard: React.FC<FAQCardProps> = ({ item, isOpen, onClick }) => {
  return (
    <div className="border-b border-gray-800">
      <button
        onClick={onClick}
        className="w-full flex justify-between items-center text-left py-6"
      >
        <span className="text-lg font-medium text-white">{item.question}</span>
        <span className={`transform transition-transform duration-300 ${isOpen ? 'rotate-45' : 'rotate-0'}`}>
          <i className="fa-solid fa-plus text-cyan-400"></i>
        </span>
      </button>
      <div
        className={`grid transition-all duration-500 ease-in-out ${isOpen ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'}`}
      >
        <div className="overflow-hidden">
          <p className="pb-6 text-gray-400">
            {item.answer}
          </p>
        </div>
      </div>
    </div>
  );
};

interface FAQSectionProps {
  onNavigate: () => void;
}

const FAQSection: React.FC<FAQSectionProps> = ({ onNavigate }) => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const handleClick = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section id="faq" className="py-20 md:py-28 bg-[#0a0a0a]">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-white">Frequently Asked Questions</h2>
          <p className="max-w-2xl mx-auto mt-4 text-gray-400">
            Have questions? We've got answers. If you can't find what you're looking for, feel free to contact us.
          </p>
        </div>
        <div className="max-w-3xl mx-auto">
          {FAQS.slice(0, 5).map((faq, index) => (
            <FAQCard
              key={index}
              item={faq}
              isOpen={openIndex === index}
              onClick={() => handleClick(index)}
            />
          ))}
        </div>
        <div className="text-center mt-12">
            <button onClick={onNavigate} title="View all frequently asked questions" className="text-cyan-400 font-semibold hover:text-cyan-300 transition-colors">
                See all FAQs &rarr;
            </button>
        </div>
      </div>
    </section>
  );
};

export default FAQSection;