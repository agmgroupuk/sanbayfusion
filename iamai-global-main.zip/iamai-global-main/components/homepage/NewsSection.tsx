import React from 'react';
import type { Page } from '../../App';

interface CustomCardProps {
  title: string;
  description: string;
  icon: string;
  buttonText: string;
  onNavigate: (page: Page) => void;
  navigateTo: Page;
}

const CustomCard: React.FC<CustomCardProps> = ({ title, description, icon, buttonText, onNavigate, navigateTo }) => (
  <div className="bg-gray-900/50 border border-gray-800 rounded-2xl overflow-hidden flex flex-col group hover:border-cyan-500/50 transition-all duration-300 transform hover:-translate-y-1">
    {/* Icon Header */}
    <div className="p-8 bg-gradient-to-br from-gray-800/50 to-gray-900/50 flex items-center justify-center h-40">
      <span className="text-6xl">{icon}</span>
    </div>

    {/* Content */}
    <div className="p-6 flex flex-col flex-grow">
      <h3 className="text-2xl font-bold text-white">{title}</h3>
      <p className="mt-4 text-gray-400 flex-grow leading-relaxed">{description}</p>

      {/* Button */}
      <button 
        onClick={() => onNavigate(navigateTo)} 
        title={buttonText}
        className="mt-6 bg-cyan-500 hover:bg-cyan-600 text-black font-semibold px-6 py-3 rounded-lg transition-all duration-300 transform hover:scale-105 flex items-center justify-center group-hover:shadow-lg group-hover:shadow-cyan-500/50"
      >
        {buttonText} <span className="ml-2 transform group-hover:translate-x-1 transition-transform">&rarr;</span>
      </button>
    </div>
  </div>
);

interface NewsSectionProps {
  onNavigate: (page: Page) => void;
}

const NewsSection: React.FC<NewsSectionProps> = ({ onNavigate }) => {
  return (
    <section id="news" className="py-20 md:py-28 bg-black">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-white">Latest Updates & News</h2>
          <p className="max-w-2xl mx-auto mt-4 text-gray-400">
            Explore our insights on AI and stay up-to-date with the latest developments.
          </p>
        </div>

        {/* Two Card Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {/* AI History Card */}
          <CustomCard
            icon="📚"
            title="AI History from 1936 to 2025"
            description="Discover the fascinating evolution of artificial intelligence over nearly a century. From Turing's groundbreaking theory to modern multi-agent systems, explore the milestones that shaped the AI revolution and where we're headed next."
            buttonText="Explore Blog"
            onNavigate={onNavigate}
            navigateTo="blog"
          />

          {/* Updates & News Card */}
          <CustomCard
            icon="📰"
            title="Latest Updates & News"
            description="Stay informed with the latest developments in AI technology. Get real-time updates on product releases, industry news, breakthrough discoveries, and insights from our team about the future of intelligent agents."
            buttonText="View News"
            onNavigate={onNavigate}
            navigateTo="news"
          />
        </div>
      </div>
    </section>
  );
};

export default NewsSection;