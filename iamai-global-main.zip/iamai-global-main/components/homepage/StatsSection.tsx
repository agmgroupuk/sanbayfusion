import React from 'react';
import { STATS } from '../../constants';

const StatsSection: React.FC = () => {
  return (
    <section className="py-20 md:py-28 bg-[#0a0a0a]">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          {STATS.map(stat => (
            <div key={stat.label} className="p-4">
              <p className="text-4xl md:text-5xl font-bold text-cyan-400">{stat.value}</p>
              <p className="mt-2 text-sm md:text-base text-gray-400 uppercase tracking-wider">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default StatsSection;
