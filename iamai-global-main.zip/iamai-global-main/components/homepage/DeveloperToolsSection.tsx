import React from 'react';
import './DeveloperToolsSection.css';

interface Tool {
  name: string;
  icon: string;
  color: string;
}

const DeveloperToolsSection: React.FC = () => {
  const tools: Tool[] = [
    { name: 'Python', icon: '🐍', color: '#3776ab' },
    { name: 'Node.js', icon: '⬢', color: '#339933' },
    { name: 'TypeScript', icon: 'TS', color: '#3178c6' },
    { name: 'React', icon: '⚛️', color: '#61dafb' },
    { name: 'Next.js', icon: '▲', color: '#000000' },
    { name: 'AWS', icon: '☁️', color: '#ff9900' },
    { name: 'GitHub', icon: '🐙', color: '#333333' },
    { name: 'Git', icon: '🌳', color: '#f34f29' },
    { name: 'PostgreSQL', icon: '🐘', color: '#336791' },
    { name: 'MongoDB', icon: '🍃', color: '#13aa52' },
    { name: 'Redis', icon: '💾', color: '#dc382d' },
    { name: 'GraphQL', icon: '◈', color: '#e10098' },
    { name: 'REST API', icon: '🔌', color: '#00a4ef' },
    { name: 'AWS', icon: '☁️', color: '#ff9900' },
    { name: 'Vercel', icon: '▼', color: '#000000' },
    { name: 'Vite', icon: '⚡', color: '#646cff' },
    { name: 'Tailwind CSS', icon: '🎨', color: '#06b6d4' },
    { name: 'Webpack', icon: '📦', color: '#8dd6f3' },
    { name: 'Jest', icon: '🃏', color: '#15c213' },
    { name: 'ESLint', icon: '✓', color: '#4b32c3' },
  ];

  return (
    <section className="relative overflow-hidden bg-black py-16">
      {/* Background elements */}
      <div className="absolute inset-0 bg-grid-gray-900 [mask-image:linear-gradient(to_right,transparent,white,transparent)]"></div>
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[400px] bg-cyan-500/5 rounded-full blur-3xl"></div>

      <div className="relative z-10">
        <div className="text-center mb-12 px-6">
          <p className="text-sm font-semibold text-cyan-400 uppercase tracking-wider">Powered by Modern Developer Stack</p>
          <p className="mt-2 text-gray-400 text-lg">Built with the tools developers love</p>
        </div>

        {/* Scrolling Container */}
        <div className="relative overflow-hidden">
          {/* Left gradient fade */}
          <div className="absolute left-0 top-0 bottom-0 w-32 bg-gradient-to-r from-black via-transparent to-transparent z-20 pointer-events-none"></div>
          
          {/* Right gradient fade */}
          <div className="absolute right-0 top-0 bottom-0 w-32 bg-gradient-to-l from-black via-transparent to-transparent z-20 pointer-events-none"></div>

          {/* Scrolling Content */}
          <div className="developer-tools-scroll">
            {/* First set of tools */}
            {tools.map((tool, index) => (
              <div key={`tool-${index}`} className="developer-tool">
                <div className="flex flex-col items-center justify-center h-24">
                  <div className="text-4xl mb-2">{tool.icon}</div>
                  <p className="text-xs font-semibold text-gray-300 whitespace-nowrap">{tool.name}</p>
                </div>
              </div>
            ))}

            {/* Duplicate set for seamless loop */}
            {tools.map((tool, index) => (
              <div key={`tool-duplicate-${index}`} className="developer-tool">
                <div className="flex flex-col items-center justify-center h-24">
                  <div className="text-4xl mb-2">{tool.icon}</div>
                  <p className="text-xs font-semibold text-gray-300 whitespace-nowrap">{tool.name}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default DeveloperToolsSection;
