import React from 'react';
import type { Page } from '../../App';

interface DatabasePopulateSectionProps {
  onNavigate: (page: Page) => void;
}

const DatabasePopulateSection: React.FC<DatabasePopulateSectionProps> = ({ onNavigate }) => {
  return (
    <section className="py-20 bg-gradient-to-br from-gray-900 via-black to-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Database Population Service
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto mb-8">
            Generate realistic sample data for your databases instantly. Perfect for testing,
            development, and populating demo environments with authentic-looking data.
          </p>
          <button
            onClick={() => onNavigate('database-populate')}
            className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white font-semibold py-4 px-8 rounded-lg text-lg transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl"
          >
            Start Populating →
          </button>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-12">
          <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl p-6 border border-gray-700 hover:border-green-500/50 transition-all duration-300">
            <div className="w-12 h-12 bg-green-500/20 rounded-lg flex items-center justify-center mb-4">
              <svg className="w-6 h-6 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4" />
              </svg>
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">Multiple Templates</h3>
            <p className="text-gray-400">
              Choose from pre-built templates for users, products, blog posts, analytics, and more.
            </p>
          </div>

          <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl p-6 border border-gray-700 hover:border-green-500/50 transition-all duration-300">
            <div className="w-12 h-12 bg-green-500/20 rounded-lg flex items-center justify-center mb-4">
              <svg className="w-6 h-6 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">Custom Schemas</h3>
            <p className="text-gray-400">
              Define your own data structures with JSON schemas for complete customization.
            </p>
          </div>

          <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl p-6 border border-gray-700 hover:border-green-500/50 transition-all duration-300">
            <div className="w-12 h-12 bg-green-500/20 rounded-lg flex items-center justify-center mb-4">
              <svg className="w-6 h-6 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">Export Ready</h3>
            <p className="text-gray-400">
              Export generated data in JSON format, ready to import into any database system.
            </p>
          </div>
        </div>

        <div className="text-center">
          <p className="text-gray-400 mb-6">
            Need sample data for your next project?
          </p>
          <button
            onClick={() => onNavigate('database-populate')}
            className="bg-transparent border-2 border-green-500 text-green-400 hover:bg-green-500 hover:text-white font-semibold py-3 px-6 rounded-lg transition-all duration-300"
          >
            Try Database Population
          </button>
        </div>
      </div>
    </section>
  );
};

export default DatabasePopulateSection;