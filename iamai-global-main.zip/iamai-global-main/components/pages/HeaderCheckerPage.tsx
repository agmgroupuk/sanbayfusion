import React, { useState, useEffect } from 'react';
import { ArrowLeft, Eye, Search, Shield, AlertTriangle, CheckCircle, XCircle, Info, Lock, Zap, Globe, Code, TrendingUp, Download, Copy, Check, Clock, AlertCircle } from 'lucide-react';

interface Props { onNavigate?: (page: string) => void }

interface SecurityHeader {
  name: string;
  value?: string;
  present: boolean;
  score: number;
  maxScore: number;
  severity: 'critical' | 'high' | 'medium' | 'low';
  description: string;
  recommendation?: string;
}

interface HeaderResult {
  headers: Record<string, string>;
  statusCode: number;
  url: string;
  redirectChain?: string[];
  securityHeaders: SecurityHeader[];
  securityScore: number;
  corsEnabled: boolean;
  cspPresent: boolean;
  hstsPresent: boolean;
}

interface HistoryEntry {
  id: string;
  url: string;
  timestamp: string;
  securityScore: number;
  statusCode: number;
  issues: number;
}

const HeaderCheckerPage: React.FC<Props> = ({ onNavigate }) => {
  const [url, setUrl] = useState('https://github.com');
  const [method, setMethod] = useState<'HEAD'|'GET'>('HEAD');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<HeaderResult | null>(null);
  const [error, setError] = useState('');
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'overview' | 'security' | 'cors' | 'performance'>('overview');

  useEffect(() => {
    const savedHistory = localStorage.getItem('headerCheckHistory');
    if (savedHistory) {
      try {
        setHistory(JSON.parse(savedHistory));
      } catch (e) {
        console.error('Failed to load history:', e);
      }
    }
  }, []);

  const analyzeSecurityHeaders = (headers: Record<string, string>): SecurityHeader[] => {
    const securityHeaders: SecurityHeader[] = [
      {
        name: 'Strict-Transport-Security',
        value: headers['strict-transport-security'],
        present: !!headers['strict-transport-security'],
        score: headers['strict-transport-security'] ? 15 : 0,
        maxScore: 15,
        severity: 'critical',
        description: 'Forces HTTPS connections',
        recommendation: 'Add: Strict-Transport-Security: max-age=31536000; includeSubDomains'
      },
      {
        name: 'Content-Security-Policy',
        value: headers['content-security-policy'],
        present: !!headers['content-security-policy'],
        score: headers['content-security-policy'] ? 15 : 0,
        maxScore: 15,
        severity: 'critical',
        description: 'Prevents XSS attacks',
        recommendation: 'Add CSP header to restrict content sources'
      },
      {
        name: 'X-Frame-Options',
        value: headers['x-frame-options'],
        present: !!headers['x-frame-options'],
        score: headers['x-frame-options'] ? 10 : 0,
        maxScore: 10,
        severity: 'high',
        description: 'Prevents clickjacking',
        recommendation: 'Add: X-Frame-Options: DENY or SAMEORIGIN'
      },
      {
        name: 'X-Content-Type-Options',
        value: headers['x-content-type-options'],
        present: !!headers['x-content-type-options'],
        score: headers['x-content-type-options'] ? 10 : 0,
        maxScore: 10,
        severity: 'high',
        description: 'Prevents MIME sniffing',
        recommendation: 'Add: X-Content-Type-Options: nosniff'
      },
      {
        name: 'Referrer-Policy',
        value: headers['referrer-policy'],
        present: !!headers['referrer-policy'],
        score: headers['referrer-policy'] ? 10 : 0,
        maxScore: 10,
        severity: 'medium',
        description: 'Controls referrer information',
        recommendation: 'Add: Referrer-Policy: no-referrer or strict-origin-when-cross-origin'
      },
      {
        name: 'Permissions-Policy',
        value: headers['permissions-policy'] || headers['feature-policy'],
        present: !!(headers['permissions-policy'] || headers['feature-policy']),
        score: (headers['permissions-policy'] || headers['feature-policy']) ? 10 : 0,
        maxScore: 10,
        severity: 'medium',
        description: 'Controls browser features',
        recommendation: 'Add Permissions-Policy to restrict browser APIs'
      },
      {
        name: 'X-XSS-Protection',
        value: headers['x-xss-protection'],
        present: !!headers['x-xss-protection'],
        score: headers['x-xss-protection'] ? 5 : 0,
        maxScore: 5,
        severity: 'low',
        description: 'Legacy XSS protection',
        recommendation: 'Add: X-XSS-Protection: 1; mode=block'
      },
      {
        name: 'Access-Control-Allow-Origin',
        value: headers['access-control-allow-origin'],
        present: !!headers['access-control-allow-origin'],
        score: headers['access-control-allow-origin'] === '*' ? -5 : 5,
        maxScore: 5,
        severity: headers['access-control-allow-origin'] === '*' ? 'medium' : 'low',
        description: 'CORS configuration',
        recommendation: headers['access-control-allow-origin'] === '*' ? 'Avoid using * in production' : 'CORS configured correctly'
      }
    ];

    return securityHeaders;
  };

  const check = async () => {
    if (!url.trim()) return;
    setLoading(true); setError(''); setResult(null);
    
    try {
      const res = await fetch(`/api/tools/headers?url=${encodeURIComponent(url.trim())}&method=${method}`);
      const data = await res.json();
      
      if (data.success) {
        const headers = data.data.headers || data.data;
        const normalizedHeaders: Record<string, string> = {};
        
        // Normalize header keys to lowercase
        Object.keys(headers).forEach(key => {
          normalizedHeaders[key.toLowerCase()] = headers[key];
        });

        const securityHeaders = analyzeSecurityHeaders(normalizedHeaders);
        const totalScore = securityHeaders.reduce((sum, h) => sum + h.score, 0);
        const maxScore = securityHeaders.reduce((sum, h) => sum + h.maxScore, 0);
        const securityScore = Math.max(0, Math.round((totalScore / maxScore) * 100));

        const headerResult: HeaderResult = {
          headers: normalizedHeaders,
          statusCode: data.data.statusCode || 200,
          url: url.trim(),
          redirectChain: data.data.redirectChain,
          securityHeaders,
          securityScore,
          corsEnabled: !!normalizedHeaders['access-control-allow-origin'],
          cspPresent: !!normalizedHeaders['content-security-policy'],
          hstsPresent: !!normalizedHeaders['strict-transport-security']
        };

        setResult(headerResult);
        addToHistory(headerResult);
      } else {
        setError(data.error || 'Header check failed');
      }
    } catch (e: any) { 
      setError(e?.message || 'Network error'); 
    }
    finally { setLoading(false); }
  };

  const addToHistory = (headerResult: HeaderResult) => {
    const issues = headerResult.securityHeaders.filter(h => !h.present && h.severity !== 'low').length;
    
    const entry: HistoryEntry = {
      id: Date.now().toString(),
      url: headerResult.url,
      timestamp: new Date().toISOString(),
      securityScore: headerResult.securityScore,
      statusCode: headerResult.statusCode,
      issues
    };

    const newHistory = [entry, ...history.filter(h => h.url !== headerResult.url).slice(0, 19)];
    setHistory(newHistory);
    localStorage.setItem('headerCheckHistory', JSON.stringify(newHistory));
  };

  const clearHistory = () => {
    setHistory([]);
    localStorage.removeItem('headerCheckHistory');
  };

  const copyHeaders = () => {
    if (!result) return;
    const text = Object.entries(result.headers)
      .map(([key, value]) => `${key}: ${value}`)
      .join('\n');
    
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const downloadReport = () => {
    if (!result) return;
    
    const report = {
      url: result.url,
      timestamp: new Date().toISOString(),
      securityScore: result.securityScore,
      statusCode: result.statusCode,
      headers: result.headers,
      securityAnalysis: result.securityHeaders.map(h => ({
        header: h.name,
        present: h.present,
        value: h.value,
        score: `${h.score}/${h.maxScore}`,
        severity: h.severity,
        recommendation: h.recommendation
      })),
      corsEnabled: result.corsEnabled,
      cspPresent: result.cspPresent,
      hstsPresent: result.hstsPresent,
      redirectChain: result.redirectChain
    };

    const json = JSON.stringify(report, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `security-headers-${new URL(result.url).hostname}-${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'green';
    if (score >= 60) return 'yellow';
    if (score >= 40) return 'orange';
    return 'red';
  };

  const getScoreGrade = (score: number) => {
    if (score >= 90) return 'A+';
    if (score >= 80) return 'A';
    if (score >= 70) return 'B';
    if (score >= 60) return 'C';
    if (score >= 50) return 'D';
    return 'F';
  };

  const scoreColor = result ? getScoreColor(result.securityScore) : 'gray';
  const scoreGrade = result ? getScoreGrade(result.securityScore) : 'N/A';
  const criticalIssues = result?.securityHeaders.filter(h => !h.present && h.severity === 'critical').length || 0;
  const highIssues = result?.securityHeaders.filter(h => !h.present && h.severity === 'high').length || 0;
  const totalIssues = result?.securityHeaders.filter(h => !h.present && h.severity !== 'low').length || 0;

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <section className="relative overflow-hidden py-12 border-b border-gray-800">
        <div className="absolute inset-0 bg-grid-gray-900 [mask-image:linear-gradient(to_bottom,white_30%,transparent)]"></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-blue-500/10 rounded-full blur-3xl"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <button 
            onClick={() => onNavigate?.('toolbox')} 
            className="mb-6 flex items-center gap-2 text-gray-400 hover:text-cyan-400 transition-colors"
          >
            <ArrowLeft className="w-4 h-4"/> Back to Toolbox
          </button>
          
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 bg-blue-500/20 rounded-lg border border-blue-500/30">
              <Eye className="w-6 h-6 text-blue-400"/>
            </div>
            <div>
              <h1 className="text-3xl md:text-4xl font-bold">HTTP Header Analyzer</h1>
              <p className="text-gray-400 mt-1">Security headers scoring & compliance checker</p>
            </div>
          </div>

          {/* Stats Dashboard */}
          {result && (
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mt-6">
              <div className={`bg-gray-900/50 border-2 border-${scoreColor}-500/50 rounded-lg p-4`}>
                <div className="text-gray-400 text-sm mb-1">Security Score</div>
                <div className={`text-3xl font-bold text-${scoreColor}-400 flex items-center gap-2`}>
                  {result.securityScore}
                  <span className="text-lg">({scoreGrade})</span>
                </div>
              </div>
              <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-4">
                <div className="text-gray-400 text-sm mb-1">Status Code</div>
                <div className={`text-2xl font-bold ${result.statusCode < 300 ? 'text-green-400' : result.statusCode < 400 ? 'text-yellow-400' : 'text-red-400'}`}>
                  {result.statusCode}
                </div>
              </div>
              <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-4">
                <div className="text-gray-400 text-sm mb-1">Critical Issues</div>
                <div className="text-2xl font-bold text-red-400">{criticalIssues}</div>
              </div>
              <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-4">
                <div className="text-gray-400 text-sm mb-1">High Issues</div>
                <div className="text-2xl font-bold text-orange-400">{highIssues}</div>
              </div>
              <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-4">
                <div className="text-gray-400 text-sm mb-1">Total Issues</div>
                <div className="text-2xl font-bold text-yellow-400">{totalIssues}</div>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Main Content */}
      <section className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-3 gap-6">
            {/* Left Column - Analyzer & Results */}
            <div className="lg:col-span-2 space-y-6">
              {/* Header Checker Input */}
              <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
                <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                  <Search className="w-5 h-5 text-cyan-400" />
                  Analyze HTTP Headers
                </h3>
                
                <div className="space-y-4">
                  <div className="flex flex-col sm:flex-row gap-3">
                    <select 
                      className="px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-cyan-500 transition w-full sm:w-auto"
                      value={method} 
                      onChange={e => setMethod(e.target.value as any)}
                      disabled={loading}
                    >
                      <option>HEAD</option>
                      <option>GET</option>
                    </select>
                    <input 
                      className="flex-1 px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-cyan-500 transition"
                      placeholder="https://example.com" 
                      value={url} 
                      onChange={e => setUrl(e.target.value)}
                      onKeyPress={e => e.key === 'Enter' && check()}
                      disabled={loading}
                    />
                    <button 
                      onClick={check} 
                      disabled={loading || !url.trim()}
                      className="px-6 py-3 rounded-lg bg-gradient-to-r from-blue-500 to-cyan-500 text-black font-semibold flex items-center justify-center gap-2 hover:shadow-lg hover:shadow-blue-500/50 transition disabled:opacity-50 w-full sm:w-auto"
                    >
                      {loading ? (
                        <>
                          <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin"></div>
                          Analyzing...
                        </>
                      ) : (
                        <>
                          <Search className="w-4 h-4" />
                          Analyze
                        </>
                      )}
                    </button>
                  </div>

                  {error && (
                    <div className="flex items-center gap-2 p-3 bg-red-500/10 border border-red-500/30 rounded-lg">
                      <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0" />
                      <p className="text-sm text-red-300">{error}</p>
                    </div>
                  )}

                  {/* Quick Test URLs */}
                  <div className="flex flex-wrap gap-2 justify-center">
                    <span className="text-sm text-gray-400">Quick test:</span>
                    {['https://github.com', 'https://google.com', 'https://mozilla.org', 'https://cloudflare.com'].map(testUrl => (
                      <button
                        key={testUrl}
                        onClick={() => { setUrl(testUrl); }}
                        className="text-xs px-3 py-1 bg-gray-800 hover:bg-gray-700 border border-gray-700 rounded-full transition"
                      >
                        {new URL(testUrl).hostname}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Tabbed Results */}
              {result && (
                <>
                  {/* Tab Navigation */}
                  <div className="flex flex-wrap gap-2 justify-center">
                    {[
                      { id: 'overview', label: 'Overview', icon: <Info className="w-4 h-4" /> },
                      { id: 'security', label: 'Security Headers', icon: <Shield className="w-4 h-4" /> },
                      { id: 'cors', label: 'CORS & CSP', icon: <Globe className="w-4 h-4" /> },
                      { id: 'performance', label: 'All Headers', icon: <Zap className="w-4 h-4" /> }
                    ].map(tab => (
                      <button
                        key={tab.id}
                        onClick={() => setActiveTab(tab.id as any)}
                        className={`px-4 py-2 rounded-lg font-semibold transition flex items-center gap-2 ${
                          activeTab === tab.id
                            ? 'bg-gradient-to-r from-blue-500 to-cyan-500 text-black'
                            : 'bg-gray-800 text-gray-400 border border-gray-700 hover:border-cyan-500/50'
                        }`}
                      >
                        {tab.icon}
                        {tab.label}
                      </button>
                    ))}
                  </div>

                  {/* Tab Content */}
                  <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
                    <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mb-6">
                      <h3 className="text-lg font-bold text-center sm:text-left">
                        {activeTab === 'overview' && 'Security Overview'}
                        {activeTab === 'security' && 'Security Headers Analysis'}
                        {activeTab === 'cors' && 'CORS & CSP Configuration'}
                        {activeTab === 'performance' && `All Response Headers (${Object.keys(result.headers).length})`}
                      </h3>
                      <div className="flex gap-2">
                        <button
                          onClick={copyHeaders}
                          className="px-3 py-2 bg-gray-800 hover:bg-gray-700 rounded-lg border border-gray-700 transition flex items-center gap-2 text-sm"
                        >
                          {copied ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
                          Copy
                        </button>
                        <button
                          onClick={downloadReport}
                          className="px-3 py-2 bg-gray-800 hover:bg-gray-700 rounded-lg border border-gray-700 transition flex items-center gap-2 text-sm"
                        >
                          <Download className="w-4 h-4" />
                          Report
                        </button>
                      </div>
                    </div>

                    {/* Overview Tab */}
                    {activeTab === 'overview' && (
                      <div className="space-y-6">
                        {/* Security Score Breakdown */}
                        <div className={`p-6 rounded-xl border-2 border-${scoreColor}-500/50 bg-${scoreColor}-500/10`}>
                          <div className="flex items-center justify-between mb-4">
                            <div className="flex items-center gap-3">
                              <div className={`p-3 rounded-lg bg-${scoreColor}-500/20`}>
                                <Shield className={`w-6 h-6 text-${scoreColor}-400`} />
                              </div>
                              <div>
                                <div className="text-2xl font-bold">Security Grade: {scoreGrade}</div>
                                <div className="text-sm text-gray-400">Overall Score: {result.securityScore}/100</div>
                              </div>
                            </div>
                          </div>
                          <div className="w-full bg-gray-800 rounded-full h-4 overflow-hidden">
                            <div 
                              className={`h-full bg-gradient-to-r from-${scoreColor}-500 to-${scoreColor}-400 transition-all duration-500`}
                              style={{ width: `${result.securityScore}%` }}
                            ></div>
                          </div>
                        </div>

                        {/* Key Findings */}
                        <div className="grid md:grid-cols-3 gap-4">
                          <div className={`p-4 rounded-lg border ${result.hstsPresent ? 'border-green-500/50 bg-green-500/10' : 'border-red-500/50 bg-red-500/10'}`}>
                            <div className="flex items-center gap-2 mb-2">
                              {result.hstsPresent ? <CheckCircle className="w-5 h-5 text-green-400" /> : <XCircle className="w-5 h-5 text-red-400" />}
                              <span className="font-semibold">HSTS</span>
                            </div>
                            <div className="text-sm text-gray-400">
                              {result.hstsPresent ? 'Enforces HTTPS' : 'Not configured'}
                            </div>
                          </div>

                          <div className={`p-4 rounded-lg border ${result.cspPresent ? 'border-green-500/50 bg-green-500/10' : 'border-red-500/50 bg-red-500/10'}`}>
                            <div className="flex items-center gap-2 mb-2">
                              {result.cspPresent ? <CheckCircle className="w-5 h-5 text-green-400" /> : <XCircle className="w-5 h-5 text-red-400" />}
                              <span className="font-semibold">CSP</span>
                            </div>
                            <div className="text-sm text-gray-400">
                              {result.cspPresent ? 'XSS protection active' : 'No XSS protection'}
                            </div>
                          </div>

                          <div className={`p-4 rounded-lg border ${result.corsEnabled ? 'border-yellow-500/50 bg-yellow-500/10' : 'border-gray-500/50 bg-gray-500/10'}`}>
                            <div className="flex items-center gap-2 mb-2">
                              {result.corsEnabled ? <AlertCircle className="w-5 h-5 text-yellow-400" /> : <Info className="w-5 h-5 text-gray-400" />}
                              <span className="font-semibold">CORS</span>
                            </div>
                            <div className="text-sm text-gray-400">
                              {result.corsEnabled ? 'Enabled - review config' : 'Not enabled'}
                            </div>
                          </div>
                        </div>

                        {/* Redirect Chain */}
                        {result.redirectChain && result.redirectChain.length > 1 && (
                          <div className="p-4 bg-gray-800/50 border border-yellow-500/30 rounded-lg">
                            <h4 className="font-semibold mb-3 flex items-center gap-2">
                              <TrendingUp className="w-4 h-4 text-yellow-400" />
                              Redirect Chain ({result.redirectChain.length} hops)
                            </h4>
                            <div className="space-y-2">
                              {result.redirectChain.map((hop, idx) => (
                                <div key={idx} className="flex items-center gap-3 text-sm">
                                  <div className="px-2 py-1 bg-yellow-500/20 border border-yellow-500/30 rounded text-yellow-400 font-bold">
                                    {idx + 1}
                                  </div>
                                  <code className="flex-1 text-cyan-400 font-mono text-xs break-all">{hop}</code>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Security Headers Tab */}
                    {activeTab === 'security' && (
                      <div className="space-y-3">
                        {result.securityHeaders.map((header, idx) => {
                          const severityColors = {
                            critical: 'border-red-500/50 bg-red-500/10',
                            high: 'border-orange-500/50 bg-orange-500/10',
                            medium: 'border-yellow-500/50 bg-yellow-500/10',
                            low: 'border-gray-500/50 bg-gray-500/10'
                          };

                          const severityIcons = {
                            critical: <AlertTriangle className="w-5 h-5 text-red-400" />,
                            high: <AlertCircle className="w-5 h-5 text-orange-400" />,
                            medium: <Info className="w-5 h-5 text-yellow-400" />,
                            low: <CheckCircle className="w-5 h-5 text-gray-400" />
                          };

                          return (
                            <div
                              key={idx}
                              className={`p-4 rounded-xl border-2 ${header.present ? 'border-green-500/50 bg-green-500/10' : severityColors[header.severity]}`}
                            >
                              <div className="flex items-start justify-between mb-2">
                                <div className="flex items-center gap-3 flex-1">
                                  {header.present ? (
                                    <CheckCircle className="w-5 h-5 text-green-400" />
                                  ) : (
                                    severityIcons[header.severity]
                                  )}
                                  <div className="flex-1">
                                    <div className="font-bold text-white mb-1">{header.name}</div>
                                    <div className="text-xs text-gray-400">{header.description}</div>
                                  </div>
                                </div>
                                <div className="text-right">
                                  <div className="text-lg font-bold text-cyan-400">
                                    {header.score}/{header.maxScore}
                                  </div>
                                  <div className="text-xs text-gray-400 capitalize">{header.severity}</div>
                                </div>
                              </div>
                              
                              {header.value ? (
                                <div className="mt-3 pt-3 border-t border-gray-700">
                                  <div className="text-xs text-gray-400 mb-1">Current Value:</div>
                                  <code className="text-xs text-green-400 font-mono break-all">{header.value}</code>
                                </div>
                              ) : header.recommendation && (
                                <div className="mt-3 pt-3 border-t border-gray-700">
                                  <div className="text-xs text-gray-400 mb-1">Recommendation:</div>
                                  <code className="text-xs text-yellow-400 font-mono break-all">{header.recommendation}</code>
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    )}

                    {/* CORS & CSP Tab */}
                    {activeTab === 'cors' && (
                      <div className="space-y-6">
                        {/* CORS Analysis */}
                        <div className="p-4 bg-gray-800/50 rounded-lg border border-gray-700">
                          <h4 className="font-semibold mb-4 flex items-center gap-2">
                            <Globe className="w-5 h-5 text-cyan-400" />
                            CORS Configuration
                          </h4>
                          <div className="space-y-3 text-sm">
                            {result.headers['access-control-allow-origin'] ? (
                              <>
                                <div className="flex justify-between items-center p-3 bg-gray-900/50 rounded">
                                  <span className="text-gray-400">Allow-Origin:</span>
                                  <code className="text-cyan-400 font-mono">{result.headers['access-control-allow-origin']}</code>
                                </div>
                                {result.headers['access-control-allow-methods'] && (
                                  <div className="flex justify-between items-center p-3 bg-gray-900/50 rounded">
                                    <span className="text-gray-400">Allow-Methods:</span>
                                    <code className="text-cyan-400 font-mono">{result.headers['access-control-allow-methods']}</code>
                                  </div>
                                )}
                                {result.headers['access-control-allow-headers'] && (
                                  <div className="flex justify-between items-center p-3 bg-gray-900/50 rounded">
                                    <span className="text-gray-400">Allow-Headers:</span>
                                    <code className="text-cyan-400 font-mono text-xs">{result.headers['access-control-allow-headers']}</code>
                                  </div>
                                )}
                                {result.headers['access-control-allow-credentials'] && (
                                  <div className="flex justify-between items-center p-3 bg-gray-900/50 rounded">
                                    <span className="text-gray-400">Allow-Credentials:</span>
                                    <code className="text-cyan-400 font-mono">{result.headers['access-control-allow-credentials']}</code>
                                  </div>
                                )}
                              </>
                            ) : (
                              <div className="text-gray-400 p-3 bg-gray-900/50 rounded">
                                CORS is not configured on this endpoint
                              </div>
                            )}
                          </div>
                        </div>

                        {/* CSP Analysis */}
                        <div className="p-4 bg-gray-800/50 rounded-lg border border-gray-700">
                          <h4 className="font-semibold mb-4 flex items-center gap-2">
                            <Lock className="w-5 h-5 text-purple-400" />
                            Content Security Policy
                          </h4>
                          {result.headers['content-security-policy'] ? (
                            <div className="space-y-2">
                              {result.headers['content-security-policy'].split(';').map((directive, idx) => (
                                <div key={idx} className="p-2 bg-gray-900/50 rounded text-xs">
                                  <code className="text-purple-400 font-mono">{directive.trim()}</code>
                                </div>
                              ))}
                            </div>
                          ) : (
                            <div className="text-gray-400 p-3 bg-red-500/10 border border-red-500/30 rounded">
                              ⚠️ No CSP configured - vulnerable to XSS attacks
                            </div>
                          )}
                        </div>
                      </div>
                    )}

                    {/* All Headers Tab */}
                    {activeTab === 'performance' && (
                      <div className="space-y-2 max-h-[600px] overflow-y-auto">
                        {Object.entries(result.headers).map(([key, value]) => (
                          <div key={key} className="p-3 bg-gray-800/50 rounded-lg border border-gray-700 hover:border-cyan-500/50 transition">
                            <div className="font-semibold text-cyan-400 text-sm mb-1 font-mono">{key}</div>
                            <div className="text-xs text-gray-300 break-all font-mono">{value}</div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </>
              )}
            </div>

            {/* Right Column - History & Guide */}
            <div className="space-y-6">
              {/* Security Checklist */}
              <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
                <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                  <Shield className="w-5 h-5 text-green-400" />
                  Security Checklist
                </h3>
                <div className="space-y-3 text-sm">
                  {result?.securityHeaders.slice(0, 6).map((header, idx) => (
                    <div key={idx} className="flex items-start gap-2">
                      {header.present ? (
                        <CheckCircle className="w-4 h-4 text-green-400 mt-0.5" />
                      ) : (
                        <XCircle className="w-4 h-4 text-red-400 mt-0.5" />
                      )}
                      <div className="flex-1">
                        <div className={`font-semibold ${header.present ? 'text-green-400' : 'text-red-400'}`}>
                          {header.name}
                        </div>
                        <div className="text-gray-400 text-xs">{header.description}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Check History */}
              {history.length > 0 && (
                <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-bold flex items-center gap-2">
                      <Clock className="w-5 h-5 text-cyan-400" />
                      Recent Checks
                    </h3>
                    <button
                      onClick={clearHistory}
                      className="text-xs text-gray-400 hover:text-red-400 transition"
                    >
                      Clear
                    </button>
                  </div>
                  <div className="space-y-2 max-h-96 overflow-y-auto">
                    {history.map(entry => {
                      const scoreColor = getScoreColor(entry.securityScore);
                      return (
                        <button
                          key={entry.id}
                          onClick={() => setUrl(entry.url)}
                          className="w-full p-3 bg-gray-800/50 hover:bg-gray-800 border border-gray-700 hover:border-cyan-500/50 rounded-lg transition-all text-left"
                        >
                          <div className="font-mono text-cyan-400 font-semibold text-xs mb-2 truncate">
                            {entry.url}
                          </div>
                          <div className="flex items-center justify-between text-xs">
                            <span className={`px-2 py-1 rounded bg-${scoreColor}-500/20 text-${scoreColor}-400 font-bold`}>
                              {entry.securityScore}/100
                            </span>
                            <span className="text-gray-400">
                              {entry.issues} issue{entry.issues !== 1 ? 's' : ''}
                            </span>
                          </div>
                          <div className="text-xs text-gray-500 mt-2 flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {new Date(entry.timestamp).toLocaleString()}
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Best Practices */}
              <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
                <h3 className="text-lg font-bold mb-4">HTTP Security Best Practices</h3>
                <div className="space-y-3 text-sm text-gray-400">
                  <div><strong className="text-green-400">✓</strong> Always use HTTPS</div>
                  <div><strong className="text-green-400">✓</strong> Implement HSTS</div>
                  <div><strong className="text-green-400">✓</strong> Configure CSP properly</div>
                  <div><strong className="text-green-400">✓</strong> Enable X-Frame-Options</div>
                  <div><strong className="text-red-400">✗</strong> Avoid CORS wildcard (*)</div>
                  <div><strong className="text-red-400">✗</strong> Don't expose server version</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HeaderCheckerPage;
