import React from 'react';
import type { Page } from '../../App';
import { ALL_AGENTS } from '../../agents';
import { Agent } from '../../constants';

interface AgentsPageProps {
  onSelectAgent: (agent: Agent) => void;
  onNavigate: (page: Page) => void;
}

// Map agent IDs to their dedicated page routes
const getAgentPageRoute = (agentId: string): Page => {
  const agentRoutes: Record<string, Page> = {
    'ai-girlfriend': 'ai-girlfriend',
    'emo-ai': 'emo-ai',
    'pdf-mind': 'pdf-mind',
    'chat-revive': 'chat-revive',
    'tok-boost': 'tok-boost',
    'you-gen': 'you-gen',
    'agent-x': 'agent-x',
    'auto-chat': 'auto-chat',
    'cv-smash': 'cv-smash',
    'comedian': 'comedian',
    'lazy': 'lazy',
    'flirt': 'flirt',
    'sassy': 'sassy',
    'nerd': 'nerd',
    'cool': 'cool',
    'zen': 'zen',
    'gamer': 'gamer',
  };
  return agentRoutes[agentId] || 'home';
};

const AgentCard: React.FC<{ agent: Agent; onSelect: (agent: Agent) => void }> = ({ agent, onSelect }) => (
  <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6 flex flex-col items-start space-y-4 hover:border-cyan-500/50 hover:bg-gray-900 transition-all duration-300 transform hover:-translate-y-1">
    <div className="w-12 h-12 flex items-center justify-center rounded-lg bg-gray-800 text-cyan-400">
      {agent.icon && agent.icon.startsWith('data:image') ? (
        <img src={agent.icon} alt={`${agent.name} icon`} className="w-full h-full object-cover rounded-lg" />
      ) : (
        <i className={`${agent.icon} text-3xl`}></i>
      )}
    </div>
    <h3 className="text-xl font-bold text-white">{agent.name}</h3>
    <p className="text-cyan-400 text-sm font-medium">{agent.role}</p>
    <p className="text-gray-400 flex-grow">{agent.description}</p>
    <button 
      onClick={() => onSelect(agent)} 
      title={`Subscribe to ${agent.name}`}
      className="mt-auto px-4 py-2 bg-cyan-600 hover:bg-cyan-700 text-white font-semibold rounded-lg transition-colors"
    >
      Subscribe Now
    </button>
  </div>
);

const AgentsPage: React.FC<AgentsPageProps> = ({ onSelectAgent, onNavigate }) => {
  const handleSelectAgent = (agent: Agent) => {
    // onSelectAgent is now selectAgentForSubscription from App.tsx
    // It will automatically check login status and navigate to subscription or login page
    onSelectAgent(agent);
  };

  return (
    <div className="bg-black text-white">
      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 md:py-32">
        <div className="absolute inset-0 bg-grid-gray-900 [mask-image:linear-gradient(to_bottom,white_30%,transparent)]"></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-cyan-500/10 rounded-full blur-3xl"></div>
        <div className="container mx-auto px-6 text-center relative z-10">
          <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight mb-4 bg-clip-text text-transparent bg-gradient-to-b from-white to-gray-400">
            Meet Our Agents
          </h1>
          <p className="max-w-3xl mx-auto text-lg md:text-xl text-gray-400">
            Each agent is a specialized persona designed to excel in their unique domain. Choose your perfect AI companion for any task.
          </p>
        </div>
      </section>

      {/* Agents Grid */}
      <section className="py-20 md:py-28 bg-[#0a0a0a]">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {ALL_AGENTS.map((agent) => (
              <AgentCard key={agent.id} agent={agent} onSelect={handleSelectAgent} />
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 md:py-28 relative">
        <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/10 via-transparent to-cyan-500/10"></div>
        <div className="container mx-auto px-6 text-center relative z-10">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">Ready to Get Started?</h2>
          <p className="max-w-2xl mx-auto text-gray-400 mb-8">
            Pick an agent and start an amazing conversation. No signup required for your first interaction.
          </p>
          <button 
            onClick={() => {
              const randomAgent = ALL_AGENTS[Math.floor(Math.random() * ALL_AGENTS.length)];
              handleSelectAgent(randomAgent);
            }}
            className="px-8 py-3 bg-cyan-500 hover:bg-cyan-600 text-black font-semibold rounded-lg transition-all duration-300 hover:shadow-lg hover:shadow-cyan-500/50"
          >
            Try a Random Agent
          </button>
        </div>
      </section>
    </div>
  );
};

export default AgentsPage;
