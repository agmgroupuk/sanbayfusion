import React, { useState } from 'react';
import { Page } from '../../App';
import { Trophy, Star, Gift, Users, Share2, Zap, Target, Award, TrendingUp, Crown, Sparkles, Clock, MessageSquare, Bot, Wrench, Calendar, UserPlus } from 'lucide-react';

interface RewardCenterPageProps {
  onNavigate: (page: Page) => void;
}

// User progress data (mock data for now)
const userProgress = {
  totalPoints: 3450,
  currentLevel: 'Gold',
  levelProgress: 65, // percentage to next level
  nextLevelPoints: 5000,
  badges: ['Early Adopter', 'Community Star', 'Tool Master', 'Agent Explorer']
};

// Level definitions
const levels = [
  { name: 'Bronze', minPoints: 0, maxPoints: 999, color: 'from-orange-600 to-amber-700', icon: '🥉' },
  { name: 'Silver', minPoints: 1000, maxPoints: 2499, color: 'from-gray-400 to-gray-500', icon: '🥈' },
  { name: 'Gold', minPoints: 2500, maxPoints: 4999, color: 'from-yellow-400 to-yellow-600', icon: '🥇' },
  { name: 'Platinum', minPoints: 5000, maxPoints: 9999, color: 'from-cyan-400 to-blue-500', icon: '💎' },
  { name: 'Diamond', minPoints: 10000, maxPoints: 999999, color: 'from-purple-500 to-pink-600', icon: '👑' }
];

// All 17 AI Agents
const agents = [
  { name: 'AI Girlfriend Pro', category: 'Companion AI', points: 150, icon: '💖' },
  { name: 'EmoAI', category: 'Emotional Intelligence', points: 150, icon: '😊' },
  { name: 'PDFMind', category: 'Document Analysis', points: 150, icon: '�' },
  { name: 'ChatRevive', category: 'Conversation Recovery', points: 100, icon: '💬' },
  { name: 'TokBoost', category: 'Social Media Growth', points: 150, icon: '📱' },
  { name: 'YouGen', category: 'Content Generation', points: 150, icon: '✨' },
  { name: 'AgentX', category: 'Multi-Purpose AI', points: 150, icon: '🤖' },
  { name: 'AutoChat', category: 'Chat Automation', points: 100, icon: '⚡' },
  { name: 'CVSmash', category: 'Resume Builder', points: 150, icon: '�' },
  { name: 'ComedyChad', category: 'Humor & Entertainment', points: 100, icon: '�' },
  { name: 'LazyLarry', category: 'Productivity Helper', points: 100, icon: '😴' },
  { name: 'FlirtyFiona', category: 'Social Skills Coach', points: 100, icon: '�' },
  { name: 'SassySarah', category: 'Witty Companion', points: 100, icon: '💁' },
  { name: 'NerdyNeil', category: 'Tech Enthusiast', points: 150, icon: '🤓' },
  { name: 'CoolKyle', category: 'Lifestyle Advisor', points: 100, icon: '�' },
  { name: 'ZenMasterZara', category: 'Mindfulness Coach', points: 100, icon: '🧘' },
  { name: 'GamerGary', category: 'Gaming Companion', points: 100, icon: '🎮' }
];

// Developer Tools (30+)
const tools = [
  { name: 'IP Lookup', points: 10, category: 'Network' },
  { name: 'DNS Lookup', points: 10, category: 'Network' },
  { name: 'WHOIS Lookup', points: 10, category: 'Domain' },
  { name: 'SSL Checker', points: 15, category: 'Security' },
  { name: 'Threat Intelligence', points: 20, category: 'Security' },
  { name: 'Port Scanner', points: 15, category: 'Network' },
  { name: 'Ping Test', points: 5, category: 'Network' },
  { name: 'Traceroute', points: 10, category: 'Network' },
  { name: 'IP Geolocation', points: 10, category: 'Network' },
  { name: 'Email Validator', points: 10, category: 'Validation' },
  { name: 'URL Shortener', points: 5, category: 'Developer' },
  { name: 'Base64 Encoder', points: 5, category: 'Developer' },
  { name: 'JSON Formatter', points: 5, category: 'Developer' },
  { name: 'Hash Generator', points: 10, category: 'Security' },
  { name: 'QR Code Generator', points: 10, category: 'Developer' }
];

// Daily activities
const dailyActivities = [
  { name: 'Daily Login', points: 10, icon: <Calendar className="w-5 h-5" />, description: 'Login every day to earn points' },
  { name: 'First Chat of the Day', points: 20, icon: <MessageSquare className="w-5 h-5" />, description: 'Start a conversation with any agent' },
  { name: 'Use Developer Tool', points: 15, icon: <Wrench className="w-5 h-5" />, description: 'Use any developer tool' },
  { name: 'Complete Profile', points: 50, icon: <Target className="w-5 h-5" />, description: 'Fill out your profile information' }
];

// Community engagement
const communityActivities = [
  { name: 'Join Community', points: 50, icon: <Users className="w-5 h-5" />, description: 'Join the IAMAI Global community' },
  { name: 'First Post', points: 30, icon: <MessageSquare className="w-5 h-5" />, description: 'Create your first community post' },
  { name: 'Comment on Post', points: 10, icon: <MessageSquare className="w-5 h-5" />, description: 'Engage with community posts' },
  { name: 'Post gets 10 Likes', points: 25, icon: <Star className="w-5 h-5" />, description: 'Create popular content' },
  { name: 'Active Participant', points: 100, icon: <Trophy className="w-5 h-5" />, description: '10 posts in a month' }
];

// Social sharing
const socialActivities = [
  { name: 'Share on Twitter', points: 15, icon: <Share2 className="w-5 h-5" />, description: 'Share IAMAI Global on Twitter' },
  { name: 'Share on Facebook', points: 15, icon: <Share2 className="w-5 h-5" />, description: 'Share IAMAI Global on Facebook' },
  { name: 'Share on LinkedIn', points: 15, icon: <Share2 className="w-5 h-5" />, description: 'Share IAMAI Global on LinkedIn' },
  { name: 'Invite 5 Friends', points: 100, icon: <UserPlus className="w-5 h-5" />, description: 'Invite friends to join' },
  { name: 'Successful Referral', points: 250, icon: <Gift className="w-5 h-5" />, description: 'Friend signs up with your link' }
];

// Category type
type Category = 'overview' | 'agents' | 'tools' | 'daily' | 'community' | 'social';

const RewardCenterPage: React.FC<RewardCenterPageProps> = ({ onNavigate }) => {
  const [activeCategory, setActiveCategory] = useState<Category>('overview');

  const currentLevel = levels.find(l => l.name === userProgress.currentLevel);
  const nextLevel = levels[levels.findIndex(l => l.name === userProgress.currentLevel) + 1];

  return (
    <div className="bg-black text-white min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 md:py-32">
        <div className="absolute inset-0 bg-grid-gray-900 [mask-image:linear-gradient(to_bottom,white_30%,transparent)]"></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-to-r from-cyan-500/20 to-purple-500/20 rounded-full blur-3xl"></div>
        
        <div className="container mx-auto px-6 relative z-10">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 bg-cyan-500/10 border border-cyan-500/30 rounded-full px-6 py-2 mb-6">
              <Trophy className="w-5 h-5 text-cyan-400" />
              <span className="text-cyan-400 font-semibold">Reward Center</span>
            </div>
            
            <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight mb-4 bg-clip-text text-transparent bg-gradient-to-b from-white to-gray-400">
              Earn Rewards, Level Up!
            </h1>
            
            <p className="max-w-3xl mx-auto text-lg md:text-xl text-gray-400 mb-8">
              Complete tasks, engage with the community, and unlock exclusive rewards. Every action brings you closer to the next level!
            </p>

            {/* Coming Soon Banner */}
            <div className="max-w-3xl mx-auto mb-12">
              <div className="bg-gradient-to-r from-yellow-500/20 to-orange-500/20 border-2 border-yellow-500/50 rounded-2xl p-6 backdrop-blur-sm">
                <div className="flex items-center justify-center gap-3 mb-3">
                  <Sparkles className="w-6 h-6 text-yellow-400 animate-pulse" />
                  <h3 className="text-xl md:text-2xl font-bold text-yellow-400">Coming Soon!</h3>
                  <Sparkles className="w-6 h-6 text-yellow-400 animate-pulse" />
                </div>
                <p className="text-center text-gray-300 text-base md:text-lg">
                  We're working hard behind the scenes to bring you an <span className="font-semibold text-yellow-400">amazing gamification system</span>! 🚀 
                  Get ready for exciting rewards, achievements, and a whole lot of fun. Stay tuned! 🎉
                </p>
              </div>
            </div>
          </div>

          {/* User Progress Card */}
          <div className="max-w-4xl mx-auto bg-gradient-to-br from-gray-900 to-black border border-gray-800 rounded-2xl p-8 mb-8">
            <div className="flex flex-col md:flex-row items-center justify-between gap-6 mb-6">
              <div className="flex items-center gap-4">
                <div className={`w-20 h-20 rounded-full bg-gradient-to-br ${currentLevel?.color} flex items-center justify-center text-4xl shadow-lg`}>
                  {currentLevel?.icon}
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-white">{userProgress.currentLevel} Level</h3>
                  <p className="text-gray-400">{userProgress.totalPoints.toLocaleString()} Total Points</p>
                </div>
              </div>
              
              <div className="text-center md:text-right">
                <p className="text-sm text-gray-400 mb-1">Next Level: {nextLevel?.name}</p>
                <p className="text-lg font-bold text-cyan-400">{userProgress.nextLevelPoints - userProgress.totalPoints} points to go</p>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="mb-6">
              <div className="flex justify-between text-sm text-gray-400 mb-2">
                <span>Level Progress</span>
                <span>{userProgress.levelProgress}%</span>
              </div>
              <div className="w-full bg-gray-800 rounded-full h-3 overflow-hidden">
                <div 
                  className={`h-full bg-gradient-to-r ${currentLevel?.color} transition-all duration-500 rounded-full`}
                  style={{ width: `${userProgress.levelProgress}%` }}
                ></div>
              </div>
            </div>

            {/* Badges */}
            <div>
              <p className="text-sm text-gray-400 mb-3">Your Badges</p>
              <div className="flex flex-wrap gap-2">
                {userProgress.badges.map((badge, index) => (
                  <div key={index} className="bg-gray-800 border border-cyan-500/30 rounded-lg px-4 py-2 flex items-center gap-2">
                    <Award className="w-4 h-4 text-cyan-400" />
                    <span className="text-sm text-white">{badge}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Level Showcase */}
          <div className="max-w-6xl mx-auto grid grid-cols-2 md:grid-cols-5 gap-4">
            {levels.map((level, index) => (
              <div 
                key={level.name}
                className={`bg-gray-900 border ${userProgress.currentLevel === level.name ? 'border-cyan-500 shadow-lg shadow-cyan-500/20' : 'border-gray-800'} rounded-xl p-4 text-center transition-all hover:scale-105`}
              >
                <div className={`w-12 h-12 mx-auto mb-3 rounded-full bg-gradient-to-br ${level.color} flex items-center justify-center text-2xl`}>
                  {level.icon}
                </div>
                <h4 className="font-bold text-white mb-1">{level.name}</h4>
                <p className="text-xs text-gray-400">{level.minPoints}+ pts</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Category Navigation */}
      <section className="bg-black border-y border-gray-800 sticky top-0 z-40 backdrop-blur-lg bg-black/80">
        <div className="container mx-auto px-6">
          <div className="flex overflow-x-auto gap-2 py-4 no-scrollbar">
            {[
              { id: 'overview', label: 'Overview', icon: <Sparkles className="w-4 h-4" /> },
              { id: 'agents', label: 'AI Agents', icon: <Bot className="w-4 h-4" /> },
              { id: 'tools', label: 'Developer Tools', icon: <Wrench className="w-4 h-4" /> },
              { id: 'daily', label: 'Daily Activities', icon: <Calendar className="w-4 h-4" /> },
              { id: 'community', label: 'Community', icon: <Users className="w-4 h-4" /> },
              { id: 'social', label: 'Social & Referrals', icon: <Share2 className="w-4 h-4" /> }
            ].map((cat) => (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id as Category)}
                className={`flex items-center gap-2 px-6 py-3 rounded-lg font-semibold whitespace-nowrap transition-all ${
                  activeCategory === cat.id
                    ? 'bg-gradient-to-r from-cyan-500 to-blue-500 text-white'
                    : 'bg-gray-900 text-gray-400 hover:text-white hover:bg-gray-800'
                }`}
              >
                {cat.icon}
                {cat.label}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Content Sections */}
      <section className="py-20 bg-[#0a0a0a]">
        <div className="container mx-auto px-6">
          {/* Overview */}
          {activeCategory === 'overview' && (
            <div className="space-y-8">
              <div className="text-center mb-12">
                <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">How to Earn Points</h2>
                <p className="text-gray-400 max-w-2xl mx-auto">
                  Explore different ways to earn points and climb the leaderboard!
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <RewardCard 
                  icon={<Bot className="w-8 h-8" />}
                  title="Subscribe to AI Agents"
                  description="Earn 100-150 points per agent subscription"
                  points="100-150 pts"
                  gradient="from-purple-500 to-pink-600"
                />
                <RewardCard 
                  icon={<Wrench className="w-8 h-8" />}
                  title="Use Developer Tools"
                  description="5-20 points per tool usage"
                  points="5-20 pts"
                  gradient="from-blue-500 to-cyan-500"
                />
                <RewardCard 
                  icon={<Calendar className="w-8 h-8" />}
                  title="Daily Login Streak"
                  description="Login daily to earn consistent rewards"
                  points="10 pts/day"
                  gradient="from-green-500 to-emerald-600"
                />
                <RewardCard 
                  icon={<Users className="w-8 h-8" />}
                  title="Community Engagement"
                  description="Post, comment, and interact"
                  points="10-100 pts"
                  gradient="from-orange-500 to-red-600"
                />
                <RewardCard 
                  icon={<Share2 className="w-8 h-8" />}
                  title="Social Sharing"
                  description="Share on social media"
                  points="15 pts"
                  gradient="from-cyan-500 to-blue-600"
                />
                <RewardCard 
                  icon={<Gift className="w-8 h-8" />}
                  title="Invite Friends"
                  description="Successful referrals earn big"
                  points="250 pts"
                  gradient="from-yellow-500 to-orange-600"
                />
              </div>
            </div>
          )}

          {/* AI Agents */}
          {activeCategory === 'agents' && (
            <div>
              <div className="text-center mb-12">
                <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">AI Agent Subscriptions</h2>
                <p className="text-gray-400 max-w-2xl mx-auto">
                  Subscribe to any of our 17 AI agents and earn points! Specialized agents reward more points.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {agents.map((agent, index) => (
                  <div key={index} className="bg-gray-900 border border-gray-800 rounded-xl p-6 hover:border-cyan-500/50 transition-all hover:scale-105">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <div className="text-4xl">{agent.icon}</div>
                        <div>
                          <h3 className="font-bold text-white">{agent.name}</h3>
                          <p className="text-sm text-gray-400">{agent.category}</p>
                        </div>
                      </div>
                      <div className="bg-gradient-to-r from-cyan-500 to-blue-500 text-white px-3 py-1 rounded-full text-sm font-bold">
                        +{agent.points}
                      </div>
                    </div>
                    <button className="w-full bg-gray-800 hover:bg-gradient-to-r hover:from-cyan-500 hover:to-blue-500 text-white font-semibold py-2 rounded-lg transition-all">
                      Subscribe to Earn
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Developer Tools */}
          {activeCategory === 'tools' && (
            <div>
              <div className="text-center mb-12">
                <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Developer Tools Rewards</h2>
                <p className="text-gray-400 max-w-2xl mx-auto">
                  Use our 30+ developer tools and earn points with each usage!
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {tools.map((tool, index) => (
                  <div key={index} className="bg-gray-900 border border-gray-800 rounded-lg p-4 hover:border-cyan-500/50 transition-all flex justify-between items-center">
                    <div>
                      <h4 className="font-semibold text-white">{tool.name}</h4>
                      <p className="text-sm text-gray-400">{tool.category}</p>
                    </div>
                    <div className="bg-cyan-500/20 text-cyan-400 px-3 py-1 rounded-full text-sm font-bold">
                      +{tool.points}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Daily Activities */}
          {activeCategory === 'daily' && (
            <div>
              <div className="text-center mb-12">
                <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Daily Activities</h2>
                <p className="text-gray-400 max-w-2xl mx-auto">
                  Complete these daily tasks to earn consistent rewards!
                </p>
              </div>

              <div className="max-w-3xl mx-auto space-y-4">
                {dailyActivities.map((activity, index) => (
                  <div key={index} className="bg-gray-900 border border-gray-800 rounded-xl p-6 hover:border-cyan-500/50 transition-all">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-cyan-500/20 rounded-lg flex items-center justify-center text-cyan-400">
                          {activity.icon}
                        </div>
                        <div>
                          <h3 className="font-bold text-white mb-1">{activity.name}</h3>
                          <p className="text-sm text-gray-400">{activity.description}</p>
                        </div>
                      </div>
                      <div className="bg-gradient-to-r from-cyan-500 to-blue-500 text-white px-4 py-2 rounded-full font-bold">
                        +{activity.points}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Community */}
          {activeCategory === 'community' && (
            <div>
              <div className="text-center mb-12">
                <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Community Engagement</h2>
                <p className="text-gray-400 max-w-2xl mx-auto">
                  Join our community, create content, and earn big rewards!
                </p>
              </div>

              <div className="max-w-3xl mx-auto space-y-4">
                {communityActivities.map((activity, index) => (
                  <div key={index} className="bg-gray-900 border border-gray-800 rounded-xl p-6 hover:border-cyan-500/50 transition-all">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-orange-500/20 rounded-lg flex items-center justify-center text-orange-400">
                          {activity.icon}
                        </div>
                        <div>
                          <h3 className="font-bold text-white mb-1">{activity.name}</h3>
                          <p className="text-sm text-gray-400">{activity.description}</p>
                        </div>
                      </div>
                      <div className="bg-gradient-to-r from-orange-500 to-red-600 text-white px-4 py-2 rounded-full font-bold">
                        +{activity.points}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Social & Referrals */}
          {activeCategory === 'social' && (
            <div>
              <div className="text-center mb-12">
                <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Social Sharing & Referrals</h2>
                <p className="text-gray-400 max-w-2xl mx-auto">
                  Spread the word and earn massive rewards for successful referrals!
                </p>
              </div>

              <div className="max-w-3xl mx-auto space-y-4">
                {socialActivities.map((activity, index) => (
                  <div key={index} className="bg-gray-900 border border-gray-800 rounded-xl p-6 hover:border-cyan-500/50 transition-all">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-purple-500/20 rounded-lg flex items-center justify-center text-purple-400">
                          {activity.icon}
                        </div>
                        <div>
                          <h3 className="font-bold text-white mb-1">{activity.name}</h3>
                          <p className="text-sm text-gray-400">{activity.description}</p>
                        </div>
                      </div>
                      <div className="bg-gradient-to-r from-purple-500 to-pink-600 text-white px-4 py-2 rounded-full font-bold">
                        +{activity.points}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-black">
        <div className="container mx-auto px-6">
          <div className="bg-gradient-to-r from-cyan-500 to-purple-500 rounded-2xl p-10 md:p-16 text-center">
            <h2 className="text-3xl md:text-4xl font-bold text-black mb-4">Start Earning Rewards Today!</h2>
            <p className="max-w-2xl mx-auto text-gray-900 mb-8">
              Join thousands of users leveling up their experience. Complete tasks, engage with the community, and unlock exclusive rewards!
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button
                onClick={() => onNavigate('signup')}
                className="bg-black text-white font-semibold px-8 py-3 rounded-full hover:bg-gray-900 transition-all duration-300 transform hover:scale-105"
              >
                Get Started Now
              </button>
              <button
                onClick={() => onNavigate('community')}
                className="bg-white text-black font-semibold px-8 py-3 rounded-full hover:bg-gray-100 transition-all duration-300 transform hover:scale-105"
              >
                Join Community
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

// Reward Card Component
const RewardCard: React.FC<{ icon: React.ReactNode; title: string; description: string; points: string; gradient: string }> = 
  ({ icon, title, description, points, gradient }) => (
    <div className="bg-gray-900 border border-gray-800 rounded-xl p-6 hover:border-cyan-500/50 transition-all hover:scale-105">
      <div className={`w-16 h-16 rounded-lg bg-gradient-to-br ${gradient} flex items-center justify-center text-white mb-4`}>
        {icon}
      </div>
      <h3 className="text-xl font-bold text-white mb-2">{title}</h3>
      <p className="text-gray-400 text-sm mb-4">{description}</p>
      <div className="flex items-center justify-between">
        <span className="text-cyan-400 font-bold">{points}</span>
        <Zap className="w-5 h-5 text-yellow-400" />
      </div>
    </div>
  );

export default RewardCenterPage;
