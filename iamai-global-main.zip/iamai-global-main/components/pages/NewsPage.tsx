import React, { useState } from 'react';
import { Page } from '../../App';
import { ALL_AGENTS } from '../../agents';
import { Agent } from '../../constants';
import AgentDetailsModal, { AgentDetailsData } from '../modals/AgentDetailsModal';
import {
  getAgentDetailsById,
  AVAILABLE_AGENTS_DETAILS,
  COMING_SOON_AGENTS_DETAILS,
} from '../../data/agentDetailsData';
import { getAgentPageRoute } from '../../routes/agentRoutes';

interface NewsPageProps {
  onNavigate: (page: Page) => void;
  onSelectAgent?: (agent: Agent) => void;
}

// 50 Upcoming Agents with unique names, categories, and descriptions
const UPCOMING_AGENTS = [
  {
    id: 1,
    name: 'MedDoc Pro',
    category: 'Healthcare',
    role: 'Medical consultation assistant',
    description: 'Provides health information and wellness guidance',
  },
  {
    id: 2,
    name: 'LegalEase',
    category: 'Legal',
    role: 'Legal advisor',
    description: 'Assists with legal questions and document review',
  },
  {
    id: 3,
    name: 'FitCoach AI',
    category: 'Fitness',
    role: 'Personal trainer',
    description: 'Creates customized workout and nutrition plans',
  },
  {
    id: 4,
    name: 'FinanceGPT',
    category: 'Finance',
    role: 'Financial advisor',
    description: 'Provides investment and budgeting guidance',
  },
  {
    id: 5,
    name: 'TravelMate',
    category: 'Travel',
    role: 'Travel planner',
    description: 'Plans trips and finds best travel deals',
  },
  {
    id: 6,
    name: 'HomeDesign',
    category: 'Interior Design',
    role: 'Design consultant',
    description: 'Offers interior and home design suggestions',
  },
  {
    id: 7,
    name: 'CodeMaster',
    category: 'Programming',
    role: 'Code assistant',
    description: 'Helps with coding problems and solutions',
  },
  {
    id: 8,
    name: 'MusicMuse',
    category: 'Music',
    role: 'Music producer',
    description: 'Assists with music composition and production',
  },
  {
    id: 9,
    name: 'GameDev',
    category: 'Gaming',
    role: 'Game developer',
    description: 'Guides game development and design',
  },
  {
    id: 10,
    name: 'ArtStudio',
    category: 'Art',
    role: 'Art instructor',
    description: 'Teaches digital art and design techniques',
  },
  {
    id: 11,
    name: 'BusinessMentor',
    category: 'Business',
    role: 'Business consultant',
    description: 'Advises on business strategy and growth',
  },
  {
    id: 12,
    name: 'LanguageTutor',
    category: 'Education',
    role: 'Language teacher',
    description: 'Teaches multiple languages interactively',
  },
  {
    id: 13,
    name: 'ScienceExplorer',
    category: 'Science',
    role: 'Science mentor',
    description: 'Explains complex scientific concepts',
  },
  {
    id: 14,
    name: 'HistoryGuide',
    category: 'History',
    role: 'History expert',
    description: 'Provides historical insights and perspectives',
  },
  {
    id: 15,
    name: 'PhilosophyMind',
    category: 'Philosophy',
    role: 'Philosophical guide',
    description: 'Explores deep philosophical questions',
  },
  {
    id: 16,
    name: 'CareerPath',
    category: 'Career',
    role: 'Career coach',
    description: 'Guides career development and job search',
  },
  {
    id: 17,
    name: 'MentalWellness',
    category: 'Mental Health',
    role: 'Wellness coach',
    description: 'Supports mental health and mindfulness',
  },
  {
    id: 18,
    name: 'ChefAssistant',
    category: 'Cooking',
    role: 'Culinary expert',
    description: 'Provides recipes and cooking tips',
  },
  {
    id: 19,
    name: 'GreenLiving',
    category: 'Sustainability',
    role: 'Eco advisor',
    description: 'Promotes sustainable lifestyle choices',
  },
  {
    id: 20,
    name: 'PetCare',
    category: 'Pet Care',
    role: 'Pet consultant',
    description: 'Offers pet care and training advice',
  },
  {
    id: 21,
    name: 'FashionStylist',
    category: 'Fashion',
    role: 'Fashion consultant',
    description: 'Suggests style tips and outfit ideas',
  },
  {
    id: 22,
    name: 'DreamAnalyzer',
    category: 'Psychology',
    role: 'Dream interpreter',
    description: 'Analyzes and interprets dreams',
  },
  {
    id: 23,
    name: 'AstrologyGuide',
    category: 'Astrology',
    role: 'Astrology expert',
    description: 'Provides astrological insights and readings',
  },
  {
    id: 24,
    name: 'TechNews',
    category: 'Technology',
    role: 'Tech journalist',
    description: 'Keeps you updated on latest tech trends',
  },
  {
    id: 25,
    name: 'CryptoAnalyst',
    category: 'Cryptocurrency',
    role: 'Crypto advisor',
    description: 'Analyzes cryptocurrency markets and trends',
  },
  {
    id: 26,
    name: 'RealEstateExp',
    category: 'Real Estate',
    role: 'Property advisor',
    description: 'Helps with property search and investment',
  },
  {
    id: 27,
    name: 'AutoExpert',
    category: 'Automotive',
    role: 'Car specialist',
    description: 'Advises on vehicles and maintenance',
  },
  {
    id: 28,
    name: 'PhotographyPro',
    category: 'Photography',
    role: 'Photo guide',
    description: 'Teaches photography techniques',
  },
  {
    id: 29,
    name: 'MovieCritic',
    category: 'Entertainment',
    role: 'Film analyst',
    description: 'Reviews and discusses movies and shows',
  },
  {
    id: 30,
    name: 'BookwormBuddy',
    category: 'Literature',
    role: 'Literary guide',
    description: 'Recommends books and discusses literature',
  },
  {
    id: 31,
    name: 'SportsAnalyst',
    category: 'Sports',
    role: 'Sports commentator',
    description: 'Provides sports analysis and predictions',
  },
  {
    id: 32,
    name: 'FitnessNutri',
    category: 'Nutrition',
    role: 'Nutritionist',
    description: 'Creates personalized nutrition plans',
  },
  {
    id: 33,
    name: 'YogaMaster',
    category: 'Wellness',
    role: 'Yoga instructor',
    description: 'Guides yoga and meditation practices',
  },
  {
    id: 34,
    name: 'DanceMove',
    category: 'Dance',
    role: 'Dance choreographer',
    description: 'Teaches dance moves and choreography',
  },
  {
    id: 35,
    name: 'MarketingGuru',
    category: 'Marketing',
    role: 'Marketing strategist',
    description: 'Develops marketing campaigns',
  },
  {
    id: 36,
    name: 'DataDiver',
    category: 'Data Science',
    role: 'Data analyst',
    description: 'Analyzes data and provides insights',
  },
  {
    id: 37,
    name: 'CloudExpert',
    category: 'Cloud Computing',
    role: 'Cloud architect',
    description: 'Designs cloud infrastructure solutions',
  },
  {
    id: 38,
    name: 'AIResearcher',
    category: 'AI/ML',
    role: 'AI specialist',
    description: 'Explores AI and machine learning concepts',
  },
  {
    id: 39,
    name: 'SecurityGuard',
    category: 'Cybersecurity',
    role: 'Security expert',
    description: 'Provides cybersecurity and privacy tips',
  },
  {
    id: 40,
    name: 'NetworkPro',
    category: 'Networking',
    role: 'Network engineer',
    description: 'Designs and troubleshoots networks',
  },
  {
    id: 41,
    name: 'DatabaseMaster',
    category: 'Databases',
    role: 'Database admin',
    description: 'Manages and optimizes databases',
  },
  {
    id: 42,
    name: 'UIDesigner',
    category: 'Design',
    role: 'UI/UX designer',
    description: 'Creates beautiful user interfaces',
  },
  {
    id: 43,
    name: 'QASpecialist',
    category: 'Quality Assurance',
    role: 'QA engineer',
    description: 'Tests and ensures software quality',
  },
  {
    id: 44,
    name: 'DevOpsEngineer',
    category: 'DevOps',
    role: 'DevOps specialist',
    description: 'Streamlines deployment processes',
  },
  {
    id: 45,
    name: 'MobileDevApp',
    category: 'Mobile Development',
    role: 'App developer',
    description: 'Builds mobile applications',
  },
  {
    id: 46,
    name: 'WebMaster',
    category: 'Web Development',
    role: 'Web developer',
    description: 'Creates responsive websites',
  },
  {
    id: 47,
    name: 'BlockchainDev',
    category: 'Blockchain',
    role: 'Blockchain developer',
    description: 'Develops blockchain solutions',
  },
  {
    id: 48,
    name: 'IoTExplorer',
    category: 'IoT',
    role: 'IoT specialist',
    description: 'Designs IoT systems and devices',
  },
  {
    id: 49,
    name: 'VRCreator',
    category: 'Virtual Reality',
    role: 'VR developer',
    description: 'Creates immersive VR experiences',
  },
  {
    id: 50,
    name: 'ARExperiencer',
    category: 'Augmented Reality',
    role: 'AR specialist',
    description: 'Develops augmented reality applications',
  },
];

interface AgentCardProps {
  agent: (typeof UPCOMING_AGENTS)[0] | Agent;
  isAvailable?: boolean;
  onNavigate?: (page: Page) => void;
  onDetailsClick: (agentDetails: AgentDetailsData | null) => void;
  onSelectAgent?: (agent: Agent) => void;
}

const AgentCard: React.FC<AgentCardProps> = ({
  agent,
  isAvailable = false,
  onNavigate,
  onDetailsClick,
  onSelectAgent,
}) => {
  const renderAgentIcon = () => {
    if ('icon' in agent && agent.icon) {
      if (agent.icon.startsWith('data:image')) {
        return (
          <img
            src={agent.icon}
            alt={`${agent.name} icon`}
            className="w-full h-full object-cover rounded-lg"
          />
        );
      }

      if (agent.icon.includes('fa-')) {
        return <i className={`${agent.icon} text-cyan-400 text-2xl`} aria-hidden="true"></i>;
      }
    }

    return <i className="fa-solid fa-robot text-cyan-400 text-xl" aria-hidden="true"></i>;
  };

  const handleAccessClick = () => {
    if (isAvailable && onNavigate) {
      // For available agents (which are from ALL_AGENTS)
      if ('id' in agent && typeof agent.id === 'string') {
        const pageRoute = getAgentPageRoute(agent.id);
        if (onSelectAgent) {
          onSelectAgent(agent as Agent);
        }
        onNavigate(pageRoute);
      }
    }
  };

  const handleDetailsClick = () => {
    let details: AgentDetailsData | null = null;

    if ('id' in agent && typeof agent.id === 'string') {
      // Available agent
      details = AVAILABLE_AGENTS_DETAILS[agent.id] || null;
    } else {
      // Coming soon agent - find by name
      const nameLower = agent.name.toLowerCase().replace(/\s+/g, '-');
      details = COMING_SOON_AGENTS_DETAILS[nameLower] || null;

      // If no predefined details, create a default structure
      if (!details) {
        const agentCategory = 'category' in agent ? agent.category : 'General';
        details = {
          name: agent.name,
          role: agent.role,
          description: agent.description,
          icon: 'fa-solid fa-hourglass-end',
          category: agentCategory,
          overview: `${agent.name} is coming soon. This ${agentCategory.toLowerCase()} specialist will help with: ${agent.description}`,
          capabilities: [
            'Professional expertise in ' + agentCategory.toLowerCase(),
            'Specialized knowledge and skills',
            'Advanced features and functionality',
            'User-friendly interface',
            'Continuous learning and improvement',
            'Expert guidance and support',
          ],
          features: [
            'Coming soon - stay tuned for launch',
            'Expert features in development',
            'Advanced capabilities being created',
            'Professional-grade solutions',
            'Customized tools for your needs',
            'Seamless integration ready',
          ],
          howItWorks: [
            'This agent is currently in development',
            'Our team is building advanced features',
            'Expected launch: Q4 2025',
            'Join our waitlist for early access',
            'Get notified when it launches',
          ],
          benefits: [
            'Access to specialized expertise',
            'Professional-grade assistance',
            'Save time on complex tasks',
            'Improve productivity and efficiency',
            'Get expert guidance anytime',
          ],
          useCases: [
            'Professional assistance with ' + agentCategory.toLowerCase(),
            'Expert guidance and consultation',
            'Task automation and optimization',
            'Learning and skill development',
            'Problem-solving and strategy',
          ],
          keyStrengths: [
            'Expertise in ' + agentCategory,
            'Professional approach',
            'User-focused design',
            'Advanced capabilities',
            'Coming soon!',
          ],
          bestFor: `People seeking professional help with ${agentCategory.toLowerCase()} who want expert guidance and support`,
        } as AgentDetailsData;
      }
    }

    onDetailsClick(details);
  };

  return (
    <div className="bg-gradient-to-br from-gray-900/50 to-gray-800/30 border border-gray-700 rounded-xl overflow-hidden hover:border-cyan-500/50 transition-all duration-300 transform hover:-translate-y-1 group flex flex-col">
      <div className="p-6 flex flex-col flex-1">
        {/* Agent Icon/Avatar */}
        <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-cyan-500/20 to-blue-500/20 border border-cyan-500/30 flex items-center justify-center mb-4 group-hover:from-cyan-500/30 group-hover:to-blue-500/30 transition-colors">
          {renderAgentIcon()}
        </div>

        {/* Agent Details */}
        <h3 className="text-lg font-bold text-white mb-1">{agent.name}</h3>
        <p className="text-xs font-semibold text-cyan-400 uppercase tracking-wide mb-2">
          {'category' in agent ? agent.category : agent.role}
        </p>
        <p className="text-sm font-medium text-gray-300 mb-3">
          {'role' in agent && 'category' in agent ? agent.role : ''}
        </p>
        <p className="text-sm text-gray-400 mb-6 flex-1">{agent.description}</p>

        {/* Status Badge & Buttons */}
        <div className="space-y-3 mt-auto">
          {/* Badge */}
          <div className="flex items-center">
            {isAvailable ? (
              <span className="inline-flex items-center gap-2 px-3 py-1 bg-green-500/20 text-green-400 text-xs font-semibold rounded-full">
                <i className="fa-solid fa-check-circle"></i>
                Available
              </span>
            ) : (
              <span className="inline-flex items-center gap-2 px-3 py-1 bg-yellow-500/20 text-yellow-400 text-xs font-semibold rounded-full">
                <i className="fa-solid fa-hourglass-end"></i>
                Coming Soon
              </span>
            )}
          </div>

          {/* Two Buttons */}
          <div className="flex gap-2 w-full">
            {/* Primary Button */}
            <button
              onClick={isAvailable ? handleAccessClick : undefined}
              title={isAvailable ? `Access ${agent.name}` : `${agent.name} coming soon`}
              disabled={!isAvailable}
              className={`flex-1 px-3 py-2 rounded-lg border font-medium text-sm transition-all duration-300 ${
                isAvailable
                  ? 'bg-green-500/20 hover:bg-green-500/30 text-green-400 hover:text-green-300 border-green-500/50'
                  : 'bg-gray-800 text-gray-400 border-gray-700 cursor-not-allowed'
              }`}
            >
              {isAvailable ? 'Access →' : 'Coming Soon'}
            </button>

            {/* Details Button */}
            <button
              onClick={handleDetailsClick}
              title={`View details for ${agent.name}`}
              className="flex-1 px-3 py-2 bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-400 hover:text-cyan-300 rounded-lg border border-cyan-500/50 transition-all duration-300 font-medium text-sm"
            >
              Details
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

const NewsPage: React.FC<NewsPageProps> = ({ onNavigate, onSelectAgent }) => {
  const [selectedAgent, setSelectedAgent] = useState<AgentDetailsData | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleDetailsClick = (agentDetails: AgentDetailsData | null) => {
    setSelectedAgent(agentDetails);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setSelectedAgent(null);
  };

  return (
    <div className="min-h-screen py-20 md:py-28 bg-black">
      <AgentDetailsModal isOpen={isModalOpen} onClose={handleCloseModal} agent={selectedAgent} />

      <div className="container mx-auto px-6">
        {/* Header */}
        <div className="mb-16">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold tracking-tight mb-4 bg-clip-text text-transparent bg-gradient-to-r from-white via-gray-300 to-gray-400">
            Agents Marketplace
          </h1>
          <p className="max-w-3xl text-lg md:text-xl text-gray-400">
            Explore our collection of AI agents. Start with our 9 available agents or stay tuned for
            50 exciting new additions coming to the IA M AI platform.
          </p>
        </div>

        {/* Available Agents Section */}
        <div className="mb-20">
          <div className="mb-8">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-3">
              <i className="fa-solid fa-check-circle text-green-400 mr-3"></i>
              Available Now
            </h2>
            <p className="text-gray-400">
              Our 17 powerful AI agents ready to help you achieve your goals
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-12">
            {ALL_AGENTS.map(agent => (
              <AgentCard
                key={agent.id}
                agent={agent}
                isAvailable={true}
                onNavigate={onNavigate}
                onDetailsClick={handleDetailsClick}
                onSelectAgent={onSelectAgent}
              />
            ))}
          </div>
        </div>

        {/* Coming Soon Divider */}
        <div className="my-16 border-t border-gray-800"></div>

        {/* Coming Soon Agents Section */}
        <div className="mb-20">
          <div className="mb-8">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-3">
              <i className="fa-solid fa-hourglass-end text-yellow-400 mr-3"></i>
              Coming Soon
            </h2>
            <p className="text-gray-400">
              50 exciting new AI agents launching soon with specialized expertise across multiple
              domains
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-12">
            {UPCOMING_AGENTS.map(agent => (
              <AgentCard
                key={agent.id}
                agent={agent}
                isAvailable={false}
                onNavigate={onNavigate}
                onDetailsClick={handleDetailsClick}
                onSelectAgent={onSelectAgent}
              />
            ))}
          </div>
        </div>

        {/* Info Box */}
        <div className="max-w-4xl mx-auto bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border border-cyan-500/30 rounded-xl p-8 text-center">
          <h2 className="text-2xl font-bold text-white mb-3">Exciting Expansion</h2>
          <p className="text-gray-400 mb-6">
            We're constantly expanding our agent lineup with specialized AI assistants. These
            upcoming agents will bring new capabilities and expertise to our platform. Stay tuned
            for their launch!
          </p>
          <button
            onClick={() => onNavigate('home')}
            className="inline-block px-6 py-3 bg-cyan-500 hover:bg-cyan-600 text-black font-semibold rounded-lg transition-all duration-300 hover:shadow-lg hover:shadow-cyan-500/50"
          >
            ← Back to Home
          </button>
        </div>
      </div>
    </div>
  );
};

export default NewsPage;
