import React from 'react';
import type { Page } from '../../App';

const ValueCard: React.FC<{ icon: string; title: string; description: string }> = ({ icon, title, description }) => (
    <div className="bg-gray-900/50 p-8 rounded-2xl border border-gray-800 hover:border-cyan-400/50 transition-all duration-300 transform hover:-translate-y-2">
        <div className="mx-auto w-16 h-16 flex items-center justify-center rounded-xl bg-gray-800 mb-4 text-cyan-400">
            <i className={`${icon} text-3xl`}></i>
        </div>
        <h3 className="text-xl font-bold text-white mb-2">{title}</h3>
        <p className="text-gray-400">{description}</p>
    </div>
);


const AboutPage: React.FC<{ onNavigate: (page: Page) => void; }> = ({ onNavigate }) => {
  const values = [
    { icon: 'fa-solid fa-rocket', title: "Innovation at the Core", description: "We push the boundaries of AI, turning complex technology into accessible, character-driven experiences." },
    { icon: 'fa-solid fa-users', title: "Human-Centric Design", description: "Our agents are built to understand, assist, and collaborate with people in a natural and intuitive way." },
    { icon: 'fa-solid fa-shield-halved', title: "Ethical & Secure", description: "We are committed to building responsible AI with a foundation of privacy, security, and transparency." },
  ];

  return (
    <div className="bg-black text-white">
      {/* Hero Section */}
      <section className="py-20 md:py-32 text-center">
        <div className="container mx-auto px-6">
            <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight mb-4">Our Mission: Humanize AI</h1>
            <p className="max-w-3xl mx-auto text-lg md:text-xl text-gray-400">
                We believe the future of artificial intelligence isn't about replacing humans, but augmenting our potential. We're building a world where specialized, character-driven AI agents become trusted partners in creativity, productivity, and discovery.
            </p>
        </div>
      </section>

      {/* Intro Section */}
      <section className="py-20 md:py-28 bg-[#0a0a0a]">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-2xl md:text-3xl font-bold text-cyan-400 mb-2">AI Digital Friend</h2>
              <p className="text-xl text-gray-300 italic">Building emotionally intelligent, human-centric AI systems that redefine digital companionship.</p>
            </div>
            
            <div className="space-y-8 text-gray-300 leading-relaxed">
              <div>
                <h3 className="text-2xl font-bold text-white mb-4">Intro</h3>
                <p className="mb-4">
                  <span className="text-cyan-400 font-semibold">AI Digital Friend</span> is a product of <span className="text-cyan-400 font-semibold">Grand Pa United™</span>, a global alliance of innovators from the UAE, UK, and USA, united by a shared mission: to build emotionally intelligent, human-centric AI systems that redefine digital companionship.
                </p>
                <p className="mb-4">
                  This initiative is led by the visionary leadership of <span className="text-cyan-400 font-semibold">Mr. Chaudhary Mumtaz & Sons</span>, whose commitment to innovation, community empowerment, and ethical technology has shaped the foundation of the platform.
                </p>
                <p>
                  The focus is not just on tools, but on creating intelligent allies designed to support, understand, and evolve with users across cultures and contexts.
                </p>
              </div>

              <div>
                <h3 className="text-2xl font-bold text-white mb-4">Our Mission</h3>
                <p className="mb-4">
                  To develop modular, adaptive, and emotionally aware AI agents that enhance human life through intuitive interaction, deep learning, and ethical design.
                </p>
                <p className="mb-4">Each module is:</p>
                <ul className="space-y-2 mb-4">
                  <li className="flex items-start gap-3">
                    <span className="text-cyan-400 font-bold">•</span>
                    <span><span className="text-white font-semibold">Modular</span> – easily integrated and customized</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-cyan-400 font-bold">•</span>
                    <span><span className="text-white font-semibold">Intuitive</span> – seamless user experience across skill levels</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-cyan-400 font-bold">•</span>
                    <span><span className="text-white font-semibold">Intelligent</span> – advanced frameworks for real-time learning</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-cyan-400 font-bold">•</span>
                    <span><span className="text-white font-semibold">Companionable</span> – engages with empathy, not just efficiency</span>
                  </li>
                </ul>
                <p>
                  The aim is to bridge the gap between AI and human connection — making technology smarter and more relatable.
                </p>
              </div>

              <div>
                <h3 className="text-2xl font-bold text-white mb-4">Why AI Digital Friend?</h3>
                <p className="mb-4">
                  In a world full of automation, the future belongs to human-aware AI — systems that understand context, emotion, and intent.
                </p>
                <p className="mb-4">The platform is:</p>
                <ul className="space-y-2 mb-4">
                  <li className="flex items-start gap-3">
                    <span className="text-cyan-400 font-bold">•</span>
                    <span><span className="text-white font-semibold">Approachable</span> – friendly and natural interactions</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-cyan-400 font-bold">•</span>
                    <span><span className="text-white font-semibold">Adaptive</span> – continuously learning from user behavior</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-cyan-400 font-bold">•</span>
                    <span><span className="text-white font-semibold">Secure</span> – built with privacy and ethical safeguards</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-cyan-400 font-bold">•</span>
                    <span><span className="text-white font-semibold">Scalable</span> – enterprise-ready, global expansion possible</span>
                  </li>
                </ul>
                <p>
                  This is about building timeless technology that serves real needs, not just trends.
                </p>
              </div>

              <div>
                <h3 className="text-2xl font-bold text-white mb-4">The Road Ahead: Royal AI™</h3>
                <p className="mb-4">
                  Long-term vision: <span className="text-cyan-400 font-semibold">Royal AI™</span>, a next-generation ecosystem to push the boundaries of AI–human collaboration.
                </p>
                
                <div className="mb-6">
                  <h4 className="text-lg font-bold text-white mb-4">Phase I: Strategic Platforms</h4>
                  
                  <div className="mb-6 pl-4 border-l-2 border-cyan-500/30">
                    <h5 className="text-white font-semibold mb-2">Red Teaming Academy</h5>
                    <ul className="space-y-1 text-sm">
                      <li>• Secure, invite-only platform for ethical hacking and cybersecurity education.</li>
                      <li>• Hands-on labs, mentorship, prevention, and awareness.</li>
                      <li>• Youth empowerment and professional development.</li>
                    </ul>
                  </div>

                  <div className="pl-4 border-l-2 border-cyan-500/30">
                    <h5 className="text-white font-semibold mb-2">One Last AI Master</h5>
                    <ul className="space-y-1 text-sm">
                      <li>• An immersive AI multiverse with 50+ intelligent agents.</li>
                      <li>• Roles: emotional support, strategy, creativity, collaboration.</li>
                      <li>• Modular architecture for both enterprise and consumer use.</li>
                      <li>• Includes memory, voice, and visual intelligence.</li>
                      <li>• Goal: cinematic AI design — interactions that feel personal and purposeful.</li>
                    </ul>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-2xl font-bold text-white mb-4">Our Vision</h3>
                <p className="mb-4">
                  A future where AI and humanity co-create solutions, govern systems, and elevate global well-being.
                </p>
                <p className="mb-4">
                  <span className="text-cyan-400 font-semibold">AI Digital Friend</span> will be a trusted ally as AI becomes part of daily life. One day, AI could play a role in governance, education, and diplomacy — and this platform is preparing that infrastructure now.
                </p>
              </div>

              <div>
                <h3 className="text-2xl font-bold text-white mb-4">Strategic Platforms Overview</h3>
                
                <div className="mb-6 p-4 bg-gray-900/30 rounded-lg border border-gray-800">
                  <h4 className="text-white font-semibold mb-3">OneManArmy.ai</h4>
                  <ul className="space-y-2 text-sm">
                    <li>• Tactical platform for ethical hacking education.</li>
                    <li>• Real-world labs, AI-powered mentors, certification pathways.</li>
                    <li>• Youth-focused, premium, secure, invite-only.</li>
                  </ul>
                </div>

                <div className="p-4 bg-gray-900/30 rounded-lg border border-gray-800">
                  <h4 className="text-white font-semibold mb-3">OneLast.ai</h4>
                  <ul className="space-y-2 text-sm">
                    <li>• Cinematic AI multiverse with 50+ modular agents.</li>
                    <li>• Agents with memory, emotion, voice, and personality.</li>
                    <li>• Feels like cinematic storytelling.</li>
                    <li>• Deployable across terminal, web, and mobile.</li>
                    <li>• Enterprise-ready, scalable, customizable.</li>
                  </ul>
                </div>
              </div>

              <div>
                <h3 className="text-2xl font-bold text-white mb-4">Public Manifesto</h3>
                <p className="mb-4">
                  This is built for the public — the real stakeholders.
                </p>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-start gap-3">
                    <span className="text-cyan-400">✓</span>
                    <span>Every learner cracking their first exploit.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-cyan-400">✓</span>
                    <span>Every creator launching with an AI co-pilot.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-cyan-400">✓</span>
                    <span>Every dreamer who sees tech as a story, not just a tool.</span>
                  </li>
                </ul>
                
                <p className="mb-4">Belief:</p>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-start gap-3">
                    <span className="text-cyan-400 font-bold">→</span>
                    <span>Platforms should feel personal.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-cyan-400 font-bold">→</span>
                    <span>Agents should feel alive.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-cyan-400 font-bold">→</span>
                    <span>Every launch should feel cinematic.</span>
                  </li>
                </ul>
                
                <p className="text-lg font-semibold text-cyan-400">
                  Royal AI™: Every limitation becomes a legend. Every user becomes a collaborator.
                </p>
              </div>

              <div>
                <h3 className="text-2xl font-bold text-white mb-4">Acknowledgments</h3>
                <p>
                  Special thanks to <span className="text-cyan-400 font-semibold">Professor Johnny</span>, whose technical brilliance, creative direction, and strategic insight shaped the platform's architecture, branding, and strategy.
                </p>
                <p>
                  His work embodies <span className="text-cyan-400 italic">guerrilla-grade innovation</span> — turning constraints into creativity, and ideas into impact.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-20 md:py-28 bg-black">
         <div className="container mx-auto px-6">
            <div className="text-center mb-12">
                <h2 className="text-3xl md:text-4xl font-bold text-white">Our Core Values</h2>
            </div>
            <div className="max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8">
                {values.map(value => <ValueCard key={value.title} {...value} />)}
            </div>
         </div>
      </section>
      
      {/* Special Thanks Section */}
      <section className="py-20 md:py-28 bg-[#0a0a0a]">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto">
            <div className="bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border border-cyan-500/30 rounded-2xl p-8 md:p-12">
              <div className="flex items-start gap-4 mb-6">
                <i className="fa-solid fa-heart text-cyan-400 text-3xl flex-shrink-0 mt-1"></i>
                <div>
                  <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">Special Thanks</h2>
                  <div className="space-y-4 text-gray-300 leading-relaxed">
                    <p>
                      We would like to extend our deepest gratitude to <span className="text-cyan-400 font-semibold">Mr. Ben from Thailand</span>, whose invaluable support has been instrumental in bringing IA M AI to life.
                    </p>
                    <p>
                      Mr. Ben's generous contributions have been multifaceted and transformative. He has provided essential tools and resources that have streamlined our development process, and his substantial financial support has enabled us to push the boundaries of what we thought was possible. Beyond these tangible contributions, his belief in our vision and consistent encouragement have kept us motivated through every challenge.
                    </p>
                    <p>
                      His commitment to innovation and human-centric technology aligns perfectly with our mission. Without his partnership, partnership, dedication, and faith in this project, IA M AI simply would not exist in its current form. Mr. Ben embodies the spirit of collaboration that drives us forward.
                    </p>
                    <p className="italic text-cyan-300">
                      Mr. Ben, this project is as much your achievement as it is ours. Thank you for believing in us and in the future of AI.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Join Us CTA */}
      <section className="py-20 md:py-28 bg-black">
        <div className="container mx-auto px-6 text-center">
            <h2 className="text-3xl font-bold text-white">Want to Join Our Mission?</h2>
            <p className="max-w-xl mx-auto mt-4 text-gray-400">We're always looking for passionate people to help us build the future of AI. Check out our open roles.</p>
            <div className="mt-8">
                <button
                    onClick={() => onNavigate('careers')}
                    title="View open career positions"
                    className="bg-cyan-500 text-black font-semibold px-8 py-3 rounded-full hover:bg-cyan-400 transition-all duration-300 transform hover:scale-105"
                >
                    View Careers
                </button>
            </div>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;
