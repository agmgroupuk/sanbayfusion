import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  Zap,
  Globe,
  Network,
  Server,
  Shield,
  Code,
  FileText,
  Eye,
  Radio,
  Cpu,
  Lock,
  Crown,
  TrendingUp,
  Activity,
  AlertTriangle,
} from 'lucide-react';
import { authService } from '../../services/authService';

interface Tool {
  id: string;
  name: string;
  description: string;
  icon: React.ReactNode;
  category: string;
  comingSoon: boolean;
  features: string[];
  requiresPremium: boolean;
  subscriptionLevel: 'daily' | 'weekly' | 'monthly' | 'yearly' | 'free';
}

interface ToolboxPageProps {
  onNavigate?: (page: string) => void;
}

interface SubscriptionStatus {
  hasAccess: boolean;
  type: string;
  expiresAt?: Date;
  usageToday: number;
  usageLimit: number;
}

interface ToolboxDashboard {
  subscription: {
    type: string;
    expiresAt: string;
    isActive: boolean;
  };
  permissions: {
    canAccessNetworkTools: boolean;
    canAccessDomainTools: boolean;
    canAccessSecurityTools: boolean;
    canAccessUtilityTools: boolean;
    canAccessWebTools: boolean;
    canAccessMonitoringTools: boolean;
    canAccessDevelopmentTools: boolean;
    maxToolUsagePerDay: number;
    canExportResults: boolean;
  };
  usage: {
    today: {
      toolUsage: number;
      limit: number;
      toolsUsed: string[];
    };
    total: {
      toolUsage: number;
      favoriteTools: string[];
    };
  };
}

const DEFAULT_USAGE_LIMIT = 100;

const createDefaultDashboard = (): ToolboxDashboard => ({
  subscription: {
    type: 'Free',
    expiresAt: '',
    isActive: false,
  },
  permissions: {
    canAccessNetworkTools: false,
    canAccessDomainTools: false,
    canAccessSecurityTools: false,
    canAccessUtilityTools: false,
    canAccessWebTools: false,
    canAccessMonitoringTools: false,
    canAccessDevelopmentTools: false,
    maxToolUsagePerDay: DEFAULT_USAGE_LIMIT,
    canExportResults: false,
  },
  usage: {
    today: {
      toolUsage: 0,
      limit: DEFAULT_USAGE_LIMIT,
      toolsUsed: [],
    },
    total: {
      toolUsage: 0,
      favoriteTools: [],
    },
  },
});

const buildDefaultSubscriptionStatus = (): SubscriptionStatus => ({
  hasAccess: false,
  type: 'none',
  expiresAt: undefined,
  usageToday: 0,
  usageLimit: DEFAULT_USAGE_LIMIT,
});

const ToolboxPage: React.FC<ToolboxPageProps> = ({ onNavigate }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [subscriptionStatus, setSubscriptionStatus] = useState<SubscriptionStatus | null>(null);
  const [dashboard, setDashboard] = useState<ToolboxDashboard | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loading, setLoading] = useState(true);
  const [showSubscriptionModal, setShowSubscriptionModal] = useState(false);

  const applyVisitorDashboardState = useCallback(() => {
    setDashboard(createDefaultDashboard());
    setSubscriptionStatus(buildDefaultSubscriptionStatus());
  }, []);

  const applyDashboardData = useCallback((payload: ToolboxDashboard) => {
    setDashboard(payload);
    const normalizedType = (payload.subscription.type || 'free').toLowerCase();

    // Dashboard controls usage stats; global subscription controls access
    setSubscriptionStatus(prev => ({
      ...(prev ?? buildDefaultSubscriptionStatus()),
      type: normalizedType,
      usageToday: payload.usage?.today?.toolUsage ?? 0,
      usageLimit: payload.usage?.today?.limit ?? DEFAULT_USAGE_LIMIT,
    }));
  }, []);

  // Load dashboard data on mount
  useEffect(() => {
    const loadDashboard = async () => {
      try {
        const authenticated = authService.isAuthenticated();
        setIsAuthenticated(authenticated);

        if (!authenticated) {
          applyVisitorDashboardState();
          setLoading(false);
          return;
        }

        const response = await authService.authenticatedFetch('/api/toolbox/dashboard');

        if (response.ok) {
          const data = await response.json();
          if (data?.data) {
            applyDashboardData(data.data);
          } else {
            applyVisitorDashboardState();
          }
        } else if (response.status === 403) {
          // No subscription - show modal
          applyVisitorDashboardState();
          setShowSubscriptionModal(true);
        } else {
          applyVisitorDashboardState();
        }
      } catch (error) {
        console.error('Failed to load toolbox dashboard:', error);
        applyVisitorDashboardState();
      } finally {
        setLoading(false);
      }
    };

    loadDashboard();
  }, [applyDashboardData, applyVisitorDashboardState]);

  // Check unified IAMAI subscription status – any active plan unlocks all toolbox tools
  useEffect(() => {
    const checkGlobalSubscription = async () => {
      try {
        const authenticated = authService.isAuthenticated();
        if (!authenticated) {
          setSubscriptionStatus(buildDefaultSubscriptionStatus());
          return;
        }

        const response = await authService.authenticatedFetch('/api/subscription/current');
        if (response.ok) {
          const data = await response.json();
          const hasActiveSubscription = Boolean(data?.subscription && data.status === 'ACTIVE');
          const normalizedPlan = hasActiveSubscription
            ? (data.subscription.plan || 'MONTHLY').toLowerCase()
            : 'none';

          setSubscriptionStatus(prev => ({
            ...(prev ?? buildDefaultSubscriptionStatus()),
            hasAccess: hasActiveSubscription,
            type: normalizedPlan,
            expiresAt:
              hasActiveSubscription && data.subscription.billing?.currentPeriodEnd
                ? new Date(data.subscription.billing.currentPeriodEnd)
                : undefined,
          }));
        } else {
          setSubscriptionStatus(prev => ({
            ...(prev ?? buildDefaultSubscriptionStatus()),
            hasAccess: false,
          }));
        }
      } catch (error) {
        console.error('Failed to check global subscription status for toolbox:', error);
        setSubscriptionStatus(prev => ({
          ...(prev ?? buildDefaultSubscriptionStatus()),
          hasAccess: false,
        }));
      }
    };

    checkGlobalSubscription();
  }, []);

  const derivedDashboard = useMemo(() => dashboard ?? createDefaultDashboard(), [dashboard]);
  const derivedSubscriptionStatus = useMemo(
    () => subscriptionStatus ?? buildDefaultSubscriptionStatus(),
    [subscriptionStatus]
  );

  // Unified rule: any active IAMAI subscription unlocks toolbox
  const hasSubscriptionAccess = Boolean(isAuthenticated && derivedSubscriptionStatus.hasAccess);

  const usageLimit = hasSubscriptionAccess
    ? derivedDashboard.usage.today.limit
    : derivedSubscriptionStatus.usageLimit;
  const usageCount = hasSubscriptionAccess
    ? derivedDashboard.usage.today.toolUsage
    : derivedSubscriptionStatus.usageToday;
  const usagePercent = usageLimit > 0 ? Math.min((usageCount / usageLimit) * 100, 100) : 0;
  const toolsUsedCount = hasSubscriptionAccess ? derivedDashboard.usage.today.toolsUsed.length : 0;

  const subscriptionLabel = hasSubscriptionAccess
    ? derivedDashboard.subscription.type
    : isAuthenticated
      ? 'No Active Plan'
      : 'Visitor';

  const expiresLabel =
    hasSubscriptionAccess && derivedDashboard.subscription.expiresAt
      ? new Date(derivedDashboard.subscription.expiresAt).toLocaleDateString('en-US', {
          year: 'numeric',
          month: 'short',
          day: 'numeric',
        })
      : isAuthenticated
        ? 'No active subscription'
        : '—';

  const subscriptionHelperText = hasSubscriptionAccess
    ? `Expires: ${expiresLabel}`
    : isAuthenticated
      ? 'Upgrade to activate your plan'
      : 'Log in to subscribe for access';

  const statusText = hasSubscriptionAccess ? 'Active' : isAuthenticated ? 'Not Active' : 'Visitor';
  const statusDescription = hasSubscriptionAccess
    ? 'All systems operational'
    : isAuthenticated
      ? 'Upgrade to unlock toolbox'
      : 'Log in to access tools';
  const statusColor = hasSubscriptionAccess
    ? 'text-green-400'
    : isAuthenticated
      ? 'text-yellow-400'
      : 'text-gray-400';

  const usageHelperText = hasSubscriptionAccess
    ? 'Tools used today'
    : isAuthenticated
      ? 'Upgrade for higher limits'
      : 'Sign in to start using tools';

  const toolsHelperText = hasSubscriptionAccess
    ? 'Different tools today'
    : isAuthenticated
      ? 'Start using tools to see stats'
      : 'Log in to track usage';

  const tools: Tool[] = [
    {
      id: 'ip-info',
      name: 'IP Info Lookup',
      description:
        'Get detailed information about any IP address including location, ISP, organization, and network details.',
      icon: <Globe className="w-8 h-8" />,
      category: 'network',
      comingSoon: false,
      requiresPremium: false,
      subscriptionLevel: 'daily',
      features: ['Geolocation', 'ISP Info', 'Hostname Resolution', 'Network Type'],
    },
    {
      id: 'dns-lookup',
      name: 'DNS Lookup',
      description:
        'Perform DNS queries to find A, AAAA, MX, TXT, and other DNS records for any domain.',
      icon: <Network className="w-8 h-8" />,
      category: 'network',
      comingSoon: false,
      requiresPremium: false,
      subscriptionLevel: 'daily',
      features: ['A Records', 'MX Records', 'TXT Records', 'Name Server Info'],
    },
    {
      id: 'whois',
      name: 'WHOIS Lookup',
      description:
        'Look up domain registration details, registrar information, and ownership data.',
      icon: <FileText className="w-8 h-8" />,
      category: 'domain',
      comingSoon: false,
      requiresPremium: false,
      subscriptionLevel: 'daily',
      features: ['Domain Owner', 'Registrar Info', 'Registration Date', 'Expiration Date'],
    },
    {
      id: 'ping-test',
      name: 'Ping Test',
      description: 'Test the reachability of a host on an IP network and measure latency.',
      icon: <Radio className="w-8 h-8" />,
      category: 'network',
      comingSoon: false,
      requiresPremium: false,
      subscriptionLevel: 'daily',
      features: ['Latency Measurement', 'Packet Loss', 'Connection Status', 'Response Time'],
    },
    {
      id: 'port-scanner',
      name: 'Port Scanner',
      description: 'Scan for open ports on a server and identify running services.',
      icon: <Server className="w-8 h-8" />,
      category: 'security',
      comingSoon: false,
      requiresPremium: true,
      subscriptionLevel: 'weekly',
      features: ['Port Detection', 'Service Identification', 'Vulnerability Check', 'Port Status'],
    },
    {
      id: 'ssl-checker',
      name: 'SSL Certificate Checker',
      description: 'Verify SSL/TLS certificate details, expiration dates, and security issues.',
      icon: <Shield className="w-8 h-8" />,
      category: 'security',
      comingSoon: false,
      requiresPremium: true,
      subscriptionLevel: 'weekly',
      features: ['Certificate Details', 'Expiration Warning', 'Chain Validation', 'Security Grade'],
    },
    {
      id: 'url-encoder',
      name: 'URL Encoder/Decoder',
      description: 'Encode and decode URLs, handle special characters and percent-encoding.',
      icon: <Code className="w-8 h-8" />,
      category: 'utilities',
      comingSoon: false,
      requiresPremium: false,
      subscriptionLevel: 'daily',
      features: ['URL Encoding', 'URL Decoding', 'Base64 Support', 'Character Mapping'],
    },
    {
      id: 'header-checker',
      name: 'HTTP Header Checker',
      description: 'Analyze HTTP headers and response codes from web servers.',
      icon: <Eye className="w-8 h-8" />,
      category: 'web',
      comingSoon: false,
      requiresPremium: true,
      subscriptionLevel: 'weekly',
      features: ['Response Headers', 'Status Codes', 'Server Info', 'Security Headers'],
    },
    {
      id: 'uptime-monitor',
      name: 'Uptime Monitor',
      description: 'Monitor website uptime, downtime, and get real-time status alerts.',
      icon: <Cpu className="w-8 h-8" />,
      category: 'monitoring',
      comingSoon: true,
      requiresPremium: true,
      subscriptionLevel: 'monthly',
      features: ['Real-time Monitoring', 'Uptime History', 'Alert System', 'Status Page'],
    },
    {
      id: 'api-tester',
      name: 'API Testing Tool',
      description:
        'Test API endpoints with custom headers, methods, and request bodies in real-time.',
      icon: <Zap className="w-8 h-8" />,
      category: 'development',
      comingSoon: false,
      requiresPremium: true,
      subscriptionLevel: 'weekly',
      features: ['All HTTP Methods', 'Custom Headers', 'Request Body', 'Real-time Response'],
    },
    {
      id: 'domain-research-suite',
      name: 'Domain Research Suite',
      description:
        'Comprehensive domain intelligence with WHOIS data, historical records, and related domain discovery.',
      icon: <FileText className="w-8 h-8" />,
      category: 'domain',
      comingSoon: false,
      requiresPremium: false,
      subscriptionLevel: 'daily',
      features: ['WHOIS Data', 'Historical Records', 'Related Domains', 'Monitoring'],
    },
    {
      id: 'screenshot-api',
      name: 'Website Screenshot',
      description:
        'Capture high-quality screenshots of any website with custom dimensions, device presets, and configurable quality.',
      icon: <Eye className="w-8 h-8" />,
      category: 'web',
      comingSoon: false,
      requiresPremium: true,
      subscriptionLevel: 'weekly',
      features: ['Device Presets', 'Custom Dimensions', 'Full Page', 'Multiple Formats'],
    },
    {
      id: 'email-verification',
      name: 'Email Verification',
      description:
        'Validate email addresses with syntax check, domain validation, SMTP verification, and disposable email detection.',
      icon: <Shield className="w-8 h-8" />,
      category: 'security',
      comingSoon: false,
      requiresPremium: true,
      subscriptionLevel: 'weekly',
      features: ['Format Check', 'SMTP Validation', 'Disposable Detection', 'Bulk Verification'],
    },
    {
      id: 'ip-netblocks',
      name: 'IP Netblocks Lookup',
      description:
        'Discover IP ranges and netblock information with CIDR notation, network details, and organization data.',
      icon: <Network className="w-8 h-8" />,
      category: 'network',
      comingSoon: false,
      requiresPremium: false,
      subscriptionLevel: 'daily',
      features: ['CIDR Lookup', 'Network Info', 'Organization Details', 'IP Range Analysis'],
    },
    {
      id: 'domain-reputation',
      name: 'Domain Reputation',
      description:
        'Check domain reputation with threat scoring, malware detection, phishing analysis, and security ratings.',
      icon: <Shield className="w-8 h-8" />,
      category: 'security',
      comingSoon: false,
      requiresPremium: true,
      subscriptionLevel: 'weekly',
      features: ['Threat Score', 'Malware Check', 'Phishing Detection', 'Risk Analysis'],
    },
    {
      id: 'website-categorization',
      name: 'Website Categorization',
      description:
        'Automatically classify websites into IAB categories with confidence scores and content analysis.',
      icon: <FileText className="w-8 h-8" />,
      category: 'web',
      comingSoon: false,
      requiresPremium: true,
      subscriptionLevel: 'weekly',
      features: ['IAB Categories', 'Content Classification', 'Confidence Scores', 'Multi-Category'],
    },
    {
      id: 'domain-availability',
      name: 'Domain Availability',
      description:
        'Check domain availability across multiple TLDs with bulk checking and alternative suggestions.',
      icon: <Globe className="w-8 h-8" />,
      category: 'domain',
      comingSoon: false,
      requiresPremium: false,
      subscriptionLevel: 'daily',
      features: ['Multi-TLD Check', 'Bulk Search', 'Suggestions', 'Price Comparison'],
    },
    {
      id: 'mac-address',
      name: 'MAC Address Lookup',
      description:
        'Identify device manufacturers from MAC addresses using the IEEE OUI database with vendor information.',
      icon: <Server className="w-8 h-8" />,
      category: 'network',
      comingSoon: false,
      requiresPremium: false,
      subscriptionLevel: 'daily',
      features: ['Vendor Lookup', 'OUI Database', 'Device Type', 'Manufacturer Info'],
    },
    {
      id: 'threat-intelligence',
      name: 'Threat Intelligence',
      description:
        'Advanced threat analysis for IPs and domains with IOC detection, risk scoring, and security insights.',
      icon: <Shield className="w-8 h-8" />,
      category: 'security',
      comingSoon: false,
      requiresPremium: true,
      subscriptionLevel: 'weekly',
      features: ['IOC Detection', 'Risk Scoring', 'Threat Analysis', 'Security Reports'],
    },
  ];

  const categories = [
    { id: 'all', name: 'All Tools' },
    { id: 'network', name: 'Network' },
    { id: 'domain', name: 'Domain' },
    { id: 'security', name: 'Security' },
    { id: 'utilities', name: 'Utilities' },
    { id: 'web', name: 'Web' },
    { id: 'monitoring', name: 'Monitoring' },
    { id: 'development', name: 'Development' },
  ];

  const filteredTools =
    selectedCategory === 'all' ? tools : tools.filter(tool => tool.category === selectedCategory);

  const handleToolClick = (tool: Tool) => {
    if (!hasSubscriptionAccess) {
      setShowSubscriptionModal(true);
      return;
    }

    // Any paid, active subscription unlocks all tools
    if (onNavigate) {
      onNavigate(tool.id);
    }
  };

  const checkSubscriptionLevel = (requiredLevel: string): boolean => {
    if (!subscriptionStatus) return false;

    const levels = ['daily', 'weekly', 'monthly', 'yearly'];
    const currentLevel = levels.indexOf(subscriptionStatus.type);
    const required = levels.indexOf(requiredLevel);

    return currentLevel >= required;
  };

  const getSubscriptionBadge = (level: string) => {
    const badges = {
      daily: { text: 'Basic', color: 'bg-green-500' },
      weekly: { text: 'Pro', color: 'bg-blue-500' },
      monthly: { text: 'Premium', color: 'bg-purple-500' },
      yearly: { text: 'Enterprise', color: 'bg-yellow-500' },
    };
    return badges[level as keyof typeof badges] || badges.daily;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin w-12 h-12 border-2 border-cyan-500 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-gray-400">Loading Toolbox...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Subscription Modal */}
      {showSubscriptionModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-gray-900 rounded-2xl border border-gray-800 p-8 max-w-md w-full">
            <div className="text-center mb-6">
              <Lock className="w-16 h-16 text-cyan-400 mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-white mb-2">Active Subscription Required</h3>
              <p className="text-gray-400">
                Toolbox access requires an active subscription to any IAMAI agent. Subscribe or
                renew your daily, weekly, or monthly plan to unlock all tools.
              </p>
            </div>

            <div className="space-y-4 mb-6">
              <div className="bg-gray-800 rounded-lg p-4">
                <div className="flex items-center gap-3 mb-2">
                  <Crown className="w-5 h-5 text-yellow-400" />
                  <span className="font-semibold">Premium Features</span>
                </div>
                <ul className="text-sm text-gray-400 space-y-1">
                  <li>• Access to all toolbox tools</li>
                  <li>• Unlimited daily usage</li>
                  <li>• Advanced analytics</li>
                  <li>• Export capabilities</li>
                </ul>
              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => setShowSubscriptionModal(false)}
                className="flex-1 px-4 py-2 bg-gray-800 hover:bg-gray-700 rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  setShowSubscriptionModal(false);
                  if (onNavigate) onNavigate('ai-lab');
                }}
                className="flex-1 px-4 py-2 bg-cyan-500 hover:bg-cyan-600 rounded-lg transition-colors font-semibold"
              >
                Upgrade Now
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Dashboard Section */}
      {!loading && (
        <section className="py-8 bg-gray-950/50 border-b border-gray-800">
          <div className="container mx-auto px-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              {/* Subscription Status */}
              <div className="bg-gray-900/50 rounded-lg p-4 border border-gray-800">
                <div className="flex items-center gap-3 mb-2">
                  <Crown className="w-5 h-5 text-yellow-400" />
                  <span className="font-semibold">Subscription</span>
                </div>
                <p className="text-2xl font-bold text-cyan-400">{subscriptionLabel}</p>
                <p className="text-sm text-gray-400">{subscriptionHelperText}</p>
              </div>

              {/* Usage Today */}
              <div className="bg-gray-900/50 rounded-lg p-4 border border-gray-800">
                <div className="flex items-center gap-3 mb-2">
                  <Activity
                    className={`w-5 h-5 ${hasSubscriptionAccess ? 'text-green-400' : 'text-gray-500'}`}
                  />
                  <span className="font-semibold">Usage Today</span>
                </div>
                <p
                  className={`text-2xl font-bold ${
                    hasSubscriptionAccess ? 'text-green-400' : 'text-gray-400'
                  }`}
                >
                  {usageCount}/{usageLimit}
                </p>
                <div className="w-full bg-gray-800 rounded-full h-2 mt-2">
                  <div
                    className={`${hasSubscriptionAccess ? 'bg-green-400' : 'bg-gray-600'} h-2 rounded-full`}
                    style={{ width: `${usagePercent}%` }}
                  ></div>
                </div>
                <p className="text-sm text-gray-400 mt-2">{usageHelperText}</p>
              </div>

              {/* Tools Used */}
              <div className="bg-gray-900/50 rounded-lg p-4 border border-gray-800">
                <div className="flex items-center gap-3 mb-2">
                  <TrendingUp
                    className={`w-5 h-5 ${hasSubscriptionAccess ? 'text-blue-400' : 'text-gray-500'}`}
                  />
                  <span className="font-semibold">Tools Used</span>
                </div>
                <p
                  className={`text-2xl font-bold ${hasSubscriptionAccess ? 'text-blue-400' : 'text-gray-400'}`}
                >
                  {toolsUsedCount}
                </p>
                <p className="text-sm text-gray-400">{toolsHelperText}</p>
              </div>

              {/* Status */}
              <div className="bg-gray-900/50 rounded-lg p-4 border border-gray-800">
                <div className="flex items-center gap-3 mb-2">
                  <AlertTriangle className={`w-5 h-5 ${statusColor}`} />
                  <span className="font-semibold">Status</span>
                </div>
                <p className={`text-2xl font-bold ${statusColor}`}>{statusText}</p>
                <p className="text-sm text-gray-400">{statusDescription}</p>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 md:py-32">
        <div className="absolute inset-0 bg-grid-gray-900 [mask-image:linear-gradient(to_bottom,white_30%,transparent)]"></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-cyan-500/10 rounded-full blur-3xl"></div>

        <div className="container mx-auto px-6 text-center relative z-10">
          <div className="mb-6 inline-flex items-center gap-2 px-4 py-2 bg-cyan-500/10 rounded-full border border-cyan-500/30">
            <Zap className="w-4 h-4 text-cyan-400" />
            <span className="text-sm font-medium text-cyan-400">
              {subscriptionStatus?.hasAccess
                ? 'Premium Developer Tools'
                : 'Powerful Developer Tools'}
            </span>
          </div>

          <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight mb-4 bg-clip-text text-transparent bg-gradient-to-b from-white to-gray-400">
            IAMAI Toolbox
            {subscriptionStatus?.hasAccess && (
              <Crown className="inline-block w-8 h-8 text-yellow-400 ml-2" />
            )}
          </h1>

          <div className="flex justify-center mb-4">
            <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold border border-emerald-400/50 bg-emerald-500/10 text-emerald-300">
              <Crown className="w-3 h-3" />
              Included with any active subscription
            </span>
          </div>

          <p className="max-w-3xl mx-auto text-lg md:text-xl text-gray-400 mb-8">
            A comprehensive suite of networking, security, and development tools designed to help
            developers, administrators, and security professionals get their work done faster.
          </p>

          <div className="flex gap-4 justify-center">
            <button
              onClick={() => onNavigate?.('contact')}
              className="px-8 py-3 bg-gradient-to-r from-cyan-500 to-purple-500 text-black font-semibold rounded-lg hover:shadow-lg hover:shadow-cyan-500/50 transition-all duration-300 transform hover:scale-105"
            >
              Get Started
            </button>
            <button
              onClick={() => onNavigate?.('documentation')}
              className="px-8 py-3 bg-gray-900 text-white font-semibold rounded-lg border border-cyan-500/50 hover:border-cyan-400 hover:bg-gray-800/50 transition-colors"
            >
              Learn More
            </button>
          </div>
        </div>
      </section>

      {/* Category Filter */}
      <section className="py-8 border-b border-gray-800 bg-[#0a0a0a]">
        <div className="max-w-6xl mx-auto px-6">
          <div className="flex flex-wrap gap-2 justify-center">
            {categories.map(cat => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-4 py-2 rounded-lg font-medium transition-all ${
                  selectedCategory === cat.id
                    ? 'bg-gradient-to-r from-cyan-500 to-purple-500 text-black'
                    : 'bg-gray-900 text-gray-400 border border-gray-800 hover:border-cyan-500/50 hover:text-cyan-400'
                }`}
              >
                {cat.name}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Tools Grid */}
      <section className="py-16 bg-black">
        <div className="max-w-6xl mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredTools.map(tool => {
              const hasAccess = subscriptionStatus?.hasAccess;
              // Any active subscription unlocks all tools
              const isLocked = !hasAccess;
              const badge = getSubscriptionBadge(tool.subscriptionLevel);

              return (
                <div
                  key={tool.id}
                  className={`group relative bg-gray-900/50 border border-gray-800 rounded-2xl p-6 flex flex-col items-start space-y-4 transition-all duration-300 transform hover:-translate-y-1 ${
                    isLocked ? 'opacity-75' : 'hover:border-cyan-500/50 hover:bg-gray-900'
                  }`}
                >
                  {/* Lock Overlay */}
                  {isLocked && (
                    <div className="absolute inset-0 bg-black/30 backdrop-blur-[1px] rounded-2xl flex items-center justify-center z-10">
                      <div className="text-center">
                        <Lock className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                        <p className="text-xs text-gray-400">Subscription Required</p>
                      </div>
                    </div>
                  )}

                  {/* Premium Badge */}
                  {tool.requiresPremium && (
                    <div className="absolute top-4 right-4 z-20">
                      <div
                        className={`inline-flex items-center gap-1 px-3 py-1 ${badge.color} rounded-full`}
                      >
                        <Crown className="w-3 h-3 text-white" />
                        <span className="text-xs font-semibold text-white">{badge.text}</span>
                      </div>
                    </div>
                  )}

                  {/* Coming Soon Badge */}
                  {tool.comingSoon && (
                    <div className="absolute top-4 left-4 z-20 inline-flex items-center gap-1 px-3 py-1 bg-yellow-500/10 border border-yellow-500/30 rounded-full">
                      <span className="w-2 h-2 bg-yellow-500 rounded-full animate-pulse"></span>
                      <span className="text-xs font-semibold text-yellow-400">Coming Soon</span>
                    </div>
                  )}

                  {/* Icon */}
                  <div
                    className={`w-12 h-12 flex items-center justify-center rounded-lg ${
                      isLocked
                        ? 'bg-gray-800 text-gray-500'
                        : 'bg-gray-800 text-cyan-400 group-hover:bg-cyan-500/20'
                    }`}
                  >
                    {tool.icon}
                  </div>

                  {/* Tool Name */}
                  <h3 className={`text-xl font-bold ${isLocked ? 'text-gray-500' : 'text-white'}`}>
                    {tool.name}
                  </h3>

                  {/* Description */}
                  <p
                    className={`text-sm leading-relaxed flex-grow ${
                      isLocked ? 'text-gray-500' : 'text-gray-400'
                    }`}
                  >
                    {tool.description}
                  </p>

                  {/* Subscription Level */}
                  <div className="w-full">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-xs font-semibold text-gray-500 uppercase tracking-wide">
                        Subscription Level
                      </span>
                      <span className={`text-xs px-2 py-1 rounded-full ${badge.color} text-white`}>
                        {badge.text}
                      </span>
                    </div>
                  </div>

                  {/* Features */}
                  <div className="w-full space-y-2">
                    <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide">
                      Features
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {tool.features.slice(0, 3).map((feature, idx) => (
                        <span
                          key={idx}
                          className={`inline-flex items-center px-2 py-1 text-xs rounded border ${
                            isLocked
                              ? 'bg-gray-800 text-gray-500 border-gray-700'
                              : 'bg-gray-800 text-gray-300 border-gray-700 hover:border-cyan-500/50'
                          }`}
                        >
                          {feature}
                        </span>
                      ))}
                      {tool.features.length > 3 && (
                        <span className="text-xs text-gray-500">
                          +{tool.features.length - 3} more
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Category Badge */}
                  <div className="w-full pt-4 border-t border-gray-800">
                    <span
                      className={`inline-flex items-center px-3 py-1 text-xs font-medium rounded-full capitalize ${
                        isLocked ? 'bg-gray-800/50 text-gray-500' : 'bg-gray-800/50 text-gray-400'
                      }`}
                    >
                      {tool.category}
                    </span>
                  </div>

                  {/* Button */}
                  <button
                    disabled={tool.comingSoon}
                    onClick={() => handleToolClick(tool)}
                    className={`w-full py-2 px-4 rounded-lg font-semibold transition-all ${
                      tool.comingSoon
                        ? 'bg-gray-800 text-gray-500 cursor-not-allowed'
                        : isLocked
                          ? 'bg-gray-800 text-gray-400 hover:bg-gray-700 border border-gray-600'
                          : 'bg-gradient-to-r from-cyan-500 to-purple-500 text-black hover:shadow-lg hover:shadow-cyan-500/50 active:scale-95'
                    }`}
                  >
                    {tool.comingSoon ? 'Coming Soon' : isLocked ? 'Upgrade to Access' : 'Try Now'}
                  </button>
                </div>
              );
            })}
          </div>

          {/* No results message */}
          {filteredTools.length === 0 && (
            <div className="text-center py-12">
              <p className="text-gray-400 text-lg">No tools found in this category.</p>
            </div>
          )}
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 md:py-28 bg-[#0a0a0a]">
        <div className="container mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-white">Why Choose IAMAI Toolbox?</h2>
            <p className="max-w-2xl mx-auto mt-4 text-gray-400">
              Built for professionals who demand accuracy and reliability
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                title: 'Fast & Reliable',
                description:
                  'Lightning-fast results with 99.9% uptime guarantee for critical tools.',
                icon: '⚡',
              },
              {
                title: 'Easy to Use',
                description:
                  'Simple, intuitive interface that anyone can use without technical knowledge.',
                icon: '🎯',
              },
              {
                title: 'Subscription Based',
                description: 'Transparent pricing with different tiers for various usage needs.',
                icon: '💳',
              },
              {
                title: 'Secure & Private',
                description:
                  'Your data is encrypted and never stored. Complete privacy guaranteed.',
                icon: '🔒',
              },
              {
                title: 'Regular Updates',
                description: 'New tools and features added regularly based on user feedback.',
                icon: '🔄',
              },
              {
                title: 'API Access',
                description: 'Integrate tools into your applications with our comprehensive API.',
                icon: '🔌',
              },
            ].map((feature, idx) => (
              <div
                key={idx}
                className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6 flex flex-col items-start space-y-4 hover:border-cyan-500/50 hover:bg-gray-900 transition-all duration-300 transform hover:-translate-y-1"
              >
                <div className="text-3xl">{feature.icon}</div>
                <h3 className="text-lg font-bold text-white">{feature.title}</h3>
                <p className="text-gray-400 text-sm">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action Section */}
      <section className="py-20 md:py-28 bg-black">
        <div className="container mx-auto px-6">
          <div className="relative bg-gradient-to-r from-cyan-500 to-purple-500 rounded-2xl p-10 md:p-16 text-center overflow-hidden">
            {/* Background elements */}
            <div className="absolute inset-0 opacity-10">
              <div className="absolute top-0 left-0 w-40 h-40 bg-white rounded-full -translate-x-1/2 -translate-y-1/2"></div>
              <div className="absolute bottom-0 right-0 w-40 h-40 bg-white rounded-full translate-x-1/2 translate-y-1/2"></div>
            </div>

            <div className="relative z-10">
              <h2 className="text-3xl md:text-4xl font-bold text-black mb-4">
                Ready to Get Started?
              </h2>
              <p className="text-gray-900 text-lg mb-8 max-w-2xl mx-auto">
                Start using IAMAI tools today and supercharge your workflow. All tools are designed
                with performance and reliability in mind.
              </p>

              <div className="flex gap-4 justify-center">
                <button
                  onClick={() => onNavigate?.('contact')}
                  className="px-8 py-3 bg-black text-white font-semibold rounded-lg hover:bg-gray-800 transition-all duration-300 transform hover:scale-105"
                >
                  Get in Touch
                </button>
                <button
                  onClick={() => onNavigate?.('live-support')}
                  className="px-8 py-3 bg-black text-white font-semibold rounded-lg border border-white hover:bg-gray-800 transition-colors"
                >
                  Contact Support
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 md:py-28 bg-[#0a0a0a]">
        <div className="container mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-2">
              Frequently Asked Questions
            </h2>
          </div>

          <div className="max-w-3xl mx-auto space-y-6">
            {[
              {
                q: 'Do I need a subscription to use the toolbox?',
                a: "Yes. Toolbox access is tied to your active subscriptions. If you don't have an active plan, you'll see a prompt to subscribe before using tools.",
              },
              {
                q: 'What subscription levels are available?',
                a: 'We offer simple per-agent plans: Daily ($1), Weekly ($5), and Monthly ($19). There is no free plan—any active daily, weekly, or monthly subscription counts as Active.',
              },
              {
                q: 'Is my data secure?',
                a: 'Absolutely. All data is encrypted in transit and at rest. We never store or sell your information.',
              },
              {
                q: 'Can I use these tools with an API?',
                a: 'Yes, API access is included with all subscription levels. Higher tiers get increased rate limits and priority support.',
              },
              {
                q: 'What happens if I reach my daily limit?',
                a: 'Usage resets daily at midnight UTC. You can upgrade your subscription for higher limits or wait for the reset.',
              },
            ].map((item, idx) => (
              <div
                key={idx}
                className="bg-gray-900/50 border border-gray-800 rounded-lg p-6 hover:border-cyan-500/50 transition-all"
              >
                <h3 className="text-lg font-bold text-white mb-2">Q: {item.q}</h3>
                <p className="text-gray-400">A: {item.a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default ToolboxPage;
