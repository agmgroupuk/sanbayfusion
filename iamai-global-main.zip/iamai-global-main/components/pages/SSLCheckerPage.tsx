import React, { useState, useEffect } from 'react';
import { ArrowLeft, Shield, Search, Lock, AlertTriangle, CheckCircle, Calendar, Clock, Key, Server, Info, TrendingUp, Download, Copy, Check, RefreshCw, AlertCircle, XCircle } from 'lucide-react';

interface Props { onNavigate?: (page: string) => void }

interface SSLResult {
  valid: boolean;
  issuer: string;
  subject: string;
  validFrom: string;
  validTo: string;
  daysRemaining: number;
  protocol: string;
  cipher: string;
  bits: number;
  serialNumber?: string;
  fingerprint?: string;
  altNames?: string[];
  chain?: CertificateChain[];
}

interface CertificateChain {
  subject: string;
  issuer: string;
  validFrom: string;
  validTo: string;
}

interface HistoryEntry {
  id: string;
  host: string;
  timestamp: string;
  daysRemaining: number;
  status: 'valid' | 'expiring' | 'expired' | 'invalid';
  issuer: string;
}

const SSLCheckerPage: React.FC<Props> = ({ onNavigate }) => {
  const [host, setHost] = useState('github.com');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<SSLResult | null>(null);
  const [error, setError] = useState('');
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [copied, setCopied] = useState(false);
  const [autoCheck, setAutoCheck] = useState(false);

  useEffect(() => {
    // Load history
    const savedHistory = localStorage.getItem('sslCheckHistory');
    if (savedHistory) {
      try {
        setHistory(JSON.parse(savedHistory));
      } catch (e) {
        console.error('Failed to load history:', e);
      }
    }
  }, []);

  const run = async () => {
    if (!host.trim()) return;
    setLoading(true); setError(''); setResult(null);
    try {
      const res = await fetch(`/api/tools/ssl?host=${encodeURIComponent(host.trim())}`);
      const data = await res.json();
      if (data.success) {
        setResult(data.data);
        addToHistory(data.data);
      }
      else setError(data.error || 'SSL check failed');
    } catch (e: any) { 
      setError(e?.message || 'Network error'); 
    }
    finally { setLoading(false); }
  };

  const addToHistory = (sslData: SSLResult) => {
    const status = sslData.daysRemaining < 0 ? 'expired' :
                   sslData.daysRemaining <= 30 ? 'expiring' :
                   sslData.valid ? 'valid' : 'invalid';

    const entry: HistoryEntry = {
      id: Date.now().toString(),
      host,
      timestamp: new Date().toISOString(),
      daysRemaining: sslData.daysRemaining,
      status,
      issuer: sslData.issuer
    };

    const newHistory = [entry, ...history.filter(h => h.host !== host).slice(0, 19)];
    setHistory(newHistory);
    localStorage.setItem('sslCheckHistory', JSON.stringify(newHistory));
  };

  const clearHistory = () => {
    setHistory([]);
    localStorage.removeItem('sslCheckHistory');
  };

  const copyResults = () => {
    if (!result) return;
    const text = `SSL Certificate Info for ${host}\n` +
      `Valid: ${result.valid}\n` +
      `Issuer: ${result.issuer}\n` +
      `Valid From: ${new Date(result.validFrom).toLocaleString()}\n` +
      `Valid To: ${new Date(result.validTo).toLocaleString()}\n` +
      `Days Remaining: ${result.daysRemaining}\n` +
      `Protocol: ${result.protocol}\n` +
      `Cipher: ${result.cipher}\n` +
      `Bits: ${result.bits}`;
    
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const downloadCertInfo = () => {
    if (!result) return;
    const json = JSON.stringify(result, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ssl-cert-${host}-${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const getCipherStrength = (bits: number): { level: string; color: string } => {
    if (bits >= 256) return { level: 'Excellent', color: 'green' };
    if (bits >= 128) return { level: 'Good', color: 'cyan' };
    if (bits >= 112) return { level: 'Fair', color: 'yellow' };
    return { level: 'Weak', color: 'red' };
  };

  const getExpiryStatus = (days: number): { level: string; color: string; icon: JSX.Element } => {
    if (days < 0) return { 
      level: 'Expired', 
      color: 'red', 
      icon: <XCircle className="w-5 h-5" /> 
    };
    if (days <= 7) return { 
      level: 'Critical', 
      color: 'red', 
      icon: <AlertTriangle className="w-5 h-5" /> 
    };
    if (days <= 30) return { 
      level: 'Warning', 
      color: 'yellow', 
      icon: <AlertCircle className="w-5 h-5" /> 
    };
    if (days <= 90) return { 
      level: 'Monitor', 
      color: 'orange', 
      icon: <Clock className="w-5 h-5" /> 
    };
    return { 
      level: 'Healthy', 
      color: 'green', 
      icon: <CheckCircle className="w-5 h-5" /> 
    };
  };

  const expiryStatus = result ? getExpiryStatus(result.daysRemaining) : null;
  const cipherStrength = result ? getCipherStrength(result.bits) : null;

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <section className="relative overflow-hidden py-12 border-b border-gray-800">
        <div className="absolute inset-0 bg-grid-gray-900 [mask-image:linear-gradient(to_bottom,white_30%,transparent)]"></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-green-500/10 rounded-full blur-3xl"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <button 
            onClick={() => onNavigate?.('toolbox')} 
            className="mb-6 flex items-center gap-2 text-gray-400 hover:text-cyan-400 transition-colors"
          >
            <ArrowLeft className="w-4 h-4"/> Back to Toolbox
          </button>
          
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 bg-green-500/20 rounded-lg border border-green-500/30">
              <Shield className="w-6 h-6 text-green-400"/>
            </div>
            <div>
              <h1 className="text-3xl md:text-4xl font-bold">SSL Certificate Checker</h1>
              <p className="text-gray-400 mt-1">Monitor certificate health and security</p>
            </div>
          </div>

          {/* Stats Dashboard */}
          {result && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
              <div className={`bg-gray-900/50 border border-${expiryStatus?.color}-500/30 rounded-lg p-4`}>
                <div className="text-gray-400 text-sm mb-1">Certificate Status</div>
                <div className={`text-2xl font-bold text-${expiryStatus?.color}-400 flex items-center gap-2`}>
                  {expiryStatus?.icon}
                  {expiryStatus?.level}
                </div>
              </div>
              <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-4">
                <div className="text-gray-400 text-sm mb-1">Days Remaining</div>
                <div className={`text-2xl font-bold ${
                  result.daysRemaining < 0 ? 'text-red-400' :
                  result.daysRemaining <= 30 ? 'text-yellow-400' : 'text-green-400'
                }`}>
                  {result.daysRemaining}
                </div>
              </div>
              <div className={`bg-gray-900/50 border border-${cipherStrength?.color}-500/30 rounded-lg p-4`}>
                <div className="text-gray-400 text-sm mb-1">Encryption</div>
                <div className={`text-2xl font-bold text-${cipherStrength?.color}-400`}>
                  {result.bits}-bit
                </div>
              </div>
              <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-4">
                <div className="text-gray-400 text-sm mb-1">Protocol</div>
                <div className="text-2xl font-bold text-cyan-400">{result.protocol}</div>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Main Content */}
      <section className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-3 gap-6">
            {/* Left Column - Checker & Results */}
            <div className="lg:col-span-2 space-y-6">
              {/* SSL Checker Input */}
              <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
                <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                  <Search className="w-5 h-5 text-cyan-400" />
                  Check SSL Certificate
                </h3>
                
                <div className="space-y-4">
                  <div className="flex flex-col sm:flex-row gap-3">
                    <input 
                      className="flex-1 px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-cyan-500 transition"
                      placeholder="example.com (no https://)" 
                      value={host} 
                      onChange={e => setHost(e.target.value)}
                      onKeyPress={e => e.key === 'Enter' && run()}
                      disabled={loading}
                    />
                    <button 
                      onClick={run} 
                      disabled={loading || !host.trim()}
                      className="px-6 py-3 rounded-lg bg-gradient-to-r from-green-500 to-cyan-500 text-black font-semibold flex items-center justify-center gap-2 hover:shadow-lg hover:shadow-green-500/50 transition disabled:opacity-50 w-full sm:w-auto"
                    >
                      {loading ? (
                        <>
                          <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin"></div>
                          Checking...
                        </>
                      ) : (
                        <>
                          <Search className="w-4 h-4" />
                          Check SSL
                        </>
                      )}
                    </button>
                  </div>

                  {error && (
                    <div className="flex items-center gap-2 p-3 bg-red-500/10 border border-red-500/30 rounded-lg">
                      <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0" />
                      <p className="text-sm text-red-300">{error}</p>
                    </div>
                  )}

                  {/* Quick Test Domains */}
                  <div className="flex flex-wrap gap-2">
                    <span className="text-sm text-gray-400">Quick test:</span>
                    {['github.com', 'google.com', 'cloudflare.com', 'amazon.com'].map(domain => (
                      <button
                        key={domain}
                        onClick={() => { setHost(domain); }}
                        className="text-xs px-3 py-1 bg-gray-800 hover:bg-gray-700 border border-gray-700 rounded-full transition"
                      >
                        {domain}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* SSL Certificate Details */}
              {result && (
                <>
                  {/* Main Certificate Info */}
                  <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
                    <div className="flex items-center justify-between mb-6">
                      <h3 className="text-lg font-bold flex items-center gap-2">
                        <Lock className="w-5 h-5 text-green-400" />
                        Certificate Details
                      </h3>
                      <div className="flex gap-2">
                        <button
                          onClick={copyResults}
                          className="px-3 py-2 bg-gray-800 hover:bg-gray-700 rounded-lg border border-gray-700 transition flex items-center gap-2 text-sm"
                        >
                          {copied ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
                          Copy
                        </button>
                        <button
                          onClick={downloadCertInfo}
                          className="px-3 py-2 bg-gray-800 hover:bg-gray-700 rounded-lg border border-gray-700 transition flex items-center gap-2 text-sm"
                        >
                          <Download className="w-4 h-4" />
                          Export
                        </button>
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="p-4 bg-gray-800/50 rounded-lg border border-gray-700">
                        <div className="flex items-center gap-2 text-sm text-gray-400 mb-2">
                          <Server className="w-4 h-4" />
                          Subject
                        </div>
                        <div className="text-white font-semibold break-all">{result.subject}</div>
                      </div>

                      <div className="p-4 bg-gray-800/50 rounded-lg border border-gray-700">
                        <div className="flex items-center gap-2 text-sm text-gray-400 mb-2">
                          <Shield className="w-4 h-4" />
                          Issuer
                        </div>
                        <div className="text-white font-semibold break-all">{result.issuer}</div>
                      </div>

                      <div className="p-4 bg-gray-800/50 rounded-lg border border-gray-700">
                        <div className="flex items-center gap-2 text-sm text-gray-400 mb-2">
                          <Calendar className="w-4 h-4" />
                          Valid From
                        </div>
                        <div className="text-white font-semibold">
                          {new Date(result.validFrom).toLocaleDateString()}
                        </div>
                      </div>

                      <div className={`p-4 bg-gray-800/50 rounded-lg border-2 ${
                        result.daysRemaining < 0 ? 'border-red-500/50' :
                        result.daysRemaining <= 30 ? 'border-yellow-500/50' :
                        'border-green-500/50'
                      }`}>
                        <div className="flex items-center gap-2 text-sm text-gray-400 mb-2">
                          <Clock className="w-4 h-4" />
                          Valid Until
                        </div>
                        <div className={`font-semibold ${
                          result.daysRemaining < 0 ? 'text-red-400' :
                          result.daysRemaining <= 30 ? 'text-yellow-400' :
                          'text-green-400'
                        }`}>
                          {new Date(result.validTo).toLocaleDateString()}
                        </div>
                      </div>

                      <div className="p-4 bg-gray-800/50 rounded-lg border border-gray-700">
                        <div className="flex items-center gap-2 text-sm text-gray-400 mb-2">
                          <Key className="w-4 h-4" />
                          Cipher Suite
                        </div>
                        <div className="text-white font-semibold text-sm">{result.cipher}</div>
                      </div>

                      <div className={`p-4 bg-gray-800/50 rounded-lg border-2 border-${cipherStrength?.color}-500/50`}>
                        <div className="flex items-center gap-2 text-sm text-gray-400 mb-2">
                          <TrendingUp className="w-4 h-4" />
                          Encryption Strength
                        </div>
                        <div className={`text-${cipherStrength?.color}-400 font-semibold`}>
                          {result.bits}-bit ({cipherStrength?.level})
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Certificate Chain */}
                  {result.chain && result.chain.length > 0 && (
                    <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
                      <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                        <Lock className="w-5 h-5 text-purple-400" />
                        Certificate Chain ({result.chain.length} certificates)
                      </h3>
                      <div className="space-y-3">
                        {result.chain.map((cert, idx) => (
                          <div key={idx} className="p-4 bg-gray-800/50 border border-gray-700 rounded-lg hover:border-purple-500/50 transition">
                            <div className="flex items-start gap-3">
                              <div className="px-2 py-1 bg-purple-500/20 border border-purple-500/30 rounded text-purple-400 font-bold text-sm">
                                #{idx + 1}
                              </div>
                              <div className="flex-1 space-y-2">
                                <div className="text-sm">
                                  <span className="text-gray-400">Subject:</span>
                                  <span className="ml-2 text-white font-semibold">{cert.subject}</span>
                                </div>
                                <div className="text-sm">
                                  <span className="text-gray-400">Issuer:</span>
                                  <span className="ml-2 text-cyan-400">{cert.issuer}</span>
                                </div>
                                <div className="text-xs text-gray-500">
                                  Valid: {new Date(cert.validFrom).toLocaleDateString()} → {new Date(cert.validTo).toLocaleDateString()}
                                </div>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Alternative Names */}
                  {result.altNames && result.altNames.length > 0 && (
                    <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
                      <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                        <Info className="w-5 h-5 text-cyan-400" />
                        Alternative Names ({result.altNames.length})
                      </h3>
                      <div className="flex flex-wrap gap-2">
                        {result.altNames.map((name, idx) => (
                          <span
                            key={idx}
                            className="px-3 py-1 bg-cyan-500/10 border border-cyan-500/30 rounded-full text-cyan-400 text-sm"
                          >
                            {name}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </>
              )}
            </div>

            {/* Right Column - History & Security Guide */}
            <div className="space-y-6">
              {/* Security Score & Recommendations */}
              {result && (
                <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
                  <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                    <Shield className="w-5 h-5 text-green-400" />
                    Security Assessment
                  </h3>
                  <div className="space-y-3 text-sm">
                    {result.valid && (
                      <div className="flex items-start gap-2">
                        <CheckCircle className="w-4 h-4 text-green-400 mt-0.5" />
                        <div>
                          <div className="font-semibold text-green-400">Certificate Valid</div>
                          <div className="text-gray-400 text-xs">Trusted by browsers</div>
                        </div>
                      </div>
                    )}
                    {result.daysRemaining > 30 && (
                      <div className="flex items-start gap-2">
                        <CheckCircle className="w-4 h-4 text-green-400 mt-0.5" />
                        <div>
                          <div className="font-semibold text-green-400">Not Expiring Soon</div>
                          <div className="text-gray-400 text-xs">{result.daysRemaining} days remaining</div>
                        </div>
                      </div>
                    )}
                    {result.daysRemaining <= 30 && result.daysRemaining > 0 && (
                      <div className="flex items-start gap-2">
                        <AlertCircle className="w-4 h-4 text-yellow-400 mt-0.5" />
                        <div>
                          <div className="font-semibold text-yellow-400">Renewal Needed</div>
                          <div className="text-gray-400 text-xs">Expires in {result.daysRemaining} days</div>
                        </div>
                      </div>
                    )}
                    {result.bits >= 256 && (
                      <div className="flex items-start gap-2">
                        <CheckCircle className="w-4 h-4 text-green-400 mt-0.5" />
                        <div>
                          <div className="font-semibold text-green-400">Strong Encryption</div>
                          <div className="text-gray-400 text-xs">{result.bits}-bit cipher</div>
                        </div>
                      </div>
                    )}
                    {result.protocol.includes('TLS') && (
                      <div className="flex items-start gap-2">
                        <CheckCircle className="w-4 h-4 text-green-400 mt-0.5" />
                        <div>
                          <div className="font-semibold text-green-400">Modern Protocol</div>
                          <div className="text-gray-400 text-xs">{result.protocol}</div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Check History */}
              {history.length > 0 && (
                <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-bold flex items-center gap-2">
                      <Clock className="w-5 h-5 text-cyan-400" />
                      Recent Checks
                    </h3>
                    <button
                      onClick={clearHistory}
                      className="text-xs text-gray-400 hover:text-red-400 transition"
                    >
                      Clear
                    </button>
                  </div>
                  <div className="space-y-2 max-h-96 overflow-y-auto">
                    {history.map(entry => {
                      const statusColors = {
                        valid: 'border-green-500/50 bg-green-500/10',
                        expiring: 'border-yellow-500/50 bg-yellow-500/10',
                        expired: 'border-red-500/50 bg-red-500/10',
                        invalid: 'border-gray-500/50 bg-gray-500/10'
                      };

                      return (
                        <button
                          key={entry.id}
                          onClick={() => setHost(entry.host)}
                          className={`w-full p-3 ${statusColors[entry.status]} border rounded-lg transition-all text-left hover:scale-[1.02]`}
                        >
                          <div className="font-mono text-cyan-400 font-semibold text-sm mb-2">
                            {entry.host}
                          </div>
                          <div className="flex items-center justify-between text-xs">
                            <span className="text-gray-400">
                              {entry.daysRemaining} days left
                            </span>
                            <span className={`px-2 py-0.5 rounded capitalize ${
                              entry.status === 'valid' ? 'bg-green-500/20 text-green-400' :
                              entry.status === 'expiring' ? 'bg-yellow-500/20 text-yellow-400' :
                              entry.status === 'expired' ? 'bg-red-500/20 text-red-400' :
                              'bg-gray-500/20 text-gray-400'
                            }`}>
                              {entry.status}
                            </span>
                          </div>
                          <div className="text-xs text-gray-500 mt-2 flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {new Date(entry.timestamp).toLocaleString()}
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* SSL Best Practices */}
              <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
                <h3 className="text-lg font-bold mb-4">SSL Best Practices</h3>
                <div className="space-y-3 text-sm">
                  <div className="text-gray-400">
                    <strong className="text-green-400">✓</strong> Renew certificates 30 days before expiry
                  </div>
                  <div className="text-gray-400">
                    <strong className="text-green-400">✓</strong> Use 256-bit encryption minimum
                  </div>
                  <div className="text-gray-400">
                    <strong className="text-green-400">✓</strong> Enable TLS 1.2 or higher only
                  </div>
                  <div className="text-gray-400">
                    <strong className="text-green-400">✓</strong> Implement HSTS headers
                  </div>
                  <div className="text-gray-400">
                    <strong className="text-red-400">✗</strong> Avoid self-signed certificates
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default SSLCheckerPage;
