import React, { useState } from 'react';
import { Page } from '../../App';
import {
  ArrowLeft,
  Scale,
  FileText,
  Shield,
  CreditCard,
  Users,
  AlertCircle,
  CheckCircle,
  X,
  ExternalLink,
  BookOpen,
  UserX,
  Gavel,
  Ban,
  Lock,
  Globe,
  Zap,
} from 'lucide-react';

interface TermsConditionsPageProps {
  onNavigate: (page: Page) => void;
}

interface TermsArticle {
  id: string;
  title: string;
  icon: React.ReactNode;
  excerpt: string;
  category: string;
  content: {
    introduction: string;
    sections: {
      heading: string;
      paragraphs: string[];
      list?: string[];
    }[];
    conclusion?: string;
  };
}

const TermsConditionsPage: React.FC<TermsConditionsPageProps> = ({ onNavigate }) => {
  const [selectedArticle, setSelectedArticle] = useState<TermsArticle | null>(null);
  const [activeCategory, setActiveCategory] = useState<string>('all');

  const articles: TermsArticle[] = [
    {
      id: 'agreement',
      title: 'Agreement to Terms',
      icon: <Scale className="w-6 h-6 text-cyan-400" />,
      excerpt: 'By using our platform, you agree to be bound by these Terms of Service.',
      category: 'Legal Basis',
      content: {
        introduction:
          'These Terms of Service ("Terms") govern your access to and use of IA M AI\'s multi-agent platform, including all AI agents, developer tools, and related services. By creating an account or using our services, you agree to be legally bound by these Terms.',
        sections: [
          {
            heading: 'Acceptance of Terms',
            paragraphs: [
              'By accessing or using any part of our platform, you acknowledge that you have read, understood, and agree to be bound by these Terms of Service, our Privacy Policy, and all applicable laws and regulations.',
              'If you do not agree with any part of these Terms, you must not use our services. Your continued use of the platform constitutes ongoing acceptance of these Terms.',
            ],
            list: [
              'You must be at least 13 years old (16 in the EU) to use our services',
              'You represent that you have the legal capacity to enter into this agreement',
              'If using on behalf of an organization, you have authority to bind that organization',
              'You agree to use the platform in compliance with all applicable laws',
              'You understand these Terms constitute a legally binding agreement',
            ],
          },
          {
            heading: 'Modifications to Terms',
            paragraphs: [
              'We reserve the right to modify these Terms at any time. We will notify you of any material changes via email or through prominent notice on the platform at least 30 days before the changes take effect.',
              'Your continued use of our services after changes become effective constitutes your acceptance of the modified Terms. If you do not agree to the changes, you must stop using our services and may close your account.',
            ],
            list: [
              'Material changes will be announced 30 days in advance',
              'You will receive email notification of significant updates',
              'In-app banners will highlight important changes',
              'Version history is available in our Terms archive',
              'Continued use after changes = acceptance of new Terms',
            ],
          },
          {
            heading: 'Entire Agreement',
            paragraphs: [
              'These Terms, together with our Privacy Policy, Cookie Policy, and any additional terms specific to certain services, constitute the entire agreement between you and IA M AI regarding your use of our platform.',
            ],
          },
        ],
        conclusion:
          'By using IA M AI, you enter into a legally binding agreement. Please read these Terms carefully and contact us if you have any questions.',
      },
    },
    {
      id: 'account-responsibilities',
      title: 'Account & User Responsibilities',
      icon: <Users className="w-6 h-6 text-cyan-400" />,
      excerpt:
        'Your obligations regarding account creation, security, and proper use of our services.',
      category: 'Account Management',
      content: {
        introduction:
          'As a user of IA M AI, you have certain responsibilities regarding your account, the security of your credentials, and how you use our platform and AI agents.',
        sections: [
          {
            heading: 'Account Registration',
            paragraphs: [
              'To access certain features of our platform, you must create an account. You agree to provide accurate, current, and complete information during registration and to keep this information updated.',
            ],
            list: [
              'Provide a valid email address for verification',
              'Choose a secure password (we recommend a password manager)',
              'Keep your account information accurate and up-to-date',
              'One person or entity per account (no sharing)',
              'Verify your email address to activate full features',
              'Optional: Enable two-factor authentication for added security',
            ],
          },
          {
            heading: 'Account Security',
            paragraphs: [
              'You are responsible for maintaining the confidentiality of your account credentials and for all activities that occur under your account. You must immediately notify us of any unauthorized use of your account or any other breach of security.',
            ],
            list: [
              'Keep your password confidential - never share it',
              'Use a strong, unique password for your account',
              'Enable two-factor authentication when available',
              'Log out from shared or public computers',
              'Report suspicious activity immediately to security@iamai.global',
              'You are responsible for all actions taken using your account',
              'IA M AI is not liable for losses from unauthorized use',
            ],
          },
          {
            heading: 'Acceptable Use',
            paragraphs: [
              "You agree to use our platform and AI agents responsibly, ethically, and in compliance with all applicable laws. You must not use our services in any way that could harm, disable, or impair the platform or interfere with others' use.",
            ],
            list: [
              '✅ Use AI agents for legitimate, lawful purposes',
              '✅ Respect intellectual property rights',
              '✅ Follow community guidelines',
              '✅ Report bugs and security issues responsibly',
              '❌ No harassment, abuse, or hate speech',
              '❌ No spam or unauthorized marketing',
              '❌ No attempting to bypass security measures',
              '❌ No scraping or automated data extraction',
              '❌ No creating fake accounts or impersonation',
              '❌ No illegal content generation or distribution',
            ],
          },
          {
            heading: 'Account Suspension & Termination',
            paragraphs: [
              'We reserve the right to suspend or terminate your account at any time, with or without notice, for violations of these Terms, suspicious activity, or at our discretion. You may also terminate your account at any time through your account settings.',
            ],
            list: [
              'Violations may result in immediate account suspension',
              'Serious violations may result in permanent ban',
              'You will receive notice except in cases of severe violations',
              'You may appeal suspensions by contacting support',
              'Upon termination, your access to all services ceases',
              'Some data may be retained as required by law',
              'Paid subscriptions may be refunded pro-rata (see Refund Policy)',
            ],
          },
        ],
        conclusion:
          'Your account is your responsibility. Use our platform ethically, keep your credentials secure, and help us maintain a safe, positive community for all users.',
      },
    },
    {
      id: 'ai-usage',
      title: 'AI Services & Usage Limits',
      icon: <Zap className="w-6 h-6 text-cyan-400" />,
      excerpt: 'Terms governing AI agent interactions, usage limits, and content generation.',
      category: 'AI Services',
      content: {
        introduction:
          'IA M AI provides 17 AI-powered agents and various AI-driven tools. This section outlines the terms specific to using these AI services, including usage limits, content policies, and expectations.',
        sections: [
          {
            heading: 'AI Agent Services',
            paragraphs: [
              'Our platform offers 17 specialized AI agents (AI Girlfriend Pro, EmoAI, PDFMind, ChatRevive, TokBoost, YouGen, AgentX, AutoChat, CVSmash, ComedyChad, LazyLarry, FlirtyFiona, SassySarah, NerdyNeil, CoolKyle, ZenMasterZara, GamerGary) powered by state-of-the-art AI models.',
              'Each agent has specific capabilities and is designed for particular use cases. AI-generated content is provided "as is" and should be reviewed before use in critical applications.',
            ],
            list: [
              'AI responses are generated in real-time using advanced language models',
              'Agents may occasionally produce inaccurate or incomplete information',
              'You are responsible for reviewing and verifying AI-generated content',
              'AI agents do not provide professional advice (legal, medical, financial)',
              'Agent memory is optional and can be managed in privacy settings',
              'Conversations may be used to improve services (opt-out available)',
            ],
          },
          {
            heading: 'Usage Limits & Rate Limiting',
            paragraphs: [
              'To ensure fair use and platform stability, we implement usage limits based on your active subscription. Daily, weekly, and monthly plans may include different soft limits and fair use thresholds.',
            ],
            list: [
              'Per-Agent Limits: Usage may be scoped to individual agent subscriptions',
              'Fair Use: Soft caps to prevent abuse or excessive automated use',
              'Rate limiting: Maximum requests per minute to protect system stability',
              'Large file processing (PDFMind): Size and frequency limits may apply',
              'API access: Custom rate limits based on plan or enterprise agreement',
              'Excessive usage may result in temporary throttling or review',
              'Enterprise and custom plans available for high-volume needs',
            ],
          },
          {
            heading: 'Content Generation Policies',
            paragraphs: [
              'Our AI agents are designed to generate helpful, safe, and appropriate content. We have implemented safety measures to prevent generation of harmful, illegal, or inappropriate content.',
            ],
            list: [
              'AI will refuse requests for illegal content',
              'Harmful content (violence, self-harm) is blocked',
              'Hate speech and discriminatory content is prohibited',
              'Explicit adult content generation is restricted',
              'Impersonation and fraudulent content is not allowed',
              'Content moderation systems are in place',
              'You may report inappropriate AI responses',
              'Repeated violations may result in account suspension',
            ],
          },
          {
            heading: 'AI Limitations & Disclaimers',
            paragraphs: [
              'AI technology, while powerful, has limitations. Users should understand these limitations when using our services.',
            ],
            list: [
              'AI may produce factually incorrect information (hallucinations)',
              'AI lacks real-time knowledge beyond training data cutoff',
              'AI does not have true understanding or consciousness',
              'AI responses should not replace professional expertise',
              'AI may reflect biases present in training data',
              'We continuously work to improve AI accuracy and safety',
              'Service availability is not guaranteed 100% of the time',
            ],
          },
        ],
        conclusion:
          'Our AI services are powerful tools designed to assist you. Use them responsibly, understand their limitations, and always verify critical information independently.',
      },
    },
    {
      id: 'payment-subscription',
      title: 'Payment & Subscription Terms',
      icon: <CreditCard className="w-6 h-6 text-cyan-400" />,
      excerpt: 'Billing, subscriptions, refunds, and payment terms for premium services.',
      category: 'Billing',
      content: {
        introduction:
          'IA M AI offers simple, one-time purchase plans with per-agent billing. This section covers all aspects of billing, payments, agent access, and our refund policy.',
        sections: [
          {
            heading: 'Purchase Plans',
            paragraphs: [
              'We offer three core per-agent access options: Daily, Weekly, and Monthly. Each plan provides time-limited access and is priced to keep access affordable and predictable.',
              'Purchases are ONE-TIME payments with no automatic renewal. When your access expires, you can repurchase at any time. Prices are subject to change with 30 days notice.',
            ],
            list: [
              'Daily Plan: 24-hour access per agent (typically $1)',
              'Weekly Plan: 7-day access per agent (typically $5)',
              'Monthly Plan: 30-day access per agent (typically $19)',
              'Per-Agent Billing: You only pay for the specific agents you activate',
              'One Plan Per Agent: Cannot purchase same agent twice while active',
              'Multiple Agents Allowed: Can purchase different agents simultaneously',
              'Prices displayed in USD (local currency may apply)',
              'Taxes may be added based on your location',
            ],
          },
          {
            heading: 'Payment Processing',
            paragraphs: [
              'Payments are processed securely through third-party payment providers (Stripe). We do not store your full credit card information on our servers.',
              'Each purchase grants immediate access for the selected duration. No recurring charges will be made.',
            ],
            list: [
              'Accepted payment methods: Credit/debit cards, PayPal',
              'One-time payment only - no automatic renewals',
              'You will receive receipts via email for all purchases',
              'Each purchase is independent',
              'Access automatically expires after the purchased duration',
              'Failed payments will prevent access activation',
              'All transactions are encrypted and secure',
            ],
          },
          {
            heading: 'Cancellation & Refunds',
            paragraphs: [
              'You may cancel your subscription at any time through your account settings. Cancellation takes effect at the end of your current billing period, and you will retain access until then.',
              'We offer a 7-day money-back guarantee for new subscribers. After 7 days, subscriptions are non-refundable except as required by law or at our discretion.',
            ],
            list: [
              'Cancel anytime - no cancellation fees',
              'Access continues until end of paid period',
              '7-day money-back guarantee for new subscriptions',
              'Refunds processed within 5-10 business days',
              'Pro-rated refunds may be offered for service issues',
              'No refunds for partial months (except guarantee period)',
              'Enterprise contracts have separate cancellation terms',
              'Contact support@iamai.global for refund requests',
            ],
          },
          {
            heading: 'Price Changes',
            paragraphs: [
              'We may change purchase prices at any time. Active purchases are not affected - you have access for the duration you paid for. New purchases will reflect current pricing.',
            ],
            list: [
              'Price increases announced 30 days in advance',
              'Your current purchase is unaffected by price changes',
              'Access duration you paid for is honored',
              'New purchases use current prices',
              'No price adjustments to active purchases',
              'Transparent pricing always displayed at checkout',
            ],
          },
        ],
        conclusion:
          'We strive for transparent, fair billing practices. Each purchase is independent with no recurring charges. Cancel anytime without affecting future purchases.',
      },
    },
    {
      id: 'intellectual-property',
      title: 'Intellectual Property Rights',
      icon: <FileText className="w-6 h-6 text-cyan-400" />,
      excerpt: 'Ownership of content, AI-generated material, and intellectual property policies.',
      category: 'IP & Content',
      content: {
        introduction:
          'This section clarifies ownership rights for platform content, user-generated content, AI-generated content, and intellectual property protections.',
        sections: [
          {
            heading: 'Platform Ownership',
            paragraphs: [
              'IA M AI, including all software, AI models, designs, text, graphics, user interfaces, code, and trade dress are owned by us or our licensors and are protected by intellectual property laws.',
              'You are granted a limited, non-exclusive, non-transferable license to access and use our platform for personal or business purposes in accordance with these Terms.',
            ],
            list: [
              'All platform code, design, and functionality is our property',
              'AI agent personalities and system prompts are proprietary',
              'Our trademarks and logos are protected',
              'You may not copy, modify, or reverse engineer our platform',
              'You may not create derivative works without permission',
              'Screenshots and content for review/educational purposes are allowed',
            ],
          },
          {
            heading: 'Your Content',
            paragraphs: [
              'You retain ownership of any content you upload, submit, or create on our platform (excluding AI-generated content). However, you grant us a license to use this content to provide and improve our services.',
            ],
            list: [
              'You own prompts, uploaded files, and user-created content',
              'You grant us license to process and store your content',
              'We may use anonymized content to improve AI models (opt-out available)',
              'You are responsible for ensuring you have rights to uploaded content',
              'Do not upload copyrighted material without permission',
              'We may remove content that violates rights or policies',
            ],
          },
          {
            heading: 'AI-Generated Content',
            paragraphs: [
              'Content generated by our AI agents in response to your prompts is owned by you, subject to applicable laws and regulations. However, similar content may be generated for other users with similar prompts.',
              'You are responsible for ensuring AI-generated content does not infringe on third-party rights before using it commercially or publicly.',
            ],
            list: [
              'You own AI-generated content created in response to your prompts',
              'You may use AI content for personal and commercial purposes',
              "You must verify AI content doesn't infringe third-party rights",
              'Similar content may be generated for other users',
              'We do not guarantee uniqueness of AI-generated content',
              'You indemnify us for your use of AI-generated content',
              'Follow attribution guidelines if required by specific tools',
            ],
          },
          {
            heading: 'Copyright Infringement',
            paragraphs: [
              'We respect intellectual property rights and expect our users to do the same. If you believe content on our platform infringes your copyright, please contact us with details.',
            ],
            list: [
              'DMCA compliant: We respond to takedown notices',
              'Submit copyright claims to legal@iamai.global',
              'Include proof of ownership and location of infringement',
              'We will investigate and remove infringing content',
              'Repeat infringers may have accounts terminated',
              'False claims may result in legal consequences',
            ],
          },
        ],
        conclusion:
          'We respect intellectual property rights. You own your content and AI-generated outputs, while we retain ownership of our platform and technology.',
      },
    },
    {
      id: 'prohibited-conduct',
      title: 'Prohibited Conduct & Violations',
      icon: <Ban className="w-6 h-6 text-cyan-400" />,
      excerpt: 'Activities strictly forbidden on our platform and consequences for violations.',
      category: 'Rules & Enforcement',
      content: {
        introduction:
          'To maintain a safe, legal, and positive environment, certain activities are strictly prohibited on IA M AI. Violations may result in immediate account suspension or termination.',
        sections: [
          {
            heading: 'Illegal Activities',
            paragraphs: [
              'You may not use our platform for any illegal purpose or to facilitate illegal activities. This includes but is not limited to:',
            ],
            list: [
              '❌ Generating or distributing illegal content',
              '❌ Facilitating fraud, scams, or deceptive practices',
              '❌ Money laundering or terrorist financing',
              '❌ Hacking, cracking, or unauthorized access attempts',
              '❌ Distribution of malware, viruses, or harmful code',
              '❌ Violation of export control or sanctions laws',
              '❌ Child exploitation or endangerment (zero tolerance)',
              '❌ Drug trafficking or illegal substance promotion',
            ],
          },
          {
            heading: 'Harmful Content',
            paragraphs: [
              'Content that promotes harm, violence, or illegal activities is strictly prohibited:',
            ],
            list: [
              '❌ Violence, gore, or graphic content',
              '❌ Self-harm or suicide encouragement',
              '❌ Hate speech or discrimination',
              '❌ Harassment, bullying, or threats',
              '❌ Doxxing or sharing private information',
              '❌ Non-consensual intimate content',
              '❌ Impersonation or identity theft',
              '❌ Misinformation intended to cause harm',
            ],
          },
          {
            heading: 'Platform Abuse',
            paragraphs: [
              'Actions that abuse, disrupt, or interfere with our platform or other users are forbidden:',
            ],
            list: [
              '❌ Automated scraping or data extraction',
              '❌ Creating multiple accounts to bypass limits',
              '❌ Attempting to overwhelm or DDoS our services',
              '❌ Reverse engineering or decompiling our code',
              '❌ Bypassing rate limits or security measures',
              '❌ Selling or transferring accounts',
              '❌ Sharing login credentials',
              '❌ Using exploits or bugs for unfair advantage',
            ],
          },
          {
            heading: 'Consequences & Enforcement',
            paragraphs: ['Violations are taken seriously and may result in immediate action:'],
            list: [
              '⚠️ First offense: Warning and content removal',
              '⚠️ Repeated violations: Temporary suspension (7-30 days)',
              '🚫 Serious violations: Permanent account termination',
              '🚫 Illegal activity: Report to law enforcement',
              '📧 You will receive notice via email (when possible)',
              '🔍 Appeals can be submitted to appeals@iamai.global',
              '⚖️ Final decisions rest with IA M AI',
              '💰 No refunds for violations-based terminations',
            ],
          },
        ],
        conclusion:
          'We have zero tolerance for illegal activity, harmful content, and platform abuse. Help us maintain a safe community by reporting violations and using our services responsibly.',
      },
    },
    {
      id: 'liability-disclaimers',
      title: 'Liability & Disclaimers',
      icon: <AlertCircle className="w-6 h-6 text-cyan-400" />,
      excerpt:
        'Limitations of liability, disclaimers, and what we are and are not responsible for.',
      category: 'Legal Protection',
      content: {
        introduction:
          'This section outlines important limitations on our liability and disclaimers about our services. Please read carefully as these provisions affect your legal rights.',
        sections: [
          {
            heading: 'Service "As Is"',
            paragraphs: [
              'Our services are provided "as is" and "as available" without warranties of any kind, either express or implied. We do not guarantee that our services will be uninterrupted, secure, or error-free.',
            ],
            list: [
              'No warranty of merchantability or fitness for particular purpose',
              'No guarantee of accuracy of AI-generated content',
              'No guarantee of continuous, uninterrupted service',
              'We may experience downtime for maintenance or issues',
              'Third-party services (AI providers) may affect availability',
              'You use our services at your own risk',
            ],
          },
          {
            heading: 'Limitation of Liability',
            paragraphs: [
              'To the maximum extent permitted by law, IA M AI shall not be liable for any indirect, incidental, special, consequential, or punitive damages, or any loss of profits or revenues, whether incurred directly or indirectly, or any loss of data, use, goodwill, or other intangible losses.',
              'Our total liability for any claims arising from or relating to our services shall not exceed the amount you paid us in the twelve (12) months preceding the claim, or $100, whichever is greater.',
            ],
            list: [
              'Not liable for lost profits or business opportunities',
              'Not liable for data loss (maintain your own backups)',
              'Not liable for third-party actions or content',
              'Not liable for AI-generated content errors',
              'Not liable for decisions made based on AI advice',
              'Maximum liability limited to amount paid or $100',
              'Some jurisdictions do not allow limitations, so this may not apply to you',
            ],
          },
          {
            heading: 'AI Content Disclaimer',
            paragraphs: [
              'AI-generated content is provided for informational and entertainment purposes only. It is not professional advice and should not be relied upon for critical decisions.',
            ],
            list: [
              'AI responses may contain errors or inaccuracies',
              'Not a substitute for professional advice (legal, medical, financial)',
              'Verify important information from authoritative sources',
              'You are responsible for how you use AI-generated content',
              'AI has knowledge cutoffs and may not have latest information',
              'We are not responsible for actions taken based on AI advice',
            ],
          },
          {
            heading: 'Third-Party Services',
            paragraphs: [
              'Our platform integrates with third-party services (AI providers, payment processors, etc.). We are not responsible for the availability, accuracy, or content of these third-party services.',
            ],
            list: [
              'Mistral AI, OpenAI, Google, Anthropic provide AI capabilities',
              'Stripe handles payment processing',
              'Third-party services have their own terms and policies',
              'We are not responsible for third-party outages or issues',
              'Third-party service changes may affect our platform',
              'You agree to third-party terms when using their services through us',
            ],
          },
        ],
        conclusion:
          'While we strive to provide excellent service, we must limit our liability to operate sustainably. Use our services responsibly and understand these limitations.',
      },
    },
    {
      id: 'indemnification',
      title: 'Indemnification',
      icon: <Shield className="w-6 h-6 text-cyan-400" />,
      excerpt: 'Your agreement to protect us from claims arising from your use of our services.',
      category: 'Legal Protection',
      content: {
        introduction:
          'By using IA M AI, you agree to indemnify and hold us harmless from claims, damages, and expenses arising from your use of our services or violation of these Terms.',
        sections: [
          {
            heading: 'Your Indemnification Obligations',
            paragraphs: [
              "You agree to defend, indemnify, and hold harmless IA M AI, our affiliates, licensors, and service providers, and our respective officers, directors, employees, contractors, agents, licensors, suppliers, successors, and assigns from and against any claims, liabilities, damages, judgments, awards, losses, costs, expenses, or fees (including reasonable attorneys' fees) arising out of or relating to:",
            ],
            list: [
              'Your violation of these Terms of Service',
              'Your violation of any law or rights of a third party',
              'Your use or misuse of our services',
              'Your content and how you use AI-generated content',
              'Infringement of intellectual property rights by your content',
              'False or misleading information you provide',
              'Unauthorized use of your account by third parties',
              'Your interactions with other users',
            ],
          },
          {
            heading: 'Indemnification Process',
            paragraphs: [
              'If we are subject to a claim for which you must indemnify us, we will promptly notify you and provide you with the opportunity to defend the claim at your expense. We reserve the right to assume the exclusive defense and control of any matter subject to indemnification by you.',
            ],
            list: [
              'We will notify you of any claims requiring indemnification',
              'You will have opportunity to defend at your expense',
              'We may choose to participate in defense',
              'You may not settle claims without our consent',
              'We may take control of defense if needed',
              'You will reimburse our defense costs if you lose',
            ],
          },
        ],
        conclusion:
          'Indemnification protects us from legal issues caused by your actions. Use our services legally and responsibly to avoid indemnification situations.',
      },
    },
    {
      id: 'dispute-resolution',
      title: 'Dispute Resolution & Arbitration',
      icon: <Gavel className="w-6 h-6 text-cyan-400" />,
      excerpt:
        'How disputes are resolved, including arbitration agreements and class action waivers.',
      category: 'Legal Process',
      content: {
        introduction:
          'This section explains how disputes between you and IA M AI will be resolved. It includes an arbitration agreement and class action waiver, which affect your legal rights.',
        sections: [
          {
            heading: 'Informal Resolution',
            paragraphs: [
              'Before initiating formal proceedings, we encourage you to contact us to seek informal resolution of any dispute. Most disputes can be resolved quickly and amicably through direct communication.',
            ],
            list: [
              'Contact support@iamai.global with dispute details',
              'We will respond within 5 business days',
              'Both parties will work in good faith to resolve',
              'Many issues can be resolved without formal proceedings',
              'This step is required before arbitration or litigation',
            ],
          },
          {
            heading: 'Binding Arbitration',
            paragraphs: [
              'If informal resolution fails, you agree that any dispute arising from or relating to these Terms or our services shall be resolved through binding arbitration, rather than in court, except for disputes that may be taken to small claims court.',
              'Arbitration is more informal than a lawsuit and uses a neutral arbitrator instead of a judge or jury. Arbitration is final and binding, with limited rights of appeal.',
            ],
            list: [
              'Disputes resolved through binding arbitration',
              'American Arbitration Association (AAA) rules apply',
              'One arbitrator selected per AAA procedures',
              'Arbitration conducted in English',
              'Location: Your home county or via remote proceedings',
              'Each party bears own costs (we may cover filing fees)',
              'Arbitrator decision is final and binding',
              'Very limited grounds for appeal',
            ],
          },
          {
            heading: 'Class Action Waiver',
            paragraphs: [
              'You agree to resolve disputes with us only on an individual basis and waive any right to bring claims as a class action, collective action, or representative proceeding.',
            ],
            list: [
              'No class action lawsuits permitted',
              'No collective or representative actions',
              'Each user must bring claims individually',
              'No combining claims with other users',
              'Arbitrator may not consolidate claims',
              'This waiver is a material term of our agreement',
              'Some jurisdictions may not enforce this waiver',
            ],
          },
          {
            heading: 'Exceptions to Arbitration',
            paragraphs: ['Certain disputes are excluded from the arbitration requirement:'],
            list: [
              'Disputes that qualify for small claims court',
              'Claims for injunctive relief to stop unauthorized use',
              'Intellectual property disputes',
              'Claims that cannot be arbitrated by law',
              'Either party may seek preliminary relief in court if needed',
            ],
          },
          {
            heading: 'Governing Law',
            paragraphs: [
              'These Terms are governed by the laws of [Your Jurisdiction], without regard to its conflict of laws principles. You consent to the exclusive jurisdiction of courts in [Your Jurisdiction] for any disputes not subject to arbitration.',
            ],
          },
        ],
        conclusion:
          'Arbitration and the class action waiver are important provisions. If you do not agree, you must stop using our services. Some jurisdictions provide additional rights.',
      },
    },
    {
      id: 'termination',
      title: 'Termination of Services',
      icon: <UserX className="w-6 h-6 text-cyan-400" />,
      excerpt: 'Conditions under which accounts may be terminated and the effects of termination.',
      category: 'Account Management',
      content: {
        introduction:
          'Both you and IA M AI have the right to terminate your account and access to our services under certain conditions. This section explains the termination process and its effects.',
        sections: [
          {
            heading: 'Your Right to Terminate',
            paragraphs: [
              'You may terminate your account at any time through your account settings or by contacting our support team. Termination is effective immediately upon completion of the process.',
            ],
            list: [
              'Cancel anytime through account settings',
              'Or email support@iamai.global to request termination',
              'Active subscriptions continue until period end',
              'You may request immediate termination (no refund)',
              'Download your data before terminating (30 days after)',
              'Termination is irreversible - all data will be deleted',
            ],
          },
          {
            heading: 'Our Right to Terminate',
            paragraphs: [
              'We reserve the right to suspend or terminate your account and access to our services at any time, with or without cause, with or without notice. Reasons for termination may include but are not limited to:',
            ],
            list: [
              'Violation of these Terms of Service',
              'Fraudulent or illegal activity',
              'Abuse of services or other users',
              'Failed payment for subscriptions',
              'Prolonged inactivity (with notice)',
              'At our discretion for any reason',
              'To comply with legal requirements',
              'If providing services becomes unlawful or impractical',
            ],
          },
          {
            heading: 'Effects of Termination',
            paragraphs: ['Upon termination, whether by you or by us, the following will occur:'],
            list: [
              'Immediate loss of access to all services',
              'All subscriptions and licenses revoked',
              'AI agent conversations deleted (per retention policy)',
              'Uploaded files and documents deleted',
              'Account data deleted (except as legally required)',
              'No refunds except as required by law or policy',
              'Certain provisions of Terms survive termination',
              'You remain liable for pre-termination activities',
            ],
          },
          {
            heading: 'Survival of Terms',
            paragraphs: [
              'The following provisions survive termination of your account: indemnification, limitation of liability, dispute resolution, intellectual property rights, and any other provisions that by their nature should survive.',
            ],
          },
        ],
        conclusion:
          'Both parties have termination rights. Account termination results in loss of access and data deletion. Some Terms provisions continue to apply after termination.',
      },
    },
    {
      id: 'miscellaneous',
      title: 'Miscellaneous Provisions',
      icon: <FileText className="w-6 h-6 text-cyan-400" />,
      excerpt: 'Additional legal provisions including severability, assignment, and force majeure.',
      category: 'General Terms',
      content: {
        introduction:
          "This section contains additional important legal provisions that don't fit in other categories but are essential to our agreement.",
        sections: [
          {
            heading: 'Entire Agreement',
            paragraphs: [
              'These Terms of Service, together with our Privacy Policy and any supplemental terms for specific services, constitute the entire agreement between you and IA M AI and supersede all prior agreements, understandings, or communications.',
            ],
          },
          {
            heading: 'Severability',
            paragraphs: [
              'If any provision of these Terms is found to be invalid or unenforceable, the remaining provisions will remain in full force and effect. The invalid provision will be modified to the minimum extent necessary to make it valid and enforceable.',
            ],
          },
          {
            heading: 'Waiver',
            paragraphs: [
              'Our failure to enforce any right or provision of these Terms will not be considered a waiver of those rights. Any waiver must be in writing and signed by us.',
            ],
          },
          {
            heading: 'Assignment',
            paragraphs: [
              'You may not assign or transfer these Terms or your account to any third party without our prior written consent. We may assign these Terms to any affiliate or in connection with a merger, acquisition, or sale of assets.',
            ],
          },
          {
            heading: 'Force Majeure',
            paragraphs: [
              'We shall not be liable for any failure or delay in performance due to circumstances beyond our reasonable control, including but not limited to acts of God, war, terrorism, riots, natural disasters, pandemics, internet or power outages, or governmental actions.',
            ],
          },
          {
            heading: 'No Agency',
            paragraphs: [
              'No agency, partnership, joint venture, or employment relationship is created between you and IA M AI as a result of these Terms or your use of our services.',
            ],
          },
          {
            heading: 'Notices',
            paragraphs: [
              'Any notices to you may be provided via email to your registered address or through prominent notice on our platform. Notices to us should be sent to legal@iamai.global.',
            ],
            list: [
              'Legal notices: legal@iamai.global',
              'Support inquiries: support@iamai.global',
              'Privacy concerns: privacy@iamai.global',
              'Security issues: security@iamai.global',
              'Physical mail: [Your Company Address]',
            ],
          },
        ],
        conclusion:
          'These miscellaneous provisions are important legal protections and clarifications that complete our Terms of Service agreement.',
      },
    },
  ];

  const categories = [
    'all',
    'Legal Basis',
    'Account Management',
    'AI Services',
    'Billing',
    'IP & Content',
    'Rules & Enforcement',
    'Legal Protection',
    'Legal Process',
    'General Terms',
  ];

  const filteredArticles =
    activeCategory === 'all'
      ? articles
      : articles.filter(article => article.category === activeCategory);

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <header className="border-b border-gray-800 bg-[#0a0a0a] sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <button
              onClick={() => onNavigate('home')}
              className="flex items-center gap-2 text-cyan-400 hover:text-cyan-300 transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
              <span className="text-sm">Back to Home</span>
            </button>
            <h1 className="text-2xl md:text-3xl font-bold text-white">Terms of Service</h1>
            <div className="w-20"></div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-12">
        <div className="max-w-7xl mx-auto">
          {/* Introduction */}
          <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-8 mb-8">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-3 bg-cyan-900/50 border border-cyan-500/30 rounded-xl">
                <Scale className="w-8 h-8 text-cyan-400" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-white">Terms of Service</h2>
                <p className="text-gray-500">Last updated: November 2025</p>
              </div>
            </div>
            <p className="text-gray-400 leading-relaxed mb-4">
              Welcome to <span className="text-cyan-400 font-semibold">IA M AI</span>. These Terms
              of Service govern your use of our multi-agent AI platform, including all 17 AI agents,
              developer tools, and related services. By using our platform, you agree to these
              Terms.
            </p>
            <p className="text-gray-500 text-sm">
              Please read these Terms carefully. They contain important information about your
              rights, obligations, and limitations of liability.
            </p>
          </div>

          {/* Category Filters */}
          <div className="mb-8">
            <h3 className="text-lg font-semibold mb-4 text-white">Browse by Category</h3>
            <div className="flex flex-wrap gap-2">
              {categories.map(category => (
                <button
                  key={category}
                  onClick={() => setActiveCategory(category)}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                    activeCategory === category
                      ? 'bg-cyan-500 text-black shadow-lg'
                      : 'bg-gray-900/50 text-gray-400 hover:bg-gray-800 border border-gray-800 hover:text-cyan-400'
                  }`}
                >
                  {category === 'all' ? '📋 All Articles' : category}
                </button>
              ))}
            </div>
          </div>

          {/* Article Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            {filteredArticles.map(article => (
              <div
                key={article.id}
                className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6 hover:border-cyan-500/50 transition-all cursor-pointer group"
                onClick={() => setSelectedArticle(article)}
              >
                <div className="flex items-start gap-4 mb-4">
                  <div className="p-3 bg-cyan-900/50 border border-cyan-500/30 rounded-xl group-hover:bg-cyan-500/20 transition-colors">
                    {article.icon}
                  </div>
                  <div className="flex-1">
                    <h3 className="text-lg font-bold text-white group-hover:text-cyan-400 transition-colors mb-1">
                      {article.title}
                    </h3>
                    <span className="inline-block px-2 py-1 bg-gray-800 text-cyan-400 text-xs rounded-full">
                      {article.category}
                    </span>
                  </div>
                </div>
                <p className="text-gray-400 text-sm mb-4 line-clamp-3">{article.excerpt}</p>
                <div className="flex items-center gap-2 text-cyan-400 text-sm font-medium group-hover:text-cyan-300 transition-colors">
                  <BookOpen className="w-4 h-4" />
                  <span>Read Full Article</span>
                  <ExternalLink className="w-3 h-3 ml-auto" />
                </div>
              </div>
            ))}
          </div>

          {/* Contact Information */}
          <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-8">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-3 bg-cyan-900/50 border border-cyan-500/30 rounded-xl">
                <AlertCircle className="w-6 h-6 text-cyan-400" />
              </div>
              <h2 className="text-2xl font-bold text-white">Questions About These Terms?</h2>
            </div>
            <p className="text-gray-400 mb-4">
              If you have questions about these Terms of Service or need clarification, please
              contact us:
            </p>
            <div className="space-y-2 text-gray-400">
              <p>
                <span className="text-cyan-400 font-semibold">Legal Team:</span> legal@iamai.global
              </p>
              <p>
                <span className="text-cyan-400 font-semibold">Support:</span> support@iamai.global
              </p>
              <p>
                <span className="text-cyan-400 font-semibold">General Inquiries:</span>{' '}
                contact@iamai.global
              </p>
            </div>
          </div>
        </div>
      </main>

      {/* Article Modal */}
      {selectedArticle && (
        <div
          className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4 animate-fadeIn"
          onClick={() => setSelectedArticle(null)}
        >
          <div
            className="bg-[#0a0a0a] border border-gray-800 rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden"
            onClick={e => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="sticky top-0 bg-[#0a0a0a] border-b border-gray-800 p-6 flex items-start justify-between z-10">
              <div className="flex items-start gap-4 flex-1">
                <div className="p-3 bg-cyan-900/50 border border-cyan-500/30 rounded-xl flex-shrink-0">
                  {selectedArticle.icon}
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-white mb-2">{selectedArticle.title}</h2>
                  <span className="inline-block px-3 py-1 bg-gray-800 text-cyan-400 text-sm rounded-full">
                    {selectedArticle.category}
                  </span>
                </div>
              </div>
              <button
                onClick={() => setSelectedArticle(null)}
                className="p-2 hover:bg-gray-800 rounded-lg transition-colors flex-shrink-0"
              >
                <X className="w-6 h-6 text-gray-400 hover:text-white" />
              </button>
            </div>

            {/* Modal Content - Scrollable */}
            <div className="overflow-y-auto max-h-[calc(90vh-140px)] p-6 space-y-6">
              {/* Introduction */}
              {selectedArticle.content.introduction && (
                <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-6">
                  <p className="text-gray-400 leading-relaxed">
                    {selectedArticle.content.introduction}
                  </p>
                </div>
              )}

              {/* Sections */}
              {selectedArticle.content.sections.map((section, index) => (
                <div key={index} className="space-y-4">
                  <h3 className="text-xl font-bold text-white flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-cyan-900/50 border border-cyan-500/30 flex items-center justify-center text-cyan-400 text-sm font-bold">
                      {index + 1}
                    </div>
                    {section.heading}
                  </h3>

                  {section.paragraphs.map((paragraph, pIndex) => (
                    <p key={pIndex} className="text-gray-400 leading-relaxed pl-10">
                      {paragraph}
                    </p>
                  ))}

                  {section.list && section.list.length > 0 && (
                    <ul className="space-y-2 pl-10">
                      {section.list.map((item, itemIndex) => (
                        <li key={itemIndex} className="flex items-start gap-3">
                          <CheckCircle className="w-5 h-5 text-cyan-400 flex-shrink-0 mt-0.5" />
                          <span className="text-gray-400 text-sm">{item}</span>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              ))}

              {/* Conclusion */}
              {selectedArticle.content.conclusion && (
                <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-6 mt-8">
                  <div className="flex items-start gap-3">
                    <AlertCircle className="w-6 h-6 text-cyan-400 flex-shrink-0 mt-1" />
                    <p className="text-gray-400 leading-relaxed font-medium">
                      {selectedArticle.content.conclusion}
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TermsConditionsPage;
