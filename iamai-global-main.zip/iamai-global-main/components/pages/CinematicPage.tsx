import React, { useState } from 'react';
import { Page } from '../../App';
import { Film, Play, Sparkles, Users, Zap, Brain, Lock, ChevronRight } from 'lucide-react';

interface CinematicPageProps {
  onNavigate: (page: Page) => void;
}

interface CinematicFeature {
  icon: React.ReactNode;
  title: string;
  description: string;
}

interface CinematicExperience {
  id: string;
  title: string;
  description: string;
  category: 'story' | 'interactive' | 'immersive';
  status: 'live' | 'coming-soon';
}

const CinematicPage: React.FC<CinematicPageProps> = ({ onNavigate }) => {
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'story' | 'interactive' | 'immersive'>('all');

  const features: CinematicFeature[] = [
    {
      icon: <Film className="w-8 h-8" />,
      title: 'Cinematic Storytelling',
      description: 'Experience AI-generated narratives with professional production quality and emotional depth.',
    },
    {
      icon: <Users className="w-8 h-8" />,
      title: 'Character Interaction',
      description: 'Engage with realistic AI characters that respond dynamically to your choices and input.',
    },
    {
      icon: <Brain className="w-8 h-8" />,
      title: 'Adaptive Narratives',
      description: 'Stories that evolve based on your decisions, creating unique experiences each time.',
    },
    {
      icon: <Zap className="w-8 h-8" />,
      title: 'Real-time Generation',
      description: 'Watch content generated on-demand with cutting-edge AI technology.',
    },
    {
      icon: <Sparkles className="w-8 h-8" />,
      title: 'Visual Effects',
      description: 'Stunning visual sequences and scene descriptions that bring stories to life.',
    },
    {
      icon: <Lock className="w-8 h-8" />,
      title: 'Premium Access',
      description: 'Exclusive cinematic content available to premium subscribers.',
    },
  ];

  const experiences: CinematicExperience[] = [
    {
      id: 'detective',
      title: 'The Detective\'s Dilemma',
      description: 'Solve complex mysteries with AI detectives who remember your past decisions.',
      category: 'interactive',
      status: 'coming-soon',
    },
    {
      id: 'space-odyssey',
      title: 'Space Odyssey',
      description: 'An immersive journey through galaxies with dynamic storytelling and exploration.',
      category: 'immersive',
      status: 'coming-soon',
    },
    {
      id: 'romance-tales',
      title: 'Romance Chronicles',
      description: 'Experience emotionally engaging stories with multiple narrative paths.',
      category: 'story',
      status: 'coming-soon',
    },
    {
      id: 'action-quest',
      title: 'Action Quest',
      description: 'Fast-paced adventures where your choices determine the outcome.',
      category: 'interactive',
      status: 'coming-soon',
    },
    {
      id: 'fantasy-realm',
      title: 'Fantasy Realm',
      description: 'Explore magical worlds with AI-generated landscapes and creatures.',
      category: 'immersive',
      status: 'coming-soon',
    },
    {
      id: 'scifi-exploration',
      title: 'Sci-Fi Exploration',
      description: 'Discover futuristic technologies and encounter alien civilizations.',
      category: 'story',
      status: 'coming-soon',
    },
  ];

  const filteredExperiences = selectedCategory === 'all' 
    ? experiences 
    : experiences.filter(exp => exp.category === selectedCategory);

  return (
    <div className="bg-black text-white min-h-screen">
      {/* Hero Section */}
      <section className="py-20 md:py-32 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-red-500/10 via-purple-500/10 to-blue-500/10 blur-3xl" />
        <div className="container mx-auto px-6 relative z-10">
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-red-500/20 mb-6">
              <Film className="w-8 h-8 text-red-400" />
            </div>
            <h1 className="text-5xl md:text-6xl font-bold mb-4 bg-gradient-to-r from-red-400 via-purple-400 to-blue-400 bg-clip-text text-transparent">
              Cinematic Experiences
            </h1>
            <p className="text-lg text-gray-300 max-w-2xl mx-auto mb-4">
              Immerse yourself in AI-generated cinematic stories where you control the narrative.
            </p>
            <p className="text-sm text-gray-500">Premium storytelling powered by advanced AI</p>
          </div>
        </div>
      </section>

      {/* Introduction */}
      <section className="py-12 bg-gray-900/50 border-y border-gray-800">
        <div className="container mx-auto px-6">
          <div className="max-w-3xl mx-auto text-center">
            <p className="text-gray-300 text-lg leading-relaxed">
              Welcome to the future of entertainment. Our Cinematic Experiences platform combines AI storytelling with interactive elements to create immersive narratives tailored to your preferences. Every decision matters. Every story is unique.
            </p>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-20 md:py-28">
        <div className="container mx-auto px-6">
          <h2 className="text-4xl font-bold text-center mb-12">What Makes Our Cinema Special</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {features.map((feature, idx) => (
              <div
                key={idx}
                className="group bg-gray-900/50 border border-gray-800 rounded-2xl p-8 hover:border-red-500/50 transition-all duration-300 transform hover:scale-105"
              >
                <div className="text-red-400 mb-4 group-hover:scale-110 transition-transform">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-bold text-white mb-3">
                  {feature.title}
                </h3>
                <p className="text-gray-400 leading-relaxed">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Cinematic Experiences */}
      <section className="py-20 md:py-28 bg-gray-900/30 border-y border-gray-800">
        <div className="container mx-auto px-6">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold mb-4">Explore Our Stories</h2>
              <p className="text-gray-400 max-w-2xl mx-auto">
                Choose from our collection of immersive cinematic experiences.
              </p>
            </div>

            {/* Category Filter */}
            <div className="flex flex-wrap gap-3 justify-center mb-12">
              {['all', 'story', 'interactive', 'immersive'].map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat as any)}
                  className={`px-6 py-2 rounded-full font-semibold transition-all ${
                    selectedCategory === cat
                      ? 'bg-red-500 text-black'
                      : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
                  }`}
                >
                  {cat.charAt(0).toUpperCase() + cat.slice(1)}
                </button>
              ))}
            </div>

            {/* Experiences Grid */}
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredExperiences.map((exp) => (
                <div
                  key={exp.id}
                  className="group bg-gray-900/50 border border-gray-800 rounded-2xl overflow-hidden hover:border-red-500/50 transition-all duration-300"
                >
                  {/* Card Header with Category Badge */}
                  <div className="relative h-40 bg-gradient-to-br from-red-500/20 to-purple-500/20 flex items-center justify-center overflow-hidden">
                    <Play className="w-16 h-16 text-red-400/50 group-hover:scale-110 transition-transform" />
                    <div className="absolute top-3 right-3 px-3 py-1 bg-red-500/80 text-white text-xs font-bold rounded-full capitalize">
                      {exp.category}
                    </div>
                  </div>

                  {/* Card Content */}
                  <div className="p-6">
                    <h3 className="text-xl font-bold text-white mb-2">
                      {exp.title}
                    </h3>
                    <p className="text-gray-400 text-sm mb-4">
                      {exp.description}
                    </p>

                    {/* Status Badge */}
                    <div className="flex items-center justify-between">
                      {exp.status === 'coming-soon' ? (
                        <span className="inline-flex items-center gap-2 px-3 py-1 bg-yellow-500/20 text-yellow-400 text-xs font-semibold rounded-full">
                          <Sparkles className="w-3 h-3" />
                          Coming Soon
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-2 px-3 py-1 bg-green-500/20 text-green-400 text-xs font-semibold rounded-full">
                          <Play className="w-3 h-3" />
                          Now Playing
                        </span>
                      )}
                      <button className="text-red-400 hover:text-red-300 transition-colors">
                        <ChevronRight className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 md:py-28">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-4xl font-bold text-center mb-12">How It Works</h2>
            <div className="space-y-8">
              {[
                { num: '1', title: 'Select Your Story', desc: 'Choose from our collection of cinematic experiences based on your mood and interests.' },
                { num: '2', title: 'Make Your Choices', desc: 'Guide the narrative with meaningful decisions that impact the story\'s direction and outcome.' },
                { num: '3', title: 'Experience Magic', desc: 'Watch as the AI generates unique scenes, dialogue, and visual descriptions in real-time.' },
                { num: '4', title: 'Share & Create', desc: 'Save your journey, share it with friends, and create new variations of your favorite stories.' },
              ].map((step, idx) => (
                <div key={idx} className="flex gap-6 items-start group">
                  <div className="w-12 h-12 rounded-full bg-red-500/20 border border-red-500/50 flex items-center justify-center flex-shrink-0 group-hover:bg-red-500 group-hover:text-black transition-all">
                    <span className="font-bold text-lg text-red-400 group-hover:text-black">{step.num}</span>
                  </div>
                  <div className="flex-1 pt-1">
                    <h3 className="text-xl font-bold text-white mb-2">{step.title}</h3>
                    <p className="text-gray-400">{step.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Roadmap */}
      <section className="py-16 md:py-20 bg-gradient-to-r from-red-500/10 to-purple-500/10 border-y border-gray-800">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-center mb-8">Coming to the Platform</h2>
            <div className="grid md:grid-cols-3 gap-6">
              {[
                { title: 'Multi-Agent Stories', desc: 'Collaborate with multiple AI agents in complex narratives.' },
                { title: 'Voice Acting', desc: 'Professional voice-over narration for immersive audio.' },
                { title: 'Social Theater', desc: 'Share experiences with friends in real-time.' },
              ].map((item, idx) => (
                <div key={idx} className="bg-gray-900/50 border border-gray-800 rounded-lg p-6 hover:border-red-500/50 transition-all">
                  <h4 className="font-semibold text-red-400 mb-2">{item.title}</h4>
                  <p className="text-gray-400 text-sm">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="container mx-auto px-6">
          <div className="max-w-2xl mx-auto text-center bg-gray-900/50 border border-gray-800 rounded-2xl p-12 hover:border-red-500/50 transition-all">
            <h2 className="text-3xl font-bold text-white mb-4">Ready for Your Cinematic Journey?</h2>
            <p className="text-gray-400 mb-8">
              Dive into immersive stories where your choices matter. Available on premium plans.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button
                onClick={() => onNavigate('subscription')}
                className="inline-block bg-red-500 text-white font-semibold px-8 py-3 rounded-full hover:bg-red-600 transition-all duration-300 transform hover:scale-105"
              >
                Start Streaming
              </button>
              <button
                onClick={() => onNavigate('home')}
                className="inline-block bg-gray-800 text-white font-semibold px-8 py-3 rounded-full hover:bg-gray-700 transition-all duration-300"
              >
                Learn More
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <section className="py-12 border-t border-gray-800 bg-black/50">
        <div className="container mx-auto px-6 text-center">
          <button
            onClick={() => onNavigate('home')}
            className="text-gray-400 hover:text-red-400 transition-colors font-medium"
          >
            ← Back to Home
          </button>
        </div>
      </section>
    </div>
  );
};

export default CinematicPage;
