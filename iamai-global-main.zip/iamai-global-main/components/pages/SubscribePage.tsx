import React, { useState, useEffect, useCallback } from 'react';
import {
  Agent,
  AGENT_PURCHASE_PLANS,
  PurchasePlan,
  PurchasePlanSlug,
} from '../../constants';
import { ALL_AGENTS } from '../../agents';
import type { Page } from '../../App';

const SubscriptionCard: React.FC<{
  plan: PurchasePlan;
  onSelect: () => void;
  agentName: string;
  isLoading: boolean;
  isSelected: boolean;
}> = ({ plan, onSelect, agentName, isLoading, isSelected }) => (
  <div
    className={`border rounded-2xl p-8 flex flex-col bg-gray-900/50 transition-all duration-300 ${
      isSelected
        ? 'border-cyan-500/80 shadow-lg shadow-cyan-500/30'
        : 'border-gray-800 hover:border-cyan-500/50'
    }`}
  >
    <h3 className="text-lg font-semibold text-cyan-400">{plan.name}</h3>
    <div className="mt-4 flex items-baseline">
      <span className="text-4xl font-bold text-white">{plan.price}</span>
      <span className="ml-1 text-gray-400">{plan.period}</span>
    </div>
    <p className="mt-4 text-gray-400 h-12">{plan.description}</p>
    <button
      onClick={onSelect}
      disabled={isLoading}
      title={`Subscribe to the ${plan.name} plan for ${agentName}`}
      className={`w-full text-center mt-8 block px-6 py-3 rounded-lg font-semibold transition-colors ${
        isLoading
          ? 'bg-gray-600 text-gray-400 cursor-not-allowed'
          : isSelected
            ? 'bg-cyan-500 text-black shadow-cyan-500/30 shadow-lg'
            : 'bg-cyan-500 text-black hover:bg-cyan-400'
      }`}
    >
      {isLoading ? 'Processing...' : 'Subscribe Now'}
    </button>
  </div>
);

const formatPlanLabel = (slug: PurchasePlanSlug) =>
  slug.charAt(0).toUpperCase() + slug.slice(1);

interface SubscribePageProps {
  onNavigate: (page: Page) => void;
}

const SubscribePage: React.FC<SubscribePageProps> = ({ onNavigate }) => {
  const [selectedAgent, setSelectedAgent] = useState<Agent | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [user, setUser] = useState<any>(null);
  const [initialPlan, setInitialPlan] = useState<PurchasePlanSlug | null>(null);
  const [highlightedPlan, setHighlightedPlan] = useState<PurchasePlanSlug | null>(null);
  const [autoCheckoutTriggered, setAutoCheckoutTriggered] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  const normalizeUserData = (rawUser: any) => {
    if (!rawUser) return null;
    const normalizedEmail =
      rawUser.email || rawUser.userEmail || rawUser.contactEmail || rawUser.primaryEmail || '';
    const normalizedId =
      rawUser.id ||
      rawUser._id ||
      rawUser.userId ||
      rawUser.uid ||
      rawUser.uuid ||
      rawUser.identifier ||
      normalizedEmail ||
      '';

    return {
      ...rawUser,
      id: normalizedId,
      email: normalizedEmail,
    };
  };

  const getStoredAuthData = () => {
    let storedUser: any = null;
    let storedToken: string | null = null;

    const legacyAuth = localStorage.getItem('iamai_auth');
    if (legacyAuth) {
      try {
        const parsedLegacy = JSON.parse(legacyAuth);
        const candidateUser = parsedLegacy.data?.user || parsedLegacy.user || parsedLegacy;
        storedUser = normalizeUserData(candidateUser);
        storedToken = parsedLegacy.data?.token || parsedLegacy.token || null;
      } catch (error) {
        console.error('Failed to parse legacy auth data:', error);
        localStorage.removeItem('iamai_auth');
        localStorage.removeItem('iamai_auth_token');
      }
    }

    if (!storedUser) {
      const storedUserData = localStorage.getItem('iamai_user');
      if (storedUserData) {
        try {
          const parsedUser = JSON.parse(storedUserData);
          storedUser = normalizeUserData(parsedUser);
        } catch (error) {
          console.error('Failed to parse stored user data:', error);
          localStorage.removeItem('iamai_user');
        }
      }
    }

    return { storedUser, storedToken };
  };

  useEffect(() => {
    // Get agent from URL parameter
    const urlParams = new URLSearchParams(window.location.search);
    const agentId = urlParams.get('agent');

    if (agentId) {
      const agent = ALL_AGENTS.find(a => a.id === agentId);
      if (agent) {
        setSelectedAgent(agent);
      }
    }

    // Check authentication (support both legacy tokens and new cookie-based flow)
    const { storedUser } = getStoredAuthData();
    if (storedUser) {
      console.log('Setting user from stored auth data:', {
        userEmail: storedUser.email,
        hasId: !!storedUser.id,
      });
      setUser(storedUser);
    }

    // Check for status messages
    const status = urlParams.get('status');
    if (status === 'cancelled') {
      setError('Payment was cancelled. Please try again if you want to subscribe.');
    }

    const planParam = urlParams.get('plan');
    if (planParam === 'daily' || planParam === 'weekly' || planParam === 'monthly') {
      const slug = planParam as PurchasePlanSlug;
      setHighlightedPlan(slug);
      if (status !== 'cancelled') {
        setInitialPlan(slug);
        setStatusMessage(`Preparing ${formatPlanLabel(slug)} checkout...`);
      } else {
        setInitialPlan(null);
        setStatusMessage(null);
      }
    }
  }, []);

  const handleSubscribe = useCallback(
    async (planName: PurchasePlanSlug | string) => {
      const normalizedPlan = planName.toLowerCase() as PurchasePlanSlug;
      setHighlightedPlan(normalizedPlan);
      setStatusMessage(
        `Redirecting you to checkout for the ${formatPlanLabel(normalizedPlan)} plan...`
      );

      if (!selectedAgent) return;

      setIsLoading(true);
      setError(null);

      try {
        // Get user info and auth token from storage (supports cookie-based auth)
        const { storedUser, storedToken } = getStoredAuthData();

        if (!storedUser || !storedUser.email) {
          console.error('User validation failed:', {
            hasStoredUser: !!storedUser,
            hasEmail: storedUser?.email,
          });
          setError('Your session has expired. Please log in again.');
          setIsLoading(false);
          setTimeout(() => onNavigate('login'), 2000);
          return;
        }

        // Map plan names to Stripe plan IDs
        const planMapping: Record<string, string> = {
          daily: 'daily',
          weekly: 'weekly',
          monthly: 'monthly',
        };

        const stripePlanId = planMapping[normalizedPlan];
        if (!stripePlanId) {
          throw new Error('Invalid plan selected');
        }

        // Create Stripe checkout session
        console.log('Making request to create checkout with plan:', stripePlanId);

        const API_BASE =
          window.location.hostname === 'localhost'
            ? 'http://localhost:3001'
            : 'https://iamai.global';
        const headers: Record<string, string> = {
          'Content-Type': 'application/json',
        };

        if (storedToken) {
          headers.Authorization = `Bearer ${storedToken}`;
        }

        const response = await fetch(`${API_BASE}/api/payments/create-checkout`, {
          method: 'POST',
          headers,
          credentials: 'include',
          body: JSON.stringify({
            plan: stripePlanId,
            userId: storedUser.id || storedUser.email,
            userEmail: storedUser.email,
            agentId: selectedAgent.id, // Include agent ID for tracking
            agentName: selectedAgent.name,
            successUrl: `${window.location.origin}/thank-you?agent=${selectedAgent.id}&plan=${stripePlanId}`,
            cancelUrl: `${window.location.origin}/subscribe?agent=${selectedAgent.id}&plan=${stripePlanId}&status=cancelled`,
          }),
        });

        console.log('Response status:', response.status);

        if (!response.ok) {
          const errorData = await response.json().catch(() => ({ error: 'Unknown error' }));
          console.error('Checkout error:', errorData);
          throw new Error(
            errorData.error || errorData.message || 'Failed to create checkout session'
          );
        }

        const { url } = await response.json();

        // Redirect to Stripe Checkout
        window.location.href = url;
      } catch (err: any) {
        console.error('Subscription error:', err);
        setError(err.message || 'Failed to start checkout. Please try again.');
        setStatusMessage(null);
        setIsLoading(false);
      }
    },
    [selectedAgent, onNavigate]
  );

  useEffect(() => {
    if (!initialPlan || autoCheckoutTriggered || !user || !selectedAgent) {
      return;
    }
    setAutoCheckoutTriggered(true);
    setStatusMessage(`Redirecting you to checkout for the ${formatPlanLabel(initialPlan)} plan...`);
    handleSubscribe(initialPlan);
  }, [initialPlan, autoCheckoutTriggered, user, selectedAgent, handleSubscribe]);

  const handleBackToDashboard = () => {
    onNavigate('dashboard');
  };

  const handleLogin = () => {
    onNavigate('login');
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="max-w-md mx-auto text-center p-8">
          <div className="mb-8">
            <i className="fa-solid fa-lock text-6xl text-gray-600 mb-4"></i>
            <h2 className="text-2xl font-bold text-white mb-4">Login Required</h2>
            <p className="text-gray-400 mb-6">
              You need to be logged in to subscribe to our agents.
            </p>
            <button
              onClick={handleLogin}
              className="px-6 py-3 bg-cyan-600 hover:bg-cyan-700 text-white font-semibold rounded-lg transition-colors mr-4"
            >
              Login to Continue
            </button>
            <button
              onClick={handleBackToDashboard}
              className="px-6 py-3 bg-gray-600 hover:bg-gray-700 text-white font-semibold rounded-lg transition-colors"
            >
              Back to Dashboard
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (!selectedAgent) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="max-w-md mx-auto text-center p-8">
          <div className="mb-8">
            <i className="fa-solid fa-robot text-6xl text-gray-600 mb-4"></i>
            <h2 className="text-2xl font-bold text-white mb-4">No Agent Selected</h2>
            <p className="text-gray-400 mb-6">Please select an agent to subscribe to.</p>
            <button
              onClick={handleBackToDashboard}
              className="px-6 py-3 bg-cyan-600 hover:bg-cyan-700 text-white font-semibold rounded-lg transition-colors"
            >
              Back to Dashboard
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black">
      {/* Header */}
      <header className="bg-black/95 backdrop-blur-sm border-b border-gray-800 sticky top-0 z-40">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="text-2xl font-bold text-white">
                IA <span className="text-cyan-400">M</span> AI
              </div>
              <div className="text-gray-400">/</div>
              <div className="text-gray-300">Subscribe</div>
            </div>
            <button
              onClick={handleBackToDashboard}
              className="text-gray-400 hover:text-white transition-colors"
              title="Back to Dashboard"
            >
              <i className="fa-solid fa-times text-xl"></i>
            </button>
          </div>
        </div>
      </header>

      {/* Subscription Content */}
      <section className="py-20 md:py-28">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <div className="w-20 h-20 flex items-center justify-center rounded-2xl bg-gray-800 mb-6 mx-auto text-cyan-400">
                {selectedAgent.icon && selectedAgent.icon.startsWith('data:image') ? (
                  <img
                    src={selectedAgent.icon}
                    alt={`${selectedAgent.name} icon`}
                    className="w-full h-full object-cover rounded-2xl"
                  />
                ) : (
                  <i className={`${selectedAgent.icon} text-6xl`}></i>
                )}
              </div>
              <h1 className="text-3xl md:text-4xl font-bold text-white">
                Subscribe to {selectedAgent.name}
              </h1>
              <p className="max-w-2xl mx-auto mt-4 text-gray-400">
                {selectedAgent.role}: {selectedAgent.description}
              </p>
            </div>

            {error && (
              <div className="mb-8 p-4 bg-red-500/10 border border-red-500/50 rounded-lg text-red-400 text-center">
                {error}
              </div>
            )}

            {statusMessage && (
              <div className="mb-8 p-4 bg-cyan-500/10 border border-cyan-500/40 rounded-lg text-cyan-200 text-center">
                {statusMessage}
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {AGENT_PURCHASE_PLANS.map(plan => {
                const slug = plan.name.toLowerCase() as PurchasePlanSlug;
                return (
                  <SubscriptionCard
                    key={plan.name}
                    plan={plan}
                    agentName={selectedAgent.name}
                    isLoading={isLoading}
                    isSelected={highlightedPlan === slug}
                    onSelect={() => handleSubscribe(slug)}
                  />
                );
              })}
            </div>

            <div className="text-center mt-12">
              <button
                onClick={handleBackToDashboard}
                disabled={isLoading}
                title="Return to dashboard"
                className={`transition-colors ${
                  isLoading
                    ? 'text-gray-600 cursor-not-allowed'
                    : 'text-gray-400 hover:text-cyan-400'
                }`}
              >
                &larr; Back to dashboard
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default SubscribePage;
