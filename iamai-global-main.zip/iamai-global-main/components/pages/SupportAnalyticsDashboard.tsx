/**
 * Support Analytics Dashboard
 * Tracks containment rate, escalation rate, CSAT score, latency, and top issues
 * Admin access only
 */

import React, { useState, useEffect } from 'react';
import { Line as LineChart, Bar as BarChart, Pie as PieChart } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, BarElement, ArcElement, Title, Tooltip, Legend } from 'chart.js';
import {
  TrendingUp,
  TrendingDown,
  AlertCircle,
  CheckCircle,
  Clock,
  MessageSquare,
  Activity,
  RefreshCw,
  Download,
  Filter,
} from 'lucide-react';

interface AnalyticsData {
  containmentRate: number;
  escalationRate: number;
  csatScore: number;
  avgLatency: number;
  totalTickets: number;
  resolvedTickets: number;
  escalatedTickets: number;
  averageResolutionTime: number;
  trendsData: Array<{
    date: string;
    containment: number;
    escalation: number;
    csat: number;
  }>;
  categoryBreakdown: Array<{
    name: string;
    value: number;
    percentage: number;
  }>;
  topIssues: Array<{
    title: string;
    count: number;
    severity: 'high' | 'medium' | 'low';
  }>;
  severityDistribution: Array<{
    name: string;
    value: number;
  }>;
}

interface SupportAnalyticsDashboardProps {
  onNavigate?: (page: string) => void;
  isAdmin?: boolean;
}

const SupportAnalyticsDashboard: React.FC<SupportAnalyticsDashboardProps> = ({
  onNavigate,
  isAdmin = false,
}) => {
  const [analytics, setAnalytics] = useState<AnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedPeriod, setSelectedPeriod] = useState('week'); // week, month, quarter, year
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!isAdmin) return;
    fetchAnalytics();
  }, [selectedPeriod, isAdmin]);

  /**
   * Fetch analytics data from backend
   */
  const fetchAnalytics = async (): Promise<void> => {
    try {
      setLoading(true);
      setError(null);

      const response = await fetch(`/api/support/analytics?period=${selectedPeriod}`, {
        method: 'GET',
        headers: { 'Content-Type': 'application/json' },
      });

      if (!response.ok) {
        throw new Error(`Failed to fetch analytics: ${response.status}`);
      }

      const data = await response.json();
      setAnalytics(data);
    } catch (err) {
      console.error('[Analytics] Error fetching data:', err);
      setError(err instanceof Error ? err.message : 'Failed to load analytics');
    } finally {
      setLoading(false);
    }
  };

  /**
   * Handle export to CSV
   */
  const handleExport = (): void => {
    if (!analytics) return;

    const csv = generateCSV(analytics);
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `support-analytics-${new Date().toISOString()}.csv`;
    a.click();
  };

  /**
   * Generate CSV from analytics data
   */
  const generateCSV = (data: AnalyticsData): string => {
    const lines = [
      ['Metric', 'Value'],
      ['Containment Rate', `${data.containmentRate}%`],
      ['Escalation Rate', `${data.escalationRate}%`],
      ['CSAT Score', data.csatScore.toFixed(2)],
      ['Average Latency', `${data.avgLatency}ms`],
      ['Total Tickets', data.totalTickets],
      ['Resolved Tickets', data.resolvedTickets],
      ['Escalated Tickets', data.escalatedTickets],
      ['Average Resolution Time', `${data.averageResolutionTime} hours`],
    ];

    return lines.map((line) => line.join(',')).join('\n');
  };

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-black text-white py-20 md:py-28">
        <div className="container mx-auto px-6 max-w-2xl">
          <div className="bg-gradient-to-br from-red-500/10 to-purple-500/10 border border-red-500/30 rounded-lg p-8 text-center">
            <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
            <h1 className="text-2xl font-bold text-white mb-2">Access Denied</h1>
            <p className="text-gray-400 mb-6">
              This dashboard is restricted to administrators only.
            </p>
            <button
              onClick={() => onNavigate?.('dashboard')}
              className="px-6 py-2 bg-cyan-500 hover:bg-cyan-600 text-black font-semibold rounded transition-colors"
            >
              Go to Dashboard
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-black text-white py-20 md:py-28">
        <div className="container mx-auto px-6">
          <div className="flex items-center justify-center gap-3">
            <div className="w-3 h-3 bg-cyan-500 rounded-full animate-pulse"></div>
            <span className="text-gray-400">Loading analytics...</span>
          </div>
        </div>
      </div>
    );
  }

  if (error || !analytics) {
    return (
      <div className="min-h-screen bg-black text-white py-20 md:py-28">
        <div className="container mx-auto px-6 max-w-2xl">
          <div className="bg-gradient-to-br from-red-500/10 to-purple-500/10 border border-red-500/30 rounded-lg p-6">
            <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
            <p className="text-center text-gray-400 mb-4">
              {error || 'Failed to load analytics data'}
            </p>
            <button
              onClick={fetchAnalytics}
              className="w-full px-4 py-2 bg-cyan-500 hover:bg-cyan-600 text-black font-semibold rounded transition-colors flex items-center justify-center gap-2"
            >
              <RefreshCw className="w-4 h-4" />
              Retry
            </button>
          </div>
        </div>
      </div>
    );
  }

  const colors = {
    cyan: '#06b6d4',
    green: '#10b981',
    red: '#ef4444',
    yellow: '#eab308',
    purple: '#a855f7',
    blue: '#3b82f6',
  };

  return (
    <div className="min-h-screen bg-black text-white py-20 md:py-28">
      <div className="container mx-auto px-6">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-2">
            Support Analytics Dashboard
          </h1>
          <p className="text-gray-400">
            Real-time insights into support performance and quality metrics
          </p>
        </div>

        {/* Controls */}
        <div className="flex flex-wrap items-center gap-4 mb-8">
          <div className="flex gap-2">
            <button
              onClick={() => setSelectedPeriod('week')}
              className={`px-4 py-2 rounded font-medium transition-colors ${
                selectedPeriod === 'week'
                  ? 'bg-cyan-500 text-black'
                  : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
              }`}
            >
              Week
            </button>
            <button
              onClick={() => setSelectedPeriod('month')}
              className={`px-4 py-2 rounded font-medium transition-colors ${
                selectedPeriod === 'month'
                  ? 'bg-cyan-500 text-black'
                  : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
              }`}
            >
              Month
            </button>
            <button
              onClick={() => setSelectedPeriod('quarter')}
              className={`px-4 py-2 rounded font-medium transition-colors ${
                selectedPeriod === 'quarter'
                  ? 'bg-cyan-500 text-black'
                  : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
              }`}
            >
              Quarter
            </button>
            <button
              onClick={() => setSelectedPeriod('year')}
              className={`px-4 py-2 rounded font-medium transition-colors ${
                selectedPeriod === 'year'
                  ? 'bg-cyan-500 text-black'
                  : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
              }`}
            >
              Year
            </button>
          </div>

          <div className="ml-auto flex gap-2">
            <button
              onClick={fetchAnalytics}
              className="px-4 py-2 bg-gray-800 hover:bg-gray-700 text-gray-300 rounded font-medium transition-colors flex items-center gap-2"
            >
              <RefreshCw className="w-4 h-4" />
              Refresh
            </button>
            <button
              onClick={handleExport}
              className="px-4 py-2 bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-400 border border-cyan-500/30 rounded font-medium transition-colors flex items-center gap-2"
            >
              <Download className="w-4 h-4" />
              Export
            </button>
          </div>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-8">
          {/* Containment Rate */}
          <div className="bg-gray-900/50 border border-gray-700/50 rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-gray-400 text-sm font-medium">Containment Rate</span>
              <CheckCircle className="w-4 h-4 text-green-400" />
            </div>
            <p className="text-3xl font-bold text-white mb-1">
              {analytics.containmentRate}%
            </p>
            <p className="text-xs text-green-400 flex items-center gap-1">
              <TrendingUp className="w-3 h-3" />
              Target: 85%
            </p>
          </div>

          {/* Escalation Rate */}
          <div className="bg-gray-900/50 border border-gray-700/50 rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-gray-400 text-sm font-medium">Escalation Rate</span>
              <AlertCircle className="w-4 h-4 text-yellow-400" />
            </div>
            <p className="text-3xl font-bold text-white mb-1">
              {analytics.escalationRate}%
            </p>
            <p className="text-xs text-yellow-400 flex items-center gap-1">
              <TrendingDown className="w-3 h-3" />
              Target: &lt;15%
            </p>
          </div>

          {/* CSAT Score */}
          <div className="bg-gray-900/50 border border-gray-700/50 rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-gray-400 text-sm font-medium">CSAT Score</span>
              <Activity className="w-4 h-4 text-cyan-400" />
            </div>
            <p className="text-3xl font-bold text-white mb-1">
              {analytics.csatScore.toFixed(1)}/5
            </p>
            <p className="text-xs text-cyan-400">Customer Satisfaction</p>
          </div>

          {/* Avg Latency */}
          <div className="bg-gray-900/50 border border-gray-700/50 rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-gray-400 text-sm font-medium">Avg Latency</span>
              <Clock className="w-4 h-4 text-purple-400" />
            </div>
            <p className="text-3xl font-bold text-white mb-1">
              {analytics.avgLatency}ms
            </p>
            <p className="text-xs text-purple-400">Response Time</p>
          </div>

          {/* Total Tickets */}
          <div className="bg-gray-900/50 border border-gray-700/50 rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-gray-400 text-sm font-medium">Total Tickets</span>
              <MessageSquare className="w-4 h-4 text-blue-400" />
            </div>
            <p className="text-3xl font-bold text-white mb-1">
              {analytics.totalTickets}
            </p>
            <p className="text-xs text-blue-400">
              {analytics.resolvedTickets} resolved
            </p>
          </div>
        </div>

        {/* Charts Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Trends Chart */}
          <div className="bg-gray-900/50 border border-gray-700/50 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-white mb-4">
              Performance Trends
            </h3>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={analytics.trendsData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis stroke="#9ca3af" />
                <YAxis stroke="#9ca3af" />
                <Tooltip
                  contentStyle={{ backgroundColor: '#111827', border: '1px solid #374151' }}
                  labelStyle={{ color: '#f3f4f6' }}
                />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="containment"
                  stroke={colors.green}
                  strokeWidth={2}
                  name="Containment %"
                />
                <Line
                  type="monotone"
                  dataKey="escalation"
                  stroke={colors.red}
                  strokeWidth={2}
                  name="Escalation %"
                />
                <Line
                  type="monotone"
                  dataKey="csat"
                  stroke={colors.cyan}
                  strokeWidth={2}
                  name="CSAT"
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Category Breakdown */}
          <div className="bg-gray-900/50 border border-gray-700/50 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-white mb-4">
              Issues by Category
            </h3>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={analytics.categoryBreakdown}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percentage }) => `${name} ${percentage}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {analytics.categoryBreakdown.map((_, index) => (
                    <Cell
                      key={`cell-${index}`}
                      fill={Object.values(colors)[index % Object.values(colors).length]}
                    />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ backgroundColor: '#111827', border: '1px solid #374151' }}
                  labelStyle={{ color: '#f3f4f6' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          {/* Severity Distribution */}
          <div className="bg-gray-900/50 border border-gray-700/50 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-white mb-4">
              Severity Distribution
            </h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={analytics.severityDistribution}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis stroke="#9ca3af" />
                <YAxis stroke="#9ca3af" />
                <Tooltip
                  contentStyle={{ backgroundColor: '#111827', border: '1px solid #374151' }}
                  labelStyle={{ color: '#f3f4f6' }}
                />
                <Bar dataKey="value" fill={colors.cyan} name="Tickets" />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Top Issues */}
          <div className="bg-gray-900/50 border border-gray-700/50 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-white mb-4">
              Top Issues This Period
            </h3>
            <div className="space-y-3">
              {analytics.topIssues.map((issue, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between p-3 bg-black/50 rounded border border-gray-700/50"
                >
                  <div className="flex-1">
                    <p className="text-sm font-medium text-white">{issue.title}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <span
                        className={`text-xs px-2 py-0.5 rounded ${
                          issue.severity === 'high'
                            ? 'bg-red-500/20 text-red-400'
                            : issue.severity === 'medium'
                            ? 'bg-yellow-500/20 text-yellow-400'
                            : 'bg-green-500/20 text-green-400'
                        }`}
                      >
                        {issue.severity.toUpperCase()}
                      </span>
                    </div>
                  </div>
                  <span className="text-lg font-bold text-cyan-400">
                    {issue.count}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer Stats */}
        <div className="bg-gray-900/50 border border-gray-700/50 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-white mb-4">
            Resolution Statistics
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <p className="text-gray-400 text-sm mb-2">Avg Resolution Time</p>
              <p className="text-2xl font-bold text-cyan-400">
                {analytics.averageResolutionTime}
                <span className="text-sm text-gray-400">hrs</span>
              </p>
            </div>
            <div>
              <p className="text-gray-400 text-sm mb-2">Resolution Rate</p>
              <p className="text-2xl font-bold text-green-400">
                {Math.round((analytics.resolvedTickets / analytics.totalTickets) * 100)}
                <span className="text-sm text-gray-400">%</span>
              </p>
            </div>
            <div>
              <p className="text-gray-400 text-sm mb-2">Escalated Tickets</p>
              <p className="text-2xl font-bold text-yellow-400">
                {analytics.escalatedTickets}
                <span className="text-sm text-gray-400">tickets</span>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SupportAnalyticsDashboard;
