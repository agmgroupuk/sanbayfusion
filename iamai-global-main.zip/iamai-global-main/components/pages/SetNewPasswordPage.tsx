import React, { useState, useEffect } from 'react';
import { getApiUrl } from '../../config/api';

interface SetNewPasswordPageProps {
  onNavigate: (page: 'home' | 'login' | 'signup') => void;
}

const SetNewPasswordPage: React.FC<SetNewPasswordPageProps> = ({ onNavigate }) => {
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [token, setToken] = useState('');
  const [success, setSuccess] = useState(false);
  const [countdown, setCountdown] = useState(5);

  // Extract token from URL (assuming it's passed as ?token=xyz)
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const resetToken = params.get('token');

    if (!resetToken) {
      setError('Invalid or missing reset link. Please request a new one.');
    } else {
      setToken(resetToken);
    }
  }, []);

  // Countdown timer for redirect
  useEffect(() => {
    if (success && countdown > 0) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
      return () => clearTimeout(timer);
    } else if (success && countdown === 0) {
      onNavigate('login');
    }
  }, [success, countdown, onNavigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!password || password.length < 8) {
      setError('Password must be at least 8 characters');
      return;
    }

    if (password !== confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    setLoading(true);
    setError('');
    setMessage('');

    try {
      const response = await fetch(getApiUrl('/auth/reset-password'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          token,
          password,
          confirmPassword
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to reset password');
      }

      setSuccess(true);
      setMessage('✓ Password reset successfully!');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to reset password. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="py-20 md:py-32 bg-black flex items-center justify-center min-h-screen">
      <div className="container mx-auto px-6">
        <div className="max-w-md mx-auto bg-gray-900/50 border border-gray-800 rounded-2xl p-8">
          {/* Logo */}
          <div className="text-center mb-8">
            <img 
              src="/assets/iamai-logo.png" 
              alt="IA M AI Logo" 
              className="h-12 w-auto mx-auto mb-4"
              onError={(e) => {
                e.currentTarget.style.display = 'none';
              }}
            />
          </div>

          {/* Header */}
          <div className="text-center mb-6">
            <h2 className="text-3xl font-bold text-white mb-2">Set New Password</h2>
            <p className="text-gray-400 text-sm">Create a strong password to secure your account</p>
          </div>

          {/* Messages */}
          {error && !success && (
            <div className="mb-4 p-3 bg-red-500/20 border border-red-500/50 rounded-lg text-red-400 text-sm">
              {error}
            </div>
          )}

          {message && success && (
            <div className="mb-4 p-3 bg-green-500/20 border border-green-500/50 rounded-lg text-green-400 text-sm">
              {message}
            </div>
          )}

          {/* Form */}
          {!success && !error ? (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  New Password
                </label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="At least 8 characters"
                  className="w-full px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500 transition-colors"
                  disabled={loading}
                />
                <p className="text-xs text-gray-500 mt-1">
                  Use a mix of letters, numbers, and symbols for security
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Confirm Password
                </label>
                <input
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Confirm your new password"
                  className="w-full px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500 transition-colors"
                  disabled={loading}
                />
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={loading || !token}
                className="w-full px-5 py-3 bg-cyan-500 text-black font-semibold rounded-lg hover:bg-cyan-400 transition-colors duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {loading ? (
                  <>
                    <span className="inline-block w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin"></span>
                    Resetting password...
                  </>
                ) : (
                  'Reset Password'
                )}
              </button>
            </form>
          ) : success ? (
            // Success state
            <div className="space-y-4">
              <div className="flex items-center justify-center">
                <div className="w-16 h-16 rounded-full bg-green-500/20 border border-green-500/50 flex items-center justify-center">
                  <span className="text-4xl">✓</span>
                </div>
              </div>
              <p className="text-center text-white font-semibold text-lg">
                Your password has been reset successfully!
              </p>
              <p className="text-center text-gray-400 text-sm">
                You can now log in with your new password.
              </p>
              <p className="text-center text-gray-500 text-xs">
                Redirecting to login in {countdown} seconds...
              </p>
              <button
                onClick={() => onNavigate('login')}
                className="w-full px-5 py-3 bg-cyan-500 text-black font-semibold rounded-lg hover:bg-cyan-400 transition-colors duration-300"
              >
                Go to Login Now
              </button>
            </div>
          ) : (
            // Error state
            <div className="space-y-4">
              <div className="flex items-center justify-center">
                <div className="w-16 h-16 rounded-full bg-red-500/20 border border-red-500/50 flex items-center justify-center">
                  <span className="text-3xl">✕</span>
                </div>
              </div>
              <p className="text-center text-white font-semibold">
                Invalid or Expired Link
              </p>
              <p className="text-center text-gray-400 text-sm">
                The password reset link has expired or is invalid. Please request a new one.
              </p>
              <button
                onClick={() => onNavigate('login')}
                className="w-full px-5 py-3 bg-cyan-500 text-black font-semibold rounded-lg hover:bg-cyan-400 transition-colors duration-300"
              >
                Back to Login
              </button>
            </div>
          )}

          {/* Divider */}
          {!error && (
            <>
              <div className="relative my-6">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-gray-700"></div>
                </div>
                <div className="relative flex justify-center text-sm">
                  <span className="px-2 bg-gray-900/50 text-gray-400">or</span>
                </div>
              </div>

              {/* Footer */}
              <div className="text-center space-y-3">
                <button
                  onClick={() => onNavigate('login')}
                  title="Go back to login"
                  className="text-gray-500 hover:text-gray-400 text-sm transition-colors"
                >
                  ← Back to Login
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </section>
  );
};

export default SetNewPasswordPage;
