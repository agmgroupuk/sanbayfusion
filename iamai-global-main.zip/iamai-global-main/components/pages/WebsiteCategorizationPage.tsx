import React, { useState, useEffect } from 'react';
import {
  Search,
  Globe,
  Tag,
  Folder,
  TrendingUp,
  Activity,
  BarChart3,
  Info,
  Clock,
  Copy,
  Download,
} from 'lucide-react';

interface Category {
  id: string;
  name: string;
  tier: number;
  confidence: number;
}

interface CategorizationData {
  url: string;
  categories: Category[];
  primaryCategory: string;
  secondaryCategories: string[];
  confidenceScore: number;
  iabCategories: {
    tier1: string[];
    tier2: string[];
  };
  contentType: string;
  language: string;
  safetyRating: 'safe' | 'moderate' | 'restricted' | 'adult';
  tags: string[];
}

interface HistoryItem {
  id: string;
  url: string;
  timestamp: number;
  primaryCategory: string;
  confidence: number;
  status: 'success' | 'error';
}

const WebsiteCategorizationPage: React.FC = () => {
  const [url, setUrl] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<CategorizationData | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [showHistory, setShowHistory] = useState(false);

  const [stats, setStats] = useState({
    totalAnalyzed: 0,
    uniqueCategories: 0,
    avgConfidence: 0,
    topCategory: 'N/A',
  });

  useEffect(() => {
    const savedHistory = toolDataService.getCategorizationHistory();
    if (savedHistory.length > 0) setHistory(savedHistory);
    const savedStats = toolDataService.getCategorizationStats();
    if (Object.keys(savedStats).length > 0) setStats(savedStats);
  }, []);

  useEffect(() => {
    if (history.length > 0) {
      toolDataService.saveCategorizationHistory(history);
      updateStats();
    }
  }, [history]);

  const updateStats = () => {
    const successItems = history.filter(h => h.status === 'success');
    const categories = new Set(successItems.map(h => h.primaryCategory));
    const avgConf =
      successItems.length > 0
        ? Math.round(successItems.reduce((sum, h) => sum + h.confidence, 0) / successItems.length)
        : 0;

    const categoryCounts: Record<string, number> = {};
    successItems.forEach(h => {
      categoryCounts[h.primaryCategory] = (categoryCounts[h.primaryCategory] || 0) + 1;
    });
    const topCat =
      Object.keys(categoryCounts).length > 0
        ? Object.entries(categoryCounts).sort((a, b) => b[1] - a[1])[0][0]
        : 'N/A';

    const newStats = {
      totalAnalyzed: history.length,
      uniqueCategories: categories.size,
      avgConfidence: avgConf,
      topCategory: topCat,
    };

    setStats(newStats);
    toolDataService.saveCategorizationStats(newStats);
  };

  const handleCategorize = async () => {
    if (!url.trim()) {
      setError('Please enter a URL');
      return;
    }

    setIsLoading(true);
    setError(null);
    setResult(null);

    try {
      const cleanUrl = url.replace(/^https?:\/\//, '').replace(/\/$/, '');

      const response = await fetch(
        `/api/tools/website-categorization?url=${encodeURIComponent(cleanUrl)}`
      );

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `API Error: ${response.status}`);
      }

      const data = await response.json();

      if (!data.success) {
        throw new Error(data.error || 'Failed to categorize website');
      }

      const categorizationData: CategorizationData = {
        url: data.url,
        categories: data.categories,
        primaryCategory: data.primaryCategory,
        secondaryCategories: data.secondaryCategories,
        confidenceScore: data.confidenceScore,
        iabCategories: data.iabCategories,
        contentType: data.contentType,
        language: data.language,
        safetyRating: data.safetyRating,
        tags: data.tags,
      };

      setResult(categorizationData);

      const historyItem: HistoryItem = {
        id: Date.now().toString(),
        url: cleanUrl,
        timestamp: Date.now(),
        primaryCategory: data.primaryCategory,
        confidence: data.confidenceScore,
        status: 'success',
      };

      setHistory(prev => [historyItem, ...prev]);
    } catch (err: any) {
      setError(err.message || 'Failed to categorize website');
      const historyItem: HistoryItem = {
        id: Date.now().toString(),
        url,
        timestamp: Date.now(),
        primaryCategory: 'Unknown',
        confidence: 0,
        status: 'error',
      };
      setHistory(prev => [historyItem, ...prev]);
    } finally {
      setIsLoading(false);
    }
  };

  const calculateSafetyRating = (
    category: string
  ): 'safe' | 'moderate' | 'restricted' | 'adult' => {
    const safeCats = ['Business', 'Technology', 'Education', 'News', 'Science'];
    const moderateCats = ['Entertainment', 'Sports', 'Shopping', 'Social Media'];
    const restrictedCats = ['Gaming', 'Dating', 'Forums'];

    if (safeCats.some(c => category.includes(c))) return 'safe';
    if (moderateCats.some(c => category.includes(c))) return 'moderate';
    if (restrictedCats.some(c => category.includes(c))) return 'restricted';
    return 'safe';
  };

  const generateTags = (primary: string, secondary: string[]): string[] => {
    const tags: string[] = [primary];
    tags.push(...secondary.slice(0, 3));
    tags.push('Web Application', 'Online Service');
    return tags.filter((t, idx) => tags.indexOf(t) === idx).slice(0, 6);
  };

  const getSafetyColor = (rating: string) => {
    switch (rating) {
      case 'safe':
        return 'from-green-500/10 to-emerald-500/10 border-green-500/30 text-green-400';
      case 'moderate':
        return 'from-yellow-500/10 to-orange-500/10 border-yellow-500/30 text-yellow-400';
      case 'restricted':
        return 'from-orange-500/10 to-red-500/10 border-orange-500/30 text-orange-400';
      case 'adult':
        return 'from-red-500/10 to-pink-500/10 border-red-500/30 text-red-400';
      default:
        return 'from-gray-500/10 to-gray-500/10 border-gray-500/30 text-gray-400';
    }
  };

  const getConfidenceColor = (conf: number) => {
    if (conf >= 80) return 'text-green-400';
    if (conf >= 60) return 'text-yellow-400';
    return 'text-orange-400';
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const exportData = () => {
    if (!result) return;
    const dataStr = JSON.stringify(result, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `categorization_${result.url.replace(/[^a-z0-9]/gi, '_')}_${Date.now()}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const formatTimestamp = (timestamp: number) => {
    const date = new Date(timestamp);
    return date.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <div className="min-h-screen bg-black text-white p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 bg-gradient-to-br from-purple-500/10 to-pink-500/10 rounded-xl">
              <Folder className="w-8 h-8 text-purple-400" />
            </div>
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-400 via-pink-400 to-cyan-400 bg-clip-text text-transparent">
                Website Categorization
              </h1>
              <p className="text-gray-400 mt-1">
                Classify websites with IAB categories and content analysis
              </p>
            </div>
          </div>

          <div className="bg-gradient-to-br from-purple-500/5 to-pink-500/5 border border-purple-500/20 rounded-xl p-4">
            <div className="flex items-start gap-3">
              <Info className="w-5 h-5 text-purple-400 mt-0.5 flex-shrink-0" />
              <div className="text-sm text-gray-300">
                <p className="font-semibold text-purple-400 mb-1">About Website Categorization</p>
                <p>
                  Automatically classifies websites using IAB (Interactive Advertising Bureau)
                  taxonomy with AI-powered content analysis. Powered by{' '}
                  <span className="text-cyan-400 font-semibold">IA M AI Global Platform</span>.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Stats Dashboard */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border border-cyan-500/20 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <Search className="w-5 h-5 text-cyan-400" />
              <TrendingUp className="w-4 h-4 text-cyan-400/50" />
            </div>
            <div className="text-2xl font-bold text-cyan-400">{stats?.totalAnalyzed || 0}</div>
            <div className="text-sm text-gray-400 mt-1">Websites Analyzed</div>
          </div>

          <div className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border border-purple-500/20 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <Folder className="w-5 h-5 text-purple-400" />
              <Activity className="w-4 h-4 text-purple-400/50" />
            </div>
            <div className="text-2xl font-bold text-purple-400">{stats?.uniqueCategories || 0}</div>
            <div className="text-sm text-gray-400 mt-1">Unique Categories</div>
          </div>

          <div className="bg-gradient-to-br from-green-500/10 to-emerald-500/10 border border-green-500/20 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <BarChart3 className="w-5 h-5 text-green-400" />
              <Globe className="w-4 h-4 text-green-400/50" />
            </div>
            <div className="text-2xl font-bold text-green-400">{stats?.avgConfidence || 0}%</div>
            <div className="text-sm text-gray-400 mt-1">Avg Confidence</div>
          </div>

          <div className="bg-gradient-to-br from-orange-500/10 to-yellow-500/10 border border-orange-500/20 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <Tag className="w-5 h-5 text-orange-400" />
              <TrendingUp className="w-4 h-4 text-orange-400/50" />
            </div>
            <div
              className="text-base font-bold text-orange-400 truncate"
              title={stats?.topCategory || 'N/A'}
            >
              {stats?.topCategory?.length > 10
                ? stats.topCategory.substring(0, 10) + '...'
                : stats?.topCategory || 'N/A'}
            </div>
            <div className="text-sm text-gray-400 mt-1">Top Category</div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Search */}
            <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
              <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <Globe className="w-5 h-5 text-purple-400" />
                Categorize Website
              </h2>
              <div className="flex flex-col sm:flex-row gap-3">
                <input
                  type="text"
                  value={url}
                  onChange={e => setUrl(e.target.value)}
                  onKeyPress={e => e.key === 'Enter' && !isLoading && handleCategorize()}
                  placeholder="Enter URL (e.g., example.com)"
                  className="flex-1 px-4 py-3 bg-black border border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 text-white placeholder-gray-500"
                  disabled={isLoading}
                />
                <button
                  onClick={handleCategorize}
                  disabled={isLoading}
                  className="w-full sm:w-auto px-6 py-3 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 disabled:from-gray-600 disabled:to-gray-700 rounded-lg font-semibold transition-all duration-200 flex items-center justify-center gap-2"
                >
                  {isLoading ? (
                    <>
                      <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      Analyzing...
                    </>
                  ) : (
                    <>
                      <Search className="w-5 h-5" />
                      Categorize
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Error */}
            {error && (
              <div className="bg-gradient-to-br from-red-500/10 to-pink-500/10 border border-red-500/30 rounded-xl p-4">
                <div className="flex items-center gap-3">
                  <Info className="w-5 h-5 text-red-400" />
                  <p className="text-red-400">{error}</p>
                </div>
              </div>
            )}

            {/* Results */}
            {result && (
              <div className="space-y-6">
                {/* Primary Category */}
                <div
                  className={`bg-gradient-to-br ${getSafetyColor(result.safetyRating)} border rounded-xl p-6`}
                >
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-semibold flex items-center gap-2">
                      <Folder className="w-5 h-5" />
                      Classification Results
                    </h2>
                    <div className="flex gap-2">
                      <button
                        onClick={() => copyToClipboard(JSON.stringify(result, null, 2))}
                        className="p-2 bg-gray-800 hover:bg-gray-700 border border-gray-700 rounded-lg"
                      >
                        <Copy className="w-4 h-4" />
                      </button>
                      <button
                        onClick={exportData}
                        className="p-2 bg-gradient-to-r from-purple-500/20 to-pink-500/20 border border-purple-500/30 rounded-lg"
                      >
                        <Download className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  <div className="mb-4">
                    <div className="text-sm text-gray-400 mb-2">Website</div>
                    <div className="text-xl font-semibold mb-4">{result.url}</div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className="text-sm text-gray-400 mb-2">Primary Category</div>
                      <div className="text-2xl font-bold mb-1">{result.primaryCategory}</div>
                    </div>
                    <div>
                      <div className="text-sm text-gray-400 mb-2">Confidence</div>
                      <div
                        className={`text-2xl font-bold ${getConfidenceColor(result.confidenceScore)}`}
                      >
                        {result.confidenceScore.toFixed(1)}%
                      </div>
                    </div>
                  </div>

                  <div className="mt-4">
                    <span
                      className={`px-3 py-1.5 rounded-full text-sm font-bold uppercase ${getSafetyColor(result.safetyRating)}`}
                    >
                      {result.safetyRating} Content
                    </span>
                  </div>
                </div>

                {/* All Categories */}
                <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
                  <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                    <BarChart3 className="w-5 h-5 text-purple-400" />
                    Category Breakdown
                  </h3>
                  <div className="space-y-3">
                    {result.categories.map(category => (
                      <div
                        key={category.id}
                        className="bg-gray-800/50 border border-gray-700 rounded-lg p-4"
                      >
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <Tag className="w-4 h-4 text-purple-400" />
                            <span className="font-medium">{category.name}</span>
                          </div>
                          <span
                            className={`text-sm font-semibold ${getConfidenceColor(category.confidence)}`}
                          >
                            {category.confidence.toFixed(1)}%
                          </span>
                        </div>
                        <div className="w-full bg-gray-700 rounded-full h-2 overflow-hidden">
                          <div
                            className={`h-full ${category.confidence >= 80 ? 'bg-green-500' : category.confidence >= 60 ? 'bg-yellow-500' : 'bg-orange-500'}`}
                            style={{ width: `${category.confidence}%` }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* IAB Categories */}
                <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
                  <h3 className="text-lg font-semibold mb-4">IAB Categories</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <div className="text-sm text-gray-400 mb-3">Tier 1 (Primary)</div>
                      <div className="space-y-2">
                        {result.iabCategories.tier1.map((cat, idx) => (
                          <div
                            key={idx}
                            className="px-3 py-2 bg-purple-500/10 border border-purple-500/20 rounded-lg text-sm"
                          >
                            {cat}
                          </div>
                        ))}
                      </div>
                    </div>
                    <div>
                      <div className="text-sm text-gray-400 mb-3">Tier 2 (Secondary)</div>
                      <div className="space-y-2">
                        {result.iabCategories.tier2.map((cat, idx) => (
                          <div
                            key={idx}
                            className="px-3 py-2 bg-cyan-500/10 border border-cyan-500/20 rounded-lg text-sm"
                          >
                            {cat}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Tags */}
                <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
                  <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                    <Tag className="w-5 h-5 text-cyan-400" />
                    Content Tags
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {result.tags.map((tag, idx) => (
                      <span
                        key={idx}
                        className="px-3 py-1.5 bg-gradient-to-r from-cyan-500/20 to-blue-500/20 border border-cyan-500/30 rounded-full text-sm font-medium"
                      >
                        #{tag}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Additional Info */}
                <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
                  <h3 className="text-lg font-semibold mb-4">Additional Information</h3>
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Content Type:</span>
                      <span className="text-white font-medium">{result.contentType}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Language:</span>
                      <span className="text-white font-medium">
                        {result.language.toUpperCase()}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Safety Rating:</span>
                      <span
                        className={`font-medium capitalize ${getSafetyColor(result.safetyRating).split(' ').pop()}`}
                      >
                        {result.safetyRating}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* History Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-gray-900 border border-gray-800 rounded-xl p-6 sticky top-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold flex items-center gap-2">
                  <Clock className="w-5 h-5 text-cyan-400" />
                  Recent Analysis
                </h2>
                <button
                  onClick={() => setShowHistory(!showHistory)}
                  className="text-sm text-cyan-400 hover:text-cyan-300"
                >
                  {showHistory ? 'Hide' : 'Show'}
                </button>
              </div>

              {showHistory && (
                <div className="space-y-3 max-h-[600px] overflow-y-auto custom-scrollbar">
                  {history.length === 0 ? (
                    <p className="text-gray-500 text-sm text-center py-8">
                      No analysis history yet
                    </p>
                  ) : (
                    history.map(item => (
                      <div
                        key={item.id}
                        onClick={() => item.status === 'success' && setUrl(item.url)}
                        className="p-3 rounded-lg border bg-gray-800/50 border-gray-700 hover:bg-gray-800 cursor-pointer transition-colors"
                      >
                        <div className="text-sm text-white font-medium mb-2 truncate">
                          {item.url}
                        </div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-xs text-purple-400 truncate">
                            {item.primaryCategory}
                          </span>
                          <span
                            className={`text-xs font-bold ${getConfidenceColor(item.confidence)}`}
                          >
                            {item.confidence}%
                          </span>
                        </div>
                        <div className="text-xs text-gray-500">
                          {formatTimestamp(item.timestamp)}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 6px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: #1f2937; border-radius: 3px; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #4b5563; border-radius: 3px; }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: #6b7280; }
      `}</style>
    </div>
  );
};

export default WebsiteCategorizationPage;
