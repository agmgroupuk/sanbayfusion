import React from 'react';
import { Page } from '../../App';
import SolutionsSection from '../SolutionsSection';

interface SolutionsPageProps {
  onNavigate: (page: Page) => void;
}

const SolutionsPage: React.FC<SolutionsPageProps> = ({ onNavigate }) => {
  return (
    <div className="bg-[#0a0a0a]">
      <SolutionsSection />
      <div className="text-center pb-20">
        <button onClick={() => onNavigate('home')} title="Return to the homepage" className="text-cyan-400 hover:text-cyan-300 font-semibold">
          &larr; Back to Home
        </button>
      </div>
    </div>
  );
};

export default SolutionsPage;
