import React, { useState, useEffect } from 'react';
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  ResponsiveContainer,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from 'recharts';
import {
  Activity,
  Users,
  MessageSquare,
  TrendingUp,
  Zap,
  BarChart3,
  ArrowLeft,
} from 'lucide-react';
import { getSocket } from '../../services/socket';

const AnalyticsPage = ({ onNavigate }) => {
  const [stats, setStats] = useState({
    totalRequests: 0,
    activeUsers: 0,
    totalMessages: 0,
    avgResponseTime: 0,
  });

  const [requestData, setRequestData] = useState<any[]>([]);
  const [messageData, setMessageData] = useState<any[]>([]);
  const [userData, setUserData] = useState<any[]>([]);
  const [agentData, setAgentData] = useState<any[]>([]);
  const [performanceData, setPerformanceData] = useState<any[]>([]);

  useEffect(() => {
    const socket = getSocket();

    socket.on('analytics:update', (data: any) => {
      if (data.stats) setStats(data.stats);
      if (data.requestData) setRequestData(data.requestData);
      if (data.messageData) setMessageData(data.messageData);
      if (data.userData) setUserData(data.userData);
      if (data.agentData) setAgentData(data.agentData);
      if (data.performanceData) setPerformanceData(data.performanceData);
    });

    socket.emit('analytics:request');

    // Mock data for development
    const mockData = {
      requestData: [
        { time: '00:00', requests: 120 },
        { time: '04:00', requests: 150 },
        { time: '08:00', requests: 280 },
        { time: '12:00', requests: 420 },
        { time: '16:00', requests: 380 },
        { time: '20:00', requests: 250 },
      ],
      messageData: [
        { date: 'Mon', messages: 340 },
        { date: 'Tue', messages: 420 },
        { date: 'Wed', messages: 380 },
        { date: 'Thu', messages: 520 },
        { date: 'Fri', messages: 460 },
        { date: 'Sat', messages: 290 },
        { date: 'Sun', messages: 250 },
      ],
      userData: [
        { hour: '00:00', users: 45 },
        { hour: '04:00', users: 30 },
        { hour: '08:00', users: 85 },
        { hour: '12:00', users: 120 },
        { hour: '16:00', users: 95 },
        { hour: '20:00', users: 70 },
      ],
      agentData: [
        { name: 'AgentX', value: 450 },
        { name: 'LazyLarry', value: 380 },
        { name: 'SassySarah', value: 320 },
        { name: 'GamerGary', value: 280 },
        { name: 'Others', value: 570 },
      ],
      performanceData: [
        { metric: 'Uptime', value: 98 },
        { metric: 'Accuracy', value: 95 },
        { metric: 'Speed', value: 92 },
        { metric: 'Engagement', value: 88 },
        { metric: 'Satisfaction', value: 94 },
      ],
    };

    setRequestData(mockData.requestData);
    setMessageData(mockData.messageData);
    setUserData(mockData.userData);
    setAgentData(mockData.agentData);
    setPerformanceData(mockData.performanceData);

    setStats({
      totalRequests: 15420,
      activeUsers: 342,
      totalMessages: 8945,
      avgResponseTime: 1.2,
    });

    return () => {
      socket.off('analytics:update');
    };
  }, []);

  const COLORS = ['#06b6d4', '#a855f7', '#ec4899', '#f59e0b', '#10b981'];

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Hero Section */}
      <section className="relative overflow-hidden border-b border-gray-800">
        <div className="absolute inset-0 bg-grid-gray-900 [mask-image:linear-gradient(to_bottom,white_30%,transparent)]"></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-to-r from-cyan-500/10 to-purple-500/10 rounded-full blur-3xl"></div>

        <div className="container mx-auto px-6 py-12 md:py-16 relative z-10">
          {/* Back Button */}
          <div className="flex justify-start mb-6">
            <button
              onClick={() => onNavigate('status')}
              className="inline-flex items-center px-4 py-2 rounded-lg bg-gray-900/50 backdrop-blur-sm border border-gray-700 hover:border-cyan-500/50 text-gray-400 hover:text-cyan-400 transition-all duration-300 group"
            >
              <ArrowLeft className="w-4 h-4 mr-2 group-hover:-translate-x-1 transition-transform" />
              Back to Status
            </button>
          </div>

          {/* Icon Badge */}
          <div className="flex justify-center mb-6">
            <div className="inline-flex items-center justify-center p-4 rounded-2xl bg-gradient-to-br from-cyan-500/20 to-purple-500/20 backdrop-blur-sm border border-cyan-500/30">
              <BarChart3 className="w-8 h-8 sm:w-10 sm:h-10 text-cyan-400" />
            </div>
          </div>

          {/* Title */}
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold text-center mb-4 bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400">
            Analytics Dashboard
          </h1>

          {/* Subtitle */}
          <p className="text-center text-gray-400 text-base md:text-lg mb-8 max-w-2xl mx-auto">
            Real-time insights and performance metrics tracking API requests, user activity, agent
            distribution, and system performance across all services.
          </p>

          {/* Quick Stats Preview */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 sm:gap-6 max-w-4xl mx-auto">
            <div className="text-center">
              <div className="text-2xl sm:text-3xl font-bold text-cyan-400">
                {stats?.totalRequests?.toLocaleString() || '0'}
              </div>
              <div className="text-xs sm:text-sm text-gray-400">Total Requests</div>
            </div>
            <div className="text-center">
              <div className="text-2xl sm:text-3xl font-bold text-purple-400">
                {stats?.activeUsers || 0}
              </div>
              <div className="text-xs sm:text-sm text-gray-400">Active Users</div>
            </div>
            <div className="text-center">
              <div className="text-2xl sm:text-3xl font-bold text-pink-400">
                {stats?.totalMessages?.toLocaleString() || '0'}
              </div>
              <div className="text-xs sm:text-sm text-gray-400">Messages</div>
            </div>
            <div className="text-center">
              <div className="text-2xl sm:text-3xl font-bold text-green-400">
                {stats?.avgResponseTime || 0}s
              </div>
              <div className="text-xs sm:text-sm text-gray-400">Avg Response</div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <div className="container mx-auto px-4 pb-12">
        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          <div className="bg-gray-900/50 backdrop-blur-sm rounded-xl p-6 border border-cyan-500/30">
            <div className="flex items-center justify-between mb-4">
              <Activity className="w-8 h-8 text-cyan-400" />
              <span className="text-green-400 text-sm">+12%</span>
            </div>
            <p className="text-gray-400 text-sm mb-2">Total Requests</p>
            <p className="text-3xl font-bold text-white">
              {stats?.totalRequests?.toLocaleString() || '0'}
            </p>
          </div>

          <div className="bg-gray-900/50 backdrop-blur-sm rounded-xl p-6 border border-purple-500/30">
            <div className="flex items-center justify-between mb-4">
              <Users className="w-8 h-8 text-purple-400" />
              <span className="text-green-400 text-sm">+8%</span>
            </div>
            <p className="text-gray-400 text-sm mb-2">Active Users</p>
            <p className="text-3xl font-bold text-white">
              {stats?.activeUsers?.toLocaleString() || '0'}
            </p>
          </div>

          <div className="bg-gray-900/50 backdrop-blur-sm rounded-xl p-6 border border-pink-500/30">
            <div className="flex items-center justify-between mb-4">
              <MessageSquare className="w-8 h-8 text-pink-400" />
              <span className="text-green-400 text-sm">+15%</span>
            </div>
            <p className="text-gray-400 text-sm mb-2">Total Messages</p>
            <p className="text-3xl font-bold text-white">
              {stats?.totalMessages?.toLocaleString() || '0'}
            </p>
          </div>

          <div className="bg-gray-900/50 backdrop-blur-sm rounded-xl p-6 border border-cyan-500/30">
            <div className="flex items-center justify-between mb-4">
              <Zap className="w-8 h-8 text-cyan-400" />
              <span className="text-green-400 text-sm">-5%</span>
            </div>
            <p className="text-gray-400 text-sm mb-2">Avg Response Time</p>
            <p className="text-3xl font-bold text-white">{stats?.avgResponseTime || 0}s</p>
          </div>
        </div>

        {/* Charts Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* API Requests Chart */}
          <div className="bg-gray-900/50 backdrop-blur-sm rounded-xl p-6 border border-cyan-500/30">
            <h3 className="text-xl font-semibold mb-6 text-white flex items-center">
              <TrendingUp className="w-5 h-5 mr-2 text-cyan-400" />
              API Requests
            </h3>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={requestData}>
                <defs>
                  <linearGradient id="colorRequests" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.8} />
                    <stop offset="95%" stopColor="#06b6d4" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="time" stroke="#9ca3af" />
                <YAxis stroke="#9ca3af" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#1f2937',
                    border: '1px solid #374151',
                    borderRadius: '8px',
                  }}
                  labelStyle={{ color: '#fff' }}
                />
                <Area
                  type="monotone"
                  dataKey="requests"
                  stroke="#06b6d4"
                  fillOpacity={1}
                  fill="url(#colorRequests)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          {/* Message Volume Chart */}
          <div className="bg-gray-900/50 backdrop-blur-sm rounded-xl p-6 border border-purple-500/30">
            <h3 className="text-xl font-semibold mb-6 text-white flex items-center">
              <MessageSquare className="w-5 h-5 mr-2 text-purple-400" />
              Message Volume
            </h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={messageData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="date" stroke="#9ca3af" />
                <YAxis stroke="#9ca3af" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#1f2937',
                    border: '1px solid #374151',
                    borderRadius: '8px',
                  }}
                  labelStyle={{ color: '#fff' }}
                />
                <Bar dataKey="messages" fill="#a855f7" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Active Users Chart */}
          <div className="bg-gray-900/50 backdrop-blur-sm rounded-xl p-6 border border-pink-500/30">
            <h3 className="text-xl font-semibold mb-6 text-white flex items-center">
              <Users className="w-5 h-5 mr-2 text-pink-400" />
              Active Users
            </h3>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={userData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="hour" stroke="#9ca3af" />
                <YAxis stroke="#9ca3af" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#1f2937',
                    border: '1px solid #374151',
                    borderRadius: '8px',
                  }}
                  labelStyle={{ color: '#fff' }}
                />
                <Line
                  type="monotone"
                  dataKey="users"
                  stroke="#ec4899"
                  strokeWidth={2}
                  dot={{ fill: '#ec4899' }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Agent Distribution Chart */}
          <div className="bg-gray-900/50 backdrop-blur-sm rounded-xl p-6 border border-cyan-500/30">
            <h3 className="text-xl font-semibold mb-6 text-white flex items-center">
              <Activity className="w-5 h-5 mr-2 text-cyan-400" />
              Agent Distribution
            </h3>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={agentData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }: any) =>
                    `${name} ${((percent || 0) * 100).toFixed(0)}%`
                  }
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {agentData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#1f2937',
                    border: '1px solid #374151',
                    borderRadius: '8px',
                  }}
                  labelStyle={{ color: '#fff' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          {/* Performance Radar Chart */}
          <div className="bg-gray-900/50 backdrop-blur-sm rounded-xl p-6 border border-purple-500/30 lg:col-span-2">
            <h3 className="text-xl font-semibold mb-6 text-white flex items-center">
              <Zap className="w-5 h-5 mr-2 text-purple-400" />
              Performance Metrics
            </h3>
            <ResponsiveContainer width="100%" height={400}>
              <RadarChart data={performanceData}>
                <PolarGrid stroke="#374151" />
                <PolarAngleAxis dataKey="metric" stroke="#9ca3af" />
                <PolarRadiusAxis stroke="#9ca3af" />
                <Radar
                  name="Performance"
                  dataKey="value"
                  stroke="#a855f7"
                  fill="#a855f7"
                  fillOpacity={0.6}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#1f2937',
                    border: '1px solid #374151',
                    borderRadius: '8px',
                  }}
                  labelStyle={{ color: '#fff' }}
                />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AnalyticsPage;
