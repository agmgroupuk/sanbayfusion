import React, { useState, useEffect } from 'react';
import { ArrowLeft, AlertTriangle, CheckCircle, Loader, Upload, X } from 'lucide-react';
import ReportService from '../../services/ReportService';
import type { ReportData } from '../../services/ReportService';

interface FormState {
  reporterEmail: string;
  reporterName: string;
  category: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  description: string;
  affectedUser: string;
  evidenceFile?: File;
  agreedToTerms: boolean;
  agreedToAccuracy: boolean;
}

interface SubmissionState {
  isSubmitting: boolean;
  error: string | null;
  success: boolean;
  reportId: string | null;
}

export default function ReportsPage(): JSX.Element {
  const [isLoggedIn] = useState(true); // Assume logged in, adjust based on context
  const [formState, setFormState] = useState<FormState>({
    reporterEmail: '',
    reporterName: '',
    category: '',
    severity: 'medium',
    description: '',
    affectedUser: '',
    agreedToTerms: false,
    agreedToAccuracy: false,
  });

  const [submissionState, setSubmissionState] = useState<SubmissionState>({
    isSubmitting: false,
    error: null,
    success: false,
    reportId: null,
  });

  const [characterCount, setCharacterCount] = useState(0);
  const [showFileUpload, setShowFileUpload] = useState(false);
  const [fileName, setFileName] = useState<string | null>(null);

  // Get category icon
  const getCategoryIcon = (category: string): string => {
    return ReportService.REPORT_CATEGORIES[category as keyof typeof ReportService.REPORT_CATEGORIES]?.icon || '❓';
  };

  // Handle form input changes
  const handleInputChange = (field: keyof FormState, value: any) => {
    setFormState((prev) => ({ ...prev, [field]: value }));

    if (field === 'description') {
      setCharacterCount(value.length);
    }
  };

  // Handle file upload
  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // Validate file size (max 10MB)
      if (file.size > 10 * 1024 * 1024) {
        setSubmissionState((prev) => ({
          ...prev,
          error: 'File size must not exceed 10MB',
        }));
        return;
      }

      // Validate file type
      const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'application/pdf', 'text/plain'];
      if (!allowedTypes.includes(file.type)) {
        setSubmissionState((prev) => ({
          ...prev,
          error: 'Please upload an image (JPG, PNG, GIF), PDF, or text file',
        }));
        return;
      }

      setFormState((prev) => ({ ...prev, evidenceFile: file }));
      setFileName(file.name);
      setSubmissionState((prev) => ({ ...prev, error: null }));
    }
  };

  // Remove uploaded file
  const handleRemoveFile = () => {
    setFormState((prev) => ({ ...prev, evidenceFile: undefined }));
    setFileName(null);
  };

  // Validate form
  const validateForm = (): { isValid: boolean; errors: string[] } => {
    const errors: string[] = [];

    if (!formState.reporterEmail.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
      errors.push('Valid email address is required');
    }

    if (!formState.category) {
      errors.push('Please select a report category');
    }

    if (formState.description.trim().length < 20) {
      errors.push('Description must be at least 20 characters');
    }

    if (formState.description.length > 5000) {
      errors.push('Description cannot exceed 5000 characters');
    }

    if (!formState.agreedToTerms) {
      errors.push('You must agree to the Terms and Conditions');
    }

    if (!formState.agreedToAccuracy) {
      errors.push('You must confirm the accuracy of your report');
    }

    return {
      isValid: errors.length === 0,
      errors,
    };
  };

  // Handle form submission
  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();

    // Validate form
    const validation = validateForm();
    if (!validation.isValid) {
      setSubmissionState({
        isSubmitting: false,
        error: validation.errors.join('; '),
        success: false,
        reportId: null,
      });
      return;
    }

    setSubmissionState({
      isSubmitting: true,
      error: null,
      success: false,
      reportId: null,
    });

    try {
      // Simulate file upload if present
      let evidenceUrl: string | undefined;
      if (formState.evidenceFile) {
        // In a real implementation, upload to cloud storage
        evidenceUrl = `evidence-${Date.now()}-${formState.evidenceFile.name}`;
      }

      // Submit report
      const response = await ReportService.submitReport({
        reporterEmail: formState.reporterEmail,
        reporterName: formState.reporterName,
        category: formState.category,
        severity: formState.severity,
        description: formState.description,
        affectedUser: formState.affectedUser,
        evidenceUrl,
      });

      if (response.success) {
        setSubmissionState({
          isSubmitting: false,
          error: null,
          success: true,
          reportId: response.reportId || null,
        });

        // Reset form
        setFormState({
          reporterEmail: '',
          reporterName: '',
          category: '',
          severity: 'medium',
          description: '',
          affectedUser: '',
          agreedToTerms: false,
          agreedToAccuracy: false,
        });
        setCharacterCount(0);
        setFileName(null);
      } else {
        setSubmissionState({
          isSubmitting: false,
          error: response.message,
          success: false,
          reportId: null,
        });
      }
    } catch (error) {
      setSubmissionState({
        isSubmitting: false,
        error: `An error occurred: ${error instanceof Error ? error.message : 'Unknown error'}`,
        success: false,
        reportId: null,
      });
    }
  };

  if (submissionState.success) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-4 sm:p-8">
        <div className="max-w-2xl mx-auto">
          {/* Success Message */}
          <div className="bg-gradient-to-r from-emerald-500/20 to-cyan-500/20 border border-emerald-500/50 rounded-xl p-8 text-center">
            <CheckCircle className="w-16 h-16 mx-auto text-emerald-400 mb-4" />

            <h1 className="text-3xl font-bold text-white mb-2">Report Submitted Successfully</h1>

            <p className="text-slate-300 mb-6">
              Thank you for helping us maintain a safe and respectful community. Your report has been received and will be reviewed by our moderation team.
            </p>

            {submissionState.reportId && (
              <div className="bg-slate-800/50 rounded-lg p-4 mb-6">
                <p className="text-slate-400 text-sm mb-1">Report ID:</p>
                <p className="text-cyan-400 font-mono text-lg break-all">{submissionState.reportId}</p>
                <p className="text-slate-400 text-sm mt-2">Keep this ID for your records to track the status of your report.</p>
              </div>
            )}

            <p className="text-slate-300 mb-6">
              We will investigate this matter thoroughly. If you have any additional information, you can submit another report with the details.
            </p>

            <button
              onClick={() => window.history.back()}
              className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 text-white font-semibold rounded-lg transition-all duration-300 transform hover:scale-105"
            >
              <ArrowLeft size={20} />
              Back to Dashboard
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-4 sm:p-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <button
            onClick={() => window.history.back()}
            className="flex items-center gap-2 text-cyan-400 hover:text-cyan-300 transition-colors mb-4"
          >
            <ArrowLeft size={20} />
            Back
          </button>

          <h1 className="text-4xl font-bold text-white mb-2">Report Suspicious Activity</h1>
          <p className="text-slate-300">
            Help us keep our community safe by reporting abuse, fraud, harassment, or any other suspicious activity.
          </p>
        </div>

        {/* Legal Warning Banner */}
        <div className="bg-gradient-to-r from-amber-500/20 to-orange-500/20 border-2 border-amber-500/50 rounded-xl p-6 mb-8 flex gap-4">
          <AlertTriangle className="w-8 h-8 text-amber-400 flex-shrink-0 mt-1" />
          <div>
            <h3 className="text-lg font-bold text-amber-300 mb-2">Legal Warning</h3>
            <p className="text-slate-300 text-sm leading-relaxed">
              False reports and abuse of this system are taken very seriously and may result in severe legal consequences, including:
              criminal charges for filing false reports, civil liability for damages, account termination and permanent ban, and referral to law
              enforcement authorities. All submissions are logged with your IP address and device information for verification and legal purposes.
              By submitting this report, you confirm that the information provided is accurate and truthful to the best of your knowledge.
            </p>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Error Messages */}
          {submissionState.error && (
            <div className="bg-red-500/20 border border-red-500/50 rounded-lg p-4 flex gap-3">
              <X className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-red-200 font-semibold mb-1">Submission Error</p>
                <p className="text-red-100 text-sm">{submissionState.error}</p>
              </div>
            </div>
          )}

          {/* Reporter Information */}
          <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700/50 rounded-xl p-6">
            <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
              <span className="w-8 h-8 rounded-full bg-cyan-500/30 text-cyan-400 flex items-center justify-center text-sm font-bold">1</span>
              Your Information
            </h2>

            <div className="space-y-4">
              {/* Email */}
              <div>
                <label className="block text-sm font-semibold text-slate-200 mb-2">Email Address *</label>
                <input
                  type="email"
                  value={formState.reporterEmail}
                  onChange={(e) => handleInputChange('reporterEmail', e.target.value)}
                  placeholder="your@email.com"
                  className="w-full px-4 py-3 bg-slate-700/50 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/30 transition-all duration-300"
                  required
                />
                <p className="text-xs text-slate-400 mt-1">We use this to follow up on your report if needed.</p>
              </div>

              {/* Name */}
              <div>
                <label className="block text-sm font-semibold text-slate-200 mb-2">Full Name (Optional)</label>
                <input
                  type="text"
                  value={formState.reporterName}
                  onChange={(e) => handleInputChange('reporterName', e.target.value)}
                  placeholder="John Doe"
                  className="w-full px-4 py-3 bg-slate-700/50 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/30 transition-all duration-300"
                />
              </div>
            </div>
          </div>

          {/* Report Details */}
          <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700/50 rounded-xl p-6">
            <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
              <span className="w-8 h-8 rounded-full bg-cyan-500/30 text-cyan-400 flex items-center justify-center text-sm font-bold">2</span>
              Report Details
            </h2>

            <div className="space-y-4">
              {/* Category */}
              <div>
                <label className="block text-sm font-semibold text-slate-200 mb-3">Report Category *</label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {Object.entries(ReportService.REPORT_CATEGORIES).map(([key, category]) => (
                    <button
                      key={key}
                      type="button"
                      onClick={() => handleInputChange('category', key)}
                      className={`p-3 rounded-lg border-2 transition-all duration-300 text-left ${
                        formState.category === key
                          ? 'bg-cyan-500/20 border-cyan-500 shadow-lg shadow-cyan-500/20'
                          : 'bg-slate-700/30 border-slate-600 hover:border-slate-500'
                      }`}
                    >
                      <div className="flex items-start gap-2">
                        <span className="text-xl mt-0.5">{category.icon}</span>
                        <div>
                          <p className="font-semibold text-white text-sm">{category.name}</p>
                          <p className="text-xs text-slate-300">{category.description}</p>
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Severity */}
              <div>
                <label className="block text-sm font-semibold text-slate-200 mb-3">Severity Level *</label>
                <div className="flex gap-2 flex-wrap">
                  {(['low', 'medium', 'high', 'critical'] as const).map((level) => (
                    <button
                      key={level}
                      type="button"
                      onClick={() => handleInputChange('severity', level)}
                      className={`px-4 py-2 rounded-lg font-semibold transition-all duration-300 capitalize ${
                        formState.severity === level
                          ? level === 'critical'
                            ? 'bg-red-500/30 text-red-300 border-2 border-red-500'
                            : level === 'high'
                              ? 'bg-orange-500/30 text-orange-300 border-2 border-orange-500'
                              : level === 'medium'
                                ? 'bg-yellow-500/30 text-yellow-300 border-2 border-yellow-500'
                                : 'bg-blue-500/30 text-blue-300 border-2 border-blue-500'
                          : 'bg-slate-700/30 border-2 border-slate-600 text-slate-300 hover:border-slate-500'
                      }`}
                    >
                      {level}
                    </button>
                  ))}
                </div>
              </div>

              {/* Affected User */}
              <div>
                <label className="block text-sm font-semibold text-slate-200 mb-2">Affected User/Account (Optional)</label>
                <input
                  type="text"
                  value={formState.affectedUser}
                  onChange={(e) => handleInputChange('affectedUser', e.target.value)}
                  placeholder="Username or account email of the user/content involved"
                  className="w-full px-4 py-3 bg-slate-700/50 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/30 transition-all duration-300"
                />
              </div>

              {/* Description */}
              <div>
                <label className="block text-sm font-semibold text-slate-200 mb-2">Detailed Description *</label>
                <textarea
                  value={formState.description}
                  onChange={(e) => handleInputChange('description', e.target.value)}
                  placeholder="Please provide detailed information about what happened, including dates, times, links, and any other relevant context. This helps us investigate more effectively."
                  rows={6}
                  className="w-full px-4 py-3 bg-slate-700/50 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/30 transition-all duration-300 resize-none"
                />
                <div className="flex justify-between items-center mt-2">
                  <p className="text-xs text-slate-400">Minimum 20 characters | Maximum 5000 characters</p>
                  <p
                    className={`text-xs font-semibold ${
                      characterCount < 20
                        ? 'text-red-400'
                        : characterCount > 4800
                          ? 'text-amber-400'
                          : 'text-emerald-400'
                    }`}
                  >
                    {characterCount} / 5000
                  </p>
                </div>
              </div>

              {/* File Upload */}
              <div>
                <button
                  type="button"
                  onClick={() => setShowFileUpload(!showFileUpload)}
                  className="flex items-center gap-2 px-4 py-2 bg-slate-700/50 border border-slate-600 hover:border-slate-500 text-cyan-400 rounded-lg transition-all duration-300"
                >
                  <Upload size={18} />
                  {fileName ? 'Change Evidence File' : 'Add Evidence File'}
                </button>

                {showFileUpload && (
                  <div className="mt-3 p-4 bg-slate-700/30 border border-slate-600 rounded-lg">
                    <input
                      type="file"
                      onChange={handleFileUpload}
                      accept="image/jpeg,image/png,image/gif,application/pdf,text/plain"
                      className="w-full text-slate-300"
                    />
                    <p className="text-xs text-slate-400 mt-2">
                      Supported: JPG, PNG, GIF, PDF, TXT (Max 10MB). Screenshots or documents that support your report.
                    </p>
                  </div>
                )}

                {fileName && (
                  <div className="mt-3 p-3 bg-emerald-500/20 border border-emerald-500/50 rounded-lg flex items-center justify-between">
                    <span className="text-emerald-300 text-sm">{fileName}</span>
                    <button
                      type="button"
                      onClick={handleRemoveFile}
                      className="text-emerald-400 hover:text-emerald-300 transition-colors"
                    >
                      <X size={18} />
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Agreements */}
          <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700/50 rounded-xl p-6">
            <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
              <span className="w-8 h-8 rounded-full bg-cyan-500/30 text-cyan-400 flex items-center justify-center text-sm font-bold">3</span>
              Confirmations
            </h2>

            <div className="space-y-4">
              {/* Terms Agreement */}
              <label className="flex items-start gap-3 cursor-pointer group">
                <input
                  type="checkbox"
                  checked={formState.agreedToTerms}
                  onChange={(e) => handleInputChange('agreedToTerms', e.target.checked)}
                  className="mt-1 w-5 h-5 rounded border-2 border-slate-500 accent-cyan-500 cursor-pointer"
                />
                <span className="text-slate-300 text-sm leading-relaxed group-hover:text-white transition-colors">
                  I agree that any false, misleading, or abusive report may result in legal action, account suspension, criminal charges, and civil
                  liability. I understand that all submissions are logged and investigated. *
                </span>
              </label>

              {/* Accuracy Confirmation */}
              <label className="flex items-start gap-3 cursor-pointer group">
                <input
                  type="checkbox"
                  checked={formState.agreedToAccuracy}
                  onChange={(e) => handleInputChange('agreedToAccuracy', e.target.checked)}
                  className="mt-1 w-5 h-5 rounded border-2 border-slate-500 accent-cyan-500 cursor-pointer"
                />
                <span className="text-slate-300 text-sm leading-relaxed group-hover:text-white transition-colors">
                  I confirm that the information I am providing in this report is accurate and truthful to the best of my knowledge. *
                </span>
              </label>
            </div>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={submissionState.isSubmitting || !formState.agreedToTerms || !formState.agreedToAccuracy}
            className="w-full py-4 bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 disabled:from-slate-600 disabled:to-slate-600 disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold rounded-lg transition-all duration-300 transform hover:scale-105 disabled:hover:scale-100 flex items-center justify-center gap-2"
          >
            {submissionState.isSubmitting ? (
              <>
                <Loader size={20} className="animate-spin" />
                Submitting Report...
              </>
            ) : (
              <>
                <CheckCircle size={20} />
                Submit Report
              </>
            )}
          </button>

          <p className="text-center text-xs text-slate-400">
            Your report is encrypted and secure. We will keep your identity confidential while investigating.
          </p>
        </form>
      </div>
    </div>
  );
}
