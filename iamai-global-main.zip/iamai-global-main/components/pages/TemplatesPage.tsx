import React from 'react';
import { TEMPLATES, Template } from '../../constants';
import { Page } from '../../App';

interface TemplatesPageProps {
  onNavigate: (page: Page) => void;
}

const TemplateCard: React.FC<{ template: Template; onNavigate: (page: Page) => void }> = ({ template, onNavigate }) => {
  const handleUseTemplate = () => {
    const templatePage = `template-${template.id}` as Page;
    onNavigate(templatePage);
  };

  return (
    <div className="bg-gray-900/50 p-8 rounded-lg text-center border border-gray-800 hover:border-cyan-500/30 transition-colors duration-300 transform hover:-translate-y-1 flex flex-col items-center">
        <div className="w-16 h-16 mb-4 flex items-center justify-center rounded-full bg-cyan-900/50 border border-cyan-500/30 text-cyan-400 text-3xl">
            <i className={template.icon}></i>
        </div>
        <h3 className="mt-4 font-semibold text-white text-lg">{template.name}</h3>
        <p className="mt-2 text-sm text-gray-400 flex-grow">{template.description}</p>
        <button 
          onClick={handleUseTemplate}
          title={`Use the ${template.name} template`} 
          className="mt-6 w-full text-center px-4 py-2 text-sm bg-gray-800 text-white rounded-lg font-semibold hover:bg-gray-700 transition-colors"
        >
            Use Template
        </button>
    </div>
  );
};


const TemplatesPage: React.FC<TemplatesPageProps> = ({ onNavigate }) => {
  return (
    <div className="py-20 md:py-28 bg-black">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold text-white">Agent Templates</h1>
            <p className="max-w-2xl mx-auto mt-4 text-gray-400">
                Browse our library of pre-built agent templates to get started in minutes.
            </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {TEMPLATES.map((template) => (
            <TemplateCard key={template.name} template={template} onNavigate={onNavigate} />
          ))}
           {/* You can add more templates here */}
        </div>
         <div className="text-center mt-16">
            <button onClick={() => onNavigate('home')} title="Return to the homepage" className="text-gray-400 hover:text-cyan-400 transition-colors">
                &larr; Back to Home
            </button>
        </div>
      </div>
    </div>
  );
};

export default TemplatesPage;