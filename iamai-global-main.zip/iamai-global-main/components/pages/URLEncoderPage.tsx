import React, { useMemo, useState } from 'react';
import { ArrowLeft, Code, Copy, Check, Download, Upload, RefreshCw, Clock, Zap, BookOpen } from 'lucide-react';

interface Props { onNavigate?: (page: string) => void }

type EncodingFormat = 'standard' | 'base64' | 'hex' | 'binary';

interface HistoryEntry {
  id: string;
  input: string;
  output: string;
  format: EncodingFormat;
  mode: 'encode' | 'decode';
  timestamp: string;
}

interface Template {
  name: string;
  value: string;
  description: string;
}

const URLEncoderPage: React.FC<Props> = ({ onNavigate }) => {
  const [mode, setMode] = useState<'encode' | 'decode'>('encode');
  const [format, setFormat] = useState<EncodingFormat>('standard');
  const [input, setInput] = useState('https://example.com?q=hello world&lang=en');
  const [batchInput, setBatchInput] = useState('');
  const [batchMode, setBatchMode] = useState(false);
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [copied, setCopied] = useState(false);
  
  const templates: Template[] = [
    {
      name: 'URL with Query',
      value: 'https://example.com?search=hello world&page=1',
      description: 'Basic URL with query parameters'
    },
    {
      name: 'Email Link',
      value: 'mailto:user@example.com?subject=Hello&body=How are you?',
      description: 'Email with subject and body'
    },
    {
      name: 'Special Characters',
      value: 'User name: John Doe, Email: john@example.com',
      description: 'Text with spaces and special chars'
    },
    {
      name: 'Unicode Text',
      value: 'Hello 世界 🌍 Привет مرحبا',
      description: 'International characters'
    }
  ];

  const output = useMemo(() => {
    try {
      if (!input.trim()) return '';
      
      if (mode === 'encode') {
        switch (format) {
          case 'standard':
            return encodeURIComponent(input);
          case 'base64':
            return btoa(unescape(encodeURIComponent(input)));
          case 'hex':
            return Array.from(input)
              .map(c => c.charCodeAt(0).toString(16).padStart(2, '0'))
              .join('');
          case 'binary':
            return Array.from(input)
              .map(c => c.charCodeAt(0).toString(2).padStart(8, '0'))
              .join(' ');
          default:
            return encodeURIComponent(input);
        }
      } else {
        switch (format) {
          case 'standard':
            return decodeURIComponent(input);
          case 'base64':
            return decodeURIComponent(escape(atob(input)));
          case 'hex':
            return input.match(/.{1,2}/g)
              ?.map(byte => String.fromCharCode(parseInt(byte, 16)))
              .join('') || '';
          case 'binary':
            return input.split(' ')
              .map(byte => String.fromCharCode(parseInt(byte, 2)))
              .join('');
          default:
            return decodeURIComponent(input);
        }
      }
    } catch {
      return 'Error: Invalid input for ' + format + ' ' + mode;
    }
  }, [input, mode, format]);

  const batchOutput = useMemo(() => {
    if (!batchMode || !batchInput.trim()) return '';
    
    const lines = batchInput.split('\n').filter(line => line.trim());
    return lines.map(line => {
      try {
        if (mode === 'encode') {
          switch (format) {
            case 'standard':
              return encodeURIComponent(line);
            case 'base64':
              return btoa(unescape(encodeURIComponent(line)));
            case 'hex':
              return Array.from(line)
                .map(c => c.charCodeAt(0).toString(16).padStart(2, '0'))
                .join('');
            default:
              return encodeURIComponent(line);
          }
        } else {
          switch (format) {
            case 'standard':
              return decodeURIComponent(line);
            case 'base64':
              return decodeURIComponent(escape(atob(line)));
            case 'hex':
              return line.match(/.{1,2}/g)
                ?.map(byte => String.fromCharCode(parseInt(byte, 16)))
                .join('') || '';
            default:
              return decodeURIComponent(line);
          }
        }
      } catch {
        return 'Error: ' + line;
      }
    }).join('\n');
  }, [batchInput, mode, format, batchMode]);

  const saveToHistory = () => {
    const entry: HistoryEntry = {
      id: Date.now().toString(),
      input: batchMode ? batchInput : input,
      output: batchMode ? batchOutput : output,
      format,
      mode,
      timestamp: new Date().toISOString()
    };
    setHistory(prev => [entry, ...prev.slice(0, 9)]);
  };

  const loadFromHistory = (entry: HistoryEntry) => {
    setInput(entry.input);
    setMode(entry.mode);
    setFormat(entry.format);
    setBatchMode(false);
  };

  const loadTemplate = (template: Template) => {
    setInput(template.value);
    setMode('encode');
    setBatchMode(false);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const downloadResult = () => {
    const text = batchMode ? batchOutput : output;
    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${mode}-${format}-${Date.now()}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const swap = () => {
    setInput(output);
    setMode(mode === 'encode' ? 'decode' : 'encode');
  };

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <section className="relative overflow-hidden py-12 border-b border-gray-800">
        <div className="absolute inset-0 bg-grid-gray-900 [mask-image:linear-gradient(to_bottom,white_30%,transparent)]"></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-blue-500/10 rounded-full blur-3xl"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <button
            onClick={() => onNavigate?.('toolbox')} 
            className="mb-6 flex items-center gap-2 text-gray-400 hover:text-cyan-400 transition-colors"
          >
            <ArrowLeft className="w-4 h-4"/> Back to Toolbox
          </button>
          
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 bg-cyan-500/20 rounded-lg border border-cyan-500/30">
              <Code className="w-6 h-6 text-cyan-400"/>
            </div>
            <div>
              <h1 className="text-3xl md:text-4xl font-bold">URL Encoder / Decoder</h1>
              <p className="text-gray-400 mt-1">Encode and decode with multiple formats</p>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
            <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-4">
              <div className="text-gray-400 text-sm mb-1">Mode</div>
              <div className="text-2xl font-bold text-cyan-400 capitalize">{mode}</div>
            </div>
            <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-4">
              <div className="text-gray-400 text-sm mb-1">Format</div>
              <div className="text-2xl font-bold text-purple-400 capitalize">{format}</div>
            </div>
            <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-4">
              <div className="text-gray-400 text-sm mb-1">Batch Mode</div>
              <div className="text-2xl font-bold">{batchMode ? '🟢' : '⚪'}</div>
            </div>
            <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-4">
              <div className="text-gray-400 text-sm mb-1">History</div>
              <div className="text-2xl font-bold text-green-400">{history.length}</div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-6">
            {/* Left Column - Input/Output */}
            <div className="lg:col-span-2 space-y-6">
              {/* Controls */}
              <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {/* Mode Toggle */}
                  <div className="col-span-2">
                    <label className="block text-sm text-gray-400 mb-2">Mode</label>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={() => setMode('encode')}
                        className={`px-4 py-2 rounded-lg font-semibold transition ${
                          mode === 'encode'
                            ? 'bg-gradient-to-r from-cyan-500 to-purple-500 text-black'
                            : 'bg-gray-800 text-gray-400 border border-gray-700 hover:border-cyan-500/50'
                        }`}
                      >
                        Encode
                      </button>
                      <button
                        onClick={() => setMode('decode')}
                        className={`px-4 py-2 rounded-lg font-semibold transition ${
                          mode === 'decode'
                            ? 'bg-gradient-to-r from-cyan-500 to-purple-500 text-black'
                            : 'bg-gray-800 text-gray-400 border border-gray-700 hover:border-cyan-500/50'
                        }`}
                      >
                        Decode
                      </button>
                    </div>
                  </div>

                  {/* Format Selection */}
                  <div className="col-span-2">
                    <label className="block text-sm text-gray-400 mb-2">Format</label>
                    <select
                      value={format}
                      onChange={e => setFormat(e.target.value as EncodingFormat)}
                      className="w-full px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-cyan-500 transition"
                    >
                      <option value="standard">URL Standard</option>
                      <option value="base64">Base64</option>
                      <option value="hex">Hexadecimal</option>
                      <option value="binary">Binary</option>
                    </select>
                  </div>

                  {/* Batch Mode Toggle */}
                  <div className="col-span-2 md:col-span-4">
                    <div className="flex items-center gap-3 p-4 bg-gray-800/50 rounded-lg border border-gray-700">
                      <input
                        type="checkbox"
                        id="batchMode"
                        checked={batchMode}
                        onChange={e => setBatchMode(e.target.checked)}
                        className="w-4 h-4"
                      />
                      <label htmlFor="batchMode" className="text-sm text-gray-300 flex-1">
                        Batch Processing (one item per line)
                      </label>
                      {batchMode && <Zap className="w-4 h-4 text-yellow-400 animate-pulse" />}
                    </div>
                  </div>
                </div>
              </div>

              {/* Input/Output */}
              <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
                <div className="space-y-4">
                  {/* Input */}
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <label className="text-sm text-gray-400">
                        {batchMode ? 'Batch Input (one per line)' : 'Input'}
                      </label>
                      <div className="flex gap-2">
                        <button
                          onClick={() => batchMode ? setBatchInput('') : setInput('')}
                          className="text-xs text-gray-400 hover:text-cyan-400 transition"
                        >
                          Clear
                        </button>
                      </div>
                    </div>
                    <textarea 
                      className="w-full h-48 px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white font-mono text-sm focus:outline-none focus:border-cyan-500 transition resize-none" 
                      placeholder={batchMode ? 'Enter multiple values, one per line...' : 'Enter text to ' + mode + '...'}
                      value={batchMode ? batchInput : input} 
                      onChange={e => batchMode ? setBatchInput(e.target.value) : setInput(e.target.value)}
                    />
                  </div>

                  {/* Action Buttons */}
                  <div className="flex items-center justify-center gap-4">
                    <button
                      onClick={swap}
                      disabled={!output}
                      className="p-3 bg-gray-800 hover:bg-gray-700 rounded-lg border border-gray-700 transition disabled:opacity-50"
                      title="Swap input/output"
                    >
                      <RefreshCw className="w-5 h-5" />
                    </button>
                    <div className="h-px flex-1 bg-gradient-to-r from-transparent via-cyan-500/50 to-transparent"></div>
                    <button
                      onClick={saveToHistory}
                      disabled={!output}
                      className="px-6 py-3 bg-gradient-to-r from-cyan-500 to-purple-500 text-black font-semibold rounded-lg hover:shadow-lg hover:shadow-cyan-500/50 transition disabled:opacity-50"
                    >
                      Save to History
                    </button>
                    <div className="h-px flex-1 bg-gradient-to-r from-transparent via-purple-500/50 to-transparent"></div>
                  </div>

                  {/* Output */}
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <label className="text-sm text-gray-400">
                        {batchMode ? 'Batch Output' : 'Output'}
                      </label>
                      <div className="flex gap-2">
                        <button
                          onClick={() => copyToClipboard(batchMode ? batchOutput : output)}
                          disabled={!output}
                          className="text-xs px-3 py-1 bg-gray-800 hover:bg-gray-700 rounded border border-gray-700 transition disabled:opacity-50 flex items-center gap-1"
                        >
                          {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                          Copy
                        </button>
                        <button
                          onClick={downloadResult}
                          disabled={!output}
                          className="text-xs px-3 py-1 bg-gray-800 hover:bg-gray-700 rounded border border-gray-700 transition disabled:opacity-50 flex items-center gap-1"
                        >
                          <Download className="w-3 h-3" />
                          Download
                        </button>
                      </div>
                    </div>
                    <textarea 
                      readOnly 
                      className="w-full h-48 px-4 py-3 bg-black border border-gray-700 rounded-lg text-cyan-400 font-mono text-sm resize-none" 
                      value={batchMode ? batchOutput : output}
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Right Column - Templates & History */}
            <div className="space-y-6">
              {/* Templates */}
              <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
                <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                  <BookOpen className="w-5 h-5 text-cyan-400" />
                  Templates
                </h3>
                <div className="space-y-2">
                  {templates.map((template, idx) => (
                    <button
                      key={idx}
                      onClick={() => loadTemplate(template)}
                      className="w-full p-3 text-left bg-gray-800/50 hover:bg-gray-800 border border-gray-700 hover:border-cyan-500/50 rounded-lg transition"
                    >
                      <div className="font-semibold text-sm text-cyan-400 mb-1">
                        {template.name}
                      </div>
                      <div className="text-xs text-gray-500">
                        {template.description}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* History */}
              {history.length > 0 && (
                <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-bold flex items-center gap-2">
                      <Clock className="w-5 h-5 text-cyan-400" />
                      History
                    </h3>
                    <button
                      onClick={() => setHistory([])}
                      className="text-xs text-gray-400 hover:text-red-400 transition"
                    >
                      Clear
                    </button>
                  </div>
                  <div className="space-y-2 max-h-96 overflow-auto">
                    {history.map(entry => (
                      <button
                        key={entry.id}
                        onClick={() => loadFromHistory(entry)}
                        className="w-full p-3 text-left bg-gray-800/50 hover:bg-gray-800 border border-gray-700 hover:border-cyan-500/50 rounded-lg transition"
                      >
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-xs px-2 py-1 bg-cyan-500/10 border border-cyan-500/30 rounded text-cyan-400 capitalize">
                            {entry.mode}
                          </span>
                          <span className="text-xs px-2 py-1 bg-purple-500/10 border border-purple-500/30 rounded text-purple-400 capitalize">
                            {entry.format}
                          </span>
                        </div>
                        <div className="text-xs text-gray-400 truncate font-mono">
                          {entry.input.substring(0, 30)}...
                        </div>
                        <div className="text-xs text-gray-500 mt-1">
                          {new Date(entry.timestamp).toLocaleString()}
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Format Guide */}
              <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
                <h3 className="text-lg font-bold mb-4">Format Guide</h3>
                <div className="space-y-3 text-sm">
                  <div>
                    <div className="text-cyan-400 font-semibold mb-1">URL Standard</div>
                    <div className="text-gray-400 text-xs">Percent-encoding for URLs</div>
                  </div>
                  <div>
                    <div className="text-cyan-400 font-semibold mb-1">Base64</div>
                    <div className="text-gray-400 text-xs">Binary-to-text encoding</div>
                  </div>
                  <div>
                    <div className="text-cyan-400 font-semibold mb-1">Hexadecimal</div>
                    <div className="text-gray-400 text-xs">Base-16 representation</div>
                  </div>
                  <div>
                    <div className="text-cyan-400 font-semibold mb-1">Binary</div>
                    <div className="text-gray-400 text-xs">Base-2 representation</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default URLEncoderPage;
