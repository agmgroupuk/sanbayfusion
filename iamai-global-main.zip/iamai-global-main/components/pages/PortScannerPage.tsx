import React, { useEffect, useState } from 'react';
import { ArrowLeft, Server, Play, Pause, Shield, AlertTriangle, AlertCircle, CheckCircle, XCircle, Clock, Zap, Activity, Download, Copy, Check, RefreshCw, Search, TrendingUp, Lock, Info } from 'lucide-react';
import { getSocket } from '../../services/socket';

interface Props { onNavigate?: (page: string) => void }

type ScanUpdate = { 
  host: string; 
  port: number; 
  open: boolean; 
  service?: string;
  version?: string;
  error?: string 
};

interface ScanResult extends ScanUpdate {
  timestamp: string;
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
  vulnerabilities?: string[];
}

interface HistoryEntry {
  id: string;
  host: string;
  timestamp: string;
  totalPorts: number;
  openPorts: number;
  closedPorts: number;
  criticalPorts: number;
}

const PortScannerPage: React.FC<Props> = ({ onNavigate }) => {
  const [host, setHost] = useState('scanme.nmap.org');
  const [ports, setPorts] = useState('21,22,25,53,80,110,143,443,465,587,993,995,3306,3389,5432,5900,6379,8080,8443,27017');
  const [updates, setUpdates] = useState<ScanUpdate[]>([]);
  const [results, setResults] = useState<ScanResult[]>([]);
  const [running, setRunning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [startTime, setStartTime] = useState<number | null>(null);
  const [elapsedTime, setElapsedTime] = useState(0);
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [copied, setCopied] = useState(false);
  const [scanPreset, setScanPreset] = useState<'common' | 'web' | 'database' | 'custom'>('common');

  const portPresets = {
    common: '21,22,25,53,80,110,143,443,465,587,993,995,3306,3389,5432,5900,6379,8080,8443,27017',
    web: '80,443,8080,8443,8000,8888,3000,5000,9090',
    database: '1433,3306,5432,6379,27017,5984,9200,9042',
    custom: ports
  };

  const commonServices: Record<number, { name: string; risk: 'low' | 'medium' | 'high' | 'critical'; cves?: string[] }> = {
    21: { name: 'FTP', risk: 'high', cves: ['CVE-2021-44142'] },
    22: { name: 'SSH', risk: 'medium', cves: ['CVE-2023-38408'] },
    23: { name: 'Telnet', risk: 'critical', cves: ['CVE-2020-10188'] },
    25: { name: 'SMTP', risk: 'medium' },
    53: { name: 'DNS', risk: 'low' },
    80: { name: 'HTTP', risk: 'low' },
    110: { name: 'POP3', risk: 'medium' },
    143: { name: 'IMAP', risk: 'medium' },
    443: { name: 'HTTPS', risk: 'low' },
    445: { name: 'SMB', risk: 'high', cves: ['CVE-2017-0144 (EternalBlue)'] },
    465: { name: 'SMTPS', risk: 'low' },
    587: { name: 'SMTP Submission', risk: 'medium' },
    993: { name: 'IMAPS', risk: 'low' },
    995: { name: 'POP3S', risk: 'low' },
    1433: { name: 'MS SQL', risk: 'high', cves: ['CVE-2020-0618'] },
    3306: { name: 'MySQL', risk: 'high', cves: ['CVE-2023-21980'] },
    3389: { name: 'RDP', risk: 'critical', cves: ['CVE-2019-0708 (BlueKeep)'] },
    5432: { name: 'PostgreSQL', risk: 'medium', cves: ['CVE-2023-39417'] },
    5900: { name: 'VNC', risk: 'high', cves: ['CVE-2006-2369'] },
    6379: { name: 'Redis', risk: 'high', cves: ['CVE-2022-0543'] },
    8080: { name: 'HTTP Alt', risk: 'low' },
    8443: { name: 'HTTPS Alt', risk: 'low' },
    27017: { name: 'MongoDB', risk: 'high', cves: ['CVE-2021-20329'] }
  };

  useEffect(() => {
    // Load history
    const savedHistory = toolDataService.getPortScanHistory();
    if (savedHistory.length > 0) {
      setHistory(savedHistory);
    }
  }, []);

  useEffect(() => {
    const socket = getSocket();
    const onUpdate = (u: ScanUpdate) => {
      setUpdates(prev => [...prev, u]);
      
      // Convert to ScanResult with security info
      if (u.open) {
        const serviceInfo = commonServices[u.port];
        const result: ScanResult = {
          ...u,
          timestamp: new Date().toISOString(),
          riskLevel: serviceInfo?.risk || 'low',
          service: serviceInfo?.name || 'Unknown',
          vulnerabilities: serviceInfo?.cves
        };
        setResults(prev => [...prev, result]);
      }
    };
    
    const onDone = () => {
      setRunning(false);
      setProgress(100);
      
      // Save to history
      const openCount = updates.filter(u => u.open).length;
      const criticalCount = results.filter(r => r.riskLevel === 'critical').length;
      
      const entry: HistoryEntry = {
        id: Date.now().toString(),
        host,
        timestamp: new Date().toISOString(),
        totalPorts: updates.length,
        openPorts: openCount,
        closedPorts: updates.length - openCount,
        criticalPorts: criticalCount
      };
      
      const newHistory = [entry, ...history.slice(0, 9)];
      setHistory(newHistory);
      toolDataService.savePortScanHistory(newHistory);
    };
    
    socket.on('tools:portscan:update', onUpdate);
    socket.on('tools:portscan:done', onDone);
    
    return () => {
      socket.off('tools:portscan:update', onUpdate);
      socket.off('tools:portscan:done', onDone);
    };
  }, [updates, results, history, host]);

  // Timer effect
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (running && startTime) {
      interval = setInterval(() => {
        setElapsedTime(Date.now() - startTime);
      }, 100);
    }
    return () => clearInterval(interval);
  }, [running, startTime]);

  const start = () => {
    const portList = scanPreset === 'custom' 
      ? ports.split(',').map(p => parseInt(p.trim(), 10)).filter(n => Number.isFinite(n))
      : portPresets[scanPreset].split(',').map(p => parseInt(p.trim(), 10));
    
    if (portList.length === 0) return;
    if (portList.length > 100) {
      alert('Maximum 100 ports allowed per scan');
      return;
    }
    
    setUpdates([]);
    setResults([]);
    setRunning(true);
    setProgress(0);
    setStartTime(Date.now());
    setElapsedTime(0);
    
    getSocket().emit('tools:portscan:start', { host, ports: portList });
    
    // Simulate progress
    let currentProgress = 0;
    const progressInterval = setInterval(() => {
      currentProgress += (100 / portList.length);
      setProgress(Math.min(currentProgress, 99));
      
      if (currentProgress >= 99) {
        clearInterval(progressInterval);
      }
    }, 100);
  };

  const loadPreset = (preset: typeof scanPreset) => {
    setScanPreset(preset);
    if (preset !== 'custom') {
      setPorts(portPresets[preset]);
    }
  };

  const copyResults = () => {
    const text = results.map(r => 
      `${r.port}\t${r.service || 'Unknown'}\t${r.riskLevel.toUpperCase()}\t${r.vulnerabilities?.join(', ') || 'None known'}`
    ).join('\n');
    
    navigator.clipboard.writeText(`Port\tService\tRisk\tCVEs\n${text}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const downloadResults = () => {
    const csv = [
      'Port,Service,Risk Level,Vulnerabilities,Timestamp',
      ...results.map(r => 
        `${r.port},${r.service || 'Unknown'},${r.riskLevel},${r.vulnerabilities?.join('; ') || 'None'},${r.timestamp}`
      )
    ].join('\n');
    
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `port-scan-${host}-${Date.now()}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const formatElapsedTime = (ms: number) => {
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return minutes > 0 ? `${minutes}m ${remainingSeconds}s` : `${seconds}s`;
  };

  const getSecurityScore = () => {
    if (results.length === 0) return 100;
    
    const criticalCount = results.filter(r => r.riskLevel === 'critical').length;
    const highCount = results.filter(r => r.riskLevel === 'high').length;
    const mediumCount = results.filter(r => r.riskLevel === 'medium').length;
    
    const score = 100 - (criticalCount * 25) - (highCount * 15) - (mediumCount * 5);
    return Math.max(0, score);
  };

  const securityScore = getSecurityScore();
  const openPorts = results.length;
  const criticalPorts = results.filter(r => r.riskLevel === 'critical').length;
  const highRiskPorts = results.filter(r => r.riskLevel === 'high').length;
  const vulnerablePorts = results.filter(r => r.vulnerabilities && r.vulnerabilities.length > 0).length;

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <section className="relative overflow-hidden py-12 border-b border-gray-800">
        <div className="absolute inset-0 bg-grid-gray-900 [mask-image:linear-gradient(to_bottom,white_30%,transparent)]"></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-purple-500/10 rounded-full blur-3xl"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <button 
            onClick={() => onNavigate?.('toolbox')} 
            className="mb-6 flex items-center gap-2 text-gray-400 hover:text-cyan-400 transition-colors"
          >
            <ArrowLeft className="w-4 h-4"/> Back to Toolbox
          </button>
          
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 bg-purple-500/20 rounded-lg border border-purple-500/30">
              <Server className="w-6 h-6 text-purple-400"/>
            </div>
            <div>
              <h1 className="text-3xl md:text-4xl font-bold">Port Scanner</h1>
              <p className="text-gray-400 mt-1">Security-focused port scanning with CVE detection</p>
            </div>
          </div>

          {/* Stats Dashboard */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mt-6">
            <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-4">
              <div className="text-gray-400 text-sm mb-1">Security Score</div>
              <div className={`text-2xl font-bold ${
                securityScore >= 80 ? 'text-green-400' : 
                securityScore >= 60 ? 'text-yellow-400' : 
                securityScore >= 40 ? 'text-orange-400' : 'text-red-400'
              }`}>
                {securityScore}%
              </div>
            </div>
            <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-4">
              <div className="text-gray-400 text-sm mb-1">Open Ports</div>
              <div className="text-2xl font-bold text-cyan-400">{openPorts}</div>
            </div>
            <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-4">
              <div className="text-gray-400 text-sm mb-1">Critical Risk</div>
              <div className="text-2xl font-bold text-red-400">{criticalPorts}</div>
            </div>
            <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-4">
              <div className="text-gray-400 text-sm mb-1">High Risk</div>
              <div className="text-2xl font-bold text-orange-400">{highRiskPorts}</div>
            </div>
            <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-4">
              <div className="text-gray-400 text-sm mb-1">With CVEs</div>
              <div className="text-2xl font-bold text-purple-400">{vulnerablePorts}</div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-3 gap-6">
            {/* Left Column - Scanner Controls */}
            <div className="lg:col-span-2 space-y-6">
              {/* Scan Configuration */}
              <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
                <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                  <Search className="w-5 h-5 text-cyan-400" />
                  Scan Configuration
                </h3>
                
                <div className="space-y-4">
                  {/* Host Input */}
                  <div>
                    <label className="block text-sm text-gray-400 mb-2">Target Host</label>
                    <input 
                      className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-cyan-500 transition"
                      placeholder="example.com or 8.8.8.8" 
                      value={host} 
                      onChange={e => setHost(e.target.value)}
                      disabled={running}
                    />
                  </div>

                  {/* Preset Selection */}
                  <div>
                    <label className="block text-sm text-gray-400 mb-2">Scan Preset</label>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                      {(['common', 'web', 'database', 'custom'] as const).map(preset => (
                        <button
                          key={preset}
                          onClick={() => loadPreset(preset)}
                          disabled={running}
                          className={`px-4 py-2 rounded-lg font-semibold transition ${
                            scanPreset === preset
                              ? 'bg-gradient-to-r from-cyan-500 to-purple-500 text-black'
                              : 'bg-gray-800 text-gray-400 border border-gray-700 hover:border-cyan-500/50'
                          } disabled:opacity-50`}
                        >
                          {preset.charAt(0).toUpperCase() + preset.slice(1)}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Port List */}
                  <div>
                    <label className="block text-sm text-gray-400 mb-2">
                      Ports to Scan {scanPreset === 'custom' && '(comma-separated, max 100)'}
                    </label>
                    <textarea 
                      className="w-full h-24 px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-sm font-mono focus:outline-none focus:border-cyan-500 transition resize-none"
                      value={ports} 
                      onChange={e => setPorts(e.target.value)}
                      disabled={running || scanPreset !== 'custom'}
                    />
                  </div>

                  {/* Scan Button */}
                  <button 
                    onClick={start} 
                    disabled={running || !host.trim()}
                    className="w-full px-6 py-4 rounded-lg bg-gradient-to-r from-cyan-500 to-purple-500 text-black font-bold text-lg flex items-center justify-center gap-3 hover:shadow-lg hover:shadow-cyan-500/50 transition disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {running ? (
                      <>
                        <div className="w-5 h-5 border-2 border-black border-t-transparent rounded-full animate-spin"></div>
                        Scanning... {progress.toFixed(0)}%
                      </>
                    ) : (
                      <>
                        <Play className="w-5 h-5" />
                        Start Security Scan
                      </>
                    )}
                  </button>

                  {/* Progress Bar */}
                  {(running || progress > 0) && (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-400">Scan Progress</span>
                        <span className="text-cyan-400 font-mono">{progress.toFixed(1)}%</span>
                      </div>
                      <div className="w-full bg-gray-800 rounded-full h-3 overflow-hidden">
                        <div 
                          className="h-full bg-gradient-to-r from-cyan-500 to-purple-500 transition-all duration-300 rounded-full"
                          style={{ width: `${progress}%` }}
                        ></div>
                      </div>
                      <div className="flex items-center justify-between text-xs text-gray-500">
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {formatElapsedTime(elapsedTime)}
                        </span>
                        <span>{updates.length} ports checked</span>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Scan Results */}
              {results.length > 0 && (
                <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-bold flex items-center gap-2">
                      <Shield className="w-5 h-5 text-cyan-400" />
                      Security Analysis ({results.length} open ports)
                    </h3>
                    <div className="flex gap-2">
                      <button
                        onClick={copyResults}
                        className="px-3 py-2 bg-gray-800 hover:bg-gray-700 rounded-lg border border-gray-700 transition flex items-center gap-2 text-sm"
                      >
                        {copied ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
                        Copy
                      </button>
                      <button
                        onClick={downloadResults}
                        className="px-3 py-2 bg-gray-800 hover:bg-gray-700 rounded-lg border border-gray-700 transition flex items-center gap-2 text-sm"
                      >
                        <Download className="w-4 h-4" />
                        Export
                      </button>
                    </div>
                  </div>

                  <div className="space-y-2 max-h-[600px] overflow-y-auto">
                    {results.map((result, idx) => {
                      const riskColors = {
                        critical: 'border-red-500/50 bg-red-500/10',
                        high: 'border-orange-500/50 bg-orange-500/10',
                        medium: 'border-yellow-500/50 bg-yellow-500/10',
                        low: 'border-green-500/50 bg-green-500/10'
                      };
                      
                      const riskIcons = {
                        critical: <AlertTriangle className="w-5 h-5 text-red-400" />,
                        high: <AlertCircle className="w-5 h-5 text-orange-400" />,
                        medium: <Info className="w-5 h-5 text-yellow-400" />,
                        low: <CheckCircle className="w-5 h-5 text-green-400" />
                      };

                      return (
                        <div
                          key={idx}
                          className={`p-4 rounded-xl border-2 ${riskColors[result.riskLevel]} transition-all hover:scale-[1.02]`}
                        >
                          <div className="flex items-start justify-between mb-2">
                            <div className="flex items-center gap-3">
                              {riskIcons[result.riskLevel]}
                              <div>
                                <div className="flex items-center gap-2">
                                  <span className="text-xl font-bold text-cyan-400">Port {result.port}</span>
                                  <span className="px-2 py-0.5 bg-gray-800 rounded text-xs font-semibold">
                                    {result.service || 'Unknown'}
                                  </span>
                                </div>
                                <div className="text-xs text-gray-400 mt-1">
                                  Risk Level: <span className="font-semibold capitalize">{result.riskLevel}</span>
                                </div>
                              </div>
                            </div>
                          </div>

                          {result.vulnerabilities && result.vulnerabilities.length > 0 && (
                            <div className="mt-3 pt-3 border-t border-gray-700">
                              <div className="flex items-center gap-2 text-sm text-gray-300 mb-2">
                                <Lock className="w-4 h-4 text-red-400" />
                                <span className="font-semibold">Known Vulnerabilities:</span>
                              </div>
                              <div className="space-y-1">
                                {result.vulnerabilities.map((cve, cveIdx) => (
                                  <div key={cveIdx} className="text-sm px-3 py-1 bg-red-500/20 border border-red-500/30 rounded text-red-300 font-mono">
                                    {cve}
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>

            {/* Right Column - History & Info */}
            <div className="space-y-6">
              {/* Security Tips */}
              <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
                <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-cyan-400" />
                  Security Tips
                </h3>
                <div className="space-y-3 text-sm">
                  <div className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-green-400 mt-0.5" />
                    <div>
                      <div className="font-semibold text-green-400">Close Unnecessary Ports</div>
                      <div className="text-gray-400 text-xs">Only expose required services</div>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <AlertTriangle className="w-4 h-4 text-red-400 mt-0.5" />
                    <div>
                      <div className="font-semibold text-red-400">Critical Ports Alert</div>
                      <div className="text-gray-400 text-xs">RDP (3389), Telnet (23) are high-risk</div>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <Shield className="w-4 h-4 text-cyan-400 mt-0.5" />
                    <div>
                      <div className="font-semibold text-cyan-400">Use Firewalls</div>
                      <div className="text-gray-400 text-xs">Implement proper firewall rules</div>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <Lock className="w-4 h-4 text-purple-400 mt-0.5" />
                    <div>
                      <div className="font-semibold text-purple-400">Update Services</div>
                      <div className="text-gray-400 text-xs">Keep all services patched</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Scan History */}
              {history.length > 0 && (
                <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-bold flex items-center gap-2">
                      <Clock className="w-5 h-5 text-cyan-400" />
                      Recent Scans
                    </h3>
                    <button
                      onClick={() => {
                        setHistory([]);
                        toolDataService.clearPortScanHistory();
                      }}
                      className="text-xs text-gray-400 hover:text-red-400 transition"
                    >
                      Clear
                    </button>
                  </div>
                  <div className="space-y-2 max-h-96 overflow-y-auto">
                    {history.map(entry => (
                      <div
                        key={entry.id}
                        className="p-3 bg-gray-800/50 hover:bg-gray-800 border border-gray-700 hover:border-cyan-500/50 rounded-lg transition-all cursor-pointer"
                        onClick={() => setHost(entry.host)}
                      >
                        <div className="font-mono text-cyan-400 font-semibold text-sm mb-2">
                          {entry.host}
                        </div>
                        <div className="grid grid-cols-2 gap-2 text-xs">
                          <div>
                            <span className="text-gray-400">Open:</span>{' '}
                            <span className="text-green-400 font-semibold">{entry.openPorts}</span>
                          </div>
                          <div>
                            <span className="text-gray-400">Critical:</span>{' '}
                            <span className="text-red-400 font-semibold">{entry.criticalPorts}</span>
                          </div>
                        </div>
                        <div className="text-xs text-gray-500 mt-2 flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {new Date(entry.timestamp).toLocaleString()}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Common Ports Reference */}
              <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
                <h3 className="text-lg font-bold mb-4">Common Ports</h3>
                <div className="space-y-2 text-xs max-h-64 overflow-y-auto">
                  {Object.entries(commonServices).slice(0, 10).map(([port, info]) => (
                    <div key={port} className="flex items-center justify-between p-2 bg-gray-800/50 rounded">
                      <span className="font-mono text-cyan-400">{port}</span>
                      <span className="text-gray-400">{info.name}</span>
                      <span className={`px-2 py-0.5 rounded text-xs font-semibold ${
                        info.risk === 'critical' ? 'bg-red-500/20 text-red-400' :
                        info.risk === 'high' ? 'bg-orange-500/20 text-orange-400' :
                        info.risk === 'medium' ? 'bg-yellow-500/20 text-yellow-400' :
                        'bg-green-500/20 text-green-400'
                      }`}>
                        {info.risk}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default PortScannerPage;
