import React, { useState } from 'react';
import { getApiUrl } from '../../config/api';

interface ForgotPasswordPageProps {
  onNavigate: (page: 'home' | 'login' | 'signup') => void;
}

const ForgotPasswordPage: React.FC<ForgotPasswordPageProps> = ({ onNavigate }) => {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!email.trim()) {
      setError('Please enter your email address');
      return;
    }

    setLoading(true);
    setError('');
    setMessage('');

    try {
      const response = await fetch(getApiUrl('/auth/forgot-password'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to send reset email');
      }

      setSubmitted(true);
      setMessage(`✓ Password reset link sent to ${email}`);
      setEmail('');

      // Auto-redirect after 5 seconds
      setTimeout(() => {
        onNavigate('login');
      }, 5000);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to send reset email. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="py-20 md:py-32 bg-black flex items-center justify-center min-h-screen">
      <div className="container mx-auto px-6">
        <div className="max-w-md mx-auto bg-gray-900/50 border border-gray-800 rounded-2xl p-8">
          {/* Logo */}
          <div className="text-center mb-8">
            <img 
              src="/assets/iamai-logo.png" 
              alt="IA M AI Logo" 
              className="h-12 w-auto mx-auto mb-4"
              onError={(e) => {
                e.currentTarget.style.display = 'none';
              }}
            />
          </div>

          {/* Header */}
          <div className="text-center mb-6">
            <h2 className="text-3xl font-bold text-white mb-2">Reset Password</h2>
            <p className="text-gray-400 text-sm">
              Enter your email address and we'll send you a link to reset your password.
            </p>
          </div>

          {/* Messages */}
          {error && (
            <div className="mb-4 p-3 bg-red-500/20 border border-red-500/50 rounded-lg text-red-400 text-sm">
              {error}
            </div>
          )}

          {message && (
            <div className="mb-4 p-3 bg-green-500/20 border border-green-500/50 rounded-lg text-green-400 text-sm">
              {message}
            </div>
          )}

          {/* Form */}
          {!submitted ? (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Email Address
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  className="w-full px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500 transition-colors"
                  disabled={loading}
                />
                <p className="text-xs text-gray-500 mt-2">
                  We'll only use this to send you a password reset link.
                </p>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={loading}
                className="w-full px-5 py-3 bg-cyan-500 text-black font-semibold rounded-lg hover:bg-cyan-400 transition-colors duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {loading ? (
                  <>
                    <span className="inline-block w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin"></span>
                    Sending reset link...
                  </>
                ) : (
                  'Send Reset Link'
                )}
              </button>
            </form>
          ) : (
            // Success message
            <div className="space-y-4">
              <div className="flex items-center justify-center">
                <div className="w-12 h-12 rounded-full bg-green-500/20 border border-green-500/50 flex items-center justify-center">
                  <span className="text-2xl">✓</span>
                </div>
              </div>
              <p className="text-center text-gray-400 text-sm">
                Check your email for a password reset link. The link will expire in 24 hours.
              </p>
              <p className="text-center text-gray-500 text-xs">
                Redirecting to login in a few seconds...
              </p>
            </div>
          )}

          {/* Divider */}
          <div className="relative my-6">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-gray-700"></div>
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-2 bg-gray-900/50 text-gray-400">or</span>
            </div>
          </div>

          {/* Footer */}
          <div className="text-center space-y-3">
            <p className="text-gray-400 text-sm">
              Remember your password?{' '}
              <button
                onClick={() => onNavigate('login')}
                title="Go back to login"
                className="font-semibold text-cyan-400 hover:text-cyan-300 transition-colors"
              >
                Sign In
              </button>
            </p>

            <p className="text-gray-400 text-sm">
              Need an account?{' '}
              <button
                onClick={() => onNavigate('signup')}
                title="Go to signup page"
                className="font-semibold text-cyan-400 hover:text-cyan-300 transition-colors"
              >
                Sign Up
              </button>
            </p>

            <button
              onClick={() => onNavigate('home')}
              title="Return to homepage"
              className="text-gray-500 hover:text-gray-400 text-sm transition-colors"
            >
              ← Back to Home
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ForgotPasswordPage;
