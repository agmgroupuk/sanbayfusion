import React, { useState, useRef, useEffect } from 'react';
import { MessageCircle, Send, Upload, FileText, X, Clock, CheckCircle2, AlertCircle, ArrowLeft } from 'lucide-react';
import { Page } from '../../App';
import { getSocket } from '../../services/socket';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  status?: 'sending' | 'sent' | 'error';
}

interface UploadedDocument {
  id: string;
  name: string;
  type: string;
  size: number;
  uploadedAt: Date;
}

interface SupportTicket {
  id: string;
  category: string;
  severity: 'low' | 'medium' | 'high';
  status: 'open' | 'in-progress' | 'resolved';
  createdAt: Date;
}

interface UserProfile {
  name: string;
  email: string;
  subscriptionTier: 'free' | 'pro' | 'enterprise';
  subscriptionStatus: 'active' | 'expired' | 'trial';
}

interface LiveSupportPageProps {
  onNavigate?: (page: Page) => void;
  isLoggedIn?: boolean;
}

const LiveSupportPage: React.FC<LiveSupportPageProps> = ({ onNavigate, isLoggedIn = false }) => {
  // User authentication check
  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-black text-white py-20 md:py-28">
        <div className="container mx-auto px-6 max-w-2xl">
          {/* Header */}
          <div className="text-center mb-12">
            <div className="flex justify-center mb-6">
              <div className="p-4 bg-gradient-to-br from-cyan-500 to-cyan-600 rounded-lg">
                <MessageCircle className="w-8 h-8 text-black" />
              </div>
            </div>
            <h1 className="text-4xl font-bold text-white mb-4">Live Support</h1>
            <p className="text-gray-400 mb-8">
              Sign in to access our AI-powered support agent. We'll use your profile information to provide personalized assistance.
            </p>
          </div>

          {/* Login Prompt Card */}
          <div className="bg-gradient-to-br from-cyan-500/10 to-purple-500/10 border border-cyan-500/30 rounded-lg p-8 mb-8">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-white mb-2">Sign In Required</h2>
              <p className="text-gray-300">
                To get the best support experience, please log in to your account first. This helps us:
              </p>
            </div>

            {/* Benefits List */}
            <div className="space-y-4 mb-8">
              <div className="flex items-start gap-4">
                <div className="w-6 h-6 rounded-full bg-cyan-500/20 border border-cyan-500 flex items-center justify-center flex-shrink-0 mt-1">
                  <CheckCircle2 className="w-4 h-4 text-cyan-400" />
                </div>
                <div>
                  <p className="text-white font-semibold">Personalized Assistance</p>
                  <p className="text-gray-400 text-sm">Access your account history and preferences</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-6 h-6 rounded-full bg-cyan-500/20 border border-cyan-500 flex items-center justify-center flex-shrink-0 mt-1">
                  <CheckCircle2 className="w-4 h-4 text-cyan-400" />
                </div>
                <div>
                  <p className="text-white font-semibold">Faster Resolution</p>
                  <p className="text-gray-400 text-sm">We'll have your subscription and account context ready</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-6 h-6 rounded-full bg-cyan-500/20 border border-cyan-500 flex items-center justify-center flex-shrink-0 mt-1">
                  <CheckCircle2 className="w-4 h-4 text-cyan-400" />
                </div>
                <div>
                  <p className="text-white font-semibold">Support History</p>
                  <p className="text-gray-400 text-sm">Track previous tickets and their status</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-6 h-6 rounded-full bg-cyan-500/20 border border-cyan-500 flex items-center justify-center flex-shrink-0 mt-1">
                  <CheckCircle2 className="w-4 h-4 text-cyan-400" />
                </div>
                <div>
                  <p className="text-white font-semibold">Priority Support</p>
                  <p className="text-gray-400 text-sm">Your subscription tier determines response priority</p>
                </div>
              </div>
            </div>

            {/* Consent Notice */}
            <div className="bg-gray-900/50 border border-gray-700 rounded-lg p-4 mb-8">
              <p className="text-gray-300 text-sm">
                <strong>Privacy Notice:</strong> We'll use your profile information and chat messages solely to provide support. Your data is encrypted and never shared with third parties.
              </p>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col gap-4">
              <button
                onClick={() => onNavigate?.('signup')}
                className="w-full px-6 py-3 bg-cyan-500 text-black font-semibold rounded-lg hover:bg-cyan-400 transition-colors"
              >
                Sign In or Create Account
              </button>
              <button
                onClick={() => onNavigate?.('home')}
                className="w-full px-6 py-3 bg-gray-800 text-white font-semibold rounded-lg hover:bg-gray-700 transition-colors flex items-center justify-center gap-2"
              >
                <ArrowLeft className="w-4 h-4" />
                Go Back Home
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Main Live Support Component (for logged-in users)
  // Load real user data from localStorage
  const [userProfile] = useState<UserProfile>(() => {
    const userName = localStorage.getItem('iamai_user_name') || 'User';
    const userEmail = localStorage.getItem('iamai_user_email') || 'user@example.com';
    const userTier = localStorage.getItem('iamai_subscription_tier') || 'free';
    const userStatus = localStorage.getItem('iamai_subscription_status') || 'active';
    
    return {
      name: userName,
      email: userEmail,
      subscriptionTier: userTier as 'free' | 'pro' | 'enterprise',
      subscriptionStatus: userStatus as 'active' | 'expired' | 'trial',
    };
  });

  const [socket] = useState(() => getSocket());
  const [isConnected, setIsConnected] = useState(false);

  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: `Hello ${userProfile.name}! 👋 Welcome to Live Support. I'm here to help you with any questions or issues. I can see you're on our ${userProfile.subscriptionTier.toUpperCase()} plan. How can I assist you today?`,
      timestamp: new Date(),
      status: 'sent'
    }
  ]);
  
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [documents, setDocuments] = useState<UploadedDocument[]>([]);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const [showUploadArea, setShowUploadArea] = useState(false);
  const [supportTicket, setSupportTicket] = useState<SupportTicket | null>(null);
  const [showTicketInfo, setShowTicketInfo] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Initialize WebSocket connection
  useEffect(() => {
    if (!socket) return;

    // Connection events
    socket.on('connect', () => {
      console.log('✅ Connected to support WebSocket');
      setIsConnected(true);
    });

    socket.on('disconnect', () => {
      console.log('❌ Disconnected from support WebSocket');
      setIsConnected(false);
    });

    // Support message events
    socket.on('support:message:received', (data: any) => {
      console.log('Message received:', data);
      // Update message status to sent
      setMessages(prev => prev.map(msg => 
        msg.id === data.messageId ? { ...msg, status: 'sent' as const } : msg
      ));
    });

    socket.on('support:message:status', (data: any) => {
      console.log('Message status:', data);
    });

    // Ticket creation events
    socket.on('support:ticket:created', (data: any) => {
      console.log('Ticket created:', data);
      setSupportTicket({
        id: data.caseId,
        category: data.category,
        severity: data.severity,
        status: data.status,
        createdAt: new Date(data.createdAt),
      });
      setShowTicketInfo(true);
      
      // Add confirmation message
      const ticketMessage: Message = {
        id: `ticket-${Date.now()}`,
        role: 'assistant',
        content: `✅ Support ticket created successfully!\n\n**Case ID:** ${data.caseId}\n**Category:** ${data.category}\n**Severity:** ${data.severity}\n**SLA:** ${data.slaHours} hours\n\nOur team will respond within ${data.slaHours} hours. You can track this ticket in your dashboard.`,
        timestamp: new Date(),
        status: 'sent',
      };
      setMessages(prev => [...prev, ticketMessage]);
    });

    socket.on('support:error', (data: any) => {
      console.error('Support error:', data);
      const errorMessage: Message = {
        id: `error-${Date.now()}`,
        role: 'assistant',
        content: `❌ Error: ${data.message}. Please try again or contact support@iamai.global`,
        timestamp: new Date(),
        status: 'error',
      };
      setMessages(prev => [...prev, errorMessage]);
    });

    return () => {
      socket.off('connect');
      socket.off('disconnect');
      socket.off('support:message:received');
      socket.off('support:message:status');
      socket.off('support:ticket:created');
      socket.off('support:error');
    };
  }, [socket]);

  // Auto-scroll to latest message
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = Math.min(textareaRef.current.scrollHeight, 120) + 'px';
    }
  }, [inputValue]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!inputValue.trim()) return;

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: inputValue,
      timestamp: new Date(),
      status: 'sending'
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsLoading(true);

    try {
      // Get auth token from localStorage
      const token = localStorage.getItem('iamai_token');
      
      // Send to backend with user context
      const response = await fetch('http://localhost:3001/api/live-support/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({
          message: inputValue,
          documentIds: documents.map(d => d.id),
          conversationHistory: messages,
        }),
      });

      if (!response.ok) throw new Error('Failed to send message');

      const data = await response.json();

      // Add assistant response
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: data.response,
        timestamp: new Date(),
        status: 'sent'
      };

      setMessages(prev => [...prev, assistantMessage]);

      // Check if ticket was created
      if (data.ticket) {
        setSupportTicket(data.ticket);
        setShowTicketInfo(true);
      }
    } catch (error) {
      console.error('Error sending message:', error);
      const errorMessage: Message = {
        id: (Date.now() + 2).toString(),
        role: 'assistant',
        content: 'Sorry, I encountered an error. Please try again or contact our team.',
        timestamp: new Date(),
        status: 'error'
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDocumentUpload = async (files: FileList | null) => {
    if (!files) return;

    setIsUploading(true);
    const formData = new FormData();

    for (let i = 0; i < files.length; i++) {
      formData.append('files', files[i]);
    }

    try {
      setUploadProgress(30);

      const token = localStorage.getItem('iamai_token');
      const response = await fetch('http://localhost:3001/api/live-support/upload', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
        body: formData,
      });

      setUploadProgress(70);

      if (!response.ok) throw new Error('Upload failed');

      const data = await response.json();

      setUploadProgress(100);

      const newDocuments: UploadedDocument[] = data.documents.map((doc: any) => ({
        id: doc.id,
        name: doc.name,
        type: doc.type,
        size: doc.size,
        uploadedAt: new Date(doc.uploadedAt),
      }));

      setDocuments(prev => [...prev, ...newDocuments]);

      // Auto-dismiss success
      setTimeout(() => {
        setUploadProgress(0);
        setIsUploading(false);
      }, 500);
    } catch (error) {
      console.error('Error uploading document:', error);
      alert('Failed to upload document. Please try again.');
      setIsUploading(false);
      setUploadProgress(0);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    handleDocumentUpload(e.dataTransfer.files);
  };

  const removeDocument = (id: string) => {
    setDocuments(prev => prev.filter(doc => doc.id !== id));
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
  };

  const formatTime = (date: Date): string => {
    return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="min-h-screen bg-black text-white py-20 md:py-28">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-3 bg-gradient-to-br from-cyan-500 to-cyan-600 rounded-lg">
              <MessageCircle className="w-6 h-6 text-black" />
            </div>
            <h1 className="text-4xl font-bold text-white">Live Support</h1>
          </div>
          <p className="text-gray-400">
            Get instant help from our AI support agent. Upload documents, ask questions, and get real-time responses.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Main Chat Area */}
          <div className="lg:col-span-3">
            {/* Chat Container */}
            <div className="bg-gray-900 rounded-lg shadow-lg border border-gray-800 overflow-hidden flex flex-col h-[600px]">
              {/* Messages */}
              <div className="flex-1 overflow-y-auto p-6 space-y-4">
                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'} w-full`}
                  >
                    <div
                      className={`max-w-xs lg:max-w-md px-4 py-3 rounded-lg ${
                        message.role === 'user'
                          ? 'bg-cyan-500 text-black rounded-br-none ml-auto' 
                          : 'bg-gray-800 text-white rounded-bl-none'
                      }`}
                    >
                      <p className="text-sm break-words">{message.content}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-xs opacity-70">{formatTime(message.timestamp)}</span>
                        {message.role === 'user' && (
                          message.status === 'sending' ? (
                            <Clock className="w-3 h-3" />
                          ) : message.status === 'error' ? (
                            <AlertCircle className="w-3 h-3" />
                          ) : (
                            <CheckCircle2 className="w-3 h-3" />
                          )
                        )}
                      </div>
                    </div>
                  </div>
                ))}

                {/* Typing Indicator */}
                {isLoading && (
                  <div className="flex justify-start">
                    <div className="bg-gray-800 px-4 py-3 rounded-lg rounded-bl-none">
                      <div className="flex gap-1">
                        <div className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce"></div>
                        <div className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                        <div className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                      </div>
                    </div>
                  </div>
                )}

                <div ref={messagesEndRef} />
              </div>

              {/* Divider */}
              <div className="border-t border-gray-800"></div>

              {/* Input Area */}
              <div className="p-4 bg-gray-800 space-y-3">
                {/* Documents Display */}
                {documents.length > 0 && (
                  <div className="space-y-2">
                    <label className="text-xs font-semibold text-gray-400">
                      Attached Documents ({documents.length})
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {documents.map((doc) => (
                        <div
                          key={doc.id}
                          className="flex items-center gap-2 bg-gray-700 px-3 py-2 rounded-lg border border-gray-600 text-sm text-gray-300"
                        >
                          <FileText className="w-4 h-4 text-cyan-400" />
                          <span className="truncate max-w-[150px]">{doc.name}</span>
                          <span className="text-xs text-gray-500">({formatFileSize(doc.size)})</span>
                          <button
                            onClick={() => removeDocument(doc.id)}
                            className="ml-1 text-gray-400 hover:text-red-400 transition"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Upload Progress */}
                {isUploading && uploadProgress > 0 && (
                  <div className="w-full bg-gray-700 rounded-full h-2">
                    <div
                      className="bg-cyan-500 h-2 rounded-full transition-all"
                      style={{ width: `${uploadProgress}%` }}
                    ></div>
                  </div>
                )}

                {/* Input Form */}
                <form onSubmit={handleSendMessage} className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={isUploading || isLoading}
                    className="p-2 text-gray-400 hover:bg-gray-700 rounded-lg transition disabled:opacity-50"
                    title="Upload document"
                  >
                    <Upload className="w-5 h-5" />
                  </button>
                  <input
                    ref={fileInputRef}
                    type="file"
                    multiple
                    accept=".pdf,.doc,.docx,.txt,.jpg,.png,.jpeg"
                    onChange={(e) => handleDocumentUpload(e.target.files)}
                    className="hidden"
                  />

                  <textarea
                    ref={textareaRef}
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    placeholder="Type your message or ask a question... (Shift + Enter for new line)"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        handleSendMessage(e as any);
                      }
                    }}
                    disabled={isLoading}
                    className="flex-1 px-4 py-2 border border-gray-700 rounded-lg bg-gray-700 text-white placeholder-gray-400 resize-none focus:outline-none focus:ring-2 focus:ring-cyan-500 disabled:opacity-50"
                    rows={1}
                  />

                  <button
                    type="submit"
                    disabled={isLoading || !inputValue.trim()}
                    className="p-2 bg-cyan-500 text-black rounded-lg hover:bg-cyan-400 transition disabled:opacity-50 disabled:cursor-not-allowed font-semibold"
                    title="Send message"
                  >
                    <Send className="w-5 h-5" />
                  </button>
                </form>
              </div>
            </div>
          </div>

          {/* Sidebar - Quick Actions & Info */}
          <div className="lg:col-span-1 space-y-4">
            {/* Support Info Card */}
            <div className="bg-gray-900 border border-cyan-500/30 rounded-lg p-4">
              <h3 className="font-semibold text-cyan-400 mb-3">Support Tips</h3>
              <ul className="space-y-2 text-sm text-gray-300">
                <li className="flex gap-2">
                  <span className="text-lg">📄</span>
                  <span>Upload documents for analysis</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-lg">⚡</span>
                  <span>Get instant responses</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-lg">🎫</span>
                  <span>Automatic ticket creation if needed</span>
                </li>
              </ul>
            </div>

            {/* Ticket Info Card */}
            {supportTicket && showTicketInfo && (
              <div className="bg-gray-900 border border-green-500/30 rounded-lg p-4">
                <div className="flex items-start justify-between mb-3">
                  <h3 className="font-semibold text-green-400">Ticket Created ✓</h3>
                  <button
                    onClick={() => setShowTicketInfo(false)}
                    className="text-green-400 hover:text-green-300"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
                <div className="space-y-2 text-sm text-gray-300">
                  <p>
                    <strong>Ticket ID:</strong>
                    <br />
                    <code className="bg-gray-800 px-2 py-1 rounded text-xs font-mono text-green-400">
                      {supportTicket.id}
                    </code>
                  </p>
                  <p>
                    <strong>Category:</strong> {supportTicket.category}
                  </p>
                  <p>
                    <strong>Priority:</strong> {supportTicket.severity.toUpperCase()}
                  </p>
                  <p className="text-xs mt-2">
                    You'll receive an email update within 48 hours.
                  </p>
                </div>
              </div>
            )}

            {/* FAQ Quick Links */}
            <div className="bg-gray-900 border border-gray-800 rounded-lg p-4">
              <h3 className="font-semibold text-white mb-3">Common Questions</h3>
              <ul className="space-y-2">
                {[
                  'How do I reset my password?',
                  'Billing and subscriptions',
                  'Integration help',
                  'API documentation'
                ].map((faq, i) => (
                  <button
                    key={i}
                    onClick={() => setInputValue(faq)}
                    className="w-full text-left text-sm px-3 py-2 bg-gray-800 hover:bg-gray-700 rounded text-gray-300 transition"
                  >
                    {faq}
                  </button>
                ))}
              </ul>
            </div>

            {/* Status Indicator */}
            <div className="flex items-center gap-2 text-sm text-gray-400">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              <span>Support available 24/7</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LiveSupportPage;
