import React, { useState, useMemo } from 'react';
import { FAQS, FAQItem, FAQ_CATEGORIES } from '../../constants';
import { Search, ChevronDown, HelpCircle, MessageCircle } from 'lucide-react';

interface FAQCardProps {
  item: FAQItem;
  isOpen: boolean;
  onClick: () => void;
}

const FAQCard: React.FC<FAQCardProps> = ({ item, isOpen, onClick }) => {
  return (
    <div className="border border-gray-800 rounded-lg hover:border-cyan-500/30 transition-colors overflow-hidden">
      <button
        onClick={onClick}
        className="w-full flex justify-between items-center text-left p-5 hover:bg-gray-900/30 transition-colors"
      >
        <div className="flex-1">
          <span className="text-base font-medium text-white leading-relaxed">{item.question}</span>
        </div>
        <span className={`flex-shrink-0 ml-4 transform transition-transform duration-300 ${isOpen ? 'rotate-180' : 'rotate-0'}`}>
          <ChevronDown className="w-5 h-5 text-cyan-400" />
        </span>
      </button>
      <div
        className={`grid transition-all duration-500 ease-in-out ${isOpen ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'}`}
      >
        <div className="overflow-hidden">
          <div className="border-t border-gray-800 p-5 bg-gray-900/20">
            <p className="text-gray-300 leading-relaxed">
              {item.answer}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

interface FAQPageProps {
  onNavigate: (page: 'home' | 'support') => void;
}

const FAQPage: React.FC<FAQPageProps> = ({ onNavigate }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedIndices, setExpandedIndices] = useState<Set<number>>(new Set([0]));
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  // Get unique categories in order
  const categories = useMemo(() => {
    return Object.values(FAQ_CATEGORIES);
  }, []);

  // Filter FAQs based on search and category
  const filteredFAQs = useMemo(() => {
    return FAQS.filter((faq) => {
      const matchesSearch =
        searchQuery === '' ||
        faq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
        faq.answer.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesCategory = selectedCategory === null || faq.category === selectedCategory;

      return matchesSearch && matchesCategory;
    });
  }, [searchQuery, selectedCategory]);

  // Group filtered FAQs by category
  const groupedFAQs = useMemo(() => {
    const grouped: Record<string, FAQItem[]> = {};
    categories.forEach((cat) => {
      grouped[cat] = filteredFAQs.filter((faq) => faq.category === cat);
    });
    return grouped;
  }, [filteredFAQs, categories]);

  const toggleExpand = (index: number) => {
    const newExpanded = new Set(expandedIndices);
    if (newExpanded.has(index)) {
      newExpanded.delete(index);
    } else {
      newExpanded.add(index);
    }
    setExpandedIndices(newExpanded);
  };

  const currentIndex = useMemo(() => {
    let count = 0;
    return new Map(
      filteredFAQs.map((faq) => {
        const index = count++;
        return [JSON.stringify(faq), index];
      })
    );
  }, [filteredFAQs]);

  return (
    <div className="min-h-screen py-20 md:py-28 bg-gradient-to-b from-black via-gray-950 to-black">
      <div className="container mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="flex items-center justify-center gap-3 mb-4">
            <HelpCircle className="w-8 h-8 text-cyan-400" />
            <h1 className="text-4xl md:text-5xl font-bold text-white">Frequently Asked Questions</h1>
          </div>
          <p className="max-w-2xl mx-auto text-gray-400 text-lg">
            Find answers to common questions about our platform, agents, live support, reports, and more. Use the search or filter by category below.
          </p>
        </div>

        {/* Search Bar */}
        <div className="max-w-4xl mx-auto mb-12">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-500" />
            <input
              type="text"
              placeholder="Search FAQs by keyword..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-3 bg-gray-900/50 border border-gray-800 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500/50 transition-colors"
            />
          </div>
        </div>

        {/* Category Filter */}
        <div className="max-w-4xl mx-auto mb-12">
          <div className="flex flex-wrap gap-2 justify-center">
            <button
              onClick={() => setSelectedCategory(null)}
              className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                selectedCategory === null
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50'
                  : 'bg-gray-900/30 text-gray-400 border border-gray-800 hover:border-gray-700'
              }`}
            >
              All Categories
            </button>
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-4 py-2 rounded-lg font-medium transition-colors text-sm ${
                  selectedCategory === category
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50'
                    : 'bg-gray-900/30 text-gray-400 border border-gray-800 hover:border-gray-700'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>

        {/* FAQs by Category */}
        <div className="max-w-4xl mx-auto space-y-12">
          {categories.map((category) => {
            const categoryFAQs = groupedFAQs[category];
            if (categoryFAQs.length === 0) return null;

            return (
              <section key={category}>
                {/* Category Header */}
                <div className="mb-6">
                  <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                    <div className="w-1 h-8 bg-gradient-to-b from-cyan-500 to-blue-500 rounded-full"></div>
                    {category}
                  </h2>
                  <div className="h-0.5 bg-gradient-to-r from-cyan-500/50 to-transparent mt-3"></div>
                </div>

                {/* Category FAQs */}
                <div className="space-y-4">
                  {categoryFAQs.map((faq, categoryIndex) => {
                    const globalIndex = currentIndex.get(JSON.stringify(faq)) ?? -1;
                    return (
                      <FAQCard
                        key={categoryIndex}
                        item={faq}
                        isOpen={expandedIndices.has(globalIndex)}
                        onClick={() => toggleExpand(globalIndex)}
                      />
                    );
                  })}
                </div>
              </section>
            );
          })}
        </div>

        {/* No Results */}
        {filteredFAQs.length === 0 && (
          <div className="max-w-4xl mx-auto text-center py-12">
            <div className="bg-gray-900/30 border border-gray-800 rounded-lg p-8">
              <MessageCircle className="w-12 h-12 text-gray-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">No FAQs Found</h3>
              <p className="text-gray-400 mb-6">
                We couldn't find any FAQs matching your search. Try different keywords or browse all categories.
              </p>
              <button
                onClick={() => {
                  setSearchQuery('');
                  setSelectedCategory(null);
                }}
                className="px-6 py-2 bg-cyan-500/20 text-cyan-300 border border-cyan-500/50 rounded-lg hover:bg-cyan-500/30 transition-colors font-medium"
              >
                Clear Filters
              </button>
            </div>
          </div>
        )}

        {/* Help Section */}
        <div className="max-w-4xl mx-auto mt-16 pt-12 border-t border-gray-800">
          <div className="bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border border-cyan-500/30 rounded-lg p-8 text-center">
            <h3 className="text-xl font-semibold text-white mb-3">Still need help?</h3>
            <p className="text-gray-400 mb-6">
              If you can't find the answer you're looking for, our support team is here to help.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button
                onClick={() => onNavigate('home')}
                className="px-6 py-2 bg-gray-900 border border-gray-800 text-gray-300 rounded-lg hover:border-gray-700 transition-colors font-medium"
              >
                ← Back to Home
              </button>
              <button
                onClick={() => onNavigate('support')}
                className="px-6 py-2 bg-cyan-500/20 text-cyan-300 border border-cyan-500/50 rounded-lg hover:bg-cyan-500/30 transition-colors font-medium"
              >
                Visit Support Center →
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FAQPage;