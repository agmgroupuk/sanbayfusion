import React, { useState } from 'react';
import { TEMPLATES } from '../../constants';
import { Page } from '../../App';

interface TemplateDetailPageProps {
  templateId: string;
  onNavigate: (page: Page) => void;
}

interface TemplateFile {
  name: string;
  language: string;
  code: string;
}

interface TemplateDetails {
  id: string;
  name: string;
  description: string;
  icon: string;
  overview: string;
  features: string[];
  useCases: string[];
  installation: string[];
  files: TemplateFile[];
  apiEndpoint: string;
}

const TEMPLATE_DETAILS: Record<string, TemplateDetails> = {
  'customer-support-bot': {
    id: 'customer-support-bot',
    name: 'Customer Support Bot',
    description: 'Resolve customer queries instantly, 24/7.',
    icon: 'fa-solid fa-headset',
    overview: 'Build an intelligent customer support bot that can handle common queries, provide instant responses, and escalate complex issues to human agents. This template includes natural language understanding, context retention, and integration with popular helpdesk systems.',
    features: [
      'Natural language understanding for customer queries',
      'Multi-turn conversation support',
      'Integration with helpdesk ticketing systems',
      'Automatic sentiment analysis',
      'Escalation to human agents',
      'Knowledge base integration',
      'Multi-language support',
      '24/7 availability'
    ],
    useCases: [
      'E-commerce customer support',
      'SaaS product help',
      'Technical support assistance',
      'Order tracking and status updates',
      'Returns and refunds handling',
      'Account management support'
    ],
    installation: [
      'Clone this template to your workspace',
      'Install dependencies: npm install @iamai/sdk',
      'Configure your API keys in .env file',
      'Customize the agent responses in agent-config.ts',
      'Deploy using: npm run deploy'
    ],
    files: [
      {
        name: 'agent-config.ts',
        language: 'typescript',
        code: `import { Agent } from '@iamai/sdk';

export const customerSupportBot: Agent = {
  id: 'customer-support-bot',
  name: 'Customer Support Bot',
  role: 'Customer Support Specialist',
  description: 'AI-powered support agent for handling customer queries',
  
  capabilities: {
    canAttachFiles: true,
    canUseVoice: true,
    canAccessWeb: true,
  },
  
  voicePreferences: {
    defaultGender: 'female',
    allowGenderToggle: true,
  },
  
  cognition: {
    contextualAwareness: true,
    longTermMemory: true,
    goalTracking: true,
    adaptiveLearning: true,
    ethicalReasoning: true,
  },
  
  personalityMatrix: {
    formality: 70,
    humor: 40,
    enthusiasm: 75,
  },
  
  systemPrompt: \`You are a helpful customer support agent. Your goal is to:
- Understand customer issues clearly
- Provide accurate and helpful solutions
- Be patient and empathetic
- Escalate complex issues when necessary
- Always maintain a professional and friendly tone\`,
};`
      },
      {
        name: 'index.ts',
        language: 'typescript',
        code: `import { IAMAIClient } from '@iamai/sdk';
import { customerSupportBot } from './agent-config';

// Initialize the IAMAI client
const client = new IAMAIClient({
  apiKey: process.env.IAMAI_API_KEY || '',
});

// Register the agent
async function registerAgent() {
  try {
    const response = await client.agents.create(customerSupportBot);
    console.log('Agent registered successfully:', response);
    return response;
  } catch (error) {
    console.error('Failed to register agent:', error);
    throw error;
  }
}

// Chat function
export async function chat(message: string, conversationId?: string) {
  try {
    const response = await client.chat.create({
      agent: customerSupportBot.id,
      message,
      conversationId,
    });
    return response;
  } catch (error) {
    console.error('Chat error:', error);
    throw error;
  }
}

// Initialize and export
registerAgent();
export { customerSupportBot };`
      },
      {
        name: 'package.json',
        language: 'json',
        code: `{
  "name": "customer-support-bot-template",
  "version": "1.0.0",
  "description": "Customer support bot template for IAMAI",
  "main": "index.ts",
  "scripts": {
    "dev": "ts-node index.ts",
    "build": "tsc",
    "deploy": "iamai deploy"
  },
  "dependencies": {
    "@iamai/sdk": "^1.0.0"
  },
  "devDependencies": {
    "@types/node": "^20.0.0",
    "typescript": "^5.0.0",
    "ts-node": "^10.9.0"
  }
}`
      },
      {
        name: '.env.example',
        language: 'bash',
        code: `# IAMAI API Configuration
IAMAI_API_KEY=your_api_key_here

# Optional: Helpdesk Integration
HELPDESK_API_KEY=your_helpdesk_api_key
HELPDESK_URL=https://your-helpdesk.com/api

# Optional: Knowledge Base
KB_API_URL=https://your-kb.com/api
KB_API_KEY=your_kb_api_key`
      }
    ],
    apiEndpoint: 'https://api.iamai.global/v1/chat'
  },
  'onboarding-assistant': {
    id: 'onboarding-assistant',
    name: 'Onboarding Assistant',
    description: 'Guide new users through your product seamlessly.',
    icon: 'fa-solid fa-rocket',
    overview: 'Create an intelligent onboarding assistant that guides new users through your product features, answers questions, and ensures a smooth onboarding experience. Perfect for SaaS products, mobile apps, and web platforms.',
    features: [
      'Step-by-step user guidance',
      'Interactive product tours',
      'Contextual help and tips',
      'Progress tracking',
      'Personalized onboarding paths',
      'Feature discovery assistance',
      'Integration with analytics',
      'Automated follow-ups'
    ],
    useCases: [
      'SaaS product onboarding',
      'Mobile app tutorials',
      'New employee onboarding',
      'Platform feature introduction',
      'User activation campaigns',
      'Product adoption improvement'
    ],
    installation: [
      'Clone this template to your workspace',
      'Install dependencies: npm install @iamai/sdk',
      'Configure onboarding steps in onboarding-config.ts',
      'Customize welcome messages and prompts',
      'Deploy using: npm run deploy'
    ],
    files: [
      {
        name: 'agent-config.ts',
        language: 'typescript',
        code: `import { Agent } from '@iamai/sdk';

export const onboardingAssistant: Agent = {
  id: 'onboarding-assistant',
  name: 'Onboarding Assistant',
  role: 'Product Onboarding Specialist',
  description: 'Guide users through product features and setup',
  
  capabilities: {
    canAttachFiles: true,
    canUseVoice: true,
    canAccessWeb: false,
  },
  
  voicePreferences: {
    defaultGender: 'female',
    allowGenderToggle: true,
  },
  
  cognition: {
    contextualAwareness: true,
    longTermMemory: true,
    goalTracking: true,
    adaptiveLearning: true,
    ethicalReasoning: true,
  },
  
  personalityMatrix: {
    formality: 50,
    humor: 60,
    enthusiasm: 90,
  },
  
  systemPrompt: \`You are an enthusiastic onboarding assistant. Your goals:
- Welcome new users warmly
- Guide them through product features step-by-step
- Answer questions about functionality
- Provide helpful tips and best practices
- Track progress and celebrate milestones
- Ensure users feel confident using the product\`,
};`
      },
      {
        name: 'onboarding-steps.ts',
        language: 'typescript',
        code: `export interface OnboardingStep {
  id: string;
  title: string;
  description: string;
  action: string;
  completed: boolean;
}

export const onboardingSteps: OnboardingStep[] = [
  {
    id: 'step-1',
    title: 'Welcome!',
    description: 'Learn about our platform and what you can do',
    action: 'watch-intro',
    completed: false,
  },
  {
    id: 'step-2',
    title: 'Set Up Your Profile',
    description: 'Add your information and preferences',
    action: 'setup-profile',
    completed: false,
  },
  {
    id: 'step-3',
    title: 'Explore Features',
    description: 'Take a tour of the main features',
    action: 'feature-tour',
    completed: false,
  },
  {
    id: 'step-4',
    title: 'Create Your First Project',
    description: 'Start building with a guided tutorial',
    action: 'create-project',
    completed: false,
  },
  {
    id: 'step-5',
    title: 'You\\'re All Set!',
    description: 'Onboarding complete. Start exploring!',
    action: 'complete',
    completed: false,
  },
];`
      }
    ],
    apiEndpoint: 'https://api.iamai.global/v1/chat'
  },
  'sales-development-rep': {
    id: 'sales-development-rep',
    name: 'Sales Development Rep',
    description: 'Qualify leads and book meetings automatically.',
    icon: 'fa-solid fa-dollar-sign',
    overview: 'Build an AI-powered sales development representative that qualifies leads, answers product questions, and books meetings with your sales team. Integrates with your CRM and calendar systems.',
    features: [
      'Lead qualification automation',
      'Meeting scheduling integration',
      'CRM synchronization',
      'Product knowledge Q&A',
      'Lead scoring and prioritization',
      'Email and chat follow-ups',
      'Sales pipeline management',
      'Performance analytics'
    ],
    useCases: [
      'B2B lead generation',
      'Sales qualification process',
      'Demo booking automation',
      'Inbound lead management',
      'Sales funnel optimization',
      'Lead nurturing campaigns'
    ],
    installation: [
      'Clone this template to your workspace',
      'Install dependencies: npm install @iamai/sdk',
      'Configure CRM integration in crm-config.ts',
      'Set up calendar integration',
      'Deploy using: npm run deploy'
    ],
    files: [
      {
        name: 'agent-config.ts',
        language: 'typescript',
        code: `import { Agent } from '@iamai/sdk';

export const salesDevelopmentRep: Agent = {
  id: 'sales-development-rep',
  name: 'Sales Development Rep',
  role: 'Sales Development Representative',
  description: 'AI SDR for lead qualification and meeting booking',
  
  capabilities: {
    canAttachFiles: true,
    canUseVoice: true,
    canAccessWeb: true,
  },
  
  voicePreferences: {
    defaultGender: 'male',
    allowGenderToggle: true,
  },
  
  cognition: {
    contextualAwareness: true,
    longTermMemory: true,
    goalTracking: true,
    adaptiveLearning: true,
    ethicalReasoning: true,
  },
  
  personalityMatrix: {
    formality: 75,
    humor: 35,
    enthusiasm: 80,
  },
  
  systemPrompt: \`You are a professional sales development representative. Your objectives:
- Qualify leads based on BANT criteria (Budget, Authority, Need, Timeline)
- Answer product questions confidently
- Identify pain points and business needs
- Schedule meetings with qualified prospects
- Maintain a consultative, non-pushy approach
- Track all interactions in CRM\`,
};`
      },
      {
        name: 'qualification-criteria.ts',
        language: 'typescript',
        code: `export interface QualificationCriteria {
  budget: {
    question: string;
    minimumBudget: number;
  };
  authority: {
    question: string;
    targetRoles: string[];
  };
  need: {
    question: string;
    painPoints: string[];
  };
  timeline: {
    question: string;
    maxTimeframe: string;
  };
}

export const qualificationCriteria: QualificationCriteria = {
  budget: {
    question: 'What is your budget range for this solution?',
    minimumBudget: 5000,
  },
  authority: {
    question: 'Who is involved in the decision-making process?',
    targetRoles: ['CEO', 'CTO', 'VP', 'Director', 'Manager'],
  },
  need: {
    question: 'What challenges are you looking to solve?',
    painPoints: [
      'Efficiency improvement',
      'Cost reduction',
      'Revenue growth',
      'Customer satisfaction',
    ],
  },
  timeline: {
    question: 'When are you looking to implement a solution?',
    maxTimeframe: '6 months',
  },
};`
      }
    ],
    apiEndpoint: 'https://api.iamai.global/v1/chat'
  },
  'content-summarizer': {
    id: 'content-summarizer',
    name: 'Content Summarizer',
    description: 'Condense articles and documents into key points.',
    icon: 'fa-solid fa-file-lines',
    overview: 'Create an intelligent content summarization agent that can process long-form content, extract key insights, and generate concise summaries. Perfect for news aggregation, research, and content curation.',
    features: [
      'Multi-format content processing',
      'Key point extraction',
      'Summary length customization',
      'Topic identification',
      'Sentiment analysis',
      'Citation preservation',
      'Bulk processing support',
      'Multiple summary formats'
    ],
    useCases: [
      'News article summarization',
      'Research paper condensation',
      'Meeting notes summary',
      'Email thread summarization',
      'Content curation',
      'Knowledge base creation'
    ],
    installation: [
      'Clone this template to your workspace',
      'Install dependencies: npm install @iamai/sdk',
      'Configure summarization preferences',
      'Set up document processing pipeline',
      'Deploy using: npm run deploy'
    ],
    files: [
      {
        name: 'agent-config.ts',
        language: 'typescript',
        code: `import { Agent } from '@iamai/sdk';

export const contentSummarizer: Agent = {
  id: 'content-summarizer',
  name: 'Content Summarizer',
  role: 'Content Analysis Specialist',
  description: 'AI agent for content summarization and analysis',
  
  capabilities: {
    canAttachFiles: true,
    canUseVoice: false,
    canAccessWeb: true,
  },
  
  voicePreferences: {
    defaultGender: 'female',
    allowGenderToggle: true,
  },
  
  cognition: {
    contextualAwareness: true,
    longTermMemory: true,
    goalTracking: false,
    adaptiveLearning: true,
    ethicalReasoning: true,
  },
  
  personalityMatrix: {
    formality: 80,
    humor: 20,
    enthusiasm: 60,
  },
  
  systemPrompt: \`You are a content summarization specialist. Your tasks:
- Read and analyze long-form content
- Extract key points and main ideas
- Generate concise, accurate summaries
- Identify important themes and topics
- Preserve critical information and context
- Format summaries for easy reading
- Maintain objectivity and accuracy\`,
};`
      },
      {
        name: 'summarization-utils.ts',
        language: 'typescript',
        code: `export interface SummarizationOptions {
  maxLength: number;
  format: 'bullet-points' | 'paragraph' | 'brief';
  includeSentiment: boolean;
  includeTopics: boolean;
  preserveCitations: boolean;
}

export const defaultOptions: SummarizationOptions = {
  maxLength: 300,
  format: 'bullet-points',
  includeSentiment: false,
  includeTopics: true,
  preserveCitations: true,
};

export async function summarizeContent(
  content: string,
  options: Partial<SummarizationOptions> = {}
) {
  const opts = { ...defaultOptions, ...options };
  
  // Summarization logic here
  const summary = {
    original_length: content.length,
    summary_length: 0,
    key_points: [],
    topics: [],
    sentiment: null,
    citations: [],
  };
  
  return summary;
}

export function extractKeyPoints(content: string, count: number = 5): string[] {
  // Extract key points logic
  return [];
}

export function identifyTopics(content: string): string[] {
  // Topic identification logic
  return [];
}`
      }
    ],
    apiEndpoint: 'https://api.iamai.global/v1/chat'
  },
  
  // Local AI Models
  'llama-3-local': {
    id: 'llama-3-local',
    name: 'Llama 3.2 (Local)',
    description: 'Run Meta\'s Llama 3.2 model locally with Ollama.',
    icon: 'fa-solid fa-server',
    overview: 'Deploy Meta\'s powerful Llama 3.2 language model on your local machine using Ollama. This template provides everything you need to run state-of-the-art AI inference locally without relying on cloud APIs, ensuring complete data privacy and zero API costs.',
    features: [
      'Run 1B, 3B, or 11B parameter variants locally',
      'Complete data privacy - no cloud dependencies',
      'Zero API costs after initial setup',
      'Customizable system prompts and parameters',
      'Support for function calling and structured outputs',
      'Multi-turn conversations with context retention',
      'Fast inference on consumer hardware',
      'Integration with IAMAI agent framework'
    ],
    useCases: [
      'Privacy-sensitive applications (healthcare, legal)',
      'Offline AI assistants and chatbots',
      'Development and testing environments',
      'Edge deployment scenarios',
      'Custom fine-tuned model deployment',
      'Cost-effective high-volume inference'
    ],
    installation: [
      'Install Ollama: curl -fsSL https://ollama.com/install.sh | sh',
      'Pull Llama 3.2 model: ollama pull llama3.2',
      'Install dependencies: npm install @iamai/sdk ollama',
      'Configure model in agent-config.ts',
      'Run locally: npm start'
    ],
    files: [
      {
        name: 'agent-config.ts',
        language: 'typescript',
        code: `import { Agent } from '@iamai/sdk';

export const llama3LocalAgent: Agent = {
  id: 'llama-3-local',
  name: 'Llama 3.2 Local Assistant',
  role: 'Local AI Assistant',
  description: 'Llama 3.2 running locally via Ollama',
  
  // Local model configuration
  modelConfig: {
    provider: 'ollama',
    model: 'llama3.2',
    baseUrl: 'http://localhost:11434',
    temperature: 0.7,
    maxTokens: 2048,
  },
  
  capabilities: {
    canAttachFiles: true,
    canUseVoice: false,
    canAccessWeb: false,
  },
  
  systemPrompt: \`You are a helpful AI assistant powered by Llama 3.2 running locally.
You have access to the full context of conversations and can help with:
- Answering questions and providing information
- Code generation and debugging
- Creative writing and brainstorming
- Analysis and summarization
Always be helpful, accurate, and respectful.\`,
};`
      },
      {
        name: 'index.ts',
        language: 'typescript',
        code: `import { Ollama } from 'ollama';
import { llama3LocalAgent } from './agent-config';

const ollama = new Ollama({ host: 'http://localhost:11434' });

async function chat(message: string) {
  const response = await ollama.chat({
    model: 'llama3.2',
    messages: [
      {
        role: 'system',
        content: llama3LocalAgent.systemPrompt
      },
      {
        role: 'user',
        content: message
      }
    ],
    stream: false,
  });
  
  return response.message.content;
}

// Example usage
async function main() {
  const reply = await chat('Hello! Tell me about yourself.');
  console.log('Assistant:', reply);
}

main();`
      },
      {
        name: 'package.json',
        language: 'json',
        code: `{
  "name": "llama3-local-agent",
  "version": "1.0.0",
  "description": "Local Llama 3.2 agent via Ollama",
  "main": "index.ts",
  "scripts": {
    "start": "ts-node index.ts",
    "dev": "nodemon index.ts"
  },
  "dependencies": {
    "@iamai/sdk": "^1.0.0",
    "ollama": "^0.5.0"
  },
  "devDependencies": {
    "@types/node": "^20.0.0",
    "ts-node": "^10.9.0",
    "typescript": "^5.0.0"
  }
}`
      },
      {
        name: 'README.md',
        language: 'markdown',
        code: `# Llama 3.2 Local Agent

Run Meta's Llama 3.2 model locally using Ollama.

## Prerequisites

- Ollama installed: https://ollama.com/download
- At least 8GB RAM (for 3B model)
- Node.js 18+

## Available Models

- \`llama3.2:1b\` - Smallest, fastest (1GB)
- \`llama3.2:3b\` - Balanced (2GB)
- \`llama3.2:11b\` - Most capable (7GB)

## Quick Start

\`\`\`bash
# Pull the model
ollama pull llama3.2

# Install dependencies
npm install

# Run the agent
npm start
\`\`\`

## Model Info

- **Developer:** Meta AI
- **Parameters:** 1B - 11B
- **Context Length:** 128K tokens
- **License:** Llama 3.2 Community License`
      }
    ],
    apiEndpoint: 'http://localhost:11434/api/chat'
  },
  
  'mistral-local': {
    id: 'mistral-local',
    name: 'Mistral 7B (Local)',
    description: 'Efficient 7B parameter model for local deployment.',
    icon: 'fa-solid fa-microchip',
    overview: 'Deploy Mistral AI\'s efficient 7B parameter model locally. Known for excellent performance-to-size ratio, Mistral 7B delivers impressive results while running smoothly on consumer hardware.',
    features: [
      '7B parameters optimized for efficiency',
      'Excellent reasoning capabilities',
      'Support for function calling',
      'Fast inference speed',
      '32K context window',
      'Multilingual support',
      'Low memory footprint (4GB RAM)',
      'Apache 2.0 license'
    ],
    useCases: [
      'General-purpose chatbots',
      'Code assistance and generation',
      'Document analysis',
      'Creative writing',
      'Task automation',
      'Educational applications'
    ],
    installation: [
      'Install Ollama: curl -fsSL https://ollama.com/install.sh | sh',
      'Pull Mistral: ollama pull mistral',
      'Install dependencies: npm install ollama',
      'Configure in your project',
      'Start developing: npm start'
    ],
    files: [
      {
        name: 'agent-config.ts',
        language: 'typescript',
        code: `import { Agent } from '@iamai/sdk';

export const mistralLocalAgent: Agent = {
  id: 'mistral-local',
  name: 'Mistral 7B Assistant',
  role: 'Efficient Local AI',
  description: 'Mistral 7B running locally via Ollama',
  
  modelConfig: {
    provider: 'ollama',
    model: 'mistral',
    baseUrl: 'http://localhost:11434',
    temperature: 0.7,
    topP: 0.9,
    maxTokens: 4096,
  },
  
  capabilities: {
    canAttachFiles: true,
    canUseVoice: false,
    canAccessWeb: false,
  },
  
  systemPrompt: \`You are a helpful AI assistant powered by Mistral 7B.
You excel at:
- Clear and concise explanations
- Code generation and debugging
- Logical reasoning and problem-solving
- Multilingual communication
Always provide accurate and helpful responses.\`,
};`
      },
      {
        name: 'index.ts',
        language: 'typescript',
        code: `import { Ollama } from 'ollama';
import { mistralLocalAgent } from './agent-config';

const ollama = new Ollama({ host: 'http://localhost:11434' });

async function chatWithMistral(userMessage: string) {
  const response = await ollama.chat({
    model: 'mistral',
    messages: [
      { role: 'system', content: mistralLocalAgent.systemPrompt },
      { role: 'user', content: userMessage }
    ],
    options: {
      temperature: 0.7,
      top_p: 0.9,
    }
  });
  
  return response.message.content;
}

// Streaming example
async function streamChat(message: string) {
  const stream = await ollama.chat({
    model: 'mistral',
    messages: [{ role: 'user', content: message }],
    stream: true,
  });
  
  for await (const chunk of stream) {
    process.stdout.write(chunk.message.content);
  }
}`
      }
    ],
    apiEndpoint: 'http://localhost:11434/api/chat'
  },
  
  'phi-3-local': {
    id: 'phi-3-local',
    name: 'Phi-3 Mini (Local)',
    description: 'Microsoft\'s compact 3.8B model for edge devices.',
    icon: 'fa-solid fa-mobile-screen',
    overview: 'Microsoft\'s Phi-3 Mini delivers impressive performance in a compact 3.8B parameter package. Optimized for edge deployment and resource-constrained environments.',
    features: [
      'Compact 3.8B parameters',
      'Optimized for CPU inference',
      'Low memory usage (2.3GB)',
      'Fast response times',
      'Excellent reasoning for size',
      'MIT license - fully open',
      'Mobile-friendly',
      'ONNX runtime support'
    ],
    useCases: [
      'Mobile and edge applications',
      'IoT devices',
      'Embedded systems',
      'Low-resource servers',
      'Offline assistants',
      'Prototype development'
    ],
    installation: [
      'Install Ollama: curl -fsSL https://ollama.com/install.sh | sh',
      'Pull Phi-3: ollama pull phi3',
      'Install SDK: npm install ollama @iamai/sdk',
      'Configure model parameters',
      'Deploy: npm run deploy'
    ],
    files: [
      {
        name: 'agent-config.ts',
        language: 'typescript',
        code: `import { Agent } from '@iamai/sdk';

export const phi3LocalAgent: Agent = {
  id: 'phi-3-local',
  name: 'Phi-3 Mini Assistant',
  role: 'Compact AI Assistant',
  description: 'Microsoft Phi-3 Mini for edge deployment',
  
  modelConfig: {
    provider: 'ollama',
    model: 'phi3',
    baseUrl: 'http://localhost:11434',
    temperature: 0.6,
    maxTokens: 2048,
  },
  
  capabilities: {
    canAttachFiles: false,
    canUseVoice: false,
    canAccessWeb: false,
  },
  
  systemPrompt: \`You are a helpful AI assistant powered by Microsoft Phi-3 Mini.
Despite your compact size, you provide:
- Accurate information and explanations
- Logical reasoning and problem-solving
- Code assistance and debugging
- Quick responses optimized for edge devices
Be concise and helpful.\`,
};`
      }
    ],
    apiEndpoint: 'http://localhost:11434/api/chat'
  },
  
  'gemma-local': {
    id: 'gemma-local',
    name: 'Gemma 2B (Local)',
    description: 'Google\'s lightweight model for local inference.',
    icon: 'fa-solid fa-cube',
    overview: 'Google\'s Gemma 2B offers excellent performance in an ultra-compact package. Perfect for development, testing, and lightweight production deployments.',
    features: [
      'Ultra-compact 2B parameters',
      'Fast inference on CPU',
      'Low memory (1.5GB)',
      'Gemini-inspired architecture',
      'Multi-task capable',
      'Open weights',
      'Efficient fine-tuning',
      'Commercial-friendly license'
    ],
    useCases: [
      'Rapid prototyping',
      'Development environments',
      'Educational projects',
      'Resource-constrained deployment',
      'Local testing',
      'Personal assistants'
    ],
    installation: [
      'Install Ollama: curl -fsSL https://ollama.com/install.sh | sh',
      'Pull Gemma: ollama pull gemma:2b',
      'Install packages: npm install ollama',
      'Configure agent settings',
      'Run: npm start'
    ],
    files: [
      {
        name: 'agent-config.ts',
        language: 'typescript',
        code: `import { Agent } from '@iamai/sdk';

export const gemmaLocalAgent: Agent = {
  id: 'gemma-local',
  name: 'Gemma 2B Assistant',
  role: 'Lightweight AI',
  description: 'Google Gemma 2B for fast local inference',
  
  modelConfig: {
    provider: 'ollama',
    model: 'gemma:2b',
    baseUrl: 'http://localhost:11434',
    temperature: 0.7,
    maxTokens: 2048,
  },
  
  systemPrompt: \`You are a helpful AI assistant powered by Google Gemma.
You provide quick, accurate responses while using minimal resources.
Focus on clarity and helpfulness.\`,
};`
      }
    ],
    apiEndpoint: 'http://localhost:11434/api/chat'
  },
  
  'codellama-local': {
    id: 'codellama-local',
    name: 'CodeLlama (Local)',
    description: 'Specialized code generation model running locally.',
    icon: 'fa-solid fa-code',
    overview: 'Meta\'s CodeLlama is specifically trained for code generation, completion, and understanding. Run it locally for AI-powered coding assistance without cloud dependencies.',
    features: [
      'Specialized for code tasks',
      'Supports 20+ programming languages',
      'Code completion and generation',
      'Bug detection and fixing',
      'Code explanation and documentation',
      '100K context window',
      'Multiple size variants (7B-34B)',
      'Llama 2 license'
    ],
    useCases: [
      'IDE integration',
      'Code review automation',
      'Documentation generation',
      'Code refactoring assistance',
      'Learning programming',
      'Debugging support'
    ],
    installation: [
      'Install Ollama: curl -fsSL https://ollama.com/install.sh | sh',
      'Pull CodeLlama: ollama pull codellama',
      'Install deps: npm install ollama @iamai/sdk',
      'Configure coding agent',
      'Start coding: npm run dev'
    ],
    files: [
      {
        name: 'agent-config.ts',
        language: 'typescript',
        code: `import { Agent } from '@iamai/sdk';

export const codeLlamaAgent: Agent = {
  id: 'codellama-local',
  name: 'CodeLlama Assistant',
  role: 'Code Generation Specialist',
  description: 'CodeLlama for local code assistance',
  
  modelConfig: {
    provider: 'ollama',
    model: 'codellama',
    baseUrl: 'http://localhost:11434',
    temperature: 0.2, // Lower for more deterministic code
    maxTokens: 4096,
  },
  
  capabilities: {
    canAttachFiles: true,
    canUseVoice: false,
    canAccessWeb: false,
  },
  
  systemPrompt: \`You are CodeLlama, an expert programming assistant.
You excel at:
- Writing clean, efficient code
- Debugging and fixing errors
- Explaining code concepts
- Code refactoring and optimization
- Documentation generation
Always provide well-commented, production-ready code.\`,
};`
      },
      {
        name: 'code-helper.ts',
        language: 'typescript',
        code: `import { Ollama } from 'ollama';
import { codeLlamaAgent } from './agent-config';

const ollama = new Ollama({ host: 'http://localhost:11434' });

export async function generateCode(prompt: string, language: string) {
  const response = await ollama.chat({
    model: 'codellama',
    messages: [
      {
        role: 'system',
        content: codeLlamaAgent.systemPrompt
      },
      {
        role: 'user',
        content: \`Generate \${language} code for: \${prompt}\`
      }
    ],
    options: {
      temperature: 0.2,
    }
  });
  
  return response.message.content;
}

export async function explainCode(code: string) {
  const response = await ollama.chat({
    model: 'codellama',
    messages: [{
      role: 'user',
      content: \`Explain this code:\n\n\${code}\`
    }]
  });
  
  return response.message.content;
}

export async function fixBug(code: string, error: string) {
  const response = await ollama.chat({
    model: 'codellama',
    messages: [{
      role: 'user',
      content: \`Fix this code error:\n\nCode:\n\${code}\n\nError:\n\${error}\`
    }]
  });
  
  return response.message.content;
}`
      }
    ],
    apiEndpoint: 'http://localhost:11434/api/chat'
  },
  
  'neural-chat-local': {
    id: 'neural-chat-local',
    name: 'Neural Chat 7B (Local)',
    description: 'Intel\'s optimized conversational AI model.',
    icon: 'fa-solid fa-comments',
    overview: 'Intel\'s Neural Chat 7B is optimized for conversational AI with excellent performance on Intel hardware. Fine-tuned for natural, engaging conversations.',
    features: [
      'Optimized for Intel CPUs',
      'Natural conversation flow',
      'Context-aware responses',
      '7B parameters',
      'Fast inference on CPU',
      'Multilingual support',
      'Apache 2.0 license',
      'Easy fine-tuning'
    ],
    useCases: [
      'Customer service chatbots',
      'Virtual assistants',
      'Interactive tutorials',
      'Conversational interfaces',
      'Support automation',
      'Personal AI companions'
    ],
    installation: [
      'Install Ollama: curl -fsSL https://ollama.com/install.sh | sh',
      'Pull Neural Chat: ollama pull neural-chat',
      'Install SDK: npm install ollama',
      'Setup conversation config',
      'Launch: npm start'
    ],
    files: [
      {
        name: 'agent-config.ts',
        language: 'typescript',
        code: `import { Agent } from '@iamai/sdk';

export const neuralChatAgent: Agent = {
  id: 'neural-chat-local',
  name: 'Neural Chat Assistant',
  role: 'Conversational AI',
  description: 'Intel Neural Chat for natural conversations',
  
  modelConfig: {
    provider: 'ollama',
    model: 'neural-chat',
    baseUrl: 'http://localhost:11434',
    temperature: 0.8,
    topP: 0.95,
    maxTokens: 2048,
  },
  
  capabilities: {
    canAttachFiles: true,
    canUseVoice: true,
    canAccessWeb: false,
  },
  
  personalityMatrix: {
    formality: 50,
    humor: 60,
    enthusiasm: 70,
  },
  
  systemPrompt: \`You are a friendly and helpful AI assistant.
You excel at natural conversations and understanding context.
Be engaging, empathetic, and conversational while remaining helpful.\`,
};`
      }
    ],
    apiEndpoint: 'http://localhost:11434/api/chat'
  },
  
  'vicuna-local': {
    id: 'vicuna-local',
    name: 'Vicuna 13B (Local)',
    description: 'Open-source chatbot trained by fine-tuning LLaMA.',
    icon: 'fa-solid fa-brain',
    overview: 'Vicuna 13B is an open-source chatbot trained by fine-tuning LLaMA on user-shared conversations. Achieves 90%+ quality of ChatGPT while running locally.',
    features: [
      '13B parameters for high quality',
      '90% ChatGPT quality score',
      'Fine-tuned on conversation data',
      'Excellent instruction following',
      'Creative and detailed responses',
      'Open-source and modifiable',
      'Active community',
      'Research-friendly license'
    ],
    useCases: [
      'High-quality chatbots',
      'Research and experimentation',
      'Creative writing assistance',
      'Detailed explanations',
      'Complex reasoning tasks',
      'Educational applications'
    ],
    installation: [
      'Install Ollama: curl -fsSL https://ollama.com/install.sh | sh',
      'Pull Vicuna: ollama pull vicuna',
      'Install deps: npm install ollama',
      'Configure agent',
      'Run: npm start'
    ],
    files: [
      {
        name: 'agent-config.ts',
        language: 'typescript',
        code: `import { Agent } from '@iamai/sdk';

export const vicunaAgent: Agent = {
  id: 'vicuna-local',
  name: 'Vicuna 13B Assistant',
  role: 'Advanced Conversational AI',
  description: 'Vicuna 13B for high-quality interactions',
  
  modelConfig: {
    provider: 'ollama',
    model: 'vicuna',
    baseUrl: 'http://localhost:11434',
    temperature: 0.7,
    topP: 0.9,
    maxTokens: 4096,
  },
  
  capabilities: {
    canAttachFiles: true,
    canUseVoice: false,
    canAccessWeb: false,
  },
  
  cognition: {
    contextualAwareness: true,
    longTermMemory: true,
    goalTracking: true,
    adaptiveLearning: true,
  },
  
  systemPrompt: \`You are Vicuna, a helpful AI assistant.
You provide detailed, thoughtful responses and engage in natural conversation.
You excel at creative tasks, detailed explanations, and complex reasoning.
Always be helpful, accurate, and respectful.\`,
};`
      }
    ],
    apiEndpoint: 'http://localhost:11434/api/chat'
  },
  
  'orca-mini-local': {
    id: 'orca-mini-local',
    name: 'Orca Mini (Local)',
    description: 'Compact model trained on explanation data.',
    icon: 'fa-solid fa-fish',
    overview: 'Orca Mini is a compact model trained on high-quality explanation data. Excels at providing clear, step-by-step explanations while maintaining a small footprint.',
    features: [
      'Trained on explanation traces',
      'Excellent at step-by-step reasoning',
      'Compact 3B or 7B variants',
      'Clear and educational responses',
      'Fast inference',
      'Good for learning',
      'Low resource usage',
      'Open license'
    ],
    useCases: [
      'Educational applications',
      'Tutorial generation',
      'Concept explanation',
      'Learning assistants',
      'Documentation writing',
      'Problem-solving guidance'
    ],
    installation: [
      'Install Ollama: curl -fsSL https://ollama.com/install.sh | sh',
      'Pull Orca Mini: ollama pull orca-mini',
      'Install packages: npm install ollama',
      'Setup configuration',
      'Start: npm run dev'
    ],
    files: [
      {
        name: 'agent-config.ts',
        language: 'typescript',
        code: `import { Agent } from '@iamai/sdk';

export const orcaMiniAgent: Agent = {
  id: 'orca-mini-local',
  name: 'Orca Mini Assistant',
  role: 'Educational AI',
  description: 'Orca Mini for clear explanations',
  
  modelConfig: {
    provider: 'ollama',
    model: 'orca-mini',
    baseUrl: 'http://localhost:11434',
    temperature: 0.6,
    maxTokens: 2048,
  },
  
  capabilities: {
    canAttachFiles: true,
    canUseVoice: false,
    canAccessWeb: false,
  },
  
  systemPrompt: \`You are Orca Mini, an educational AI assistant.
You excel at providing clear, step-by-step explanations.
Break down complex topics into understandable parts.
Use examples and analogies to make concepts clear.
Always be patient and thorough in your explanations.\`,
};`
      }
    ],
    apiEndpoint: 'http://localhost:11434/api/chat'
  }
};

const TemplateDetailPage: React.FC<TemplateDetailPageProps> = ({ templateId, onNavigate }) => {
  const [selectedFile, setSelectedFile] = useState<string>('');
  const [copiedFile, setCopiedFile] = useState<string>('');

  const template = TEMPLATE_DETAILS[templateId];

  if (!template) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-3xl font-bold mb-4">Template Not Found</h1>
          <button
            onClick={() => onNavigate('templates')}
            className="text-cyan-400 hover:text-cyan-300 transition-colors"
          >
            ← Back to Templates
          </button>
        </div>
      </div>
    );
  }

  // Set default selected file
  React.useEffect(() => {
    if (template.files.length > 0 && !selectedFile) {
      setSelectedFile(template.files[0].name);
    }
  }, [template, selectedFile]);

  const copyToClipboard = (code: string, fileName: string) => {
    navigator.clipboard.writeText(code);
    setCopiedFile(fileName);
    setTimeout(() => setCopiedFile(''), 2000);
  };

  const currentFile = template.files.find(f => f.name === selectedFile) || template.files[0];

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <div className="bg-gray-900/50 border-b border-gray-800">
        <div className="container mx-auto px-6 py-6">
          <button
            onClick={() => onNavigate('templates')}
            className="text-gray-400 hover:text-cyan-400 transition-colors mb-4 flex items-center gap-2"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            Back to Templates
          </button>
          
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 flex items-center justify-center rounded-xl bg-cyan-900/50 border border-cyan-500/30">
              <i className={`${template.icon} text-3xl text-cyan-400`}></i>
            </div>
            <div>
              <h1 className="text-3xl font-bold">{template.name}</h1>
              <p className="text-gray-400 mt-1">{template.description}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-6 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Documentation */}
          <div className="lg:col-span-1 space-y-6">
            {/* Overview */}
            <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-6">
              <h2 className="text-xl font-bold text-white mb-4">Overview</h2>
              <p className="text-gray-300 text-sm leading-relaxed">{template.overview}</p>
            </div>

            {/* Features */}
            <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-6">
              <h2 className="text-xl font-bold text-white mb-4">Features</h2>
              <ul className="space-y-2">
                {template.features.map((feature, idx) => (
                  <li key={idx} className="text-gray-300 text-sm flex items-start gap-2">
                    <span className="text-cyan-400 mt-1">✓</span>
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Use Cases */}
            <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-6">
              <h2 className="text-xl font-bold text-white mb-4">Use Cases</h2>
              <ul className="space-y-2">
                {template.useCases.map((useCase, idx) => (
                  <li key={idx} className="text-gray-300 text-sm flex items-start gap-2">
                    <span className="text-gray-600">•</span>
                    <span>{useCase}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Installation */}
            <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-6">
              <h2 className="text-xl font-bold text-white mb-4">Quick Start</h2>
              <ol className="space-y-3">
                {template.installation.map((step, idx) => (
                  <li key={idx} className="text-gray-300 text-sm flex gap-3">
                    <span className="flex-shrink-0 w-6 h-6 flex items-center justify-center rounded-full bg-cyan-500/20 text-cyan-400 text-xs font-bold">
                      {idx + 1}
                    </span>
                    <span className="pt-0.5">{step}</span>
                  </li>
                ))}
              </ol>
            </div>

            {/* API Endpoint */}
            <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-6">
              <h2 className="text-xl font-bold text-white mb-4">API Endpoint Example</h2>
              <code className="text-cyan-400 text-sm break-all">{template.apiEndpoint}</code>
            </div>
          </div>

          {/* Right Column - Code Files */}
          <div className="lg:col-span-2">
            <div className="bg-gray-900/50 border border-gray-800 rounded-xl overflow-hidden">
              {/* File Tabs */}
              <div className="border-b border-gray-800 bg-gray-900/80">
                <div className="flex overflow-x-auto">
                  {template.files.map((file) => (
                    <button
                      key={file.name}
                      onClick={() => setSelectedFile(file.name)}
                      className={`px-4 py-3 text-sm font-medium whitespace-nowrap transition-colors border-b-2 ${
                        selectedFile === file.name
                          ? 'text-cyan-400 border-cyan-400 bg-gray-900/50'
                          : 'text-gray-400 border-transparent hover:text-gray-300'
                      }`}
                    >
                      {file.name}
                    </button>
                  ))}
                </div>
              </div>

              {/* Code Display */}
              <div className="relative">
                <div className="absolute top-4 right-4 z-10">
                  <button
                    onClick={() => copyToClipboard(currentFile.code, currentFile.name)}
                    className="px-3 py-2 bg-gray-800 hover:bg-gray-700 text-white text-sm rounded-lg transition-colors flex items-center gap-2"
                  >
                    {copiedFile === currentFile.name ? (
                      <>
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                        Copied!
                      </>
                    ) : (
                      <>
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                        </svg>
                        Copy Code
                      </>
                    )}
                  </button>
                </div>
                
                <pre className="p-6 overflow-x-auto text-sm leading-relaxed" style={{ maxHeight: '600px' }}>
                  <code className="text-gray-300">{currentFile.code}</code>
                </pre>
              </div>
            </div>

            {/* Deploy Button */}
            <div className="mt-6">
              <button className="w-full px-6 py-4 bg-gradient-to-r from-cyan-500 to-blue-500 text-white font-semibold rounded-xl hover:shadow-xl hover:shadow-cyan-500/30 transition-all">
                <span className="flex items-center justify-center gap-2">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                  </svg>
                  Deploy This Template
                </span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TemplateDetailPage;
