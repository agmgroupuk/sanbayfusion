import React, { useEffect, useMemo, useState } from 'react';
import { ArrowLeft, Radio, Play, StopCircle, Activity, TrendingUp, TrendingDown, Clock, Zap, Download, Copy, Check, AlertCircle } from 'lucide-react';
import { getSocket } from '../../services/socket';
import { LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';

interface Props { onNavigate?: (page: string) => void }

type PingUpdate = { host: string; seq: number; alive: boolean; timeMs?: number|null; error?: string; timestamp?: number };

interface HistoryEntry {
  id: string;
  host: string;
  count: number;
  stats: {
    min: number;
    max: number;
    avg: number;
    loss: string;
  } | null;
  timestamp: string;
}

const PingTestPage: React.FC<Props> = ({ onNavigate }) => {
  const [host, setHost] = useState('8.8.8.8');
  const [count, setCount] = useState(10);
  const [intervalMs, setIntervalMs] = useState(1000);
  const [running, setRunning] = useState(false);
  const [updates, setUpdates] = useState<PingUpdate[]>([]);
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [copied, setCopied] = useState(false);
  const [continuous, setContinuous] = useState(false);
  
  const stats = useMemo(() => {
    const times = updates.map(u=>u.timeMs || 0).filter(Boolean) as number[];
    if (times.length === 0) return null;
    
    const min = Math.min(...times);
    const max = Math.max(...times);
    const avg = Math.round(times.reduce((a,b)=>a+b,0)/times.length);
    const loss = ((updates.length - times.length) / updates.length * 100).toFixed(1);
    
    return { min, max, avg, loss };
  }, [updates]);

  const jitter = useMemo(() => {
    const times = updates.map(u=>u.timeMs || 0).filter(Boolean) as number[];
    if (times.length < 2) return null;
    
    let totalVariation = 0;
    for (let i = 1; i < times.length; i++) {
      totalVariation += Math.abs(times[i] - times[i-1]);
    }
    return Math.round(totalVariation / (times.length - 1));
  }, [updates]);

  const chartData = useMemo(() => {
    return updates.map(u => ({
      seq: u.seq,
      time: u.timeMs || 0,
      alive: u.alive
    }));
  }, [updates]);

  useEffect(() => {
    const socket = getSocket();
    const onUpdate = (u: PingUpdate) => setUpdates(prev => [...prev, u]);
    const onDone = () => {
      setRunning(false);
      
      // Save to history if we have valid stats
      if (stats && updates.length > 0) {
        const historyEntry: HistoryEntry = {
          id: Date.now().toString(),
          host,
          count: updates.length,
          stats,
          timestamp: new Date().toISOString()
        };
        setHistory(prev => [historyEntry, ...prev.slice(0, 9)]);
      }
    };
    socket.on('tools:ping:update', onUpdate);
    socket.on('tools:ping:done', onDone);
    return () => {
      socket.off('tools:ping:update', onUpdate);
      socket.off('tools:ping:done', onDone);
    };
  }, [stats, updates.length, host]);

  const start = () => {
    console.log('[PingTest] Starting ping test', { host, count: continuous ? 999 : count, intervalMs });
    const socket = getSocket();
    console.log('[PingTest] Socket connected:', socket.connected);
    if (!socket.connected) {
      console.error('[PingTest] Socket not connected!');
      alert('WebSocket not connected. Please refresh the page.');
      return;
    }
    setUpdates([]);
    setRunning(true);
    socket.emit('tools:ping:start', { host, count: continuous ? 999 : count, intervalMs });
    console.log('[PingTest] Emitted tools:ping:start');
  };

  const stop = () => {
    console.log('[PingTest] Stopping ping test');
    setRunning(false);
    getSocket().emit('tools:ping:stop');
    console.log('[PingTest] Emitted tools:ping:stop');
  };

  const copyResults = () => {
    const text = JSON.stringify({ host, count: updates.length, updates, stats }, null, 2);
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const downloadResults = () => {
    const blob = new Blob([JSON.stringify({ host, count: updates.length, updates, stats }, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ping-${host}-${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const loadFromHistory = (entry: HistoryEntry) => {
    setHost(entry.host);
    setCount(entry.count);
  };

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <section className="relative overflow-hidden py-12 border-b border-gray-800">
        <div className="absolute inset-0 bg-grid-gray-900 [mask-image:linear-gradient(to_bottom,white_30%,transparent)]"></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-cyan-500/10 rounded-full blur-3xl"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <button 
            onClick={() => onNavigate?.('toolbox')} 
            className="mb-6 flex items-center gap-2 text-gray-400 hover:text-cyan-400 transition-colors"
          >
            <ArrowLeft className="w-4 h-4"/> Back to Toolbox
          </button>
          
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 bg-cyan-500/20 rounded-lg border border-cyan-500/30">
              <Radio className="w-6 h-6 text-cyan-400"/>
            </div>
            <div>
              <h1 className="text-3xl md:text-4xl font-bold">Ping Test</h1>
              <p className="text-gray-400 mt-1">Real-time network latency monitoring</p>
            </div>
          </div>

          {/* Stats Dashboard */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mt-6">
            <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-4">
              <div className="text-gray-400 text-sm mb-1">Packets Sent</div>
              <div className="text-2xl font-bold text-cyan-400">{updates.length}</div>
            </div>
            <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-4">
              <div className="text-gray-400 text-sm mb-1">Average</div>
              <div className="text-2xl font-bold text-green-400">
                {stats ? `${stats.avg}ms` : '--'}
              </div>
            </div>
            <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-4">
              <div className="text-gray-400 text-sm mb-1">Min / Max</div>
              <div className="text-lg font-bold text-purple-400">
                {stats ? `${stats.min} / ${stats.max}ms` : '--'}
              </div>
            </div>
            <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-4">
              <div className="text-gray-400 text-sm mb-1">Packet Loss</div>
              <div className="text-2xl font-bold text-red-400">
                {stats ? `${stats.loss}%` : '--'}
              </div>
            </div>
            <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-4">
              <div className="text-gray-400 text-sm mb-1">Jitter</div>
              <div className="text-2xl font-bold text-yellow-400">
                {jitter !== null ? `${jitter}ms` : '--'}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-3 gap-6">
            {/* Left Column - Controls */}
            <div className="lg:col-span-2 space-y-6">
              {/* Control Panel */}
              <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
                <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
                  <Activity className="w-5 h-5 text-cyan-400" />
                  Ping Configuration
                </h2>
                
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm text-gray-400 mb-2">Host or IP Address</label>
                    <input 
                      className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500 transition" 
                      placeholder="8.8.8.8 or google.com" 
                      value={host} 
                      onChange={e=>setHost(e.target.value)}
                      disabled={running}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm text-gray-400 mb-2">Packet Count</label>
                      <input 
                        type="number" 
                        className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-cyan-500 transition" 
                        value={count} 
                        onChange={e=>setCount(parseInt(e.target.value||'0',10))}
                        disabled={running || continuous}
                        min={1}
                        max={100}
                      />
                    </div>
                    <div>
                      <label className="block text-sm text-gray-400 mb-2">Interval (ms)</label>
                      <select
                        className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-cyan-500 transition"
                        value={intervalMs}
                        onChange={e=>setIntervalMs(parseInt(e.target.value))}
                        disabled={running}
                      >
                        <option value={500}>500ms</option>
                        <option value={1000}>1000ms</option>
                        <option value={2000}>2000ms</option>
                        <option value={5000}>5000ms</option>
                      </select>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 p-4 bg-gray-800/50 rounded-lg border border-gray-700">
                    <input
                      type="checkbox"
                      id="continuous"
                      checked={continuous}
                      onChange={e => setContinuous(e.target.checked)}
                      className="w-4 h-4"
                      disabled={running}
                    />
                    <label htmlFor="continuous" className="text-sm text-gray-300 flex-1">
                      Continuous Ping (runs until stopped)
                    </label>
                    {continuous && !running && (
                      <Zap className="w-4 h-4 text-yellow-400" />
                    )}
                  </div>

                  <div className="flex gap-3">
                    {!running ? (
                      <button 
                        onClick={start} 
                        disabled={!host.trim()}
                        className="flex-1 px-6 py-3 rounded-lg bg-gradient-to-r from-cyan-500 to-purple-500 text-black font-semibold flex items-center justify-center gap-2 hover:shadow-lg hover:shadow-cyan-500/50 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                      >
                        <Play className="w-4 h-4"/>
                        Start Ping
                      </button>
                    ) : (
                      <button 
                        onClick={stop}
                        className="flex-1 px-6 py-3 rounded-lg bg-red-500 text-white font-semibold flex items-center justify-center gap-2 hover:bg-red-600 transition-all"
                      >
                        <StopCircle className="w-4 h-4"/>
                        Stop Ping
                      </button>
                    )}
                    
                    {updates.length > 0 && (
                      <>
                        <button
                          onClick={copyResults}
                          className="px-4 py-3 bg-gray-800 hover:bg-gray-700 rounded-lg border border-gray-700 transition"
                          title="Copy results"
                        >
                          {copied ? <Check className="w-5 h-5 text-green-400" /> : <Copy className="w-5 h-5" />}
                        </button>
                        <button
                          onClick={downloadResults}
                          className="px-4 py-3 bg-gray-800 hover:bg-gray-700 rounded-lg border border-gray-700 transition"
                          title="Download results"
                        >
                          <Download className="w-5 h-5" />
                        </button>
                      </>
                    )}
                  </div>
                </div>
              </div>

              {/* Charts */}
              {chartData.length > 0 && (
                <>
                  {/* Latency Chart */}
                  <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
                    <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                      <TrendingUp className="w-5 h-5 text-cyan-400" />
                      Latency Over Time
                    </h3>
                    <ResponsiveContainer width="100%" height={250}>
                      <LineChart data={chartData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                        <XAxis 
                          dataKey="seq" 
                          stroke="#9CA3AF"
                          label={{ value: 'Sequence', position: 'insideBottom', offset: -5, fill: '#9CA3AF' }}
                        />
                        <YAxis 
                          stroke="#9CA3AF"
                          label={{ value: 'Latency (ms)', angle: -90, position: 'insideLeft', fill: '#9CA3AF' }}
                        />
                        <Tooltip 
                          contentStyle={{ backgroundColor: '#1F2937', border: '1px solid #374151', borderRadius: '8px' }}
                          labelStyle={{ color: '#9CA3AF' }}
                        />
                        <Legend />
                        <Line 
                          type="monotone" 
                          dataKey="time" 
                          stroke="#06B6D4" 
                          strokeWidth={2}
                          dot={{ fill: '#06B6D4', r: 4 }}
                          name="Response Time (ms)"
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>

                  {/* Area Chart */}
                  <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
                    <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                      <Activity className="w-5 h-5 text-purple-400" />
                      Performance Distribution
                    </h3>
                    <ResponsiveContainer width="100%" height={250}>
                      <AreaChart data={chartData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                        <XAxis 
                          dataKey="seq" 
                          stroke="#9CA3AF"
                        />
                        <YAxis 
                          stroke="#9CA3AF"
                        />
                        <Tooltip 
                          contentStyle={{ backgroundColor: '#1F2937', border: '1px solid #374151', borderRadius: '8px' }}
                        />
                        <Area 
                          type="monotone" 
                          dataKey="time" 
                          stroke="#A855F7" 
                          fill="#A855F7"
                          fillOpacity={0.3}
                          name="Latency"
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </>
              )}

              {/* Results List */}
              {updates.length > 0 && (
                <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
                  <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                    <Clock className="w-5 h-5 text-green-400" />
                    Ping Results
                  </h3>
                  <div className="max-h-64 overflow-auto space-y-2">
                    {updates.map((u, i) => (
                      <div 
                        key={i} 
                        className="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg border border-gray-700"
                      >
                        <div className="flex items-center gap-3">
                          {u.alive ? (
                            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                          ) : (
                            <div className="w-2 h-2 bg-red-400 rounded-full"></div>
                          )}
                          <span className="font-mono text-sm">
                            Packet #{u.seq}
                          </span>
                        </div>
                        <div className="flex items-center gap-4">
                          {u.alive ? (
                            <>
                              <span className="text-green-400 text-sm font-medium">
                                {u.timeMs}ms
                              </span>
                              {u.timeMs && u.timeMs < 50 && <TrendingUp className="w-4 h-4 text-green-400" />}
                              {u.timeMs && u.timeMs >= 50 && u.timeMs < 100 && <Activity className="w-4 h-4 text-yellow-400" />}
                              {u.timeMs && u.timeMs >= 100 && <TrendingDown className="w-4 h-4 text-red-400" />}
                            </>
                          ) : (
                            <span className="text-red-400 text-sm">
                              {u.error || 'Timeout'}
                            </span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Right Column - History & Info */}
            <div className="space-y-6">
              {/* Quick Hosts */}
              <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
                <h3 className="text-lg font-bold mb-4">Quick Test</h3>
                <div className="space-y-2">
                  {[
                    { host: '8.8.8.8', label: 'Google DNS' },
                    { host: '1.1.1.1', label: 'Cloudflare DNS' },
                    { host: 'google.com', label: 'Google' },
                    { host: 'github.com', label: 'GitHub' }
                  ].map(({ host: h, label }) => (
                    <button
                      key={h}
                      onClick={() => {
                        setHost(h);
                        setTimeout(start, 100);
                      }}
                      disabled={running}
                      className="w-full px-4 py-2 text-left bg-gray-800/50 hover:bg-gray-800 border border-gray-700 hover:border-cyan-500/50 rounded-lg transition text-sm disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <div className="font-semibold text-cyan-400">{label}</div>
                      <div className="text-xs text-gray-400 font-mono">{h}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* History */}
              {history.length > 0 && (
                <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-bold flex items-center gap-2">
                      <Clock className="w-5 h-5 text-cyan-400" />
                      Recent Tests
                    </h3>
                    <button
                      onClick={() => setHistory([])}
                      className="text-xs text-gray-400 hover:text-red-400 transition"
                    >
                      Clear
                    </button>
                  </div>
                  <div className="space-y-2 max-h-96 overflow-auto">
                    {history.map(entry => (
                      <button
                        key={entry.id}
                        onClick={() => loadFromHistory(entry)}
                        className="w-full p-3 text-left bg-gray-800/50 hover:bg-gray-800 border border-gray-700 hover:border-cyan-500/50 rounded-lg transition"
                      >
                        <div className="font-mono text-sm text-cyan-400 mb-1">{entry.host}</div>
                        {entry.stats && (
                          <div className="flex items-center gap-3 text-xs text-gray-400">
                            <span>Avg: <span className="text-green-400">{entry.stats.avg}ms</span></span>
                            <span>Loss: <span className="text-red-400">{entry.stats.loss}%</span></span>
                          </div>
                        )}
                        <div className="text-xs text-gray-500 mt-1">
                          {new Date(entry.timestamp).toLocaleString()}
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Info Panel */}
              <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
                <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                  <AlertCircle className="w-5 h-5 text-cyan-400" />
                  Performance Guide
                </h3>
                <div className="space-y-3 text-sm">
                  <div className="flex items-start gap-2">
                    <div className="w-16 px-2 py-1 bg-green-500/10 border border-green-500/30 rounded text-green-400 text-xs text-center">
                      &lt; 50ms
                    </div>
                    <div className="flex-1 text-gray-400 leading-relaxed">Excellent connection</div>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="w-16 px-2 py-1 bg-yellow-500/10 border border-yellow-500/30 rounded text-yellow-400 text-xs text-center">
                      50-100ms
                    </div>
                    <div className="flex-1 text-gray-400 leading-relaxed">Good for most use</div>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="w-16 px-2 py-1 bg-red-500/10 border border-red-500/30 rounded text-red-400 text-xs text-center">
                      &gt; 100ms
                    </div>
                    <div className="flex-1 text-gray-400 leading-relaxed">May affect real-time apps</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default PingTestPage;
