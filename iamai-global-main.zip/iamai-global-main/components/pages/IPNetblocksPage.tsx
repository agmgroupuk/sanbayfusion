import React, { useState, useEffect } from 'react';
import {
  Search,
  Copy,
  Download,
  Network,
  Server,
  Globe,
  Building,
  MapPin,
  AlertCircle,
  Info,
  Clock,
  TrendingUp,
  Activity,
} from 'lucide-react';

interface NetblockData {
  cidr: string;
  ipRange: string;
  ipCount: number;
  organization: string;
  country: string;
  city: string;
  asn: string;
  asnName: string;
  netName: string;
  netType: string;
  description: string;
  allocatedDate: string;
  lastModified: string;
  status: string;
  abuse: {
    email: string;
    phone: string;
  };
}

interface HistoryItem {
  id: string;
  ip: string;
  timestamp: number;
  result: NetblockData | null;
  status: 'success' | 'error';
  error?: string;
}

const IPNetblocksPage: React.FC = () => {
  const [ipAddress, setIpAddress] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<NetblockData | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [showHistory, setShowHistory] = useState(false);

  // Stats
  const [stats, setStats] = useState({
    totalLookups: 0,
    uniqueNetworks: 0,
    avgIPsPerBlock: 0,
    topOrganization: 'N/A',
  });

  // Load history from localStorage
  useEffect(() => {
    const savedHistory = localStorage.getItem('ipNetblocksHistory');
    if (savedHistory) {
      setHistory(JSON.parse(savedHistory));
    }

    const savedStats = localStorage.getItem('ipNetblocksStats');
    if (savedStats) {
      setStats(JSON.parse(savedStats));
    }
  }, []);

  // Save history to localStorage
  useEffect(() => {
    if (history.length > 0) {
      localStorage.setItem('ipNetblocksHistory', JSON.stringify(history.slice(0, 50)));
      updateStats();
    }
  }, [history]);

  const updateStats = () => {
    const successfulLookups = history.filter(h => h.status === 'success' && h.result);
    const uniqueOrgs = new Set(successfulLookups.map(h => h.result?.organization).filter(Boolean));
    const totalIPs = successfulLookups.reduce((sum, h) => sum + (h.result?.ipCount || 0), 0);
    const avgIPs =
      successfulLookups.length > 0 ? Math.round(totalIPs / successfulLookups.length) : 0;

    // Find most common organization
    const orgCounts: Record<string, number> = {};
    successfulLookups.forEach(h => {
      if (h.result?.organization) {
        orgCounts[h.result.organization] = (orgCounts[h.result.organization] || 0) + 1;
      }
    });
    const topOrg =
      Object.keys(orgCounts).length > 0
        ? Object.entries(orgCounts).sort((a, b) => b[1] - a[1])[0][0]
        : 'N/A';

    const newStats = {
      totalLookups: history.length,
      uniqueNetworks: uniqueOrgs.size,
      avgIPsPerBlock: avgIPs,
      topOrganization: topOrg,
    };

    setStats(newStats);
    localStorage.setItem('ipNetblocksStats', JSON.stringify(newStats));
  };

  const handleLookup = async () => {
    if (!ipAddress.trim()) {
      setError('Please enter an IP address');
      return;
    }

    setIsLoading(true);
    setError(null);
    setResult(null);

    try {
      const response = await fetch(`/api/tools/ip-netblocks?ip=${encodeURIComponent(ipAddress)}`);

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `API Error: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();

      if (!data.success) {
        throw new Error(data.error || 'Failed to lookup IP netblock');
      }

      // Create netblock data from backend response
      const netblockData: NetblockData = {
        cidr: data.cidr,
        ipRange: data.ipRange,
        ipCount: data.ipCount,
        organization: data.organization,
        country: data.country,
        city: data.city,
        asn: data.asn,
        asnName: data.asnName,
        netName: data.netName,
        netType: data.netType,
        description: data.description,
        allocatedDate: data.allocatedDate,
        lastModified: data.lastModified,
        status: data.status,
        abuse: {
          email: data.abuse.email,
          phone: data.abuse.phone,
        },
      };

      setResult(netblockData);

      // Add to history
      const historyItem: HistoryItem = {
        id: Date.now().toString(),
        ip: ipAddress,
        timestamp: Date.now(),
        result: netblockData,
        status: 'success',
      };

      setHistory(prev => [historyItem, ...prev]);
    } catch (err: any) {
      const errorMessage = err.message || 'Failed to lookup IP netblock';
      setError(errorMessage);

      // Add error to history
      const historyItem: HistoryItem = {
        id: Date.now().toString(),
        ip: ipAddress,
        timestamp: Date.now(),
        result: null,
        status: 'error',
        error: errorMessage,
      };

      setHistory(prev => [historyItem, ...prev]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !isLoading) {
      handleLookup();
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const exportData = () => {
    if (!result) return;
    const dataStr = JSON.stringify(result, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `netblock_${ipAddress}_${Date.now()}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
  };

  const formatTimestamp = (timestamp: number) => {
    const date = new Date(timestamp);
    return date.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <div className="min-h-screen bg-black text-white p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 bg-gradient-to-br from-cyan-500/10 to-blue-500/10 rounded-xl">
              <Network className="w-8 h-8 text-cyan-400" />
            </div>
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-cyan-400 via-blue-400 to-purple-400 bg-clip-text text-transparent">
                IP Netblocks Lookup
              </h1>
              <p className="text-gray-400 mt-1">Discover network information and IP ranges</p>
            </div>
          </div>

          {/* Info Box */}
          <div className="bg-gradient-to-br from-blue-500/5 to-cyan-500/5 border border-blue-500/20 rounded-xl p-4">
            <div className="flex items-start gap-3">
              <Info className="w-5 h-5 text-blue-400 mt-0.5 flex-shrink-0" />
              <div className="text-sm text-gray-300">
                <p className="font-semibold text-blue-400 mb-1">About IP Netblocks</p>
                <p>
                  IP Netblocks provide information about network ranges, including CIDR notation, IP
                  count, organization ownership, ASN details, and abuse contacts. Powered by{' '}
                  <span className="text-cyan-400 font-semibold">IA M AI Global Platform</span>.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Stats Dashboard */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border border-cyan-500/20 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <Search className="w-5 h-5 text-cyan-400" />
              <TrendingUp className="w-4 h-4 text-cyan-400/50" />
            </div>
            <div className="text-2xl font-bold text-cyan-400">{stats?.totalLookups || 0}</div>
            <div className="text-sm text-gray-400 mt-1">Total Lookups</div>
          </div>

          <div className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border border-purple-500/20 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <Network className="w-5 h-5 text-purple-400" />
              <Activity className="w-4 h-4 text-purple-400/50" />
            </div>
            <div className="text-2xl font-bold text-purple-400">{stats?.uniqueNetworks || 0}</div>
            <div className="text-sm text-gray-400 mt-1">Unique Networks</div>
          </div>

          <div className="bg-gradient-to-br from-green-500/10 to-emerald-500/10 border border-green-500/20 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <Server className="w-5 h-5 text-green-400" />
              <Globe className="w-4 h-4 text-green-400/50" />
            </div>
            <div className="text-2xl font-bold text-green-400">
              {stats?.avgIPsPerBlock?.toLocaleString() || '0'}
            </div>
            <div className="text-sm text-gray-400 mt-1">Avg IPs/Block</div>
          </div>

          <div className="bg-gradient-to-br from-orange-500/10 to-yellow-500/10 border border-orange-500/20 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <Building className="w-5 h-5 text-orange-400" />
              <MapPin className="w-4 h-4 text-orange-400/50" />
            </div>
            <div
              className="text-lg font-bold text-orange-400 truncate"
              title={stats?.topOrganization || 'N/A'}
            >
              {stats?.topOrganization?.length > 12
                ? stats.topOrganization.substring(0, 12) + '...'
                : stats?.topOrganization || 'N/A'}
            </div>
            <div className="text-sm text-gray-400 mt-1">Top Organization</div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Search Section */}
            <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
              <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <Search className="w-5 h-5 text-cyan-400" />
                Lookup IP Netblock
              </h2>

              <div className="flex flex-col sm:flex-row gap-3">
                <input
                  type="text"
                  value={ipAddress}
                  onChange={e => setIpAddress(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Enter IP address (e.g., 8.8.8.8)"
                  className="flex-1 px-4 py-3 bg-black border border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500 text-white placeholder-gray-500"
                  disabled={isLoading}
                />
                <button
                  onClick={handleLookup}
                  disabled={isLoading}
                  className="w-full sm:w-auto px-6 py-3 bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 disabled:from-gray-600 disabled:to-gray-700 rounded-lg font-semibold transition-all duration-200 flex items-center justify-center gap-2"
                >
                  {isLoading ? (
                    <>
                      <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      Searching...
                    </>
                  ) : (
                    <>
                      <Search className="w-5 h-5" />
                      Lookup
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Error Message */}
            {error && (
              <div className="bg-gradient-to-br from-red-500/10 to-pink-500/10 border border-red-500/30 rounded-xl p-4">
                <div className="flex items-center gap-3">
                  <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0" />
                  <div>
                    <p className="text-red-400 font-semibold">Error</p>
                    <p className="text-gray-300 text-sm mt-1">{error}</p>
                  </div>
                </div>
              </div>
            )}

            {/* Result Display */}
            {result && (
              <div className="bg-gray-900 border border-gray-800 rounded-xl p-6 space-y-6">
                {/* Header with Actions */}
                <div className="flex items-center justify-between pb-4 border-b border-gray-800">
                  <h2 className="text-xl font-semibold flex items-center gap-2">
                    <Network className="w-5 h-5 text-cyan-400" />
                    Netblock Information
                  </h2>
                  <div className="flex gap-2">
                    <button
                      onClick={() => copyToClipboard(JSON.stringify(result, null, 2))}
                      className="p-2 bg-gray-800 hover:bg-gray-700 border border-gray-700 rounded-lg transition-colors"
                      title="Copy to clipboard"
                    >
                      <Copy className="w-4 h-4" />
                    </button>
                    <button
                      onClick={exportData}
                      className="p-2 bg-gradient-to-r from-cyan-500/20 to-blue-500/20 hover:from-cyan-500/30 hover:to-blue-500/30 border border-cyan-500/30 rounded-lg transition-colors"
                      title="Export as JSON"
                    >
                      <Download className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Network Details */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* CIDR Block */}
                  <div className="bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border border-cyan-500/20 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-gray-400 text-sm">CIDR Block</span>
                      <button
                        onClick={() => copyToClipboard(result.cidr)}
                        className="text-cyan-400 hover:text-cyan-300"
                      >
                        <Copy className="w-4 h-4" />
                      </button>
                    </div>
                    <div className="text-lg font-mono text-cyan-400">{result.cidr}</div>
                  </div>

                  {/* IP Range */}
                  <div className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border border-purple-500/20 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-gray-400 text-sm">IP Range</span>
                      <button
                        onClick={() => copyToClipboard(result.ipRange)}
                        className="text-purple-400 hover:text-purple-300"
                      >
                        <Copy className="w-4 h-4" />
                      </button>
                    </div>
                    <div className="text-sm font-mono text-purple-400">{result.ipRange}</div>
                  </div>

                  {/* IP Count */}
                  <div className="bg-gradient-to-br from-green-500/10 to-emerald-500/10 border border-green-500/20 rounded-lg p-4">
                    <div className="text-gray-400 text-sm mb-2">Total IP Addresses</div>
                    <div className="text-2xl font-bold text-green-400">
                      {result.ipCount.toLocaleString()}
                    </div>
                  </div>

                  {/* ASN */}
                  <div className="bg-gradient-to-br from-orange-500/10 to-yellow-500/10 border border-orange-500/20 rounded-lg p-4">
                    <div className="text-gray-400 text-sm mb-2">Autonomous System Number</div>
                    <div className="text-xl font-mono text-orange-400">{result.asn}</div>
                  </div>
                </div>

                {/* Organization Info */}
                <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-4">
                  <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                    <Building className="w-5 h-5 text-cyan-400" />
                    Organization Details
                  </h3>
                  <div className="space-y-3">
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-sm">
                      <span className="text-gray-400">Organization:</span>
                      <span className="sm:col-span-2 text-white font-medium break-words">
                        {result.organization}
                      </span>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-sm">
                      <span className="text-gray-400">ASN Name:</span>
                      <span className="sm:col-span-2 text-white break-words">{result.asnName}</span>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-sm">
                      <span className="text-gray-400">Network Name:</span>
                      <span className="sm:col-span-2 text-white break-words">{result.netName}</span>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-sm">
                      <span className="text-gray-400">Network Type:</span>
                      <span className="sm:col-span-2">
                        <span className="px-2 py-1 bg-cyan-500/20 text-cyan-400 rounded text-xs font-semibold">
                          {result.netType}
                        </span>
                      </span>
                    </div>
                  </div>
                </div>

                {/* Location Info */}
                <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-4">
                  <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                    <MapPin className="w-5 h-5 text-green-400" />
                    Location
                  </h3>
                  <div className="space-y-3">
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-sm">
                      <span className="text-gray-400">Country:</span>
                      <span className="sm:col-span-2 text-white font-medium break-words">
                        {result.country}
                      </span>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-sm">
                      <span className="text-gray-400">City:</span>
                      <span className="sm:col-span-2 text-white break-words">{result.city}</span>
                    </div>
                  </div>
                </div>

                {/* Dates & Status */}
                <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-4">
                  <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                    <Clock className="w-5 h-5 text-purple-400" />
                    Dates & Status
                  </h3>
                  <div className="space-y-3">
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-sm">
                      <span className="text-gray-400">Allocated:</span>
                      <span className="sm:col-span-2 text-white break-words">
                        {formatDate(result.allocatedDate)}
                      </span>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-sm">
                      <span className="text-gray-400">Last Modified:</span>
                      <span className="sm:col-span-2 text-white break-words">
                        {formatDate(result.lastModified)}
                      </span>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-sm">
                      <span className="text-gray-400">Status:</span>
                      <span className="sm:col-span-2">
                        <span className="px-2 py-1 bg-green-500/20 text-green-400 rounded text-xs font-semibold">
                          {result.status}
                        </span>
                      </span>
                    </div>
                  </div>
                </div>

                {/* Abuse Contacts */}
                <div className="bg-gradient-to-br from-red-500/10 to-pink-500/10 border border-red-500/20 rounded-lg p-4">
                  <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                    <AlertCircle className="w-5 h-5 text-red-400" />
                    Abuse Contacts
                  </h3>
                  <div className="space-y-3">
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-sm">
                      <span className="text-gray-400">Email:</span>
                      <span className="sm:col-span-2 flex flex-wrap items-center gap-2 break-all">
                        <a
                          href={`mailto:${result.abuse.email}`}
                          className="text-cyan-400 hover:text-cyan-300 underline"
                        >
                          {result.abuse.email}
                        </a>
                        <button
                          onClick={() => copyToClipboard(result.abuse.email)}
                          className="text-gray-400 hover:text-white flex-shrink-0"
                        >
                          <Copy className="w-3 h-3" />
                        </button>
                      </span>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-sm">
                      <span className="text-gray-400">Phone:</span>
                      <span className="sm:col-span-2 text-white break-words">
                        {result.abuse.phone}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Description */}
                {result.description && (
                  <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-4">
                    <h3 className="text-sm font-semibold text-gray-400 mb-2">Description</h3>
                    <p className="text-white text-sm leading-relaxed">{result.description}</p>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* History Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-gray-900 border border-gray-800 rounded-xl p-6 sticky top-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold flex items-center gap-2">
                  <Clock className="w-5 h-5 text-cyan-400" />
                  Recent Lookups
                </h2>
                <button
                  onClick={() => setShowHistory(!showHistory)}
                  className="text-sm text-cyan-400 hover:text-cyan-300"
                >
                  {showHistory ? 'Hide' : 'Show'}
                </button>
              </div>

              {showHistory && (
                <div className="space-y-3 max-h-[600px] overflow-y-auto custom-scrollbar">
                  {history.length === 0 ? (
                    <p className="text-gray-500 text-sm text-center py-8">No lookup history yet</p>
                  ) : (
                    history.map(item => (
                      <div
                        key={item.id}
                        onClick={() => item.status === 'success' && setIpAddress(item.ip)}
                        className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                          item.status === 'success'
                            ? 'bg-gray-800/50 border-gray-700 hover:bg-gray-800 hover:border-cyan-500/30'
                            : 'bg-red-500/5 border-red-500/20 hover:bg-red-500/10'
                        }`}
                      >
                        <div className="flex items-start justify-between mb-2">
                          <span className="font-mono text-sm text-white">{item.ip}</span>
                          {item.status === 'success' ? (
                            <span className="text-xs text-green-400">✓</span>
                          ) : (
                            <span className="text-xs text-red-400">✗</span>
                          )}
                        </div>
                        {item.status === 'success' && item.result ? (
                          <>
                            <div className="text-xs text-gray-400 mb-1">
                              {item.result.organization}
                            </div>
                            <div className="text-xs text-cyan-400 font-mono">
                              {item.result.cidr}
                            </div>
                          </>
                        ) : (
                          <div className="text-xs text-red-400">{item.error}</div>
                        )}
                        <div className="text-xs text-gray-500 mt-2">
                          {formatTimestamp(item.timestamp)}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Custom Scrollbar Styles */}
      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: #1f2937;
          border-radius: 3px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #4b5563;
          border-radius: 3px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: #6b7280;
        }
      `}</style>
    </div>
  );
};

export default IPNetblocksPage;
