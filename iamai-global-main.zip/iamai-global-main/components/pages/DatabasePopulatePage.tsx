import React, { useState } from 'react';
import type { Page } from '../../App';

interface DatabasePopulatePageProps {
  onNavigate: (page: Page) => void;
}

const DatabasePopulatePage: React.FC<DatabasePopulatePageProps> = ({ onNavigate }) => {
  const [selectedTemplate, setSelectedTemplate] = useState<string>('');
  const [customSchema, setCustomSchema] = useState<string>('');
  const [recordCount, setRecordCount] = useState<number>(100);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [generatedData, setGeneratedData] = useState<string>('');

  const templates = [
    {
      id: 'users',
      name: 'Users Database',
      description: 'Generate sample user data with profiles, emails, and preferences',
      schema: `{
  "name": "string",
  "email": "string",
  "age": "number",
  "country": "string",
  "preferences": {
    "theme": "string",
    "notifications": "boolean"
  }
}`
    },
    {
      id: 'products',
      name: 'E-commerce Products',
      description: 'Generate product catalog with prices, categories, and descriptions',
      schema: `{
  "name": "string",
  "price": "number",
  "category": "string",
  "description": "string",
  "inStock": "boolean",
  "rating": "number"
}`
    },
    {
      id: 'blog-posts',
      name: 'Blog Posts',
      description: 'Generate blog content with titles, content, and metadata',
      schema: `{
  "title": "string",
  "content": "string",
  "author": "string",
  "publishedAt": "date",
  "tags": "array",
  "views": "number"
}`
    },
    {
      id: 'analytics',
      name: 'Analytics Data',
      description: 'Generate website analytics data with page views and user behavior',
      schema: `{
  "page": "string",
  "userId": "string",
  "timestamp": "date",
  "duration": "number",
  "device": "string",
  "location": "string"
}`
    }
  ];

  const handleGenerate = async () => {
    setIsGenerating(true);
    // Simulate API call to generate data
    setTimeout(() => {
      const mockData = generateMockData(selectedTemplate || 'custom', recordCount);
      setGeneratedData(JSON.stringify(mockData, null, 2));
      setIsGenerating(false);
    }, 2000);
  };

  const generateMockData = (template: string, count: number) => {
    const data = [];
    for (let i = 0; i < count; i++) {
      switch (template) {
        case 'users':
          data.push({
            name: `User ${i + 1}`,
            email: `user${i + 1}@example.com`,
            age: Math.floor(Math.random() * 60) + 18,
            country: ['USA', 'UK', 'Canada', 'Australia', 'Germany'][Math.floor(Math.random() * 5)],
            preferences: {
              theme: Math.random() > 0.5 ? 'dark' : 'light',
              notifications: Math.random() > 0.5
            }
          });
          break;
        case 'products':
          data.push({
            name: `Product ${i + 1}`,
            price: Math.floor(Math.random() * 500) + 10,
            category: ['Electronics', 'Clothing', 'Books', 'Home', 'Sports'][Math.floor(Math.random() * 5)],
            description: `This is a sample description for product ${i + 1}`,
            inStock: Math.random() > 0.3,
            rating: Math.floor(Math.random() * 5) + 1
          });
          break;
        case 'blog-posts':
          data.push({
            title: `Blog Post ${i + 1}`,
            content: `This is the content for blog post ${i + 1}. It contains sample text that would typically be much longer in a real blog post.`,
            author: `Author ${Math.floor(Math.random() * 10) + 1}`,
            publishedAt: new Date(Date.now() - Math.random() * 365 * 24 * 60 * 60 * 1000).toISOString(),
            tags: ['sample', 'data', 'generated'],
            views: Math.floor(Math.random() * 10000)
          });
          break;
        case 'analytics':
          data.push({
            page: `/page${Math.floor(Math.random() * 10) + 1}`,
            userId: `user_${Math.floor(Math.random() * 1000)}`,
            timestamp: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toISOString(),
            duration: Math.floor(Math.random() * 300) + 10,
            device: ['desktop', 'mobile', 'tablet'][Math.floor(Math.random() * 3)],
            location: ['New York', 'London', 'Tokyo', 'Paris', 'Sydney'][Math.floor(Math.random() * 5)]
          });
          break;
        default:
          data.push({ id: i + 1, data: `Sample record ${i + 1}` });
      }
    }
    return data;
  };

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <div className="bg-gradient-to-r from-gray-900 to-black py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-bold mb-6">
            Database Population Service
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Generate realistic sample data for your databases. Perfect for testing,
            development, and demonstration purposes.
          </p>
          <button
            onClick={() => onNavigate('home')}
            className="mt-6 bg-cyan-500 hover:bg-cyan-600 text-white px-6 py-3 rounded-lg transition-colors"
          >
            ← Back to Home
          </button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid lg:grid-cols-2 gap-12">
          {/* Configuration Panel */}
          <div className="space-y-8">
            <div>
              <h2 className="text-2xl font-bold mb-6">Configuration</h2>

              {/* Template Selection */}
              <div className="mb-6">
                <label className="block text-sm font-medium mb-3">Choose Template</label>
                <div className="grid gap-3">
                  {templates.map((template) => (
                    <div
                      key={template.id}
                      onClick={() => {
                        setSelectedTemplate(template.id);
                        setCustomSchema(template.schema);
                      }}
                      className={`p-4 border rounded-lg cursor-pointer transition-all ${
                        selectedTemplate === template.id
                          ? 'border-cyan-500 bg-cyan-500/10'
                          : 'border-gray-700 hover:border-gray-600'
                      }`}
                    >
                      <h3 className="font-semibold mb-1">{template.name}</h3>
                      <p className="text-sm text-gray-400">{template.description}</p>
                    </div>
                  ))}
                  <div
                    onClick={() => {
                      setSelectedTemplate('custom');
                      setCustomSchema('');
                    }}
                    className={`p-4 border rounded-lg cursor-pointer transition-all ${
                      selectedTemplate === 'custom'
                        ? 'border-cyan-500 bg-cyan-500/10'
                        : 'border-gray-700 hover:border-gray-600'
                    }`}
                  >
                    <h3 className="font-semibold mb-1">Custom Schema</h3>
                    <p className="text-sm text-gray-400">Define your own data structure</p>
                  </div>
                </div>
              </div>

              {/* Record Count */}
              <div className="mb-6">
                <label className="block text-sm font-medium mb-3">
                  Number of Records: {recordCount}
                </label>
                <input
                  type="range"
                  min="10"
                  max="1000"
                  value={recordCount}
                  onChange={(e) => setRecordCount(Number(e.target.value))}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-gray-400 mt-1">
                  <span>10</span>
                  <span>1000</span>
                </div>
              </div>

              {/* Custom Schema */}
              {selectedTemplate === 'custom' && (
                <div className="mb-6">
                  <label className="block text-sm font-medium mb-3">JSON Schema</label>
                  <textarea
                    value={customSchema}
                    onChange={(e) => setCustomSchema(e.target.value)}
                    placeholder='{"name": "string", "email": "string", "age": "number"}'
                    className="w-full h-32 bg-gray-800 border border-gray-700 rounded-lg p-3 text-sm font-mono"
                  />
                </div>
              )}

              {/* Generate Button */}
              <button
                onClick={handleGenerate}
                disabled={isGenerating || !selectedTemplate}
                className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 disabled:from-gray-600 disabled:to-gray-700 text-white font-semibold py-4 px-6 rounded-lg transition-all duration-300 disabled:cursor-not-allowed"
              >
                {isGenerating ? (
                  <div className="flex items-center justify-center">
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                    Generating...
                  </div>
                ) : (
                  'Generate Sample Data'
                )}
              </button>
            </div>
          </div>

          {/* Results Panel */}
          <div>
            <h2 className="text-2xl font-bold mb-6">Generated Data</h2>
            {generatedData ? (
              <div className="bg-gray-900 border border-gray-700 rounded-lg p-4">
                <div className="flex justify-between items-center mb-4">
                  <span className="text-sm text-gray-400">
                    {recordCount} records generated
                  </span>
                  <button
                    onClick={() => navigator.clipboard.writeText(generatedData)}
                    className="text-cyan-400 hover:text-cyan-300 text-sm"
                  >
                    Copy JSON
                  </button>
                </div>
                <pre className="text-xs text-gray-300 overflow-auto max-h-96">
                  {generatedData}
                </pre>
              </div>
            ) : (
              <div className="bg-gray-900 border border-gray-700 rounded-lg p-8 text-center">
                <div className="text-gray-500 mb-4">
                  <svg className="w-12 h-12 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                </div>
                <p className="text-gray-400">
                  Select a template and click "Generate Sample Data" to see results
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Features */}
        <div className="mt-16 grid md:grid-cols-3 gap-8">
          <div className="text-center">
            <div className="w-12 h-12 bg-cyan-500/20 rounded-lg flex items-center justify-center mx-auto mb-4">
              <svg className="w-6 h-6 text-cyan-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <h3 className="text-lg font-semibold mb-2">Realistic Data</h3>
            <p className="text-gray-400 text-sm">
              Generate authentic-looking data that mimics real-world scenarios
            </p>
          </div>

          <div className="text-center">
            <div className="w-12 h-12 bg-cyan-500/20 rounded-lg flex items-center justify-center mx-auto mb-4">
              <svg className="w-6 h-6 text-cyan-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
            </div>
            <h3 className="text-lg font-semibold mb-2">Fast Generation</h3>
            <p className="text-gray-400 text-sm">
              Create thousands of records in seconds with optimized algorithms
            </p>
          </div>

          <div className="text-center">
            <div className="w-12 h-12 bg-cyan-500/20 rounded-lg flex items-center justify-center mx-auto mb-4">
              <svg className="w-6 h-6 text-cyan-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 5a1 1 0 011-1h14a1 1 0 011 1v2a1 1 0 01-1 1H5a1 1 0 01-1-1V5zM4 13a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H5a1 1 0 01-1-1v-6zM16 13a1 1 0 011-1h2a1 1 0 011 1v6a1 1 0 01-1 1h-2a1 1 0 01-1-1v-6z" />
              </svg>
            </div>
            <h3 className="text-lg font-semibold mb-2">Multiple Formats</h3>
            <p className="text-gray-400 text-sm">
              Export data in JSON, CSV, and SQL formats for any database system
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DatabasePopulatePage;