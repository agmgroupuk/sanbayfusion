import React, { useEffect, useState } from 'react';
import {
  ArrowLeft,
  Activity,
  Play,
  Square,
  Plus,
  Trash2,
  TrendingUp,
  Clock,
  Zap,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Download,
  Copy,
  Check,
  BarChart3,
  Globe,
  Settings,
} from 'lucide-react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from 'recharts';
import { getSocket } from '../../services/socket';

interface Props {
  onNavigate?: (page: string) => void;
}

type UptimeUpdate = {
  url: string;
  status: number;
  ok: boolean;
  durationMs: number;
  timestamp: string;
  error?: string;
};

interface MonitorTarget {
  id: string;
  url: string;
  nickname?: string;
  enabled: boolean;
}

interface MonitorStats {
  url: string;
  totalChecks: number;
  successfulChecks: number;
  failedChecks: number;
  uptime: number;
  avgResponseTime: number;
  lastStatus?: number;
  lastCheck?: string;
  currentStatus: 'up' | 'down' | 'checking';
}

interface IncidentEntry {
  id: string;
  url: string;
  type: 'down' | 'slow' | 'recovered';
  timestamp: number;
  status?: number;
  responseTime?: number;
  error?: string;
}

interface HistoryEntry {
  id: string;
  url: string;
  totalChecks: number;
  uptime: number;
  avgResponseTime: number;
  duration: number;
  timestamp: number;
}

const UptimeMonitorPage: React.FC<Props> = ({ onNavigate }) => {
  const [targets, setTargets] = useState<MonitorTarget[]>([]);
  const [newUrl, setNewUrl] = useState('');
  const [newNickname, setNewNickname] = useState('');
  const [intervalMs, setIntervalMs] = useState(60000); // Default 1 minute
  const [slowThreshold, setSlowThreshold] = useState(3000); // Default 3 seconds
  const [running, setRunning] = useState(false);
  const [events, setEvents] = useState<UptimeUpdate[]>([]);
  const [stats, setStats] = useState<Map<string, MonitorStats>>(new Map());
  const [incidents, setIncidents] = useState<IncidentEntry[]>([]);
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [startTime, setStartTime] = useState<number | null>(null);
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'incidents' | 'history' | 'settings'>(
    'dashboard'
  );

  // Load saved configuration
  useEffect(() => {
    const storedTargets = toolDataService.getUptimeTargets();
    const storedHistory = toolDataService.getUptimeHistory();

    if (storedTargets.length > 0) {
      setTargets(storedTargets);
    }

    if (storedHistory.length > 0) {
      setUptimeHistory(storedHistory);
    }
  }, []);

  // WebSocket listeners
  useEffect(() => {
    const socket = getSocket();

    const onUpdate = (update: UptimeUpdate) => {
      setEvents(prev => [update, ...prev].slice(0, 500));

      // Update stats
      setStats(prevStats => {
        const newStats = new Map(prevStats);
        const existing = newStats.get(update.url) || {
          url: update.url,
          totalChecks: 0,
          successfulChecks: 0,
          failedChecks: 0,
          uptime: 0,
          avgResponseTime: 0,
          currentStatus: 'checking' as const,
        };

        const totalChecks = existing.totalChecks + 1;
        const successfulChecks = update.ok
          ? existing.successfulChecks + 1
          : existing.successfulChecks;
        const failedChecks = update.ok ? existing.failedChecks : existing.failedChecks + 1;
        const uptime = (successfulChecks / totalChecks) * 100;
        const avgResponseTime =
          (existing.avgResponseTime * existing.totalChecks + update.durationMs) / totalChecks;

        newStats.set(update.url, {
          url: update.url,
          totalChecks,
          successfulChecks,
          failedChecks,
          uptime,
          avgResponseTime,
          lastStatus: update.status,
          lastCheck: update.timestamp,
          currentStatus: update.ok ? 'up' : 'down',
        });

        return newStats;
      });

      // Check for incidents
      if (!update.ok) {
        const incident: IncidentEntry = {
          id: Date.now().toString(),
          url: update.url,
          type: 'down',
          timestamp: Date.now(),
          status: update.status,
          error: update.error,
        };
        setIncidents(prev => [incident, ...prev].slice(0, 100));
      } else if (update.durationMs > slowThreshold) {
        const incident: IncidentEntry = {
          id: Date.now().toString(),
          url: update.url,
          type: 'slow',
          timestamp: Date.now(),
          status: update.status,
          responseTime: update.durationMs,
        };
        setIncidents(prev => [incident, ...prev].slice(0, 100));
      }
    };

    const onDone = () => {
      setRunning(false);
      saveToHistory();
    };

    socket.on('tools:uptime:update', onUpdate);
    socket.on('tools:uptime:done', onDone);

    return () => {
      socket.off('tools:uptime:update', onUpdate);
      socket.off('tools:uptime:done', onDone);
    };
  }, [slowThreshold]);

  // Add target
  const addTarget = () => {
    if (!newUrl.trim()) return;
    if (targets.length >= 10) {
      alert('Maximum 10 monitoring targets allowed');
      return;
    }

    const target: MonitorTarget = {
      id: Date.now().toString(),
      url: newUrl.trim(),
      nickname: newNickname.trim() || undefined,
      enabled: true,
    };

    const newTargets = [...targets, target];
    setTargets(newTargets);
    toolDataService.saveUptimeTargets(newTargets);
    setNewUrl('');
    setNewNickname('');
  };

  // Remove target
  const removeTarget = (id: string) => {
    const newTargets = targets.filter(t => t.url !== url);
    setTargets(newTargets);
    toolDataService.saveUptimeTargets(newTargets);
  };

  // Toggle target enabled
  const toggleTarget = (id: string) => {
    const newTargets = targets.map(t => (t.id === id ? { ...t, enabled: !t.enabled } : t));
    setTargets(newTargets);
    toolDataService.saveUptimeTargets(newTargets);
  };

  // Start monitoring
  const start = () => {
    const enabledTargets = targets.filter(t => t.enabled);
    if (enabledTargets.length === 0) {
      alert('Please add at least one enabled monitoring target');
      return;
    }

    setEvents([]);
    setStats(new Map());
    setIncidents([]);
    setRunning(true);
    setStartTime(Date.now());

    // Start monitoring each enabled target
    enabledTargets.forEach(target => {
      getSocket().emit('tools:uptime:start', { url: target.url, intervalMs });
    });
  };

  // Stop monitoring
  const stop = () => {
    getSocket().emit('tools:uptime:stop');
    setRunning(false);
  };

  // Save to history
  const saveToHistory = () => {
    if (!startTime || stats.size === 0) return;

    const duration = Date.now() - startTime;
    const entries: HistoryEntry[] = Array.from(stats.values()).map(stat => ({
      id: Date.now().toString() + Math.random(),
      url: stat.url,
      totalChecks: stat.totalChecks,
      uptime: stat.uptime,
      avgResponseTime: stat.avgResponseTime,
      duration,
      timestamp: Date.now(),
    }));

    const newHistory = [...entries, ...history].slice(0, 50);
    setHistory(newHistory);
    toolDataService.saveUptimeHistory(newHistory);
  };

  // Export stats
  const exportStats = () => {
    const data = Array.from(stats.values()).map(stat => ({
      url: stat.url,
      totalChecks: stat.totalChecks,
      successfulChecks: stat.successfulChecks,
      failedChecks: stat.failedChecks,
      uptime: stat.uptime.toFixed(2) + '%',
      avgResponseTime: stat.avgResponseTime.toFixed(0) + 'ms',
      lastStatus: stat.lastStatus,
      lastCheck: stat.lastCheck,
    }));

    const json = JSON.stringify(data, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `uptime-monitor-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Copy summary
  const copySummary = () => {
    const summary = Array.from(stats.values())
      .map(
        stat =>
          `${stat.url}: ${stat.uptime.toFixed(2)}% uptime, ${stat.avgResponseTime.toFixed(0)}ms avg`
      )
      .join('\n');

    navigator.clipboard.writeText(summary);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Clear history
  const clearHistory = () => {
    setHistory([]);
    toolDataService.clearUptimeHistory();
  };

  // Calculate overall stats
  const overallStats = React.useMemo(() => {
    if (stats.size === 0) {
      return { avgUptime: 0, totalChecks: 0, avgResponseTime: 0, activeTargets: 0 };
    }

    const values = Array.from(stats.values());
    const avgUptime = values.reduce((sum, s) => sum + s.uptime, 0) / values.length;
    const totalChecks = values.reduce((sum, s) => sum + s.totalChecks, 0);
    const avgResponseTime = values.reduce((sum, s) => sum + s.avgResponseTime, 0) / values.length;
    const activeTargets = values.filter(s => s.currentStatus === 'up').length;

    return { avgUptime, totalChecks, avgResponseTime, activeTargets };
  }, [stats]);

  // Get chart data
  const chartData = React.useMemo(() => {
    return events
      .slice(0, 50)
      .reverse()
      .map((event, idx) => ({
        time: new Date(event.timestamp).toLocaleTimeString(),
        responseTime: event.durationMs,
        status: event.ok ? 1 : 0,
      }));
  }, [events]);

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <section className="relative overflow-hidden py-12 border-b border-gray-800">
        <div className="absolute inset-0 bg-grid-gray-900 [mask-image:linear-gradient(to_bottom,white_30%,transparent)]"></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-green-500/10 rounded-full blur-3xl"></div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <button
            onClick={() => onNavigate?.('toolbox')}
            className="mb-6 flex items-center gap-2 text-gray-400 hover:text-cyan-400 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" /> Back to Toolbox
          </button>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-3 bg-green-500/20 rounded-lg border border-green-500/30">
                <Activity className="w-6 h-6 text-green-400" />
              </div>
              <div>
                <h1 className="text-3xl md:text-4xl font-bold">Uptime Monitor</h1>
                <p className="text-gray-400 mt-1">
                  Real-time availability tracking & incident management
                </p>
              </div>
            </div>

            {/* Control Buttons */}
            <div className="flex gap-3">
              {!running ? (
                <button
                  onClick={start}
                  disabled={targets.filter(t => t.enabled).length === 0}
                  className="px-6 py-3 rounded-lg bg-gradient-to-r from-green-500 to-emerald-500 text-black font-semibold flex items-center gap-2 hover:shadow-lg hover:shadow-green-500/50 transition disabled:opacity-50"
                >
                  <Play className="w-4 h-4" />
                  Start Monitoring
                </button>
              ) : (
                <button
                  onClick={stop}
                  className="px-6 py-3 rounded-lg bg-gradient-to-r from-red-500 to-orange-500 text-white font-semibold flex items-center gap-2 hover:shadow-lg hover:shadow-red-500/50 transition"
                >
                  <Square className="w-4 h-4" />
                  Stop Monitoring
                </button>
              )}
            </div>
          </div>

          {/* Overall Stats Dashboard */}
          {running && stats.size > 0 && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
              <div className="bg-gray-900/50 border-2 border-green-500/50 rounded-lg p-4">
                <div className="text-gray-400 text-sm mb-1">Average Uptime</div>
                <div className="text-3xl font-bold text-green-400 flex items-center gap-2">
                  {overallStats?.avgUptime?.toFixed(2) || '0.00'}%
                </div>
              </div>
              <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-4">
                <div className="text-gray-400 text-sm mb-1">Active Targets</div>
                <div className="text-2xl font-bold text-cyan-400">
                  {overallStats?.activeTargets || 0}/{stats?.size || 0}
                </div>
              </div>
              <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-4">
                <div className="text-gray-400 text-sm mb-1">Total Checks</div>
                <div className="text-2xl font-bold text-purple-400">
                  {overallStats?.totalChecks || 0}
                </div>
              </div>
              <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-4">
                <div className="text-gray-400 text-sm mb-1">Avg Response</div>
                <div className="text-2xl font-bold text-yellow-400">
                  {overallStats?.avgResponseTime?.toFixed(0) || '0'}ms
                </div>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Main Content */}
      <section className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Tab Navigation */}
          <div className="flex flex-wrap gap-2 mb-6">
            {[
              { id: 'dashboard', label: 'Dashboard', icon: <BarChart3 className="w-4 h-4" /> },
              {
                id: 'incidents',
                label: 'Incidents',
                icon: <AlertTriangle className="w-4 h-4" />,
                count: incidents.length,
              },
              {
                id: 'history',
                label: 'History',
                icon: <Clock className="w-4 h-4" />,
                count: history.length,
              },
              { id: 'settings', label: 'Settings', icon: <Settings className="w-4 h-4" /> },
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-4 py-2 rounded-lg font-semibold transition flex items-center gap-2 ${
                  activeTab === tab.id
                    ? 'bg-gradient-to-r from-green-500 to-emerald-500 text-black'
                    : 'bg-gray-800 text-gray-400 border border-gray-700 hover:border-green-500/50'
                }`}
              >
                {tab.icon}
                {tab.label}
                {tab.count !== undefined && tab.count > 0 && (
                  <span
                    className={`px-2 py-0.5 rounded-full text-xs font-bold ${
                      activeTab === tab.id ? 'bg-black/20' : 'bg-green-500/20 text-green-400'
                    }`}
                  >
                    {tab.count}
                  </span>
                )}
              </button>
            ))}
          </div>

          {/* Dashboard Tab */}
          {activeTab === 'dashboard' && (
            <div className="grid lg:grid-cols-3 gap-6">
              {/* Left Column - Targets & Charts */}
              <div className="lg:col-span-2 space-y-6">
                {/* Target Status Cards */}
                <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-bold flex items-center gap-2">
                      <Globe className="w-5 h-5 text-green-400" />
                      Monitoring Targets ({targets.filter(t => t.enabled).length}/{targets.length})
                    </h3>
                    {stats.size > 0 && (
                      <div className="flex gap-2">
                        <button
                          onClick={copySummary}
                          className="px-3 py-2 bg-gray-800 hover:bg-gray-700 rounded-lg border border-gray-700 transition flex items-center gap-2 text-sm"
                        >
                          {copied ? (
                            <Check className="w-4 h-4 text-green-400" />
                          ) : (
                            <Copy className="w-4 h-4" />
                          )}
                          Copy
                        </button>
                        <button
                          onClick={exportStats}
                          className="px-3 py-2 bg-gray-800 hover:bg-gray-700 rounded-lg border border-gray-700 transition flex items-center gap-2 text-sm"
                        >
                          <Download className="w-4 h-4" />
                          Export
                        </button>
                      </div>
                    )}
                  </div>

                  {targets.length === 0 ? (
                    <div className="text-center py-12 text-gray-400">
                      <Activity className="w-12 h-12 mx-auto mb-4 opacity-50" />
                      <p>No monitoring targets configured</p>
                      <p className="text-sm mt-2">Add targets in the Settings tab</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {targets.map(target => {
                        const targetStats = stats.get(target.url);
                        return (
                          <div
                            key={target.id}
                            className={`p-4 rounded-xl border-2 ${
                              !target.enabled
                                ? 'border-gray-700 bg-gray-800/30'
                                : targetStats?.currentStatus === 'up'
                                  ? 'border-green-500/50 bg-green-500/10'
                                  : targetStats?.currentStatus === 'down'
                                    ? 'border-red-500/50 bg-red-500/10'
                                    : 'border-gray-700 bg-gray-800/50'
                            }`}
                          >
                            <div className="flex items-start justify-between mb-3">
                              <div className="flex-1">
                                <div className="flex items-center gap-2 mb-1">
                                  {targetStats?.currentStatus === 'up' ? (
                                    <CheckCircle className="w-5 h-5 text-green-400" />
                                  ) : targetStats?.currentStatus === 'down' ? (
                                    <XCircle className="w-5 h-5 text-red-400" />
                                  ) : (
                                    <Activity className="w-5 h-5 text-gray-400 animate-pulse" />
                                  )}
                                  <span className="font-bold text-white">
                                    {target.nickname || 'Unnamed'}
                                  </span>
                                  {!target.enabled && (
                                    <span className="px-2 py-0.5 bg-gray-700 text-gray-400 text-xs rounded-full">
                                      Disabled
                                    </span>
                                  )}
                                </div>
                                <div className="text-xs text-gray-400 font-mono break-all">
                                  {target.url}
                                </div>
                              </div>
                            </div>

                            {targetStats && (
                              <div className="grid grid-cols-4 gap-3 text-center">
                                <div className="p-2 bg-gray-800/50 rounded">
                                  <div className="text-xs text-gray-400 mb-1">Uptime</div>
                                  <div
                                    className={`text-sm font-bold ${targetStats.uptime >= 99 ? 'text-green-400' : targetStats.uptime >= 95 ? 'text-yellow-400' : 'text-red-400'}`}
                                  >
                                    {targetStats.uptime.toFixed(2)}%
                                  </div>
                                </div>
                                <div className="p-2 bg-gray-800/50 rounded">
                                  <div className="text-xs text-gray-400 mb-1">Checks</div>
                                  <div className="text-sm font-bold text-cyan-400">
                                    {targetStats?.totalChecks || 0}
                                  </div>
                                </div>
                                <div className="p-2 bg-gray-800/50 rounded">
                                  <div className="text-xs text-gray-400 mb-1">Avg Time</div>
                                  <div className="text-sm font-bold text-purple-400">
                                    {targetStats?.avgResponseTime?.toFixed(0) || '0'}ms
                                  </div>
                                </div>
                                <div className="p-2 bg-gray-800/50 rounded">
                                  <div className="text-xs text-gray-400 mb-1">Status</div>
                                  <div className="text-sm font-bold text-green-400">
                                    {targetStats.lastStatus || '-'}
                                  </div>
                                </div>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>

                {/* Response Time Chart */}
                {running && chartData.length > 0 && (
                  <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
                    <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                      <TrendingUp className="w-5 h-5 text-cyan-400" />
                      Response Time Trend
                    </h3>
                    <ResponsiveContainer width="100%" height={300}>
                      <LineChart data={chartData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                        <XAxis dataKey="time" stroke="#9CA3AF" fontSize={12} />
                        <YAxis
                          stroke="#9CA3AF"
                          fontSize={12}
                          label={{
                            value: 'Response Time (ms)',
                            angle: -90,
                            position: 'insideLeft',
                            fill: '#9CA3AF',
                          }}
                        />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: '#1F2937',
                            border: '1px solid #374151',
                            borderRadius: '8px',
                          }}
                          labelStyle={{ color: '#9CA3AF' }}
                        />
                        <Legend />
                        <Line
                          type="monotone"
                          dataKey="responseTime"
                          stroke="#06B6D4"
                          strokeWidth={2}
                          dot={{ fill: '#06B6D4', r: 3 }}
                          name="Response Time"
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                )}

                {/* Recent Events */}
                {events.length > 0 && (
                  <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
                    <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                      <Clock className="w-5 h-5 text-purple-400" />
                      Recent Events ({events.length})
                    </h3>
                    <div className="space-y-2 max-h-96 overflow-y-auto">
                      {events.slice(0, 20).map((event, idx) => (
                        <div
                          key={idx}
                          className={`p-3 rounded-lg border ${
                            event.ok
                              ? 'border-green-500/30 bg-green-500/10'
                              : 'border-red-500/30 bg-red-500/10'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3 flex-1">
                              {event.ok ? (
                                <CheckCircle className="w-4 h-4 text-green-400" />
                              ) : (
                                <XCircle className="w-4 h-4 text-red-400" />
                              )}
                              <div className="flex-1">
                                <div className="text-sm font-mono text-cyan-400 truncate">
                                  {event.url}
                                </div>
                                {event.error && (
                                  <div className="text-xs text-red-400 mt-1">{event.error}</div>
                                )}
                              </div>
                            </div>
                            <div className="flex items-center gap-4 text-sm">
                              <span
                                className={`font-bold ${event.ok ? 'text-green-400' : 'text-red-400'}`}
                              >
                                {event.status}
                              </span>
                              <span className="text-purple-400 font-mono">
                                {event.durationMs}ms
                              </span>
                              <span className="text-gray-400 text-xs">
                                {new Date(event.timestamp).toLocaleTimeString()}
                              </span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Right Column - Quick Stats */}
              <div className="space-y-6">
                {/* Monitoring Status */}
                <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
                  <h3 className="text-lg font-bold mb-4">Status</h3>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-400">Monitor Status</span>
                      <span
                        className={`px-3 py-1 rounded-full text-sm font-bold ${
                          running ? 'bg-green-500/20 text-green-400' : 'bg-gray-700 text-gray-400'
                        }`}
                      >
                        {running ? 'Active' : 'Stopped'}
                      </span>
                    </div>
                    {startTime && running && (
                      <div className="flex items-center justify-between">
                        <span className="text-gray-400">Running For</span>
                        <span className="text-white font-mono">
                          {Math.floor((Date.now() - startTime) / 60000)}m{' '}
                          {Math.floor(((Date.now() - startTime) % 60000) / 1000)}s
                        </span>
                      </div>
                    )}
                    <div className="flex items-center justify-between">
                      <span className="text-gray-400">Check Interval</span>
                      <span className="text-cyan-400 font-mono">{intervalMs / 1000}s</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-400">Slow Threshold</span>
                      <span className="text-yellow-400 font-mono">{slowThreshold}ms</span>
                    </div>
                  </div>
                </div>

                {/* Best Practices */}
                <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
                  <h3 className="text-lg font-bold mb-4">Monitoring Tips</h3>
                  <div className="space-y-3 text-sm text-gray-400">
                    <div>
                      <strong className="text-green-400">✓</strong> Check interval 30s-5min
                    </div>
                    <div>
                      <strong className="text-green-400">✓</strong> Monitor critical endpoints
                    </div>
                    <div>
                      <strong className="text-green-400">✓</strong> Set slow threshold 3-5s
                    </div>
                    <div>
                      <strong className="text-green-400">✓</strong> Review incidents regularly
                    </div>
                    <div>
                      <strong className="text-red-400">✗</strong> Don't check too frequently
                    </div>
                    <div>
                      <strong className="text-red-400">✗</strong> Don't ignore slow responses
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Incidents Tab */}
          {activeTab === 'incidents' && (
            <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-bold flex items-center gap-2">
                  <AlertTriangle className="w-5 h-5 text-red-400" />
                  Incident Log ({incidents.length})
                </h3>
                <button
                  onClick={() => setIncidents([])}
                  className="text-sm text-gray-400 hover:text-red-400 transition"
                >
                  Clear All
                </button>
              </div>

              {incidents.length === 0 ? (
                <div className="text-center py-12 text-gray-400">
                  <CheckCircle className="w-12 h-12 mx-auto mb-4 opacity-50 text-green-400" />
                  <p>No incidents detected</p>
                  <p className="text-sm mt-2">All systems operational</p>
                </div>
              ) : (
                <div className="space-y-3 max-h-[600px] overflow-y-auto">
                  {incidents.map(incident => (
                    <div
                      key={incident.id}
                      className={`p-4 rounded-lg border-2 ${
                        incident.type === 'down'
                          ? 'border-red-500/50 bg-red-500/10'
                          : 'border-yellow-500/50 bg-yellow-500/10'
                      }`}
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center gap-2">
                          {incident.type === 'down' ? (
                            <XCircle className="w-5 h-5 text-red-400" />
                          ) : (
                            <Zap className="w-5 h-5 text-yellow-400" />
                          )}
                          <span
                            className={`px-3 py-1 rounded-full text-xs font-bold ${
                              incident.type === 'down'
                                ? 'bg-red-500/20 text-red-400'
                                : 'bg-yellow-500/20 text-yellow-400'
                            }`}
                          >
                            {incident.type === 'down' ? 'DOWN' : 'SLOW RESPONSE'}
                          </span>
                        </div>
                        <span className="text-xs text-gray-400">
                          {new Date(incident.timestamp).toLocaleString()}
                        </span>
                      </div>
                      <div className="text-sm font-mono text-cyan-400 mb-2">{incident.url}</div>
                      {incident.error && (
                        <div className="text-sm text-red-400 mt-2">{incident.error}</div>
                      )}
                      {incident.responseTime && (
                        <div className="text-sm text-yellow-400 mt-2">
                          Response time: {incident.responseTime}ms (threshold: {slowThreshold}ms)
                        </div>
                      )}
                      {incident.status && (
                        <div className="text-sm text-gray-400 mt-2">Status: {incident.status}</div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* History Tab */}
          {activeTab === 'history' && (
            <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-bold flex items-center gap-2">
                  <Clock className="w-5 h-5 text-cyan-400" />
                  Monitoring History ({history.length})
                </h3>
                <button
                  onClick={clearHistory}
                  className="text-sm text-gray-400 hover:text-red-400 transition flex items-center gap-1"
                >
                  <Trash2 className="w-3 h-3" />
                  Clear
                </button>
              </div>

              {history.length === 0 ? (
                <div className="text-center py-12 text-gray-400">
                  <Clock className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>No monitoring history</p>
                  <p className="text-sm mt-2">History is saved after each monitoring session</p>
                </div>
              ) : (
                <div className="space-y-2 max-h-[600px] overflow-y-auto">
                  {history.map(entry => (
                    <div
                      key={entry.id}
                      className="p-4 bg-gray-800/50 border border-gray-700 rounded-lg hover:border-cyan-500/50 transition"
                    >
                      <div className="flex items-center justify-between mb-3">
                        <div className="text-sm font-mono text-cyan-400 truncate flex-1">
                          {entry.url}
                        </div>
                        <div className="text-xs text-gray-400">
                          {new Date(entry.timestamp).toLocaleString()}
                        </div>
                      </div>
                      <div className="grid grid-cols-4 gap-3 text-center">
                        <div className="p-2 bg-gray-900/50 rounded">
                          <div className="text-xs text-gray-400 mb-1">Uptime</div>
                          <div
                            className={`text-sm font-bold ${
                              entry.uptime >= 99
                                ? 'text-green-400'
                                : entry.uptime >= 95
                                  ? 'text-yellow-400'
                                  : 'text-red-400'
                            }`}
                          >
                            {entry.uptime.toFixed(2)}%
                          </div>
                        </div>
                        <div className="p-2 bg-gray-900/50 rounded">
                          <div className="text-xs text-gray-400 mb-1">Checks</div>
                          <div className="text-sm font-bold text-cyan-400">{entry.totalChecks}</div>
                        </div>
                        <div className="p-2 bg-gray-900/50 rounded">
                          <div className="text-xs text-gray-400 mb-1">Avg Time</div>
                          <div className="text-sm font-bold text-purple-400">
                            {entry.avgResponseTime.toFixed(0)}ms
                          </div>
                        </div>
                        <div className="p-2 bg-gray-900/50 rounded">
                          <div className="text-xs text-gray-400 mb-1">Duration</div>
                          <div className="text-sm font-bold text-yellow-400">
                            {Math.floor(entry.duration / 60000)}m
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Settings Tab */}
          {activeTab === 'settings' && (
            <div className="grid lg:grid-cols-2 gap-6">
              {/* Add Target */}
              <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
                <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                  <Plus className="w-5 h-5 text-green-400" />
                  Add Monitoring Target
                </h3>

                <div className="space-y-4">
                  <div>
                    <label className="text-sm text-gray-400 mb-2 block">URL (Required)</label>
                    <input
                      className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-green-500 transition"
                      placeholder="https://example.com"
                      value={newUrl}
                      onChange={e => setNewUrl(e.target.value)}
                    />
                  </div>

                  <div>
                    <label className="text-sm text-gray-400 mb-2 block">Nickname (Optional)</label>
                    <input
                      className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-green-500 transition"
                      placeholder="My Website"
                      value={newNickname}
                      onChange={e => setNewNickname(e.target.value)}
                    />
                  </div>

                  <button
                    onClick={addTarget}
                    disabled={!newUrl.trim() || targets.length >= 10}
                    className="w-full px-4 py-3 rounded-lg bg-gradient-to-r from-green-500 to-emerald-500 text-black font-semibold flex items-center justify-center gap-2 hover:shadow-lg hover:shadow-green-500/50 transition disabled:opacity-50"
                  >
                    <Plus className="w-4 h-4" />
                    Add Target ({targets.length}/10)
                  </button>

                  {targets.length >= 10 && (
                    <p className="text-sm text-yellow-400">Maximum 10 targets reached</p>
                  )}
                </div>
              </div>

              {/* Configure Settings */}
              <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
                <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                  <Settings className="w-5 h-5 text-cyan-400" />
                  Monitor Configuration
                </h3>

                <div className="space-y-4">
                  <div>
                    <label className="text-sm text-gray-400 mb-2 block flex items-center justify-between">
                      Check Interval
                      <span className="text-cyan-400 font-mono">{intervalMs / 1000}s</span>
                    </label>
                    <input
                      type="range"
                      min="10000"
                      max="300000"
                      step="10000"
                      value={intervalMs}
                      onChange={e => setIntervalMs(parseInt(e.target.value))}
                      className="w-full"
                    />
                    <div className="flex justify-between text-xs text-gray-500 mt-1">
                      <span>10s</span>
                      <span>5min</span>
                    </div>
                  </div>

                  <div>
                    <label className="text-sm text-gray-400 mb-2 block flex items-center justify-between">
                      Slow Response Threshold
                      <span className="text-yellow-400 font-mono">{slowThreshold}ms</span>
                    </label>
                    <input
                      type="range"
                      min="1000"
                      max="10000"
                      step="500"
                      value={slowThreshold}
                      onChange={e => setSlowThreshold(parseInt(e.target.value))}
                      className="w-full"
                    />
                    <div className="flex justify-between text-xs text-gray-500 mt-1">
                      <span>1s</span>
                      <span>10s</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Manage Targets */}
              <div className="lg:col-span-2 bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
                <h3 className="text-lg font-bold mb-4">Manage Targets</h3>

                {targets.length === 0 ? (
                  <div className="text-center py-8 text-gray-400">
                    <Globe className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>No targets configured</p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {targets.map(target => (
                      <div
                        key={target.id}
                        className="flex items-center justify-between p-4 bg-gray-800/50 border border-gray-700 rounded-lg"
                      >
                        <div className="flex items-center gap-3 flex-1">
                          <button
                            onClick={() => toggleTarget(target.id)}
                            className={`p-2 rounded-lg border-2 transition ${
                              target.enabled
                                ? 'border-green-500 bg-green-500/20'
                                : 'border-gray-600 bg-gray-700/20'
                            }`}
                          >
                            {target.enabled ? (
                              <CheckCircle className="w-4 h-4 text-green-400" />
                            ) : (
                              <XCircle className="w-4 h-4 text-gray-400" />
                            )}
                          </button>
                          <div className="flex-1">
                            <div className="font-semibold text-white">
                              {target.nickname || 'Unnamed'}
                            </div>
                            <div className="text-sm text-gray-400 font-mono truncate">
                              {target.url}
                            </div>
                          </div>
                        </div>
                        <button
                          onClick={() => removeTarget(target.id)}
                          className="p-2 text-red-400 hover:bg-red-500/20 rounded-lg transition"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  );
};

export default UptimeMonitorPage;
