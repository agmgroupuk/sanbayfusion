import React, { useState, useEffect } from 'react';
import { Send, Plus, Trash2, Copy, Clock, ArrowLeft, Save, Folder, Download, Upload, PlayCircle, CheckCircle, XCircle, Code, Settings, History } from 'lucide-react';

const HTTP_METHODS = ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD', 'OPTIONS'];

interface Header {
  id: string;
  key: string;
  value: string;
  enabled: boolean;
}

interface TestAssertion {
  id: string;
  type: 'status' | 'header' | 'body' | 'time';
  field?: string;
  operator: '==' | '!=' | '>' | '<' | 'contains' | 'exists';
  value: string;
  enabled: boolean;
}

interface APIRequest {
  id: string;
  name: string;
  method: string;
  url: string;
  headers: Header[];
  body: string;
  tests: TestAssertion[];
  collectionId?: string;
}

interface Collection {
  id: string;
  name: string;
  description?: string;
  requests: string[]; // Request IDs
}

interface EnvVariable {
  id: string;
  key: string;
  value: string;
  enabled: boolean;
}

interface Environment {
  id: string;
  name: string;
  variables: EnvVariable[];
}

interface HistoryEntry {
  id: string;
  requestId?: string;
  method: string;
  url: string;
  status?: number;
  responseTime?: number;
  success: boolean;
  timestamp: number;
  testResults?: TestResult[];
}

interface TestResult {
  assertion: TestAssertion;
  passed: boolean;
  actual?: any;
  message: string;
}

interface APITesterPageProps {
  onNavigate?: (page: string) => void;
}

const APITesterPage: React.FC<APITesterPageProps> = ({ onNavigate }) => {
  // Current Request State
  const [currentRequest, setCurrentRequest] = useState<APIRequest>({
    id: 'new',
    name: 'Untitled Request',
    method: 'GET',
    url: 'https://api.example.com/endpoint',
    headers: [{ id: '1', key: 'Content-Type', value: 'application/json', enabled: true }],
    body: '{\n  "key": "value"\n}',
    tests: []
  });

  // Collections & Saved Requests
  const [collections, setCollections] = useState<Collection[]>([]);
  const [savedRequests, setSavedRequests] = useState<APIRequest[]>([]);
  
  // Environments
  const [environments, setEnvironments] = useState<Environment[]>([]);
  const [activeEnvId, setActiveEnvId] = useState<string | null>(null);

  // Response & Execution
  const [response, setResponse] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [responseTime, setResponseTime] = useState<number | null>(null);
  const [testResults, setTestResults] = useState<TestResult[]>([]);

  // History
  const [history, setHistory] = useState<HistoryEntry[]>([]);

  // UI State
  const [mainTab, setMainTab] = useState<'request' | 'collections' | 'environment' | 'history'>('request');
  const [requestTab, setRequestTab] = useState<'body' | 'headers' | 'tests'>('body');
  const [responseTab, setResponseTab] = useState<'body' | 'headers' | 'tests'>('body');

  // Modals
  const [showSaveModal, setShowSaveModal] = useState(false);
  const [showNewCollectionModal, setShowNewCollectionModal] = useState(false);
  const [newCollectionName, setNewCollectionName] = useState('');
  const [newRequestName, setNewRequestName] = useState('');
  const [selectedCollectionId, setSelectedCollectionId] = useState<string>('');

  // Load saved data
  useEffect(() => {
    const storedCollections = toolDataService.getAPICollections();
    const storedRequests = toolDataService.getAPIRequests();
    const storedEnvs = toolDataService.getAPIEnvironments();
    const storedHistory = toolDataService.getAPIHistory();
    const storedActiveEnv = toolDataService.getAPIActiveEnvironment();

    if (storedCollections.length > 0) {
      setCollections(storedCollections);
    }
    if (storedRequests.length > 0) {
      setSavedRequests(storedRequests);
    }
    if (storedEnvs.length > 0) {
      setEnvironments(storedEnvs);
    }
    if (storedHistory.length > 0) {
      setHistory(storedHistory);
    }
    if (storedActiveEnv) {
      setActiveEnvId(storedActiveEnv);
    }
  }, []);

  // Replace environment variables in text
  const replaceEnvVars = (text: string): string => {
    if (!activeEnvId) return text;
    
    const env = environments.find(e => e.id === activeEnvId);
    if (!env) return text;

    let result = text;
    env.variables
      .filter(v => v.enabled)
      .forEach(v => {
        result = result.replace(new RegExp(`{{${v.key}}}`, 'g'), v.value);
      });

    return result;
  };

  // Header management
  const addHeader = () => {
    setCurrentRequest(prev => ({
      ...prev,
      headers: [...prev.headers, { id: Date.now().toString(), key: '', value: '', enabled: true }]
    }));
  };

  const removeHeader = (id: string) => {
    setCurrentRequest(prev => ({
      ...prev,
      headers: prev.headers.filter(h => h.id !== id)
    }));
  };

  const updateHeader = (id: string, field: keyof Header, value: any) => {
    setCurrentRequest(prev => ({
      ...prev,
      headers: prev.headers.map(h => h.id === id ? { ...h, [field]: value } : h)
    }));
  };

  // Test assertion management
  const addTest = () => {
    setCurrentRequest(prev => ({
      ...prev,
      tests: [...prev.tests, {
        id: Date.now().toString(),
        type: 'status',
        operator: '==',
        value: '200',
        enabled: true
      }]
    }));
  };

  const removeTest = (id: string) => {
    setCurrentRequest(prev => ({
      ...prev,
      tests: prev.tests.filter(t => t.id !== id)
    }));
  };

  const updateTest = (id: string, field: keyof TestAssertion, value: any) => {
    setCurrentRequest(prev => ({
      ...prev,
      tests: prev.tests.map(t => t.id === id ? { ...t, [field]: value } : t)
    }));
  };

  // Run test assertions
  const runTests = (response: any, responseTime: number): TestResult[] => {
    return currentRequest.tests
      .filter(t => t.enabled)
      .map(test => {
        let actual: any;
        let passed = false;
        let message = '';

        try {
          switch (test.type) {
            case 'status':
              actual = response.status;
              passed = eval(`${actual} ${test.operator === 'exists' ? '!== undefined' : test.operator} ${test.value}`);
              message = passed ? `Status ${actual} matches expectation` : `Expected status ${test.operator} ${test.value}, got ${actual}`;
              break;

            case 'header':
              if (!test.field) {
                message = 'Header field not specified';
                break;
              }
              actual = response.headers?.[test.field.toLowerCase()];
              if (test.operator === 'exists') {
                passed = actual !== undefined;
                message = passed ? `Header ${test.field} exists` : `Header ${test.field} not found`;
              } else if (test.operator === 'contains') {
                passed = actual?.includes(test.value);
                message = passed ? `Header ${test.field} contains "${test.value}"` : `Header ${test.field} does not contain "${test.value}"`;
              } else {
                passed = eval(`"${actual}" ${test.operator} "${test.value}"`);
                message = passed ? `Header ${test.field} matches` : `Header ${test.field} mismatch`;
              }
              break;

            case 'body':
              actual = typeof response.data === 'string' ? response.data : JSON.stringify(response.data);
              if (test.operator === 'contains') {
                passed = actual.includes(test.value);
                message = passed ? `Body contains "${test.value}"` : `Body does not contain "${test.value}"`;
              } else if (test.field) {
                try {
                  const bodyObj = typeof response.data === 'object' ? response.data : JSON.parse(response.data);
                  actual = bodyObj[test.field];
                  passed = eval(`"${actual}" ${test.operator} "${test.value}"`);
                  message = passed ? `Body field ${test.field} matches` : `Body field ${test.field} mismatch`;
                } catch (e) {
                  message = 'Body is not valid JSON';
                }
              }
              break;

            case 'time':
              actual = responseTime;
              passed = eval(`${actual} ${test.operator} ${test.value}`);
              message = passed ? `Response time ${actual}ms ${test.operator} ${test.value}ms` : `Response time ${actual}ms not ${test.operator} ${test.value}ms`;
              break;
          }
        } catch (e: any) {
          message = `Test error: ${e.message}`;
        }

        return { assertion: test, passed, actual, message };
      });
  };

  // Send Request with env vars and tests
  const sendRequest = async () => {
    setIsLoading(true);
    setResponse(null);
    setResponseTime(null);
    setTestResults([]);

    const startTime = performance.now();

    try {
      // Replace environment variables
      const processedUrl = replaceEnvVars(currentRequest.url);
      const requestHeaders: Record<string, string> = {};
      
      currentRequest.headers
        .filter(h => h.enabled && h.key.trim())
        .forEach(h => {
          requestHeaders[h.key] = replaceEnvVars(h.value);
        });

      const options: RequestInit = {
        method: currentRequest.method,
        headers: requestHeaders,
      };

      if (['POST', 'PUT', 'PATCH'].includes(currentRequest.method) && currentRequest.body.trim()) {
        options.body = replaceEnvVars(currentRequest.body);
      }

      const res = await fetch(processedUrl, options);
      const endTime = performance.now();
      const respTime = Math.round(endTime - startTime);
      setResponseTime(respTime);

      const contentType = res.headers.get('content-type');
      let data;

      if (contentType?.includes('application/json')) {
        data = await res.json();
      } else {
        data = await res.text();
      }

      const responseData = {
        status: res.status,
        statusText: res.statusText,
        headers: Object.fromEntries(res.headers.entries()),
        data
      };

      setResponse(responseData);

      // Run tests
      const results = runTests(responseData, respTime);
      setTestResults(results);

      // Add to history
      const historyEntry: HistoryEntry = {
        id: Date.now().toString(),
        requestId: currentRequest.id !== 'new' ? currentRequest.id : undefined,
        method: currentRequest.method,
        url: processedUrl,
        status: res.status,
        responseTime: respTime,
        success: res.ok && results.every(r => r.passed),
        timestamp: Date.now(),
        testResults: results
      };

      const newHistory = [historyEntry, ...history].slice(0, 50);
      setHistory(newHistory);
      toolDataService.saveAPIHistory(newHistory);

    } catch (error: any) {
      const endTime = performance.now();
      const respTime = Math.round(endTime - startTime);
      setResponseTime(respTime);
      
      const errorResponse = {
        error: true,
        message: error.message || 'Request failed'
      };
      
      setResponse(errorResponse);

      // Add error to history
      const historyEntry: HistoryEntry = {
        id: Date.now().toString(),
        method: currentRequest.method,
        url: currentRequest.url,
        responseTime: respTime,
        success: false,
        timestamp: Date.now()
      };

      const newHistory = [historyEntry, ...history].slice(0, 50);
      setHistory(newHistory);
      toolDataService.saveAPIHistory(newHistory);

    } finally {
      setIsLoading(false);
    }
  };

  // Collection Management
  const saveRequest = () => {
    if (!newRequestName.trim()) {
      alert('Please enter a request name');
      return;
    }

    const requestToSave = {
      ...currentRequest,
      id: currentRequest.id === 'new' ? Date.now().toString() : currentRequest.id,
      name: newRequestName.trim(),
      collectionId: selectedCollectionId || undefined
    };

    const existingIndex = savedRequests.findIndex(r => r.id === requestToSave.id);
    let newRequests;
    
    if (existingIndex >= 0) {
      newRequests = [...savedRequests];
      newRequests[existingIndex] = requestToSave;
    } else {
      newRequests = [...savedRequests, requestToSave];
    }

    setSavedRequests(newRequests);
    toolDataService.saveAPIRequests(newRequests);

    // Update collection if specified
    if (selectedCollectionId) {
      const newCollections = collections.map(c => {
        if (c.id === selectedCollectionId && !c.requests.includes(requestToSave.id)) {
          return { ...c, requests: [...c.requests, requestToSave.id] };
        }
        return c;
      });
      setCollections(newCollections);
      toolDataService.saveAPICollections(newCollections);
    }

    setCurrentRequest(requestToSave);
    setShowSaveModal(false);
    setNewRequestName('');
  };

  const createCollection = () => {
    if (!newCollectionName.trim()) return;

    const newCollection: Collection = {
      id: Date.now().toString(),
      name: newCollectionName.trim(),
      requests: []
    };

    const newCollections = [...collections, newCollection];
    setCollections(newCollections);
    toolDataService.saveAPICollections(newCollections);
    setNewCollectionName('');
    setShowNewCollectionModal(false);
  };

  const deleteCollection = (id: string) => {
    const newCollections = collections.filter(c => c.id !== id);
    setCollections(newCollections);
    toolDataService.saveAPICollections(newCollections);
  };

  const loadRequest = (request: APIRequest) => {
    setCurrentRequest(request);
    setMainTab('request');
  };

  const deleteRequest = (id: string) => {
    const newRequests = savedRequests.filter(r => r.id !== id);
    setSavedRequests(newRequests);
    toolDataService.saveAPIRequests(newRequests);

    // Remove from collections
    const newCollections = collections.map(c => ({
      ...c,
      requests: c.requests.filter(rid => rid !== id)
    }));
    setCollections(newCollections);
    toolDataService.saveAPICollections(newCollections);
  };

  // Environment Management
  const createEnvironment = () => {
    const envName = prompt('Environment name:');
    if (!envName?.trim()) return;

    const newEnv: Environment = {
      id: Date.now().toString(),
      name: envName.trim(),
      variables: []
    };

    const newEnvs = [...environments, newEnv];
    setEnvironments(newEnvs);
    toolDataService.saveAPIEnvironments(newEnvs);
  };

  const deleteEnvironment = (id: string) => {
    const newEnvs = environments.filter(e => e.id !== id);
    setEnvironments(newEnvs);
    toolDataService.saveAPIEnvironments(newEnvs);
    if (activeEnvId === id) {
      setActiveEnvId(null);
      toolDataService.removeAPIActiveEnvironment();
    }
  };

  const addEnvVariable = (envId: string) => {
    const newEnvs = environments.map(e => {
      if (e.id === envId) {
        return {
          ...e,
          variables: [...e.variables, {
            id: Date.now().toString(),
            key: '',
            value: '',
            enabled: true
          }]
        };
      }
      return e;
    });
    setEnvironments(newEnvs);
    toolDataService.saveAPIEnvironments(newEnvs);
  };

  const updateEnvVariable = (envId: string, varId: string, field: keyof EnvVariable, value: any) => {
    const newEnvs = environments.map(e => {
      if (e.id === envId) {
        return {
          ...e,
          variables: e.variables.map(v => 
            v.id === varId ? { ...v, [field]: value } : v
          )
        };
      }
      return e;
    });
    setEnvironments(newEnvs);
    toolDataService.saveAPIEnvironments(newEnvs);
  };

  const deleteEnvVariable = (envId: string, varId: string) => {
    const newEnvs = environments.map(e => {
      if (e.id === envId) {
        return {
          ...e,
          variables: e.variables.filter(v => v.id !== varId)
        };
      }
      return e;
    });
    setEnvironments(newEnvs);
    toolDataService.saveAPIEnvironments(newEnvs);
  };

  const setActiveEnvironment = (envId: string | null) => {
    setActiveEnvId(envId);
    if (envId) {
      toolDataService.saveAPIActiveEnvironment(envId);
    } else {
      toolDataService.removeAPIActiveEnvironment();
    }
  };

  // Export/Import
  const exportData = () => {
    const data = {
      collections,
      requests: savedRequests,
      environments
    };
    const json = JSON.stringify(data, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `api-tester-export-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const importData = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = JSON.parse(e.target?.result as string);
        if (data.collections) {
          setCollections(data.collections);
          toolDataService.saveAPICollections(data.collections);
        }
        if (data.requests) {
          setSavedRequests(data.requests);
          toolDataService.saveAPIRequests(data.requests);
        }
        if (data.environments) {
          setEnvironments(data.environments);
          toolDataService.saveAPIEnvironments(data.environments);
        }
        alert('Data imported successfully!');
      } catch (err) {
        alert('Failed to import data. Invalid format.');
      }
    };
    reader.readAsText(file);
  };

  const copyResponse = () => {
    if (response) {
      navigator.clipboard.writeText(JSON.stringify(response, null, 2));
    }
  };

  const clearHistory = () => {
    setHistory([]);
    toolDataService.clearAPIHistory();
  };

  const activeEnv = environments.find(e => e.id === activeEnvId);

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <section className="relative overflow-hidden py-12 border-b border-gray-800">
        <div className="absolute inset-0 bg-grid-gray-900 [mask-image:linear-gradient(to_bottom,white_30%,transparent)]"></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-cyan-500/10 rounded-full blur-3xl"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          {/* Back Button */}
          <button
            onClick={() => onNavigate?.('toolbox')}
            className="mb-6 flex items-center gap-2 text-gray-400 hover:text-cyan-400 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Toolbox
          </button>

          <div className="text-center">
            <div className="mb-4 inline-flex items-center gap-2 px-4 py-2 bg-cyan-500/10 rounded-full border border-cyan-500/30">
              <Send className="w-4 h-4 text-cyan-400" />
              <span className="text-sm font-medium text-cyan-400">API Testing Tool</span>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Test Your <span className="bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">APIs</span>
            </h1>
            <p className="text-xl text-gray-400 max-w-2xl mx-auto">
              Test and debug your APIs with a powerful, easy-to-use HTTP client
            </p>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-12 bg-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Request Section */}
            <div className="bg-gray-900/50 rounded-2xl p-6 border border-gray-800">
              <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
                <Send className="w-6 h-6 text-cyan-400" />
                Request
              </h2>

              {/* URL and Method */}
              <div className="space-y-4 mb-6">
                <div className="flex flex-col sm:flex-row gap-3">
                  <select
                    value={currentRequest.method}
                    onChange={(e) => setCurrentRequest(prev => ({ ...prev, method: e.target.value }))}
                    className="px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg font-semibold text-white focus:outline-none focus:border-cyan-500 transition w-full sm:w-auto"
                  >
                    {HTTP_METHODS.map(m => (
                      <option key={m} value={m}>{m}</option>
                    ))}
                  </select>
                  <input
                    type="text"
                    value={currentRequest.url}
                    onChange={(e) => setCurrentRequest(prev => ({ ...prev, url: e.target.value }))}
                    placeholder="Enter API endpoint URL"
                    className="flex-1 px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-cyan-500 transition"
                  />
                </div>
              </div>

              {/* Tabs */}
              <div className="flex gap-4 mb-4 border-b border-gray-800">
                <button
                  onClick={() => setRequestTab('body')}
                  className={`px-4 py-2 font-semibold transition ${
                    requestTab === 'body'
                      ? 'text-cyan-400 border-b-2 border-cyan-400'
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  Body
                </button>
                <button
                  onClick={() => setRequestTab('headers')}
                  className={`px-4 py-2 font-semibold transition ${
                    requestTab === 'headers'
                      ? 'text-cyan-400 border-b-2 border-cyan-400'
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  Headers ({currentRequest.headers.length})
                </button>
              </div>

              {/* Body Tab */}
              {requestTab === 'body' && (
                <div>
                  <textarea
                    value={currentRequest.body}
                    onChange={(e) => setCurrentRequest(prev => ({ ...prev, body: e.target.value }))}
                    placeholder="Request body (JSON, XML, etc.)"
                    className="w-full h-64 px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg font-mono text-sm text-white focus:outline-none focus:border-cyan-500 transition resize-none"
                    disabled={!['POST', 'PUT', 'PATCH'].includes(currentRequest.method)}
                  />
                  {!['POST', 'PUT', 'PATCH'].includes(currentRequest.method) && (
                    <p className="text-xs text-gray-500 mt-2">Request body is only available for POST, PUT, and PATCH methods</p>
                  )}
                </div>
              )}

              {/* Headers Tab */}
              {requestTab === 'headers' && (
                <div className="space-y-3">
                  {currentRequest.headers.map(header => (
                    <div key={header.id} className="flex gap-3">
                      <input
                        type="text"
                        value={header.key}
                        onChange={(e) => updateHeader(header.id, 'key', e.target.value)}
                        placeholder="Header key"
                        className="flex-1 px-3 py-2 bg-gray-800 border border-gray-700 rounded-lg text-sm text-white focus:outline-none focus:border-cyan-500 transition"
                      />
                      <input
                        type="text"
                        value={header.value}
                        onChange={(e) => updateHeader(header.id, 'value', e.target.value)}
                        placeholder="Header value"
                        className="flex-1 px-3 py-2 bg-gray-800 border border-gray-700 rounded-lg text-sm text-white focus:outline-none focus:border-cyan-500 transition"
                      />
                      <button
                        onClick={() => removeHeader(header.id)}
                        className="p-2 text-red-400 hover:bg-red-600/20 rounded-lg transition"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  ))}
                  <button
                    onClick={addHeader}
                    className="flex items-center gap-2 px-4 py-2 text-cyan-400 hover:bg-cyan-600/20 rounded-lg transition"
                  >
                    <Plus className="w-4 h-4" />
                    Add Header
                  </button>
                </div>
              )}

              {/* Send Button */}
              <button
                onClick={sendRequest}
                disabled={isLoading || !currentRequest.url.trim()}
                className="w-full mt-6 flex items-center justify-center gap-2 px-6 py-3 bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600 disabled:opacity-50 disabled:cursor-not-allowed text-black font-semibold rounded-lg transition-all duration-300 transform hover:scale-[1.02]"
              >
                {isLoading ? (
                  <>
                    <div className="w-5 h-5 border-2 border-black/30 border-t-black rounded-full animate-spin"></div>
                    Processing...
                  </>
                ) : (
                  <>
                    <Send className="w-5 h-5" />
                    Send Request
                  </>
                )}
              </button>
            </div>

            {/* Response Section */}
            <div className="bg-gray-900/50 rounded-2xl p-6 border border-gray-800">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold flex items-center gap-2">
                  <Clock className="w-6 h-6 text-purple-400" />
                  Response
                </h2>
                {response && !response.error && (
                  <button
                    onClick={copyResponse}
                    className="flex items-center gap-2 px-3 py-2 text-sm text-cyan-400 hover:bg-cyan-600/20 rounded-lg transition"
                  >
                    <Copy className="w-4 h-4" />
                    Copy
                  </button>
                )}
              </div>

              {!response && !isLoading && (
                <div className="h-full min-h-[400px] flex items-center justify-center text-center text-gray-400">
                  <div>
                    <Send className="w-16 h-16 mx-auto mb-4 opacity-50" />
                    <p className="text-lg">Send a request to see the response</p>
                    <p className="text-sm mt-2 text-gray-500">Configure your request and click "Send Request"</p>
                  </div>
                </div>
              )}

              {isLoading && (
                <div className="h-full min-h-[400px] flex items-center justify-center">
                  <div className="flex flex-col items-center gap-4">
                    <div className="flex gap-2">
                      <div className="w-3 h-3 bg-cyan-400 rounded-full animate-bounce" />
                      <div className="w-3 h-3 bg-purple-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }} />
                      <div className="w-3 h-3 bg-cyan-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
                    </div>
                    <p className="text-gray-400">Sending request...</p>
                  </div>
                </div>
              )}

              {response && (
                <div className="space-y-4">
                  {/* Status */}
                  {!response.error && (
                    <div className="flex items-center gap-4">
                      <div className={`px-3 py-1 rounded-lg font-semibold ${
                        response.status >= 200 && response.status < 300
                          ? 'bg-green-600/20 text-green-400 border border-green-600/30'
                          : response.status >= 400
                          ? 'bg-red-600/20 text-red-400 border border-red-600/30'
                          : 'bg-yellow-600/20 text-yellow-400 border border-yellow-600/30'
                      }`}>
                        {response.status} {response.statusText}
                      </div>
                      {responseTime && (
                        <div className="flex items-center gap-1 text-gray-400 text-sm">
                          <Clock className="w-4 h-4" />
                          {responseTime}ms
                        </div>
                      )}
                    </div>
                  )}

                  {/* Error */}
                  {response.error && (
                    <div className="px-4 py-3 bg-red-600/20 border border-red-600/50 rounded-lg text-red-400">
                      <div className="font-semibold mb-1">❌ Error</div>
                      <div className="text-sm">{response.message}</div>
                      {responseTime && (
                        <div className="flex items-center gap-1 text-red-400/70 text-xs mt-2">
                          <Clock className="w-3 h-3" />
                          Failed after {responseTime}ms
                        </div>
                      )}
                    </div>
                  )}

                  {/* Response Headers */}
                  {!response.error && response.headers && (
                    <div>
                      <div className="text-sm font-semibold text-gray-400 mb-2">Response Headers</div>
                      <div className="bg-gray-800 rounded-lg p-3 max-h-32 overflow-auto">
                        <pre className="text-xs text-gray-300 font-mono">
                          {JSON.stringify(response.headers, null, 2)}
                        </pre>
                      </div>
                    </div>
                  )}

                  {/* Response Data */}
                  <div>
                    <div className="text-sm font-semibold text-gray-400 mb-2">Response Body</div>
                    <div className="bg-gray-800 rounded-lg p-4 max-h-96 overflow-auto">
                      <pre className="text-sm text-gray-200 whitespace-pre-wrap break-words font-mono">
                        {JSON.stringify(response.error ? response : response.data, null, 2)}
                      </pre>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Tips Section */}
          <div className="mt-8 bg-gradient-to-r from-cyan-500/10 to-purple-500/10 border border-cyan-500/30 rounded-2xl p-6">
            <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
              <span>💡</span>
              Pro Tips
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-300">
              <div>
                <p className="font-semibold text-cyan-400 mb-1">Testing APIs</p>
                <p>Use this tool to test REST APIs, webhooks, or any HTTP endpoint</p>
              </div>
              <div>
                <p className="font-semibold text-purple-400 mb-1">Custom Headers</p>
                <p>Add authentication tokens, API keys, or custom headers as needed</p>
              </div>
              <div>
                <p className="font-semibold text-cyan-400 mb-1">Request Body</p>
                <p>Send JSON, XML, or plain text in POST, PUT, and PATCH requests</p>
              </div>
              <div>
                <p className="font-semibold text-purple-400 mb-1">Response Time</p>
                <p>Monitor API performance with real-time response time tracking</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default APITesterPage;
