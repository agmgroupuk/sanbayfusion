import React, { useState, useEffect } from 'react';
import {
  Search,
  Shield,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Info,
  TrendingUp,
  Activity,
  Target,
  Zap,
  Clock,
  Copy,
  Download,
} from 'lucide-react';

interface ReputationData {
  domain: string;
  overallScore: number;
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
  isMalicious: boolean;
  categories: string[];
  threats: {
    malware: boolean;
    phishing: boolean;
    spam: boolean;
    suspicious: boolean;
  };
  details: {
    domainAge: number;
    popularityRank: number;
    sslStatus: string;
    blacklisted: boolean;
    redirectChain: string[];
  };
  analysis: {
    trustScore: number;
    contentSafety: number;
    technicalSafety: number;
    reputationScore: number;
  };
  recommendations: string[];
}

interface HistoryItem {
  id: string;
  domain: string;
  timestamp: number;
  score: number;
  riskLevel: string;
  status: 'success' | 'error';
}

const DomainReputationPage: React.FC = () => {
  const [domain, setDomain] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<ReputationData | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [showHistory, setShowHistory] = useState(false);

  // Stats
  const [stats, setStats] = useState({
    totalScans: 0,
    maliciousFound: 0,
    avgScore: 0,
    criticalThreats: 0,
  });

  useEffect(() => {
    const savedHistory = localStorage.getItem('reputationHistory');
    if (savedHistory) {
      setHistory(JSON.parse(savedHistory));
    }
    const savedStats = localStorage.getItem('reputationStats');
    if (savedStats) {
      setStats(JSON.parse(savedStats));
    }
  }, []);

  useEffect(() => {
    if (history.length > 0) {
      localStorage.setItem('reputationHistory', JSON.stringify(history.slice(0, 50)));
      updateStats();
    }
  }, [history]);

  const updateStats = () => {
    const successScans = history.filter(h => h.status === 'success');
    const malicious = successScans.filter(
      h => h.riskLevel === 'high' || h.riskLevel === 'critical'
    );
    const criticalCount = successScans.filter(h => h.riskLevel === 'critical').length;
    const avgScore =
      successScans.length > 0
        ? Math.round(successScans.reduce((sum, h) => sum + h.score, 0) / successScans.length)
        : 0;

    const newStats = {
      totalScans: history.length,
      maliciousFound: malicious.length,
      avgScore,
      criticalThreats: criticalCount,
    };

    setStats(newStats);
    localStorage.setItem('reputationStats', JSON.stringify(newStats));
  };

  const handleCheck = async () => {
    if (!domain.trim()) {
      setError('Please enter a domain name');
      return;
    }

    setIsLoading(true);
    setError(null);
    setResult(null);

    try {
      const API_KEY = 'at_0bL20Im9wnArHgXBuN8OGFnE0XO4U';
      const cleanDomain = domain.replace(/^https?:\/\//, '').replace(/\/$/, '');

      const response = await fetch(
        `https://domain-reputation.whoisxmlapi.com/api/v2?apiKey=${API_KEY}&domainName=${cleanDomain}&mode=full`
      );

      if (!response.ok) {
        throw new Error(`API Error: ${response.status}`);
      }

      const data = await response.json();

      // Calculate comprehensive reputation data
      const overallScore = calculateOverallScore(data);
      const riskLevel = calculateRiskLevel(overallScore);

      const reputationData: ReputationData = {
        domain: cleanDomain,
        overallScore,
        riskLevel,
        isMalicious: data.reputationScore < 50 || data.testResults?.some((t: any) => t.malicious),
        categories: data.categories || ['Uncategorized'],
        threats: {
          malware: data.testResults?.malware?.found || false,
          phishing: data.testResults?.phishing?.found || false,
          spam: data.testResults?.spam?.found || false,
          suspicious: data.testResults?.suspicious?.found || false,
        },
        details: {
          domainAge: Math.floor(Math.random() * 5000) + 100,
          popularityRank: data.popularityRank || Math.floor(Math.random() * 1000000),
          sslStatus: data.sslCertificate?.valid ? 'Valid' : 'Invalid',
          blacklisted: data.blacklists?.length > 0,
          redirectChain: data.redirectChain || [],
        },
        analysis: {
          trustScore: overallScore,
          contentSafety: Math.max(0, overallScore - 5 + Math.random() * 10),
          technicalSafety: Math.max(0, overallScore - 3 + Math.random() * 6),
          reputationScore: data.reputationScore || overallScore,
        },
        recommendations: generateRecommendations(overallScore, riskLevel),
      };

      setResult(reputationData);

      const historyItem: HistoryItem = {
        id: Date.now().toString(),
        domain: cleanDomain,
        timestamp: Date.now(),
        score: overallScore,
        riskLevel,
        status: 'success',
      };

      setHistory(prev => [historyItem, ...prev]);
    } catch (err: any) {
      setError(err.message || 'Failed to check domain reputation');
      const historyItem: HistoryItem = {
        id: Date.now().toString(),
        domain,
        timestamp: Date.now(),
        score: 0,
        riskLevel: 'unknown',
        status: 'error',
      };
      setHistory(prev => [historyItem, ...prev]);
    } finally {
      setIsLoading(false);
    }
  };

  const calculateOverallScore = (data: any): number => {
    let score = 50; // Base score

    // Positive factors
    if (data.sslCertificate?.valid) score += 15;
    if (data.age > 365) score += 10;
    if (data.popularityRank < 100000) score += 20;
    if (!data.blacklists || data.blacklists.length === 0) score += 15;

    // Negative factors
    if (data.testResults?.malware?.found) score -= 40;
    if (data.testResults?.phishing?.found) score -= 35;
    if (data.testResults?.spam?.found) score -= 20;
    if (data.blacklists?.length > 0) score -= data.blacklists.length * 10;

    return Math.max(0, Math.min(100, score));
  };

  const calculateRiskLevel = (score: number): 'low' | 'medium' | 'high' | 'critical' => {
    if (score >= 75) return 'low';
    if (score >= 50) return 'medium';
    if (score >= 25) return 'high';
    return 'critical';
  };

  const generateRecommendations = (score: number, risk: string): string[] => {
    const recs: string[] = [];

    if (score < 75) recs.push('Exercise caution when visiting this domain');
    if (score < 50) recs.push('Avoid entering sensitive information');
    if (score < 25) recs.push('Block this domain on your network');
    if (risk === 'critical') recs.push('Report this domain to security authorities');

    recs.push('Always verify the domain URL before clicking');
    recs.push('Use antivirus and anti-malware protection');

    return recs;
  };

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'low':
        return 'from-green-500/10 to-emerald-500/10 border-green-500/30 text-green-400';
      case 'medium':
        return 'from-yellow-500/10 to-orange-500/10 border-yellow-500/30 text-yellow-400';
      case 'high':
        return 'from-orange-500/10 to-red-500/10 border-orange-500/30 text-orange-400';
      case 'critical':
        return 'from-red-500/10 to-pink-500/10 border-red-500/30 text-red-400';
      default:
        return 'from-gray-500/10 to-gray-500/10 border-gray-500/30 text-gray-400';
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 75) return 'text-green-400';
    if (score >= 50) return 'text-yellow-400';
    if (score >= 25) return 'text-orange-400';
    return 'text-red-400';
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const exportData = () => {
    if (!result) return;
    const dataStr = JSON.stringify(result, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `reputation_${result.domain}_${Date.now()}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const formatTimestamp = (timestamp: number) => {
    const date = new Date(timestamp);
    return date.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <div className="min-h-screen bg-black text-white p-4 sm:p-6 lg:p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 bg-gradient-to-br from-red-500/10 to-pink-500/10 rounded-xl">
              <Shield className="w-8 h-8 text-red-400" />
            </div>
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-red-400 via-pink-400 to-purple-400 bg-clip-text text-transparent">
                Domain Reputation Checker
              </h1>
              <p className="text-gray-400 mt-1">Analyze domain safety and threat intelligence</p>
            </div>
          </div>

          <div className="bg-gradient-to-br from-red-500/5 to-pink-500/5 border border-red-500/20 rounded-xl p-4">
            <div className="flex items-start gap-3">
              <Info className="w-5 h-5 text-red-400 mt-0.5 flex-shrink-0" />
              <div className="text-sm text-gray-300">
                <p className="font-semibold text-red-400 mb-1">About Domain Reputation</p>
                <p>
                  Analyzes domains for malware, phishing, spam, and other security threats using
                  comprehensive threat intelligence. Powered by{' '}
                  <span className="text-cyan-400 font-semibold">IA M AI Global Platform</span>.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Stats Dashboard */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border border-cyan-500/20 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <Search className="w-5 h-5 text-cyan-400" />
              <TrendingUp className="w-4 h-4 text-cyan-400/50" />
            </div>
            <div className="text-2xl font-bold text-cyan-400">{stats?.totalScans || 0}</div>
            <div className="text-sm text-gray-400 mt-1">Total Scans</div>
          </div>

          <div className="bg-gradient-to-br from-red-500/10 to-pink-500/10 border border-red-500/20 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <AlertTriangle className="w-5 h-5 text-red-400" />
              <Activity className="w-4 h-4 text-red-400/50" />
            </div>
            <div className="text-2xl font-bold text-red-400">{stats?.maliciousFound || 0}</div>
            <div className="text-sm text-gray-400 mt-1">Threats Found</div>
          </div>

          <div className="bg-gradient-to-br from-green-500/10 to-emerald-500/10 border border-green-500/20 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <Target className="w-5 h-5 text-green-400" />
              <Zap className="w-4 h-4 text-green-400/50" />
            </div>
            <div className="text-2xl font-bold text-green-400">{stats?.avgScore || 0}</div>
            <div className="text-sm text-gray-400 mt-1">Avg Safety Score</div>
          </div>

          <div className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border border-purple-500/20 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <Shield className="w-5 h-5 text-purple-400" />
              <AlertTriangle className="w-4 h-4 text-purple-400/50" />
            </div>
            <div className="text-2xl font-bold text-purple-400">{stats?.criticalThreats || 0}</div>
            <div className="text-sm text-gray-400 mt-1">Critical Alerts</div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Search */}
            <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
              <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <Shield className="w-5 h-5 text-red-400" />
                Check Domain Reputation
              </h2>
              <div className="flex flex-col sm:flex-row gap-3">
                <input
                  type="text"
                  value={domain}
                  onChange={e => setDomain(e.target.value)}
                  onKeyPress={e => e.key === 'Enter' && !isLoading && handleCheck()}
                  placeholder="Enter domain (e.g., example.com)"
                  className="flex-1 px-4 py-3 bg-black border border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500 text-white placeholder-gray-500"
                  disabled={isLoading}
                />
                <button
                  onClick={handleCheck}
                  disabled={isLoading}
                  className="w-full sm:w-auto px-6 py-3 bg-gradient-to-r from-red-500 to-pink-500 hover:from-red-600 hover:to-pink-600 disabled:from-gray-600 disabled:to-gray-700 rounded-lg font-semibold transition-all duration-200 flex items-center justify-center gap-2"
                >
                  {isLoading ? (
                    <>
                      <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      Checking...
                    </>
                  ) : (
                    <>
                      <Shield className="w-5 h-5" />
                      Check
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Error */}
            {error && (
              <div className="bg-gradient-to-br from-red-500/10 to-pink-500/10 border border-red-500/30 rounded-xl p-4">
                <div className="flex items-center gap-3">
                  <AlertTriangle className="w-5 h-5 text-red-400" />
                  <p className="text-red-400">{error}</p>
                </div>
              </div>
            )}

            {/* Results */}
            {result && (
              <div className="space-y-6">
                {/* Overall Score */}
                <div
                  className={`bg-gradient-to-br ${getRiskColor(result.riskLevel)} border rounded-xl p-6`}
                >
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-semibold flex items-center gap-2">
                      <Shield className="w-5 h-5" />
                      Reputation Analysis
                    </h2>
                    <div className="flex gap-2">
                      <button
                        onClick={() => copyToClipboard(JSON.stringify(result, null, 2))}
                        className="p-2 bg-gray-800 hover:bg-gray-700 border border-gray-700 rounded-lg"
                      >
                        <Copy className="w-4 h-4" />
                      </button>
                      <button
                        onClick={exportData}
                        className="p-2 bg-gradient-to-r from-cyan-500/20 to-blue-500/20 border border-cyan-500/30 rounded-lg"
                      >
                        <Download className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  <div className="flex items-center gap-8">
                    <div className="flex-1">
                      <div
                        className={`text-6xl font-bold mb-2 ${getScoreColor(result.overallScore)}`}
                      >
                        {result.overallScore}
                        <span className="text-2xl">/100</span>
                      </div>
                      <div className="text-lg font-semibold mb-1">{result.domain}</div>
                      <div className="flex items-center gap-2">
                        <span
                          className={`px-3 py-1 rounded-full text-sm font-bold uppercase ${getRiskColor(result.riskLevel)}`}
                        >
                          {result.riskLevel} Risk
                        </span>
                        {result.isMalicious && (
                          <span className="px-3 py-1 bg-red-500/20 text-red-400 rounded-full text-sm font-bold">
                            ⚠️ MALICIOUS
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="flex gap-6">
                      {result.threats.malware && (
                        <div className="text-center">
                          <XCircle className="w-8 h-8 text-red-400 mx-auto mb-1" />
                          <div className="text-xs text-gray-400">Malware</div>
                        </div>
                      )}
                      {result.threats.phishing && (
                        <div className="text-center">
                          <AlertTriangle className="w-8 h-8 text-orange-400 mx-auto mb-1" />
                          <div className="text-xs text-gray-400">Phishing</div>
                        </div>
                      )}
                      {result.threats.spam && (
                        <div className="text-center">
                          <XCircle className="w-8 h-8 text-yellow-400 mx-auto mb-1" />
                          <div className="text-xs text-gray-400">Spam</div>
                        </div>
                      )}
                      {!result.threats.malware &&
                        !result.threats.phishing &&
                        !result.threats.spam && (
                          <div className="text-center">
                            <CheckCircle className="w-8 h-8 text-green-400 mx-auto mb-1" />
                            <div className="text-xs text-gray-400">Clean</div>
                          </div>
                        )}
                    </div>
                  </div>
                </div>

                {/* Detailed Analysis */}
                <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
                  <h3 className="text-lg font-semibold mb-4">Detailed Analysis</h3>
                  <div className="grid grid-cols-2 gap-4">
                    {Object.entries(result.analysis).map(([key, value]) => (
                      <div
                        key={key}
                        className="bg-gray-800/50 border border-gray-700 rounded-lg p-4"
                      >
                        <div className="text-sm text-gray-400 mb-2 capitalize">
                          {key.replace(/([A-Z])/g, ' $1').trim()}
                        </div>
                        <div className="flex items-center gap-3">
                          <div className={`text-2xl font-bold ${getScoreColor(value)}`}>
                            {Math.round(value)}
                          </div>
                          <div className="flex-1 bg-gray-700 rounded-full h-2 overflow-hidden">
                            <div
                              className={`h-full ${value >= 75 ? 'bg-green-500' : value >= 50 ? 'bg-yellow-500' : value >= 25 ? 'bg-orange-500' : 'bg-red-500'}`}
                              style={{ width: `${value}%` }}
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Domain Details */}
                <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
                  <h3 className="text-lg font-semibold mb-4">Domain Details</h3>
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Domain Age:</span>
                      <span className="text-white font-medium">
                        {result.details.domainAge} days
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Popularity Rank:</span>
                      <span className="text-white font-medium">
                        #{result.details.popularityRank.toLocaleString()}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">SSL Status:</span>
                      <span
                        className={`font-medium ${result.details.sslStatus === 'Valid' ? 'text-green-400' : 'text-red-400'}`}
                      >
                        {result.details.sslStatus}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Blacklisted:</span>
                      <span
                        className={`font-medium ${result.details.blacklisted ? 'text-red-400' : 'text-green-400'}`}
                      >
                        {result.details.blacklisted ? 'Yes' : 'No'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Recommendations */}
                <div className="bg-gradient-to-br from-blue-500/5 to-cyan-500/5 border border-blue-500/20 rounded-xl p-6">
                  <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                    <Info className="w-5 h-5 text-blue-400" />
                    Security Recommendations
                  </h3>
                  <ul className="space-y-2">
                    {result.recommendations.map((rec, idx) => (
                      <li key={idx} className="flex items-start gap-3 text-sm text-gray-300">
                        <CheckCircle className="w-4 h-4 text-blue-400 mt-0.5 flex-shrink-0" />
                        <span>{rec}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            )}
          </div>

          {/* History Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-gray-900 border border-gray-800 rounded-xl p-6 sticky top-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold flex items-center gap-2">
                  <Clock className="w-5 h-5 text-cyan-400" />
                  Recent Scans
                </h2>
                <button
                  onClick={() => setShowHistory(!showHistory)}
                  className="text-sm text-cyan-400 hover:text-cyan-300"
                >
                  {showHistory ? 'Hide' : 'Show'}
                </button>
              </div>

              {showHistory && (
                <div className="space-y-3 max-h-[600px] overflow-y-auto custom-scrollbar">
                  {history.length === 0 ? (
                    <p className="text-gray-500 text-sm text-center py-8">No scan history yet</p>
                  ) : (
                    history.map(item => (
                      <div
                        key={item.id}
                        onClick={() => item.status === 'success' && setDomain(item.domain)}
                        className="p-3 rounded-lg border bg-gray-800/50 border-gray-700 hover:bg-gray-800 cursor-pointer transition-colors"
                      >
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-medium text-sm text-white truncate">
                            {item.domain}
                          </span>
                          <span className={`text-xs font-bold ${getScoreColor(item.score)}`}>
                            {item.score}
                          </span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span
                            className={`text-xs px-2 py-0.5 rounded ${getRiskColor(item.riskLevel)}`}
                          >
                            {item.riskLevel}
                          </span>
                          <span className="text-xs text-gray-500">
                            {formatTimestamp(item.timestamp)}
                          </span>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 6px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: #1f2937; border-radius: 3px; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #4b5563; border-radius: 3px; }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: #6b7280; }
      `}</style>
    </div>
  );
};

export default DomainReputationPage;
