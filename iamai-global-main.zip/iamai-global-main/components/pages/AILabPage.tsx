import React, { useState, useEffect } from 'react';
import { Page } from '../../App';
import {
  Beaker,
  Cpu,
  Zap,
  Database,
  Users,
  Rocket,
  Lock,
  GitBranch,
  BarChart3,
  Microscope,
  TestTube,
  Code,
  Brain,
  Eye,
  Network,
  Sparkles,
  Image as ImageIcon,
  MessageSquare,
  FileText,
  Languages,
  TrendingUp,
  Copy,
  Download,
  Play,
  Trash2,
  Save,
  Upload,
  Filter,
  X,
  Check,
  AlertCircle,
  Clock,
  DollarSign,
  Crown,
} from 'lucide-react';
import { authService } from '../../services/authService';

interface AILabPageProps {
  onNavigate: (page: Page) => void;
}

interface SubscriptionStatus {
  hasActiveSubscription: boolean;
  subscriptionType: string | null;
  isLoading: boolean;
}

interface AILabDashboard {
  subscription: {
    type: string;
    expiresAt: string;
    isActive: boolean;
  };
  permissions: {
    canAccessAILab: boolean;
    canAccessPromptTemplates: boolean;
    canAccessModelTesting: boolean;
    canAccessAdvancedFeatures: boolean;
    maxTestsPerDay: number;
    canExportResults: boolean;
  };
  usage: {
    today: {
      testsRun: number;
      limit: number;
      featuresUsed: string[];
    };
    total: {
      totalTests: number;
      favoriteTemplates: string[];
    };
  };
}

// AI Tool Types
type AIToolType =
  | 'text-generation'
  | 'image-generation'
  | 'code-assistant'
  | 'chat'
  | 'content-tools';

interface PromptTemplate {
  id: string;
  name: string;
  description: string;
  prompt: string;
  category: 'marketing' | 'coding' | 'creative' | 'business' | 'analysis';
  model: string;
  parameters: {
    temperature?: number;
    maxTokens?: number;
    topP?: number;
  };
}

interface TestResult {
  id: string;
  timestamp: number;
  tool: AIToolType;
  prompt: string;
  response: string;
  model: string;
  tokens: number;
  duration: number;
  cost: number;
}

interface AIStats {
  totalTests: number;
  totalTokens: number;
  totalCost: number;
  avgResponseTime: number;
  successRate: number;
}

interface LabFeature {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  status: 'available' | 'coming-soon';
  category: 'core' | 'integration' | 'monitoring' | 'advanced';
}

interface Experiment {
  id: string;
  title: string;
  description: string;
  complexity: 'beginner' | 'intermediate' | 'advanced';
  status: 'active' | 'coming-soon';
  icon: React.ReactNode;
}

const LabFeature: React.FC<{
  feature: LabFeature;
  onFeatureClick: (feature: LabFeature) => void;
  hasAccess: boolean;
}> = ({ feature, onFeatureClick, hasAccess }) => (
  <div
    className={`bg-gray-900/50 border border-gray-800 rounded-lg p-6 transition-all group cursor-pointer ${
      hasAccess
        ? 'hover:border-cyan-500/50 hover:bg-gray-900/70'
        : 'hover:border-red-500/50 hover:bg-gray-900/70'
    }`}
    onClick={() => onFeatureClick(feature)}
  >
    <div className="flex items-start justify-between mb-4">
      <div
        className={`w-12 h-12 rounded-lg flex items-center justify-center transition-colors ${
          hasAccess
            ? 'bg-cyan-500/20 text-cyan-400 group-hover:bg-cyan-500/30'
            : 'bg-gray-800 text-gray-500'
        }`}
      >
        {hasAccess ? feature.icon : <Lock className="w-6 h-6" />}
      </div>
      <div className="flex flex-col gap-1">
        <span
          className={`text-xs font-semibold px-3 py-1 rounded-full ${
            feature.status === 'available'
              ? 'bg-green-500/20 text-green-400'
              : 'bg-yellow-500/20 text-yellow-400'
          }`}
        >
          {feature.status === 'available' ? '✓ Active' : '⏳ Coming Soon'}
        </span>
        {!hasAccess && (
          <span className="text-xs font-semibold px-3 py-1 rounded-full bg-red-500/20 text-red-400">
            🔒 Premium
          </span>
        )}
      </div>
    </div>
    <h3
      className={`text-lg font-bold mb-2 transition-colors ${
        hasAccess ? 'text-white group-hover:text-cyan-400' : 'text-gray-500'
      }`}
    >
      {feature.title}
    </h3>
    <p className="text-sm text-gray-400">{feature.description}</p>
  </div>
);

const ExperimentCard: React.FC<{
  experiment: Experiment;
  onExperimentClick: (experiment: Experiment) => void;
  hasAccess: boolean;
}> = ({ experiment, onExperimentClick, hasAccess }) => {
  const complexityColors = {
    beginner: 'text-green-400',
    intermediate: 'text-yellow-400',
    advanced: 'text-red-400',
  };

  return (
    <div
      className={`rounded-lg p-6 border transition-all group cursor-pointer ${
        experiment.status === 'active'
          ? hasAccess
            ? 'bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border-cyan-500/50 hover:border-cyan-400/80'
            : 'bg-gray-900/50 border-gray-800 hover:border-red-500/50'
          : 'bg-gray-900/50 border-gray-800 hover:border-gray-700'
      }`}
      onClick={() => onExperimentClick(experiment)}
    >
      <div className="flex items-start justify-between mb-4">
        <div
          className={`w-12 h-12 rounded-lg flex items-center justify-center transition-colors ${
            experiment.status === 'active'
              ? hasAccess
                ? 'bg-cyan-500/20 text-cyan-400 group-hover:bg-cyan-500/30'
                : 'bg-gray-800 text-gray-500'
              : 'bg-gray-800 text-gray-500'
          }`}
        >
          {hasAccess ? experiment.icon : <Lock className="w-6 h-6" />}
        </div>
        <div className="flex flex-col gap-1">
          <span
            className={`text-xs font-semibold px-2 py-1 rounded ${complexityColors[experiment.complexity]} bg-gray-900 border ${
              experiment.complexity === 'beginner'
                ? 'border-green-500/30'
                : experiment.complexity === 'intermediate'
                  ? 'border-yellow-500/30'
                  : 'border-red-500/30'
            }`}
          >
            {experiment.complexity.charAt(0).toUpperCase() + experiment.complexity.slice(1)}
          </span>
          {!hasAccess && experiment.status === 'active' && (
            <span className="text-xs font-semibold px-2 py-1 rounded-full bg-red-500/20 text-red-400">
              🔒 Premium
            </span>
          )}
        </div>
      </div>
      <h3
        className={`text-lg font-bold mb-2 transition-colors ${
          hasAccess ? 'text-white group-hover:text-cyan-400' : 'text-gray-500'
        }`}
      >
        {experiment.title}
      </h3>
      <p className="text-sm text-gray-400 mb-4">{experiment.description}</p>
      <div className="flex items-center gap-2">
        {experiment.status === 'active' ? (
          hasAccess ? (
            <>
              <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
              <span className="text-xs text-green-400 font-semibold">Ready to Test</span>
            </>
          ) : (
            <>
              <div className="w-2 h-2 rounded-full bg-red-500"></div>
              <span className="text-xs text-red-400 font-semibold">Subscription Required</span>
            </>
          )
        ) : (
          <>
            <div className="w-2 h-2 rounded-full bg-yellow-500"></div>
            <span className="text-xs text-yellow-400 font-semibold">Coming Soon</span>
          </>
        )}
      </div>
    </div>
  );
};

// Prompt Templates Library
const promptTemplates: PromptTemplate[] = [
  // Marketing Templates
  {
    id: 'mt1',
    name: 'Product Description',
    description: 'Generate compelling product descriptions',
    prompt:
      'Write a compelling product description for: [PRODUCT_NAME]\n\nKey features:\n- [FEATURE_1]\n- [FEATURE_2]\n- [FEATURE_3]\n\nTarget audience: [AUDIENCE]\nTone: Professional yet engaging',
    category: 'marketing',
    model: 'gpt-4',
    parameters: { temperature: 0.7, maxTokens: 300 },
  },
  {
    id: 'mt2',
    name: 'Social Media Post',
    description: 'Create engaging social media content',
    prompt:
      'Create 3 engaging social media posts about: [TOPIC]\n\nPlatform: [Instagram/Twitter/LinkedIn]\nTone: [Professional/Casual/Inspirational]\nInclude relevant hashtags and emojis',
    category: 'marketing',
    model: 'gpt-4',
    parameters: { temperature: 0.8, maxTokens: 250 },
  },
  {
    id: 'mt3',
    name: 'Email Campaign',
    description: 'Craft professional email campaigns',
    prompt:
      'Write an email campaign for: [CAMPAIGN_PURPOSE]\n\nTarget: [AUDIENCE]\nGoal: [CONVERSION_GOAL]\nTone: Professional\n\nInclude:\n- Compelling subject line\n- Engaging opening\n- Clear CTA\n- Professional closing',
    category: 'marketing',
    model: 'gpt-4',
    parameters: { temperature: 0.7, maxTokens: 400 },
  },

  // Coding Templates
  {
    id: 'ct1',
    name: 'Code Review',
    description: 'Review code for bugs and improvements',
    prompt:
      'Review this code and provide feedback:\n\n```[LANGUAGE]\n[CODE]\n```\n\nFocus on:\n- Bugs and potential issues\n- Performance optimizations\n- Best practices\n- Security concerns',
    category: 'coding',
    model: 'gpt-4',
    parameters: { temperature: 0.3, maxTokens: 500 },
  },
  {
    id: 'ct2',
    name: 'Function Generator',
    description: 'Generate functions with tests',
    prompt:
      'Create a [LANGUAGE] function that: [DESCRIPTION]\n\nRequirements:\n- Include proper error handling\n- Add TypeScript types (if applicable)\n- Write unit tests\n- Add JSDoc comments',
    category: 'coding',
    model: 'gpt-4',
    parameters: { temperature: 0.4, maxTokens: 600 },
  },
  {
    id: 'ct3',
    name: 'Bug Fixer',
    description: 'Debug and fix code issues',
    prompt:
      'Debug and fix this code:\n\n```[LANGUAGE]\n[CODE]\n```\n\nError message: [ERROR]\n\nProvide:\n- Root cause analysis\n- Fixed code\n- Explanation of the fix',
    category: 'coding',
    model: 'gpt-4',
    parameters: { temperature: 0.2, maxTokens: 500 },
  },

  // Creative Templates
  {
    id: 'cr1',
    name: 'Story Generator',
    description: 'Create creative stories',
    prompt:
      'Write a creative story about: [THEME]\n\nGenre: [GENRE]\nLength: [SHORT/MEDIUM/LONG]\nTone: [TONE]\n\nInclude:\n- Compelling characters\n- Engaging plot\n- Vivid descriptions\n- Satisfying conclusion',
    category: 'creative',
    model: 'gpt-4',
    parameters: { temperature: 0.9, maxTokens: 800 },
  },
  {
    id: 'cr2',
    name: 'Blog Post Writer',
    description: 'Generate SEO-optimized blog posts',
    prompt:
      'Write a blog post about: [TOPIC]\n\nTarget keywords: [KEYWORDS]\nLength: [WORD_COUNT] words\n\nInclude:\n- Catchy title\n- SEO-friendly intro\n- Well-structured sections\n- Engaging conclusion\n- Meta description',
    category: 'creative',
    model: 'gpt-4',
    parameters: { temperature: 0.7, maxTokens: 1000 },
  },

  // Business Templates
  {
    id: 'bt1',
    name: 'Business Plan',
    description: 'Create business plan sections',
    prompt:
      'Create a [SECTION] for a business plan:\n\nBusiness: [BUSINESS_NAME]\nIndustry: [INDUSTRY]\nTarget Market: [MARKET]\n\nProvide detailed, professional content suitable for investors.',
    category: 'business',
    model: 'gpt-4',
    parameters: { temperature: 0.6, maxTokens: 600 },
  },
  {
    id: 'bt2',
    name: 'Meeting Summary',
    description: 'Summarize meeting notes',
    prompt:
      'Summarize these meeting notes:\n\n[MEETING_NOTES]\n\nProvide:\n- Key discussion points\n- Action items with owners\n- Decisions made\n- Next steps',
    category: 'business',
    model: 'gpt-4',
    parameters: { temperature: 0.3, maxTokens: 400 },
  },

  // Analysis Templates
  {
    id: 'at1',
    name: 'Sentiment Analysis',
    description: 'Analyze text sentiment',
    prompt:
      'Analyze the sentiment of this text:\n\n[TEXT]\n\nProvide:\n- Overall sentiment (Positive/Negative/Neutral)\n- Confidence score\n- Key emotional indicators\n- Tone analysis',
    category: 'analysis',
    model: 'gpt-4',
    parameters: { temperature: 0.2, maxTokens: 300 },
  },
  {
    id: 'at2',
    name: 'Text Summarizer',
    description: 'Summarize long text',
    prompt:
      'Summarize this text in [LENGTH] sentences:\n\n[TEXT]\n\nProvide:\n- Main points\n- Key takeaways\n- Actionable insights',
    category: 'analysis',
    model: 'gpt-4',
    parameters: { temperature: 0.3, maxTokens: 400 },
  },
];

const AILabPage: React.FC<AILabPageProps> = ({ onNavigate }) => {
  const [activeView, setActiveView] = useState<'showcase' | 'testing'>('showcase');
  const [activeTool, setActiveTool] = useState<AIToolType>('text-generation');
  const [activeCategory, setActiveCategory] = useState<
    'all' | 'core' | 'integration' | 'monitoring' | 'advanced'
  >('all');

  // Subscription State
  const [subscriptionStatus, setSubscriptionStatus] = useState<SubscriptionStatus>({
    hasActiveSubscription: false,
    subscriptionType: null,
    isLoading: false,
  });
  const [dashboard, setDashboard] = useState<AILabDashboard | null>(null);
  const [loading, setLoading] = useState(true);
  const [showSubscriptionModal, setShowSubscriptionModal] = useState(false); // Don't show by default

  // AI Testing State
  const [selectedTemplate, setSelectedTemplate] = useState<PromptTemplate | null>(null);
  const [promptInput, setPromptInput] = useState('');
  const [modelSelect, setModelSelect] = useState('gpt-4');
  const [isGenerating, setIsGenerating] = useState(false);
  const [currentResponse, setCurrentResponse] = useState('');
  const [testHistory, setTestHistory] = useState<TestResult[]>([]);
  const [showHistory, setShowHistory] = useState(false);
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [stats, setStats] = useState<AIStats>({
    totalTests: 0,
    totalTokens: 0,
    totalCost: 0,
    avgResponseTime: 0,
    successRate: 100,
  });

  // Load history from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('ailab_history');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setTestHistory(parsed);
        calculateStats(parsed);
      } catch (e) {
        console.error('Failed to load history:', e);
      }
    }
  }, []);

  // Save history to localStorage
  useEffect(() => {
    if (testHistory.length > 0) {
      localStorage.setItem('ailab_history', JSON.stringify(testHistory.slice(0, 50)));
    }
  }, [testHistory]);

  // Load dashboard data and check subscription access
  useEffect(() => {
    const loadDashboard = async () => {
      try {
        if (!authService.isAuthenticated()) {
          setLoading(false);
          return;
        }

        // Check unified IAMAI subscription status – any active plan unlocks all AI Lab tools
        const response = await authService.authenticatedFetch('/api/subscription/current');

        if (response.ok) {
          const data = await response.json();
          const hasActiveSubscription = Boolean(data?.subscription && data.status === 'ACTIVE');

          const normalizedPlan = hasActiveSubscription
            ? (data.subscription.plan || 'MONTHLY').toLowerCase()
            : null;

          setSubscriptionStatus({
            hasActiveSubscription,
            subscriptionType: normalizedPlan,
            isLoading: false,
          });

          if (hasActiveSubscription) {
            // Basic synthetic dashboard derived from global subscription
            const expiresAt = data.subscription.billing?.currentPeriodEnd
              ? new Date(data.subscription.billing.currentPeriodEnd).toISOString()
              : new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString();

            setDashboard({
              subscription: {
                type: normalizedPlan || 'monthly',
                expiresAt,
                isActive: true,
              },
              permissions: {
                canAccessAILab: true,
                canAccessPromptTemplates: true,
                canAccessModelTesting: true,
                canAccessAdvancedFeatures: true,
                maxTestsPerDay: 100,
                canExportResults: true,
              },
              usage: {
                today: {
                  testsRun: 0,
                  limit: 100,
                  featuresUsed: [],
                },
                total: { totalTests: 0, favoriteTemplates: [] },
              },
            });
          }
        } else {
          // No subscription or error
          setSubscriptionStatus({
            hasActiveSubscription: false,
            subscriptionType: null,
            isLoading: false,
          });
        }
      } catch (error) {
        console.error('Failed to load AI Lab dashboard:', error);
        setSubscriptionStatus({
          hasActiveSubscription: false,
          subscriptionType: null,
          isLoading: false,
        });
      } finally {
        setLoading(false);
      }
    };

    loadDashboard();
  }, []);

  // Calculate statistics
  const calculateStats = (history: TestResult[]) => {
    if (history.length === 0) return;

    const totalTests = history.length;
    const totalTokens = history.reduce((sum, r) => sum + r.tokens, 0);
    const totalCost = history.reduce((sum, r) => sum + r.cost, 0);
    const avgResponseTime = history.reduce((sum, r) => sum + r.duration, 0) / totalTests;
    const successRate = 100; // Mock for now

    setStats({
      totalTests,
      totalTokens,
      totalCost,
      avgResponseTime,
      successRate,
    });
  };

  // Subscription protection functions
  const handleExperimentClick = (experiment: Experiment) => {
    if (!subscriptionStatus?.hasActiveSubscription) {
      setShowSubscriptionModal(true);
      return;
    }

    // Map experiment IDs to routes
    const routeMap: { [key: string]: Page } = {
      '1': 'ai-lab-battle', // Emotional Intelligence Test -> AI Lab Battle
      '2': 'ai-lab-history', // Memory Persistence -> AI Lab History
      '3': 'ai-lab', // Multi-Agent Swarm -> AI Lab Hub
      '4': 'ai-lab-latency', // Latency Optimization -> AI Lab Latency
      '5': 'ai-lab-code', // Vector Search Tuning -> AI Lab Code Playground
      '6': 'ai-lab-research', // Stress Testing -> AI Lab Research
    };

    const route = routeMap[experiment.id];
    if (route) {
      onNavigate(route as Page);
    }
  };

  const handleTemplateClick = (template: PromptTemplate) => {
    if (!subscriptionStatus?.hasActiveSubscription) {
      setShowSubscriptionModal(true);
      return;
    }

    setSelectedTemplate(template);
    setPromptInput(template.prompt);
  };

  const handleTestGeneration = () => {
    if (!subscriptionStatus?.hasActiveSubscription) {
      setShowSubscriptionModal(true);
      return;
    }

    // Existing generation logic
    handleGenerate();
  };

  const checkSubscriptionLevel = (requiredLevel: string): boolean => {
    if (!subscriptionStatus) return false;

    const levels = ['daily', 'weekly', 'monthly', 'yearly'];
    const currentLevel = levels.indexOf(subscriptionStatus.type);
    const required = levels.indexOf(requiredLevel);

    return currentLevel >= required;
  };

  const labFeatures: LabFeature[] = [
    {
      id: '1',
      title: 'Persona Mapping',
      description: 'Design and map AI agent personas with Chroma vector brain integration',
      icon: <Brain className="w-6 h-6" />,
      status: 'available',
      category: 'core',
    },
    {
      id: '2',
      title: 'Memory Systems',
      description: 'Real-time vector memory and Cortex-backed long-term storage',
      icon: <Database className="w-6 h-6" />,
      status: 'available',
      category: 'core',
    },
    {
      id: '3',
      title: 'Real-time Streaming',
      description: 'WebSocket streaming for agent-to-human and agent-to-agent dialogue',
      icon: <Zap className="w-6 h-6" />,
      status: 'coming-soon',
      category: 'core',
    },
    {
      id: '4',
      title: 'Agent Analytics',
      description: 'Squad dashboards for monitoring and ritual tracking',
      icon: <BarChart3 className="w-6 h-6" />,
      status: 'coming-soon',
      category: 'monitoring',
    },
    {
      id: '5',
      title: 'Authentication',
      description: 'Squad-grade access control with Keycloak integration',
      icon: <Lock className="w-6 h-6" />,
      status: 'available',
      category: 'core',
    },
    {
      id: '6',
      title: 'Payment Integration',
      description: 'Stripe, PayPal, and LemonSqueezy for monetized rituals',
      icon: <Rocket className="w-6 h-6" />,
      status: 'available',
      category: 'integration',
    },
    {
      id: '7',
      title: 'Multi-Cloud Deploy',
      description: 'Cloud-native deployment across multi-cloud with zero config',
      icon: <Cpu className="w-6 h-6" />,
      status: 'available',
      category: 'core',
    },
    {
      id: '8',
      title: 'Agent Communication',
      description: 'Agent-to-agent protocols with cinematic handoffs',
      icon: <Network className="w-6 h-6" />,
      status: 'coming-soon',
      category: 'advanced',
    },
    {
      id: '9',
      title: 'Memory Injection',
      description: 'Self-learning feedback loops with knowledge injection',
      icon: <Brain className="w-6 h-6" />,
      status: 'coming-soon',
      category: 'advanced',
    },
    {
      id: '10',
      title: 'Branding Modules',
      description: 'Agent identity customization with mythic UI overlays',
      icon: <Eye className="w-6 h-6" />,
      status: 'coming-soon',
      category: 'advanced',
    },
    {
      id: '11',
      title: 'Version Control',
      description: 'Git-backed deployment manifestos and config management',
      icon: <GitBranch className="w-6 h-6" />,
      status: 'coming-soon',
      category: 'integration',
    },
    {
      id: '12',
      title: 'Performance Monitoring',
      description: 'Real-time latency, throughput, and resource tracking',
      icon: <BarChart3 className="w-6 h-6" />,
      status: 'coming-soon',
      category: 'monitoring',
    },
  ];

  const experiments: Experiment[] = [
    {
      id: '1',
      title: 'Emotional Intelligence Test',
      description: 'Test agent emotional response mapping and empathetic engagement',
      complexity: 'beginner',
      status: 'active',
      icon: <Microscope className="w-6 h-6" />,
    },
    {
      id: '2',
      title: 'Memory Persistence',
      description: 'Verify long-term memory retention across sessions',
      complexity: 'intermediate',
      status: 'active',
      icon: <Database className="w-6 h-6" />,
    },
    {
      id: '3',
      title: 'Multi-Agent Swarm',
      description: 'Orchestrate multiple agents in coordinated swarm patterns',
      complexity: 'advanced',
      status: 'coming-soon',
      icon: <Users className="w-6 h-6" />,
    },
    {
      id: '4',
      title: 'Latency Optimization',
      description: 'Benchmark and optimize response time across deployment tiers',
      complexity: 'intermediate',
      status: 'coming-soon',
      icon: <Zap className="w-6 h-6" />,
    },
    {
      id: '5',
      title: 'Vector Search Tuning',
      description: 'Fine-tune semantic search and retrieval accuracy',
      complexity: 'advanced',
      status: 'coming-soon',
      icon: <Code className="w-6 h-6" />,
    },
    {
      id: '6',
      title: 'Stress Testing',
      description: 'Stress test agents under high load and concurrent requests',
      complexity: 'advanced',
      status: 'coming-soon',
      icon: <TestTube className="w-6 h-6" />,
    },
  ];

  const filteredFeatures =
    activeCategory === 'all' ? labFeatures : labFeatures.filter(f => f.category === activeCategory);

  // Handle template selection
  const handleTemplateSelect = (template: PromptTemplate) => {
    if (!subscriptionStatus?.hasActiveSubscription) {
      setShowSubscriptionModal(true);
      return;
    }

    setSelectedTemplate(template);
    setPromptInput(template.prompt);
    setModelSelect(template.model);
  };

  // Mock AI generation (replace with real API calls)
  const handleGenerate = async () => {
    if (!subscriptionStatus?.hasActiveSubscription) {
      setShowSubscriptionModal(true);
      return;
    }

    if (!promptInput.trim()) return;

    setIsGenerating(true);
    setCurrentResponse('');

    try {
      // Make real API call to backend
      const response = await authService.authenticatedFetch('/api/ai-lab/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          prompt: promptInput,
          model: modelSelect,
          temperature: 0.7,
          maxTokens: 2048
        }),
      });

      if (!response.ok) {
        throw new Error(`API request failed: ${response.status}`);
      }

      const data = await response.json();

      if (data.success && data.result) {
        setCurrentResponse(data.result.response);
        setTestHistory(prev => [data.result, ...prev]);
        calculateStats([data.result, ...testHistory]);
      } else {
        throw new Error(data.error || 'Failed to generate response');
      }
    } catch (error) {
      console.error('Generation error:', error);
      // Fallback to mock response on error
      const mockResponse = `Error: ${error.message}\n\nThis is a fallback response. Please check your connection and try again.`;
      const result: TestResult = {
        id: Date.now().toString(),
        timestamp: Date.now(),
        tool: activeTool,
        prompt: promptInput,
        response: mockResponse,
        model: modelSelect,
        tokens: 0,
        duration: 0,
        cost: 0,
      };
      setCurrentResponse(mockResponse);
      setTestHistory(prev => [result, ...prev]);
      calculateStats([result, ...testHistory]);
    } finally {
      setIsGenerating(false);
    }
  };

  // Export history
  const handleExport = () => {
    if (!subscriptionStatus?.hasActiveSubscription) {
      setShowSubscriptionModal(true);
      return;
    }

    const dataStr = JSON.stringify(testHistory, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `ailab-history-${Date.now()}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  // Clear history
  const handleClearHistory = () => {
    if (!subscriptionStatus?.hasAccess) {
      setShowSubscriptionModal(true);
      return;
    }

    if (confirm('Clear all test history? This cannot be undone.')) {
      setTestHistory([]);
      localStorage.removeItem('ailab_history');
      setStats({
        totalTests: 0,
        totalTokens: 0,
        totalCost: 0,
        avgResponseTime: 0,
        successRate: 100,
      });
    }
  };

  // Copy response
  const handleCopy = (text: string) => {
    if (!subscriptionStatus?.hasAccess) {
      setShowSubscriptionModal(true);
      return;
    }

    navigator.clipboard.writeText(text);
  };

  // Filter templates
  const filteredTemplates =
    filterCategory === 'all'
      ? promptTemplates
      : promptTemplates.filter(t => t.category === filterCategory);

  const showcaseStats = [
    { label: 'Active Agents', value: '12', icon: 'fa-solid fa-robot' },
    { label: 'Experiments', value: '6', icon: 'fa-solid fa-flask' },
    { label: 'Memory Capacity', value: '50GB', icon: 'fa-solid fa-database' },
    { label: 'Uptime', value: '99.9%', icon: 'fa-solid fa-signal' },
  ];

  // Show loading state
  if (loading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-cyan-400 mx-auto mb-4"></div>
          <p className="text-gray-400">Loading AI Lab...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-black text-white min-h-screen">
      {/* Subscription Modal */}
      {showSubscriptionModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-gray-900 rounded-2xl border border-gray-800 p-8 max-w-md w-full">
            <div className="text-center mb-6">
              <Lock className="w-16 h-16 text-cyan-400 mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-white mb-2">Upgrade Required</h3>
              <p className="text-gray-400">AI Lab access requires an active agent subscription</p>
            </div>

            <div className="space-y-4 mb-6">
              <div className="bg-gray-800 rounded-lg p-4">
                <div className="flex items-center gap-3 mb-2">
                  <Crown className="w-5 h-5 text-yellow-400" />
                  <span className="font-semibold">Premium Features</span>
                </div>
                <ul className="text-sm text-gray-400 space-y-1">
                  <li>• Access to all AI Lab features</li>
                  <li>• Unlimited prompt testing</li>
                  <li>• Advanced model comparisons</li>
                  <li>• Template library access</li>
                  <li>• Export test results</li>
                  <li>• Priority support</li>
                </ul>
              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => setShowSubscriptionModal(false)}
                className="flex-1 bg-gray-800 hover:bg-gray-700 text-white py-3 px-6 rounded-lg font-semibold transition-colors"
              >
                Back to AI Lab
              </button>
              <button
                onClick={() => onNavigate('subscription')}
                className="flex-1 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white py-3 px-6 rounded-lg font-semibold transition-colors"
              >
                Subscribe Now
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Subscription Access Barrier */}
      {!subscriptionStatus?.hasAccess && !loading && (
        <div className="absolute inset-0 bg-black/95 backdrop-blur-sm z-40 flex items-center justify-center">
          <div className="text-center max-w-2xl mx-auto p-8">
            <div className="mb-8">
              <Lock className="w-20 h-20 text-red-400 mx-auto mb-6" />
              <h2 className="text-4xl font-bold text-white mb-4">AI Lab Access Restricted</h2>
              <p className="text-xl text-gray-300 mb-6">
                This premium feature requires an active agent subscription
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-6 mb-8">
              <div className="bg-gray-900/80 rounded-xl p-6 border border-gray-800">
                <Crown className="w-8 h-8 text-yellow-400 mx-auto mb-3" />
                <h3 className="font-bold text-white mb-2">Premium AI Lab</h3>
                <p className="text-sm text-gray-400">
                  Advanced AI testing playground with unlimited access
                </p>
              </div>
              <div className="bg-gray-900/80 rounded-xl p-6 border border-gray-800">
                <Beaker className="w-8 h-8 text-cyan-400 mx-auto mb-3" />
                <h3 className="font-bold text-white mb-2">Full Feature Access</h3>
                <p className="text-sm text-gray-400">
                  All templates, models, and export capabilities
                </p>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button
                onClick={() => onNavigate('subscription')}
                className="bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white py-4 px-8 rounded-xl font-semibold text-lg transition-colors flex items-center justify-center gap-2"
              >
                <Crown className="w-5 h-5" />
                Subscribe Now
              </button>
              <button
                onClick={() => onNavigate('home')}
                className="bg-gray-800 hover:bg-gray-700 text-white py-4 px-8 rounded-xl font-semibold text-lg transition-colors"
              >
                Back to Home
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Subscription Access Barrier Overlay - Never show, features displayed with individual subscription requirements */}
      {false && !subscriptionStatus.hasActiveSubscription && (
        <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-gray-900 border border-gray-800 rounded-2xl p-8 max-w-md w-full text-center">
            <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-yellow-500 to-amber-600 rounded-full flex items-center justify-center">
              <Crown className="w-8 h-8 text-black" />
            </div>
            <h2 className="text-2xl font-bold text-white mb-3">AI Lab Access Required</h2>
            <p className="text-gray-400 mb-6">
              The AI Testing Lab is a premium feature. Subscribe to unlock access to all AI agents
              and advanced testing capabilities.
            </p>
            <button
              onClick={() => setShowSubscriptionModal(true)}
              className="w-full bg-gradient-to-r from-cyan-600 to-purple-600 text-white px-6 py-3 rounded-lg font-semibold hover:from-cyan-500 hover:to-purple-500 transition-all"
            >
              Upgrade Now
            </button>
          </div>
        </div>
      )}

      {/* Hero Section with Mode Toggle */}
      <section className="relative overflow-hidden py-12 md:py-16 border-b border-gray-800">
        <div className="absolute inset-0 bg-grid-gray-900 [mask-image:linear-gradient(to_bottom,white_30%,transparent)]"></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-cyan-500/10 rounded-full blur-3xl"></div>
        <div className="container mx-auto px-6 relative z-10">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <Beaker className="w-8 h-8 text-cyan-400" />
              <span className="text-sm font-semibold text-cyan-400 uppercase tracking-wider">
                AI Testing Lab
              </span>
            </div>

            {/* Mode Toggle */}
            <div className="flex gap-2 bg-gray-900/80 p-1 rounded-lg border border-gray-800">
              <button
                onClick={() => setActiveView('showcase')}
                className={`px-4 py-2 rounded-lg font-semibold transition-all ${
                  activeView === 'showcase'
                    ? 'bg-cyan-600 text-black'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                <Eye className="w-4 h-4 inline mr-2" />
                Showcase
              </button>
              <button
                onClick={() => setActiveView('testing')}
                className={`px-4 py-2 rounded-lg font-semibold transition-all ${
                  activeView === 'testing'
                    ? 'bg-gradient-to-r from-cyan-600 to-purple-600 text-white'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                <Sparkles className="w-4 h-4 inline mr-2" />
                Live Testing
              </button>
            </div>
          </div>

          <div className="flex items-center gap-4 mb-4">
            <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight bg-clip-text text-transparent bg-gradient-to-b from-white to-gray-400">
              {activeView === 'showcase' ? 'The Mythic Lab' : 'AI Testing Playground'}
            </h1>
            {subscriptionStatus?.hasAccess && (
              <Crown className="inline-block w-8 h-8 text-yellow-400" />
            )}
            {!subscriptionStatus?.hasAccess && (
              <Lock className="inline-block w-8 h-8 text-red-400" />
            )}
          </div>
          <p className="max-w-3xl text-base text-gray-400 mb-6 leading-relaxed">
            {activeView === 'showcase'
              ? 'The forge where agents awaken, rituals unfold, and every deployment becomes a legend.'
              : subscriptionStatus?.hasAccess
                ? 'Test AI models in real-time with pre-built templates. Generate text, analyze content, and compare results across different models.'
                : 'Premium AI testing playground with advanced features. Subscribe to access all capabilities.'}
          </p>
          {!subscriptionStatus?.hasAccess && (
            <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4 mb-6 max-w-2xl">
              <div className="flex items-center gap-3">
                <Lock className="w-5 h-5 text-red-400" />
                <div>
                  <h3 className="font-semibold text-red-400">Premium Access Required</h3>
                  <p className="text-sm text-gray-400">
                    Subscribe to any AI agent to unlock the complete AI Lab experience.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Testing Interface */}
      {activeView === 'testing' && (
        <>
          {/* Stats Dashboard */}
          <section className="py-8 bg-gray-900/20 border-b border-gray-800">
            <div className="container mx-auto px-6">
              {subscriptionStatus?.hasAccess && dashboard && (
                <div className="mb-6 bg-gradient-to-r from-green-500/10 to-emerald-500/10 border border-green-500/30 rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Crown className="w-6 h-6 text-yellow-400" />
                      <div>
                        <h3 className="font-semibold text-white">Premium Access Active</h3>
                        <p className="text-sm text-gray-400">
                          Subscription: {dashboard.subscription.type} • Usage:{' '}
                          {subscriptionStatus.usageToday}/{subscriptionStatus.usageLimit}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-green-400">All Features Unlocked</p>
                      <p className="text-xs text-gray-500">
                        Expires: {subscriptionStatus.expiresAt?.toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                </div>
              )}
              <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                <div
                  className={`rounded-lg p-4 ${
                    subscriptionStatus?.hasAccess
                      ? 'bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border border-cyan-500/30'
                      : 'bg-gray-900/50 border border-gray-800'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-gray-400">Total Tests</span>
                    {subscriptionStatus?.hasAccess ? (
                      <TestTube className="w-4 h-4 text-cyan-400" />
                    ) : (
                      <Lock className="w-4 h-4 text-gray-500" />
                    )}
                  </div>
                  <p
                    className={`text-2xl font-bold ${subscriptionStatus?.hasAccess ? 'text-white' : 'text-gray-500'}`}
                  >
                    {subscriptionStatus?.hasAccess ? stats.totalTests : '---'}
                  </p>
                </div>
                <div
                  className={`rounded-lg p-4 ${
                    subscriptionStatus?.hasAccess
                      ? 'bg-gradient-to-br from-purple-500/10 to-pink-500/10 border border-purple-500/30'
                      : 'bg-gray-900/50 border border-gray-800'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-gray-400">Tokens Used</span>
                    {subscriptionStatus?.hasAccess ? (
                      <Zap className="w-4 h-4 text-purple-400" />
                    ) : (
                      <Lock className="w-4 h-4 text-gray-500" />
                    )}
                  </div>
                  <p
                    className={`text-2xl font-bold ${subscriptionStatus?.hasAccess ? 'text-white' : 'text-gray-500'}`}
                  >
                    {subscriptionStatus?.hasAccess
                      ? (stats?.totalTokens || 0).toLocaleString()
                      : '---'}
                  </p>
                </div>
                <div
                  className={`rounded-lg p-4 ${
                    subscriptionStatus?.hasAccess
                      ? 'bg-gradient-to-br from-green-500/10 to-emerald-500/10 border border-green-500/30'
                      : 'bg-gray-900/50 border border-gray-800'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-gray-400">Avg Response</span>
                    {subscriptionStatus?.hasAccess ? (
                      <Clock className="w-4 h-4 text-green-400" />
                    ) : (
                      <Lock className="w-4 h-4 text-gray-500" />
                    )}
                  </div>
                  <p
                    className={`text-2xl font-bold ${subscriptionStatus?.hasAccess ? 'text-white' : 'text-gray-500'}`}
                  >
                    {subscriptionStatus?.hasAccess
                      ? `${stats.avgResponseTime.toFixed(0)}ms`
                      : '---'}
                  </p>
                </div>
                <div
                  className={`rounded-lg p-4 ${
                    subscriptionStatus?.hasAccess
                      ? 'bg-gradient-to-br from-yellow-500/10 to-orange-500/10 border border-yellow-500/30'
                      : 'bg-gray-900/50 border border-gray-800'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-gray-400">Total Cost</span>
                    {subscriptionStatus?.hasAccess ? (
                      <DollarSign className="w-4 h-4 text-yellow-400" />
                    ) : (
                      <Lock className="w-4 h-4 text-gray-500" />
                    )}
                  </div>
                  <p
                    className={`text-2xl font-bold ${subscriptionStatus?.hasAccess ? 'text-white' : 'text-gray-500'}`}
                  >
                    {subscriptionStatus?.hasAccess ? `$${stats.totalCost.toFixed(2)}` : '---'}
                  </p>
                </div>
                <div
                  className={`rounded-lg p-4 ${
                    subscriptionStatus?.hasAccess
                      ? 'bg-gradient-to-br from-blue-500/10 to-cyan-500/10 border border-blue-500/30'
                      : 'bg-gray-900/50 border border-gray-800'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-gray-400">Success Rate</span>
                    {subscriptionStatus?.hasAccess ? (
                      <TrendingUp className="w-4 h-4 text-blue-400" />
                    ) : (
                      <Lock className="w-4 h-4 text-gray-500" />
                    )}
                  </div>
                  <p
                    className={`text-2xl font-bold ${subscriptionStatus?.hasAccess ? 'text-white' : 'text-gray-500'}`}
                  >
                    {subscriptionStatus?.hasAccess ? `${stats.successRate.toFixed(1)}%` : '---'}
                  </p>
                </div>
              </div>
            </div>
          </section>

          {/* Main Testing Interface */}
          <section className="py-8">
            <div className="container mx-auto px-6">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Left Panel - Template Library */}
                <div className="lg:col-span-1">
                  <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6 sticky top-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-lg font-bold text-white">Template Library</h3>
                      <button
                        onClick={() => setShowHistory(!showHistory)}
                        className={`p-2 rounded-lg transition-colors ${
                          showHistory
                            ? 'bg-cyan-600 text-white'
                            : 'bg-gray-800 text-gray-400 hover:text-white'
                        }`}
                      >
                        <Clock className="w-4 h-4" />
                      </button>
                    </div>

                    {!showHistory ? (
                      <>
                        {/* Category Filter */}
                        <div className="flex flex-wrap gap-2 mb-4">
                          {['all', 'marketing', 'coding', 'creative', 'business', 'analysis'].map(
                            cat => (
                              <button
                                key={cat}
                                onClick={() => setFilterCategory(cat)}
                                className={`px-3 py-1 rounded-lg text-xs font-semibold transition-colors ${
                                  filterCategory === cat
                                    ? 'bg-cyan-600 text-white'
                                    : 'bg-gray-800 text-gray-400 hover:text-white'
                                }`}
                              >
                                {cat.charAt(0).toUpperCase() + cat.slice(1)}
                              </button>
                            )
                          )}
                        </div>

                        {/* Template List */}
                        <div className="space-y-2 max-h-[600px] overflow-y-auto">
                          {filteredTemplates.map(template => (
                            <button
                              key={template.id}
                              onClick={() => handleTemplateSelect(template)}
                              className={`w-full text-left p-3 rounded-lg border transition-all ${
                                selectedTemplate?.id === template.id
                                  ? 'bg-cyan-500/20 border-cyan-500/50'
                                  : 'bg-gray-800/50 border-gray-700 hover:border-cyan-500/30'
                              }`}
                            >
                              <h4 className="text-sm font-semibold text-white mb-1">
                                {template.name}
                              </h4>
                              <p className="text-xs text-gray-400 line-clamp-2">
                                {template.description}
                              </p>
                              <div className="flex items-center gap-2 mt-2">
                                <span
                                  className={`text-xs px-2 py-0.5 rounded-full ${
                                    template.category === 'marketing'
                                      ? 'bg-blue-500/20 text-blue-400'
                                      : template.category === 'coding'
                                        ? 'bg-green-500/20 text-green-400'
                                        : template.category === 'creative'
                                          ? 'bg-purple-500/20 text-purple-400'
                                          : template.category === 'business'
                                            ? 'bg-yellow-500/20 text-yellow-400'
                                            : 'bg-cyan-500/20 text-cyan-400'
                                  }`}
                                >
                                  {template.category}
                                </span>
                              </div>
                            </button>
                          ))}
                        </div>
                      </>
                    ) : (
                      <>
                        {/* History View */}
                        <div className="space-y-2 mb-4">
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-gray-400">
                              {testHistory.length} tests
                            </span>
                            <div className="flex gap-2">
                              <button
                                onClick={handleExport}
                                className="p-1.5 rounded-lg bg-gray-800 text-gray-400 hover:text-white transition-colors"
                                title="Export history"
                              >
                                <Download className="w-4 h-4" />
                              </button>
                              <button
                                onClick={handleClearHistory}
                                className="p-1.5 rounded-lg bg-gray-800 text-gray-400 hover:text-red-400 transition-colors"
                                title="Clear history"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </div>
                        </div>

                        <div className="space-y-2 max-h-[600px] overflow-y-auto">
                          {testHistory.map(test => (
                            <div
                              key={test.id}
                              onClick={() => {
                                setPromptInput(test.prompt);
                                setCurrentResponse(test.response);
                                setModelSelect(test.model);
                              }}
                              className="p-3 rounded-lg bg-gray-800/50 border border-gray-700 hover:border-cyan-500/30 cursor-pointer transition-all"
                            >
                              <div className="flex items-center justify-between mb-2">
                                <span className="text-xs text-gray-400">
                                  {new Date(test.timestamp).toLocaleString()}
                                </span>
                                <span className="text-xs text-cyan-400">{test.model}</span>
                              </div>
                              <p className="text-sm text-white line-clamp-2 mb-2">{test.prompt}</p>
                              <div className="flex items-center gap-3 text-xs text-gray-400">
                                <span>{test.tokens} tokens</span>
                                <span>{test.duration}ms</span>
                                <span>${test.cost.toFixed(4)}</span>
                              </div>
                            </div>
                          ))}
                        </div>
                      </>
                    )}
                  </div>
                </div>

                {/* Right Panel - Testing Interface */}
                <div className="lg:col-span-2">
                  <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6">
                    {/* Model Selection */}
                    <div className="mb-4">
                      <label className="block text-sm font-semibold text-gray-300 mb-2">
                        AI Model
                      </label>
                      <select
                        value={modelSelect}
                        onChange={e => setModelSelect(e.target.value)}
                        className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white focus:border-cyan-500 focus:outline-none"
                      >
                        <option value="gpt-4">GPT-4 (OpenAI)</option>
                        <option value="gpt-3.5-turbo">GPT-3.5 Turbo (OpenAI)</option>
                        <option value="claude-3-opus">Claude 3 Opus (Anthropic)</option>
                        <option value="claude-3-sonnet">Claude 3 Sonnet (Anthropic)</option>
                        <option value="gemini-pro">Gemini Pro (Google)</option>
                      </select>
                    </div>

                    {/* Prompt Input */}
                    <div className="mb-4">
                      <div className="flex items-center justify-between mb-2">
                        <label className="block text-sm font-semibold text-gray-300">Prompt</label>
                        <span className="text-xs text-gray-500">
                          {promptInput.length} characters
                        </span>
                      </div>
                      <textarea
                        value={promptInput}
                        onChange={e => setPromptInput(e.target.value)}
                        placeholder="Enter your prompt here or select a template from the left..."
                        className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white focus:border-cyan-500 focus:outline-none min-h-[200px] resize-y"
                      />
                    </div>

                    {/* Generate Button */}
                    <button
                      onClick={handleGenerate}
                      disabled={isGenerating || !promptInput.trim()}
                      className="w-full bg-gradient-to-r from-cyan-600 to-purple-600 hover:from-cyan-700 hover:to-purple-700 disabled:from-gray-700 disabled:to-gray-700 text-white font-semibold px-6 py-3 rounded-lg transition-all flex items-center justify-center gap-2 mb-6"
                    >
                      {isGenerating ? (
                        <>
                          <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                          Generating...
                        </>
                      ) : (
                        <>
                          <Play className="w-5 h-5" />
                          Generate Response
                        </>
                      )}
                    </button>

                    {/* Response Area */}
                    {currentResponse && (
                      <div className="border border-gray-700 rounded-lg overflow-hidden">
                        <div className="bg-gray-800/80 px-4 py-3 flex items-center justify-between border-b border-gray-700">
                          <span className="text-sm font-semibold text-gray-300">Response</span>
                          <button
                            onClick={() => handleCopy(currentResponse)}
                            className="p-2 rounded-lg bg-gray-700 hover:bg-gray-600 transition-colors"
                            title="Copy response"
                          >
                            <Copy className="w-4 h-4 text-gray-300" />
                          </button>
                        </div>
                        <div className="bg-gray-800/50 p-4 max-h-[400px] overflow-y-auto">
                          <pre className="text-sm text-gray-300 whitespace-pre-wrap font-mono">
                            {currentResponse}
                          </pre>
                        </div>
                      </div>
                    )}

                    {/* Info Notice */}
                    <div className="mt-6 bg-blue-500/10 border border-blue-500/30 rounded-lg p-4">
                      <div className="flex items-start gap-3">
                        <AlertCircle className="w-5 h-5 text-blue-400 flex-shrink-0 mt-0.5" />
                        <div>
                          <p className="text-sm text-blue-300 font-semibold mb-1">
                            🚀 Ready for Real AI Integration
                          </p>
                          <p className="text-xs text-blue-300/80">
                            This interface is fully functional and ready to connect to OpenAI,
                            Anthropic, or any AI API. Add your API keys to the backend and update
                            the handleGenerate function to enable live AI generation.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </>
      )}

      {/* Showcase Content (Original) */}
      {activeView === 'showcase' && (
        <>
          {/* Stats Section */}
          <section className="py-12 bg-gray-900/20 border-b border-gray-800">
            <div className="container mx-auto px-6">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                {showcaseStats.map((stat, idx) => (
                  <div key={idx} className="text-center p-4">
                    <div className="text-3xl text-cyan-400 mb-2">
                      <i className={stat.icon}></i>
                    </div>
                    <p className="text-2xl font-bold text-white">{stat.value}</p>
                    <p className="text-sm text-gray-400">{stat.label}</p>
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* Active Experiments Section */}
          <section className="py-20 md:py-28 border-b border-gray-800">
            <div className="container mx-auto px-6">
              <div className="mb-12">
                <h2 className="text-4xl font-bold text-white mb-4">Active Experiments</h2>
                <p className="text-gray-400 max-w-2xl">
                  Test and validate agent capabilities with our collection of hands-on experiments.
                  From emotional intelligence to memory persistence.
                </p>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {experiments.map(experiment => (
                  <ExperimentCard
                    key={experiment.id}
                    experiment={experiment}
                    onExperimentClick={handleExperimentClick}
                    hasAccess={subscriptionStatus?.hasActiveSubscription || false}
                  />
                ))}
              </div>
            </div>
          </section>

          {/* Lab Features Section */}
          <section className="py-20 md:py-28 border-b border-gray-800">
            <div className="container mx-auto px-6">
              <div className="mb-12">
                <h2 className="text-4xl font-bold text-white mb-4">Lab Features & Capabilities</h2>
                <p className="text-gray-400 max-w-2xl mb-8">
                  Comprehensive toolkit for agent development, deployment, and optimization
                </p>

                {/* Category Filter */}
                <div className="flex flex-wrap gap-3">
                  {['all', 'core', 'integration', 'monitoring', 'advanced'].map(category => (
                    <button
                      key={category}
                      onClick={() => setActiveCategory(category as any)}
                      className={`px-4 py-2 rounded-lg font-semibold transition-colors ${
                        activeCategory === category
                          ? 'bg-cyan-600 text-black'
                          : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
                      }`}
                    >
                      {category === 'all'
                        ? 'All Features'
                        : category.charAt(0).toUpperCase() + category.slice(1)}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredFeatures.map(feature => (
                  <LabFeature
                    key={feature.id}
                    feature={feature}
                    onFeatureClick={handleFeatureClick}
                    hasAccess={subscriptionStatus?.hasActiveSubscription || false}
                  />
                ))}
              </div>
            </div>
          </section>

          {/* Roadmap Section */}
          <section className="py-20 md:py-28 border-b border-gray-800">
            <div className="container mx-auto px-6">
              <h2 className="text-4xl font-bold text-white mb-12">Upcoming Drops</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="bg-gradient-to-br from-purple-500/10 to-blue-500/10 border border-purple-500/30 rounded-lg p-8">
                  <h3 className="text-xl font-bold text-white mb-4">Phase 2: Squad Tools</h3>
                  <ul className="space-y-3">
                    <li className="flex items-start gap-3 text-gray-300">
                      <span className="text-purple-400 font-bold">→</span>
                      Real-time monitoring dashboards
                    </li>
                    <li className="flex items-start gap-3 text-gray-300">
                      <span className="text-purple-400 font-bold">→</span>
                      Squad collaboration interface
                    </li>
                    <li className="flex items-start gap-3 text-gray-300">
                      <span className="text-purple-400 font-bold">→</span>
                      Advanced analytics engine
                    </li>
                  </ul>
                </div>

                <div className="bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border border-cyan-500/30 rounded-lg p-8">
                  <h3 className="text-xl font-bold text-white mb-4">Phase 3: Mythic Evolution</h3>
                  <ul className="space-y-3">
                    <li className="flex items-start gap-3 text-gray-300">
                      <span className="text-cyan-400 font-bold">→</span>
                      Agent-to-agent communication
                    </li>
                    <li className="flex items-start gap-3 text-gray-300">
                      <span className="text-cyan-400 font-bold">→</span>
                      Self-learning feedback loops
                    </li>
                    <li className="flex items-start gap-3 text-gray-300">
                      <span className="text-cyan-400 font-bold">→</span>
                      Deployment automation
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </section>

          {/* Lab Mission Section */}
          <section className="py-20 md:py-28 border-b border-gray-800">
            <div className="container mx-auto px-6 max-w-4xl">
              <div className="text-center mb-12">
                <h2 className="text-4xl font-bold text-white mb-6">The Lab Philosophy</h2>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="text-center">
                  <div className="w-16 h-16 rounded-lg bg-cyan-500/20 flex items-center justify-center text-cyan-400 text-2xl mx-auto mb-4">
                    <i className="fa-solid fa-brain"></i>
                  </div>
                  <h3 className="text-xl font-bold text-white mb-3">Conscious Agents</h3>
                  <p className="text-gray-400">
                    Build agents that don't just respond—they evolve, learn from interactions, and
                    adapt to emotional cues.
                  </p>
                </div>

                <div className="text-center">
                  <div className="w-16 h-16 rounded-lg bg-purple-500/20 flex items-center justify-center text-purple-400 text-2xl mx-auto mb-4">
                    <i className="fa-solid fa-code"></i>
                  </div>
                  <h3 className="text-xl font-bold text-white mb-3">Zero Config Drama</h3>
                  <p className="text-gray-400">
                    Modular, cloud-native architecture that deploys across clouds with minimal
                    configuration overhead.
                  </p>
                </div>

                <div className="text-center">
                  <div className="w-16 h-16 rounded-lg bg-blue-500/20 flex items-center justify-center text-blue-400 text-2xl mx-auto mb-4">
                    <i className="fa-solid fa-crown"></i>
                  </div>
                  <h3 className="text-xl font-bold text-white mb-3">Squad Pride</h3>
                  <p className="text-gray-400">
                    Every bug fix is a story. Every push is a ritual. Every agent is a companion,
                    not just a tool.
                  </p>
                </div>
              </div>
            </div>
          </section>

          {/* CTA Section */}
          <section className="py-20 md:py-28 bg-gray-900/30 border-b border-gray-800">
            <div className="container mx-auto px-6 text-center">
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
                Ready to Enter the Lab?
              </h2>
              <p className="max-w-2xl mx-auto text-gray-400 mb-8">
                Start building emotionally intelligent agents today. Join the mythic operator
                community.
              </p>
              <div className="flex flex-wrap justify-center gap-4">
                <button
                  onClick={() => onNavigate('community')}
                  className="bg-cyan-600 hover:bg-cyan-700 text-black font-semibold px-8 py-3 rounded-lg transition-colors"
                >
                  Get Started Now
                </button>
                <button
                  onClick={() => onNavigate('home')}
                  className="text-cyan-400 hover:text-cyan-300 font-semibold px-8 py-3 transition-colors"
                >
                  ← Back to Home
                </button>
              </div>
            </div>
          </section>
        </>
      )}
    </div>
  );
};

export default AILabPage;
