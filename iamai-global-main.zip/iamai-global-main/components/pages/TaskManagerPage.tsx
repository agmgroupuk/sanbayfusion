import React, { useState, useMemo } from 'react';
import { Page } from '../../App';

interface TaskManagerPageProps {
  onNavigate: (page: Page) => void;
}

interface Task {
  id: number;
  title: string;
  description: string;
  status: 'To Do' | 'In Progress' | 'Done';
  priority: 'Low' | 'Medium' | 'High';
  creationDate: string; // ISO string
  dueDate: string; // ISO string
}

const mockTasks: Task[] = [
  { id: 1, title: 'Deploy frontend updates', description: 'Push the latest UI changes to production.', status: 'To Do', priority: 'High', creationDate: '2024-07-28T10:00:00Z', dueDate: '2024-07-30T23:59:59Z' },
  { id: 2, title: 'Fix API authentication bug', description: 'Users are reporting 401 errors on the /me endpoint.', status: 'In Progress', priority: 'High', creationDate: '2024-07-27T14:00:00Z', dueDate: '2024-07-29T17:00:00Z' },
  { id: 3, title: 'Update documentation for new agent', description: 'Add a new section for the CVSmash agent in the docs.', status: 'Done', priority: 'Medium', creationDate: '2024-07-25T09:00:00Z', dueDate: '2024-07-28T23:59:59Z' },
  { id: 4, title: 'Research new AI models', description: 'Investigate performance of Llama 3.2 vs Gemma 2 for summarization.', status: 'To Do', priority: 'Medium', creationDate: '2024-07-29T11:00:00Z', dueDate: '2024-08-05T23:59:59Z' },
  { id: 5, title: 'Refactor chat component state', description: 'Improve state management in the ChatArea component.', status: 'To Do', priority: 'Low', creationDate: '2024-07-26T16:00:00Z', dueDate: '2024-08-02T23:59:59Z' },
  { id: 6, title: 'Plan Q4 roadmap', description: 'Outline key features and initiatives for the upcoming quarter.', status: 'In Progress', priority: 'High', creationDate: '2024-07-20T10:00:00Z', dueDate: '2024-08-15T23:59:59Z' },
  { id: 7, title: 'Onboard new developer', description: 'Set up environment and provide initial training.', status: 'Done', priority: 'Medium', creationDate: '2024-07-22T09:00:00Z', dueDate: '2024-07-24T23:59:59Z' },
  { id: 8, title: 'Organize team offsite event', description: 'Coordinate logistics for the yearly team gathering.', status: 'To Do', priority: 'Low', creationDate: '2024-07-29T15:00:00Z', dueDate: '2024-09-01T23:59:59Z' },
];

const statusColors: Record<Task['status'], string> = {
  'To Do': 'bg-gray-500/20 text-gray-300 dark:bg-gray-600/30 dark:text-gray-300',
  'In Progress': 'bg-yellow-500/20 text-yellow-400 dark:bg-yellow-600/30 dark:text-yellow-300',
  'Done': 'bg-green-500/20 text-green-400 dark:bg-green-600/30 dark:text-green-300',
};

const priorityColors: Record<Task['priority'], string> = {
  'Low': 'bg-cyan-500/20 text-cyan-400 dark:bg-cyan-600/30 dark:text-cyan-300',
  'Medium': 'bg-orange-500/20 text-orange-400 dark:bg-orange-600/30 dark:text-orange-300',
  'High': 'bg-red-500/20 text-red-400 dark:bg-red-600/30 dark:text-red-300',
};

const TaskCard: React.FC<{ task: Task }> = ({ task }) => (
  <div className="bg-white dark:bg-gray-900/50 border border-gray-200 dark:border-gray-800 rounded-xl p-5 flex flex-col space-y-4 hover:border-cyan-500/30 transition-all duration-300">
    <div className="flex justify-between items-start">
      <h3 className="font-bold text-gray-900 dark:text-white text-lg">{task.title}</h3>
      <div className={`px-2 py-0.5 text-xs font-semibold rounded-full ${priorityColors[task.priority]}`}>{task.priority}</div>
    </div>
    <p className="text-gray-600 dark:text-gray-400 text-sm flex-grow">{task.description}</p>
    <div className="pt-4 border-t border-gray-200 dark:border-gray-800 space-y-2">
       <div className="flex items-center justify-between text-xs text-gray-500 dark:text-gray-500">
        <span className="font-semibold">Status</span>
        <div className={`px-2 py-0.5 font-semibold rounded-full ${statusColors[task.status]}`}>{task.status}</div>
      </div>
      <div className="flex items-center justify-between text-xs text-gray-500 dark:text-gray-500">
        <span className="font-semibold">Due Date</span>
        <span>{new Date(task.dueDate).toLocaleDateString()}</span>
      </div>
      <div className="flex items-center justify-between text-xs text-gray-500 dark:text-gray-500">
        <span className="font-semibold">Created</span>
        <span>{new Date(task.creationDate).toLocaleDateString()}</span>
      </div>
    </div>
  </div>
);

const SummaryCard: React.FC<{ title: string; value: string | number; icon: string; color: string }> = ({ title, value, icon, color }) => (
    <div className="bg-white dark:bg-gray-900/50 border border-gray-200 dark:border-gray-800 rounded-xl p-5">
        <div className="flex items-center">
            <div className={`w-12 h-12 rounded-lg flex items-center justify-center mr-4 ${color}`}>
                <i className={`fa-solid ${icon} text-2xl`}></i>
            </div>
            <div>
                <p className="text-sm text-gray-500 dark:text-gray-400">{title}</p>
                <p className="text-3xl font-bold text-gray-900 dark:text-white">{value}</p>
            </div>
        </div>
    </div>
);


const TaskManagerPage: React.FC<TaskManagerPageProps> = ({ onNavigate }) => {
  const [tasks, setTasks] = useState<Task[]>(mockTasks);
  const [filterStatus, setFilterStatus] = useState<'all' | Task['status']>('all');
  const [sortBy, setSortBy] = useState<'creationDate' | 'dueDate' | 'priority'>('creationDate');

  const displayedTasks = useMemo(() => {
    const priorityMap: Record<Task['priority'], number> = { 'Low': 1, 'Medium': 2, 'High': 3 };

    return tasks
      .filter(task => filterStatus === 'all' || task.status === filterStatus)
      .sort((a, b) => {
        switch (sortBy) {
          case 'priority':
            return priorityMap[b.priority] - priorityMap[a.priority];
          case 'dueDate':
            return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
          case 'creationDate':
          default:
            return new Date(b.creationDate).getTime() - new Date(a.creationDate).getTime();
        }
      });
  }, [tasks, filterStatus, sortBy]);
  
  const FilterButton: React.FC<{ status: 'all' | Task['status'], label: string }> = ({ status, label }) => {
    const isActive = filterStatus === status;
    return (
        <button
            onClick={() => setFilterStatus(status)}
            className={`px-4 py-2 text-sm font-semibold rounded-lg transition-colors ${
                isActive
                ? 'bg-cyan-500 text-black'
                : 'bg-gray-200 dark:bg-gray-800 text-gray-800 dark:text-gray-300 hover:bg-gray-300 dark:hover:bg-gray-700'
            }`}
        >
            {label}
        </button>
    );
  };

  const totalTasks = mockTasks.length;
  const completedTasks = mockTasks.filter(t => t.status === 'Done').length;
  const pendingTasks = totalTasks - completedTasks;
  const overdueTasks = mockTasks.filter(t => t.status !== 'Done' && new Date(t.dueDate) < new Date()).length;
  const completionPercentage = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;


  return (
    <div className="py-20 md:py-28 bg-white dark:bg-black flex-1">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white">Task Manager</h1>
            <p className="max-w-2xl mx-auto mt-4 text-gray-600 dark:text-gray-400">
                Organize, filter, and sort your project tasks efficiently.
            </p>
        </div>

        <div className="mb-10">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
                <SummaryCard title="Total Tasks" value={totalTasks} icon="fa-list-check" color="bg-blue-500/20 text-blue-400" />
                <SummaryCard title="Completed" value={completedTasks} icon="fa-check-double" color="bg-green-500/20 text-green-400" />
                <SummaryCard title="Pending" value={pendingTasks} icon="fa-clock" color="bg-yellow-500/20 text-yellow-400" />
                <SummaryCard title="Overdue" value={overdueTasks} icon="fa-triangle-exclamation" color="bg-red-500/20 text-red-400" />
            </div>
            <div>
                <div className="flex justify-between items-center mb-2">
                    <span className="text-sm font-medium text-gray-600 dark:text-gray-400">Completion Progress</span>
                    <span className="text-sm font-bold text-gray-900 dark:text-white">{completionPercentage}%</span>
                </div>
                <div className="w-full bg-gray-200 dark:bg-gray-800 rounded-full h-2.5">
                    <div className="bg-cyan-500 h-2.5 rounded-full" style={{ width: `${completionPercentage}%`, transition: 'width 0.5s ease-in-out' }}></div>
                </div>
            </div>
        </div>
        
        <div className="flex flex-col md:flex-row justify-between items-center mb-8 p-4 bg-gray-100 dark:bg-gray-900/50 border border-gray-200 dark:border-gray-800 rounded-xl gap-4">
            <div className="flex items-center gap-2 flex-wrap">
                <span className="text-sm font-semibold text-gray-500 dark:text-gray-400 mr-2">Filter by:</span>
                <FilterButton status="all" label="All" />
                <FilterButton status="To Do" label="To Do" />
                <FilterButton status="In Progress" label="In Progress" />
                <FilterButton status="Done" label="Done" />
            </div>
            
            <div className="flex items-center gap-2">
                <label htmlFor="sort-by" className="text-sm font-semibold text-gray-500 dark:text-gray-400">Sort by:</label>
                <select
                    id="sort-by"
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
                    className="bg-gray-100 dark:bg-gray-800 border border-gray-300 dark:border-gray-700 text-gray-900 dark:text-white text-sm rounded-lg focus:ring-cyan-500 focus:border-cyan-500 block p-2"
                >
                    <option value="creationDate">Creation Date</option>
                    <option value="dueDate">Due Date</option>
                    <option value="priority">Priority</option>
                </select>
            </div>
        </div>

        {displayedTasks.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {displayedTasks.map(task => <TaskCard key={task.id} task={task} />)}
            </div>
        ) : (
            <div className="text-center py-16 bg-gray-100 dark:bg-gray-900/50 border border-gray-200 dark:border-gray-800 rounded-xl">
                <i className="fa-solid fa-folder-open text-5xl text-gray-400 dark:text-gray-600 mb-4"></i>
                <h3 className="text-xl font-bold text-gray-900 dark:text-white">No Tasks Found</h3>
                <p className="text-gray-600 dark:text-gray-400 mt-2">There are no tasks matching your current filters.</p>
            </div>
        )}
      </div>
    </div>
  );
};

export default TaskManagerPage;