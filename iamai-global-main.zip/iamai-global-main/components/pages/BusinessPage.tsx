import React, { useState } from 'react';
import { Page } from '../../App';
import { Check, X } from 'lucide-react';

interface BusinessPageProps {
  onNavigate: (page: Page) => void;
}

const FeatureCard: React.FC<{ icon: string; title: string; description: string }> = ({ icon, title, description }) => (
  <div className="bg-gray-900/50 p-8 rounded-xl border border-gray-800 hover:border-cyan-500/50 transition-all duration-300">
    <div className="w-12 h-12 flex items-center justify-center rounded-lg bg-cyan-500/20 text-cyan-400 mb-4">
      <i className={`${icon} text-2xl`}></i>
    </div>
    <h3 className="text-lg font-bold text-white mb-2">{title}</h3>
    <p className="text-gray-400">{description}</p>
  </div>
);

const PricingTier: React.FC<{ name: string; price: string; description: string; features: string[]; isPopular?: boolean; onSelect: () => void }> = ({ name, price, description, features, isPopular, onSelect }) => (
  <div className={`relative rounded-2xl border transition-all duration-300 ${isPopular ? 'border-cyan-500 bg-cyan-500/5 transform scale-105' : 'border-gray-800 bg-gray-900/50 hover:border-cyan-500/50'}`}>
    {isPopular && (
      <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-cyan-500 text-black px-4 py-1 rounded-full text-xs font-bold">
        MOST POPULAR
      </div>
    )}
    <div className="p-8">
      <h3 className="text-2xl font-bold text-white mb-2">{name}</h3>
      <p className="text-gray-400 mb-6">{description}</p>
      <div className="mb-6">
        <span className="text-4xl font-bold text-white">${price}</span>
        <span className="text-gray-400 ml-2">/month</span>
      </div>
      <button
        onClick={onSelect}
        className={`w-full py-3 rounded-lg font-semibold transition-all duration-300 mb-6 ${
          isPopular 
            ? 'bg-cyan-500 text-black hover:bg-cyan-400' 
            : 'bg-gray-800 text-white hover:bg-gray-700'
        }`}
      >
        Available Soon
      </button>
      <div className="space-y-4">
        {features.map((feature, idx) => (
          <div key={idx} className="flex items-start gap-3">
            <Check className="w-5 h-5 text-cyan-400 flex-shrink-0 mt-0.5" />
            <span className="text-gray-300">{feature}</span>
          </div>
        ))}
      </div>
    </div>
  </div>
);

const CaseStudy: React.FC<{ company: string; industry: string; result: string; description: string; icon: string }> = ({ company, industry, result, description, icon }) => (
  <div className="bg-gradient-to-br from-gray-900/50 to-gray-800/30 p-8 rounded-xl border border-gray-800 hover:border-cyan-500/50 transition-all duration-300">
    <div className="flex items-start justify-between mb-6">
      <div>
        <h3 className="text-xl font-bold text-white">{company}</h3>
        <p className="text-cyan-400 text-sm">{industry}</p>
      </div>
      <div className="w-12 h-12 flex items-center justify-center rounded-lg bg-cyan-500/20 text-cyan-400">
        <i className={`${icon} text-2xl`}></i>
      </div>
    </div>
    <p className="text-gray-300 mb-4">{description}</p>
    <div className="pt-4 border-t border-gray-700">
      <p className="text-sm text-gray-400 mb-2">Result:</p>
      <p className="text-cyan-400 font-semibold">{result}</p>
    </div>
  </div>
);

const BusinessPage: React.FC<BusinessPageProps> = ({ onNavigate }) => {
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);

  const enterprises = [
    { icon: 'fa-solid fa-building', title: 'Enterprise Automation', description: 'Scale operations with AI-powered workflows and intelligent process automation.' },
    { icon: 'fa-solid fa-chart-line', title: 'Business Analytics', description: 'Real-time insights and data-driven decision making with AI analysis.' },
    { icon: 'fa-solid fa-shield-halved', title: 'Security & Compliance', description: 'Enterprise-grade security with full compliance and audit trails.' },
    { icon: 'fa-solid fa-users', title: 'Team Collaboration', description: 'AI-enhanced collaboration tools for remote and distributed teams.' },
    { icon: 'fa-solid fa-headset', title: '24/7 Support', description: 'Dedicated support team and rapid response to enterprise needs.' },
    { icon: 'fa-solid fa-code', title: 'API Integration', description: 'Seamless integration with existing enterprise systems and workflows.' },
  ];

  const pricingTiers = [
    {
      name: 'Starter',
      price: '2,499',
      description: 'For small teams and growing businesses',
      features: [
        'Up to 5 AI agents',
        '100,000 API calls/month',
        'Basic analytics',
        'Email support',
        'Custom branding',
        'Single sign-on (SSO)',
      ]
    },
    {
      name: 'Professional',
      price: '9,999',
      description: 'For mid-sized enterprises',
      features: [
        'Unlimited AI agents',
        '1,000,000 API calls/month',
        'Advanced analytics',
        'Priority support',
        'Custom branding & domain',
        'SSO + Role management',
        'API rate priority',
        'Dedicated account manager',
      ],
      isPopular: true
    },
    {
      name: 'Enterprise',
      price: 'Custom',
      description: 'For large organizations',
      features: [
        'Everything in Professional',
        'Unlimited API calls',
        'On-premise deployment',
        '24/7 dedicated support',
        'Custom SLA agreement',
        'Advanced security features',
        'White-label solution',
        'Custom integration support',
      ]
    },
  ];

  const caseStudies = [
    {
      company: 'TechCorp Solutions',
      industry: 'Software Development',
      result: '45% reduction in customer support costs',
      description: 'Implemented AI agents for customer service, reducing support tickets by 40% through intelligent automation.',
      icon: 'fa-solid fa-laptop'
    },
    {
      company: 'FinanceFlow Inc.',
      industry: 'Financial Services',
      result: '60% faster report generation',
      description: 'Used AI analytics agents to automate financial reporting, completing quarterly reports in days instead of weeks.',
      icon: 'fa-solid fa-chart-pie'
    },
    {
      company: 'RetailMax Ltd.',
      industry: 'E-commerce',
      result: '35% increase in customer engagement',
      description: 'Deployed personalized AI agents for product recommendations, boosting customer satisfaction and sales.',
      icon: 'fa-solid fa-shopping-cart'
    },
  ];

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Hero Section */}
      <section className="py-20 md:py-32 text-center">
        <div className="container mx-auto px-6">
          <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight mb-4 bg-clip-text text-transparent bg-gradient-to-r from-white to-gray-400">
            Enterprise AI Solutions
          </h1>
          <p className="max-w-3xl mx-auto text-lg md:text-xl text-gray-400">
            Empower your organization with intelligent, scalable AI agents designed for enterprise operations. From automation to analytics, we've got your business covered.
          </p>
        </div>
      </section>

      {/* Enterprise Features Section */}
      <section className="py-20 md:py-28 bg-[#0a0a0a]">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Why Choose IA M AI for Business?</h2>
            <p className="max-w-2xl mx-auto text-gray-400">Trusted by enterprises to drive innovation and efficiency</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {enterprises.map((feature) => (
              <FeatureCard key={feature.title} {...feature} />
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-20 md:py-28 bg-black">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Flexible Pricing Plans</h2>
            <p className="max-w-2xl mx-auto text-gray-400">Choose the perfect plan for your organization</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {pricingTiers.map((tier, idx) => (
              <PricingTier
                key={idx}
                {...tier}
                onSelect={() => setSelectedPlan(tier.name)}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Case Studies Section */}
      <section className="py-20 md:py-28 bg-[#0a0a0a]">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Success Stories</h2>
            <p className="max-w-2xl mx-auto text-gray-400">See how leading companies leverage our AI solutions</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {caseStudies.map((study, idx) => (
              <CaseStudy key={idx} {...study} />
            ))}
          </div>
        </div>
      </section>

      {/* Implementation Section */}
      <section className="py-20 md:py-28 bg-black">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-12 text-center">Implementation & Support</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
              <div>
                <h3 className="text-xl font-bold text-white mb-6">Onboarding Process</h3>
                <div className="space-y-4">
                  {[
                    { step: '1', title: 'Assessment', desc: 'Understand your business needs and goals' },
                    { step: '2', title: 'Configuration', desc: 'Customize agents for your workflows' },
                    { step: '3', title: 'Integration', desc: 'Seamlessly connect with existing systems' },
                    { step: '4', title: 'Training', desc: 'Empower your team with full training' },
                  ].map((item, idx) => (
                    <div key={idx} className="flex gap-4">
                      <div className="w-10 h-10 rounded-full bg-cyan-500/20 text-cyan-400 flex items-center justify-center font-bold flex-shrink-0">
                        {item.step}
                      </div>
                      <div>
                        <h4 className="font-semibold text-white">{item.title}</h4>
                        <p className="text-sm text-gray-400">{item.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <h3 className="text-xl font-bold text-white mb-6">Ongoing Support</h3>
                <div className="space-y-4">
                  {[
                    { icon: 'fa-solid fa-headset', title: 'Dedicated Support', desc: '24/7 expert support team' },
                    { icon: 'fa-solid fa-chart-line', title: 'Performance Monitoring', desc: 'Real-time analytics & reporting' },
                    { icon: 'fa-solid fa-wrench', title: 'Continuous Optimization', desc: 'Regular improvements & updates' },
                    { icon: 'fa-solid fa-graduation-cap', title: 'Training & Certification', desc: 'Ongoing team education' },
                  ].map((item, idx) => (
                    <div key={idx} className="flex gap-4">
                      <div className="w-10 h-10 rounded-lg bg-cyan-500/20 text-cyan-400 flex items-center justify-center flex-shrink-0">
                        <i className={`${item.icon} text-lg`}></i>
                      </div>
                      <div>
                        <h4 className="font-semibold text-white">{item.title}</h4>
                        <p className="text-sm text-gray-400">{item.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 md:py-28 bg-[#0a0a0a]">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">Ready to Transform Your Business?</h2>
          <p className="max-w-2xl mx-auto text-gray-400 mb-8">
            Let's discuss how IA M AI can help you achieve your business goals.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={() => onNavigate('contact')}
              className="px-8 py-3 bg-cyan-500 text-black font-semibold rounded-lg hover:bg-cyan-400 transition-all duration-300"
            >
              Contact Sales
            </button>
            <button
              onClick={() => onNavigate('home')}
              className="px-8 py-3 bg-gray-800 text-white font-semibold rounded-lg hover:bg-gray-700 transition-all duration-300"
            >
              Back to Home
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default BusinessPage;
