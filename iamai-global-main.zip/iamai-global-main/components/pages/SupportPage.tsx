import React, { useState } from 'react';
import { Page } from '../../App';
import { MessageCircle, Users, Mail, BookOpen, HelpCircle, Send, CheckCircle } from 'lucide-react';

interface SupportPageProps {
  onNavigate: (page: Page) => void;
}

const SupportPage: React.FC<SupportPageProps> = ({ onNavigate }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    description: ''
  });
  const [submitted, setSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const supportCards = [
    {
      icon: <HelpCircle className="w-8 h-8" />,
      title: 'Contact Us',
      description: 'Get in touch with our support team for any inquiries or issues.',
      color: 'from-cyan-500 to-blue-500',
      action: () => onNavigate('contact')
    },
    {
      icon: <Users className="w-8 h-8" />,
      title: 'Community',
      description: 'Join our community to connect with other developers and users.',
      color: 'from-purple-500 to-pink-500',
      action: () => onNavigate('community')
    },
    {
      icon: <MessageCircle className="w-8 h-8" />,
      title: 'Live Chat Support',
      description: 'Get instant help from our AI-powered live support system.',
      color: 'from-green-500 to-emerald-500',
      action: () => onNavigate('live-support')
    },
    {
      icon: <BookOpen className="w-8 h-8" />,
      title: 'Documentation',
      description: 'Browse our comprehensive API documentation and guides.',
      color: 'from-orange-500 to-red-500',
      action: () => onNavigate('documentation')
    },
    {
      icon: <HelpCircle className="w-8 h-8" />,
      title: 'FAQ',
      description: 'Find answers to frequently asked questions.',
      color: 'from-indigo-500 to-purple-500',
      action: () => onNavigate('faq')
    },
    {
      icon: <BookOpen className="w-8 h-8" />,
      title: 'Tutorials',
      description: 'Learn through our step-by-step tutorials and guides.',
      color: 'from-sky-500 to-cyan-500',
      action: () => onNavigate('tutorials')
    }
  ];

  const handleFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.email || !formData.description.trim()) {
      alert('Please fill in all required fields');
      return;
    }

    setIsSubmitting(true);
    
    // Simulate form submission
    try {
      // In a real app, you'd send this to your backend
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setSubmitted(true);
      setFormData({ name: '', email: '', description: '' });
      
      // Reset success message after 5 seconds
      setTimeout(() => setSubmitted(false), 5000);
    } catch (error) {
      console.error('Error submitting form:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 md:py-28">
        <div className="absolute inset-0 bg-grid-gray-900 [mask-image:linear-gradient(to_bottom,white_30%,transparent)]"></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-cyan-500/10 rounded-full blur-3xl"></div>
        
        <div className="container mx-auto px-6 text-center relative z-10">
          <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight mb-4 bg-clip-text text-transparent bg-gradient-to-b from-white to-gray-400">
            Support Center
          </h1>
          <p className="max-w-3xl mx-auto text-lg md:text-xl text-gray-400">
            We're here to help! Find the support resources you need, or reach out to our team directly.
          </p>
        </div>
      </section>

      {/* Support Cards Section */}
      <section className="py-20 md:py-28 bg-[#0a0a0a]">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">How Can We Help?</h2>
            <p className="text-gray-400 text-lg">Choose from multiple support channels and resources</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {supportCards.map((card, idx) => (
              <button
                key={idx}
                onClick={card.action}
                className="group h-full text-left"
              >
                <div className="h-full bg-gray-900/50 border border-gray-800 rounded-2xl p-8 flex flex-col items-start space-y-4 hover:border-cyan-500/50 hover:bg-gray-900 transition-all duration-300 transform hover:-translate-y-2 cursor-pointer">
                  {/* Icon Container */}
                  <div className={`w-14 h-14 flex items-center justify-center rounded-lg bg-gradient-to-br ${card.color} p-3 text-white`}>
                    {card.icon}
                  </div>

                  {/* Content */}
                  <div className="flex-grow">
                    <h3 className="text-xl font-bold text-white mb-2 group-hover:text-cyan-400 transition-colors">
                      {card.title}
                    </h3>
                    <p className="text-gray-400 text-sm">
                      {card.description}
                    </p>
                  </div>

                  {/* Arrow */}
                  <div className="text-cyan-400 group-hover:translate-x-1 transition-transform">
                    <span className="text-lg font-semibold">→</span>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Suggestion Form Section */}
      <section className="py-20 md:py-28 bg-black">
        <div className="container mx-auto px-6">
          <div className="max-w-2xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Share Your Feedback</h2>
              <p className="text-gray-400">Have a suggestion or found an issue? We'd love to hear from you!</p>
            </div>

            {submitted && (
              <div className="mb-8 bg-gradient-to-r from-green-500/20 to-emerald-500/20 border border-green-500/50 rounded-2xl p-6 flex items-start gap-4">
                <CheckCircle className="w-6 h-6 text-green-400 flex-shrink-0 mt-1" />
                <div>
                  <h3 className="text-lg font-bold text-green-400 mb-1">Thank You!</h3>
                  <p className="text-gray-300">
                    Your suggestion has been received. We'll review it and get back to you soon at {formData.email}.
                  </p>
                </div>
              </div>
            )}

            <form onSubmit={handleFormSubmit} className="bg-gray-900/50 border border-gray-800 rounded-2xl p-8 space-y-6">
              {/* Name Field (Optional) */}
              <div>
                <label htmlFor="name" className="block text-sm font-semibold text-gray-300 mb-2">
                  Name <span className="text-gray-500">(Optional)</span>
                </label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleFormChange}
                  placeholder="Your name"
                  className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500/50 focus:ring-2 focus:ring-cyan-500/20 transition-all"
                />
              </div>

              {/* Email Field (Required) */}
              <div>
                <label htmlFor="email" className="block text-sm font-semibold text-gray-300 mb-2">
                  Email <span className="text-red-400">*</span>
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleFormChange}
                  placeholder="your@email.com"
                  required
                  className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500/50 focus:ring-2 focus:ring-cyan-500/20 transition-all"
                />
              </div>

              {/* Description Field (Required) */}
              <div>
                <label htmlFor="description" className="block text-sm font-semibold text-gray-300 mb-2">
                  Your Suggestion or Issue <span className="text-red-400">*</span>
                </label>
                <textarea
                  id="description"
                  name="description"
                  value={formData.description}
                  onChange={handleFormChange}
                  placeholder="Tell us your feedback, suggestions, or describe any issues you're experiencing..."
                  required
                  rows={6}
                  className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500/50 focus:ring-2 focus:ring-cyan-500/20 transition-all resize-none"
                />
              </div>

              {/* Send Button */}
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-gradient-to-r from-cyan-500 to-purple-500 text-black font-semibold py-3 px-6 rounded-lg hover:shadow-lg hover:shadow-cyan-500/50 transition-all duration-300 transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100 flex items-center justify-center gap-2"
              >
                <Send className="w-5 h-5" />
                {isSubmitting ? 'Sending...' : 'Send Feedback'}
              </button>

              {/* Help Text */}
              <p className="text-xs text-gray-500 text-center">
                We take your feedback seriously and will review it carefully.
              </p>
            </form>
          </div>
        </div>
      </section>

      {/* Additional Help Section */}
      <section className="py-20 md:py-28 bg-[#0a0a0a] border-t border-gray-800">
        <div className="container mx-auto px-6">
          <div className="text-center">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">Still Need Help?</h2>
            <div className="flex flex-col md:flex-row gap-4 justify-center items-center">
              <button
                onClick={() => onNavigate('contact')}
                className="px-8 py-3 bg-gradient-to-r from-cyan-500 to-purple-500 text-black font-semibold rounded-lg hover:shadow-lg hover:shadow-cyan-500/50 transition-all duration-300 transform hover:scale-105"
              >
                Contact Us Directly
              </button>
              <button
                onClick={() => onNavigate('live-support')}
                className="px-8 py-3 bg-gray-900 text-white font-semibold rounded-lg border border-cyan-500/50 hover:border-cyan-400 hover:bg-gray-800/50 transition-colors"
              >
                Start Live Chat
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default SupportPage;
