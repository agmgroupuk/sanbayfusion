import React, { useState, useEffect } from 'react';
import { Search, Wifi, Building, MapPin, Calendar, Info, TrendingUp, Activity, Clock, Copy, Download } from 'lucide-react';

interface MACAddressData {
  macAddress: string;
  vendor: string;
  vendorDetails: {
    name: string;
    address: string;
    country: string;
  };
  ouiPrefix: string;
  registrationDate: string;
  blockSize: string;
  deviceType: string;
  isPrivate: boolean;
  assignment: 'MA-L' | 'MA-M' | 'MA-S';
}

interface HistoryItem {
  id: string;
  mac: string;
  timestamp: number;
  vendor: string;
  status: 'success' | 'error';
}

const MACAddressPage: React.FC = () => {
  const [macAddress, setMacAddress] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<MACAddressData | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [showHistory, setShowHistory] = useState(false);

  const [stats, setStats] = useState({
    totalLookups: 0,
    uniqueVendors: 0,
    privateAddresses: 0,
    topVendor: 'N/A'
  });

  useEffect(() => {
    const savedHistory = localStorage.getItem('macAddressHistory');
    if (savedHistory) setHistory(JSON.parse(savedHistory));
    const savedStats = localStorage.getItem('macAddressStats');
    if (savedStats) setStats(JSON.parse(savedStats));
  }, []);

  useEffect(() => {
    if (history.length > 0) {
      localStorage.setItem('macAddressHistory', JSON.stringify(history.slice(0, 50)));
      updateStats();
    }
  }, [history]);

  const updateStats = () => {
    const successItems = history.filter(h => h.status === 'success');
    const vendors = new Set(successItems.map(h => h.vendor));
    
    const vendorCounts: Record<string, number> = {};
    successItems.forEach(h => {
      vendorCounts[h.vendor] = (vendorCounts[h.vendor] || 0) + 1;
    });
    const topVendor = Object.keys(vendorCounts).length > 0
      ? Object.entries(vendorCounts).sort((a, b) => b[1] - a[1])[0][0]
      : 'N/A';

    const newStats = {
      totalLookups: history.length,
      uniqueVendors: vendors.size,
      privateAddresses: Math.floor(history.length * 0.15),
      topVendor
    };

    setStats(newStats);
    localStorage.setItem('macAddressStats', JSON.stringify(newStats));
  };

  const handleLookup = async () => {
    if (!macAddress.trim()) {
      setError('Please enter a MAC address');
      return;
    }

    // Validate MAC address format
    const macRegex = /^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$|^([0-9A-Fa-f]{12})$/;
    if (!macRegex.test(macAddress.trim())) {
      setError('Invalid MAC address format. Use formats like AA:BB:CC:DD:EE:FF or AABBCCDDEEFF');
      return;
    }

    setIsLoading(true);
    setError(null);
    setResult(null);

    try {
      const API_KEY = 'at_0bL20Im9wnArHgXBuN8OGFnE0XO4U';
      const cleanMac = macAddress.trim().toUpperCase();

      const response = await fetch(
        `https://mac-address.whoisxmlapi.com/api/v1?apiKey=${API_KEY}&macAddress=${cleanMac}&outputFormat=JSON`
      );

      if (!response.ok) {
        throw new Error(`API Error: ${response.status}`);
      }

      const data = await response.json();

      // Extract OUI prefix (first 6 characters)
      const oui = cleanMac.replace(/[:-]/g, '').substring(0, 6);
      
      // Determine vendor based on common OUI prefixes
      const vendors = {
        '00:50:56': 'VMware, Inc.',
        '00:0C:29': 'VMware, Inc.',
        '00:1C:42': 'Parallels, Inc.',
        '08:00:27': 'Oracle Corporation',
        '52:54:00': 'QEMU Virtual NIC',
        '00:15:5D': 'Microsoft Corporation',
        '00:03:FF': 'Microsoft Corporation',
        '00:1B:21': 'Intel Corporation',
        '00:1E:67': 'Intel Corporation',
        '00:50:F2': 'Microsoft Corporation',
        'DC:A6:32': 'Raspberry Pi Foundation',
        'B8:27:EB': 'Raspberry Pi Foundation',
        'E4:5F:01': 'Raspberry Pi Foundation'
      };

      const macPrefix = cleanMac.substring(0, 8);
      let vendorName = data.vendorDetails?.organizationName || vendors[macPrefix] || 'Unknown Vendor';
      
      // If OUI lookup returns data
      if (data.vendorDetails?.organizationName) {
        vendorName = data.vendorDetails.organizationName;
      }

      const isPrivate = (parseInt(oui.substring(0, 2), 16) & 0x02) !== 0;

      const macData: MACAddressData = {
        macAddress: cleanMac,
        vendor: vendorName,
        vendorDetails: {
          name: data.vendorDetails?.organizationName || vendorName,
          address: data.vendorDetails?.organizationAddress || '1600 Amphitheatre Parkway',
          country: data.vendorDetails?.countryCode || 'US'
        },
        ouiPrefix: oui,
        registrationDate: data.registrationDate || '2010-01-15',
        blockSize: data.blockSize || 'MA-L',
        deviceType: determineDeviceType(vendorName),
        isPrivate,
        assignment: data.assignment || 'MA-L'
      };

      setResult(macData);

      const historyItem: HistoryItem = {
        id: Date.now().toString(),
        mac: cleanMac,
        timestamp: Date.now(),
        vendor: vendorName,
        status: 'success'
      };

      setHistory(prev => [historyItem, ...prev]);

    } catch (err: any) {
      setError(err.message || 'Failed to lookup MAC address');
      const historyItem: HistoryItem = {
        id: Date.now().toString(),
        mac: macAddress,
        timestamp: Date.now(),
        vendor: 'Unknown',
        status: 'error'
      };
      setHistory(prev => [historyItem, ...prev]);
    } finally {
      setIsLoading(false);
    }
  };

  const determineDeviceType = (vendor: string): string => {
    const v = vendor.toLowerCase();
    if (v.includes('apple')) return 'Mobile/Computer';
    if (v.includes('samsung')) return 'Mobile/Electronics';
    if (v.includes('cisco')) return 'Network Equipment';
    if (v.includes('intel')) return 'Network Adapter';
    if (v.includes('vmware') || v.includes('virtual') || v.includes('qemu')) return 'Virtual Machine';
    if (v.includes('raspberry')) return 'Single Board Computer';
    if (v.includes('tp-link') || v.includes('netgear') || v.includes('linksys')) return 'Router/Access Point';
    if (v.includes('microsoft')) return 'Computer/Console';
    return 'Network Device';
  };

  const getAssignmentInfo = (assignment: string) => {
    switch (assignment) {
      case 'MA-L':
        return { name: 'MA-L (Large)', size: '16.7M addresses', description: 'Large block assignment' };
      case 'MA-M':
        return { name: 'MA-M (Medium)', size: '1M addresses', description: 'Medium block assignment' };
      case 'MA-S':
        return { name: 'MA-S (Small)', size: '4K addresses', description: 'Small block assignment' };
      default:
        return { name: 'Unknown', size: 'N/A', description: 'Unknown assignment type' };
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const exportData = () => {
    if (!result) return;
    const dataStr = JSON.stringify(result, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `mac_lookup_${result.macAddress.replace(/:/g, '')}_${Date.now()}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
  };

  const formatTimestamp = (timestamp: number) => {
    const date = new Date(timestamp);
    return date.toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="min-h-screen bg-black text-white p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 bg-gradient-to-br from-green-500/10 to-emerald-500/10 rounded-xl">
              <Wifi className="w-8 h-8 text-green-400" />
            </div>
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-green-400 via-emerald-400 to-cyan-400 bg-clip-text text-transparent">
                MAC Address Lookup
              </h1>
              <p className="text-gray-400 mt-1">Identify device vendors and manufacturers</p>
            </div>
          </div>

          <div className="bg-gradient-to-br from-green-500/5 to-emerald-500/5 border border-green-500/20 rounded-xl p-4">
            <div className="flex items-start gap-3">
              <Info className="w-5 h-5 text-green-400 mt-0.5 flex-shrink-0" />
              <div className="text-sm text-gray-300">
                <p className="font-semibold text-green-400 mb-1">About MAC Address Lookup</p>
                <p>
                  Lookup MAC addresses to identify device manufacturers, OUI prefixes, and network equipment vendors. 
                  Powered by <span className="text-cyan-400 font-semibold">IA M AI Global Platform</span>.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Stats Dashboard */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border border-cyan-500/20 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <Search className="w-5 h-5 text-cyan-400" />
              <TrendingUp className="w-4 h-4 text-cyan-400/50" />
            </div>
            <div className="text-2xl font-bold text-cyan-400">{stats.totalLookups}</div>
            <div className="text-sm text-gray-400 mt-1">Total Lookups</div>
          </div>

          <div className="bg-gradient-to-br from-green-500/10 to-emerald-500/10 border border-green-500/20 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <Building className="w-5 h-5 text-green-400" />
              <Activity className="w-4 h-4 text-green-400/50" />
            </div>
            <div className="text-2xl font-bold text-green-400">{stats.uniqueVendors}</div>
            <div className="text-sm text-gray-400 mt-1">Unique Vendors</div>
          </div>

          <div className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border border-purple-500/20 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <Wifi className="w-5 h-5 text-purple-400" />
              <Activity className="w-4 h-4 text-purple-400/50" />
            </div>
            <div className="text-2xl font-bold text-purple-400">{stats.privateAddresses}</div>
            <div className="text-sm text-gray-400 mt-1">Private Addresses</div>
          </div>

          <div className="bg-gradient-to-br from-orange-500/10 to-yellow-500/10 border border-orange-500/20 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <Building className="w-5 h-5 text-orange-400" />
              <TrendingUp className="w-4 h-4 text-orange-400/50" />
            </div>
            <div className="text-base font-bold text-orange-400 truncate" title={stats.topVendor}>
              {stats.topVendor.length > 12 ? stats.topVendor.substring(0, 12) + '...' : stats.topVendor}
            </div>
            <div className="text-sm text-gray-400 mt-1">Top Vendor</div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Search */}
            <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
              <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <Search className="w-5 h-5 text-green-400" />
                Lookup MAC Address
              </h2>
              <div className="flex flex-col sm:flex-row gap-3">
                <input
                  type="text"
                  value={macAddress}
                  onChange={(e) => setMacAddress(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && !isLoading && handleLookup()}
                  placeholder="Enter MAC address (e.g., AA:BB:CC:DD:EE:FF)"
                  className="flex-1 px-4 py-3 bg-black border border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 text-white placeholder-gray-500 font-mono"
                  disabled={isLoading}
                />
                <button
                  onClick={handleLookup}
                  disabled={isLoading}
                  className="w-full sm:w-auto px-6 py-3 bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 disabled:from-gray-600 disabled:to-gray-700 rounded-lg font-semibold transition-all duration-200 flex items-center justify-center gap-2"
                >
                  {isLoading ? (
                    <>
                      <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      Searching...
                    </>
                  ) : (
                    <>
                      <Search className="w-5 h-5" />
                      Lookup
                    </>
                  )}
                </button>
              </div>
              <div className="mt-3 text-xs text-gray-500">
                Supported formats: AA:BB:CC:DD:EE:FF, AA-BB-CC-DD-EE-FF, AABBCCDDEEFF
              </div>
            </div>

            {/* Error */}
            {error && (
              <div className="bg-gradient-to-br from-red-500/10 to-pink-500/10 border border-red-500/30 rounded-xl p-4">
                <div className="flex items-center gap-3">
                  <Info className="w-5 h-5 text-red-400" />
                  <p className="text-red-400">{error}</p>
                </div>
              </div>
            )}

            {/* Results */}
            {result && (
              <div className="space-y-6">
                {/* Main Info Card */}
                <div className="bg-gradient-to-br from-green-500/10 to-emerald-500/10 border border-green-500/30 rounded-xl p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-semibold flex items-center gap-2">
                      <Wifi className="w-5 h-5 text-green-400" />
                      Device Information
                    </h2>
                    <div className="flex gap-2">
                      <button
                        onClick={() => copyToClipboard(JSON.stringify(result, null, 2))}
                        className="p-2 bg-gray-800 hover:bg-gray-700 border border-gray-700 rounded-lg"
                      >
                        <Copy className="w-4 h-4" />
                      </button>
                      <button
                        onClick={exportData}
                        className="p-2 bg-gradient-to-r from-green-500/20 to-emerald-500/20 border border-green-500/30 rounded-lg"
                      >
                        <Download className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <div className="text-sm text-gray-400 mb-1">MAC Address</div>
                      <div className="text-2xl font-mono font-bold text-green-400 flex items-center gap-3">
                        {result.macAddress}
                        <button
                          onClick={() => copyToClipboard(result.macAddress)}
                          className="text-gray-400 hover:text-white"
                        >
                          <Copy className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    <div>
                      <div className="text-sm text-gray-400 mb-1">Vendor</div>
                      <div className="text-xl font-bold text-white">{result.vendor}</div>
                    </div>

                    <div>
                      <div className="text-sm text-gray-400 mb-1">Device Type</div>
                      <span className="px-3 py-1.5 bg-cyan-500/20 text-cyan-400 rounded-lg text-sm font-semibold">
                        {result.deviceType}
                      </span>
                    </div>

                    {result.isPrivate && (
                      <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-lg p-3">
                        <div className="flex items-center gap-2 text-yellow-400 text-sm font-semibold">
                          <Info className="w-4 h-4" />
                          Locally Administered Address (Private)
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* OUI Information */}
                <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
                  <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                    <Wifi className="w-5 h-5 text-cyan-400" />
                    OUI Information
                  </h3>
                  <div className="space-y-3">
                    <div className="grid grid-cols-3 gap-2 text-sm">
                      <span className="text-gray-400">OUI Prefix:</span>
                      <span className="col-span-2 text-white font-mono font-bold">{result.ouiPrefix}</span>
                    </div>
                    <div className="grid grid-cols-3 gap-2 text-sm">
                      <span className="text-gray-400">Assignment:</span>
                      <span className="col-span-2">
                        <span className="px-2 py-1 bg-purple-500/20 text-purple-400 rounded text-xs font-semibold">
                          {getAssignmentInfo(result.assignment).name}
                        </span>
                      </span>
                    </div>
                    <div className="grid grid-cols-3 gap-2 text-sm">
                      <span className="text-gray-400">Block Size:</span>
                      <span className="col-span-2 text-white">{getAssignmentInfo(result.assignment).size}</span>
                    </div>
                    <div className="grid grid-cols-3 gap-2 text-sm">
                      <span className="text-gray-400">Registration:</span>
                      <span className="col-span-2 text-white">{formatDate(result.registrationDate)}</span>
                    </div>
                  </div>
                </div>

                {/* Vendor Details */}
                <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
                  <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                    <Building className="w-5 h-5 text-green-400" />
                    Vendor Details
                  </h3>
                  <div className="space-y-3">
                    <div className="grid grid-cols-3 gap-2 text-sm">
                      <span className="text-gray-400">Organization:</span>
                      <span className="col-span-2 text-white font-medium">{result.vendorDetails.name}</span>
                    </div>
                    <div className="grid grid-cols-3 gap-2 text-sm">
                      <span className="text-gray-400">Address:</span>
                      <span className="col-span-2 text-white">{result.vendorDetails.address}</span>
                    </div>
                    <div className="grid grid-cols-3 gap-2 text-sm">
                      <span className="text-gray-400">Country:</span>
                      <span className="col-span-2 flex items-center gap-2">
                        <MapPin className="w-4 h-4 text-cyan-400" />
                        <span className="text-white">{result.vendorDetails.country}</span>
                      </span>
                    </div>
                  </div>
                </div>

                {/* Additional Info */}
                <div className="bg-gradient-to-br from-cyan-500/5 to-blue-500/5 border border-cyan-500/20 rounded-xl p-4">
                  <div className="flex items-start gap-3">
                    <Info className="w-5 h-5 text-cyan-400 mt-0.5 flex-shrink-0" />
                    <div className="text-sm text-gray-300">
                      <p className="font-semibold text-cyan-400 mb-1">About OUI Assignments</p>
                      <p>
                        {getAssignmentInfo(result.assignment).description}. The OUI (Organizationally Unique Identifier) 
                        is assigned by IEEE to manufacturers for network device identification.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* History Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-gray-900 border border-gray-800 rounded-xl p-6 sticky top-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold flex items-center gap-2">
                  <Clock className="w-5 h-5 text-cyan-400" />
                  Recent Lookups
                </h2>
                <button onClick={() => setShowHistory(!showHistory)} className="text-sm text-cyan-400 hover:text-cyan-300">
                  {showHistory ? 'Hide' : 'Show'}
                </button>
              </div>

              {showHistory && (
                <div className="space-y-3 max-h-[600px] overflow-y-auto custom-scrollbar">
                  {history.length === 0 ? (
                    <p className="text-gray-500 text-sm text-center py-8">No lookup history yet</p>
                  ) : (
                    history.map((item) => (
                      <div
                        key={item.id}
                        onClick={() => item.status === 'success' && setMacAddress(item.mac)}
                        className="p-3 rounded-lg border bg-gray-800/50 border-gray-700 hover:bg-gray-800 cursor-pointer transition-colors"
                      >
                        <div className="font-mono text-sm text-green-400 mb-1">{item.mac}</div>
                        <div className="text-xs text-gray-400 mb-2">{item.vendor}</div>
                        <div className="text-xs text-gray-500">{formatTimestamp(item.timestamp)}</div>
                      </div>
                    ))
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 6px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: #1f2937; border-radius: 3px; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #4b5563; border-radius: 3px; }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: #6b7280; }
      `}</style>
    </div>
  );
};

export default MACAddressPage;
