import React, { useMemo, useEffect, useCallback, useState } from 'react';
import type { Page } from '../../App';
import { Agent, SubscriptionPlanSlug } from '../../constants';
import { ALL_AGENTS } from '../../agents';
import { getApiUrl } from '../../config/api';

interface ThankYouPageProps {
  onNavigate: (page: Page) => void;
  onSelectAgent: (agent: Agent) => void;
  onRefreshAppData?: () => Promise<void>;
}

const PLAN_LABELS: Record<SubscriptionPlanSlug, string> = {
  daily: 'Daily Plan',
  weekly: 'Weekly Plan',
  monthly: 'Monthly Plan',
};

const PLAN_PRICES: Record<SubscriptionPlanSlug, string> = {
  daily: '$1/day',
  weekly: '$5/week',
  monthly: '$19/month',
};

const PLAN_DESCRIPTIONS: Record<SubscriptionPlanSlug, string> = {
  daily: '24-hour access',
  weekly: '7-day access',
  monthly: '30-day access',
};

const API_BASE =
  window.location.hostname === 'localhost' ? 'http://localhost:3001' : 'https://iamai.global';

const ThankYouPage: React.FC<ThankYouPageProps> = ({
  onNavigate,
  onSelectAgent,
  onRefreshAppData,
}) => {
  const searchParams = useMemo(() => new URLSearchParams(window.location.search), []);
  const agentId = searchParams.get('agent');
  const planParam = searchParams.get('plan') as SubscriptionPlanSlug | null;
  const [grantingAccess, setGrantingAccess] = useState(false);
  const [activated, setActivated] = useState(false);

  const selectedAgent = useMemo(() => {
    if (!agentId) return null;
    return ALL_AGENTS.find(agent => agent.id === agentId) || null;
  }, [agentId]);

  const planLabel = planParam && PLAN_LABELS[planParam];

  // Activate purchase via API (fallback when webhook doesn't fire)
  const activatePurchase = useCallback(async () => {
    if (!agentId || activated) return;

    try {
      console.log('[ThankYouPage] Attempting to activate purchase for:', agentId);
      const response = await fetch(`${API_BASE}/api/purchases/activate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ agentId, plan: planParam }),
      });

      const data = await response.json();
      if (data.success) {
        console.log('[ThankYouPage] Purchase activated successfully:', data);
        setActivated(true);
      } else {
        console.log('[ThankYouPage] Activation response:', data.message || data.error);
      }
    } catch (error) {
      console.error('[ThankYouPage] Failed to activate purchase:', error);
    }
  }, [agentId, planParam, activated]);

  const refreshData = useCallback(async () => {
    // Just refresh app data - webhook should have already updated the purchase status
    if (!onRefreshAppData) return;
    try {
      await onRefreshAppData();
    } catch (error) {
      console.error('[ThankYouPage] Failed to refresh app data after checkout:', error);
    }
  }, [onRefreshAppData]);

  useEffect(() => {
    // Immediately try to activate the purchase (fallback for webhook)
    activatePurchase();

    // Poll for purchase status every 5 seconds for up to 15 seconds (reduced frequency)
    let pollCount = 0;
    const maxPolls = 3; // 3 polls = 15 seconds total (reduced from 7)
    let isActive = true; // Prevent memory leaks if component unmounts

    const pollInterval = setInterval(async () => {
      if (!isActive) return;
      pollCount++;

      // Try to activate on each poll in case it wasn't activated yet
      if (!activated) {
        await activatePurchase();
      }
      await refreshData();

      if (pollCount >= maxPolls) {
        clearInterval(pollInterval);
      }
    }, 5000); // Poll every 5 seconds instead of 2 seconds

    // Initial immediate refresh
    refreshData();

    // Auto-redirect to dashboard after 15 seconds with success parameter
    const redirectTimer = setTimeout(() => {
      if (!isActive) return;
      const dashboardUrl = `/dashboard?subscription=success${agentId ? `&agent=${agentId}` : ''}`;
      window.location.href = dashboardUrl;
    }, 15000);

    return () => {
      isActive = false;
      clearInterval(pollInterval);
      clearTimeout(redirectTimer);
    };
  }, [agentId, activatePurchase]); // Added activatePurchase dependency

  const handleGoToDashboard = async () => {
    await refreshData();
    onNavigate('dashboard');
  };

  const handleGoToChat = async () => {
    await refreshData();
    if (selectedAgent) {
      onSelectAgent(selectedAgent);
      onNavigate('agent-chat', selectedAgent.id);
    } else {
      onNavigate('dashboard');
    }
  };

  const handleBrowseAgents = async () => {
    await refreshData();
    onNavigate('agents');
  };

  return (
    <div className="min-h-screen bg-black flex items-center justify-center px-6 py-24">
      <div className="max-w-2xl w-full bg-gray-900/60 border border-gray-800 rounded-3xl p-10 text-center shadow-xl shadow-cyan-500/10">
        <div className="mx-auto mb-6 w-20 h-20 flex items-center justify-center rounded-full bg-cyan-500/10 text-cyan-400">
          <i className="fa-solid fa-circle-check text-4xl"></i>
        </div>
        <p className="text-sm uppercase tracking-[0.35em] text-cyan-400 mb-3">Payment Successful</p>
        <h1 className="text-4xl font-bold text-white mb-4">
          Welcome to {selectedAgent ? selectedAgent.name : 'IA M AI'}!
        </h1>

        {/* Subscription Details Card */}
        {selectedAgent && planParam && (
          <div className="bg-gray-800/50 border border-gray-700 rounded-2xl p-6 mb-8">
            <div className="flex items-center justify-center gap-4 mb-4">
              {selectedAgent.icon && (
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-cyan-500 to-purple-500 flex items-center justify-center">
                  <i className={`${selectedAgent.icon} text-2xl text-white`}></i>
                </div>
              )}
              <div className="text-left">
                <h3 className="text-xl font-bold text-white">{selectedAgent.name}</h3>
                <p className="text-sm text-gray-400">{selectedAgent.role}</p>
              </div>
            </div>
            <div className="border-t border-gray-700 pt-4 space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-gray-400">Plan:</span>
                <span className="text-white font-semibold">{PLAN_LABELS[planParam]}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-400">Price:</span>
                <span className="text-cyan-400 font-bold">{PLAN_PRICES[planParam]}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-400">Access:</span>
                <span className="text-white">{PLAN_DESCRIPTIONS[planParam]}</span>
              </div>
            </div>
          </div>
        )}

        <p className="text-gray-400 leading-relaxed mb-8">
          {selectedAgent
            ? `Your subscription to ${selectedAgent.name} is now active! Start chatting immediately or explore your dashboard.`
            : 'Your subscription is active. Visit your dashboard to start using your AI agents.'}
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button
            onClick={handleGoToChat}
            className="flex-1 px-6 py-3 bg-gradient-to-r from-cyan-500 to-blue-500 text-white font-semibold rounded-xl hover:from-cyan-400 hover:to-blue-400 transition-all shadow-lg shadow-cyan-500/20"
          >
            {selectedAgent ? (
              <>
                <i className="fa-solid fa-comments mr-2"></i>
                Start Chatting with {selectedAgent.name}
              </>
            ) : (
              'Browse Agents'
            )}
          </button>
          <button
            onClick={handleGoToDashboard}
            className="flex-1 px-6 py-3 bg-gray-800 text-white font-semibold rounded-xl hover:bg-gray-700 transition-colors border border-gray-700"
          >
            <i className="fa-solid fa-dashboard mr-2"></i>
            Go to Dashboard
          </button>
        </div>

        {!selectedAgent && (
          <button
            onClick={handleBrowseAgents}
            className="mt-6 text-sm text-gray-500 hover:text-cyan-400 transition-colors"
          >
            Prefer to pick an agent first? Browse the lineup →
          </button>
        )}
      </div>
    </div>
  );
};

export default ThankYouPage;
