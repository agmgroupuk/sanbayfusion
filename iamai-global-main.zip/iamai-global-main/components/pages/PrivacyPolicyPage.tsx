import React, { useState } from 'react';
import { Page } from '../../App';
import { ArrowLeft, Shield, Lock, Eye, Database, Users, Globe, Settings, X, ExternalLink, BookOpen, AlertCircle, CheckCircle, Cookie, Brain, Mail, Bell } from 'lucide-react';

interface PrivacyPolicyPageProps {
  onNavigate: (page: Page) => void;
}

interface PrivacyArticle {
  id: string;
  title: string;
  icon: React.ReactNode;
  excerpt: string;
  category: string;
  content: {
    introduction: string;
    sections: {
      heading: string;
      paragraphs: string[];
      list?: string[];
    }[];
    conclusion?: string;
  };
}

const PrivacyPolicyPage: React.FC<PrivacyPolicyPageProps> = ({ onNavigate }) => {
  const [selectedArticle, setSelectedArticle] = useState<PrivacyArticle | null>(null);
  const [activeCategory, setActiveCategory] = useState<string>('all');

  const articles: PrivacyArticle[] = [
    {
      id: 'data-collection',
      title: 'What Information We Collect',
      icon: <Database className="w-6 h-6 text-cyan-400" />,
      excerpt: 'Comprehensive overview of all data types we collect across our multi-agent platform.',
      category: 'Data Collection',
      content: {
        introduction: 'As a global multi-agent AI platform, IA M AI collects various types of information to provide you with personalized, secure, and efficient services. We are committed to transparency about what we collect and why.',
        sections: [
          {
            heading: 'Personal Information',
            paragraphs: [
              'When you create an account or interact with our platform, we collect personal information that you voluntarily provide. This includes your name, email address, phone number, profile picture, and any other information you choose to share.',
              'We also collect authentication data such as passwords (encrypted), security questions, and two-factor authentication preferences to keep your account secure.'
            ],
            list: [
              'Full name and display name',
              'Email address and verified status',
              'Phone number (optional)',
              'Profile photo or avatar',
              'Date of birth (for age verification)',
              'Country and language preferences',
              'Account security settings'
            ]
          },
          {
            heading: 'AI Interaction Data',
            paragraphs: [
              'When you interact with any of our 17 AI agents (AI Girlfriend Pro, EmoAI, PDFMind, ChatRevive, TokBoost, YouGen, AgentX, AutoChat, CVSmash, ComedyChad, LazyLarry, FlirtyFiona, SassySarah, NerdyNeil, CoolKyle, ZenMasterZara, GamerGary), we collect conversation data.',
              'This data includes your prompts, messages, uploaded files (for agents like PDFMind), and the AI-generated responses. We use this data to improve agent performance, personalize your experience, and maintain conversation history.'
            ],
            list: [
              'Chat messages and prompts sent to AI agents',
              'AI-generated responses and recommendations',
              'Conversation timestamps and duration',
              'Agent preferences and favorites',
              'Uploaded documents and files (stored encrypted)',
              'Voice recordings (if using voice features)',
              'Feedback ratings (thumbs up/down)'
            ]
          },
          {
            heading: 'Technical & Usage Data',
            paragraphs: [
              'We automatically collect technical information about your device and how you use our platform. This helps us optimize performance, prevent fraud, and improve user experience.',
              'This data is collected through cookies, log files, and analytics tools. You can manage cookie preferences in your browser settings.'
            ],
            list: [
              'IP address and geolocation data',
              'Device type, model, and operating system',
              'Browser type and version',
              'Screen resolution and display settings',
              'Pages visited and navigation patterns',
              'Time spent on different features',
              'Referral source and marketing attribution',
              'Error logs and crash reports',
              'Network performance metrics'
            ]
          },
          {
            heading: 'Payment & Subscription Data',
            paragraphs: [
              'If you subscribe to premium features or agent subscriptions, we collect payment information through secure third-party processors. We never store complete credit card numbers on our servers.'
            ],
            list: [
              'Billing name and address',
              'Last 4 digits of payment card',
              'Payment method type',
              'Transaction history and receipts',
              'Subscription tier and renewal dates',
              'Promotional codes and discounts used'
            ]
          },
          {
            heading: 'Social Media & Third-Party Data',
            paragraphs: [
              'If you connect social media accounts or use third-party services with IA M AI, we may receive information from those platforms according to their privacy policies and your authorization.'
            ],
            list: [
              'Social media profile information',
              'Friends list and connections',
              'Shared content and posts',
              'Authentication tokens',
              'Third-party app permissions'
            ]
          }
        ],
        conclusion: 'We collect only the information necessary to provide, improve, and secure our services. You have control over most data collection through your privacy settings.'
      }
    },
    {
      id: 'data-usage',
      title: 'How We Use Your Information',
      icon: <Settings className="w-6 h-6 text-cyan-400" />,
      excerpt: 'Detailed explanation of how your data powers our AI agents and platform features.',
      category: 'Data Usage',
      content: {
        introduction: 'Your data is the foundation of personalized AI experiences on our platform. We use your information responsibly to deliver exceptional service, enhance features, and ensure platform security.',
        sections: [
          {
            heading: 'AI Agent Personalization',
            paragraphs: [
              'Each of our 17 AI agents learns from your interactions to provide increasingly personalized and helpful responses. Your conversation history helps agents remember context, preferences, and past discussions.',
              'For example, AI Girlfriend Pro learns your communication style, EmoAI understands your emotional patterns, and PDFMind remembers your document analysis preferences.'
            ],
            list: [
              'Maintaining conversation context and memory',
              'Adapting communication style to your preferences',
              'Remembering important dates and events you mention',
              'Learning your interests and topics of interest',
              'Improving response relevance over time',
              'Personalizing recommendations and suggestions'
            ]
          },
          {
            heading: 'Platform Features & Services',
            paragraphs: [
              'We use your data to operate, maintain, and improve all platform features including the AI Studio, Reward Center, Developer Toolbox, and community features.'
            ],
            list: [
              'Account creation and management',
              'Authentication and access control',
              'Subscription processing and billing',
              'Reward points calculation and level progression',
              'Developer tools usage tracking',
              'Community posts and interactions',
              'Customer support and assistance',
              'Platform analytics and performance monitoring'
            ]
          },
          {
            heading: 'Security & Fraud Prevention',
            paragraphs: [
              'Your data helps us protect your account and maintain platform integrity. We analyze patterns to detect unusual activity, prevent unauthorized access, and combat fraudulent behavior.'
            ],
            list: [
              'Detecting suspicious login attempts',
              'Identifying bot and spam activity',
              'Preventing account takeovers',
              'Monitoring for policy violations',
              'Protecting against DDoS attacks',
              'Verifying user identity when needed'
            ]
          },
          {
            heading: 'Communication & Notifications',
            paragraphs: [
              'We use your contact information to send important updates, respond to inquiries, and deliver notifications about your account and activities.'
            ],
            list: [
              'Account verification and password resets',
              'Subscription renewals and billing notices',
              'New feature announcements',
              'Agent updates and improvements',
              'Security alerts and warnings',
              'Promotional offers (with your consent)',
              'Community activity notifications',
              'Customer support responses'
            ]
          }
        ],
        conclusion: 'Every data point serves a purpose in creating a better experience for you and our community. We never use your personal data for purposes incompatible with those described here without your explicit consent.'
      }
    },
    {
      id: 'data-sharing',
      title: 'Data Sharing & Third Parties',
      icon: <Users className="w-6 h-6 text-cyan-400" />,
      excerpt: 'Who we share your data with and under what circumstances, including AI model providers.',
      category: 'Data Sharing',
      content: {
        introduction: 'We carefully manage third-party access to your data. We only share information when necessary to provide our services, comply with legal obligations, or with your explicit consent.',
        sections: [
          {
            heading: 'AI Model Providers',
            paragraphs: [
              'Our multi-agent platform integrates with leading AI providers including Mistral AI, OpenAI, Google Gemini, and Anthropic Claude. When you interact with AI agents, your prompts may be processed by these services.',
              'Each provider has their own privacy policy and data handling practices. We work only with providers who maintain high privacy and security standards.'
            ],
            list: [
              'Mistral AI - Primary AI provider for most agents',
              'OpenAI - GPT models for specific features',
              'Google Gemini - Multimodal and analysis tasks',
              'Anthropic Claude - Complex reasoning tasks',
              'ElevenLabs - Text-to-speech functionality',
              'Stability AI - Image generation features'
            ]
          },
          {
            heading: 'Service Providers & Infrastructure',
            paragraphs: [
              'We use trusted third-party services to host, operate, and maintain our platform. These providers have access only to the data necessary to perform their functions.'
            ],
            list: [
              'AWS - Cloud hosting and infrastructure',
              'MongoDB Atlas - Database services',
              'Stripe - Payment processing',
              'SendGrid - Email delivery',
              'Cloudflare - CDN and DDoS protection',
              'Google Analytics - Usage analytics',
              'Sentry - Error tracking and monitoring'
            ]
          },
          {
            heading: 'What We Never Do',
            paragraphs: [
              'We want to be crystal clear about what we will NEVER do with your data:'
            ],
            list: [
              '❌ Sell your personal information to data brokers',
              '❌ Share your private conversations publicly',
              '❌ Use your data to train AI models without consent',
              '❌ Provide your data to advertisers',
              '❌ Track you across other websites',
              '❌ Share your information for political purposes'
            ]
          }
        ],
        conclusion: 'Transparency is core to our values. If our data sharing practices change, we will update this policy and notify you in advance.'
      }
    },
    {
      id: 'data-security',
      title: 'Security & Data Protection',
      icon: <Shield className="w-6 h-6 text-cyan-400" />,
      excerpt: 'Comprehensive security measures protecting your data across our global platform.',
      category: 'Security',
      content: {
        introduction: 'Protecting your data is our top priority. We employ industry-leading security measures, encryption technologies, and continuous monitoring to safeguard your information.',
        sections: [
          {
            heading: 'Encryption Standards',
            paragraphs: [
              'All data transmitted to and from IA M AI is encrypted using industry-standard protocols. Data stored on our servers is encrypted at rest using advanced encryption algorithms.'
            ],
            list: [
              'TLS 1.3 encryption for data in transit',
              'AES-256 encryption for data at rest',
              'Encrypted database connections',
              'Secure API communications',
              'End-to-end encryption for sensitive conversations (optional)',
              'Encrypted file storage for uploaded documents',
              'Hashed and salted passwords (bcrypt)'
            ]
          },
          {
            heading: 'Access Controls',
            paragraphs: [
              'We implement strict access controls to ensure only authorized personnel can access user data, and only when necessary for their job functions.'
            ],
            list: [
              'Role-based access control (RBAC)',
              'Multi-factor authentication for employee access',
              'Principle of least privilege',
              'Regular access audits and reviews',
              'Automatic session timeouts',
              'IP whitelisting for admin access',
              'Detailed access logging'
            ]
          },
          {
            heading: 'Infrastructure Security',
            paragraphs: [
              'Our platform is hosted on AWS with enterprise-grade security features and certifications. We use multiple layers of security across our infrastructure.'
            ],
            list: [
              'AWS SOC 2 Type II certified infrastructure',
              'Isolated production environments',
              'Firewall and intrusion detection systems',
              'DDoS protection via Cloudflare',
              'Regular security patches and updates',
              'Network segmentation',
              'Automated backup systems',
              'Disaster recovery procedures'
            ]
          }
        ],
        conclusion: 'Security is not a one-time effort but an ongoing commitment. We continuously invest in new technologies and practices to stay ahead of emerging threats.'
      }
    },
    {
      id: 'user-rights',
      title: 'Your Privacy Rights & Controls',
      icon: <CheckCircle className="w-6 h-6 text-cyan-400" />,
      excerpt: 'Comprehensive guide to exercising your rights under GDPR, CCPA, and other regulations.',
      category: 'User Rights',
      content: {
        introduction: 'You have significant rights regarding your personal data. We make it easy for you to access, control, and manage your information on our platform.',
        sections: [
          {
            heading: 'Right to Access',
            paragraphs: [
              'You have the right to know what personal information we collect, use, and share about you. You can request a complete copy of your data at any time.'
            ],
            list: [
              'Download all your personal data (data portability)',
              'View your conversation history with all AI agents',
              'Access your account settings and preferences',
              'See your subscription and payment history',
              'Review your activity logs',
              'Export data in machine-readable format (JSON/CSV)'
            ]
          },
          {
            heading: 'Right to Deletion',
            paragraphs: [
              'You can request deletion of your personal data. We will honor deletion requests subject to legal retention requirements and legitimate business needs.'
            ],
            list: [
              'Delete your entire account and all associated data',
              'Remove specific AI agent conversation histories',
              'Erase uploaded files and documents',
              'Delete community posts and comments',
              'Remove feedback and ratings'
            ]
          },
          {
            heading: 'California Privacy Rights (CCPA)',
            paragraphs: [
              'California residents have additional rights under the California Consumer Privacy Act (CCPA).'
            ],
            list: [
              'Know what personal information is collected',
              'Know whether personal information is sold or disclosed',
              'Say no to the sale of personal information',
              'Access your personal information',
              'Request deletion of personal information',
              'Equal service and price, even if you exercise privacy rights'
            ]
          },
          {
            heading: 'European Privacy Rights (GDPR)',
            paragraphs: [
              'European Union residents have rights under the General Data Protection Regulation (GDPR).'
            ],
            list: [
              'Right to be informed about data processing',
              'Right of access to your personal data',
              'Right to rectification of inaccurate data',
              'Right to erasure ("right to be forgotten")',
              'Right to restrict processing',
              'Right to data portability',
              'Right to object to processing',
              'Rights related to automated decision-making',
              'Right to lodge a complaint with supervisory authority'
            ]
          }
        ],
        conclusion: 'Your privacy rights are not just legal requirements – they are fundamental to how we operate. We are committed to making these rights meaningful and accessible.'
      }
    },
    {
      id: 'cookies',
      title: 'Cookies & Tracking Technologies',
      icon: <Cookie className="w-6 h-6 text-cyan-400" />,
      excerpt: 'Detailed breakdown of cookies and tracking technologies used across our platform.',
      category: 'Cookies',
      content: {
        introduction: 'We use cookies and similar technologies to enhance your experience, analyze usage, and provide personalized features. You have control over most cookies through your browser and account settings.',
        sections: [
          {
            heading: 'Essential Cookies',
            paragraphs: [
              'These cookies are necessary for the platform to function properly. You cannot opt out of essential cookies without affecting your ability to use our services.'
            ],
            list: [
              'Authentication: Keep you logged in between sessions',
              'Security: Prevent cross-site request forgery (CSRF) attacks',
              'Session Management: Maintain your active session',
              'Load Balancing: Distribute traffic across our servers',
              'Feature Toggles: Enable/disable specific features for your account'
            ]
          },
          {
            heading: 'Performance Cookies',
            paragraphs: [
              'These cookies help us understand how you interact with our platform, identify performance issues, and improve user experience.'
            ],
            list: [
              'Page load times and performance metrics',
              'Error tracking and bug reports',
              'Feature usage statistics',
              'A/B testing for new features',
              'Heat maps and click tracking'
            ]
          },
          {
            heading: 'Managing Cookies',
            paragraphs: [
              'You have multiple options to control cookies:'
            ],
            list: [
              'Browser Settings: Most browsers allow you to reject or delete cookies',
              'Cookie Consent Manager: Use our cookie preference center',
              'Opt-Out Links: Click opt-out links for specific services',
              'Do Not Track: We respect Do Not Track browser signals',
              'Private/Incognito Mode: Browse without storing cookies',
              'Ad Blockers: Use extensions to block tracking cookies'
            ]
          }
        ],
        conclusion: 'We believe in transparency and control. If you have questions about cookies or want to adjust your preferences, visit your account settings or contact us.'
      }
    },
    {
      id: 'ai-privacy',
      title: 'AI-Specific Privacy Considerations',
      icon: <Brain className="w-6 h-6 text-cyan-400" />,
      excerpt: 'Special privacy considerations for AI interactions, model training, and agent personalization.',
      category: 'AI & ML',
      content: {
        introduction: 'As a multi-agent AI platform, we have unique privacy considerations related to how our AI agents process, learn from, and remember your interactions.',
        sections: [
          {
            heading: 'How AI Agents Process Your Data',
            paragraphs: [
              'When you chat with any of our 17 AI agents, your messages are processed in real-time to generate responses. This processing happens on secure servers with strict access controls.'
            ],
            list: [
              'Messages are encrypted during transmission',
              'Processing happens in isolated environments',
              'Responses are generated based on AI models and your context',
              'No human reviews your private conversations without explicit consent',
              'Conversation data is stored encrypted in secure databases',
              'Each agent has separate memory and context'
            ]
          },
          {
            heading: 'AI Model Training',
            paragraphs: [
              'We want to be transparent about when and how your interactions might be used to improve AI models. You have control over this process.'
            ],
            list: [
              'Default: Your conversations are NOT used for model training',
              'Opt-In: You can choose to contribute to AI improvement',
              'Anonymization: If you opt in, data is anonymized and stripped of personal identifiers',
              'Aggregation: Only patterns and trends are extracted, not individual conversations',
              'Quality Control: Human review only with explicit permission',
              'Opt-Out Anytime: Change your mind at any time in settings'
            ]
          },
          {
            heading: 'Agent Memory & Personalization',
            paragraphs: [
              'Our AI agents can remember context from your conversations to provide more personalized and helpful responses. You control what they remember.'
            ],
            list: [
              'Short-term Memory: Context within a single conversation session',
              'Long-term Memory: Key facts and preferences across sessions (with your consent)',
              'Selective Memory: Choose what agents should remember or forget',
              'Memory Deletion: Clear agent memories at any time',
              'Memory Export: Download what agents know about you',
              'Agent-Specific: Each agent has separate memory (not shared)'
            ]
          }
        ],
        conclusion: 'AI privacy is evolving, and so are we. We commit to transparency, user control, and responsible AI development. Your trust is our most valuable asset.'
      }
    },
    {
      id: 'international',
      title: 'International Data Transfers',
      icon: <Globe className="w-6 h-6 text-cyan-400" />,
      excerpt: 'How we handle data transfers across borders and comply with international regulations.',
      category: 'International',
      content: {
        introduction: 'As a global platform, IA M AI serves users worldwide. This means your data may be transferred to and processed in countries other than your own. We ensure appropriate safeguards are in place for all international transfers.',
        sections: [
          {
            heading: 'Where Your Data Is Stored',
            paragraphs: [
              'Our primary data centers are located in the United States and European Union, powered by AWS infrastructure. We use edge servers worldwide for performance optimization.'
            ],
            list: [
              'Primary: US East (Virginia) and EU West (Ireland)',
              'Secondary: Asia Pacific (Singapore)',
              'CDN: Global Cloudflare edge network',
              'Backups: Multiple geographic regions',
              'User data stays in preferred region when possible'
            ]
          },
          {
            heading: 'EU-US Data Transfers',
            paragraphs: [
              'For transfers between the European Union and United States, we rely on multiple legal mechanisms to ensure GDPR compliance.'
            ],
            list: [
              'EU-US Data Privacy Framework participation',
              'Standard Contractual Clauses (SCCs)',
              'Supplementary measures for data protection',
              'Regular compliance audits',
              'Binding Corporate Rules (in development)'
            ]
          }
        ],
        conclusion: 'International data protection is complex, but our commitment is simple: your data is protected with the same high standards regardless of where it travels.'
      }
    },
    {
      id: 'children',
      title: 'Children\'s Privacy',
      icon: <AlertCircle className="w-6 h-6 text-cyan-400" />,
      excerpt: 'Our policies regarding children\'s data and COPPA compliance.',
      category: 'Special Categories',
      content: {
        introduction: 'IA M AI is committed to protecting the privacy of children. We comply with the Children\'s Online Privacy Protection Act (COPPA) and similar international regulations.',
        sections: [
          {
            heading: 'Age Requirements',
            paragraphs: [
              'Our platform has age restrictions to ensure appropriate use and legal compliance.'
            ],
            list: [
              'Minimum age: 13 years old in most countries',
              'Minimum age: 16 years old in the EU',
              'Age verification required during registration',
              'Parental consent required for users under 13 (special programs only)',
              'Age-appropriate content and features'
            ]
          },
          {
            heading: 'Parental Controls',
            paragraphs: [
              'Parents or guardians can exercise significant control over children\'s accounts.'
            ],
            list: [
              'Access child\'s account information',
              'Review AI interaction history',
              'Manage privacy settings',
              'Request data deletion',
              'Set usage limits and restrictions',
              'Receive activity reports',
              'Approve agent subscriptions'
            ]
          }
        ],
        conclusion: 'Children\'s safety and privacy are paramount. We take our responsibilities seriously and continuously improve our protections.'
      }
    },
    {
      id: 'retention',
      title: 'Data Retention & Deletion',
      icon: <Database className="w-6 h-6 text-cyan-400" />,
      excerpt: 'How long we keep your data and what happens when you delete your account.',
      category: 'Data Management',
      content: {
        introduction: 'We retain your data only as long as necessary to provide services, comply with legal obligations, and resolve disputes. You can request deletion at any time.',
        sections: [
          {
            heading: 'Retention Periods',
            paragraphs: [
              'Different types of data have different retention periods based on their purpose and legal requirements.'
            ],
            list: [
              'Active Account Data: Retained while account is active',
              'Conversation History: 90 days by default (configurable)',
              'Transaction Records: 7 years (legal requirement)',
              'Login Logs: 1 year',
              'Support Tickets: 3 years',
              'Marketing Data: Until opt-out or 2 years of inactivity',
              'Anonymous Analytics: 26 months',
              'Backup Data: 30 days'
            ]
          },
          {
            heading: 'Account Deletion',
            paragraphs: [
              'When you delete your account, we begin the deletion process immediately. However, some data may be retained for legal or operational reasons.'
            ],
            list: [
              'Immediate: Account access revoked',
              'Within 24 hours: Personal profile data deleted',
              'Within 7 days: AI conversation history deleted',
              'Within 30 days: Backups purged',
              'Retained: Transaction records (legal requirement)',
              'Retained: Aggregated analytics (anonymized)',
              'Retained: Logs required for security/fraud prevention'
            ]
          }
        ],
        conclusion: 'We respect your right to be forgotten while balancing legal obligations and platform security needs.'
      }
    },
    {
      id: 'changes',
      title: 'Policy Changes & Updates',
      icon: <Bell className="w-6 h-6 text-cyan-400" />,
      excerpt: 'How we handle updates to this privacy policy and notify you of changes.',
      category: 'Policy Updates',
      content: {
        introduction: 'Our privacy policy may change as our platform evolves or regulations update. We are committed to transparency and will always notify you of significant changes.',
        sections: [
          {
            heading: 'Notification Methods',
            paragraphs: [
              'We use multiple channels to notify you of privacy policy updates.'
            ],
            list: [
              'Email: Sent to your registered email address',
              'In-App Banner: Prominent notice when you log in',
              'Privacy Center: Updated version posted with change log',
              'Blog Post: Detailed explanation of significant changes',
              'Social Media: Announcements on official channels'
            ]
          },
          {
            heading: 'Advance Notice',
            paragraphs: [
              'We provide advance notice before implementing significant changes.'
            ],
            list: [
              'Minor Changes: Effective immediately',
              'Moderate Changes: 7 days advance notice',
              'Major Changes: 30 days advance notice',
              'Notice Period: Time to review and opt out if desired'
            ]
          }
        ],
        conclusion: 'We believe in transparency and user empowerment. Significant changes will never be made without clear notice and explanation.'
      }
    }
  ];

  const categories = ['all', 'Data Collection', 'Data Usage', 'Data Sharing', 'Security', 'User Rights', 'Cookies', 'AI & ML', 'International', 'Special Categories', 'Data Management', 'Policy Updates'];

  const filteredArticles = activeCategory === 'all' 
    ? articles 
    : articles.filter(article => article.category === activeCategory);

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <header className="border-b border-gray-800 bg-[#0a0a0a] sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <button
              onClick={() => onNavigate('home')}
              className="flex items-center gap-2 text-cyan-400 hover:text-cyan-300 transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
              <span className="text-sm">Back to Home</span>
            </button>
            <h1 className="text-2xl md:text-3xl font-bold text-white">
              Privacy Policy
            </h1>
            <div className="w-20"></div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-12">
        <div className="max-w-7xl mx-auto">
          {/* Introduction */}
          <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-8 mb-8">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-3 bg-cyan-900/50 border border-cyan-500/30 rounded-xl">
                <Shield className="w-8 h-8 text-cyan-400" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-white">Your Privacy Matters to Us</h2>
                <p className="text-gray-500">Last updated: November 2025</p>
              </div>
            </div>
            <p className="text-gray-400 leading-relaxed mb-4">
              At <span className="text-cyan-400 font-semibold">IA M AI</span>, we are committed to protecting your privacy across our global multi-agent platform. 
              This comprehensive privacy center explains how we collect, use, protect, and respect your data when you interact with our 17 AI agents and platform features.
            </p>
            <p className="text-gray-500 text-sm">
              We believe in transparency, user control, and responsible AI. Explore our detailed privacy articles below to understand your rights and our practices.
            </p>
          </div>

          {/* Category Filters */}
          <div className="mb-8">
            <h3 className="text-lg font-semibold mb-4 text-white">Browse by Category</h3>
            <div className="flex flex-wrap gap-2">
              {categories.map((category) => (
                <button
                  key={category}
                  onClick={() => setActiveCategory(category)}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                    activeCategory === category
                      ? 'bg-cyan-500 text-black shadow-lg'
                      : 'bg-gray-900/50 text-gray-400 hover:bg-gray-800 border border-gray-800 hover:text-cyan-400'
                  }`}
                >
                  {category === 'all' ? '📚 All Articles' : category}
                </button>
              ))}
            </div>
          </div>

          {/* Article Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            {filteredArticles.map((article) => (
              <div
                key={article.id}
                className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6 hover:border-cyan-500/50 transition-all cursor-pointer group"
                onClick={() => setSelectedArticle(article)}
              >
                <div className="flex items-start gap-4 mb-4">
                  <div className="p-3 bg-cyan-900/50 border border-cyan-500/30 rounded-xl group-hover:bg-cyan-500/20 transition-colors">
                    {article.icon}
                  </div>
                  <div className="flex-1">
                    <h3 className="text-lg font-bold text-white group-hover:text-cyan-400 transition-colors mb-1">
                      {article.title}
                    </h3>
                    <span className="inline-block px-2 py-1 bg-gray-800 text-cyan-400 text-xs rounded-full">
                      {article.category}
                    </span>
                  </div>
                </div>
                <p className="text-gray-400 text-sm mb-4 line-clamp-3">
                  {article.excerpt}
                </p>
                <div className="flex items-center gap-2 text-cyan-400 text-sm font-medium group-hover:text-cyan-300 transition-colors">
                  <BookOpen className="w-4 h-4" />
                  <span>Read Full Article</span>
                  <ExternalLink className="w-3 h-3 ml-auto" />
                </div>
              </div>
            ))}
          </div>

          {/* Contact Information */}
          <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-8">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-3 bg-cyan-900/50 border border-cyan-500/30 rounded-xl">
                <Mail className="w-6 h-6 text-cyan-400" />
              </div>
              <h2 className="text-2xl font-bold text-white">Questions or Concerns?</h2>
            </div>
            <p className="text-gray-400 mb-4">
              If you have any questions about this Privacy Policy or our data practices, please don't hesitate to reach out:
            </p>
            <div className="space-y-2 text-gray-400">
              <p><span className="text-cyan-400 font-semibold">Privacy Team:</span> privacy@iamai.global</p>
              <p><span className="text-cyan-400 font-semibold">Support:</span> support@iamai.global</p>
              <p><span className="text-cyan-400 font-semibold">Data Protection Officer:</span> dpo@iamai.global</p>
            </div>
          </div>
        </div>
      </main>

      {/* Article Modal */}
      {selectedArticle && (
        <div 
          className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4 animate-fadeIn"
          onClick={() => setSelectedArticle(null)}
        >
          <div 
            className="bg-[#0a0a0a] border border-gray-800 rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="sticky top-0 bg-[#0a0a0a] border-b border-gray-800 p-6 flex items-start justify-between z-10">
              <div className="flex items-start gap-4 flex-1">
                <div className="p-3 bg-cyan-900/50 border border-cyan-500/30 rounded-xl flex-shrink-0">
                  {selectedArticle.icon}
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-white mb-2">{selectedArticle.title}</h2>
                  <span className="inline-block px-3 py-1 bg-gray-800 text-cyan-400 text-sm rounded-full">
                    {selectedArticle.category}
                  </span>
                </div>
              </div>
              <button
                onClick={() => setSelectedArticle(null)}
                className="p-2 hover:bg-gray-800 rounded-lg transition-colors flex-shrink-0"
              >
                <X className="w-6 h-6 text-gray-400 hover:text-white" />
              </button>
            </div>

            {/* Modal Content - Scrollable */}
            <div className="overflow-y-auto max-h-[calc(90vh-140px)] p-6 space-y-6">
              {/* Introduction */}
              {selectedArticle.content.introduction && (
                <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-6">
                  <p className="text-gray-400 leading-relaxed">{selectedArticle.content.introduction}</p>
                </div>
              )}

              {/* Sections */}
              {selectedArticle.content.sections.map((section, index) => (
                <div key={index} className="space-y-4">
                  <h3 className="text-xl font-bold text-white flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-cyan-900/50 border border-cyan-500/30 flex items-center justify-center text-cyan-400 text-sm font-bold">
                      {index + 1}
                    </div>
                    {section.heading}
                  </h3>
                  
                  {section.paragraphs.map((paragraph, pIndex) => (
                    <p key={pIndex} className="text-gray-400 leading-relaxed pl-10">
                      {paragraph}
                    </p>
                  ))}

                  {section.list && section.list.length > 0 && (
                    <ul className="space-y-2 pl-10">
                      {section.list.map((item, itemIndex) => (
                        <li key={itemIndex} className="flex items-start gap-3">
                          <CheckCircle className="w-5 h-5 text-cyan-400 flex-shrink-0 mt-0.5" />
                          <span className="text-gray-400 text-sm">{item}</span>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              ))}

              {/* Conclusion */}
              {selectedArticle.content.conclusion && (
                <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-6 mt-8">
                  <div className="flex items-start gap-3">
                    <AlertCircle className="w-6 h-6 text-cyan-400 flex-shrink-0 mt-1" />
                    <p className="text-gray-400 leading-relaxed font-medium">{selectedArticle.content.conclusion}</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PrivacyPolicyPage;
