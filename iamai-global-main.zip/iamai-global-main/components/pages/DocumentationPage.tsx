import React, { useState, useRef, useEffect } from 'react';
import { Page } from '../../App';
import { ALL_AGENTS } from '../../agents';
import { AVAILABLE_AGENTS_DETAILS } from '../../data/agentDetailsData';

interface DocumentationPageProps {
  onNavigate: (page: Page) => void;
}

const navItems = {
  'Getting Started': [
    { title: 'Introduction', slug: 'introduction' },
    { title: 'Platform Architecture', slug: 'architecture' },
    { title: 'Authentication', slug: 'authentication' },
    { title: 'Quick Start', slug: 'quick-start' },
  ],
  'API Reference': [
    { title: 'Chat Endpoint', slug: 'api-chat' },
    { title: 'Agents Endpoint', slug: 'api-agents' },
    { title: 'Memory Endpoint', slug: 'api-memory' },
    { title: 'Tools Endpoint', slug: 'api-tools' },
    { title: 'Live Support Endpoint', slug: 'api-live-support' },
  ],
  'Agent SDK': [
    { title: 'Creating an Agent', slug: 'sdk-create' },
    { title: 'Defining Capabilities', slug: 'sdk-capabilities' },
    { title: 'Using Tools', slug: 'sdk-tools' },
    { title: 'Agent Events', slug: 'sdk-events' },
  ],
  'Agents': ALL_AGENTS.map(agent => ({
    title: agent.name,
    slug: `agent-${agent.id}`,
  })),
  'Toolbox': [
    { title: 'IP Info Lookup', slug: 'tool-ip-info' },
    { title: 'DNS Lookup', slug: 'tool-dns-lookup' },
    { title: 'WHOIS Lookup', slug: 'tool-whois' },
    { title: 'Ping Test', slug: 'tool-ping' },
    { title: 'Port Scanner', slug: 'tool-port-scanner' },
    { title: 'SSL Checker', slug: 'tool-ssl-checker' },
    { title: 'URL Encoder/Decoder', slug: 'tool-url-encoder' },
    { title: 'HTTP Header Checker', slug: 'tool-header-checker' },
    { title: 'API Testing Tool', slug: 'tool-api-tester' },
    { title: 'Domain Research Suite', slug: 'tool-domain-research' },
    { title: 'Website Screenshot', slug: 'tool-screenshot' },
    { title: 'Email Verification', slug: 'tool-email-verify' },
  ],
  'AI Labs': [
    { title: 'Overview', slug: 'ailab-overview' },
    { title: 'Emotional Intelligence Test', slug: 'ailab-emotional' },
    { title: 'Memory Persistence', slug: 'ailab-memory' },
    { title: 'Multi-Agent Swarm', slug: 'ailab-swarm' },
    { title: 'Latency Optimization', slug: 'ailab-latency' },
    { title: 'Vector Search Tuning', slug: 'ailab-vector' },
    { title: 'Stress Testing', slug: 'ailab-stress' },
  ],
  'AI Studio': [
    { title: 'Getting Started', slug: 'studio-getting-started' },
    { title: 'Visual Agent Builder', slug: 'studio-builder' },
    { title: 'Workflow Designer', slug: 'studio-workflow' },
    { title: 'Testing & Preview', slug: 'studio-testing' },
    { title: 'Deployment', slug: 'studio-deployment' },
  ],
  'Integration': [
    { title: 'Webhooks', slug: 'webhooks' },
    { title: 'Rate Limiting', slug: 'rate-limiting' },
    { title: 'Error Handling', slug: 'error-handling' },
  ],
};

const DocumentationContent: React.FC<{ slug: string }> = ({ slug }) => {
    const contentMap: Record<string, JSX.Element> = {
        'introduction': (
            <>
                <h1 className="text-3xl font-bold text-white mb-4">Introduction</h1>
                <p className="text-gray-300 mb-4">Welcome to the IA M AI developer documentation. This guide will walk you through everything you need to know to start building with our character-driven AI agent platform.</p>
                <p className="text-gray-300 mb-6">Our platform is designed to be extensible, scalable, and easy to use, whether you're interacting with our agents via our REST API or building your own custom agents with our SDK.</p>
                
                <h2 className="text-2xl font-bold text-white mt-8 mb-4">Core Concepts</h2>
                <ul className="list-disc pl-6 space-y-2 mb-6 text-gray-300">
                    <li><strong className="text-white">Agents:</strong> Specialized, containerized AI personas with unique roles and capabilities.</li>
                    <li><strong className="text-white">Universal Memory:</strong> A persistent, shared context layer that allows agents to retain information across conversations.</li>
                    <li><strong className="text-white">Skills:</strong> Modular capabilities that can be enabled for agents, such as web search or code execution.</li>
                    <li><strong className="text-white">Live Support:</strong> Real-time AI-powered customer support with document analysis and human escalation.</li>
                </ul>

                <h2 className="text-2xl font-bold text-white mt-8 mb-4">What You Can Build</h2>
                <ul className="list-disc pl-6 space-y-2 text-gray-300">
                    <li>Custom AI chatbots with unique personalities</li>
                    <li>Automated customer support systems</li>
                    <li>Intelligent content generation tools</li>
                    <li>Multi-agent collaborative systems</li>
                    <li>Context-aware conversational interfaces</li>
                </ul>
            </>
        ),
        'architecture': (
            <>
                <h1 className="text-3xl font-bold text-white mb-4">Platform Architecture</h1>
                <p className="text-gray-300 mb-6">Our platform is built on a modern, microservices-based architecture to ensure scalability and reliability.</p>
                
                <h2 className="text-2xl font-bold text-white mt-6 mb-4">Core Components</h2>
                
                <h3 className="text-xl font-bold text-cyan-400 mt-4 mb-2">API Gateway</h3>
                <p className="text-gray-300 mb-4">Central entry point for all client requests with load balancing and rate limiting.</p>

                <h3 className="text-xl font-bold text-cyan-400 mt-4 mb-2">Agent Service</h3>
                <p className="text-gray-300 mb-4">Manages agent instances, processes, and lifecycle. Each agent runs in an isolated process environment.</p>

                <h3 className="text-xl font-bold text-cyan-400 mt-4 mb-2">Memory Service</h3>
                <p className="text-gray-300 mb-4">Provides persistent, context-aware memory that agents can query and update during conversations.</p>

                <h3 className="text-xl font-bold text-cyan-400 mt-4 mb-2">Tool Service</h3>
                <p className="text-gray-300 mb-4">Registry and executor for agent tools and integrations.</p>

                <h3 className="text-xl font-bold text-cyan-400 mt-4 mb-2">Live Support Engine</h3>
                <p className="text-gray-300 mb-4">AI-powered support system with document analysis, ticket routing, and human escalation.</p>
            </>
        ),
        'authentication': (
            <>
                <h1 className="text-3xl font-bold text-white mb-4">Authentication</h1>
                <p className="text-gray-300 mb-4">All API requests to the IA M AI platform must be authenticated using API Keys. Your API keys carry many privileges, so be sure to keep them secure!</p>
                
                <h2 className="text-2xl font-bold text-white mt-6 mb-4">Getting Your API Key</h2>
                <ol className="list-decimal pl-6 space-y-2 mb-6 text-gray-300">
                    <li>Log in to your IA M AI account</li>
                    <li>Navigate to Settings → API Keys</li>
                    <li>Click "Generate New Key"</li>
                    <li>Copy and store your key securely</li>
                </ol>

                <h2 className="text-2xl font-bold text-white mt-6 mb-4">Using Your API Key</h2>
                <p className="text-gray-300 mb-2">Include your API key in the Authorization header:</p>
                <pre className="bg-gray-800/80 p-4 rounded-lg my-4 text-sm overflow-x-auto text-gray-100">
                    <code>{`Authorization: Bearer YOUR_API_KEY`}</code>
                </pre>

                <h2 className="text-2xl font-bold text-white mt-6 mb-4">Example Request</h2>
                <pre className="bg-gray-800/80 p-4 rounded-lg my-4 text-sm overflow-x-auto text-gray-100">
                    <code>{`curl https://api.iamai.global/v1/chat \\
  -H "Authorization: Bearer YOUR_API_KEY" \\
  -H "Content-Type: application/json" \\
  -d '{
    "agent": "AgentX",
    "message": "Hello, world!"
  }'`}</code>
                </pre>

                <h2 className="text-2xl font-bold text-white mt-6 mb-4">Security Best Practices</h2>
                <ul className="list-disc pl-6 space-y-2 text-gray-300">
                    <li>Never commit API keys to version control</li>
                    <li>Use environment variables to store sensitive data</li>
                    <li>Rotate your keys regularly</li>
                    <li>Revoke compromised keys immediately</li>
                </ul>
            </>
        ),
        'quick-start': (
            <>
                <h1 className="text-3xl font-bold text-white mb-4">Quick Start</h1>
                <p className="text-gray-300 mb-6">Get up and running with IA M AI in 5 minutes.</p>

                <h2 className="text-2xl font-bold text-white mt-6 mb-4">Step 1: Install SDK</h2>
                <pre className="bg-gray-800/80 p-4 rounded-lg my-4 text-sm overflow-x-auto text-gray-100">
                    <code>{`npm install @iamai/sdk`}</code>
                </pre>

                <h2 className="text-2xl font-bold text-white mt-6 mb-4">Step 2: Initialize Client</h2>
                <pre className="bg-gray-800/80 p-4 rounded-lg my-4 text-sm overflow-x-auto text-gray-100">
                    <code>{`import { IAMAIClient } from '@iamai/sdk';

const client = new IAMAIClient({
  apiKey: process.env.IAMAI_API_KEY,
});`}</code>
                </pre>

                <h2 className="text-2xl font-bold text-white mt-6 mb-4">Step 3: Start a Chat</h2>
                <pre className="bg-gray-800/80 p-4 rounded-lg my-4 text-sm overflow-x-auto text-gray-100">
                    <code>{`const response = await client.chat.create({
  agent: 'AgentX',
  message: 'Hello!',
});

console.log(response.message);`}</code>
                </pre>

                <h2 className="text-2xl font-bold text-white mt-6 mb-4">Next Steps</h2>
                <ul className="list-disc pl-6 space-y-2 text-gray-300">
                    <li>Read the full API Reference</li>
                    <li>Explore Agent SDK documentation</li>
                    <li>Check out example projects</li>
                </ul>
            </>
        ),
        'api-chat': (
            <>
                <h1 className="text-3xl font-bold text-white mb-4">Chat Endpoint</h1>
                <p className="text-gray-300 mb-6">Send messages to agents and receive responses.</p>

                <h2 className="text-2xl font-bold text-white mt-6 mb-4">POST /api/v1/chat</h2>
                <p className="text-gray-300 mb-4">Send a message to an agent and get a response.</p>

                <h3 className="text-xl font-bold text-cyan-400 mt-4 mb-2">Request</h3>
                <pre className="bg-gray-800/80 p-4 rounded-lg my-4 text-sm overflow-x-auto text-gray-100">
                    <code>{`{
  "agent": "string",
  "message": "string",
  "conversationId": "string (optional)",
  "context": "object (optional)",
  "tools": ["string (optional)"]
}`}</code>
                </pre>

                <h3 className="text-xl font-bold text-cyan-400 mt-4 mb-2">Response</h3>
                <pre className="bg-gray-800/80 p-4 rounded-lg my-4 text-sm overflow-x-auto text-gray-100">
                    <code>{`{
  "conversationId": "string",
  "message": "string",
  "timestamp": "ISO8601",
  "agentId": "string",
  "status": "success"
}`}</code>
                </pre>

                <h3 className="text-xl font-bold text-cyan-400 mt-4 mb-2">Example</h3>
                <pre className="bg-gray-800/80 p-4 rounded-lg my-4 text-sm overflow-x-auto text-gray-100">
                    <code>{`curl -X POST https://api.iamai.global/v1/chat \\
  -H "Authorization: Bearer YOUR_API_KEY" \\
  -H "Content-Type: application/json" \\
  -d '{
    "agent": "AgentX",
    "message": "What can you help me with?"
  }'`}</code>
                </pre>

                <h3 className="text-xl font-bold text-cyan-400 mt-4 mb-2">Error Codes</h3>
                <ul className="list-disc pl-6 space-y-2 text-gray-300">
                    <li>400: Invalid request format</li>
                    <li>401: Authentication failed</li>
                    <li>404: Agent not found</li>
                    <li>429: Rate limit exceeded</li>
                    <li>500: Server error</li>
                </ul>
            </>
        ),
        'api-agents': (
            <>
                <h1 className="text-3xl font-bold text-white mb-4">Agents Endpoint</h1>
                <p className="text-gray-300 mb-6">List, retrieve, and manage AI agents.</p>

                <h2 className="text-2xl font-bold text-white mt-6 mb-4">GET /api/v1/agents</h2>
                <p className="text-gray-300 mb-4">List all available agents.</p>

                <h3 className="text-xl font-bold text-cyan-400 mt-4 mb-2">Response</h3>
                <pre className="bg-gray-800/80 p-4 rounded-lg my-4 text-sm overflow-x-auto text-gray-100">
                    <code>{`{
  "agents": [
    {
      "id": "string",
      "name": "string",
      "description": "string",
      "personality": "object",
      "capabilities": ["string"],
      "status": "online|offline"
    }
  ]
}`}</code>
                </pre>

                <h2 className="text-2xl font-bold text-white mt-6 mb-4">GET /api/v1/agents/{'{id}'}</h2>
                <p className="text-gray-300 mb-4">Get details about a specific agent.</p>

                <h3 className="text-xl font-bold text-cyan-400 mt-4 mb-2">Response</h3>
                <pre className="bg-gray-800/80 p-4 rounded-lg my-4 text-sm overflow-x-auto text-gray-100">
                    <code>{`{
  "id": "string",
  "name": "string",
  "description": "string",
  "personality": {
    "traits": ["string"],
    "communicationStyle": "string"
  },
  "capabilities": ["string"],
  "tools": ["string"],
  "status": "online",
  "createdAt": "ISO8601"
}`}</code>
                </pre>

                <h2 className="text-2xl font-bold text-white mt-6 mb-4">Example</h2>
                <pre className="bg-gray-800/80 p-4 rounded-lg my-4 text-sm overflow-x-auto text-gray-100">
                    <code>{`curl https://api.iamai.global/v1/agents \\
  -H "Authorization: Bearer YOUR_API_KEY"`}</code>
                </pre>
            </>
        ),
        'api-memory': (
            <>
                <h1 className="text-3xl font-bold text-white mb-4">Memory Endpoint</h1>
                <p className="text-gray-300 mb-6">Access and manage the Universal Memory system.</p>

                <h2 className="text-2xl font-bold text-white mt-6 mb-4">POST /api/v1/memory/store</h2>
                <p className="text-gray-300 mb-4">Store information in Universal Memory.</p>

                <h3 className="text-xl font-bold text-cyan-400 mt-4 mb-2">Request</h3>
                <pre className="bg-gray-800/80 p-4 rounded-lg my-4 text-sm overflow-x-auto text-gray-100">
                    <code>{`{
  "key": "string",
  "value": "object",
  "ttl": "number (seconds, optional)",
  "scope": "global|user|conversation"
}`}</code>
                </pre>

                <h2 className="text-2xl font-bold text-white mt-6 mb-4">GET /api/v1/memory/retrieve</h2>
                <p className="text-gray-300 mb-4">Retrieve information from Universal Memory.</p>

                <h3 className="text-xl font-bold text-cyan-400 mt-4 mb-2">Query Parameters</h3>
                <ul className="list-disc pl-6 space-y-2 text-gray-300 mb-4">
                    <li><code className="text-cyan-300">key</code> - Memory key to retrieve</li>
                    <li><code className="text-cyan-300">scope</code> - Memory scope (global, user, or conversation)</li>
                </ul>

                <h3 className="text-xl font-bold text-cyan-400 mt-4 mb-2">Response</h3>
                <pre className="bg-gray-800/80 p-4 rounded-lg my-4 text-sm overflow-x-auto text-gray-100">
                    <code>{`{
  "key": "string",
  "value": "object",
  "createdAt": "ISO8601",
  "updatedAt": "ISO8601"
}`}</code>
                </pre>
            </>
        ),
        'api-tools': (
            <>
                <h1 className="text-3xl font-bold text-white mb-4">Tools Endpoint</h1>
                <p className="text-gray-300 mb-6">Access the Toolbox API for utility tools.</p>

                <h2 className="text-2xl font-bold text-white mt-6 mb-4">GET /api/v1/tools</h2>
                <p className="text-gray-300 mb-4">List all available utility tools.</p>

                <h3 className="text-xl font-bold text-cyan-400 mt-4 mb-2">Response</h3>
                <pre className="bg-gray-800/80 p-4 rounded-lg my-4 text-sm overflow-x-auto text-gray-100">
                    <code>{`{
  "tools": [
    {
      "id": "string",
      "name": "string",
      "description": "string",
      "category": "string",
      "endpoint": "string",
      "status": "available|coming-soon"
    }
  ]
}`}</code>
                </pre>

                <h2 className="text-2xl font-bold text-white mt-6 mb-4">POST /api/v1/tools/ip-info</h2>
                <p className="text-gray-300 mb-4">Get IP information and geolocation.</p>

                <h3 className="text-xl font-bold text-cyan-400 mt-4 mb-2">Request</h3>
                <pre className="bg-gray-800/80 p-4 rounded-lg my-4 text-sm overflow-x-auto text-gray-100">
                    <code>{`{ "ip": "string" }`}</code>
                </pre>

                <h2 className="text-2xl font-bold text-white mt-6 mb-4">Supported Tools</h2>
                <ul className="list-disc pl-6 space-y-2 text-gray-300">
                    <li>/tools/ip-info - IP information lookup</li>
                    <li>/tools/dns-lookup - DNS records query</li>
                    <li>/tools/whois - Domain registration info</li>
                    <li>/tools/ssl-checker - SSL certificate validation</li>
                </ul>
            </>
        ),
        'api-live-support': (
            <>
                <h1 className="text-3xl font-bold text-white mb-4">Live Support Endpoint</h1>
                <p className="text-gray-300 mb-6">Real-time AI-powered customer support with document analysis.</p>

                <h2 className="text-2xl font-bold text-white mt-6 mb-4">POST /api/v1/live-support/chat</h2>
                <p className="text-gray-300 mb-4">Send a message to Live Support.</p>

                <h3 className="text-xl font-bold text-cyan-400 mt-4 mb-2">Request</h3>
                <pre className="bg-gray-800/80 p-4 rounded-lg my-4 text-sm overflow-x-auto text-gray-100">
                    <code>{`{
  "message": "string",
  "documentIds": ["string (optional)"],
  "conversationHistory": ["object (optional)"],
  "userId": "string (optional)"
}`}</code>
                </pre>

                <h3 className="text-xl font-bold text-cyan-400 mt-4 mb-2">Response</h3>
                <pre className="bg-gray-800/80 p-4 rounded-lg my-4 text-sm overflow-x-auto text-gray-100">
                    <code>{`{
  "response": "string",
  "ticket": {
    "id": "string",
    "category": "string",
    "severity": "low|medium|high",
    "status": "open"
  },
  "timestamp": "ISO8601"
}`}</code>
                </pre>

                <h2 className="text-2xl font-bold text-white mt-6 mb-4">POST /api/v1/live-support/upload</h2>
                <p className="text-gray-300 mb-4">Upload documents for analysis.</p>

                <h3 className="text-xl font-bold text-cyan-400 mt-4 mb-2">Request</h3>
                <p className="text-gray-300 mb-2">Form Data with file upload</p>

                <h3 className="text-xl font-bold text-cyan-400 mt-4 mb-2">Supported Formats</h3>
                <ul className="list-disc pl-6 space-y-2 text-gray-300">
                    <li>PDF</li>
                    <li>DOC/DOCX</li>
                    <li>TXT</li>
                    <li>JPG/PNG/GIF</li>
                </ul>

                <h2 className="text-2xl font-bold text-white mt-6 mb-4">Features</h2>
                <ul className="list-disc pl-6 space-y-2 text-gray-300">
                    <li>Real-time AI responses powered by Gemini</li>
                    <li>Document analysis and extraction</li>
                    <li>Automatic issue classification</li>
                    <li>Support ticket generation</li>
                    <li>Human escalation support</li>
                </ul>
            </>
        ),
        'sdk-create': (
            <>
                <h1 className="text-3xl font-bold text-white mb-4">Creating an Agent</h1>
                <p className="text-gray-300 mb-6">Learn how to create custom AI agents with unique personalities and capabilities.</p>

                <h2 className="text-2xl font-bold text-white mt-6 mb-4">Basic Agent</h2>
                <pre className="bg-gray-800/80 p-4 rounded-lg my-4 text-sm overflow-x-auto text-gray-100">
                    <code>{`import { Agent } from '@iamai/sdk';

const myAgent = new Agent({
  name: 'MyAgent',
  personality: {
    traits: ['helpful', 'friendly', 'knowledgeable'],
    communicationStyle: 'conversational'
  },
  systemPrompt: 'You are a helpful assistant...'
});

await myAgent.deploy();`}</code>
                </pre>

                <h2 className="text-2xl font-bold text-white mt-6 mb-4">Agent Configuration</h2>
                <ul className="list-disc pl-6 space-y-2 text-gray-300 mb-6">
                    <li><code className="text-cyan-300">name</code> - Agent identifier</li>
                    <li><code className="text-cyan-300">personality</code> - Behavioral traits</li>
                    <li><code className="text-cyan-300">systemPrompt</code> - Core instructions</li>
                    <li><code className="text-cyan-300">capabilities</code> - Available features</li>
                    <li><code className="text-cyan-300">tools</code> - Integrated tools</li>
                </ul>

                <h2 className="text-2xl font-bold text-white mt-6 mb-4">Adding Context</h2>
                <pre className="bg-gray-800/80 p-4 rounded-lg my-4 text-sm overflow-x-auto text-gray-100">
                    <code>{`myAgent.setContext({
  company: 'ACME Corp',
  domain: 'customer-support',
  knowledgeBase: 'path/to/kb'
});`}</code>
                </pre>
            </>
        ),
        'sdk-capabilities': (
            <>
                <h1 className="text-3xl font-bold text-white mb-4">Defining Capabilities</h1>
                <p className="text-gray-300 mb-6">Configure what your agent can do.</p>

                <h2 className="text-2xl font-bold text-white mt-6 mb-4">Available Capabilities</h2>
                <ul className="list-disc pl-6 space-y-2 text-gray-300 mb-6">
                    <li><code className="text-cyan-300">text_generation</code> - Generate text responses</li>
                    <li><code className="text-cyan-300">web_search</code> - Search the web for information</li>
                    <li><code className="text-cyan-300">code_execution</code> - Execute code snippets</li>
                    <li><code className="text-cyan-300">file_processing</code> - Read and analyze files</li>
                    <li><code className="text-cyan-300">sentiment_analysis</code> - Analyze user sentiment</li>
                </ul>

                <h2 className="text-2xl font-bold text-white mt-6 mb-4">Enable Capabilities</h2>
                <pre className="bg-gray-800/80 p-4 rounded-lg my-4 text-sm overflow-x-auto text-gray-100">
                    <code>{`const agent = new Agent({
  name: 'SearchAgent',
  capabilities: [
    'text_generation',
    'web_search',
    'sentiment_analysis'
  ]
});`}</code>
                </pre>

                <h2 className="text-2xl font-bold text-white mt-6 mb-4">Capability Configuration</h2>
                <pre className="bg-gray-800/80 p-4 rounded-lg my-4 text-sm overflow-x-auto text-gray-100">
                    <code>{`agent.configureCapability('web_search', {
  provider: 'google',
  maxResults: 10,
  timeoutMs: 5000
});`}</code>
                </pre>
            </>
        ),
        'sdk-tools': (
            <>
                <h1 className="text-3xl font-bold text-white mb-4">Using Tools</h1>
                <p className="text-gray-300 mb-6">Integrate third-party tools and utilities with your agents.</p>

                <h2 className="text-2xl font-bold text-white mt-6 mb-4">Available Tools</h2>
                <ul className="list-disc pl-6 space-y-2 text-gray-300 mb-6">
                    <li><code className="text-cyan-300">calculator</code> - Perform calculations</li>
                    <li><code className="text-cyan-300">weather</code> - Get weather information</li>
                    <li><code className="text-cyan-300">database</code> - Query databases</li>
                    <li><code className="text-cyan-300">email</code> - Send emails</li>
                    <li><code className="text-cyan-300">slack</code> - Integrate with Slack</li>
                </ul>

                <h2 className="text-2xl font-bold text-white mt-6 mb-4">Adding Tools</h2>
                <pre className="bg-gray-800/80 p-4 rounded-lg my-4 text-sm overflow-x-auto text-gray-100">
                    <code>{`import { tools } from '@iamai/sdk';

const agent = new Agent({
  name: 'HelperBot',
  tools: [
    tools.calculator,
    tools.weather,
    {
      name: 'custom_tool',
      description: 'My custom tool',
      execute: async (params) => {
        return await myFunction(params);
      }
    }
  ]
});`}</code>
                </pre>

                <h2 className="text-2xl font-bold text-white mt-6 mb-4">Tool Usage</h2>
                <pre className="bg-gray-800/80 p-4 rounded-lg my-4 text-sm overflow-x-auto text-gray-100">
                    <code>{`agent.on('tool_call', async (toolName, params) => {
  console.log(\`Calling tool: \${toolName}\`);
  const result = await agent.executeTool(toolName, params);
  return result;
});`}</code>
                </pre>
            </>
        ),
        'sdk-events': (
            <>
                <h1 className="text-3xl font-bold text-white mb-4">Agent Events</h1>
                <p className="text-gray-300 mb-6">Listen to and respond to agent lifecycle events.</p>

                <h2 className="text-2xl font-bold text-white mt-6 mb-4">Available Events</h2>
                <ul className="list-disc pl-6 space-y-2 text-gray-300 mb-6">
                    <li><code className="text-cyan-300">message</code> - New message received</li>
                    <li><code className="text-cyan-300">response</code> - Response generated</li>
                    <li><code className="text-cyan-300">tool_call</code> - Tool execution requested</li>
                    <li><code className="text-cyan-300">error</code> - Error occurred</li>
                    <li><code className="text-cyan-300">deployed</code> - Agent deployed</li>
                    <li><code className="text-cyan-300">shutdown</code> - Agent shutting down</li>
                </ul>

                <h2 className="text-2xl font-bold text-white mt-6 mb-4">Event Listeners</h2>
                <pre className="bg-gray-800/80 p-4 rounded-lg my-4 text-sm overflow-x-auto text-gray-100">
                    <code>{`agent.on('message', (data) => {
  console.log('New message:', data.content);
});

agent.on('tool_call', async (toolName, params) => {
  console.log(\`Executing \${toolName}\`);
});

agent.on('error', (error) => {
  console.error('Agent error:', error);
});`}</code>
                </pre>

                <h2 className="text-2xl font-bold text-white mt-6 mb-4">Emitting Events</h2>
                <pre className="bg-gray-800/80 p-4 rounded-lg my-4 text-sm overflow-x-auto text-gray-100">
                    <code>{`agent.emit('custom_event', {
  data: 'custom data'
});`}</code>
                </pre>
            </>
        ),
        'webhooks': (
            <>
                <h1 className="text-3xl font-bold text-white mb-4">Webhooks</h1>
                <p className="text-gray-300 mb-6">Receive real-time notifications about events in your agents.</p>

                <h2 className="text-2xl font-bold text-white mt-6 mb-4">Registering a Webhook</h2>
                <pre className="bg-gray-800/80 p-4 rounded-lg my-4 text-sm overflow-x-auto text-gray-100">
                    <code>{`curl -X POST https://api.iamai.global/v1/webhooks \\
  -H "Authorization: Bearer YOUR_API_KEY" \\
  -H "Content-Type: application/json" \\
  -d '{
    "url": "https://your-domain.com/webhook",
    "events": ["message.received", "agent.deployed"],
    "active": true
  }'`}</code>
                </pre>

                <h2 className="text-2xl font-bold text-white mt-6 mb-4">Webhook Events</h2>
                <ul className="list-disc pl-6 space-y-2 text-gray-300 mb-6">
                    <li><code className="text-cyan-300">message.received</code> - New message received</li>
                    <li><code className="text-cyan-300">agent.deployed</code> - Agent deployed</li>
                    <li><code className="text-cyan-300">agent.error</code> - Agent error</li>
                    <li><code className="text-cyan-300">memory.updated</code> - Memory updated</li>
                </ul>

                <h2 className="text-2xl font-bold text-white mt-6 mb-4">Payload Example</h2>
                <pre className="bg-gray-800/80 p-4 rounded-lg my-4 text-sm overflow-x-auto text-gray-100">
                    <code>{`{
  "event": "message.received",
  "timestamp": "2024-01-15T10:30:00Z",
  "data": {
    "agentId": "agent-123",
    "conversationId": "conv-456",
    "message": "Hello!"
  }
}`}</code>
                </pre>
            </>
        ),
        'rate-limiting': (
            <>
                <h1 className="text-3xl font-bold text-white mb-4">Rate Limiting</h1>
                <p className="text-gray-300 mb-6">Understand rate limits on API endpoints.</p>

                <h2 className="text-2xl font-bold text-white mt-6 mb-4">Default Limits</h2>
                <ul className="list-disc pl-6 space-y-2 text-gray-300 mb-6">
                    <li><code className="text-cyan-300">/chat</code> - 100 requests per minute</li>
                    <li><code className="text-cyan-300">/agents</code> - 1000 requests per hour</li>
                    <li><code className="text-cyan-300">/memory</code> - 500 requests per minute</li>
                    <li><code className="text-cyan-300">/live-support</code> - 50 requests per minute</li>
                </ul>

                <h2 className="text-2xl font-bold text-white mt-6 mb-4">Rate Limit Headers</h2>
                <pre className="bg-gray-800/80 p-4 rounded-lg my-4 text-sm overflow-x-auto text-gray-100">
                    <code>{`X-RateLimit-Limit: 100
X-RateLimit-Remaining: 99
X-RateLimit-Reset: 1641234567`}</code>
                </pre>

                <h2 className="text-2xl font-bold text-white mt-6 mb-4">Handling Rate Limits</h2>
                <p className="text-gray-300 mb-2">When you hit a rate limit, you'll receive a 429 response:</p>
                <pre className="bg-gray-800/80 p-4 rounded-lg my-4 text-sm overflow-x-auto text-gray-100">
                    <code>{`{
  "error": "Too many requests",
  "retryAfter": 60
}`}</code>
                </pre>

                <p className="text-gray-300 mt-4">Wait the specified number of seconds before retrying.</p>
            </>
        ),
        'error-handling': (
            <>
                <h1 className="text-3xl font-bold text-white mb-4">Error Handling</h1>
                <p className="text-gray-300 mb-6">Understand and handle API errors gracefully.</p>

                <h2 className="text-2xl font-bold text-white mt-6 mb-4">Error Response Format</h2>
                <pre className="bg-gray-800/80 p-4 rounded-lg my-4 text-sm overflow-x-auto text-gray-100">
                    <code>{`{
  "error": {
    "code": "string",
    "message": "string",
    "details": "object (optional)"
  }
}`}</code>
                </pre>

                <h2 className="text-2xl font-bold text-white mt-6 mb-4">Common Error Codes</h2>
                <ul className="list-disc pl-6 space-y-2 text-gray-300 mb-6">
                    <li><code className="text-cyan-300">INVALID_REQUEST</code> - Request format is invalid</li>
                    <li><code className="text-cyan-300">AUTHENTICATION_FAILED</code> - API key invalid</li>
                    <li><code className="text-cyan-300">RESOURCE_NOT_FOUND</code> - Resource doesn't exist</li>
                    <li><code className="text-cyan-300">RATE_LIMIT_EXCEEDED</code> - Rate limit hit</li>
                    <li><code className="text-cyan-300">INTERNAL_ERROR</code> - Server error</li>
                </ul>

                <h2 className="text-2xl font-bold text-white mt-6 mb-4">Error Handling Example</h2>
                <pre className="bg-gray-800/80 p-4 rounded-lg my-4 text-sm overflow-x-auto text-gray-100">
                    <code>{`try {
  const response = await client.chat.create({
    agent: 'AgentX',
    message: 'Hello'
  });
} catch (error) {
  if (error.code === 'RATE_LIMIT_EXCEEDED') {
    console.log('Rate limited. Retry after', error.retryAfter);
  } else if (error.code === 'AUTHENTICATION_FAILED') {
    console.log('Invalid API key');
  } else {
    console.error('Unexpected error:', error);
  }
}`}</code>
                </pre>
            </>
        ),
    };

    // Dynamically add agent documentation
    ALL_AGENTS.forEach(agent => {
        const agentDetails = AVAILABLE_AGENTS_DETAILS[agent.id];
        const agentSlug = `agent-${agent.id}`;
        
        contentMap[agentSlug] = (
            <>
                <div className="flex items-center gap-4 mb-6">
                    <div className="w-16 h-16 flex items-center justify-center rounded-xl bg-gray-800 border border-gray-700 text-cyan-400">
                        <i className={`${agent.icon} text-4xl`}></i>
                    </div>
                    <div>
                        <h1 className="text-3xl font-bold text-white mb-1">{agent.name}</h1>
                        <p className="text-cyan-400 text-lg font-medium">{agent.role}</p>
                    </div>
                </div>

                <div className="mb-6 p-4 bg-gray-800/50 rounded-lg border border-gray-700">
                    <p className="text-gray-300 text-lg">{agent.description}</p>
                </div>

                {agentDetails && (
                    <>
                        <h2 className="text-2xl font-bold text-white mt-8 mb-4">Overview</h2>
                        <p className="text-gray-300 mb-6">{agentDetails.overview}</p>

                        <h2 className="text-2xl font-bold text-white mt-8 mb-4">Best For</h2>
                        <p className="text-gray-300 mb-6">{agentDetails.bestFor}</p>

                        {agentDetails.capabilities && agentDetails.capabilities.length > 0 && (
                            <>
                                <h2 className="text-2xl font-bold text-white mt-8 mb-4">Capabilities</h2>
                                <ul className="list-disc pl-6 space-y-2 mb-6 text-gray-300">
                                    {agentDetails.capabilities.map((capability, idx) => (
                                        <li key={idx}>{capability}</li>
                                    ))}
                                </ul>
                            </>
                        )}

                        {agentDetails.features && agentDetails.features.length > 0 && (
                            <>
                                <h2 className="text-2xl font-bold text-white mt-8 mb-4">Key Features</h2>
                                <ul className="list-disc pl-6 space-y-2 mb-6 text-gray-300">
                                    {agentDetails.features.map((feature, idx) => (
                                        <li key={idx}>{feature}</li>
                                    ))}
                                </ul>
                            </>
                        )}

                        {agentDetails.howItWorks && agentDetails.howItWorks.length > 0 && (
                            <>
                                <h2 className="text-2xl font-bold text-white mt-8 mb-4">How It Works</h2>
                                <ol className="list-decimal pl-6 space-y-2 mb-6 text-gray-300">
                                    {agentDetails.howItWorks.map((step, idx) => (
                                        <li key={idx}>{step}</li>
                                    ))}
                                </ol>
                            </>
                        )}

                        {agentDetails.useCases && agentDetails.useCases.length > 0 && (
                            <>
                                <h2 className="text-2xl font-bold text-white mt-8 mb-4">Use Cases</h2>
                                <ul className="list-disc pl-6 space-y-2 mb-6 text-gray-300">
                                    {agentDetails.useCases.map((useCase, idx) => (
                                        <li key={idx}>{useCase}</li>
                                    ))}
                                </ul>
                            </>
                        )}

                        {agentDetails.benefits && agentDetails.benefits.length > 0 && (
                            <>
                                <h2 className="text-2xl font-bold text-white mt-8 mb-4">Benefits</h2>
                                <ul className="list-disc pl-6 space-y-2 mb-6 text-gray-300">
                                    {agentDetails.benefits.map((benefit, idx) => (
                                        <li key={idx}>{benefit}</li>
                                    ))}
                                </ul>
                            </>
                        )}

                        {agentDetails.keyStrengths && agentDetails.keyStrengths.length > 0 && (
                            <>
                                <h2 className="text-2xl font-bold text-white mt-8 mb-4">Key Strengths</h2>
                                <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-6">
                                    {agentDetails.keyStrengths.map((strength, idx) => (
                                        <div key={idx} className="bg-cyan-500/10 border border-cyan-500/30 rounded-lg p-3 text-center">
                                            <span className="text-cyan-300 font-medium">{strength}</span>
                                        </div>
                                    ))}
                                </div>
                            </>
                        )}
                    </>
                )}

                {/* Agent Technical Details */}
                <h2 className="text-2xl font-bold text-white mt-8 mb-4">Technical Details</h2>
                
                <h3 className="text-xl font-bold text-cyan-400 mt-4 mb-3">Capabilities</h3>
                <ul className="list-disc pl-6 space-y-2 mb-6 text-gray-300">
                    <li><strong>File Attachments:</strong> {agent.capabilities.canAttachFiles ? '✅ Supported' : '❌ Not supported'}</li>
                    <li><strong>Voice Input:</strong> {agent.capabilities.canUseVoice ? '✅ Supported' : '❌ Not supported'}</li>
                    <li><strong>Web Access:</strong> {agent.capabilities.canAccessWeb ? '✅ Supported' : '❌ Not supported'}</li>
                </ul>

                {agent.personalityMatrix && (
                    <>
                        <h3 className="text-xl font-bold text-cyan-400 mt-4 mb-3">Personality Profile</h3>
                        <div className="space-y-3 mb-6">
                            <div className="flex items-center gap-4">
                                <span className="text-gray-300 w-32">Formality:</span>
                                <div className="flex-1 bg-gray-700/50 rounded-full h-3">
                                    <div 
                                        className="bg-gradient-to-r from-cyan-500 to-cyan-400 h-3 rounded-full transition-all"
                                        style={{ width: `${agent.personalityMatrix.formality}%` }}
                                    ></div>
                                </div>
                                <span className="text-cyan-400 w-12 text-right">{agent.personalityMatrix.formality}%</span>
                            </div>
                            <div className="flex items-center gap-4">
                                <span className="text-gray-300 w-32">Humor:</span>
                                <div className="flex-1 bg-gray-700/50 rounded-full h-3">
                                    <div 
                                        className="bg-gradient-to-r from-cyan-500 to-cyan-400 h-3 rounded-full transition-all"
                                        style={{ width: `${agent.personalityMatrix.humor}%` }}
                                    ></div>
                                </div>
                                <span className="text-cyan-400 w-12 text-right">{agent.personalityMatrix.humor}%</span>
                            </div>
                            <div className="flex items-center gap-4">
                                <span className="text-gray-300 w-32">Enthusiasm:</span>
                                <div className="flex-1 bg-gray-700/50 rounded-full h-3">
                                    <div 
                                        className="bg-gradient-to-r from-cyan-500 to-cyan-400 h-3 rounded-full transition-all"
                                        style={{ width: `${agent.personalityMatrix.enthusiasm}%` }}
                                    ></div>
                                </div>
                                <span className="text-cyan-400 w-12 text-right">{agent.personalityMatrix.enthusiasm}%</span>
                            </div>
                        </div>
                    </>
                )}

                {agent.examples?.prompts && agent.examples.prompts.length > 0 && (
                    <>
                        <h2 className="text-2xl font-bold text-white mt-8 mb-4">Example Interactions</h2>
                        <p className="text-gray-300 mb-4">Here are some examples of how you can interact with {agent.name}:</p>
                        
                        <div className="space-y-4">
                            {agent.examples.prompts.slice(0, 4).map((prompt, idx) => (
                                <div key={idx} className="border border-gray-700 rounded-lg overflow-hidden">
                                    <div className="bg-gray-800/50 p-4">
                                        <p className="text-sm font-semibold text-cyan-400 mb-1">You:</p>
                                        <p className="text-gray-300">"{prompt}"</p>
                                    </div>
                                    {agent.examples?.responses?.[idx] && (
                                        <div className="bg-gray-900/50 p-4 border-t border-gray-700">
                                            <p className="text-sm font-semibold text-white mb-1">{agent.name}:</p>
                                            <p className="text-gray-400 italic">"{agent.examples.responses[idx]}"</p>
                                        </div>
                                    )}
                                </div>
                            ))}
                        </div>
                    </>
                )}

                <h2 className="text-2xl font-bold text-white mt-8 mb-4">API Usage</h2>
                <p className="text-gray-300 mb-4">Send a message to {agent.name} using the Chat API:</p>
                <pre className="bg-gray-800/80 p-4 rounded-lg my-4 text-sm overflow-x-auto text-gray-100">
                    <code>{`curl -X POST https://api.iamai.global/v1/chat \\
  -H "Authorization: Bearer YOUR_API_KEY" \\
  -H "Content-Type: application/json" \\
  -d '{
    "agent": "${agent.id}",
    "message": "Your message here"
  }'`}</code>
                </pre>
            </>
        );
    });

    // Toolbox Tools Content
    if (slug.startsWith('tool-')) {
        const toolMap: Record<string, { title: string; description: string; features: string[]; usage: string }> = {
            'tool-ip-info': {
                title: 'IP Info Lookup',
                description: 'Get comprehensive information about any IP address including geolocation, ISP, security analysis, VPN/Proxy detection, and blacklist checking.',
                features: [
                    'Geolocation with interactive Google Maps',
                    'ISP and Organization details',
                    'Security assessment and risk scoring',
                    'VPN/Proxy/TOR detection',
                    'Blacklist checking across multiple RBLs',
                    'ASN and network information',
                    'Hostname resolution',
                ],
                usage: 'Navigate to the IP Info page and enter any IPv4 address to get detailed analysis. The tool provides real-time data from multiple sources including geolocation, security threats, and network details.'
            },
            'tool-dns-lookup': {
                title: 'DNS Lookup',
                description: 'Perform comprehensive DNS queries to find A, AAAA, MX, TXT, CNAME, NS, and other DNS records for any domain.',
                features: ['A/AAAA Records', 'MX Records', 'TXT Records', 'CNAME Records', 'NS (Name Server) Records', 'SOA Records', 'Real-time DNS resolution'],
                usage: 'Enter a domain name and select the record type you want to query. The tool will retrieve and display all available DNS records for that domain.'
            },
            'tool-whois': {
                title: 'WHOIS Lookup',
                description: 'Look up domain registration details, registrar information, ownership data, and expiration dates.',
                features: ['Domain Owner Information', 'Registrar Details', 'Registration Date', 'Expiration Date', 'Name Servers', 'Contact Information', 'Domain Status'],
                usage: 'Enter a domain name to retrieve its WHOIS information including ownership, registration dates, and registrar details.'
            },
            'tool-ping': {
                title: 'Ping Test',
                description: 'Test the reachability of a host on an IP network and measure round-trip time (latency).',
                features: ['Latency Measurement', 'Packet Loss Detection', 'Connection Status', 'Response Time Analysis', 'Multiple Ping Attempts', 'Average/Min/Max Statistics'],
                usage: 'Enter an IP address or hostname to test network connectivity and measure latency.'
            },
            'tool-port-scanner': {
                title: 'Port Scanner',
                description: 'Scan for open ports on a server and identify running services and potential vulnerabilities.',
                features: ['Common Port Scanning', 'Custom Port Range', 'Service Identification', 'Port Status Detection', 'Security Assessment', 'Protocol Detection'],
                usage: 'Enter an IP address or hostname and specify port ranges to scan. The tool will identify open ports and running services.'
            },
            'tool-ssl-checker': {
                title: 'SSL Certificate Checker',
                description: 'Verify SSL/TLS certificate details, check expiration dates, validate certificate chains, and assess security configuration.',
                features: ['Certificate Details', 'Expiration Warnings', 'Chain Validation', 'Issuer Information', 'Security Grade', 'Cipher Suite Analysis', 'Protocol Support'],
                usage: 'Enter a domain name to analyze its SSL/TLS certificate and security configuration.'
            },
            'tool-url-encoder': {
                title: 'URL Encoder/Decoder',
                description: 'Encode and decode URLs, handle special characters, and support various encoding formats including percent-encoding and Base64.',
                features: ['URL Encoding', 'URL Decoding', 'Base64 Support', 'Special Character Handling', 'Batch Processing', 'Format Validation'],
                usage: 'Paste your URL or text to encode/decode it. Supports multiple encoding formats.'
            },
            'tool-header-checker': {
                title: 'HTTP Header Checker',
                description: 'Analyze HTTP response headers, status codes, and security headers from web servers.',
                features: ['Response Headers', 'Status Code Analysis', 'Server Information', 'Security Headers', 'Cache Control', 'Content Type', 'Redirect Analysis'],
                usage: 'Enter a URL to analyze its HTTP headers and server response. Identifies missing security headers and configuration issues.'
            },
            'tool-api-tester': {
                title: 'API Testing Tool',
                description: 'Test REST API endpoints with custom headers, authentication, request bodies, and multiple HTTP methods. Real-time response viewing.',
                features: ['All HTTP Methods (GET, POST, PUT, DELETE, PATCH)', 'Custom Headers', 'Bearer Token Auth', 'JSON Request Body', 'Real-time Response', 'Response Time', 'Status Code Display'],
                usage: 'Enter an API endpoint URL, select HTTP method, add headers and body data, then send the request to see the response.'
            },
            'tool-domain-research': {
                title: 'Domain Research Suite',
                description: 'Comprehensive domain intelligence with WHOIS data, historical records, and related domain discovery.',
                features: ['WHOIS Data', 'Historical Records', 'Related Domain Discovery', 'Domain Monitoring', 'Ownership Timeline', 'Registrar History'],
                usage: 'Enter a domain to get comprehensive intelligence including current and historical WHOIS data, related domains, and ownership changes.'
            },
            'tool-screenshot': {
                title: 'Website Screenshot',
                description: 'Capture high-quality screenshots of any website with custom dimensions, device presets (desktop/mobile/tablet), and configurable quality.',
                features: ['Multiple Device Presets', 'Custom Dimensions', 'Full Page Capture', 'High Resolution', 'Multiple Format Support', 'Responsive Testing'],
                usage: 'Enter a website URL, choose a device preset or custom dimensions, and capture a screenshot for visual testing.'
            },
            'tool-email-verify': {
                title: 'Email Verification',
                description: 'Validate email addresses with syntax checking, domain validation, SMTP verification, and disposable email detection.',
                features: ['Syntax Validation', 'Domain Verification', 'SMTP Checking', 'Disposable Email Detection', 'Bulk Verification', 'MX Record Validation'],
                usage: 'Enter email addresses (one per line for bulk) to verify their validity, check DNS records, and detect disposable emails.'
            },
        };

        const tool = toolMap[slug];
        if (tool) {
            return (
                <div className="prose prose-invert prose-lg max-w-none text-gray-300 leading-relaxed">
                    <h1 className="text-3xl font-bold text-white mb-4">{tool.title}</h1>
                    <p className="text-gray-300 mb-6">{tool.description}</p>
                    
                    <h2 className="text-2xl font-bold text-white mt-8 mb-4">Features</h2>
                    <ul className="list-disc pl-6 space-y-2 mb-6 text-gray-300">
                        {tool.features.map((feature, idx) => (
                            <li key={idx}>{feature}</li>
                        ))}
                    </ul>

                    <h2 className="text-2xl font-bold text-white mt-8 mb-4">How to Use</h2>
                    <p className="text-gray-300 mb-6">{tool.usage}</p>

                    <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-lg p-6 mt-6">
                        <h3 className="text-lg font-bold text-cyan-400 mb-2">Access the Tool</h3>
                        <p className="text-sm text-gray-300">Navigate to Toolbox → {tool.title} from the main menu to start using this tool.</p>
                    </div>
                </div>
            );
        }
    }

    // AI Labs Content
    if (slug === 'ailab-overview') {
        return (
            <div className="prose prose-invert prose-lg max-w-none text-gray-300 leading-relaxed">
                <h1 className="text-3xl font-bold text-white mb-4">AI Labs Overview</h1>
                <p className="text-gray-300 mb-6">AI Labs is our experimental testing ground where you can test, benchmark, and optimize AI agents before deployment. Run experiments, analyze performance, and fine-tune agent behavior.</p>
                
                <h2 className="text-2xl font-bold text-white mt-8 mb-4">Available Experiments</h2>
                <ul className="list-disc pl-6 space-y-3 mb-6 text-gray-300">
                    <li><strong className="text-white">Emotional Intelligence Test</strong> - Test agent emotional response mapping and empathetic engagement</li>
                    <li><strong className="text-white">Memory Persistence</strong> - Verify long-term memory retention across sessions</li>
                    <li><strong className="text-white">Multi-Agent Swarm</strong> - Orchestrate multiple agents in coordinated patterns (Coming Soon)</li>
                    <li><strong className="text-white">Latency Optimization</strong> - Benchmark and optimize response times (Coming Soon)</li>
                    <li><strong className="text-white">Vector Search Tuning</strong> - Fine-tune semantic search accuracy (Coming Soon)</li>
                    <li><strong className="text-white">Stress Testing</strong> - Test agents under high load (Coming Soon)</li>
                </ul>

                <h2 className="text-2xl font-bold text-white mt-8 mb-4">Features</h2>
                <ul className="list-disc pl-6 space-y-2 mb-6 text-gray-300">
                    <li>Multi-model support (GPT-4, Claude, Gemini)</li>
                    <li>Real-time testing with live agents</li>
                    <li>Performance metrics and analytics</li>
                    <li>A/B testing capabilities</li>
                    <li>Export test results</li>
                    <li>Prompt template library</li>
                </ul>

                <div className="bg-purple-500/10 border border-purple-500/30 rounded-lg p-6 mt-6">
                    <h3 className="text-lg font-bold text-purple-400 mb-2">Getting Started</h3>
                    <p className="text-sm text-gray-300">Visit the AI Labs page to start running experiments and testing your AI agents.</p>
                </div>
            </div>
        );
    }

    // AI Labs individual experiment pages
    const ailabExperiments: Record<string, { title: string; description: string; complexity: string; features: string[]; usage: string }> = {
        'ailab-emotional': {
            title: 'Emotional Intelligence Test',
            description: 'Test and measure agent emotional response mapping, empathetic engagement, and sentiment analysis capabilities.',
            complexity: 'Beginner',
            features: [
                'Emotional response detection',
                'Empathy scoring',
                'Sentiment analysis',
                'Tone adaptation testing',
                'Context-aware emotional responses',
                'Multi-turn emotional tracking',
            ],
            usage: 'Run emotional intelligence tests by providing various emotional scenarios and measuring agent responses. The system evaluates empathy levels, emotional appropriateness, and contextual understanding.'
        },
        'ailab-memory': {
            title: 'Memory Persistence',
            description: 'Verify and test long-term memory retention across sessions, context windows, and agent restarts.',
            complexity: 'Intermediate',
            features: [
                'Cross-session memory retention',
                'Context window management',
                'Memory recall accuracy',
                'Long-term knowledge persistence',
                'Memory retrieval speed',
                'Forgetting curve analysis',
            ],
            usage: 'Test memory persistence by creating conversations with specific facts, ending sessions, and verifying recall in future sessions. Measure accuracy and retention over time.'
        },
        'ailab-swarm': {
            title: 'Multi-Agent Swarm',
            description: 'Orchestrate multiple agents in coordinated swarm patterns for complex task solving and collaborative intelligence.',
            complexity: 'Advanced',
            features: [
                'Multi-agent coordination',
                'Swarm intelligence algorithms',
                'Task distribution',
                'Collaborative problem-solving',
                'Agent-to-agent communication',
                'Emergent behavior analysis',
            ],
            usage: 'Deploy multiple agents to work together on complex tasks. Monitor coordination patterns, communication efficiency, and collaborative outcomes. (Coming Soon)'
        },
        'ailab-latency': {
            title: 'Latency Optimization',
            description: 'Benchmark and optimize response time across deployment tiers, network conditions, and model configurations.',
            complexity: 'Intermediate',
            features: [
                'Response time measurement',
                'P95/P99 latency tracking',
                'Network impact analysis',
                'Model performance comparison',
                'Caching effectiveness',
                'Optimization recommendations',
            ],
            usage: 'Run latency benchmarks under various conditions. Test different model configurations, caching strategies, and network scenarios to identify optimization opportunities. (Coming Soon)'
        },
        'ailab-vector': {
            title: 'Vector Search Tuning',
            description: 'Fine-tune semantic search and retrieval accuracy for RAG (Retrieval-Augmented Generation) systems.',
            complexity: 'Advanced',
            features: [
                'Embedding quality analysis',
                'Similarity threshold tuning',
                'Retrieval accuracy metrics',
                'Semantic search optimization',
                'Vector database performance',
                'RAG pipeline testing',
            ],
            usage: 'Test and optimize vector search parameters. Evaluate embedding models, adjust similarity thresholds, and measure retrieval accuracy for your specific use case. (Coming Soon)'
        },
        'ailab-stress': {
            title: 'Stress Testing',
            description: 'Stress test agents under high load, concurrent requests, and extreme conditions to ensure production readiness.',
            complexity: 'Advanced',
            features: [
                'Concurrent request handling',
                'Load testing scenarios',
                'Performance degradation analysis',
                'Error rate monitoring',
                'Resource utilization tracking',
                'Scalability assessment',
            ],
            usage: 'Simulate high-load scenarios with thousands of concurrent requests. Monitor agent performance, identify bottlenecks, and validate scalability for production deployment. (Coming Soon)'
        },
    };

    if (slug.startsWith('ailab-') && slug !== 'ailab-overview') {
        const experiment = ailabExperiments[slug];
        if (experiment) {
            return (
                <div className="prose prose-invert prose-lg max-w-none text-gray-300 leading-relaxed">
                    <h1 className="text-3xl font-bold text-white mb-4">{experiment.title}</h1>
                    <p className="text-gray-300 mb-6">{experiment.description}</p>
                    
                    <div className="bg-purple-500/10 border border-purple-500/30 rounded-lg p-4 mb-6">
                        <span className="text-sm font-semibold text-purple-400">Complexity Level: {experiment.complexity}</span>
                    </div>

                    <h2 className="text-2xl font-bold text-white mt-8 mb-4">Experiment Features</h2>
                    <ul className="list-disc pl-6 space-y-2 mb-6 text-gray-300">
                        {experiment.features.map((feature, idx) => (
                            <li key={idx}>{feature}</li>
                        ))}
                    </ul>

                    <h2 className="text-2xl font-bold text-white mt-8 mb-4">How to Run This Experiment</h2>
                    <p className="text-gray-300 mb-6">{experiment.usage}</p>

                    <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-lg p-6 mt-6">
                        <h3 className="text-lg font-bold text-cyan-400 mb-2">Access AI Labs</h3>
                        <p className="text-sm text-gray-300">Navigate to AI Labs from the main menu to run this experiment and analyze results.</p>
                    </div>
                </div>
            );
        }
    }

    // AI Studio Content
    if (slug === 'studio-getting-started') {
        return (
            <div className="prose prose-invert prose-lg max-w-none text-gray-300 leading-relaxed">
                <h1 className="text-3xl font-bold text-white mb-4">AI Studio - Getting Started</h1>
                <p className="text-gray-300 mb-6">AI Studio is a visual, no-code platform for building, customizing, and deploying AI agents. Design workflows, configure personalities, and create custom agents without writing code.</p>
                
                <h2 className="text-2xl font-bold text-white mt-8 mb-4">What You Can Build</h2>
                <ul className="list-disc pl-6 space-y-2 mb-6 text-gray-300">
                    <li>Custom AI Agents with unique personalities</li>
                    <li>Multi-step workflows and automations</li>
                    <li>Integration with external APIs and services</li>
                    <li>Conversational interfaces and chatbots</li>
                    <li>AI-powered business processes</li>
                </ul>

                <h2 className="text-2xl font-bold text-white mt-8 mb-4">Key Features</h2>
                <ul className="list-disc pl-6 space-y-2 mb-6 text-gray-300">
                    <li><strong className="text-white">Visual Agent Builder</strong> - Drag-and-drop interface for agent creation</li>
                    <li><strong className="text-white">Workflow Designer</strong> - Create complex multi-step workflows</li>
                    <li><strong className="text-white">Personality Configuration</strong> - Define agent personality and behavior</li>
                    <li><strong className="text-white">Testing Environment</strong> - Test agents before deployment</li>
                    <li><strong className="text-white">One-Click Deployment</strong> - Deploy to production instantly</li>
                    <li><strong className="text-white">Analytics Dashboard</strong> - Monitor agent performance</li>
                </ul>

                <h2 className="text-2xl font-bold text-white mt-8 mb-4">Getting Started Steps</h2>
                <ol className="list-decimal pl-6 space-y-2 mb-6 text-gray-300">
                    <li>Navigate to AI Studio from the main menu</li>
                    <li>Click "Create New Agent" to start building</li>
                    <li>Use the visual builder to configure your agent</li>
                    <li>Test your agent in the preview environment</li>
                    <li>Deploy to production when ready</li>
                </ol>

                <div className="bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border border-cyan-500/30 rounded-lg p-6 mt-6">
                    <h3 className="text-lg font-bold text-cyan-400 mb-2">Ready to Build?</h3>
                    <p className="text-sm text-gray-300">Access AI Studio from the main menu to start creating your custom AI agents.</p>
                </div>
            </div>
        );
    }

    // AI Studio other pages
    if (slug === 'studio-builder') {
        return (
            <div className="prose prose-invert prose-lg max-w-none text-gray-300 leading-relaxed">
                <h1 className="text-3xl font-bold text-white mb-4">Visual Agent Builder</h1>
                <p className="text-gray-300 mb-6">The Visual Agent Builder is a drag-and-drop interface that lets you create custom AI agents without writing code. Design agent personalities, configure capabilities, and set behavioral parameters visually.</p>
                
                <h2 className="text-2xl font-bold text-white mt-8 mb-4">Key Components</h2>
                <ul className="list-disc pl-6 space-y-3 mb-6 text-gray-300">
                    <li><strong className="text-white">Agent Canvas</strong> - Visual workspace for building agent structure</li>
                    <li><strong className="text-white">Personality Editor</strong> - Configure agent personality traits and tone</li>
                    <li><strong className="text-white">Capability Modules</strong> - Add tools, integrations, and skills</li>
                    <li><strong className="text-white">Response Templates</strong> - Pre-built response patterns and examples</li>
                    <li><strong className="text-white">Knowledge Base Integration</strong> - Connect to external data sources</li>
                    <li><strong className="text-white">Model Selection</strong> - Choose from GPT-4, Claude, Gemini, etc.</li>
                </ul>

                <h2 className="text-2xl font-bold text-white mt-8 mb-4">Building Your Agent</h2>
                <ol className="list-decimal pl-6 space-y-2 mb-6 text-gray-300">
                    <li>Start with a template or blank canvas</li>
                    <li>Define agent personality (friendly, professional, casual, etc.)</li>
                    <li>Add capabilities by dragging modules onto the canvas</li>
                    <li>Configure each capability with specific parameters</li>
                    <li>Set response templates and example interactions</li>
                    <li>Preview and test your agent in real-time</li>
                </ol>

                <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-6 mt-6">
                    <h3 className="text-lg font-bold text-blue-400 mb-2">Pro Tip</h3>
                    <p className="text-sm text-gray-300">Use the template library to start with pre-built agent configurations for common use cases like customer support, sales, or content creation.</p>
                </div>
            </div>
        );
    }

    if (slug === 'studio-workflow') {
        return (
            <div className="prose prose-invert prose-lg max-w-none text-gray-300 leading-relaxed">
                <h1 className="text-3xl font-bold text-white mb-4">Workflow Designer</h1>
                <p className="text-gray-300 mb-6">Create complex multi-step workflows that combine multiple agents, tools, and integrations. Design conditional logic, parallel processing, and automated decision trees.</p>
                
                <h2 className="text-2xl font-bold text-white mt-8 mb-4">Workflow Features</h2>
                <ul className="list-disc pl-6 space-y-3 mb-6 text-gray-300">
                    <li><strong className="text-white">Visual Flow Builder</strong> - Drag-and-drop workflow creation</li>
                    <li><strong className="text-white">Conditional Logic</strong> - If/then/else decision branches</li>
                    <li><strong className="text-white">Multi-Agent Orchestration</strong> - Coordinate multiple agents</li>
                    <li><strong className="text-white">API Integrations</strong> - Connect to external services</li>
                    <li><strong className="text-white">Data Transformation</strong> - Process and format data between steps</li>
                    <li><strong className="text-white">Error Handling</strong> - Define fallback and retry logic</li>
                    <li><strong className="text-white">Parallel Processing</strong> - Run multiple tasks simultaneously</li>
                </ul>

                <h2 className="text-2xl font-bold text-white mt-8 mb-4">Workflow Types</h2>
                <ul className="list-disc pl-6 space-y-2 mb-6 text-gray-300">
                    <li><strong className="text-white">Sequential</strong> - Steps execute one after another</li>
                    <li><strong className="text-white">Parallel</strong> - Multiple steps run simultaneously</li>
                    <li><strong className="text-white">Conditional</strong> - Branches based on conditions</li>
                    <li><strong className="text-white">Looping</strong> - Repeat steps until criteria met</li>
                    <li><strong className="text-white">Event-Driven</strong> - Triggered by external events</li>
                </ul>

                <div className="bg-purple-500/10 border border-purple-500/30 rounded-lg p-6 mt-6">
                    <h3 className="text-lg font-bold text-purple-400 mb-2">Use Cases</h3>
                    <p className="text-sm text-gray-300">Build workflows for automated customer onboarding, multi-stage support tickets, content approval processes, and complex business automations.</p>
                </div>
            </div>
        );
    }

    if (slug === 'studio-testing') {
        return (
            <div className="prose prose-invert prose-lg max-w-none text-gray-300 leading-relaxed">
                <h1 className="text-3xl font-bold text-white mb-4">Testing & Preview</h1>
                <p className="text-gray-300 mb-6">Test your agents thoroughly before deployment. Use the built-in testing environment to simulate conversations, validate workflows, and ensure quality.</p>
                
                <h2 className="text-2xl font-bold text-white mt-8 mb-4">Testing Tools</h2>
                <ul className="list-disc pl-6 space-y-3 mb-6 text-gray-300">
                    <li><strong className="text-white">Interactive Chat Preview</strong> - Test conversations in real-time</li>
                    <li><strong className="text-white">Scenario Testing</strong> - Run predefined test scenarios</li>
                    <li><strong className="text-white">A/B Testing</strong> - Compare different agent configurations</li>
                    <li><strong className="text-white">Performance Metrics</strong> - Monitor response time and accuracy</li>
                    <li><strong className="text-white">Debug Console</strong> - View detailed execution logs</li>
                    <li><strong className="text-white">User Simulation</strong> - Simulate different user types and behaviors</li>
                </ul>

                <h2 className="text-2xl font-bold text-white mt-8 mb-4">Testing Best Practices</h2>
                <ol className="list-decimal pl-6 space-y-2 mb-6 text-gray-300">
                    <li>Test all conversation flows and edge cases</li>
                    <li>Validate personality consistency across interactions</li>
                    <li>Check error handling and fallback responses</li>
                    <li>Verify integrations and API connections</li>
                    <li>Test performance under load</li>
                    <li>Get feedback from real users before production</li>
                </ol>

                <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-6 mt-6">
                    <h3 className="text-lg font-bold text-green-400 mb-2">Quality Assurance</h3>
                    <p className="text-sm text-gray-300">Use automated testing to ensure your agent maintains quality standards. Set up test suites that run automatically before each deployment.</p>
                </div>
            </div>
        );
    }

    if (slug === 'studio-deployment') {
        return (
            <div className="prose prose-invert prose-lg max-w-none text-gray-300 leading-relaxed">
                <h1 className="text-3xl font-bold text-white mb-4">Deployment</h1>
                <p className="text-gray-300 mb-6">Deploy your custom agents to production with one click. Choose deployment options, configure scaling, and monitor performance post-deployment.</p>
                
                <h2 className="text-2xl font-bold text-white mt-8 mb-4">Deployment Options</h2>
                <ul className="list-disc pl-6 space-y-3 mb-6 text-gray-300">
                    <li><strong className="text-white">Cloud Deployment</strong> - Deploy to our managed infrastructure</li>
                    <li><strong className="text-white">Dedicated Instance</strong> - Get your own dedicated server</li>
                    <li><strong className="text-white">On-Premise</strong> - Deploy to your own infrastructure</li>
                    <li><strong className="text-white">Hybrid</strong> - Combine cloud and on-premise deployments</li>
                    <li><strong className="text-white">Edge Deployment</strong> - Deploy closer to your users</li>
                </ul>

                <h2 className="text-2xl font-bold text-white mt-8 mb-4">Deployment Process</h2>
                <ol className="list-decimal pl-6 space-y-2 mb-6 text-gray-300">
                    <li>Complete all testing and validation</li>
                    <li>Choose deployment environment (staging/production)</li>
                    <li>Configure scaling and resource limits</li>
                    <li>Set up monitoring and alerting</li>
                    <li>Deploy with one-click deployment</li>
                    <li>Monitor initial performance and metrics</li>
                </ol>

                <h2 className="text-2xl font-bold text-white mt-8 mb-4">Post-Deployment</h2>
                <ul className="list-disc pl-6 space-y-2 mb-6 text-gray-300">
                    <li>Monitor real-time performance metrics</li>
                    <li>Track user interactions and feedback</li>
                    <li>Set up automated scaling rules</li>
                    <li>Configure backup and disaster recovery</li>
                    <li>Plan for updates and version management</li>
                </ul>

                <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-lg p-6 mt-6">
                    <h3 className="text-lg font-bold text-cyan-400 mb-2">Continuous Improvement</h3>
                    <p className="text-sm text-gray-300">Use analytics and user feedback to continuously improve your agent. Deploy updates seamlessly with zero downtime.</p>
                </div>
            </div>
        );
    }

    return (
        <div className="prose prose-invert prose-lg max-w-none text-gray-300 leading-relaxed">
            {contentMap[slug] || (
                <>
                    <h1 className="text-3xl font-bold text-white mb-4">Content Not Found</h1>
                    <p>This documentation page is under construction. Please check back later.</p>
                </>
            )}
        </div>
    )
}


const DocumentationPage: React.FC<DocumentationPageProps> = ({ onNavigate }) => {
    const [activeSlug, setActiveSlug] = useState('introduction');
    const contentRef = useRef<HTMLDivElement>(null);

    // Auto-scroll to content on mobile when selection changes
    useEffect(() => {
        // Only auto-scroll on mobile devices (screen width < 768px)
        if (window.innerWidth < 768 && contentRef.current) {
            // Small delay to ensure content is rendered before scrolling
            setTimeout(() => {
                contentRef.current?.scrollIntoView({ 
                    behavior: 'smooth', 
                    block: 'start' 
                });
            }, 100);
        }
    }, [activeSlug]);

    const handleNavClick = (slug: string) => {
        setActiveSlug(slug);
    };

  return (
    <div className="bg-black text-white min-h-screen">
        {/* Hero Section */}
        <section className="relative overflow-hidden border-b border-gray-800">
            <div className="absolute inset-0 bg-grid-gray-900 [mask-image:linear-gradient(to_bottom,white_30%,transparent)]"></div>
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-gradient-to-r from-purple-500/10 to-cyan-500/10 rounded-full blur-3xl"></div>
            
            <div className="container mx-auto px-6 py-12 md:py-16 text-center relative z-10">
                <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-gradient-to-br from-purple-500/20 to-cyan-500/20 mb-4">
                    <i className="fa-solid fa-book text-2xl text-purple-400"></i>
                </div>
                <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight mb-3 bg-clip-text text-transparent bg-gradient-to-r from-purple-400 via-cyan-400 to-blue-400">
                    Documentation
                </h1>
                <p className="text-base md:text-lg text-gray-400 max-w-2xl mx-auto">
                    Complete API reference, guides, and resources to build with IAMAI platform
                </p>
            </div>
        </section>

        <div className="container mx-auto md:h-screen">
            <div className="flex flex-col md:flex-row md:h-full">
                {/* Sidebar */}
                <aside className="w-full md:w-64 flex-shrink-0 border-b md:border-b-0 md:border-r border-gray-800 bg-gray-950 overflow-hidden flex flex-col">
                    {/* Header */}
                    <div className="p-4 md:p-6 border-b border-gray-800 flex-shrink-0">
                        <h2 className="text-lg font-bold text-white">Documentation</h2>
                    </div>
                    
                    {/* Scrollable Navigation */}
                    <nav className="flex-1 overflow-y-auto px-4 py-4 md:py-6 max-h-[50vh] md:max-h-none">
                        <div className="space-y-4 md:space-y-6">
                            {Object.entries(navItems).map(([category, items]) => (
                                <div key={category}>
                                    <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2 md:mb-3 px-2">{category}</h3>
                                    <ul className="space-y-1">
                                        {items.map(item => (
                                            <li key={item.slug}>
                                                <button
                                                    onClick={() => handleNavClick(item.slug)}
                                                    className={`w-full text-left px-3 py-2 text-sm rounded-md transition-colors ${
                                                        activeSlug === item.slug
                                                        ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50'
                                                        : 'text-gray-400 hover:bg-gray-800/50 hover:text-gray-300'
                                                    }`}
                                                >
                                                    {item.title}
                                                </button>
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                            ))}
                        </div>
                    </nav>
                </aside>
                
                {/* Main Content */}
                <main ref={contentRef} className="flex-1 overflow-hidden flex flex-col bg-black">
                    {/* Content Header */}
                    <div className="px-4 md:px-8 py-4 md:py-6 border-b border-gray-800 flex-shrink-0">
                        <h1 className="text-xl md:text-2xl font-bold text-white">API & SDK Documentation</h1>
                        <p className="text-gray-400 text-sm mt-1">Complete reference for building with IA M AI</p>
                    </div>
                    
                    {/* Scrollable Content Area */}
                    <div className="flex-1 overflow-y-auto px-4 md:px-8 py-4 md:py-6">
                        <article>
                           <DocumentationContent slug={activeSlug} />
                        </article>
                    </div>
                </main>
            </div>
        </div>
         <style>{`
            .prose-invert h1, .prose-invert h2, .prose-invert h3, .prose-invert strong { color: #fff; }
            .prose-invert p, .prose-invert li { color: #d1d5db; }
            .prose-invert a { color: #67e8f9; }
            .prose-invert a:hover { color: #22d3ee; }
            .prose-invert blockquote { border-left-color: #0891b2; color: #9ca3af; }
            .prose-invert code { color: #f3f4f6; background-color: rgba(255,255,255,0.1); padding: 0.2em 0.4em; border-radius: 6px; }
            
            /* Scrollbar styling */
            ::-webkit-scrollbar {
              width: 8px;
              height: 8px;
            }
            ::-webkit-scrollbar-track {
              background: transparent;
            }
            ::-webkit-scrollbar-thumb {
              background: rgba(139, 92, 246, 0.5);
              border-radius: 4px;
            }
            ::-webkit-scrollbar-thumb:hover {
              background: rgba(139, 92, 246, 0.7);
            }
       `}</style>
    </div>
  );
};

export default DocumentationPage;