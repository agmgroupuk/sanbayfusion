import React, { useState } from 'react';
import { Page } from '../../App';
import { ArrowLeft, Shield, Users, Lock, FileCheck, Globe, Trash2, BookOpen, AlertCircle, CheckCircle, X, ExternalLink, Scale, Mail, Phone, UserCheck, Database } from 'lucide-react';

interface GDPRPageProps {
  onNavigate: (page: Page) => void;
}

interface GDPRArticle {
  id: string;
  title: string;
  icon: React.ReactNode;
  excerpt: string;
  category: string;
  content: {
    introduction: string;
    sections: {
      heading: string;
      paragraphs: string[];
      list?: string[];
    }[];
    conclusion?: string;
  };
}

const GDPRPage: React.FC<GDPRPageProps> = ({ onNavigate }) => {
  const [selectedArticle, setSelectedArticle] = useState<GDPRArticle | null>(null);
  const [activeCategory, setActiveCategory] = useState<string>('all');

  const articles: GDPRArticle[] = [
    {
      id: 'introduction-gdpr',
      title: 'Introduction to GDPR Compliance',
      icon: <Shield className="w-6 h-6 text-cyan-400" />,
      excerpt: 'How IA M AI complies with the General Data Protection Regulation and protects EU users.',
      category: 'Overview',
      content: {
        introduction: 'The General Data Protection Regulation (GDPR) is a comprehensive data protection law that grants extensive rights to individuals in the European Union. IA M AI is fully committed to GDPR compliance and respects your data protection rights.',
        sections: [
          {
            heading: 'What is GDPR?',
            paragraphs: [
              'GDPR is a regulation in EU law on data protection and privacy for all individuals within the European Union and the European Economic Area. It addresses the transfer of personal data outside the EU and EEA areas.',
              'The regulation became enforceable on May 25, 2018. It aims to give individuals control over their personal data and to simplify the regulatory environment for international business by unifying data protection regulations within the EU.'
            ],
            list: [
              'Applies to all companies processing EU residents\' data',
              'Covers collection, storage, and use of personal information',
              'Grants extensive rights to data subjects (individuals)',
              'Requires explicit consent for data processing',
              'Mandates data breach notifications within 72 hours',
              'Imposes significant penalties for non-compliance (up to €20M or 4% of global revenue)'
            ]
          },
          {
            heading: 'Our GDPR Commitment',
            paragraphs: [
              'IA M AI takes GDPR compliance seriously. We have implemented comprehensive policies, procedures, and technical measures to ensure your personal data is processed lawfully, fairly, and transparently.',
              'We have appointed a Data Protection Officer (DPO) who oversees our compliance efforts and serves as your point of contact for privacy concerns.'
            ],
            list: [
              '✅ Data Protection Officer appointed and available',
              '✅ Privacy by Design principles embedded in all systems',
              '✅ Data Protection Impact Assessments (DPIAs) conducted',
              '✅ Clear legal basis for all data processing activities',
              '✅ EU-based data centers for EU user data',
              '✅ Standard Contractual Clauses for international transfers',
              '✅ Regular audits and compliance reviews',
              '✅ Staff training on GDPR and data protection'
            ]
          },
          {
            heading: 'Scope of Application',
            paragraphs: [
              'GDPR applies to IA M AI when we process personal data of individuals in the EU, regardless of where our company is located. This includes:'
            ],
            list: [
              'Offering goods or services to EU residents',
              'Monitoring the behavior of EU residents',
              'Processing personal data by a controller established in the EU',
              'Processing activities of an establishment in the EU'
            ]
          }
        ],
        conclusion: 'GDPR compliance is not just a legal obligation for us—it\'s a commitment to respecting your privacy and protecting your data. This section introduces our comprehensive GDPR policies.'
      }
    },
    {
      id: 'legal-basis',
      title: 'Legal Basis for Data Processing',
      icon: <FileCheck className="w-6 h-6 text-cyan-400" />,
      excerpt: 'The lawful grounds under which we process your personal data under GDPR.',
      category: 'Legal Compliance',
      content: {
        introduction: 'Under GDPR, we must have a valid legal basis to process your personal data. We rely on several lawful grounds depending on the nature of the processing activity.',
        sections: [
          {
            heading: 'Consent',
            paragraphs: [
              'When you voluntarily agree to specific processing activities, we rely on your consent as the legal basis. Consent must be freely given, specific, informed, and unambiguous.',
              'You have the right to withdraw consent at any time, and it must be as easy to withdraw as it was to give.'
            ],
            list: [
              '📧 Email marketing and newsletters (opt-in required)',
              '🍪 Non-essential cookies and tracking technologies',
              '🤖 AI conversation memory and personalization',
              '📊 Sharing data with third-party partners (beyond service provision)',
              '🎯 Behavioral advertising and profiling',
              '✉️ You can withdraw consent anytime in privacy settings'
            ]
          },
          {
            heading: 'Contractual Necessity',
            paragraphs: [
              'Processing is necessary to perform our contract with you (Terms of Service) or to take steps at your request before entering into a contract.'
            ],
            list: [
              'Creating and managing your account',
              'Providing AI agent services you request',
              'Processing subscription payments',
              'Delivering customer support',
              'Providing platform features and functionality',
              'Fulfilling our obligations under our Terms of Service'
            ]
          },
          {
            heading: 'Legal Obligation',
            paragraphs: [
              'We process data when necessary to comply with legal obligations under EU or member state law.'
            ],
            list: [
              'Tax and accounting records (7 years retention)',
              'Responding to lawful court orders and subpoenas',
              'Compliance with anti-money laundering regulations',
              'Record-keeping required by financial regulators',
              'Data breach notifications to authorities',
              'Responding to regulatory inquiries'
            ]
          },
          {
            heading: 'Legitimate Interests',
            paragraphs: [
              'Processing is necessary for our legitimate interests or those of a third party, except where such interests are overridden by your rights and freedoms.',
              'We conduct Legitimate Interest Assessments (LIAs) to ensure our interests do not override your rights.'
            ],
            list: [
              'Fraud prevention and platform security',
              'Network and information security',
              'Internal administration and business operations',
              'Improving and optimizing our services',
              'Direct marketing to existing customers (with opt-out)',
              'Analytics and understanding usage patterns',
              'Defending legal claims and pursuing legal rights'
            ]
          },
          {
            heading: 'Vital Interests',
            paragraphs: [
              'In rare circumstances, we may process data to protect someone\'s life or physical safety.'
            ],
            list: [
              'Emergency situations threatening life or health',
              'Preventing serious harm to you or others',
              'Medical emergencies requiring immediate action'
            ]
          }
        ],
        conclusion: 'Every processing activity we conduct has a clear legal basis under GDPR. We document these legal bases and make them available upon request.'
      }
    },
    {
      id: 'data-subjects-rights',
      title: 'Your Data Subject Rights',
      icon: <UserCheck className="w-6 h-6 text-cyan-400" />,
      excerpt: 'Comprehensive overview of your rights under GDPR and how to exercise them.',
      category: 'Your Rights',
      content: {
        introduction: 'GDPR grants you extensive rights over your personal data. IA M AI is committed to facilitating the exercise of these rights. This article explains each right and how to use it.',
        sections: [
          {
            heading: 'Right to Access (Article 15)',
            paragraphs: [
              'You have the right to obtain confirmation of whether we are processing your personal data and, if so, to access that data along with specific information about the processing.'
            ],
            list: [
              '📄 Request a copy of all personal data we hold about you',
              '📊 Receive information about processing purposes and legal bases',
              '🏢 Learn which recipients or categories have received your data',
              '⏰ Know the retention period or criteria for determining it',
              '🔄 Understand your rights to rectification, erasure, restriction, and objection',
              '⚖️ Learn about your right to lodge a complaint with a supervisory authority',
              '🌐 Receive information about data sources if not collected directly',
              '✅ First copy provided free; additional copies may incur reasonable fees'
            ]
          },
          {
            heading: 'Right to Rectification (Article 16)',
            paragraphs: [
              'You have the right to correct inaccurate personal data and to have incomplete data completed.'
            ],
            list: [
              'Update incorrect account information',
              'Correct typos in your name, email, or profile',
              'Add missing information to make your data complete',
              'We will correct data without undue delay (typically within 30 days)',
              'We will notify third parties of corrections where feasible',
              'Access your account settings to make corrections yourself'
            ]
          },
          {
            heading: 'Right to Erasure / "Right to Be Forgotten" (Article 17)',
            paragraphs: [
              'You have the right to have your personal data erased under certain conditions. This is not an absolute right and exceptions apply.'
            ],
            list: [
              '✅ When: Data no longer necessary for original purpose',
              '✅ When: You withdraw consent and no other legal basis exists',
              '✅ When: You object and no overriding legitimate grounds exist',
              '✅ When: Data was unlawfully processed',
              '✅ When: Erasure required to comply with legal obligation',
              '❌ Exception: Legal obligation to retain (tax records, dispute resolution)',
              '❌ Exception: Establishment, exercise, or defense of legal claims',
              '❌ Exception: Public interest or scientific/historical research purposes',
              '📧 Request deletion via privacy settings or privacy@iamai.global'
            ]
          },
          {
            heading: 'Right to Restriction of Processing (Article 18)',
            paragraphs: [
              'You have the right to restrict processing of your data in certain situations. Restricted data can only be stored, not actively processed.'
            ],
            list: [
              'When you contest the accuracy of data (during verification)',
              'When processing is unlawful but you prefer restriction over erasure',
              'When we no longer need data but you need it for legal claims',
              'When you object to processing (pending verification of legitimate grounds)',
              'Restricted data marked and only processed with consent or for legal claims',
              'We will inform you before lifting restriction'
            ]
          },
          {
            heading: 'Right to Data Portability (Article 20)',
            paragraphs: [
              'You have the right to receive your personal data in a structured, commonly used, machine-readable format and to transmit it to another controller.'
            ],
            list: [
              '📥 Export your data in JSON or CSV format',
              '📤 Directly transfer data to another service (where technically feasible)',
              '✅ Applies when processing is based on consent or contract',
              '✅ Applies only to data you provided to us',
              '⚙️ Only covers automated processing (not manual records)',
              '🔄 Does not include derived or inferred data',
              '📧 Request via privacy@iamai.global or download in account settings'
            ]
          },
          {
            heading: 'Right to Object (Article 21)',
            paragraphs: [
              'You have the right to object to processing of your personal data in certain circumstances, particularly for direct marketing and legitimate interest processing.'
            ],
            list: [
              '🚫 Absolute right to object to direct marketing (immediate cessation)',
              '⚖️ Right to object to legitimate interest processing (we must demonstrate compelling grounds)',
              '📊 Right to object to profiling for direct marketing',
              '🔬 Right to object to processing for scientific/historical research (unless public interest)',
              'Object via unsubscribe links, privacy settings, or privacy@iamai.global'
            ]
          },
          {
            heading: 'Rights Related to Automated Decision-Making (Article 22)',
            paragraphs: [
              'You have the right not to be subject to decisions based solely on automated processing, including profiling, which produce legal effects or similarly significantly affect you.'
            ],
            list: [
              'Right to human intervention in automated decisions',
              'Right to express your point of view',
              'Right to contest automated decisions',
              'We do not make significant automated decisions without human review',
              'AI agent responses are assistive, not decision-making',
              'You retain control over how you use AI-generated content'
            ]
          },
          {
            heading: 'How to Exercise Your Rights',
            paragraphs: [
              'Exercising your GDPR rights is straightforward. We provide multiple channels and will respond within one month (extendable by two months for complex requests).'
            ],
            list: [
              '📧 Email: privacy@iamai.global (primary method)',
              '⚙️ Account Settings: Privacy controls and data export',
              '📱 In-app: Privacy settings in user menu',
              '✉️ Mail: IA M AI Data Protection Officer, [Address]',
              '🆔 We may request identification to verify your identity',
              '⏱️ Response time: 1 month (up to 3 months for complex requests)',
              '💰 Free of charge (except excessive/repetitive requests)',
              '📋 We will provide information on action taken'
            ]
          }
        ],
        conclusion: 'Your data subject rights are fundamental to GDPR. We are committed to honoring these rights and making it easy for you to exercise them. Contact us anytime with questions or requests.'
      }
    },
    {
      id: 'data-collection-gdpr',
      title: 'Data Collection & Categories',
      icon: <Database className="w-6 h-6 text-cyan-400" />,
      excerpt: 'Detailed breakdown of personal data we collect and the categories of data subjects.',
      category: 'Data Processing',
      content: {
        introduction: 'GDPR requires transparency about what personal data we collect, from whom, and how. This article provides comprehensive details about our data collection practices.',
        sections: [
          {
            heading: 'Categories of Personal Data',
            paragraphs: [
              'We collect various types of personal data depending on how you interact with our platform. All collection is done transparently with appropriate legal basis.'
            ],
            list: [
              '🪪 Identity Data: Name, username, display name, date of birth',
              '📧 Contact Data: Email address, phone number, mailing address',
              '💳 Financial Data: Payment card details (tokenized), billing address, transaction history',
              '📱 Technical Data: IP address, browser type, device ID, operating system',
              '📊 Usage Data: Platform interactions, features used, AI agent conversations',
              '🎯 Profile Data: Preferences, feedback, survey responses, interests',
              '🗨️ Communication Data: Messages to support, feedback, inquiries',
              '📍 Location Data: Country, region, city (derived from IP address)',
              '🍪 Tracking Data: Cookies, pixels, analytics identifiers'
            ]
          },
          {
            heading: 'Categories of Data Subjects',
            paragraphs: [
              'We process personal data of various categories of individuals who interact with our services:'
            ],
            list: [
              '👤 Website Visitors: Anyone browsing our public website',
              '🔐 Registered Users: Individuals with accounts on our platform',
              '💎 Subscribers: Users with paid subscriptions to premium services',
              '📧 Newsletter Recipients: Individuals who opted into email communications',
              '💬 Customer Support Contacts: Anyone who reaches out for assistance',
              '🤝 Business Contacts: Partners, vendors, and professional contacts',
              '🧪 Research Participants: Users who opt into research studies',
              '📊 Job Applicants: Candidates who apply for positions (separate policy)'
            ]
          },
          {
            heading: 'Sources of Personal Data',
            paragraphs: [
              'We collect personal data from various sources, always with appropriate transparency and legal basis:'
            ],
            list: [
              'Directly from you: Account registration, profile updates, communications',
              'Automatically: Usage data, technical data, cookies when you use our platform',
              'Third-party integrations: Social media login, payment processors',
              'Public sources: Publicly available information (when legally permitted)',
              'Business partners: Referral partners, affiliate networks (with consent)',
              'Analytics providers: Aggregated insights from analytics services'
            ]
          },
          {
            heading: 'Special Categories of Data',
            paragraphs: [
              'GDPR provides extra protection for "special categories" of sensitive personal data. We generally do not collect special category data, but if we do, we obtain explicit consent.'
            ],
            list: [
              '🚫 We do not intentionally collect special category data',
              '⚠️ Special categories include: racial/ethnic origin, political opinions, religious beliefs, trade union membership, genetic data, biometric data, health data, sex life/orientation',
              '🤖 AI conversations may inadvertently include sensitive data you provide',
              '✅ Do not share sensitive personal information with AI agents',
              '🗑️ You can delete conversations containing sensitive data anytime',
              '📧 Contact us to remove sensitive data: privacy@iamai.global'
            ]
          }
        ],
        conclusion: 'We are transparent about what data we collect and why. If you have questions about data collection, please contact our Data Protection Officer.'
      }
    },
    {
      id: 'data-security',
      title: 'Data Security & Protection Measures',
      icon: <Lock className="w-6 h-6 text-cyan-400" />,
      excerpt: 'Technical and organizational measures we implement to protect your data.',
      category: 'Security',
      content: {
        introduction: 'GDPR requires us to implement appropriate technical and organizational measures to ensure data security. We take security seriously and employ industry-leading practices.',
        sections: [
          {
            heading: 'Technical Security Measures',
            paragraphs: [
              'We employ state-of-the-art technical safeguards to protect your personal data from unauthorized access, alteration, disclosure, or destruction.'
            ],
            list: [
              '🔒 Encryption in Transit: TLS 1.3 for all data transmission',
              '🗝️ Encryption at Rest: AES-256 encryption for stored data',
              '🛡️ Firewall Protection: Multi-layer firewall architecture',
              '🔐 Access Controls: Role-based access control (RBAC) and least privilege',
              '🔑 Multi-Factor Authentication: MFA required for admin access',
              '🧪 Vulnerability Scanning: Automated scanning and penetration testing',
              '📡 DDoS Protection: Cloudflare enterprise protection',
              '🔍 Security Monitoring: 24/7 intrusion detection and prevention',
              '🔄 Secure Backups: Encrypted, geographically distributed backups',
              '🗑️ Secure Deletion: Cryptographic erasure for data deletion'
            ]
          },
          {
            heading: 'Organizational Security Measures',
            paragraphs: [
              'Beyond technology, we implement organizational policies and procedures to maintain data security culture across our company.'
            ],
            list: [
              '📚 Staff Training: Mandatory security and privacy training for all employees',
              '📜 Confidentiality Agreements: All staff sign NDAs and data protection agreements',
              '🎯 Need-to-Know Access: Access granted only when necessary for job functions',
              '👁️ Access Logs: All data access logged and audited regularly',
              '📋 Incident Response Plan: Documented procedures for security incidents',
              '🔍 Regular Audits: Internal and third-party security audits',
              '✅ Vendor Management: Due diligence and audits of third-party processors',
              '📊 Data Protection Officer: Dedicated DPO overseeing compliance',
              '🏢 Secure Facilities: Physical security controls at data centers',
              '🗂️ Document Management: Secure storage and retention policies'
            ]
          },
          {
            heading: 'Data Breach Response',
            paragraphs: [
              'Despite our best efforts, no system is 100% secure. We have comprehensive procedures to respond to data breaches in accordance with GDPR Article 33 and 34.'
            ],
            list: [
              '⏱️ Detection: Continuous monitoring for anomalies and breaches',
              '🚨 Notification to Authority: Within 72 hours to supervisory authority',
              '📧 User Notification: Without undue delay when high risk to your rights',
              '📋 Documentation: Detailed records of all breaches and responses',
              '🔍 Investigation: Thorough analysis of root cause and impact',
              '🛠️ Remediation: Immediate steps to contain and resolve breach',
              '🔄 Prevention: Implementing measures to prevent recurrence',
              '📊 Reporting: Transparent communication about breach details',
              '💰 We maintain cyber insurance coverage'
            ]
          },
          {
            heading: 'Privacy by Design & Default',
            paragraphs: [
              'We implement Privacy by Design principles, ensuring data protection is built into all systems and processes from the start.'
            ],
            list: [
              'Minimal data collection (only what\'s necessary)',
              'Default privacy-friendly settings',
              'Data protection impact assessments (DPIAs) for high-risk processing',
              'Privacy considerations in all product development',
              'Regular review and updating of privacy measures',
              'User-friendly privacy controls and transparency'
            ]
          }
        ],
        conclusion: 'Your data security is our priority. We invest significantly in both technical and organizational measures to protect your personal information in compliance with GDPR.'
      }
    },
    {
      id: 'international-transfers',
      title: 'International Data Transfers',
      icon: <Globe className="w-6 h-6 text-cyan-400" />,
      excerpt: 'How we handle transfers of personal data outside the European Economic Area.',
      category: 'Data Processing',
      content: {
        introduction: 'GDPR restricts transfers of personal data outside the European Economic Area (EEA) unless appropriate safeguards are in place. This article explains how we ensure compliance with these requirements.',
        sections: [
          {
            heading: 'Where Your Data Is Stored',
            paragraphs: [
              'We primarily store EU users\' data within the European Economic Area. However, some services may involve data processing in other jurisdictions.'
            ],
            list: [
              '🇪🇺 Primary Storage: EU-based AWS data centers (Frankfurt, Ireland)',
              '🌍 Backup Locations: Additional EU regions for redundancy',
              '🇺🇸 Some Third-Party Services: May process data in the United States',
              '🏢 Service Providers: Carefully vetted partners with adequate safeguards',
              '📋 Inventory: We maintain a record of all data processing locations'
            ]
          },
          {
            heading: 'Legal Mechanisms for Data Transfers',
            paragraphs: [
              'When we transfer personal data outside the EEA, we ensure appropriate safeguards are in place as required by GDPR Chapter V.'
            ],
            list: [
              '📜 Standard Contractual Clauses (SCCs): EU-approved model contracts',
              '✅ Adequacy Decisions: Transfers to countries deemed adequate by EU Commission',
              '🏢 Binding Corporate Rules (BCRs): For intra-group transfers',
              '🛡️ Supplementary Measures: Additional safeguards beyond SCCs',
              '🔍 Transfer Impact Assessments: Evaluating laws in destination country',
              '🚫 No transfers without appropriate safeguards'
            ]
          },
          {
            heading: 'Transfers to the United States',
            paragraphs: [
              'Following the invalidation of Privacy Shield and subsequent legal developments, transfers to the U.S. require careful consideration.'
            ],
            list: [
              'We use Standard Contractual Clauses for U.S. transfers',
              'We implement supplementary technical measures (encryption, pseudonymization)',
              'We conduct transfer impact assessments for U.S. service providers',
              'We limit U.S. transfers to essential services only',
              'We contractually bind U.S. processors to GDPR standards',
              'We monitor legal developments (EU-U.S. Data Privacy Framework)',
              'We will update practices based on CJEU guidance'
            ]
          },
          {
            heading: 'Third-Party Processors & Transfers',
            paragraphs: [
              'Some of our service providers may process your data outside the EEA. We ensure all such processors provide adequate protection.'
            ],
            list: [
              '☁️ AWS (Infrastructure): EU and U.S. regions with SCCs',
              '🤖 AI Providers (Mistral, OpenAI, Google): See their specific policies',
              '💳 Stripe (Payments): SCCs and EU-U.S. DPF certified',
              '📧 Email Services: EU-based or with SCCs',
              '📊 Analytics: EU data processing where possible',
              '✅ All processors bound by contracts with GDPR requirements'
            ]
          },
          {
            heading: 'Your Control Over Transfers',
            paragraphs: [
              'You have rights related to international data transfers:'
            ],
            list: [
              '📋 Request information about transfer safeguards',
              '📄 Receive copies of SCCs upon request',
              '🚫 Object to transfers in certain circumstances',
              '⚖️ Lodge complaints with supervisory authority',
              '📧 Contact us: privacy@iamai.global for transfer inquiries'
            ]
          }
        ],
        conclusion: 'International data transfers are carefully managed with appropriate safeguards. We prioritize keeping EU data within the EEA and only transfer data outside when necessary and with protection.'
      }
    },
    {
      id: 'data-retention',
      title: 'Data Retention & Deletion',
      icon: <Trash2 className="w-6 h-6 text-cyan-400" />,
      excerpt: 'How long we keep your data and our deletion practices under GDPR.',
      category: 'Data Management',
      content: {
        introduction: 'GDPR requires that we only retain personal data for as long as necessary for the purposes for which it was collected. We have implemented clear retention periods and deletion procedures.',
        sections: [
          {
            heading: 'Retention Principles',
            paragraphs: [
              'Our data retention practices are guided by GDPR principles and business necessity:'
            ],
            list: [
              'Data minimization: We only retain what\'s necessary',
              'Storage limitation: Data deleted when no longer needed',
              'Purpose limitation: Data not kept longer than required for original purpose',
              'Regular reviews: Periodic audits to identify data for deletion',
              'Documented policies: Clear retention schedules for all data types'
            ]
          },
          {
            heading: 'Retention Periods by Data Type',
            paragraphs: [
              'Different types of data have different retention requirements based on legal obligations and business needs:'
            ],
            list: [
              '👤 Account Data: Duration of account + 30 days after closure',
              '💬 AI Conversations: 30 days (configurable in settings) or until deleted by user',
              '💳 Payment Records: 7 years (legal requirement for accounting)',
              '📧 Marketing Communications: Until consent withdrawn + 30 days',
              '🍪 Cookie Data: See Cookie Policy (typically 13 months max)',
              '📊 Analytics Data: 26 months (anonymized after 14 months)',
              '🎫 Support Tickets: 3 years after resolution',
              '⚖️ Legal Claims: Duration of limitation period + 1 year',
              '🔒 Security Logs: 12 months',
              '📝 Backup Data: 90 days (then permanently deleted)'
            ]
          },
          {
            heading: 'Automated Deletion',
            paragraphs: [
              'We implement automated systems to ensure timely deletion of data when retention periods expire:'
            ],
            list: [
              '🤖 Automated deletion scripts run daily',
              '🗑️ Data marked for deletion is securely erased',
              '🔍 Deletion logs maintained for audit purposes',
              '☁️ Backups purged after 90 days',
              '📧 Notification before deletion (when feasible)',
              '🛡️ Secure deletion methods (cryptographic erasure)'
            ]
          },
          {
            heading: 'Exceptions to Deletion',
            paragraphs: [
              'In certain circumstances, we may retain data longer than standard periods:'
            ],
            list: [
              '⚖️ Legal claims: Until claim resolved and limitation period expired',
              '🏛️ Legal obligations: Tax records, regulatory requirements (7 years)',
              '📋 Compliance investigations: Until investigation and appeals concluded',
              '🛡️ Fraud prevention: Flagged accounts may be retained longer',
              '📊 Anonymized data: Aggregated, non-personal data retained indefinitely',
              '🔐 Technical requirements: Data needed for system integrity'
            ]
          },
          {
            heading: 'Your Deletion Rights',
            paragraphs: [
              'You can request deletion of your data at any time, subject to limited exceptions:'
            ],
            list: [
              '🗑️ Delete Account: Account settings → Delete Account',
              '💬 Delete Conversations: Individual deletion in AI agent interface',
              '🗂️ Delete Specific Data: Request via privacy@iamai.global',
              '⏱️ Deletion processed within 30 days',
              '📧 Confirmation email sent when completed',
              '⚠️ Some data may be retained for legal compliance',
              '🔄 Right to erasure detailed in Data Subject Rights section'
            ]
          }
        ],
        conclusion: 'We take data retention seriously and only keep data as long as necessary. When retention periods expire or you request deletion, we ensure secure and complete erasure.'
      }
    },
    {
      id: 'dpo-contact',
      title: 'Data Protection Officer & Contact',
      icon: <Mail className="w-6 h-6 text-cyan-400" />,
      excerpt: 'How to contact our Data Protection Officer and exercise your GDPR rights.',
      category: 'Contact & Support',
      content: {
        introduction: 'GDPR requires companies processing large volumes of personal data to appoint a Data Protection Officer (DPO). Our DPO is your primary contact for all privacy and data protection matters.',
        sections: [
          {
            heading: 'Our Data Protection Officer',
            paragraphs: [
              'We have appointed a qualified and independent Data Protection Officer who oversees our GDPR compliance program and serves as your point of contact for privacy inquiries, concerns, and requests.'
            ],
            list: [
              '📧 Email: dpo@iamai.global (monitored daily)',
              '✉️ Mail: Data Protection Officer, IA M AI, [Company Address]',
              '📞 Phone: [DPO Phone Number] (business hours)',
              '🌐 Online Form: https://iamai.global/gdpr-contact',
              '⏱️ Response Time: Within 48 hours for urgent matters, 5 business days for standard inquiries',
              '🔒 Secure Channel: PGP encryption available upon request for sensitive communications'
            ]
          },
          {
            heading: 'When to Contact the DPO',
            paragraphs: [
              'You should contact our Data Protection Officer for any GDPR-related matters, including:'
            ],
            list: [
              '🙋 Exercising any of your data subject rights (access, rectification, erasure, etc.)',
              '❓ Questions about how we process your personal data',
              '⚠️ Privacy concerns or complaints about our practices',
              '🚨 Reporting a suspected data breach or security issue',
              '🤝 Inquiring about third-party data sharing',
              '📋 Requesting information about international data transfers',
              '📜 Obtaining copies of Standard Contractual Clauses or other safeguards',
              '🔍 Seeking clarification on this GDPR policy',
              '✅ Withdrawing consent for specific processing activities'
            ]
          },
          {
            heading: 'What to Include in Your Request',
            paragraphs: [
              'To help us respond efficiently and verify your identity, please include:'
            ],
            list: [
              'Your full name and email address associated with your account',
              'Clear description of your request or concern',
              'Specific data or processing activity you\'re inquiring about',
              'Any relevant dates, transaction IDs, or reference numbers',
              'Proof of identity (we may request additional verification)',
              'Preferred method of response (email, mail, etc.)'
            ]
          },
          {
            heading: 'Our Response Process',
            paragraphs: [
              'When you contact our DPO, here\'s what happens:'
            ],
            list: [
              '📨 Acknowledgment: We confirm receipt within 48 hours',
              '🆔 Verification: We may request identity verification for security',
              '🔍 Investigation: We thoroughly review your request',
              '📄 Response: Full response within 1 month (extendable to 3 months for complex requests)',
              '📧 Follow-up: We provide updates if additional time is needed',
              '💰 No Charge: Requests are free unless excessive or repetitive',
              '⚖️ Appeal: You may escalate to a supervisory authority if dissatisfied'
            ]
          },
          {
            heading: 'Alternative Contacts',
            paragraphs: [
              'For specific types of inquiries, you may also contact:'
            ],
            list: [
              '🔒 Security Issues: security@iamai.global',
              '🛟 Customer Support: support@iamai.global',
              '⚖️ Legal Department: legal@iamai.global',
              '📧 General Inquiries: contact@iamai.global'
            ]
          }
        ],
        conclusion: 'Our Data Protection Officer is here to help you with any privacy or GDPR-related matters. Don\'t hesitate to reach out—we\'re committed to respecting your rights and addressing your concerns.'
      }
    },
    {
      id: 'supervisory-authority',
      title: 'Supervisory Authority & Complaints',
      icon: <Scale className="w-6 h-6 text-cyan-400" />,
      excerpt: 'Your right to lodge a complaint with a data protection supervisory authority.',
      category: 'Your Rights',
      content: {
        introduction: 'Under GDPR Article 77, you have the right to lodge a complaint with a supervisory authority if you believe we have violated your data protection rights. We encourage you to contact us first, but this right is always available to you.',
        sections: [
          {
            heading: 'Your Right to Complain',
            paragraphs: [
              'You have the unconditional right to lodge a complaint with a data protection supervisory authority, particularly in the EU member state of your habitual residence, place of work, or place of the alleged infringement.',
              'This right exists independently of any other administrative or judicial remedy. You can file a complaint at any time without first attempting to resolve the issue with us (though we hope you\'ll give us a chance to address your concerns).'
            ]
          },
          {
            heading: 'When to File a Complaint',
            paragraphs: [
              'You may consider filing a complaint if:'
            ],
            list: [
              'You believe we have violated your GDPR rights',
              'You are dissatisfied with our response to your data subject request',
              'We have not responded to your inquiry within legal timeframes',
              'You suspect a data breach affecting your personal data',
              'You object to our data processing practices',
              'You believe we lack a valid legal basis for processing',
              'You have concerns about international data transfers',
              'You believe your data is being processed unlawfully'
            ]
          },
          {
            heading: 'Lead Supervisory Authority',
            paragraphs: [
              'Our lead supervisory authority (main establishment in the EU) is:'
            ],
            list: [
              '🏢 [Your Lead Supervisory Authority Name]',
              '📍 Address: [Authority Address]',
              '📧 Email: [Authority Email]',
              '📞 Phone: [Authority Phone]',
              '🌐 Website: [Authority Website]',
              '📋 Online Complaint Form: [Link to complaint form]'
            ]
          },
          {
            heading: 'Other Relevant Supervisory Authorities',
            paragraphs: [
              'You may also contact the supervisory authority in your country. Key EU supervisory authorities include:'
            ],
            list: [
              '🇮🇪 Ireland: Data Protection Commission (DPC) - www.dataprotection.ie',
              '🇩🇪 Germany: BfDI (Federal) + Länder authorities - www.bfdi.bund.de',
              '🇫🇷 France: CNIL - www.cnil.fr',
              '🇳🇱 Netherlands: Autoriteit Persoonsgegevens - www.autoriteitpersoonsgegevens.nl',
              '🇪🇸 Spain: AEPD - www.aepd.es',
              '🇮🇹 Italy: Garante - www.garanteprivacy.it',
              '🇵🇱 Poland: UODO - www.uodo.gov.pl',
              '🇧🇪 Belgium: APD/GBA - www.apd-gba.be',
              '🇸🇪 Sweden: IMY - www.imy.se',
              '🇦🇹 Austria: DSB - www.dsb.gv.at'
            ]
          },
          {
            heading: 'What to Include in a Complaint',
            paragraphs: [
              'When filing a complaint with a supervisory authority, provide:'
            ],
            list: [
              'Your contact information and details',
              'Description of the alleged GDPR violation',
              'Details of the data controller (IA M AI)',
              'Evidence supporting your complaint',
              'Description of any prior attempts to resolve with us',
              'Specific GDPR articles you believe were violated',
              'Any correspondence with us regarding the issue',
              'Details of harm or potential harm caused'
            ]
          },
          {
            heading: 'Complaint Process',
            paragraphs: [
              'After you file a complaint, the supervisory authority will:'
            ],
            list: [
              '📨 Acknowledge receipt of your complaint',
              '🔍 Assess whether the complaint falls within their competence',
              '📋 May request additional information from you',
              '🏢 Notify us of the complaint and request our response',
              '⚖️ Investigate the matter',
              '📄 Issue a decision or take enforcement action if warranted',
              '📧 Inform you of the outcome',
              '⏱️ Process may take several months depending on complexity'
            ]
          },
          {
            heading: 'Judicial Remedies',
            paragraphs: [
              'In addition to lodging a complaint with a supervisory authority, you also have the right to:'
            ],
            list: [
              '⚖️ Seek judicial remedy against a supervisory authority decision (Article 78)',
              '🏛️ Bring legal proceedings directly against us in court (Article 79)',
              '💰 Seek compensation for material or non-material damage (Article 82)',
              '⚖️ Choose jurisdiction: Your residence, our establishment, or place of infringement'
            ]
          }
        ],
        conclusion: 'We respect your right to lodge a complaint with a supervisory authority and will cooperate fully with any investigations. We prefer to resolve issues directly with you, but this right is always available.'
      }
    }
  ];

  const categories = ['all', 'Overview', 'Legal Compliance', 'Your Rights', 'Data Processing', 'Security', 'Data Management', 'Contact & Support'];

  const filteredArticles = activeCategory === 'all' 
    ? articles 
    : articles.filter(article => article.category === activeCategory);

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <header className="border-b border-gray-800 bg-[#0a0a0a] sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <button
              onClick={() => onNavigate('home')}
              className="flex items-center gap-2 text-cyan-400 hover:text-cyan-300 transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
              <span className="text-sm">Back to Home</span>
            </button>
            <h1 className="text-2xl md:text-3xl font-bold text-white">
              GDPR Compliance
            </h1>
            <div className="w-20"></div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-12">
        <div className="max-w-7xl mx-auto">
          {/* Introduction */}
          <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-8 mb-8">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-3 bg-cyan-900/50 border border-cyan-500/30 rounded-xl">
                <Shield className="w-8 h-8 text-cyan-400" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-white">GDPR Compliance Policy</h2>
                <p className="text-gray-500">Last updated: November 2025</p>
              </div>
            </div>
            <p className="text-gray-400 leading-relaxed mb-4">
              The <span className="text-cyan-400 font-semibold">General Data Protection Regulation (GDPR)</span> is comprehensive EU legislation protecting the privacy and personal data of EU residents. 
              IA M AI is fully committed to GDPR compliance and respecting your data protection rights.
            </p>
            <p className="text-gray-500 text-sm">
              This policy explains how we comply with GDPR, your rights as a data subject, and how to exercise those rights.
            </p>
          </div>

          {/* Category Filters */}
          <div className="mb-8">
            <h3 className="text-lg font-semibold mb-4 text-white">Browse by Category</h3>
            <div className="flex flex-wrap gap-2">
              {categories.map((category) => (
                <button
                  key={category}
                  onClick={() => setActiveCategory(category)}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                    activeCategory === category
                      ? 'bg-cyan-500 text-black shadow-lg'
                      : 'bg-gray-900/50 text-gray-400 hover:bg-gray-800 border border-gray-800 hover:text-cyan-400'
                  }`}
                >
                  {category === 'all' ? '📋 All Articles' : category}
                </button>
              ))}
            </div>
          </div>

          {/* Article Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            {filteredArticles.map((article) => (
              <div
                key={article.id}
                className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6 hover:border-cyan-500/50 transition-all cursor-pointer group"
                onClick={() => setSelectedArticle(article)}
              >
                <div className="flex items-start gap-4 mb-4">
                  <div className="p-3 bg-cyan-900/50 border border-cyan-500/30 rounded-xl group-hover:bg-cyan-500/20 transition-colors">
                    {article.icon}
                  </div>
                  <div className="flex-1">
                    <h3 className="text-lg font-bold text-white group-hover:text-cyan-400 transition-colors mb-1">
                      {article.title}
                    </h3>
                    <span className="inline-block px-2 py-1 bg-gray-800 text-cyan-400 text-xs rounded-full">
                      {article.category}
                    </span>
                  </div>
                </div>
                <p className="text-gray-400 text-sm mb-4 line-clamp-3">
                  {article.excerpt}
                </p>
                <div className="flex items-center gap-2 text-cyan-400 text-sm font-medium group-hover:text-cyan-300 transition-colors">
                  <BookOpen className="w-4 h-4" />
                  <span>Read Full Article</span>
                  <ExternalLink className="w-3 h-3 ml-auto" />
                </div>
              </div>
            ))}
          </div>

          {/* Contact Information */}
          <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-8">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-3 bg-cyan-900/50 border border-cyan-500/30 rounded-xl">
                <Mail className="w-6 h-6 text-cyan-400" />
              </div>
              <h2 className="text-2xl font-bold text-white">Contact Our Data Protection Officer</h2>
            </div>
            <p className="text-gray-400 mb-4">
              For any GDPR-related questions, concerns, or to exercise your data subject rights, contact our Data Protection Officer:
            </p>
            <div className="space-y-2 text-gray-400">
              <p><span className="text-cyan-400 font-semibold">Data Protection Officer:</span> dpo@iamai.global</p>
              <p><span className="text-cyan-400 font-semibold">Privacy Team:</span> privacy@iamai.global</p>
              <p><span className="text-cyan-400 font-semibold">General Inquiries:</span> contact@iamai.global</p>
            </div>
          </div>
        </div>
      </main>

      {/* Article Modal */}
      {selectedArticle && (
        <div 
          className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4 animate-fadeIn"
          onClick={() => setSelectedArticle(null)}
        >
          <div 
            className="bg-[#0a0a0a] border border-gray-800 rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="sticky top-0 bg-[#0a0a0a] border-b border-gray-800 p-6 flex items-start justify-between z-10">
              <div className="flex items-start gap-4 flex-1">
                <div className="p-3 bg-cyan-900/50 border border-cyan-500/30 rounded-xl flex-shrink-0">
                  {selectedArticle.icon}
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-white mb-2">{selectedArticle.title}</h2>
                  <span className="inline-block px-3 py-1 bg-gray-800 text-cyan-400 text-sm rounded-full">
                    {selectedArticle.category}
                  </span>
                </div>
              </div>
              <button
                onClick={() => setSelectedArticle(null)}
                className="p-2 hover:bg-gray-800 rounded-lg transition-colors flex-shrink-0"
              >
                <X className="w-6 h-6 text-gray-400 hover:text-white" />
              </button>
            </div>

            {/* Modal Content - Scrollable */}
            <div className="overflow-y-auto max-h-[calc(90vh-140px)] p-6 space-y-6">
              {/* Introduction */}
              {selectedArticle.content.introduction && (
                <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-6">
                  <p className="text-gray-400 leading-relaxed">{selectedArticle.content.introduction}</p>
                </div>
              )}

              {/* Sections */}
              {selectedArticle.content.sections.map((section, index) => (
                <div key={index} className="space-y-4">
                  <h3 className="text-xl font-bold text-white flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-cyan-900/50 border border-cyan-500/30 flex items-center justify-center text-cyan-400 text-sm font-bold">
                      {index + 1}
                    </div>
                    {section.heading}
                  </h3>
                  
                  {section.paragraphs.map((paragraph, pIndex) => (
                    <p key={pIndex} className="text-gray-400 leading-relaxed pl-10">
                      {paragraph}
                    </p>
                  ))}

                  {section.list && section.list.length > 0 && (
                    <ul className="space-y-2 pl-10">
                      {section.list.map((item, itemIndex) => (
                        <li key={itemIndex} className="flex items-start gap-3">
                          <CheckCircle className="w-5 h-5 text-cyan-400 flex-shrink-0 mt-0.5" />
                          <span className="text-gray-400 text-sm">{item}</span>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              ))}

              {/* Conclusion */}
              {selectedArticle.content.conclusion && (
                <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-6 mt-8">
                  <div className="flex items-start gap-3">
                    <AlertCircle className="w-6 h-6 text-cyan-400 flex-shrink-0 mt-1" />
                    <p className="text-gray-400 leading-relaxed font-medium">{selectedArticle.content.conclusion}</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default GDPRPage;
