import React, { useState, useEffect } from 'react';
import { Globe, Search, Lock, Code, Activity, Zap } from 'lucide-react';

// 🌍 PURE REALTIME TOOLBOX COMPONENT
// Works everywhere, no localhost, no backend needed!

class RealtimeToolboxAPI {
  constructor() {
    this.tools = {};
    this.usage = JSON.parse(localStorage.getItem('iamai_toolbox_usage') || '{}');
  }

  // 🌐 Real IP Info using external API
  async getIpInfo(ip = '') {
    try {
      const targetIP = ip || '';
      const url = targetIP ? `http://ip-api.com/json/${targetIP}` : 'http://ip-api.com/json/';

      const response = await fetch(url);
      const data = await response.json();

      this.trackUsage('ipInfo');

      return {
        success: data.status === 'success',
        data: {
          ip: data.query,
          country: data.country,
          region: data.regionName,
          city: data.city,
          isp: data.isp,
          coordinates: `${data.lat}, ${data.lon}`,
          timezone: data.timezone,
          isProxy: data.proxy,
          isMobile: data.mobile,
        },
      };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  // 🔍 Real DNS lookup using Cloudflare API
  async dnsLookup(domain, type = 'A') {
    try {
      const response = await fetch(
        `https://cloudflare-dns.com/dns-query?name=${domain}&type=${type}`,
        { headers: { Accept: 'application/dns-json' } }
      );
      const data = await response.json();

      this.trackUsage('dnsLookup');

      return {
        success: data.Status === 0,
        data: {
          domain,
          type,
          records: data.Answer
            ? data.Answer.map(r => ({
                name: r.name,
                data: r.data,
                ttl: r.TTL,
              }))
            : [],
        },
      };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  // 🛠️ URL Encoder/Decoder (Pure JavaScript)
  urlEncodeDecode(text, operation = 'encode') {
    try {
      let result;
      if (operation === 'encode') {
        result = {
          standard: encodeURIComponent(text),
          base64: btoa(text),
          hex: Array.from(text)
            .map(c => c.charCodeAt(0).toString(16).padStart(2, '0'))
            .join(''),
        };
      } else {
        result = {
          standard: decodeURIComponent(text),
          base64: atob(text),
        };
      }

      this.trackUsage('urlEncoder');
      return { success: true, data: result };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  // 📊 Track usage
  trackUsage(tool) {
    this.usage[tool] = (this.usage[tool] || 0) + 1;
    this.usage.total = (this.usage.total || 0) + 1;
    this.usage.lastUsed = new Date().toISOString();
    localStorage.setItem('iamai_toolbox_usage', JSON.stringify(this.usage));
  }

  // 📈 Get stats
  getStats() {
    return {
      total: this.usage.total || 0,
      tools: this.usage,
      lastUsed: this.usage.lastUsed,
    };
  }
}

const RealtimeToolboxPage: React.FC = () => {
  const [toolboxAPI] = useState(() => new RealtimeToolboxAPI());
  const [activeTab, setActiveTab] = useState('ip-info');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [stats, setStats] = useState(toolboxAPI.getStats());

  // Form states
  const [ipInput, setIpInput] = useState('');
  const [domainInput, setDomainInput] = useState('');
  const [dnsType, setDnsType] = useState('A');
  const [urlInput, setUrlInput] = useState('');
  const [urlOperation, setUrlOperation] = useState('encode');

  const tools = [
    {
      id: 'ip-info',
      name: 'IP Information',
      icon: <Globe className="w-5 h-5" />,
      description: 'Get real-time IP geolocation data',
    },
    {
      id: 'dns-lookup',
      name: 'DNS Lookup',
      icon: <Search className="w-5 h-5" />,
      description: 'Real-time DNS resolution',
    },
    {
      id: 'url-encoder',
      name: 'URL Encoder',
      icon: <Code className="w-5 h-5" />,
      description: 'Encode/decode URLs instantly',
    },
  ];

  const handleToolUse = async (toolId: string) => {
    setLoading(true);
    setResult(null);

    try {
      let response;

      switch (toolId) {
        case 'ip-info':
          response = await toolboxAPI.getIpInfo(ipInput);
          break;
        case 'dns-lookup':
          response = await toolboxAPI.dnsLookup(domainInput, dnsType);
          break;
        case 'url-encoder':
          response = toolboxAPI.urlEncodeDecode(urlInput, urlOperation);
          break;
        default:
          response = { success: false, error: 'Unknown tool' };
      }

      setResult(response);
      setStats(toolboxAPI.getStats());
    } catch (error: any) {
      setResult({ success: false, error: error.message });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <Zap className="w-8 h-8 text-cyan-400 mr-3" />
            <h1 className="text-4xl font-bold text-white">Realtime Toolbox</h1>
          </div>
          <p className="text-xl text-cyan-300 mb-2">Pure cloud tools, no localhost required! 🌍</p>
          <div className="flex items-center justify-center space-x-6 text-sm text-gray-300">
            <span>✅ Works everywhere</span>
            <span>⚡ Real-time APIs</span>
            <span>📊 Usage: {stats?.total || 0}</span>
          </div>
        </div>

        {/* Tool Tabs */}
        <div className="flex justify-center mb-8">
          <div className="flex space-x-2 bg-slate-800/50 rounded-lg p-2">
            {tools.map(tool => (
              <button
                key={tool.id}
                onClick={() => setActiveTab(tool.id)}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-all ${
                  activeTab === tool.id
                    ? 'bg-cyan-600 text-white'
                    : 'text-gray-300 hover:bg-slate-700'
                }`}
              >
                {tool.icon}
                <span>{tool.name}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Tool Input */}
          <div className="bg-slate-800/50 rounded-xl p-6 border border-slate-700">
            <h3 className="text-xl font-bold text-white mb-4">
              {tools.find(t => t.id === activeTab)?.name}
            </h3>
            <p className="text-gray-300 mb-6">{tools.find(t => t.id === activeTab)?.description}</p>

            {/* IP Info Form */}
            {activeTab === 'ip-info' && (
              <div className="space-y-4">
                <input
                  type="text"
                  placeholder="Enter IP address (leave empty for your IP)"
                  value={ipInput}
                  onChange={e => setIpInput(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                />
                <button
                  onClick={() => handleToolUse('ip-info')}
                  disabled={loading}
                  className="w-full bg-gradient-to-r from-cyan-600 to-blue-600 text-white px-6 py-3 rounded-lg hover:from-cyan-700 hover:to-blue-700 disabled:opacity-50 flex items-center justify-center space-x-2"
                >
                  {loading ? (
                    <Activity className="w-5 h-5 animate-spin" />
                  ) : (
                    <Globe className="w-5 h-5" />
                  )}
                  <span>{loading ? 'Looking up...' : 'Get IP Info'}</span>
                </button>
              </div>
            )}

            {/* DNS Lookup Form */}
            {activeTab === 'dns-lookup' && (
              <div className="space-y-4">
                <input
                  type="text"
                  placeholder="Enter domain name (e.g., google.com)"
                  value={domainInput}
                  onChange={e => setDomainInput(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                />
                <select
                  value={dnsType}
                  onChange={e => setDnsType(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
                >
                  <option value="A">A Record</option>
                  <option value="AAAA">AAAA Record</option>
                  <option value="MX">MX Record</option>
                  <option value="TXT">TXT Record</option>
                  <option value="NS">NS Record</option>
                </select>
                <button
                  onClick={() => handleToolUse('dns-lookup')}
                  disabled={loading || !domainInput}
                  className="w-full bg-gradient-to-r from-cyan-600 to-blue-600 text-white px-6 py-3 rounded-lg hover:from-cyan-700 hover:to-blue-700 disabled:opacity-50 flex items-center justify-center space-x-2"
                >
                  {loading ? (
                    <Activity className="w-5 h-5 animate-spin" />
                  ) : (
                    <Search className="w-5 h-5" />
                  )}
                  <span>{loading ? 'Looking up...' : 'DNS Lookup'}</span>
                </button>
              </div>
            )}

            {/* URL Encoder Form */}
            {activeTab === 'url-encoder' && (
              <div className="space-y-4">
                <textarea
                  placeholder="Enter text to encode/decode"
                  value={urlInput}
                  onChange={e => setUrlInput(e.target.value)}
                  rows={3}
                  className="w-full px-4 py-3 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                />
                <select
                  value={urlOperation}
                  onChange={e => setUrlOperation(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
                >
                  <option value="encode">Encode</option>
                  <option value="decode">Decode</option>
                </select>
                <button
                  onClick={() => handleToolUse('url-encoder')}
                  disabled={loading || !urlInput}
                  className="w-full bg-gradient-to-r from-cyan-600 to-blue-600 text-white px-6 py-3 rounded-lg hover:from-cyan-700 hover:to-blue-700 disabled:opacity-50 flex items-center justify-center space-x-2"
                >
                  {loading ? (
                    <Activity className="w-5 h-5 animate-spin" />
                  ) : (
                    <Code className="w-5 h-5" />
                  )}
                  <span>
                    {loading
                      ? 'Processing...'
                      : `${urlOperation.charAt(0).toUpperCase() + urlOperation.slice(1)} Text`}
                  </span>
                </button>
              </div>
            )}
          </div>

          {/* Results */}
          <div className="bg-slate-800/50 rounded-xl p-6 border border-slate-700">
            <h3 className="text-xl font-bold text-white mb-4">Results</h3>

            {result ? (
              <div className="space-y-4">
                {result.success ? (
                  <div className="space-y-3">
                    <div className="flex items-center space-x-2 text-green-400">
                      <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                      <span className="text-sm font-medium">SUCCESS</span>
                    </div>

                    <div className="bg-slate-900/50 rounded-lg p-4">
                      <pre className="text-sm text-gray-300 whitespace-pre-wrap overflow-x-auto">
                        {JSON.stringify(result.data, null, 2)}
                      </pre>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <div className="flex items-center space-x-2 text-red-400">
                      <div className="w-2 h-2 bg-red-400 rounded-full"></div>
                      <span className="text-sm font-medium">ERROR</span>
                    </div>

                    <div className="bg-red-900/20 border border-red-800 rounded-lg p-4">
                      <p className="text-red-300 text-sm">{result.error}</p>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-center py-12">
                <Activity className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                <p className="text-gray-400">Select a tool and run it to see results</p>
                <p className="text-sm text-gray-500 mt-2">
                  All tools work in real-time using external APIs
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Status Footer */}
        <div className="mt-8 text-center">
          <div className="inline-flex items-center space-x-4 text-sm text-gray-400 bg-slate-800/30 px-6 py-3 rounded-lg">
            <span>🌍 Pure Realtime</span>
            <span>•</span>
            <span>⚡ No localhost</span>
            <span>•</span>
            <span>📡 External APIs</span>
            <span>•</span>
            <span>💾 Usage tracked</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RealtimeToolboxPage;
