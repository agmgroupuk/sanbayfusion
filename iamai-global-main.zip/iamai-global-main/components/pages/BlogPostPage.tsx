import React from 'react';
import { BlogPost } from '../../constants';

interface BlogPostPageProps {
  post: BlogPost;
  onNavigate: (page: 'blog' | 'home') => void;
}

const BlogPostPage: React.FC<BlogPostPageProps> = ({ post, onNavigate }) => {
  const fullContent = post.content || post.excerpt.repeat(5); // Fallback for full content

  return (
    <div className="py-20 md:py-28 bg-black">
      <div className="container mx-auto px-6">
        <div className="max-w-3xl mx-auto">
          <div className="mb-8">
             <button onClick={() => onNavigate('blog')} title="Return to the blog page" className="text-cyan-400 hover:text-cyan-300 font-semibold transition-colors">
                &larr; Back to Blog
             </button>
          </div>
          
          <article>
            <div className="text-sm text-gray-400 mb-2">
                <span className="font-semibold text-cyan-400">{post.category}</span>
                <span className="mx-2">&bull;</span>
                <span>{post.date}</span>
            </div>
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-extrabold text-white tracking-tight mb-6">
                {post.title}
            </h1>
            
            <img 
                src={post.imageUrl} 
                alt={post.title} 
                className="w-full rounded-2xl aspect-video object-cover my-8"
            />

            <div className="prose prose-invert prose-lg max-w-none text-gray-300 leading-relaxed">
              <p>{fullContent}</p>
              {/* You can add more paragraphs or structured content here */}
            </div>
          </article>
          
          <div className="mt-12 pt-8 border-t border-gray-800">
             <button onClick={() => onNavigate('home')} title="Return to the homepage" className="text-gray-400 hover:text-cyan-400 transition-colors">
                &larr; Back to Home
             </button>
          </div>
        </div>
      </div>
       <style>{`
            .prose-invert h1, .prose-invert h2, .prose-invert h3, .prose-invert strong { color: #fff; }
            .prose-invert a { color: #67e8f9; }
            .prose-invert a:hover { color: #22d3ee; }
            .prose-invert blockquote { border-left-color: #0891b2; color: #9ca3af; }
       `}</style>
    </div>
  );
};

export default BlogPostPage;