import React, { useState, useRef, useEffect } from 'react';
import { Page } from '../../App';
import { Send, Settings, MessageSquare, Zap, Settings2, X, RefreshCw, ThumbsUp, ThumbsDown, Copy, Volume2, VolumeX } from 'lucide-react';
import { getApiUrl } from '../../config/api';
import ReactMarkdown from 'react-markdown';

interface AIStudioPageProps {
  onNavigate: (page: Page) => void;
}

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

interface TerminalSettings {
  model: 'mistral' | 'openai';
  temperature: number;
  maxTokens: number;
}

const MAX_MESSAGES = 20; // Maximum messages before requiring refresh

const SettingsPanel: React.FC<{
  settings: TerminalSettings;
  onSettingsChange: (settings: TerminalSettings) => void;
  onClose: () => void;
}> = ({ settings, onSettingsChange, onClose }) => (
  <div className="w-64 bg-gray-900/80 border-r border-gray-700 p-4 flex flex-col">
    <div className="flex items-center justify-between mb-6">
      <h3 className="text-lg font-bold text-white flex items-center gap-2">
        <Settings2 className="w-5 h-5 text-cyan-400" />
        Settings
      </h3>
      <button
        onClick={onClose}
        className="text-gray-400 hover:text-gray-300 transition-colors"
      >
        <X className="w-5 h-5" />
      </button>
    </div>

    <div className="space-y-6">
      {/* Model Selection */}
      <div>
        <label className="block text-sm font-semibold text-gray-300 mb-2">AI Model</label>
        <select
          value={settings.model}
          onChange={(e) => onSettingsChange({ ...settings, model: e.target.value as 'mistral' | 'openai' })}
          className="w-full bg-gray-800 border border-gray-700 rounded px-3 py-2 text-white text-sm focus:outline-none focus:border-cyan-500"
        >
          <option value="mistral">Mistral AI (Default)</option>
          <option value="openai">OpenAI GPT-4</option>
        </select>
        <p className="text-xs text-gray-500 mt-1">Fallback to OpenAI if Mistral unavailable</p>
      </div>

      {/* Temperature */}
      <div>
        <label className="block text-sm font-semibold text-gray-300 mb-2">
          Temperature: <span className="text-cyan-400">{settings.temperature.toFixed(2)}</span>
        </label>
        <input
          type="range"
          min="0"
          max="2"
          step="0.1"
          value={settings.temperature}
          onChange={(e) => onSettingsChange({ ...settings, temperature: parseFloat(e.target.value) })}
          className="w-full accent-cyan-500"
        />
        <p className="text-xs text-gray-500 mt-1">0 = Precise, 2 = Creative</p>
      </div>

      {/* Max Tokens */}
      <div>
        <label className="block text-sm font-semibold text-gray-300 mb-2">
          Max Tokens: <span className="text-cyan-400">{settings.maxTokens}</span>
        </label>
        <input
          type="range"
          min="100"
          max="2000"
          step="100"
          value={settings.maxTokens}
          onChange={(e) => onSettingsChange({ ...settings, maxTokens: parseInt(e.target.value) })}
          className="w-full accent-cyan-500"
        />
        <p className="text-xs text-gray-500 mt-1">Response length limit</p>
      </div>
    </div>

    <div className="mt-auto pt-6 border-t border-gray-700">
      <p className="text-xs text-gray-500 text-center">
        ✓ API keys from backend securely handled
      </p>
    </div>
  </div>
);

const DemoChat: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '0',
      role: 'assistant',
      content: '👋 **Welcome to AI Studio!** I\'m your **IA M AI Global** assistant, designed to showcase our platform\'s capabilities. Feel free to test any queries, ask questions, or explore what I can do. Let\'s chat! 💬✨',
      timestamp: new Date(),
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [loadingMessage, setLoadingMessage] = useState('AI Thinking...');
  const [showSettings, setShowSettings] = useState(false);
  const [messageCount, setMessageCount] = useState(0);
  const [showLimitModal, setShowLimitModal] = useState(false);
  const [feedbackStates, setFeedbackStates] = useState<Record<string, 'up' | 'down' | null>>({});
  const [speakingMessageId, setSpeakingMessageId] = useState<string | null>(null);
  const [copiedMessageId, setCopiedMessageId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const messagesContainerRef = useRef<HTMLDivElement>(null);
  const speechSynthesisRef = useRef<SpeechSynthesisUtterance | null>(null);
  const [settings, setSettings] = useState<TerminalSettings>({
    model: 'mistral',
    temperature: 0.7,
    maxTokens: 1000,
  });

  const loadingMessages = [
    '🤔 AI Thinking...',
    '✨ Generating response...',
    '⚡ Processing your request...',
    '🎯 Crafting the perfect answer...',
    '🔍 Analyzing your question...',
    '🧠 Consulting the AI brain...',
    '💫 Preparing something amazing...',
    '⚙️ Working on it...'
  ];

  // Rotate loading messages
  useEffect(() => {
    if (!isLoading) return;
    
    let index = 0;
    const interval = setInterval(() => {
      index = (index + 1) % loadingMessages.length;
      setLoadingMessage(loadingMessages[index]);
    }, 2000); // Change message every 2 seconds

    return () => clearInterval(interval);
  }, [isLoading]);

  const scrollToBottom = () => {
    if (messagesContainerRef.current) {
      messagesContainerRef.current.scrollTop = messagesContainerRef.current.scrollHeight;
    }
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const handleRefreshChat = () => {
    setMessages([
      {
        id: '0',
        role: 'assistant',
        content: '👋 **Welcome back!** I\'m your **IA M AI Global** assistant, ready for a new conversation. Feel free to ask me anything! 🚀',
        timestamp: new Date(),
      }
    ]);
    setMessageCount(0);
    setShowLimitModal(false);
    setFeedbackStates({});
    setSpeakingMessageId(null);
    setCopiedMessageId(null);
    // Stop any ongoing speech
    if (speechSynthesisRef.current) {
      window.speechSynthesis.cancel();
    }
  };

  // Handle thumbs up/down feedback
  const handleFeedback = (messageId: string, type: 'up' | 'down') => {
    setFeedbackStates(prev => ({
      ...prev,
      [messageId]: prev[messageId] === type ? null : type
    }));
  };

  // Handle copy message
  const handleCopy = (messageId: string, content: string) => {
    // Remove markdown formatting for cleaner copy
    const plainText = content
      .replace(/\*\*(.*?)\*\*/g, '$1') // Remove bold
      .replace(/\*(.*?)\*/g, '$1') // Remove italic
      .replace(/#{1,6}\s/g, '') // Remove headers
      .replace(/\[(.*?)\]\(.*?\)/g, '$1'); // Remove links
    
    navigator.clipboard.writeText(plainText).then(() => {
      setCopiedMessageId(messageId);
      setTimeout(() => setCopiedMessageId(null), 2000);
    });
  };

  // Handle text-to-speech
  const handleSpeak = (messageId: string, content: string) => {
    // If this message is already speaking, stop it
    if (speakingMessageId === messageId) {
      window.speechSynthesis.cancel();
      setSpeakingMessageId(null);
      speechSynthesisRef.current = null;
      return;
    }

    // Stop any currently speaking message
    if (speakingMessageId) {
      window.speechSynthesis.cancel();
    }

    // Remove markdown formatting for speech
    const plainText = content
      .replace(/\*\*(.*?)\*\*/g, '$1')
      .replace(/\*(.*?)\*/g, '$1')
      .replace(/#{1,6}\s/g, '')
      .replace(/\[(.*?)\]\(.*?\)/g, '$1')
      .replace(/[🤗⚕️💪🌟🧘🌙✈️💻📊🔒☁️💰⚖️📈👨‍🍳⚽📱👋💬✨🔍🎯⚡🧠💫⚙️🚀🤔]/g, ''); // Remove emojis

    const utterance = new SpeechSynthesisUtterance(plainText);
    utterance.rate = 0.9;
    utterance.pitch = 1;
    utterance.volume = 1;

    utterance.onend = () => {
      setSpeakingMessageId(null);
      speechSynthesisRef.current = null;
    };

    utterance.onerror = () => {
      setSpeakingMessageId(null);
      speechSynthesisRef.current = null;
    };

    speechSynthesisRef.current = utterance;
    setSpeakingMessageId(messageId);
    window.speechSynthesis.speak(utterance);
  };

  // Cleanup speech on unmount
  useEffect(() => {
    return () => {
      if (speechSynthesisRef.current) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  const handleSendMessage = async () => {
    if (!inputValue.trim()) return;

    // Check message limit
    if (messageCount >= MAX_MESSAGES) {
      setShowLimitModal(true);
      return;
    }

    // Add user message
    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: inputValue,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputValue('');
    setIsLoading(true);
    setMessageCount((prev) => prev + 1);

    // Create placeholder for assistant message with streaming
    const assistantId = (Date.now() + 1).toString();
    const assistantMessage: ChatMessage = {
      id: assistantId,
      role: 'assistant',
      content: '',
      timestamp: new Date(),
    };
    setMessages((prev) => [...prev, assistantMessage]);

    try {
      // Call backend API with streaming enabled
      const response = await fetch(getApiUrl('/ai/chat'), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: userMessage.content,
          provider: settings.model,
          temperature: settings.temperature,
          maxTokens: settings.maxTokens,
          conversationHistory: messages.slice(-5).map(m => ({ 
            role: m.role,
            content: m.content
          })),
          stream: false // Disable streaming for now until we fix the async iterable issue
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to get response from AI');
      }

      // Check if streaming is supported
      const contentType = response.headers.get('content-type');
      if (contentType?.includes('text/event-stream')) {
        // Handle streaming response
        const reader = response.body?.getReader();
        const decoder = new TextDecoder();
        let fullText = '';

        if (reader) {
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;

            const chunk = decoder.decode(value, { stream: true });
            const lines = chunk.split('\n');

            for (const line of lines) {
              if (line.startsWith('data: ')) {
                try {
                  const data = JSON.parse(line.slice(6));
                  
                  if (data.error) {
                    // Handle error from stream
                    console.error('Stream error:', data.error);
                    setMessages((prev) =>
                      prev.map((msg) =>
                        msg.id === assistantId
                          ? { ...msg, content: `Error: ${data.error}` }
                          : msg
                      )
                    );
                    break;
                  }
                  
                  if (data.text) {
                    fullText += data.text;
                    // Update message with typing effect
                    setMessages((prev) =>
                      prev.map((msg) =>
                        msg.id === assistantId
                          ? { ...msg, content: fullText }
                          : msg
                      )
                    );
                  }
                  if (data.done) {
                    break;
                  }
                } catch (e) {
                  // Ignore parsing errors for incomplete chunks
                }
              }
            }
          }
        }

        setMessageCount((prev) => prev + 1);
      } else {
        // Fallback to non-streaming
        const data = await response.json();
        setMessages((prev) =>
          prev.map((msg) =>
            msg.id === assistantId
              ? { ...msg, content: data.response || 'I apologize, but I encountered an error processing your request.' }
              : msg
          )
        );
        setMessageCount((prev) => prev + 1);
      }
    } catch (error) {
      console.error('Error sending message:', error);
      
      // Update placeholder with error message
      setMessages((prev) =>
        prev.map((msg) =>
          msg.id === assistantId
            ? { ...msg, content: 'I apologize, but I\'m having trouble connecting to the AI service right now. Please try again in a moment.' }
            : msg
        )
      );
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex h-full bg-black text-white">
      {/* Message Limit Modal */}
      {showLimitModal && (
        <div className="absolute inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-gray-900 border border-cyan-500 rounded-xl p-8 max-w-md w-full shadow-2xl">
            <div className="text-center">
              <div className="w-16 h-16 bg-cyan-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <MessageSquare className="w-8 h-8 text-cyan-400" />
              </div>
              <h3 className="text-2xl font-bold text-white mb-2">Message Limit Reached</h3>
              <p className="text-gray-400 mb-6">
                You've reached the message limit for this demo session. Refresh the chat to start a new conversation with IA M AI Global!
              </p>
              <button
                onClick={handleRefreshChat}
                className="w-full bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 text-white font-semibold px-6 py-3 rounded-lg transition-all flex items-center justify-center gap-2"
              >
                <RefreshCw className="w-5 h-5" />
                Refresh Chat Session
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Settings Panel */}
      {showSettings && (
        <SettingsPanel
          settings={settings}
          onSettingsChange={setSettings}
          onClose={() => setShowSettings(false)}
        />
      )}

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col">
        {/* Top Bar */}
        <div className="flex items-center justify-between p-4 border-b border-gray-700 bg-gray-900/50">
          <div className="flex items-center gap-3">
            <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
            <span className="text-sm font-semibold">Demo Chat - IA M AI</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleRefreshChat}
              className="p-2 hover:bg-gray-800 rounded-lg transition-colors text-gray-400 hover:text-cyan-400"
              title="Refresh chat"
            >
              <RefreshCw className="w-5 h-5" />
            </button>
            <button
              onClick={() => setShowSettings(!showSettings)}
              className="p-2 hover:bg-gray-800 rounded-lg transition-colors text-cyan-400 hover:text-cyan-300"
              title="Toggle settings panel"
            >
              <Settings className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Messages Container */}
        <div ref={messagesContainerRef} className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`max-w-[75%] ${message.role === 'assistant' ? 'space-y-2' : ''}`}>
                <div
                  className={`px-4 py-3 rounded-2xl ${
                    message.role === 'user'
                      ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white'
                      : 'bg-gray-800 text-gray-100 border border-gray-700'
                  }`}
                >
                  <div className="text-sm whitespace-pre-wrap prose prose-invert prose-sm max-w-none">
                    {message.role === 'user' ? (
                      <p className="mb-0">{message.content}</p>
                    ) : (
                      <ReactMarkdown
                        components={{
                          p: ({children}) => <p className="mb-2 last:mb-0">{children}</p>,
                          h1: ({children}) => <h1 className="text-lg font-bold mb-2 text-cyan-400">{children}</h1>,
                          h2: ({children}) => <h2 className="text-base font-bold mb-2 text-cyan-400">{children}</h2>,
                          h3: ({children}) => <h3 className="text-sm font-bold mb-1 text-cyan-400">{children}</h3>,
                          strong: ({children}) => <strong className="font-bold text-white">{children}</strong>,
                          em: ({children}) => <em className="italic text-cyan-300">{children}</em>,
                          ul: ({children}) => <ul className="list-disc list-inside mb-2 space-y-1">{children}</ul>,
                          ol: ({children}) => <ol className="list-decimal list-inside mb-2 space-y-1">{children}</ol>,
                          li: ({children}) => <li className="ml-2">{children}</li>,
                          code: ({children}) => <code className="bg-gray-900 px-1 py-0.5 rounded text-cyan-400 text-xs">{children}</code>,
                          pre: ({children}) => <pre className="bg-gray-900 p-2 rounded mb-2 overflow-x-auto text-xs">{children}</pre>,
                          a: ({children, href}) => <a href={href} className="text-cyan-400 hover:text-cyan-300 underline" target="_blank" rel="noopener noreferrer">{children}</a>,
                        }}
                      >
                        {message.content}
                      </ReactMarkdown>
                    )}
                  </div>
                  <span className="text-xs opacity-70 mt-1 block">
                    {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>

                {/* Action Buttons for Assistant Messages */}
                {message.role === 'assistant' && (
                  <div className="flex items-center gap-2 px-2">
                    {/* Thumbs Up */}
                    <button
                      onClick={() => handleFeedback(message.id, 'up')}
                      className={`p-1.5 rounded-lg transition-all hover:bg-gray-700 ${
                        feedbackStates[message.id] === 'up' 
                          ? 'text-green-400 bg-gray-700' 
                          : 'text-gray-500 hover:text-green-400'
                      }`}
                      title="Good response"
                    >
                      <ThumbsUp className="w-4 h-4" />
                    </button>

                    {/* Thumbs Down */}
                    <button
                      onClick={() => handleFeedback(message.id, 'down')}
                      className={`p-1.5 rounded-lg transition-all hover:bg-gray-700 ${
                        feedbackStates[message.id] === 'down' 
                          ? 'text-red-400 bg-gray-700' 
                          : 'text-gray-500 hover:text-red-400'
                      }`}
                      title="Bad response"
                    >
                      <ThumbsDown className="w-4 h-4" />
                    </button>

                    {/* Copy */}
                    <button
                      onClick={() => handleCopy(message.id, message.content)}
                      className={`p-1.5 rounded-lg transition-all hover:bg-gray-700 ${
                        copiedMessageId === message.id
                          ? 'text-cyan-400 bg-gray-700'
                          : 'text-gray-500 hover:text-cyan-400'
                      }`}
                      title={copiedMessageId === message.id ? 'Copied!' : 'Copy message'}
                    >
                      <Copy className="w-4 h-4" />
                    </button>

                    {/* Text-to-Speech */}
                    <button
                      onClick={() => handleSpeak(message.id, message.content)}
                      className={`p-1.5 rounded-lg transition-all hover:bg-gray-700 ${
                        speakingMessageId === message.id
                          ? 'text-cyan-400 bg-gray-700 animate-pulse'
                          : 'text-gray-500 hover:text-cyan-400'
                      }`}
                      title={speakingMessageId === message.id ? 'Stop speaking' : 'Read aloud'}
                    >
                      {speakingMessageId === message.id ? (
                        <VolumeX className="w-4 h-4" />
                      ) : (
                        <Volume2 className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="flex justify-start">
              <div className="bg-gray-800 text-gray-100 border border-gray-700 px-4 py-3 rounded-2xl">
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse"></div>
                  <span className="text-sm text-cyan-400 animate-pulse">{loadingMessage}</span>
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <div className="border-t border-gray-700 p-4 bg-gray-900/50">
          <div className="flex gap-2">
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && !e.shiftKey && handleSendMessage()}
              placeholder="Type your message and press Enter..."
              className="flex-1 bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500 transition-colors"
              disabled={isLoading || messageCount >= MAX_MESSAGES}
            />
            <button
              onClick={handleSendMessage}
              disabled={isLoading || !inputValue.trim() || messageCount >= MAX_MESSAGES}
              className="bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700 disabled:from-gray-700 disabled:to-gray-700 disabled:cursor-not-allowed text-white px-6 py-3 rounded-lg transition-all flex items-center gap-2 font-semibold"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
          <p className="text-xs text-gray-500 mt-2 text-center">
            💫 Powered by <span className="text-cyan-400 font-semibold">IAMAI Global</span>
          </p>
        </div>
      </div>
    </div>
  );
};

const FeatureCard: React.FC<{ icon: string, title: string, description: string }> = ({ icon, title, description }) => (
    <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6 flex flex-col items-start space-y-4 hover:border-cyan-500/50 hover:bg-gray-900 transition-all duration-300">
        <div className="w-12 h-12 flex items-center justify-center rounded-lg bg-gray-800 text-cyan-400">
            <i className={`${icon} text-2xl`}></i>
        </div>
        <h3 className="text-xl font-bold text-white">{title}</h3>
        <p className="text-gray-400">{description}</p>
    </div>
);


const AIStudioPage: React.FC<AIStudioPageProps> = ({ onNavigate }) => {
  return (
    <div className="bg-black text-white">
      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 md:py-32">
        <div className="absolute inset-0 bg-grid-gray-900 [mask-image:linear-gradient(to_bottom,white_30%,transparent)]"></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-cyan-500/10 rounded-full blur-3xl"></div>
        <div className="container mx-auto px-6 text-center relative z-10">
            <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight mb-4 bg-clip-text text-transparent bg-gradient-to-b from-white to-gray-400">
                The AI Studio
            </h1>
            <p className="max-w-3xl mx-auto text-lg md:text-xl text-gray-400 mb-8">
                Your personal agent factory. Design, build, and deploy custom AI agents with unique personalities, skills, and capabilities—no complex code required.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
                <button
                    onClick={() => onNavigate('community')}
                    title="Join our community"
                    className="bg-cyan-500 hover:bg-cyan-600 text-black font-semibold px-8 py-3 rounded-full transition-all duration-300 transform hover:scale-105 flex items-center gap-2"
                >
                    <MessageSquare className="w-5 h-5" />
                    Visit Community
                </button>
                <button
                    onClick={() => onNavigate('support')}
                    title="Get help and support"
                    className="bg-purple-600 hover:bg-purple-700 text-white font-semibold px-8 py-3 rounded-full transition-all duration-300 transform hover:scale-105 flex items-center gap-2"
                >
                    <Zap className="w-5 h-5" />
                    Support Center
                </button>
            </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 md:py-28 bg-[#0a0a0a]">
         <div className="container mx-auto px-6">
            <div className="text-center mb-12">
                <h2 className="text-3xl md:text-4xl font-bold text-white">Create Agents as Unique as Your Ideas</h2>
                <p className="max-w-2xl mx-auto mt-4 text-gray-400">
                    The AI Studio provides all the tools you need to bring your vision for an AI agent to life.
                </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <FeatureCard 
                    icon="fa-solid fa-sliders"
                    title="Visual Persona Editor"
                    description="Craft your agent's personality with intuitive sliders for traits like formality, humor, and enthusiasm. Define their core role and purpose with simple text inputs."
                />
                 <FeatureCard 
                    icon="fa-solid fa-puzzle-piece"
                    title="Modular Capabilities"
                    description="Equip your agents with powerful skills. Enable web access for real-time information, allow file attachments for document analysis, and much more with a single click."
                />
                 <FeatureCard 
                    icon="fa-solid fa-wand-magic-sparkles"
                    title="Custom Iconography"
                    description="Give your agent a unique identity. Choose from a library of predefined icons or upload your own image to perfectly match your agent's character."
                />
                 <FeatureCard 
                    icon="fa-solid fa-brain"
                    title="Advanced Cognition"
                    description="For fine-grained control, configure your agent's memory, learning style, and reasoning abilities to handle complex, long-term tasks."
                />
                 <FeatureCard 
                    icon="fa-solid fa-code"
                    title="Developer Toolkit"
                    description="Enable a suite of developer tools for your agent, including a code sandbox and API builder, turning it into a powerful development assistant."
                />
                 <FeatureCard 
                    icon="fa-solid fa-rocket"
                    title="Instant Deployment"
                    description="Once you're happy with your creation, save it and it instantly becomes available in your agent ecosystem, ready for you to interact with."
                />
            </div>
         </div>
      </section>
      
      {/* How it Works Screenshot Section */}
       <section className="py-20 md:py-28 bg-black">
        <div className="container mx-auto px-6">
            <div className="text-center mb-12">
                 <h2 className="text-3xl md:text-4xl font-bold text-white">An Interface for Imagination</h2>
                 <p className="max-w-2xl mx-auto mt-4 text-gray-400">
                    Test our AI in real-time with a live demo chat. Configure your preferred model and settings to explore our capabilities.
                 </p>
            </div>
            <div className="max-w-5xl mx-auto">
                 <div className="bg-black border border-gray-800 rounded-lg shadow-2xl shadow-cyan-500/10 overflow-hidden h-[500px] flex">
                        <DemoChat />
                    </div>
            </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 md:py-28 bg-black">
        <div className="container mx-auto px-6">
            <div className="bg-gradient-to-r from-cyan-500 to-purple-500 rounded-2xl p-10 md:p-16 text-center">
                <h2 className="text-3xl md:text-4xl font-bold text-black">Ready to Create Your First Agent?</h2>
                <p className="max-w-2xl mx-auto mt-4 text-gray-800">
                    Join the platform and unlock the AI Studio today. Your first custom agent is just a few clicks away.
                </p>
                <div className="mt-8">
                    <button
                        onClick={() => onNavigate('signup')}
                        title="Sign up for a free account"
                        className="bg-black text-white font-semibold px-8 py-3 rounded-full hover:bg-gray-800 transition-all duration-300 transform hover:scale-105"
                    >
                        Get Started Now
                    </button>
                </div>
            </div>
        </div>
      </section>

    </div>
  );
};

export default AIStudioPage;