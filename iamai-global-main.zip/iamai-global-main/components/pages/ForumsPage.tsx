import React, { useState, useEffect } from 'react';
import { Page } from '../../App';
import { MessageSquare, Heart, Reply, User, Search, Filter, TrendingUp, Award, Clock, Send, Trash2, Pin } from 'lucide-react';

interface ForumsPageProps {
  onNavigate: (page: Page) => void;
}

interface Reply {
  id: number;
  author: string;
  content: string;
  timestamp: string;
  likes: number;
  isHelpful: boolean;
  authorLevel: 'user' | 'moderator' | 'expert';
  authorAvatar?: string;
}

interface Discussion {
  id: number;
  author: string;
  authorLevel: 'user' | 'moderator' | 'expert';
  title: string;
  content: string;
  timestamp: string;
  category: string;
  replies: Reply[];
  views: number;
  likes: number;
  solved: boolean;
  tags: string[];
  pinned?: boolean;
  authorAvatar?: string;
}

interface FormData {
  name: string;
  email: string;
  category: string;
  title: string;
  message: string;
  tags: string;
}

const AuthorBadge: React.FC<{ level: 'user' | 'moderator' | 'expert' }> = ({ level }) => {
  const styles = {
    user: { bg: 'bg-gray-700', icon: 'fa-solid fa-user', label: 'User' },
    moderator: { bg: 'bg-purple-600', icon: 'fa-solid fa-shield', label: 'Moderator' },
    expert: { bg: 'bg-cyan-600', icon: 'fa-solid fa-star', label: 'Expert' },
  };
  const style = styles[level];
  return (
    <div className={`${style.bg} px-2 py-1 rounded text-xs font-semibold text-white inline-flex items-center gap-1`}>
      <i className={style.icon}></i>
      {style.label}
    </div>
  );
};

const ReplyCard: React.FC<{ 
  reply: Reply
  onLike: () => void
  onDelete?: () => void
  isOwn?: boolean
}> = ({ reply, onLike, onDelete, isOwn }) => (
  <div className="bg-gray-800/30 border border-gray-700 rounded-lg p-4 ml-8 mt-3 hover:border-gray-600 transition-colors">
    <div className="flex items-start justify-between mb-3">
      <div className="flex items-center gap-3 flex-1">
        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-cyan-500/30 to-blue-500/30 flex items-center justify-center text-cyan-400 text-xs font-bold">
          {reply.author[0].toUpperCase()}
        </div>
        <div className="flex-1">
          <p className="font-semibold text-white text-sm">{reply.author}</p>
          <p className="text-xs text-gray-500">{reply.timestamp}</p>
        </div>
      </div>
      <div className="flex items-center gap-2">
        {reply.isHelpful && (
          <span className="text-xs bg-green-500/20 text-green-400 px-2 py-1 rounded">✓ Helpful</span>
        )}
        <AuthorBadge level={reply.authorLevel} />
      </div>
    </div>
    <p className="text-gray-300 text-sm mb-3 leading-relaxed">{reply.content}</p>
    <div className="flex items-center gap-4">
      <button
        onClick={onLike}
        className="flex items-center gap-1 text-gray-400 hover:text-red-400 transition-colors text-sm group"
      >
        <Heart className="w-4 h-4 group-hover:fill-red-400" />
        <span>{reply.likes}</span>
      </button>
      {isOwn && onDelete && (
        <button
          onClick={onDelete}
          className="flex items-center gap-1 text-gray-500 hover:text-red-500 transition-colors text-sm ml-auto"
        >
          <Trash2 className="w-4 h-4" />
        </button>
      )}
    </div>
  </div>
);

const DiscussionCard: React.FC<{ 
  discussion: Discussion
  isExpanded: boolean
  onExpand: () => void
}> = ({ discussion, isExpanded, onExpand }) => (
  <div
    onClick={onExpand}
    className={`bg-gray-900/50 border rounded-lg p-6 transition-all cursor-pointer group ${
      isExpanded ? 'border-cyan-500/50 bg-gray-900/70' : 'border-gray-800 hover:border-cyan-500/50 hover:bg-gray-900/70'
    }`}
  >
    <div className="flex items-start justify-between mb-3">
      <div className="flex items-start gap-3 flex-1">
        <div className="w-12 h-12 rounded-full bg-gradient-to-br from-cyan-500/20 to-blue-500/20 flex items-center justify-center text-cyan-400 font-bold text-lg flex-shrink-0">
          {discussion.author[0].toUpperCase()}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <p className="font-semibold text-white group-hover:text-cyan-400 transition-colors">{discussion.author}</p>
            <AuthorBadge level={discussion.authorLevel} />
            {discussion.solved && (
              <span className="text-xs bg-green-500/20 text-green-400 px-2 py-1 rounded">✓ Solved</span>
            )}
            {discussion.pinned && (
              <span className="text-xs bg-yellow-500/20 text-yellow-400 px-2 py-1 rounded flex items-center gap-1">
                <Pin className="w-3 h-3" /> Pinned
              </span>
            )}
          </div>
          <p className="text-xs text-gray-500">{discussion.timestamp}</p>
        </div>
      </div>
      <span className="text-xs bg-cyan-500/20 text-cyan-400 px-3 py-1 rounded-full flex-shrink-0">{discussion.category}</span>
    </div>

    <h3 className="text-lg font-bold text-white mb-2 group-hover:text-cyan-400 transition-colors line-clamp-2">{discussion.title}</h3>
    <p className="text-gray-400 mb-4 line-clamp-2">{discussion.content}</p>

    <div className="flex flex-wrap gap-2 mb-4">
      {discussion.tags.map((tag, idx) => (
        <span key={idx} className="text-xs bg-gray-800 text-gray-300 px-2 py-1 rounded hover:bg-gray-700 cursor-pointer transition-colors">
          #{tag}
        </span>
      ))}
    </div>

    <div className="flex items-center gap-6 pt-4 border-t border-gray-800">
      <div className="flex items-center gap-2 text-gray-400 hover:text-cyan-400 transition-colors">
        <MessageSquare className="w-4 h-4" />
        <span className="text-sm font-medium">{discussion.replies.length} replies</span>
      </div>
      <div className="flex items-center gap-2 text-gray-400">
        <TrendingUp className="w-4 h-4" />
        <span className="text-sm font-medium">{discussion.views} views</span>
      </div>
      <div className="flex items-center gap-2 text-gray-400 hover:text-red-400 transition-colors">
        <Heart className="w-4 h-4" />
        <span className="text-sm font-medium">{discussion.likes}</span>
      </div>
      <span className="text-xs text-gray-500 ml-auto">{isExpanded ? '▼ Collapse' : '▶ Expand'}</span>
    </div>
  </div>
);

const ForumsPage: React.FC<ForumsPageProps> = ({ onNavigate }) => {
  const [formData, setFormData] = useState<FormData>({
    name: '',
    email: '',
    category: 'general',
    title: '',
    message: '',
    tags: '',
  });

  const [discussions, setDiscussions] = useState<Discussion[]>([
    {
      id: 1,
      author: 'Alex Johnson',
      authorLevel: 'expert',
      title: 'Getting Started with IA M AI - Best Practices & Performance Optimization Tips',
      content: 'Hi everyone! I just completed my first week with IA M AI and I\'m incredibly impressed with the capabilities. I\'d love to share some best practices I\'ve discovered for optimizing agent performance. From prompt engineering to memory management, there\'s so much we can learn together. What are your top tips for getting the most out of multiple agents?',
      timestamp: '2 hours ago',
      category: 'Getting Started',
      replies: [
        {
          id: 1,
          author: 'Sarah Chen',
          content: 'Great question! I\'ve found that initializing agents with detailed context really helps. Try passing in comprehensive system prompts customized for each agent\'s specific role and personality. This dramatically improves response quality and consistency.',
          timestamp: '1 hour ago',
          likes: 42,
          isHelpful: true,
          authorLevel: 'expert',
        },
        {
          id: 2,
          author: 'Marcus Williams',
          content: 'The memory management is crucial too. I recommend implementing proper cleanup routines between sessions to maintain performance and context accuracy.',
          timestamp: '30 minutes ago',
          likes: 18,
          isHelpful: false,
          authorLevel: 'user',
        },
        {
          id: 3,
          author: 'Dr. Emma',
          content: 'Also consider implementing rate limiting and conversation threading. These patterns have helped our team scale deployments significantly.',
          timestamp: '15 minutes ago',
          likes: 35,
          isHelpful: true,
          authorLevel: 'moderator',
        },
      ],
      views: 1342,
      likes: 154,
      solved: false,
      tags: ['best-practices', 'performance', 'optimization', 'tips'],
      pinned: true,
    },
    {
      id: 2,
      author: 'Sarah Chen',
      authorLevel: 'moderator',
      title: 'How to Integrate IA M AI with Existing CRM Workflow - Step by Step Guide for Enterprise',
      content: 'We\'re implementing IA M AI into our enterprise CRM system and need guidance on best practices for integration. Has anyone successfully integrated this with Salesforce, HubSpot, or other CRM platforms? We need to ensure data consistency and real-time synchronization. Your experiences would be invaluable for our team\'s success!',
      timestamp: '4 hours ago',
      category: 'Integration',
      replies: [
        {
          id: 3,
          author: 'DevTeam',
          content: 'We integrated with Salesforce using the REST API. The webhook system works perfectly for real-time updates. We\'ve been seeing 99.9% uptime and latency under 200ms consistently.',
          timestamp: '3 hours ago',
          likes: 78,
          isHelpful: true,
          authorLevel: 'expert',
        },
        {
          id: 4,
          author: 'Lisa Park',
          content: 'Our HubSpot integration uses custom objects and workflows. Happy to share code samples if needed. The key is proper error handling for edge cases.',
          timestamp: '2.5 hours ago',
          likes: 56,
          isHelpful: true,
          authorLevel: 'user',
        },
      ],
      views: 2367,
      likes: 189,
      solved: true,
      tags: ['integration', 'crm', 'api', 'webhook', 'enterprise'],
    },
    {
      id: 3,
      author: 'Marcus Williams',
      authorLevel: 'user',
      title: 'Amazing Results with AI Girlfriend Agent - Creative Writing & Story Development Success',
      content: 'Just wanted to share my incredible experience with the AI Girlfriend agent! The level of personalization and emotional intelligence is absolutely remarkable. I\'ve been using it for creative writing projects and the outputs are genuinely inspiring. The agent remembers context beautifully, adapts its communication style, and helps brainstorm plot ideas effectively. It\'s like having a co-author who understands your vision!',
      timestamp: '6 hours ago',
      category: 'Success Stories',
      replies: [
        {
          id: 5,
          author: 'Emma Davis',
          content: 'This is awesome! I\'ve also been impressed with the creative capabilities. Have you tried combining it with the other agents for collaborative writing projects? The results are phenomenal!',
          timestamp: '5 hours ago',
          likes: 43,
          isHelpful: false,
          authorLevel: 'user',
        },
        {
          id: 6,
          author: 'Alex Johnson',
          content: 'Great testament to our design philosophy! That\'s exactly what we were aiming for - emotionally intelligent companions that enhance creativity. Thanks for sharing your experience!',
          timestamp: '4 hours ago',
          likes: 127,
          isHelpful: false,
          authorLevel: 'expert',
        },
      ],
      views: 3203,
      likes: 524,
      solved: false,
      tags: ['success-story', 'creative-writing', 'experience', 'feature-highlight'],
      pinned: false,
    },
    {
      id: 4,
      author: 'James Thompson',
      authorLevel: 'user',
      title: 'PDF Mind Agent for Document Analysis - Feature Request for Batch Processing',
      content: 'The PDF Mind agent is incredible for document analysis, but I\'m wondering if there\'s a way to process multiple documents in batch? Currently processing them one by one is time-consuming for our research team. Would love to see batch processing capabilities in a future update!',
      timestamp: '8 hours ago',
      category: 'Feature Request',
      replies: [
        {
          id: 7,
          author: 'Product Team',
          content: 'Thanks for the feedback! Batch processing is definitely on our roadmap for Q2. We\'re working on optimizing the architecture to handle large-scale document processing efficiently.',
          timestamp: '6 hours ago',
          likes: 89,
          isHelpful: true,
          authorLevel: 'moderator',
        },
      ],
      views: 856,
      likes: 67,
      solved: false,
      tags: ['feature-request', 'pdf-mind', 'batch-processing', 'productivity'],
    },
  ]);

  const [expandedId, setExpandedId] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterCategory, setFilterCategory] = useState('all');
  const [sortBy, setSortBy] = useState<'recent' | 'popular' | 'views' | 'solved'>('recent');
  const [showForm, setShowForm] = useState(false);
  const [replyingTo, setReplyingTo] = useState<number | null>(null);
  const [replyContent, setReplyContent] = useState('');

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.name || !formData.title || !formData.message) {
      alert('Please fill in all required fields');
      return;
    }

    const newDiscussion: Discussion = {
      id: Math.max(...discussions.map(d => d.id), 0) + 1,
      author: formData.name,
      authorLevel: 'user',
      title: formData.title,
      content: formData.message,
      timestamp: 'now',
      category: formData.category,
      replies: [],
      views: 0,
      likes: 0,
      solved: false,
      tags: formData.tags.split(',').map(tag => tag.trim()).filter(tag => tag),
    };

    setDiscussions(prev => [newDiscussion, ...prev]);
    setFormData({
      name: '',
      email: '',
      category: 'general',
      title: '',
      message: '',
      tags: '',
    });
    setShowForm(false);
    alert('✓ Your discussion has been posted and is now live!');
  };

  const handleReplySubmit = (discussionId: number) => {
    if (!replyContent.trim()) return;

    setDiscussions(discussions.map(d => {
      if (d.id === discussionId) {
        return {
          ...d,
          replies: [
            ...d.replies,
            {
              id: d.replies.length + 1,
              author: 'You',
              content: replyContent,
              timestamp: 'now',
              likes: 0,
              isHelpful: false,
              authorLevel: 'user',
            }
          ]
        };
      }
      return d;
    }));

    setReplyContent('');
    setReplyingTo(null);
  };

  const filteredDiscussions = discussions
    .filter(d => {
      const matchesSearch = d.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           d.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           d.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase())) ||
                           d.author.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = filterCategory === 'all' || d.category === filterCategory;
      return matchesSearch && matchesCategory;
    })
    .sort((a, b) => {
      if (sortBy === 'recent') return new Date(b.timestamp as any).getTime() - new Date(a.timestamp as any).getTime();
      if (sortBy === 'popular') return b.likes - a.likes;
      if (sortBy === 'views') return b.views - a.views;
      if (sortBy === 'solved') return (b.solved ? 1 : 0) - (a.solved ? 1 : 0);
      return 0;
    });

  const uniqueCategories = Array.from(new Set(discussions.map(d => d.category)));
  const totalStats = {
    discussions: discussions.length,
    replies: discussions.reduce((sum, d) => sum + d.replies.length, 0),
    views: discussions.reduce((sum, d) => sum + d.views, 0),
    likes: discussions.reduce((sum, d) => sum + d.likes, 0),
  };

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Hero Section */}
      <section className="py-16 md:py-24 bg-gradient-to-b from-cyan-500/10 via-blue-500/5 to-transparent">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-6 gap-4">
            <div className="flex-1">
              <h1 className="text-3xl md:text-4xl lg:text-5xl font-extrabold tracking-tight mb-3">Community Forums</h1>
              <p className="max-w-3xl text-base md:text-lg text-gray-300">
                Live community discussions, real-time support, and shared knowledge. Join {discussions.length}+ active discussions with hundreds of contributors.
              </p>
            </div>
            <button
              onClick={() => setShowForm(!showForm)}
              className="w-full md:w-auto bg-cyan-500 hover:bg-cyan-600 text-black font-semibold px-6 py-3 rounded-lg transition-colors flex items-center justify-center gap-2 flex-shrink-0"
            >
              <MessageSquare className="w-5 h-5" />
              New Discussion
            </button>
          </div>
          
          {/* Search and Filters */}
          <div className="flex flex-col gap-4">
            <div className="flex items-center gap-2 bg-gray-900/50 border border-gray-800 rounded-lg px-3 md:px-4 py-2 hover:border-gray-700 transition-colors">
              <Search className="w-4 h-4 md:w-5 md:h-5 text-gray-400 flex-shrink-0" />
              <input
                type="text"
                placeholder="Search discussions by title, content, tags, or author..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex-1 bg-transparent text-white text-sm md:text-base focus:outline-none placeholder-gray-500"
              />
            </div>
            
            <div className="flex flex-col sm:flex-row gap-3">
              <select
                value={filterCategory}
                onChange={(e) => setFilterCategory(e.target.value)}
                className="w-full sm:w-auto bg-gray-900/50 border border-gray-800 rounded-lg px-4 py-2 text-sm md:text-base text-white focus:outline-none focus:border-cyan-500 transition-colors"
              >
                <option value="all">All Categories</option>
                {uniqueCategories.map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>

              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="w-full sm:w-auto bg-gray-900/50 border border-gray-800 rounded-lg px-4 py-2 text-sm md:text-base text-white focus:outline-none focus:border-cyan-500 transition-colors"
              >
                <option value="recent">Most Recent</option>
                <option value="popular">Most Popular</option>
                <option value="views">Most Viewed</option>
                <option value="solved">Solved First</option>
              </select>
            </div>
          </div>
        </div>
      </section>

      {/* New Discussion Form */}
      {showForm && (
        <section className="bg-gray-900/50 border-b border-gray-800 py-8">
          <div className="container mx-auto px-4 md:px-6 max-w-2xl">
            <h2 className="text-xl md:text-2xl font-bold text-white mb-6">Start a New Discussion</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-gray-300 mb-2">Name *</label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    placeholder="Your name"
                    className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-cyan-500 transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-300 mb-2">Email *</label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    placeholder="your@email.com"
                    className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-cyan-500 transition-colors"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-300 mb-2">Category *</label>
                <select
                  name="category"
                  value={formData.category}
                  onChange={handleInputChange}
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-cyan-500 transition-colors"
                >
                  <option value="general">General Discussion</option>
                  <option value="getting-started">Getting Started</option>
                  <option value="integration">Integration</option>
                  <option value="success-stories">Success Stories</option>
                  <option value="feature-request">Feature Request</option>
                  <option value="bug-report">Bug Report</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-300 mb-2">Title *</label>
                <input
                  type="text"
                  name="title"
                  value={formData.title}
                  onChange={handleInputChange}
                  placeholder="What's your discussion about?"
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-cyan-500 transition-colors"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-300 mb-2">Message *</label>
                <textarea
                  name="message"
                  value={formData.message}
                  onChange={handleInputChange}
                  placeholder="Share your thoughts, questions, or experiences... Be detailed and descriptive!"
                  rows={6}
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-cyan-500 transition-colors resize-none"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-300 mb-2">Tags (comma-separated)</label>
                <input
                  type="text"
                  name="tags"
                  value={formData.tags}
                  onChange={handleInputChange}
                  placeholder="e.g., tips, help, feedback, integration"
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-cyan-500 transition-colors"
                />
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <button
                  type="submit"
                  className="flex-1 bg-cyan-500 hover:bg-cyan-600 text-black font-semibold py-2.5 md:py-2 rounded-lg transition-colors flex items-center justify-center gap-2"
                >
                  <Send className="w-4 h-4" />
                  Post Discussion
                </button>
                <button
                  type="button"
                  onClick={() => setShowForm(false)}
                  className="flex-1 bg-gray-800 hover:bg-gray-700 text-white font-semibold py-2.5 md:py-2 rounded-lg transition-colors"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </section>
      )}

      {/* Discussions List */}
      <section className="py-12 bg-[#0a0a0a]">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl md:text-2xl font-bold text-white">
              {filteredDiscussions.length} Discussion{filteredDiscussions.length !== 1 ? 's' : ''} Found
            </h2>
          </div>

          {filteredDiscussions.length === 0 ? (
            <div className="text-center py-12 bg-gray-900/20 border border-gray-800 rounded-lg">
              <MessageSquare className="w-12 h-12 text-gray-500 mx-auto mb-4" />
              <p className="text-gray-400 text-lg mb-4">No discussions found matching your search.</p>
              <button
                onClick={() => setShowForm(true)}
                className="bg-cyan-500 hover:bg-cyan-600 text-black font-semibold px-6 py-2 rounded-lg transition-colors"
              >
                Start a New Discussion
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredDiscussions.map(discussion => (
                <div key={discussion.id}>
                  <DiscussionCard
                    discussion={discussion}
                    isExpanded={expandedId === discussion.id}
                    onExpand={() => setExpandedId(expandedId === discussion.id ? null : discussion.id)}
                  />
                  
                  {/* Expanded Discussion View */}
                  {expandedId === discussion.id && (
                    <div className="bg-gray-900/40 border border-gray-800 border-t-0 rounded-b-lg p-6">
                      <div className="mb-6">
                        <h2 className="text-2xl font-bold text-white mb-3">{discussion.title}</h2>
                        <p className="text-gray-300 leading-relaxed mb-4">{discussion.content}</p>
                        <div className="flex flex-wrap gap-2">
                          {discussion.tags.map((tag, idx) => (
                            <span key={idx} className="text-xs bg-cyan-500/20 text-cyan-400 px-3 py-1 rounded-full">
                              #{tag}
                            </span>
                          ))}
                        </div>
                      </div>

                      <div className="border-t border-gray-800 pt-6">
                        <div className="flex items-center justify-between mb-6">
                          <h3 className="text-xl font-bold text-white">
                            {discussion.replies.length} Replies
                          </h3>
                          <span className="text-sm text-gray-400">
                            {discussion.views} views • {discussion.likes} likes
                          </span>
                        </div>
                        
                        <div className="space-y-4 mb-6">
                          {discussion.replies.map((reply, idx) => (
                            <ReplyCard
                              key={reply.id}
                              reply={reply}
                              onLike={() => {
                                setDiscussions(discussions.map(d =>
                                  d.id === discussion.id
                                    ? {
                                        ...d,
                                        replies: d.replies.map(r =>
                                          r.id === reply.id ? { ...r, likes: r.likes + 1 } : r
                                        )
                                      }
                                    : d
                                ));
                              }}
                              isOwn={reply.author === 'You'}
                              onDelete={() => {
                                setDiscussions(discussions.map(d =>
                                  d.id === discussion.id
                                    ? { ...d, replies: d.replies.filter(r => r.id !== reply.id) }
                                    : d
                                ));
                              }}
                            />
                          ))}
                        </div>

                        {/* Reply Form */}
                        <div className="mt-6 p-4 bg-gray-800/30 border border-gray-700 rounded-lg">
                          <textarea
                            value={replyingTo === discussion.id ? replyContent : ''}
                            onChange={(e) => {
                              setReplyingTo(discussion.id);
                              setReplyContent(e.target.value);
                            }}
                            onFocus={() => setReplyingTo(discussion.id)}
                            placeholder="Write a reply... Share your thoughts and help the community!"
                            rows={3}
                            className="w-full bg-gray-800 border border-gray-700 rounded px-4 py-2 text-white focus:outline-none focus:border-cyan-500 placeholder-gray-500 resize-none"
                          />
                          <div className="flex gap-2 mt-3">
                            <button
                              onClick={() => handleReplySubmit(discussion.id)}
                              disabled={!replyContent.trim()}
                              className="flex items-center gap-2 bg-cyan-500 hover:bg-cyan-600 disabled:bg-gray-700 disabled:cursor-not-allowed text-black font-semibold px-4 py-2 rounded transition-colors"
                            >
                              <Send className="w-4 h-4" />
                              Post Reply
                            </button>
                            <button
                              onClick={() => setReplyingTo(null)}
                              className="bg-gray-800 hover:bg-gray-700 text-white font-semibold px-4 py-2 rounded transition-colors"
                            >
                              Cancel
                            </button>
                          </div>
                        </div>
                      </div>

                      <button
                        onClick={() => setExpandedId(null)}
                        className="mt-6 text-cyan-400 hover:text-cyan-300 font-semibold transition-colors flex items-center gap-2"
                      >
                        ▲ Collapse Discussion
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Community Stats */}
      <section className="py-12 bg-black border-t border-gray-800">
        <div className="container mx-auto px-6">
          <h2 className="text-2xl font-bold text-white mb-8 text-center">Community Stats</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[
              { icon: 'fa-solid fa-comments', label: 'Active Discussions', value: totalStats.discussions },
              { icon: 'fa-solid fa-reply', label: 'Total Replies', value: totalStats.replies },
              { icon: 'fa-solid fa-eye', label: 'Total Views', value: totalStats.views.toLocaleString() },
              { icon: 'fa-solid fa-heart', label: 'Total Likes', value: totalStats.likes },
            ].map((stat, idx) => (
              <div key={idx} className="text-center p-6 bg-gray-900/30 border border-gray-800 rounded-lg hover:border-cyan-500/30 transition-colors">
                <div className="text-4xl text-cyan-400 mb-3">
                  <i className={stat.icon}></i>
                </div>
                <p className="text-3xl font-bold text-white">{stat.value}</p>
                <p className="text-gray-400 text-sm mt-2">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Community Guidelines */}
      <section className="py-12 bg-gray-900/20 border-y border-gray-800">
        <div className="container mx-auto px-6">
          <h2 className="text-2xl font-bold text-white mb-8 text-center">Community Guidelines</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                icon: 'fa-solid fa-handshake',
                title: 'Be Respectful',
                description: 'Treat others with kindness and respect. We\'re all here to learn and grow together. Constructive criticism is welcome, but personal attacks are not.'
              },
              {
                icon: 'fa-solid fa-lightbulb',
                title: 'Share Knowledge',
                description: 'Help others by sharing your experiences, solutions, and insights. Your knowledge can help someone else solve a problem faster.'
              },
              {
                icon: 'fa-solid fa-shield-halved',
                title: 'Keep It Safe',
                description: 'Never share sensitive information, API keys, passwords, or personal data in public discussions. Use private messages when needed.'
              },
            ].map((guideline, idx) => (
              <div key={idx} className="bg-gray-900/50 border border-gray-800 rounded-lg p-6 text-center hover:border-cyan-500/30 transition-colors">
                <div className="text-4xl text-cyan-400 mb-4">
                  <i className={guideline.icon}></i>
                </div>
                <h3 className="text-lg font-bold text-white mb-2">{guideline.title}</h3>
                <p className="text-gray-400 text-sm leading-relaxed">{guideline.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Back to Community */}
      <section className="py-8 text-center border-t border-gray-800">
        <button
          onClick={() => onNavigate('community')}
          className="text-cyan-400 hover:text-cyan-300 font-semibold transition-colors flex items-center justify-center gap-2"
        >
          ← Back to Community Hub
        </button>
      </section>
    </div>
  );
};

export default ForumsPage;