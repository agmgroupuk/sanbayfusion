import React, { useState, useEffect } from 'react';
import {
  Camera,
  Download,
  Copy,
  Image as ImageIcon,
  Settings,
  Clock,
  Monitor,
  Smartphone,
  Tablet,
  AlertCircle,
  Info,
  RefreshCw,
  Check,
  X,
  Maximize,
  FileText,
  Share2,
} from 'lucide-react';

interface ScreenshotResult {
  id: string;
  url: string;
  screenshotUrl: string;
  timestamp: number;
  device: string;
  dimensions: string;
  fileSize: string;
  format: string;
}

interface ScreenshotHistory {
  id: string;
  url: string;
  timestamp: number;
  success: boolean;
  device: string;
}

const ScreenshotAPIPage: React.FC = () => {
  const [targetUrl, setTargetUrl] = useState('');
  const [isCapturing, setIsCapturing] = useState(false);
  const [result, setResult] = useState<ScreenshotResult | null>(null);
  const [history, setHistory] = useState<ScreenshotHistory[]>([]);
  const [showHistory, setShowHistory] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Screenshot configuration
  const [config, setConfig] = useState({
    device: 'desktop',
    width: 1920,
    height: 1080,
    fullPage: false,
    format: 'png',
    quality: 90,
    delay: 0,
  });

  const [stats, setStats] = useState({
    totalScreenshots: 0,
    successRate: 100,
    avgCaptureTime: 0,
    storageUsed: 0,
  });

  const API_KEY = 'at_0bL20Im9wnArHgXBuN8OGFnE0XO4U';

  // Load history from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('screenshot_history');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setHistory(parsed);
        setStats(prev => ({ ...prev, totalScreenshots: parsed.length }));
      } catch (e) {
        console.error('Failed to load history:', e);
      }
    }
  }, []);

  // Save history to localStorage
  useEffect(() => {
    if (history.length > 0) {
      localStorage.setItem('screenshot_history', JSON.stringify(history.slice(0, 50)));
    }
  }, [history]);

  // Device presets
  const devicePresets = {
    desktop: { width: 1920, height: 1080, name: 'Desktop (Full HD)' },
    laptop: { width: 1366, height: 768, name: 'Laptop (HD)' },
    tablet: { width: 768, height: 1024, name: 'Tablet (iPad)' },
    mobile: { width: 375, height: 667, name: 'Mobile (iPhone)' },
    custom: { width: config.width, height: config.height, name: 'Custom' },
  };

  const handleDeviceChange = (device: string) => {
    const preset = devicePresets[device as keyof typeof devicePresets];
    if (preset) {
      setConfig(prev => ({
        ...prev,
        device,
        width: preset.width,
        height: preset.height,
      }));
    }
  };

  const handleCapture = async () => {
    if (!targetUrl.trim()) {
      setError('Please enter a URL');
      return;
    }

    // Validate URL
    try {
      new URL(targetUrl.startsWith('http') ? targetUrl : `https://${targetUrl}`);
    } catch {
      setError('Please enter a valid URL');
      return;
    }

    setIsCapturing(true);
    setError(null);
    setResult(null);

    try {
      const cleanUrl = targetUrl.startsWith('http') ? targetUrl : `https://${targetUrl}`;

      // WhoisXML API - Screenshot API
      const apiUrl = new URL('https://website-screenshot.whoisxmlapi.com/api/v1');
      apiUrl.searchParams.append('apiKey', API_KEY);
      apiUrl.searchParams.append('url', cleanUrl);
      apiUrl.searchParams.append('credits', 'DRS');
      apiUrl.searchParams.append('mode', config.fullPage ? 'full' : 'viewport');
      apiUrl.searchParams.append('width', config.width.toString());
      apiUrl.searchParams.append('height', config.height.toString());
      apiUrl.searchParams.append('format', config.format);
      apiUrl.searchParams.append('quality', config.quality.toString());

      if (config.delay > 0) {
        apiUrl.searchParams.append('delay', config.delay.toString());
      }

      const response = await fetch(apiUrl.toString(), {
        method: 'GET',
      });

      if (!response.ok) {
        throw new Error(`API Error: ${response.status} - ${response.statusText}`);
      }

      // Get the screenshot image data
      const blob = await response.blob();
      const screenshotUrl = URL.createObjectURL(blob);

      const screenshotResult: ScreenshotResult = {
        id: Date.now().toString(),
        url: cleanUrl,
        screenshotUrl: screenshotUrl,
        timestamp: Date.now(),
        device: config.device,
        dimensions: `${config.width}x${config.height}`,
        fileSize: `${(blob.size / 1024).toFixed(2)} KB`,
        format: config.format.toUpperCase(),
      };

      setResult(screenshotResult);

      // Add to history
      const historyItem: ScreenshotHistory = {
        id: Date.now().toString(),
        url: cleanUrl,
        timestamp: Date.now(),
        success: true,
        device: config.device,
      };
      setHistory(prev => [historyItem, ...prev]);
      setStats(prev => ({
        ...prev,
        totalScreenshots: prev.totalScreenshots + 1,
        storageUsed: prev.storageUsed + blob.size,
      }));
    } catch (err: any) {
      console.error('Screenshot capture error:', err);
      setError(err.message || 'Failed to capture screenshot. Please check the URL and try again.');

      const historyItem: ScreenshotHistory = {
        id: Date.now().toString(),
        url: targetUrl,
        timestamp: Date.now(),
        success: false,
        device: config.device,
      };
      setHistory(prev => [historyItem, ...prev]);
    } finally {
      setIsCapturing(false);
    }
  };

  const handleDownload = () => {
    if (!result) return;

    const link = document.createElement('a');
    link.href = result.screenshotUrl;
    link.download = `screenshot-${new URL(result.url).hostname}-${Date.now()}.${config.format}`;
    link.click();
  };

  const handleCopy = () => {
    if (!result) return;

    fetch(result.screenshotUrl)
      .then(res => res.blob())
      .then(blob => {
        const item = new ClipboardItem({ 'image/png': blob });
        navigator.clipboard.write([item]);
      })
      .catch(err => console.error('Failed to copy:', err));
  };

  const handleShare = async () => {
    if (!result) return;

    if (navigator.share) {
      try {
        const blob = await fetch(result.screenshotUrl).then(r => r.blob());
        const file = new File([blob], `screenshot.${config.format}`, {
          type: `image/${config.format}`,
        });

        await navigator.share({
          title: 'Screenshot',
          text: `Screenshot of ${result.url}`,
          files: [file],
        });
      } catch (err) {
        console.error('Share failed:', err);
      }
    }
  };

  const handleClearHistory = () => {
    if (confirm('Clear all screenshot history?')) {
      setHistory([]);
      localStorage.removeItem('screenshot_history');
      setStats(prev => ({ ...prev, totalScreenshots: 0, storageUsed: 0 }));
    }
  };

  return (
    <div className="min-h-screen bg-black text-white py-8 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <Camera className="w-8 h-8 text-cyan-400" />
            <h1 className="text-4xl font-bold bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
              Website Screenshot Tool
            </h1>
          </div>
          <p className="text-gray-400 text-lg">
            Capture high-quality screenshots of any website with custom dimensions and device
            presets
          </p>
        </div>

        {/* Stats Dashboard */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border border-cyan-500/30 rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-400">Total Screenshots</span>
              <Camera className="w-4 h-4 text-cyan-400" />
            </div>
            <p className="text-2xl font-bold text-white">{stats?.totalScreenshots || 0}</p>
          </div>
          <div className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border border-purple-500/30 rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-400">Success Rate</span>
              <Check className="w-4 h-4 text-purple-400" />
            </div>
            <p className="text-2xl font-bold text-white">{stats?.successRate || 0}%</p>
          </div>
          <div className="bg-gradient-to-br from-green-500/10 to-emerald-500/10 border border-green-500/30 rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-400">Avg Capture Time</span>
              <Clock className="w-4 h-4 text-green-400" />
            </div>
            <p className="text-2xl font-bold text-white">{stats?.avgCaptureTime || 0}s</p>
          </div>
          <div className="bg-gradient-to-br from-yellow-500/10 to-orange-500/10 border border-yellow-500/30 rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-400">Storage Used</span>
              <ImageIcon className="w-4 h-4 text-yellow-400" />
            </div>
            <p className="text-2xl font-bold text-white">
              {(stats.storageUsed / 1024 / 1024).toFixed(2)} MB
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Configuration Panel */}
          <div className="lg:col-span-1">
            <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6 sticky top-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <Settings className="w-5 h-5 text-cyan-400" />
                  Configuration
                </h3>
                <button
                  onClick={() => setShowHistory(!showHistory)}
                  className={`p-2 rounded-lg transition-colors ${
                    showHistory ? 'bg-cyan-600 text-white' : 'bg-gray-800 text-gray-400'
                  }`}
                >
                  <Clock className="w-4 h-4" />
                </button>
              </div>

              {!showHistory ? (
                <div className="space-y-4">
                  {/* Device Preset */}
                  <div>
                    <label className="block text-sm font-semibold text-gray-300 mb-2">
                      Device Preset
                    </label>
                    <div className="grid grid-cols-2 gap-2">
                      {Object.entries(devicePresets).map(([key, preset]) => (
                        <button
                          key={key}
                          onClick={() => handleDeviceChange(key)}
                          className={`p-3 rounded-lg border transition-all ${
                            config.device === key
                              ? 'bg-cyan-600 border-cyan-600 text-white'
                              : 'bg-gray-800 border-gray-700 text-gray-400 hover:border-cyan-500/50'
                          }`}
                        >
                          {key === 'desktop' && <Monitor className="w-5 h-5 mx-auto mb-1" />}
                          {key === 'laptop' && <Monitor className="w-5 h-5 mx-auto mb-1" />}
                          {key === 'tablet' && <Tablet className="w-5 h-5 mx-auto mb-1" />}
                          {key === 'mobile' && <Smartphone className="w-5 h-5 mx-auto mb-1" />}
                          {key === 'custom' && <Settings className="w-5 h-5 mx-auto mb-1" />}
                          <span className="text-xs">
                            {key.charAt(0).toUpperCase() + key.slice(1)}
                          </span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Dimensions */}
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-semibold text-gray-300 mb-2">
                        Width (px)
                      </label>
                      <input
                        type="number"
                        value={config.width}
                        onChange={e =>
                          setConfig(prev => ({ ...prev, width: parseInt(e.target.value) || 0 }))
                        }
                        className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white focus:border-cyan-500 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-gray-300 mb-2">
                        Height (px)
                      </label>
                      <input
                        type="number"
                        value={config.height}
                        onChange={e =>
                          setConfig(prev => ({ ...prev, height: parseInt(e.target.value) || 0 }))
                        }
                        className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white focus:border-cyan-500 focus:outline-none"
                      />
                    </div>
                  </div>

                  {/* Format */}
                  <div>
                    <label className="block text-sm font-semibold text-gray-300 mb-2">Format</label>
                    <select
                      value={config.format}
                      onChange={e => setConfig(prev => ({ ...prev, format: e.target.value }))}
                      className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white focus:border-cyan-500 focus:outline-none"
                    >
                      <option value="png">PNG</option>
                      <option value="jpg">JPEG</option>
                      <option value="webp">WebP</option>
                    </select>
                  </div>

                  {/* Quality */}
                  <div>
                    <label className="block text-sm font-semibold text-gray-300 mb-2">
                      Quality: {config.quality}%
                    </label>
                    <input
                      type="range"
                      min="1"
                      max="100"
                      value={config.quality}
                      onChange={e =>
                        setConfig(prev => ({ ...prev, quality: parseInt(e.target.value) }))
                      }
                      className="w-full"
                    />
                  </div>

                  {/* Delay */}
                  <div>
                    <label className="block text-sm font-semibold text-gray-300 mb-2">
                      Delay (seconds)
                    </label>
                    <input
                      type="number"
                      value={config.delay}
                      onChange={e =>
                        setConfig(prev => ({ ...prev, delay: parseInt(e.target.value) || 0 }))
                      }
                      min="0"
                      max="30"
                      className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white focus:border-cyan-500 focus:outline-none"
                    />
                  </div>

                  {/* Full Page */}
                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={config.fullPage}
                      onChange={e => setConfig(prev => ({ ...prev, fullPage: e.target.checked }))}
                      className="w-4 h-4 rounded"
                    />
                    <label className="text-sm text-gray-300">Capture full page</label>
                  </div>
                </div>
              ) : (
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-sm text-gray-400">{history.length} screenshots</span>
                    <button
                      onClick={handleClearHistory}
                      className="p-1.5 rounded-lg bg-gray-800 text-gray-400 hover:text-red-400 transition-colors"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="space-y-2 max-h-[600px] overflow-y-auto">
                    {history.map(item => (
                      <button
                        key={item.id}
                        onClick={() => {
                          setTargetUrl(item.url);
                          setShowHistory(false);
                        }}
                        className="w-full text-left p-3 rounded-lg bg-gray-800/50 border border-gray-700 hover:border-cyan-500/30 transition-all"
                      >
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-white text-sm font-medium truncate">
                            {item.url}
                          </span>
                          {item.success ? (
                            <Check className="w-4 h-4 text-green-400 flex-shrink-0" />
                          ) : (
                            <X className="w-4 h-4 text-red-400 flex-shrink-0" />
                          )}
                        </div>
                        <div className="flex items-center gap-2 text-xs text-gray-400">
                          <span>{new Date(item.timestamp).toLocaleString()}</span>
                          <span>•</span>
                          <span>{item.device}</span>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-2">
            {/* URL Input */}
            <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6 mb-6">
              <label className="block text-sm font-semibold text-gray-300 mb-2">Website URL</label>
              <div className="flex flex-col sm:flex-row gap-2">
                <input
                  type="text"
                  value={targetUrl}
                  onChange={e => setTargetUrl(e.target.value)}
                  onKeyPress={e => e.key === 'Enter' && handleCapture()}
                  placeholder="https://example.com"
                  className="flex-1 bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:border-cyan-500 focus:outline-none"
                />
                <button
                  onClick={handleCapture}
                  disabled={isCapturing}
                  className="bg-gradient-to-r from-cyan-600 to-purple-600 hover:from-cyan-700 hover:to-purple-700 disabled:from-gray-700 disabled:to-gray-700 text-white font-semibold px-6 py-3 rounded-lg transition-all flex items-center justify-center gap-2 w-full sm:w-auto"
                >
                  {isCapturing ? (
                    <>
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                      Capturing...
                    </>
                  ) : (
                    <>
                      <Camera className="w-5 h-5" />
                      Capture
                    </>
                  )}
                </button>
              </div>

              {error && (
                <div className="mt-4 bg-red-500/10 border border-red-500/30 rounded-lg p-4 flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
                  <p className="text-red-300">{error}</p>
                </div>
              )}
            </div>

            {/* Screenshot Result */}
            {result && (
              <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-bold text-white">Screenshot Preview</h3>
                  <div className="flex gap-2">
                    <button
                      onClick={handleDownload}
                      className="p-2 bg-gray-800 hover:bg-gray-700 rounded-lg transition-colors"
                      title="Download"
                    >
                      <Download className="w-4 h-4 text-gray-300" />
                    </button>
                    <button
                      onClick={handleCopy}
                      className="p-2 bg-gray-800 hover:bg-gray-700 rounded-lg transition-colors"
                      title="Copy to clipboard"
                    >
                      <Copy className="w-4 h-4 text-gray-300" />
                    </button>
                    {navigator.share && (
                      <button
                        onClick={handleShare}
                        className="p-2 bg-gray-800 hover:bg-gray-700 rounded-lg transition-colors"
                        title="Share"
                      >
                        <Share2 className="w-4 h-4 text-gray-300" />
                      </button>
                    )}
                  </div>
                </div>

                {/* Screenshot Info */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                  <div>
                    <label className="text-xs text-gray-400">Device</label>
                    <p className="text-sm text-white font-semibold">{result.device}</p>
                  </div>
                  <div>
                    <label className="text-xs text-gray-400">Dimensions</label>
                    <p className="text-sm text-white font-semibold">{result.dimensions}</p>
                  </div>
                  <div>
                    <label className="text-xs text-gray-400">File Size</label>
                    <p className="text-sm text-white font-semibold">{result.fileSize}</p>
                  </div>
                  <div>
                    <label className="text-xs text-gray-400">Format</label>
                    <p className="text-sm text-white font-semibold">{result.format}</p>
                  </div>
                </div>

                {/* Screenshot Image */}
                <div className="border border-gray-700 rounded-lg overflow-hidden bg-gray-800">
                  <img
                    src={result.screenshotUrl}
                    alt={`Screenshot of ${result.url}`}
                    className="w-full h-auto"
                  />
                </div>

                <div className="mt-4 text-sm text-gray-400">
                  <p className="break-all">URL: {result.url}</p>
                  <p>Captured: {new Date(result.timestamp).toLocaleString()}</p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Platform Branding */}
        <div className="mt-8 bg-gradient-to-r from-cyan-500/10 to-purple-500/10 border border-cyan-500/30 rounded-lg p-4">
          <div className="flex items-start gap-3">
            <Info className="w-5 h-5 text-cyan-400 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm text-cyan-300 font-semibold mb-1">
                🚀 Powered by IA M AI Global Platform
              </p>
              <p className="text-xs text-cyan-300/80">
                Professional screenshot capture tool with custom dimensions, device presets, and
                configurable quality settings. Perfect for web monitoring, archiving, and visual
                regression testing.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ScreenshotAPIPage;
