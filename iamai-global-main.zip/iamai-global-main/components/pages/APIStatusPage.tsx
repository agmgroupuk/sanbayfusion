import React, { useState, useEffect } from 'react';
import { CheckCircle, XCircle, AlertTriangle, Server, Bot, Clock, RefreshCw, ArrowLeft, Zap, Database, Globe, Activity, TrendingUp } from 'lucide-react';
import { getSocket } from '../../services/socket';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts';

type Status = 'Operational' | 'Degraded' | 'Down';

interface APIStatus {
  name: string;
  status: Status;
  responseTime: number;
}

interface AgentStatus {
  name: string;
  status: 'Online' | 'Offline' | 'Busy';
  activeTasks: number;
}

const StatusIndicator: React.FC<{ status: Status | AgentStatus['status'] }> = ({ status }) => {
  const statusConfig = {
    Operational: { icon: <CheckCircle className="text-green-400" />, text: 'text-green-400' },
    Online: { icon: <CheckCircle className="text-green-400" />, text: 'text-green-400' },
    Degraded: { icon: <AlertTriangle className="text-yellow-400" />, text: 'text-yellow-400' },
    Busy: { icon: <AlertTriangle className="text-yellow-400" />, text: 'text-yellow-400' },
    Down: { icon: <XCircle className="text-red-400" />, text: 'text-red-400' },
    Offline: { icon: <XCircle className="text-red-400" />, text: 'text-red-400' },
  };

  const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.Down;

  return (
    <div className="flex items-center space-x-2">
      {config.icon}
      <span className={config.text}>{status}</span>
    </div>
  );
};

interface APIStatusPageProps {
    onNavigate?: (page: string) => void;
}

const APIStatusPage: React.FC<APIStatusPageProps> = ({ onNavigate }) => {
  const [apiStatuses, setApiStatuses] = useState<APIStatus[]>([
    { name: 'OpenAI API', status: 'Operational', responseTime: 145 },
    { name: 'Anthropic Claude', status: 'Operational', responseTime: 198 },
    { name: 'Google Gemini', status: 'Operational', responseTime: 167 },
    { name: 'RunwayML API', status: 'Operational', responseTime: 234 },
    { name: 'Stability AI', status: 'Operational', responseTime: 189 },
    { name: 'Replicate API', status: 'Operational', responseTime: 276 },
    { name: 'HuggingFace API', status: 'Operational', responseTime: 156 },
    { name: 'PostgreSQL Database', status: 'Operational', responseTime: 12 },
    { name: 'MongoDB', status: 'Operational', responseTime: 18 },
    { name: 'Redis Cache', status: 'Operational', responseTime: 3 },
    { name: 'Authentication Service', status: 'Operational', responseTime: 45 },
    { name: 'Email Service (SMTP)', status: 'Operational', responseTime: 89 },
    { name: 'Stripe Payment Gateway', status: 'Operational', responseTime: 134 },
    { name: 'PayPal Payment API', status: 'Operational', responseTime: 178 },
    { name: 'AWS S3 Storage', status: 'Operational', responseTime: 98 },
    { name: 'WebSocket Server', status: 'Operational', responseTime: 8 },
    { name: 'IPInfo API', status: 'Operational', responseTime: 67 },
    { name: 'MaxMind GeoIP', status: 'Operational', responseTime: 54 },
  ]);
  
  const [agentStatuses, setAgentStatuses] = useState<AgentStatus[]>([
    { name: 'AI Girlfriend Pro', status: 'Online', activeTasks: 23 },
    { name: 'EmoAI', status: 'Online', activeTasks: 18 },
    { name: 'PDFMind', status: 'Online', activeTasks: 31 },
    { name: 'CVSmash', status: 'Online', activeTasks: 15 },
    { name: 'ChatRevive', status: 'Online', activeTasks: 27 },
    { name: 'TokBoost', status: 'Online', activeTasks: 19 },
    { name: 'YouGen', status: 'Online', activeTasks: 22 },
    { name: 'AgentX', status: 'Online', activeTasks: 34 },
    { name: 'AutoChat', status: 'Online', activeTasks: 16 },
    { name: 'Comedy Chad', status: 'Online', activeTasks: 12 },
    { name: 'Lazy Larry', status: 'Online', activeTasks: 8 },
    { name: 'Flirty Fiona', status: 'Online', activeTasks: 25 },
    { name: 'Sassy Sarah', status: 'Online', activeTasks: 29 },
    { name: 'Nerdy Neil', status: 'Online', activeTasks: 20 },
    { name: 'Cool Kyle', status: 'Online', activeTasks: 18 },
    { name: 'Zen Master Zara', status: 'Online', activeTasks: 14 },
    { name: 'Gamer Gary', status: 'Busy', activeTasks: 45 },
  ]);
  
  const [lastUpdated, setLastUpdated] = useState(new Date());

  useEffect(() => {
    try {
      const socket = getSocket();

      const handleStatusUpdate = (data: { apis: APIStatus[], agents: AgentStatus[] }) => {
        setApiStatuses(data.apis || apiStatuses);
        setAgentStatuses(data.agents || agentStatuses);
        setLastUpdated(new Date());
      };

      socket.on('api-status:update', handleStatusUpdate);

      const fetchStatus = () => socket.emit('api-status:get');
      fetchStatus();
      const interval = setInterval(fetchStatus, 30000); // Refresh every 30 seconds

      return () => {
        clearInterval(interval);
        socket.off('api-status:update', handleStatusUpdate);
      };
    } catch (error) {
      console.error('WebSocket connection failed, using mock data:', error);
    }
  }, []);

  // Calculate statistics
  const operationalAPIs = apiStatuses.filter(api => api.status === 'Operational').length;
  const totalAPIs = apiStatuses.length;
  const avgResponseTime = Math.round(apiStatuses.reduce((sum, api) => sum + api.responseTime, 0) / apiStatuses.length);
  const onlineAgents = agentStatuses.filter(agent => agent.status === 'Online' || agent.status === 'Busy').length;
  const totalAgents = agentStatuses.length;
  const totalActiveTasks = agentStatuses.reduce((sum, agent) => sum + agent.activeTasks, 0);

  // Categorize APIs
  const aiProviderAPIs = apiStatuses.filter(api => 
    api.name.includes('OpenAI') || api.name.includes('Claude') || api.name.includes('Gemini') || 
    api.name.includes('RunwayML') || api.name.includes('Stability') || api.name.includes('Replicate') || 
    api.name.includes('HuggingFace')
  );
  const infrastructureAPIs = apiStatuses.filter(api => 
    api.name.includes('Database') || api.name.includes('MongoDB') || api.name.includes('Redis') || 
    api.name.includes('WebSocket') || api.name.includes('Storage')
  );
  const servicesAPIs = apiStatuses.filter(api => 
    api.name.includes('Authentication') || api.name.includes('Email') || api.name.includes('Payment') || 
    api.name.includes('IPInfo') || api.name.includes('MaxMind')
  );

  // Response time data for chart
  const responseTimeData = apiStatuses.slice(0, 10).map(api => ({
    name: api.name.split(' ')[0],
    time: api.responseTime,
  }));

  // Agent task distribution
  const agentTaskData = agentStatuses.map(agent => ({
    name: agent.name,
    tasks: agent.activeTasks,
  }));

  // Status distribution pie chart
  const statusDistribution = [
    { name: 'Operational', value: apiStatuses.filter(a => a.status === 'Operational').length, color: '#10b981' },
    { name: 'Degraded', value: apiStatuses.filter(a => a.status === 'Degraded').length, color: '#f59e0b' },
    { name: 'Down', value: apiStatuses.filter(a => a.status === 'Down').length, color: '#ef4444' },
  ].filter(item => item.value > 0);

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Hero Section */}
      <section className="relative overflow-hidden border-b border-gray-800">
        <div className="absolute inset-0 bg-grid-gray-900 [mask-image:linear-gradient(to_bottom,white_30%,transparent)]"></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-to-r from-cyan-500/10 to-blue-500/10 rounded-full blur-3xl"></div>
        
        <div className="container mx-auto px-6 py-12 md:py-16 relative z-10">
          <div className="flex items-center justify-between mb-6">
            <button 
              onClick={() => onNavigate && onNavigate('status')}
              className="flex items-center text-gray-400 hover:text-cyan-400 transition-colors group"
            >
              <ArrowLeft className="w-5 h-5 mr-2 group-hover:-translate-x-1 transition-transform" />
              <span className="text-sm font-medium">Back to Status</span>
            </button>
            <div className="flex items-center space-x-2 bg-gray-900/50 backdrop-blur-sm px-4 py-2 rounded-lg border border-cyan-500/30">
              <RefreshCw className="w-4 h-4 text-cyan-400 animate-spin" />
              <span className="text-sm text-gray-400">Auto-refresh: 30s</span>
            </div>
          </div>

          <div className="text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 via-blue-400 to-purple-400">
              API Status Monitor
            </h1>
            <p className="text-gray-400 text-base md:text-lg max-w-2xl mx-auto">Live status of all APIs, services, and AI agents across the platform</p>
          </div>
        </div>
      </section>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        <div className="max-w-7xl mx-auto">
        {/* Last Updated Info */}
        <div className="flex items-center justify-center space-x-2 text-gray-500 text-sm mb-8">
          <Clock className="w-4 h-4" />
          <span>Last updated: {lastUpdated.toLocaleTimeString()}</span>
          </div>
        </div>

        {/* Summary Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-green-500/10 backdrop-blur-sm p-6 rounded-2xl border border-green-500/30 hover:scale-105 transition-transform">
            <div className="flex items-start justify-between mb-4">
              <div className="p-3 rounded-xl bg-gradient-to-br from-green-500 to-emerald-500">
                <Server className="w-6 h-6 text-white" />
              </div>
              <span className="text-sm font-semibold px-2 py-1 rounded-full bg-green-500/20 text-green-400">
                {Math.round((operationalAPIs / totalAPIs) * 100)}%
              </span>
            </div>
            <h3 className="text-gray-400 text-sm font-medium mb-1">APIs Operational</h3>
            <p className="text-3xl font-bold text-white">{operationalAPIs}/{totalAPIs}</p>
          </div>

          <div className="bg-blue-500/10 backdrop-blur-sm p-6 rounded-2xl border border-blue-500/30 hover:scale-105 transition-transform">
            <div className="flex items-start justify-between mb-4">
              <div className="p-3 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-500">
                <Zap className="w-6 h-6 text-white" />
              </div>
              <span className="text-sm font-semibold px-2 py-1 rounded-full bg-blue-500/20 text-blue-400">
                Avg
              </span>
            </div>
            <h3 className="text-gray-400 text-sm font-medium mb-1">Response Time</h3>
            <p className="text-3xl font-bold text-white">{avgResponseTime}ms</p>
          </div>

          <div className="bg-purple-500/10 backdrop-blur-sm p-6 rounded-2xl border border-purple-500/30 hover:scale-105 transition-transform">
            <div className="flex items-start justify-between mb-4">
              <div className="p-3 rounded-xl bg-gradient-to-br from-purple-500 to-pink-500">
                <Bot className="w-6 h-6 text-white" />
              </div>
              <span className="text-sm font-semibold px-2 py-1 rounded-full bg-purple-500/20 text-purple-400">
                {Math.round((onlineAgents / totalAgents) * 100)}%
              </span>
            </div>
            <h3 className="text-gray-400 text-sm font-medium mb-1">Agents Online</h3>
            <p className="text-3xl font-bold text-white">{onlineAgents}/{totalAgents}</p>
          </div>

          <div className="bg-orange-500/10 backdrop-blur-sm p-6 rounded-2xl border border-orange-500/30 hover:scale-105 transition-transform">
            <div className="flex items-start justify-between mb-4">
              <div className="p-3 rounded-xl bg-gradient-to-br from-orange-500 to-yellow-500">
                <Activity className="w-6 h-6 text-white" />
              </div>
              <span className="text-sm font-semibold px-2 py-1 rounded-full bg-orange-500/20 text-orange-400">
                Live
              </span>
            </div>
            <h3 className="text-gray-400 text-sm font-medium mb-1">Active Tasks</h3>
            <p className="text-3xl font-bold text-white">{totalActiveTasks}</p>
          </div>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* API List - Takes 2 columns */}
          <div className="lg:col-span-2 space-y-6">
            {/* API Status Cards */}
            <div className="bg-gray-900/50 backdrop-blur-sm p-6 rounded-xl border border-green-500/30">
              <div className="flex items-center mb-6">
                <div className="p-2 rounded-lg bg-gradient-to-br from-green-500 to-emerald-500 mr-3">
                  <Server className="w-5 h-5 text-white" />
                </div>
                <h3 className="text-xl font-bold text-white">Connected APIs</h3>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {apiStatuses.map(api => (
                  <div key={api.name} className="bg-gray-900/50 p-4 rounded-xl border border-gray-700/50 hover:border-green-500/30 transition-all">
                    <div className="flex items-start justify-between mb-2">
                      <span className="font-semibold text-white">{api.name}</span>
                      <StatusIndicator status={api.status} />
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-400">Response Time</span>
                      <span className={`font-bold ${api.responseTime < 100 ? 'text-green-400' : api.responseTime < 200 ? 'text-yellow-400' : 'text-orange-400'}`}>
                        {api.status === 'Down' ? '--' : `${api.responseTime}ms`}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Response Time Chart */}
            <div className="bg-gray-900/50 backdrop-blur-sm p-6 rounded-xl border border-cyan-500/30">
              <div className="flex items-center mb-6">
                <div className="p-2 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-500 mr-3">
                  <TrendingUp className="w-5 h-5 text-white" />
                </div>
                <h3 className="text-xl font-bold text-white">API Response Times</h3>
              </div>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={responseTimeData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis dataKey="name" stroke="#9CA3AF" style={{ fontSize: '12px' }} />
                  <YAxis stroke="#9CA3AF" style={{ fontSize: '12px' }} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#1F2937', 
                      border: '1px solid #374151',
                      borderRadius: '8px',
                      boxShadow: '0 4px 6px rgba(0,0,0,0.3)'
                    }} 
                  />
                  <Bar dataKey="time" fill="#3b82f6" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Right Column - Agent Status & Charts */}
          <div className="space-y-6">
            {/* Agent Status List */}
            <div className="bg-gray-900/50 backdrop-blur-sm p-6 rounded-xl border border-purple-500/30">
              <div className="flex items-center mb-6">
                <div className="p-2 rounded-lg bg-gradient-to-br from-purple-500 to-pink-500 mr-3">
                  <Bot className="w-5 h-5 text-white" />
                </div>
                <h3 className="text-xl font-bold text-white">AI Agents</h3>
              </div>
              <div className="space-y-3 max-h-[500px] overflow-y-auto custom-scrollbar">
                {agentStatuses.map(agent => (
                  <div key={agent.name} className="bg-gray-900/50 p-4 rounded-xl border border-gray-700/50 hover:border-purple-500/30 transition-all">
                    <div className="flex items-start justify-between mb-2">
                      <span className="font-semibold text-white text-sm">{agent.name}</span>
                      <StatusIndicator status={agent.status} />
                    </div>
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-gray-400">Active Tasks</span>
                      <span className="font-bold text-purple-400">
                        {agent.status === 'Offline' ? '0' : agent.activeTasks}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Status Distribution Pie Chart */}
            <div className="bg-gray-900/50 backdrop-blur-sm p-6 rounded-xl border border-green-500/30">
              <div className="flex items-center mb-6">
                <div className="p-2 rounded-lg bg-gradient-to-br from-green-500 to-emerald-500 mr-3">
                  <Database className="w-5 h-5 text-white" />
                </div>
                <h3 className="text-xl font-bold text-white">Status Overview</h3>
              </div>
              <ResponsiveContainer width="100%" height={250}>
                <PieChart>
                  <Pie 
                    data={statusDistribution} 
                    dataKey="value" 
                    nameKey="name" 
                    cx="50%" 
                    cy="50%" 
                    outerRadius={80}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    labelStyle={{ fontSize: '12px', fill: '#fff' }}
                  >
                    {statusDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#1F2937', 
                      border: '1px solid #374151',
                      borderRadius: '8px',
                      boxShadow: '0 4px 6px rgba(0,0,0,0.3)'
                    }} 
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </div>
      
      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: rgba(31, 41, 55, 0.5);
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(139, 92, 246, 0.5);
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: rgba(139, 92, 246, 0.8);
        }
      `}</style>
    </div>
  );
};

export default APIStatusPage;
