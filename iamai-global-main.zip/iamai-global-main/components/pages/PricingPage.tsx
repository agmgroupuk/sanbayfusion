import React, { useEffect, useState } from 'react';
import PricingSection from '../PricingSection';
import type { Page } from '../../App';
import { Agent, SubscriptionPlanSlug } from '../../constants';
import { useApp } from '../../contexts/AppContext';
import { ALL_AGENTS } from '../../agents';

interface PricingPageProps {
  onNavigate: (page: Page) => void;
}

const PricingPage: React.FC<PricingPageProps> = ({ onNavigate }) => {
  const { selectAgentForSubscription, subscribe, state, setState } = useApp();
  const [planDetails, setPlanDetails] = useState<any>(null);

  useEffect(() => {
    fetch('/api/pricing')
      .then(res => res.json())
      .then(data => {
        setPlanDetails({
          daily: {
            name: data.daily.name,
            price: `$${data.daily.amount}`,
            cadence: 'one-time',
            description: '24-hour access.',
          },
          weekly: {
            name: data.weekly.name,
            price: `$${data.weekly.amount}`,
            cadence: 'one-time',
            description: '7-day access.',
          },
          monthly: {
            name: data.monthly.name,
            price: `$${data.monthly.amount}`,
            cadence: 'one-time',
            description: '30-day access.',
          },
        });
      });
  }, []);

  const resolveAgent = (): Agent | null => {
    const agent = state.agentForSubscription || state.selectedAgent || ALL_AGENTS[0] || null;
    return agent;
  };

  const handlePlanSelect = (plan: SubscriptionPlanSlug) => {
    const agent = resolveAgent();
    if (!agent) return;

    if (state.isLoggedIn) {
      subscribe(agent, plan);
    } else {
      // Persist intended agent/plan and send user to login
      selectAgentForSubscription(agent, plan);
    }
  };

  if (!planDetails) {
    return <div>Loading pricing...</div>;
  }

  return (
    <div className="bg-black min-h-screen">
      <PricingSection onNavigate={onNavigate} onSelectPlan={handlePlanSelect} />
      <div className="text-center pb-20 space-y-4">
        <div className="flex items-center justify-center gap-4">
          <button
            onClick={() => onNavigate('dashboard')}
            title="Return to dashboard"
            className="px-6 py-3 bg-gray-800 hover:bg-gray-700 text-white font-semibold rounded-lg transition-colors"
          >
            ← Back to Dashboard
          </button>
          <button
            onClick={() => onNavigate('agents')}
            title="Browse all agents"
            className="px-6 py-3 bg-cyan-500 hover:bg-cyan-600 text-black font-semibold rounded-lg transition-colors"
          >
            Browse Agents →
          </button>
        </div>
        <button
          onClick={() => onNavigate('home')}
          title="Return to homepage"
          className="text-cyan-400 hover:text-cyan-300 font-semibold transition-colors text-sm"
        >
          ← Back to Home
        </button>
      </div>
    </div>
  );
};

export default PricingPage;
