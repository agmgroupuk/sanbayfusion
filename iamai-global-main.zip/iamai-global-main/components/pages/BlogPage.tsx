import React, { useState, useRef, useEffect } from 'react';
import { BlogPost } from '../../constants';
import { blogEras, getEra, yearRange, loadBlogPosts } from '../../data/blogData';

interface BlogPageProps {
  onNavigate: (page: 'home') => void;
  onSelectBlogPost: (post: BlogPost) => void;
}

const BlogPage: React.FC<BlogPageProps> = ({ onNavigate, onSelectBlogPost }) => {
  const [selectedYear, setSelectedYear] = useState<number>(1936);
  const [blogPosts, setBlogPosts] = useState<{ [key: number]: BlogPost }>({});
  const [loading, setLoading] = useState<boolean>(true);
  const contentRef = useRef<HTMLDivElement>(null);

  // Load blog posts on component mount
  useEffect(() => {
    const loadData = async () => {
      try {
        const posts = await loadBlogPosts();
        setBlogPosts(posts);
      } catch (error) {
        console.error('Failed to load blog posts:', error);
      } finally {
        setLoading(false);
      }
    };
    
    loadData();
  }, []);

  // Auto-scroll to content on mobile when year selection changes
  useEffect(() => {
    if (window.innerWidth < 768 && contentRef.current) {
      setTimeout(() => {
        contentRef.current?.scrollIntoView({ 
          behavior: 'smooth', 
          block: 'start' 
        });
      }, 100);
    }
  }, [selectedYear]);

  const handleYearSelect = (year: number) => {
    setSelectedYear(year);
  };

  const currentPost = blogPosts[selectedYear];
  const era = getEra(selectedYear);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-900 text-white flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-white mx-auto mb-4"></div>
          <p>Loading AI History...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-900 to-blue-900 p-6">
        <div className="max-w-7xl mx-auto">
          <button
            onClick={() => onNavigate('home')}
            className="mb-4 px-4 py-2 bg-white/20 rounded-lg hover:bg-white/30 transition-colors"
          >
            ← Back to Home
          </button>
          <h1 className="text-4xl font-bold mb-2">AI Through the Ages</h1>
          <p className="text-xl opacity-90">
            Explore the complete history of artificial intelligence from 1936 to 2025
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          
          {/* Year Selector Sidebar */}
          <div className="lg:col-span-1">
            <div className="sticky top-6">
              <h2 className="text-2xl font-bold mb-6">Select Year</h2>
              
              {/* Era Legend */}
              <div className="mb-6">
                <h3 className="text-lg font-semibold mb-3">Eras</h3>
                <div className="space-y-2">
                  {blogEras.map((era, index) => (
                    <div key={index} className="flex items-center space-x-2 text-sm">
                      <div className={`w-3 h-3 rounded-full ${era.color}`}></div>
                      <span>{era.icon}</span>
                      <span>{era.name}</span>
                      <span className="text-gray-400">
                        ({era.years[0]}-{era.years[1]})
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Year Grid */}
              <div className="grid grid-cols-6 gap-1 max-h-96 overflow-y-auto">
                {yearRange.map((year) => {
                  const yearEra = getEra(year);
                  return (
                    <button
                      key={year}
                      onClick={() => handleYearSelect(year)}
                      className={`
                        p-2 text-xs rounded transition-all duration-200
                        ${selectedYear === year 
                          ? `${yearEra.color} text-white shadow-lg scale-110` 
                          : `${yearEra.color} opacity-70 hover:opacity-100 hover:scale-105`
                        }
                      `}
                    >
                      {year}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Content Area */}
          <div className="lg:col-span-3" ref={contentRef}>
            {currentPost ? (
              <div className="space-y-6">
                {/* Era Badge */}
                <div className={`inline-flex items-center space-x-2 px-4 py-2 rounded-full ${era.color} text-white`}>
                  <span className="text-lg">{era.icon}</span>
                  <span className="font-semibold">{era.name}</span>
                  <span className="opacity-75">• {selectedYear}</span>
                </div>

                {/* Post Content */}
                <div className="bg-gray-800 rounded-xl p-8">
                  <h1 className="text-3xl font-bold mb-4">{currentPost.title}</h1>
                  <p className="text-xl text-gray-300 mb-6">{currentPost.excerpt}</p>
                  
                  {/* Tags */}
                  {currentPost.tags && currentPost.tags.length > 0 && (
                    <div className="flex flex-wrap gap-2 mb-6">
                      {currentPost.tags.map((tag, index) => (
                        <span
                          key={index}
                          className="px-3 py-1 bg-blue-600 text-white text-sm rounded-full"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  )}

                  {/* Content */}
                  <div className="prose prose-invert max-w-none">
                    {currentPost.content.split('\n\n').map((paragraph, index) => (
                      <p key={index} className="mb-4 text-gray-200 leading-relaxed">
                        {paragraph}
                      </p>
                    ))}
                  </div>

                  {/* Action Button */}
                  <button
                    onClick={() => onSelectBlogPost(currentPost)}
                    className="mt-8 px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors font-semibold"
                  >
                    Read Full Article
                  </button>
                </div>
              </div>
            ) : (
              <div className="bg-gray-800 rounded-xl p-8 text-center">
                <div className="text-6xl mb-4">📚</div>
                <h2 className="text-2xl font-bold mb-4">No Content Available</h2>
                <p className="text-gray-400 mb-6">
                  We're working on adding content for {selectedYear}. 
                  Check back soon or explore other years in AI history.
                </p>
                <div className="flex justify-center space-x-4">
                  <button
                    onClick={() => setSelectedYear(2024)}
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
                  >
                    Go to 2024
                  </button>
                  <button
                    onClick={() => setSelectedYear(1956)}
                    className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition-colors"
                  >
                    Birth of AI (1956)
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default BlogPage;