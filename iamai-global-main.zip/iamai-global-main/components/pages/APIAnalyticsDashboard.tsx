import React from 'react';
import { Page } from '../../App';

interface APIAnalyticsDashboardProps {
  onNavigate: (page: Page) => void;
}

const APIAnalyticsDashboard: React.FC<APIAnalyticsDashboardProps> = ({ onNavigate }) => {
  return (
    <div className="py-20 md:py-28 bg-black flex items-center justify-center text-center">
      <div className="container mx-auto px-6">
        <h1 className="text-4xl md:text-5xl font-bold text-white">API Analytics</h1>
        <p className="max-w-2xl mx-auto mt-4 text-gray-400">
          This page is under construction. Monitor your API usage and performance metrics here soon.
        </p>
        <div className="mt-12">
          <button onClick={() => onNavigate('home')} title="Return to the homepage" className="text-cyan-400 hover:text-cyan-300 font-semibold">
            &larr; Back to Home
          </button>
        </div>
      </div>
    </div>
  );
};

export default APIAnalyticsDashboard;
