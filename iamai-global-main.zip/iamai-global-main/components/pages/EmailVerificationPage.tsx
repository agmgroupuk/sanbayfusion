import React, { useState, useEffect } from 'react';
import {
  Mail,
  CheckCircle,
  XCircle,
  AlertCircle,
  Shield,
  Server,
  Clock,
  Download,
  Copy,
  Upload,
  Filter,
  Info,
  TrendingUp,
  Zap,
} from 'lucide-react';

interface EmailVerificationResult {
  email: string;
  isValid: boolean;
  formatValid: boolean;
  smtpValid: boolean;
  domainValid: boolean;
  disposable: boolean;
  catchAll: boolean;
  freeProvider: boolean;
  mxRecords: string[];
  score: number;
  risk: 'low' | 'medium' | 'high';
  timestamp: number;
}

interface VerificationHistory {
  id: string;
  email: string;
  timestamp: number;
  isValid: boolean;
  score: number;
}

const EmailVerificationPage: React.FC = () => {
  const [email, setEmail] = useState('');
  const [bulkEmails, setBulkEmails] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);
  const [result, setResult] = useState<EmailVerificationResult | null>(null);
  const [bulkResults, setBulkResults] = useState<EmailVerificationResult[]>([]);
  const [history, setHistory] = useState<VerificationHistory[]>([]);
  const [activeTab, setActiveTab] = useState<'single' | 'bulk'>('single');
  const [showHistory, setShowHistory] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [stats, setStats] = useState({
    totalVerifications: 0,
    validEmails: 0,
    invalidEmails: 0,
    avgScore: 0,
  });

  // Load history
  useEffect(() => {
    const saved = localStorage.getItem('email_verification_history');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setHistory(parsed);
        calculateStats(parsed);
      } catch (e) {
        console.error('Failed to load history:', e);
      }
    }
  }, []);

  // Save history
  useEffect(() => {
    if (history.length > 0) {
      localStorage.setItem('email_verification_history', JSON.stringify(history.slice(0, 100)));
    }
  }, [history]);

  const calculateStats = (historyData: VerificationHistory[]) => {
    const total = historyData.length;
    const valid = historyData.filter(h => h.isValid).length;
    const avgScore = historyData.reduce((sum, h) => sum + h.score, 0) / total || 0;

    setStats({
      totalVerifications: total,
      validEmails: valid,
      invalidEmails: total - valid,
      avgScore: Math.round(avgScore),
    });
  };

  const handleVerify = async () => {
    if (!email.trim()) {
      setError('Please enter an email address');
      return;
    }

    setIsVerifying(true);
    setError(null);
    setResult(null);

    try {
      // Use backend endpoint to avoid CORS and keep API secure
      const response = await fetch('/api/tools/email-verify', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({ email }),
      });

      if (!response.ok) {
        throw new Error(`API Error: ${response.status}`);
      }

      const data = await response.json();

      if (!data.success) {
        throw new Error(data.error || 'Verification failed');
      }

      const verifyResult: EmailVerificationResult = {
        email: email,
        isValid: data.valid || false,
        formatValid: data.formatValid || false,
        smtpValid: data.smtpValid || false,
        domainValid: data.domainExists || false,
        disposable: data.disposable || false,
        catchAll: false,
        freeProvider: data.freeProvider || false,
        mxRecords: data.mxRecords || [],
        score: data.quality || calculateScoreFromData(data),
        risk: calculateRiskFromScore(data.quality || calculateScoreFromData(data)),
        timestamp: Date.now(),
      };

      setResult(verifyResult);

      // Add to history
      const historyItem: VerificationHistory = {
        id: Date.now().toString(),
        email: email,
        timestamp: Date.now(),
        isValid: verifyResult.isValid,
        score: verifyResult.score,
      };

      const newHistory = [historyItem, ...history];
      setHistory(newHistory);
      calculateStats(newHistory);
    } catch (err: any) {
      setError(err.message || 'Failed to verify email');
    } finally {
      setIsVerifying(false);
    }
  };

  const calculateScoreFromData = (data: any): number => {
    let score = 0;
    if (data.formatValid) score += 20;
    if (data.smtpValid) score += 30;
    if (data.domainExists) score += 20;
    if (!data.disposable) score += 15;
    if (!data.freeProvider) score += 15;
    return score;
  };

  const calculateRiskFromScore = (score: number): 'low' | 'medium' | 'high' => {
    if (score >= 75) return 'low';
    if (score >= 50) return 'medium';
    return 'high';
  };

  const handleBulkVerify = async () => {
    const emails = bulkEmails
      .split('\n')
      .map(e => e.trim())
      .filter(e => e);
    if (emails.length === 0) {
      setError('Please enter at least one email address');
      return;
    }

    setIsVerifying(true);
    setError(null);
    setBulkResults([]);

    const results: EmailVerificationResult[] = [];

    for (const emailAddr of emails) {
      try {
        const response = await fetch('/api/tools/email-verify', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          credentials: 'include',
          body: JSON.stringify({ email: emailAddr }),
        });

        if (response.ok) {
          const data = await response.json();
          if (data.success) {
            results.push({
              email: emailAddr,
              isValid: data.valid || false,
              formatValid: data.formatValid || false,
              smtpValid: data.smtpValid || false,
              domainValid: data.domainExists || false,
              disposable: data.disposable || false,
              catchAll: false,
              freeProvider: data.freeProvider || false,
              mxRecords: data.mxRecords || [],
              score: data.quality || calculateScoreFromData(data),
              risk: calculateRiskFromScore(data.quality || calculateScoreFromData(data)),
              timestamp: Date.now(),
            });
          }
        }
      } catch (err) {
        console.error(`Failed to verify ${emailAddr}:`, err);
      }
    }

    setBulkResults(results);
    setIsVerifying(false);
  };

  const handleExport = (format: 'json' | 'csv') => {
    const data = bulkResults.length > 0 ? bulkResults : result ? [result] : [];
    if (data.length === 0) return;

    if (format === 'json') {
      const dataStr = JSON.stringify(data, null, 2);
      const blob = new Blob([dataStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `email-verification-${Date.now()}.json`;
      link.click();
      URL.revokeObjectURL(url);
    } else {
      const csv = [
        ['Email', 'Valid', 'Format', 'SMTP', 'Domain', 'Disposable', 'Score', 'Risk'].join(','),
        ...data.map(r =>
          [
            r.email,
            r.isValid,
            r.formatValid,
            r.smtpValid,
            r.domainValid,
            r.disposable,
            r.score,
            r.risk,
          ].join(',')
        ),
      ].join('\n');

      const blob = new Blob([csv], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `email-verification-${Date.now()}.csv`;
      link.click();
      URL.revokeObjectURL(url);
    }
  };

  return (
    <div className="min-h-screen bg-black text-white py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <Mail className="w-8 h-8 text-cyan-400" />
            <h1 className="text-4xl font-bold bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
              Email Verification
            </h1>
          </div>
          <p className="text-gray-400 text-lg">
            Validate email addresses with syntax check, domain validation, and SMTP verification
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border border-cyan-500/30 rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-400">Total Verified</span>
              <Mail className="w-4 h-4 text-cyan-400" />
            </div>
            <p className="text-2xl font-bold text-white">{stats?.totalVerifications || 0}</p>
          </div>
          <div className="bg-gradient-to-br from-green-500/10 to-emerald-500/10 border border-green-500/30 rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-400">Valid Emails</span>
              <CheckCircle className="w-4 h-4 text-green-400" />
            </div>
            <p className="text-2xl font-bold text-white">{stats?.validEmails || 0}</p>
          </div>
          <div className="bg-gradient-to-br from-red-500/10 to-pink-500/10 border border-red-500/30 rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-400">Invalid Emails</span>
              <XCircle className="w-4 h-4 text-red-400" />
            </div>
            <p className="text-2xl font-bold text-white">{stats?.invalidEmails || 0}</p>
          </div>
          <div className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border border-purple-500/30 rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-400">Avg Score</span>
              <TrendingUp className="w-4 h-4 text-purple-400" />
            </div>
            <p className="text-2xl font-bold text-white">{stats?.avgScore || 0}/100</p>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-6 border-b border-gray-800">
          <button
            onClick={() => setActiveTab('single')}
            className={`px-4 py-2 font-semibold transition-all ${
              activeTab === 'single'
                ? 'text-cyan-400 border-b-2 border-cyan-400'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            Single Email
          </button>
          <button
            onClick={() => setActiveTab('bulk')}
            className={`px-4 py-2 font-semibold transition-all ${
              activeTab === 'bulk'
                ? 'text-cyan-400 border-b-2 border-cyan-400'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            Bulk Verification
          </button>
        </div>

        {/* Single Email Tab */}
        {activeTab === 'single' && (
          <>
            <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6 mb-6">
              <label className="block text-sm font-semibold text-gray-300 mb-2">
                Email Address
              </label>
              <div className="flex flex-col sm:flex-row gap-3">
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  onKeyPress={e => e.key === 'Enter' && handleVerify()}
                  placeholder="user@example.com"
                  className="flex-1 w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:border-cyan-500 focus:outline-none"
                />
                <button
                  onClick={handleVerify}
                  disabled={isVerifying}
                  className="w-full sm:w-auto bg-gradient-to-r from-cyan-600 to-purple-600 hover:from-cyan-700 hover:to-purple-700 disabled:from-gray-700 disabled:to-gray-700 text-white font-semibold px-8 py-3 rounded-lg transition-all flex items-center justify-center gap-2"
                >
                  {isVerifying ? (
                    <>
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                      Verifying...
                    </>
                  ) : (
                    <>
                      <Zap className="w-5 h-5" />
                      Verify
                    </>
                  )}
                </button>
              </div>
              {error && (
                <div className="mt-4 bg-red-500/10 border border-red-500/30 rounded-lg p-4 flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
                  <p className="text-red-300">{error}</p>
                </div>
              )}
            </div>

            {result && (
              <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-xl font-bold text-white">Verification Result</h3>
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleExport('json')}
                      className="p-2 bg-gray-800 hover:bg-gray-700 rounded-lg transition-colors"
                    >
                      <Download className="w-4 h-4 text-gray-300" />
                    </button>
                  </div>
                </div>

                {/* Overall Status */}
                <div
                  className={`p-6 rounded-lg border mb-6 ${
                    result.isValid
                      ? 'bg-green-500/10 border-green-500/30'
                      : 'bg-red-500/10 border-red-500/30'
                  }`}
                >
                  <div className="flex items-center gap-4">
                    {result.isValid ? (
                      <CheckCircle className="w-12 h-12 text-green-400" />
                    ) : (
                      <XCircle className="w-12 h-12 text-red-400" />
                    )}
                    <div className="flex-1">
                      <p
                        className={`text-2xl font-bold ${result.isValid ? 'text-green-300' : 'text-red-300'}`}
                      >
                        {result.isValid ? 'Valid Email' : 'Invalid Email'}
                      </p>
                      <p className="text-gray-400">{result.email}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-3xl font-bold text-white">{result.score}</p>
                      <p className="text-sm text-gray-400">Score</p>
                    </div>
                  </div>
                </div>

                {/* Checks Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
                  <div className="p-4 bg-gray-800/50 rounded-lg">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-300">Format Check</span>
                      {result.formatValid ? (
                        <CheckCircle className="w-5 h-5 text-green-400" />
                      ) : (
                        <XCircle className="w-5 h-5 text-red-400" />
                      )}
                    </div>
                  </div>
                  <div className="p-4 bg-gray-800/50 rounded-lg">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-300">SMTP Check</span>
                      {result.smtpValid ? (
                        <CheckCircle className="w-5 h-5 text-green-400" />
                      ) : (
                        <XCircle className="w-5 h-5 text-red-400" />
                      )}
                    </div>
                  </div>
                  <div className="p-4 bg-gray-800/50 rounded-lg">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-300">Domain Valid</span>
                      {result.domainValid ? (
                        <CheckCircle className="w-5 h-5 text-green-400" />
                      ) : (
                        <XCircle className="w-5 h-5 text-red-400" />
                      )}
                    </div>
                  </div>
                  <div className="p-4 bg-gray-800/50 rounded-lg">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-300">Disposable</span>
                      {result.disposable ? (
                        <AlertCircle className="w-5 h-5 text-yellow-400" />
                      ) : (
                        <CheckCircle className="w-5 h-5 text-green-400" />
                      )}
                    </div>
                  </div>
                  <div className="p-4 bg-gray-800/50 rounded-lg">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-300">Catch-All</span>
                      {result.catchAll ? (
                        <AlertCircle className="w-5 h-5 text-yellow-400" />
                      ) : (
                        <CheckCircle className="w-5 h-5 text-green-400" />
                      )}
                    </div>
                  </div>
                  <div className="p-4 bg-gray-800/50 rounded-lg">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-300">Free Provider</span>
                      {result.freeProvider ? (
                        <Info className="w-5 h-5 text-blue-400" />
                      ) : (
                        <Shield className="w-5 h-5 text-gray-400" />
                      )}
                    </div>
                  </div>
                </div>

                {/* MX Records */}
                {result.mxRecords.length > 0 && (
                  <div>
                    <h4 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
                      <Server className="w-5 h-5 text-cyan-400" />
                      MX Records
                    </h4>
                    <div className="space-y-2">
                      {result.mxRecords.map((mx, idx) => (
                        <div
                          key={idx}
                          className="p-3 bg-gray-800/50 rounded-lg font-mono text-sm text-gray-300"
                        >
                          {mx}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </>
        )}

        {/* Bulk Tab */}
        {activeTab === 'bulk' && (
          <>
            <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6 mb-6">
              <label className="block text-sm font-semibold text-gray-300 mb-2">
                Email Addresses (one per line)
              </label>
              <textarea
                value={bulkEmails}
                onChange={e => setBulkEmails(e.target.value)}
                placeholder="user1@example.com&#10;user2@example.com&#10;user3@example.com"
                rows={10}
                className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:border-cyan-500 focus:outline-none resize-y"
              />
              <div className="flex gap-2 mt-4">
                <button
                  onClick={handleBulkVerify}
                  disabled={isVerifying}
                  className="bg-gradient-to-r from-cyan-600 to-purple-600 hover:from-cyan-700 hover:to-purple-700 disabled:from-gray-700 disabled:to-gray-700 text-white font-semibold px-6 py-3 rounded-lg transition-all flex items-center gap-2"
                >
                  {isVerifying ? (
                    <>
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                      Verifying...
                    </>
                  ) : (
                    <>
                      <Zap className="w-5 h-5" />
                      Verify All
                    </>
                  )}
                </button>
                {bulkResults.length > 0 && (
                  <>
                    <button
                      onClick={() => handleExport('json')}
                      className="bg-gray-800 hover:bg-gray-700 text-white font-semibold px-4 py-3 rounded-lg transition-colors flex items-center gap-2"
                    >
                      <Download className="w-4 h-4" />
                      JSON
                    </button>
                    <button
                      onClick={() => handleExport('csv')}
                      className="bg-gray-800 hover:bg-gray-700 text-white font-semibold px-4 py-3 rounded-lg transition-colors flex items-center gap-2"
                    >
                      <Download className="w-4 h-4" />
                      CSV
                    </button>
                  </>
                )}
              </div>
            </div>

            {bulkResults.length > 0 && (
              <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6">
                <h3 className="text-xl font-bold text-white mb-4">
                  Bulk Results ({bulkResults.length})
                </h3>
                <div className="space-y-2">
                  {bulkResults.map((r, idx) => (
                    <div
                      key={idx}
                      className="p-4 bg-gray-800/50 rounded-lg flex items-center justify-between"
                    >
                      <div className="flex-1">
                        <p className="text-white font-medium">{r.email}</p>
                        <p className="text-xs text-gray-400">
                          Score: {r.score}/100 • Risk: {r.risk}
                        </p>
                      </div>
                      {r.isValid ? (
                        <CheckCircle className="w-6 h-6 text-green-400" />
                      ) : (
                        <XCircle className="w-6 h-6 text-red-400" />
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </>
        )}

        {/* Platform Branding */}
        <div className="mt-8 bg-gradient-to-r from-cyan-500/10 to-purple-500/10 border border-cyan-500/30 rounded-lg p-4">
          <div className="flex items-start gap-3">
            <Info className="w-5 h-5 text-cyan-400 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm text-cyan-300 font-semibold mb-1">
                🚀 Powered by IA M AI Global Platform
              </p>
              <p className="text-xs text-cyan-300/80">
                Advanced email verification with syntax validation, domain checks, SMTP
                verification, and disposable email detection.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EmailVerificationPage;
