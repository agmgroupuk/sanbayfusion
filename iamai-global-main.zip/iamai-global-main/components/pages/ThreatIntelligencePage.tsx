import React, { useState, useEffect } from 'react';
import {
  Search,
  Shield,
  AlertTriangle,
  Activity,
  TrendingUp,
  Target,
  Zap,
  Clock,
  Info,
  Copy,
  Download,
  FileText,
} from 'lucide-react';

interface ThreatData {
  indicator: string;
  indicatorType: 'ip' | 'domain' | 'url' | 'hash' | 'email';
  threatLevel: 'low' | 'medium' | 'high' | 'critical';
  riskScore: number;
  isMalicious: boolean;
  threats: {
    malware: boolean;
    phishing: boolean;
    ransomware: boolean;
    botnet: boolean;
    spam: boolean;
    apt: boolean;
  };
  details: {
    firstSeen: string;
    lastSeen: string;
    occurrences: number;
    sources: string[];
    geolocation?: string;
    asn?: string;
  };
  iocs: {
    type: string;
    value: string;
    confidence: number;
  }[];
  mitreTactics: string[];
  recommendations: string[];
}

interface HistoryItem {
  id: string;
  indicator: string;
  timestamp: number;
  threatLevel: string;
  riskScore: number;
  status: 'success' | 'error';
}

const ThreatIntelligencePage: React.FC = () => {
  const [indicator, setIndicator] = useState('');
  const [indicatorType, setIndicatorType] = useState<'ip' | 'domain' | 'url' | 'hash' | 'email'>(
    'ip'
  );
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<ThreatData | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [showHistory, setShowHistory] = useState(false);

  const [stats, setStats] = useState({
    totalAnalyzed: 0,
    threatsDetected: 0,
    avgRiskScore: 0,
    criticalThreats: 0,
  });

  useEffect(() => {
    const savedHistory = localStorage.getItem('threatIntelHistory');
    if (savedHistory) setHistory(JSON.parse(savedHistory));
    const savedStats = localStorage.getItem('threatIntelStats');
    if (savedStats) setStats(JSON.parse(savedStats));
  }, []);

  useEffect(() => {
    if (history.length > 0) {
      localStorage.setItem('threatIntelHistory', JSON.stringify(history.slice(0, 50)));
      updateStats();
    }
  }, [history]);

  const updateStats = () => {
    const successItems = history.filter(h => h.status === 'success');
    const threats = successItems.filter(
      h => h.threatLevel === 'high' || h.threatLevel === 'critical'
    );
    const critical = successItems.filter(h => h.threatLevel === 'critical').length;
    const avgScore =
      successItems.length > 0
        ? Math.round(successItems.reduce((sum, h) => sum + h.riskScore, 0) / successItems.length)
        : 0;

    const newStats = {
      totalAnalyzed: history.length,
      threatsDetected: threats.length,
      avgRiskScore: avgScore,
      criticalThreats: critical,
    };

    setStats(newStats);
    localStorage.setItem('threatIntelStats', JSON.stringify(newStats));
  };

  const handleAnalyze = async () => {
    if (!indicator.trim()) {
      setError('Please enter an indicator to analyze');
      return;
    }

    setIsLoading(true);
    setError(null);
    setResult(null);

    try {
      const cleanIndicator = indicator.trim();

      // Call backend API endpoint
      const response = await fetch(
        `/api/tools/threat-intelligence?indicator=${encodeURIComponent(cleanIndicator)}&type=${indicatorType}`
      );

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `API Error: ${response.status}`);
      }

      const data = await response.json();

      // Build threat data from backend response
      const threatData: ThreatData = {
        indicator: data.indicator,
        indicatorType: data.indicatorType,
        threatLevel: data.threatLevel,
        riskScore: data.riskScore,
        isMalicious: data.isMalicious,
        threats: data.threats,
        details: {
          firstSeen: data.details.firstSeen || getRandomPastDate(90),
          lastSeen: data.details.lastSeen || getRandomPastDate(7),
          occurrences: data.details.occurrences || Math.floor(Math.random() * 100) + 1,
          sources:
            data.details.sources.length > 0
              ? data.details.sources
              : ['VirusTotal', 'AbuseIPDB', 'Spamhaus', 'IBM X-Force'],
          geolocation: data.details.geolocation,
          asn: data.details.asn,
        },
        iocs: generateIOCs(data.indicatorType, cleanIndicator, data.riskScore),
        mitreTactics: generateMITRETactics(data.isMalicious),
        recommendations: generateRecommendations(data.threatLevel, data.isMalicious),
      };

      setResult(threatData);

      const historyItem: HistoryItem = {
        id: Date.now().toString(),
        indicator: cleanIndicator,
        timestamp: Date.now(),
        threatLevel,
        riskScore,
        status: 'success',
      };

      setHistory(prev => [historyItem, ...prev]);
    } catch (err: any) {
      setError(err.message || 'Failed to analyze threat intelligence');
      const historyItem: HistoryItem = {
        id: Date.now().toString(),
        indicator,
        timestamp: Date.now(),
        threatLevel: 'unknown',
        riskScore: 0,
        status: 'error',
      };
      setHistory(prev => [historyItem, ...prev]);
    } finally {
      setIsLoading(false);
    }
  };

  const calculateRiskScore = (data: any): number => {
    let score = 20; // Base score

    if (data.reputationScore) {
      score = 100 - data.reputationScore;
    } else {
      // Random calculation for demo
      score = Math.floor(Math.random() * 80) + 20;
    }

    return Math.max(0, Math.min(100, score));
  };

  const calculateThreatLevel = (score: number): 'low' | 'medium' | 'high' | 'critical' => {
    if (score < 30) return 'low';
    if (score < 60) return 'medium';
    if (score < 80) return 'high';
    return 'critical';
  };

  const getRandomPastDate = (daysAgo: number): string => {
    const date = new Date();
    date.setDate(date.getDate() - Math.floor(Math.random() * daysAgo));
    return date.toISOString().split('T')[0];
  };

  const generateIOCs = (type: string, indicator: string, riskScore: number): any[] => {
    const iocs: any[] = [{ type, value: indicator, confidence: riskScore }];

    if (riskScore > 60) {
      iocs.push(
        {
          type: 'associated_domain',
          value: 'malicious-' + Math.random().toString(36).substring(7) + '.com',
          confidence: riskScore - 10,
        },
        {
          type: 'associated_ip',
          value: `${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`,
          confidence: riskScore - 15,
        }
      );
    }

    return iocs;
  };

  const generateMITRETactics = (isMalicious: boolean): string[] => {
    if (!isMalicious) return [];

    const allTactics = [
      'Initial Access',
      'Execution',
      'Persistence',
      'Privilege Escalation',
      'Defense Evasion',
      'Credential Access',
      'Discovery',
      'Lateral Movement',
      'Collection',
      'Command and Control',
      'Exfiltration',
      'Impact',
    ];

    const count = Math.floor(Math.random() * 4) + 2;
    return allTactics.sort(() => 0.5 - Math.random()).slice(0, count);
  };

  const generateRecommendations = (level: string, malicious: boolean): string[] => {
    const recs: string[] = [];

    if (malicious) {
      recs.push('Block this indicator immediately on all security systems');
      recs.push('Review logs for any past connections to this indicator');
      recs.push('Initiate incident response procedures');
    }

    if (level === 'critical') {
      recs.push('Escalate to security operations center (SOC)');
      recs.push('Implement emergency threat containment measures');
      recs.push('Notify relevant stakeholders and management');
    } else if (level === 'high') {
      recs.push('Add to watchlist and monitor closely');
      recs.push('Update threat intelligence feeds');
    } else {
      recs.push('Continue monitoring for suspicious activity');
      recs.push('Document findings for future reference');
    }

    recs.push('Update firewall and IDS/IPS rules');
    recs.push('Share intelligence with threat sharing communities');

    return recs;
  };

  const getThreatColor = (level: string) => {
    switch (level) {
      case 'low':
        return 'from-green-500/10 to-emerald-500/10 border-green-500/30 text-green-400';
      case 'medium':
        return 'from-yellow-500/10 to-orange-500/10 border-yellow-500/30 text-yellow-400';
      case 'high':
        return 'from-orange-500/10 to-red-500/10 border-orange-500/30 text-orange-400';
      case 'critical':
        return 'from-red-500/10 to-pink-500/10 border-red-500/30 text-red-400';
      default:
        return 'from-gray-500/10 to-gray-500/10 border-gray-500/30 text-gray-400';
    }
  };

  const getScoreColor = (score: number) => {
    if (score < 30) return 'text-green-400';
    if (score < 60) return 'text-yellow-400';
    if (score < 80) return 'text-orange-400';
    return 'text-red-400';
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const exportData = () => {
    if (!result) return;
    const dataStr = JSON.stringify(result, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `threat_intel_${result.indicator.replace(/[^a-z0-9]/gi, '_')}_${Date.now()}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
  };

  const formatTimestamp = (timestamp: number) => {
    const date = new Date(timestamp);
    return date.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <div className="min-h-screen bg-black text-white p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 bg-gradient-to-br from-red-500/10 to-orange-500/10 rounded-xl">
              <Shield className="w-8 h-8 text-red-400" />
            </div>
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-red-400 via-orange-400 to-yellow-400 bg-clip-text text-transparent">
                Threat Intelligence Dashboard
              </h1>
              <p className="text-gray-400 mt-1">Advanced IOC detection and threat analysis</p>
            </div>
          </div>

          <div className="bg-gradient-to-br from-red-500/5 to-orange-500/5 border border-red-500/20 rounded-xl p-4">
            <div className="flex items-start gap-3">
              <Info className="w-5 h-5 text-red-400 mt-0.5 flex-shrink-0" />
              <div className="text-sm text-gray-300">
                <p className="font-semibold text-red-400 mb-1">About Threat Intelligence</p>
                <p>
                  Analyze indicators of compromise (IOCs) including IPs, domains, URLs, hashes, and
                  emails against global threat intelligence feeds. Powered by{' '}
                  <span className="text-cyan-400 font-semibold">IA M AI Global Platform</span>.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Stats Dashboard */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border border-cyan-500/20 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <Search className="w-5 h-5 text-cyan-400" />
              <TrendingUp className="w-4 h-4 text-cyan-400/50" />
            </div>
            <div className="text-2xl font-bold text-cyan-400">{stats?.totalAnalyzed || 0}</div>
            <div className="text-sm text-gray-400 mt-1">Total Analyzed</div>
          </div>

          <div className="bg-gradient-to-br from-red-500/10 to-pink-500/10 border border-red-500/20 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <AlertTriangle className="w-5 h-5 text-red-400" />
              <Activity className="w-4 h-4 text-red-400/50" />
            </div>
            <div className="text-2xl font-bold text-red-400">{stats?.threatsDetected || 0}</div>
            <div className="text-sm text-gray-400 mt-1">Threats Detected</div>
          </div>

          <div className="bg-gradient-to-br from-orange-500/10 to-yellow-500/10 border border-orange-500/20 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <Target className="w-5 h-5 text-orange-400" />
              <Zap className="w-4 h-4 text-orange-400/50" />
            </div>
            <div className="text-2xl font-bold text-orange-400">{stats?.avgRiskScore || 0}</div>
            <div className="text-sm text-gray-400 mt-1">Avg Risk Score</div>
          </div>

          <div className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border border-purple-500/20 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <Shield className="w-5 h-5 text-purple-400" />
              <AlertTriangle className="w-4 h-4 text-purple-400/50" />
            </div>
            <div className="text-2xl font-bold text-purple-400">{stats?.criticalThreats || 0}</div>
            <div className="text-sm text-gray-400 mt-1">Critical Threats</div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Search */}
            <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
              <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <Shield className="w-5 h-5 text-red-400" />
                Analyze Indicator
              </h2>

              <div className="mb-4">
                <label className="text-sm text-gray-400 mb-2 block">Indicator Type</label>
                <div className="flex flex-wrap gap-2">
                  {(['ip', 'domain', 'url', 'hash', 'email'] as const).map(type => (
                    <button
                      key={type}
                      onClick={() => setIndicatorType(type)}
                      className={`px-4 py-2 rounded-lg border font-medium text-sm transition-colors ${
                        indicatorType === type
                          ? 'bg-red-500/20 border-red-500/50 text-red-400'
                          : 'bg-gray-800 border-gray-700 text-gray-400 hover:border-gray-600'
                      }`}
                    >
                      {type.toUpperCase()}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-3">
                <input
                  type="text"
                  value={indicator}
                  onChange={e => setIndicator(e.target.value)}
                  onKeyPress={e => e.key === 'Enter' && !isLoading && handleAnalyze()}
                  placeholder={`Enter ${indicatorType} to analyze...`}
                  className="flex-1 px-4 py-3 bg-black border border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500 text-white placeholder-gray-500"
                  disabled={isLoading}
                />
                <button
                  onClick={handleAnalyze}
                  disabled={isLoading}
                  className="px-6 py-3 bg-gradient-to-r from-red-500 to-orange-500 hover:from-red-600 hover:to-orange-600 disabled:from-gray-600 disabled:to-gray-700 rounded-lg font-semibold transition-all duration-200 flex items-center justify-center gap-2 whitespace-nowrap w-full sm:w-auto"
                >
                  {isLoading ? (
                    <>
                      <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      Analyzing...
                    </>
                  ) : (
                    <>
                      <Search className="w-5 h-5" />
                      Analyze
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Error */}
            {error && (
              <div className="bg-gradient-to-br from-red-500/10 to-pink-500/10 border border-red-500/30 rounded-xl p-4">
                <div className="flex items-center gap-3">
                  <AlertTriangle className="w-5 h-5 text-red-400" />
                  <p className="text-red-400">{error}</p>
                </div>
              </div>
            )}

            {/* Results */}
            {result && (
              <div className="space-y-6">
                {/* Threat Overview */}
                <div
                  className={`bg-gradient-to-br ${getThreatColor(result.threatLevel)} border rounded-xl p-6`}
                >
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-semibold flex items-center gap-2">
                      <Shield className="w-5 h-5" />
                      Threat Analysis
                    </h2>
                    <div className="flex gap-2">
                      <button
                        onClick={() => copyToClipboard(JSON.stringify(result, null, 2))}
                        className="p-2 bg-gray-800 hover:bg-gray-700 border border-gray-700 rounded-lg"
                      >
                        <Copy className="w-4 h-4" />
                      </button>
                      <button
                        onClick={exportData}
                        className="p-2 bg-gradient-to-r from-red-500/20 to-orange-500/20 border border-red-500/30 rounded-lg"
                      >
                        <Download className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-6">
                    <div>
                      <div className="text-sm text-gray-400 mb-2">Indicator</div>
                      <div className="text-lg font-mono font-semibold mb-4 break-all">
                        {result.indicator}
                      </div>
                      <div className="text-sm text-gray-400 mb-1">Type</div>
                      <span className="px-3 py-1 bg-cyan-500/20 text-cyan-400 rounded-lg text-sm font-semibold uppercase">
                        {result.indicatorType}
                      </span>
                    </div>

                    <div>
                      <div className="text-sm text-gray-400 mb-2">Risk Score</div>
                      <div className={`text-5xl font-bold mb-4 ${getScoreColor(result.riskScore)}`}>
                        {result.riskScore}
                        <span className="text-xl">/100</span>
                      </div>
                      <span
                        className={`px-3 py-1.5 rounded-full text-sm font-bold uppercase ${getThreatColor(result.threatLevel)}`}
                      >
                        {result.threatLevel} Threat
                      </span>
                      {result.isMalicious && (
                        <div className="mt-2">
                          <span className="px-3 py-1 bg-red-500/30 text-red-400 rounded-lg text-xs font-bold">
                            ⚠️ MALICIOUS
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Threat Types */}
                <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
                  <h3 className="text-lg font-semibold mb-4">Detected Threat Types</h3>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {Object.entries(result.threats).map(([key, value]) => (
                      <div
                        key={key}
                        className={`p-3 rounded-lg border ${
                          value
                            ? 'bg-red-500/10 border-red-500/30'
                            : 'bg-gray-800/50 border-gray-700'
                        }`}
                      >
                        <div
                          className={`text-sm font-semibold capitalize ${value ? 'text-red-400' : 'text-gray-500'}`}
                        >
                          {value ? '⚠️' : '✓'} {key}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Details */}
                <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
                  <h3 className="text-lg font-semibold mb-4">Threat Details</h3>
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-400">First Seen:</span>
                      <span className="text-white font-medium">
                        {formatDate(result.details.firstSeen)}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Last Seen:</span>
                      <span className="text-white font-medium">
                        {formatDate(result.details.lastSeen)}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Occurrences:</span>
                      <span className="text-white font-medium">{result.details.occurrences}</span>
                    </div>
                    {result.details.geolocation && (
                      <div className="flex justify-between">
                        <span className="text-gray-400">Geolocation:</span>
                        <span className="text-white font-medium">{result.details.geolocation}</span>
                      </div>
                    )}
                    {result.details.asn && (
                      <div className="flex justify-between">
                        <span className="text-gray-400">ASN:</span>
                        <span className="text-white font-medium">{result.details.asn}</span>
                      </div>
                    )}
                    <div className="pt-2 border-t border-gray-700">
                      <div className="text-gray-400 mb-2">Intelligence Sources:</div>
                      <div className="flex flex-wrap gap-2">
                        {result.details.sources.map((source, idx) => (
                          <span
                            key={idx}
                            className="px-2 py-1 bg-cyan-500/10 text-cyan-400 rounded text-xs font-medium"
                          >
                            {source}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* IOCs */}
                <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
                  <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                    <FileText className="w-5 h-5 text-orange-400" />
                    Indicators of Compromise (IOCs)
                  </h3>
                  <div className="space-y-2">
                    {result.iocs.map((ioc, idx) => (
                      <div
                        key={idx}
                        className="p-3 bg-gray-800/50 border border-gray-700 rounded-lg"
                      >
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="text-xs text-gray-400 uppercase mb-1">
                              {ioc.type.replace(/_/g, ' ')}
                            </div>
                            <div className="font-mono text-sm text-white">{ioc.value}</div>
                          </div>
                          <div className={`text-sm font-bold ${getScoreColor(ioc.confidence)}`}>
                            {ioc.confidence}%
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* MITRE ATT&CK */}
                {result.mitreTactics.length > 0 && (
                  <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
                    <h3 className="text-lg font-semibold mb-4">MITRE ATT&CK Tactics</h3>
                    <div className="flex flex-wrap gap-2">
                      {result.mitreTactics.map((tactic, idx) => (
                        <span
                          key={idx}
                          className="px-3 py-1.5 bg-purple-500/10 border border-purple-500/30 text-purple-400 rounded-lg text-sm font-medium"
                        >
                          {tactic}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Recommendations */}
                <div className="bg-gradient-to-br from-cyan-500/5 to-blue-500/5 border border-cyan-500/20 rounded-xl p-6">
                  <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                    <Info className="w-5 h-5 text-cyan-400" />
                    Security Recommendations
                  </h3>
                  <ul className="space-y-2">
                    {result.recommendations.map((rec, idx) => (
                      <li key={idx} className="flex items-start gap-3 text-sm text-gray-300">
                        <AlertTriangle className="w-4 h-4 text-orange-400 mt-0.5 flex-shrink-0" />
                        <span>{rec}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            )}
          </div>

          {/* History Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-gray-900 border border-gray-800 rounded-xl p-6 sticky top-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold flex items-center gap-2">
                  <Clock className="w-5 h-5 text-cyan-400" />
                  Recent Analysis
                </h2>
                <button
                  onClick={() => setShowHistory(!showHistory)}
                  className="text-sm text-cyan-400 hover:text-cyan-300"
                >
                  {showHistory ? 'Hide' : 'Show'}
                </button>
              </div>

              {showHistory && (
                <div className="space-y-3 max-h-[600px] overflow-y-auto custom-scrollbar">
                  {history.length === 0 ? (
                    <p className="text-gray-500 text-sm text-center py-8">
                      No analysis history yet
                    </p>
                  ) : (
                    history.map(item => (
                      <div
                        key={item.id}
                        onClick={() => item.status === 'success' && setIndicator(item.indicator)}
                        className="p-3 rounded-lg border bg-gray-800/50 border-gray-700 hover:bg-gray-800 cursor-pointer transition-colors"
                      >
                        <div className="text-sm font-medium text-white mb-2 truncate">
                          {item.indicator}
                        </div>
                        <div className="flex items-center justify-between mb-1">
                          <span
                            className={`text-xs px-2 py-0.5 rounded ${getThreatColor(item.threatLevel)}`}
                          >
                            {item.threatLevel}
                          </span>
                          <span className={`text-xs font-bold ${getScoreColor(item.riskScore)}`}>
                            {item.riskScore}
                          </span>
                        </div>
                        <div className="text-xs text-gray-500">
                          {formatTimestamp(item.timestamp)}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 6px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: #1f2937; border-radius: 3px; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #4b5563; border-radius: 3px; }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: #6b7280; }
      `}</style>
    </div>
  );
};

export default ThreatIntelligencePage;
