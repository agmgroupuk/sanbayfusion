import React, { useState, useEffect } from 'react';
import {
  MapPin,
  Globe,
  Shield,
  Clock,
  Server,
  Network,
  Eye,
  Search,
  Copy,
  Check,
  AlertCircle,
  Info,
  Zap,
  Activity,
  Lock,
  AlertTriangle,
  TrendingUp,
  Database,
  Download,
  Upload,
  History,
  Trash2,
  RefreshCw,
} from 'lucide-react';
import { Page } from '../../App';
import DoctorNetworkChat from '../DoctorNetworkChat';
import { GoogleMap, LoadScript, Marker } from '@react-google-maps/api';
import { GOOGLE_MAPS_API_KEY, IPINFO_TOKEN } from '../../config';
import { authService } from '../../services/authService';

// Map container style
const mapContainerStyle = {
  width: '100%',
  height: '450px',
  borderRadius: '12px',
};

interface IPInfo {
  ip: string;
  hostname?: string;
  city?: string;
  region?: string;
  country: string;
  country_name?: string;
  country_code?: string;
  continent?: string;
  continent_code?: string;
  loc?: string;
  timezone?: string;
  org?: string;
  asn?: {
    asn: string;
    name: string;
    domain: string;
    route: string;
    type: string;
  };
  company?: {
    name: string;
    domain: string;
    type: string;
  };
  carrier?: {
    name: string;
    mcc: string;
    mnc: string;
  };
  privacy?: {
    vpn: boolean;
    proxy: boolean;
    tor: boolean;
    relay: boolean;
    hosting: boolean;
    service: string;
  };
  abuse?: {
    address: string;
    country: string;
    email: string;
    name: string;
    network: string;
    phone: string;
  };
  domains?: {
    page: number;
    total: number;
    domains: string[];
  };
  coordinates?: [number, number];
  postal?: string;
  flag?: string;
  flag_emoji?: string;
  languages?: string[];
  currency?: {
    code: string;
    symbol: string;
  };
  security?: {
    is_anonymous?: boolean;
    is_attacker?: boolean;
    is_bogon?: boolean;
    is_cloud_provider?: boolean;
    is_proxy?: boolean;
    is_relay?: boolean;
    is_tor?: boolean;
    is_tor_exit?: boolean;
    is_vpn?: boolean;
    is_hosting?: boolean;
    risk_score?: number;
    threat_types?: string[];
  };
}

interface HistoryEntry {
  id: string;
  ip: string;
  timestamp: string;
  country?: string;
  city?: string;
  org?: string;
  riskScore?: number;
  flag?: string;
}

interface GeolocationData {
  latitude: number;
  longitude: number;
  accuracy_radius: number;
  time_zone: string;
  metro_code?: number;
}

interface IPInfoPageProps {
  onNavigate: (page: Page) => void;
}

const IPInfoPage: React.FC<IPInfoPageProps> = ({ onNavigate }) => {
  const [currentIP, setCurrentIP] = useState<string>('');
  const [searchIP, setSearchIP] = useState<string>('');
  const [ipInfo, setIpInfo] = useState<IPInfo | null>(null);
  const [searchResults, setSearchResults] = useState<IPInfo | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [searchLoading, setSearchLoading] = useState<boolean>(false);
  const [error, setError] = useState<string>('');
  const [searchError, setSearchError] = useState<string>('');
  const [copied, setCopied] = useState<string>('');
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [showHistory, setShowHistory] = useState<boolean>(false);
  const [bulkInput, setBulkInput] = useState<string>('');
  const [bulkResults, setBulkResults] = useState<IPInfo[]>([]);
  const [bulkLoading, setBulkLoading] = useState<boolean>(false);
  const [showBulkLookup, setShowBulkLookup] = useState<boolean>(false);

  // Subscription state
  const [subscriptionStatus, setSubscriptionStatus] = useState<{
    hasAccess: boolean;
    usageCount?: number;
  } | null>(null);
  const [showSubscriptionModal, setShowSubscriptionModal] = useState(false);

  // Get visitor's IP info on page load
  useEffect(() => {
    fetchCurrentIPInfo();
    // Load history from localStorage
    const savedHistory = localStorage.getItem('ipLookupHistory');
    if (savedHistory) {
      try {
        setHistory(JSON.parse(savedHistory));
      } catch (e) {
        console.error('Failed to load history:', e);
      }
    }
  }, []);

  const fetchCurrentIPInfo = async () => {
    try {
      setLoading(true);
      setError('');

      const token = authService.getToken();
      if (!token) {
        setError('Please login to access IP lookup tools');
        setShowSubscriptionModal(true);
        return;
      }

      // Get user's current IP first
      const ipResponse = await fetch('https://api.ipify.org?format=json');
      const ipData = await ipResponse.json();
      const userIP = ipData.ip;

      // Use subscription-gated toolbox API
      const response = await fetch('/api/toolbox/network/ip-info', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({ ip: userIP }),
      });

      const data = await response.json();

      if (!response.ok) {
        if (response.status === 403) {
          setError('Subscription required for IP lookup tools');
          setShowSubscriptionModal(true);
          return;
        }
        throw new Error(data.error || 'Failed to fetch IP information');
      }

      if (data.success && data.data) {
        setCurrentIP(userIP);
        setIpInfo(data.data);
        setSubscriptionStatus({ hasAccess: true, usageCount: data.usageCount });
      } else {
        setError('Failed to detect your IP address');
      }
    } catch (err) {
      console.error('IP lookup error:', err);
      setError('⚠️ Unable to fetch IP information. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  const searchIPInfo = async () => {
    if (!searchIP.trim()) return;

    // Basic IP validation
    const ipRegex =
      /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    if (!ipRegex.test(searchIP.trim())) {
      setSearchError('Please enter a valid IPv4 address');
      return;
    }

    const token = authService.getToken();
    if (!token) {
      setSearchError('Please login to search IP addresses');
      setShowSubscriptionModal(true);
      return;
    }

    try {
      setSearchLoading(true);
      setSearchError('');

      // Use subscription-gated toolbox API
      const response = await fetch('/api/toolbox/network/ip-info', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({ ip: searchIP.trim() }),
        cache: 'no-cache',
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();

      if (data.ip) {
        setSearchResults(data);
        // Add to history
        addToHistory(data);
      } else if (data.error) {
        setSearchError(data.error || 'Failed to fetch IP information');
      } else {
        setSearchError('Invalid response from server');
      }
    } catch (err) {
      // Provide mock data for the searched IP with security analysis
      const mockData: IPInfo = {
        ip: searchIP.trim(),
        city: 'Demo City',
        region: 'Demo Region',
        country: 'Demo Country',
        country_name: 'Demo Country',
        country_code: 'XX',
        continent: 'XX',
        loc: '0.0,0.0',
        timezone: 'UTC',
        org: 'Demo Organization ISP',
        postal: '00000',
        coordinates: [0, 0],
        security: {
          is_vpn: false,
          is_proxy: false,
          is_tor: false,
          is_hosting: false,
          is_cloud_provider: false,
          is_anonymous: false,
          is_attacker: false,
          is_bogon: false,
          risk_score: 15,
          threat_types: [],
        },
        privacy: {
          vpn: false,
          proxy: false,
          tor: false,
          relay: false,
          hosting: false,
          service: 'Demo ISP Service',
        },
      };
      setSearchResults(mockData);
      setSearchError('⚠️ Demo Mode: Using sample data (API unavailable)');
      console.warn('IP API unavailable for search, using mock data:', err);
    } finally {
      setSearchLoading(false);
    }
  };

  // Advanced security checks using multiple free APIs
  const performSecurityChecks = async (ipInfo: IPInfo) => {
    // IPGeolocation API already provides all security data
    // This function is now a no-op but kept for compatibility
    // Security checks are done by the backend
    return;
  };

  // Check IP against multiple blacklists
  const checkBlacklists = async (
    ip: string
  ): Promise<{ isBlacklisted: boolean; lists: string[] }> => {
    const blacklistedOn: string[] = [];

    // List of popular RBLs (Real-time Blackhole Lists)
    const rbls = [
      'zen.spamhaus.org',
      'bl.spamcop.net',
      'dnsbl.sorbs.net',
      'cbl.abuseat.org',
      'b.barracudacentral.org',
    ];

    try {
      // Reverse IP for DNS lookup (e.g., 1.2.3.4 becomes 4.3.2.1)
      const reversedIP = ip.split('.').reverse().join('.');

      // Check each RBL
      for (const rbl of rbls) {
        try {
          const dnsQuery = `${reversedIP}.${rbl}`;
          // Note: DNS lookups from browser are limited, this is a simplified check
          // In production, this would be done server-side
          const response = await fetch(`https://dns.google/resolve?name=${dnsQuery}&type=A`);
          if (response.ok) {
            const data = await response.json();
            if (data.Answer && data.Answer.length > 0) {
              blacklistedOn.push(rbl);
            }
          }
        } catch (e) {
          // RBL check failed, continue with others
          continue;
        }
      }
    } catch (error) {
      console.warn('Blacklist check failed:', error);
    }

    return {
      isBlacklisted: blacklistedOn.length > 0,
      lists: blacklistedOn,
    };
  };

  const addToHistory = (ipData: IPInfo) => {
    const entry: HistoryEntry = {
      id: Date.now().toString(),
      ip: ipData.ip,
      timestamp: new Date().toISOString(),
      country: ipData.country_name || ipData.country,
      city: ipData.city,
      org: ipData.org,
      riskScore: ipData.security?.risk_score,
      flag: ipData.flag_emoji,
    };

    const newHistory = [entry, ...history.filter(h => h.ip !== ipData.ip).slice(0, 19)];
    setHistory(newHistory);
    localStorage.setItem('ipLookupHistory', JSON.stringify(newHistory));
  };

  const loadFromHistory = async (ip: string) => {
    setSearchIP(ip);
    setShowHistory(false);
    // Trigger search
    try {
      setSearchLoading(true);
      setSearchError('');

      const response = await fetch(`/api/ip/info/${ip}`);
      const data = await response.json();

      if (data.success) {
        setSearchResults(data.data);
      } else {
        setSearchError(data.error || 'Failed to fetch IP information');
      }
    } catch (err) {
      setSearchError('Network error occurred');
    } finally {
      setSearchLoading(false);
    }
  };

  const clearHistory = () => {
    setHistory([]);
    localStorage.removeItem('ipLookupHistory');
  };

  const bulkLookup = async () => {
    const ips = bulkInput
      .split('\n')
      .map(ip => ip.trim())
      .filter(ip => {
        const ipRegex =
          /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
        return ipRegex.test(ip);
      });

    if (ips.length === 0) {
      setSearchError('Please enter valid IPv4 addresses (one per line)');
      return;
    }

    if (ips.length > 20) {
      setSearchError('Maximum 20 IPs allowed per bulk lookup');
      return;
    }

    try {
      setBulkLoading(true);
      setSearchError('');

      const results = await Promise.all(
        ips.map(async ip => {
          try {
            const response = await fetch(`/api/ip/info/${ip}`);
            const data = await response.json();
            return data.success ? data.data : null;
          } catch {
            return null;
          }
        })
      );

      const validResults = results.filter((r): r is IPInfo => r !== null);
      setBulkResults(validResults);

      // Add all to history
      validResults.forEach(addToHistory);
    } catch (err) {
      setSearchError('Bulk lookup error occurred');
      console.error('Error in bulk lookup:', err);
    } finally {
      setBulkLoading(false);
    }
  };

  const exportResults = (data: IPInfo | IPInfo[], filename: string) => {
    const exportData = Array.isArray(data) ? data : [data];
    const json = JSON.stringify(exportData, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${filename}-${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const exportHistory = () => {
    if (history.length === 0) return;
    const csv = [
      'IP,Country,City,Organization,Risk Score,Timestamp',
      ...history.map(
        h =>
          `${h.ip},"${h.country || ''}","${h.city || ''}","${h.org || ''}",${h.riskScore || ''},${h.timestamp}`
      ),
    ].join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ip-lookup-history-${Date.now()}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const copyToClipboard = async (text: string, type: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(type);
      setTimeout(() => setCopied(''), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  const formatCoordinates = (loc?: string): [number, number] | null => {
    if (!loc) return null;
    const [lat, lng] = loc.split(',').map(Number);
    return [lat, lng];
  };

  const getRiskLevel = (score?: number): { level: string; color: string; description: string } => {
    if (!score)
      return { level: 'Unknown', color: 'gray', description: 'Risk assessment unavailable' };

    if (score >= 75)
      return {
        level: 'High Risk',
        color: 'red',
        description: 'High probability of malicious activity',
      };
    if (score >= 50)
      return {
        level: 'Medium Risk',
        color: 'yellow',
        description: 'Moderate risk indicators detected',
      };
    if (score >= 25)
      return { level: 'Low Risk', color: 'orange', description: 'Some risk factors present' };
    return { level: 'Safe', color: 'green', description: 'Low risk of malicious activity' };
  };

  const InfoCard: React.FC<{
    title: string;
    value: string | undefined;
    icon: React.ReactNode;
    copyable?: boolean;
    type?: string;
  }> = ({ title, value, icon, copyable = false, type = '' }) => (
    <div className="bg-gray-900/50 rounded-xl p-5 border border-gray-800 hover:border-cyan-500/50 transition-all hover:shadow-lg hover:shadow-cyan-500/10">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <div className="text-cyan-400">{icon}</div>
          <span className="text-sm font-medium text-gray-400">{title}</span>
        </div>
        {copyable && value && (
          <button
            onClick={() => copyToClipboard(value, type)}
            className="p-1 hover:bg-gray-800 rounded transition-colors text-gray-500 hover:text-cyan-400"
            title="Copy to clipboard"
          >
            {copied === type ? (
              <Check className="w-4 h-4 text-green-400" />
            ) : (
              <Copy className="w-4 h-4" />
            )}
          </button>
        )}
      </div>
      <p className="text-base font-semibold text-cyan-300 break-all">{value || '—'}</p>
    </div>
  );

  const SecurityBadge: React.FC<{ label: string; isTrue: boolean | undefined }> = ({
    label,
    isTrue,
  }) => (
    <div
      className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${
        isTrue === undefined
          ? 'bg-gray-800/50 text-gray-400'
          : isTrue
            ? 'bg-red-500/20 text-red-300 border border-red-500/30'
            : 'bg-green-500/20 text-green-300 border border-green-500/30'
      }`}
    >
      {isTrue === undefined ? '?' : isTrue ? '⚠' : '✓'} {label}
    </div>
  );

  const renderIPDetails = (data: IPInfo | null, title: string) => {
    if (!data) return null;

    const coordinates = formatCoordinates(data.loc);
    const risk = getRiskLevel(data.security?.risk_score);

    return (
      <div className="space-y-8">
        {/* Header */}
        <div className="bg-gradient-to-b from-gray-900/50 to-gray-900/20 rounded-2xl p-8 border border-gray-800 backdrop-blur">
          <h3 className="text-2xl font-bold text-white flex items-center gap-3">
            <TrendingUp className="w-6 h-6 text-cyan-400" />
            {title}
          </h3>
        </div>

        {/* IP Address Overview */}
        <div className="bg-gradient-to-b from-gray-900/50 to-gray-900/20 rounded-2xl p-8 border border-gray-800 backdrop-blur">
          <h4 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
            <Globe className="w-5 h-5 text-cyan-400" />
            IP Address Information
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            <InfoCard
              title="IP Address"
              value={data.ip}
              icon={<Globe className="w-4 h-4" />}
              copyable
              type="ip"
            />
            <InfoCard
              title="Hostname"
              value={data.hostname}
              icon={<Server className="w-4 h-4" />}
              copyable
              type="hostname"
            />
            <InfoCard
              title="ISP/Organization"
              value={data.org}
              icon={<Network className="w-4 h-4" />}
              copyable
              type="org"
            />
            <InfoCard
              title="Country"
              value={
                data.country_name ? `${data.country_name} ${data.flag_emoji || ''}` : data.country
              }
              icon={<MapPin className="w-4 h-4" />}
            />
            <InfoCard title="City" value={data.city} icon={<MapPin className="w-4 h-4" />} />
            <InfoCard title="Region" value={data.region} icon={<MapPin className="w-4 h-4" />} />
            <InfoCard title="Timezone" value={data.timezone} icon={<Clock className="w-4 h-4" />} />
            <InfoCard
              title="Postal Code"
              value={data.postal}
              icon={<MapPin className="w-4 h-4 text-pink-500" />}
            />
            {data.currency && (
              <InfoCard
                title="Currency"
                value={`${data.currency.code} (${data.currency.symbol})`}
                icon={<Zap className="w-4 h-4 text-green-600" />}
              />
            )}
          </div>
        </div>

        {/* Google Map Location */}
        {coordinates && (
          <div className="bg-gradient-to-br from-gray-900/50 to-black rounded-2xl p-6 border border-gray-800">
            <h4 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
              <MapPin className="w-5 h-5 text-cyan-400" />
              Interactive Location Map
            </h4>
            <div className="rounded-xl overflow-hidden border border-gray-700 shadow-2xl">
              <LoadScript googleMapsApiKey={GOOGLE_MAPS_API_KEY}>
                <GoogleMap
                  mapContainerStyle={mapContainerStyle}
                  center={{ lat: coordinates[0], lng: coordinates[1] }}
                  zoom={12}
                  options={{
                    styles: [
                      {
                        elementType: 'geometry',
                        stylers: [{ color: '#212121' }],
                      },
                      {
                        elementType: 'labels.icon',
                        stylers: [{ visibility: 'off' }],
                      },
                      {
                        elementType: 'labels.text.fill',
                        stylers: [{ color: '#757575' }],
                      },
                      {
                        elementType: 'labels.text.stroke',
                        stylers: [{ color: '#212121' }],
                      },
                      {
                        featureType: 'administrative',
                        elementType: 'geometry',
                        stylers: [{ color: '#757575' }],
                      },
                      {
                        featureType: 'poi',
                        elementType: 'labels.text.fill',
                        stylers: [{ color: '#757575' }],
                      },
                      {
                        featureType: 'poi.park',
                        elementType: 'geometry',
                        stylers: [{ color: '#181818' }],
                      },
                      {
                        featureType: 'poi.park',
                        elementType: 'labels.text.fill',
                        stylers: [{ color: '#616161' }],
                      },
                      {
                        featureType: 'road',
                        elementType: 'geometry.fill',
                        stylers: [{ color: '#2c2c2c' }],
                      },
                      {
                        featureType: 'road',
                        elementType: 'labels.text.fill',
                        stylers: [{ color: '#8a8a8a' }],
                      },
                      {
                        featureType: 'road.arterial',
                        elementType: 'geometry',
                        stylers: [{ color: '#373737' }],
                      },
                      {
                        featureType: 'road.highway',
                        elementType: 'geometry',
                        stylers: [{ color: '#3c3c3c' }],
                      },
                      {
                        featureType: 'water',
                        elementType: 'geometry',
                        stylers: [{ color: '#000000' }],
                      },
                      {
                        featureType: 'water',
                        elementType: 'labels.text.fill',
                        stylers: [{ color: '#3d3d3d' }],
                      },
                    ],
                    disableDefaultUI: false,
                    zoomControl: true,
                    mapTypeControl: false,
                    scaleControl: true,
                    streetViewControl: false,
                    rotateControl: false,
                    fullscreenControl: true,
                  }}
                >
                  <Marker
                    position={{ lat: coordinates[0], lng: coordinates[1] }}
                    title={`${data.city || 'Location'}, ${data.country_name || data.country}`}
                    icon={{
                      url: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iNDIiIHZpZXdCb3g9IjAgMCAzMiA0MiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJNMTYgMEMxMC40NzcgMCA2IDQuNDc3IDYgMTBDNiAxNy41IDE2IDMyIDE2IDMyQzE2IDMyIDI2IDE3LjUgMjYgMTBDMjYgNC40NzcgMjEuNTIzIDAgMTYgMFpNMTYgMTRDMTMuNzkgMTQgMTIgMTIuMjEgMTIgMTBDMTIgNy43OSAxMy43OSA2IDE2IDZDMTguMjEgNiAyMCA3Ljc5IDIwIDEwQzIwIDEyLjIxIDE4LjIxIDE0IDE2IDE0WiIgZmlsbD0iIzAwYmNkNCIvPjwvc3ZnPg==',
                    }}
                  />
                </GoogleMap>
              </LoadScript>
            </div>
            <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="bg-gray-800/50 rounded-lg p-3 border border-gray-700">
                <p className="text-xs text-gray-400 mb-1">Coordinates</p>
                <p className="text-sm font-mono text-cyan-400">
                  {coordinates[0].toFixed(6)}, {coordinates[1].toFixed(6)}
                </p>
              </div>
              <div className="bg-gray-800/50 rounded-lg p-3 border border-gray-700">
                <p className="text-xs text-gray-400 mb-1">Location</p>
                <p className="text-sm text-white">
                  {data.city && data.country_name
                    ? `${data.city}, ${data.country_name}`
                    : data.country_name || data.country || 'Unknown'}
                </p>
              </div>
            </div>
            <div className="mt-3">
              <a
                href={`https://www.google.com/maps?q=${coordinates[0]},${coordinates[1]}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto px-6 py-3 bg-gradient-to-r from-cyan-500 to-blue-500 text-black font-semibold rounded-lg hover:shadow-lg hover:shadow-cyan-500/50 transition-all flex items-center justify-center gap-2"
              >
                <Globe className="w-4 h-4" />
                Open in Google Maps
              </a>
            </div>
          </div>
        )}

        {/* Geographic Information */}
        <div className="bg-gradient-to-b from-gray-900/50 to-gray-900/20 rounded-2xl p-8 border border-gray-800 backdrop-blur">
          <h4 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
            <MapPin className="w-5 h-5 text-cyan-400" />
            Geographic Information
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <InfoCard
              title="Continent"
              value={data.continent}
              icon={<Globe className="w-4 h-4 text-blue-500" />}
            />
            <InfoCard
              title="Country Code"
              value={data.country_code}
              icon={<MapPin className="w-4 h-4 text-green-500" />}
            />
            {coordinates && (
              <>
                <InfoCard
                  title="Latitude"
                  value={coordinates[0].toString()}
                  icon={<MapPin className="w-4 h-4 text-red-500" />}
                  copyable
                  type="lat"
                />
                <InfoCard
                  title="Longitude"
                  value={coordinates[1].toString()}
                  icon={<MapPin className="w-4 h-4 text-orange-500" />}
                  copyable
                  type="lng"
                />
                <InfoCard
                  title="Coordinates"
                  value={data.loc}
                  icon={<MapPin className="w-4 h-4 text-purple-500" />}
                  copyable
                  type="coordinates"
                />
              </>
            )}
            {data.languages && (
              <InfoCard
                title="Languages"
                value={data.languages.join(', ')}
                icon={<Globe className="w-4 h-4 text-indigo-500" />}
              />
            )}
          </div>
        </div>

        {/* Network Information */}
        <div className="bg-gradient-to-b from-gray-900/50 to-gray-900/20 rounded-2xl p-8 border border-gray-800 backdrop-blur">
          <h4 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
            <Network className="w-5 h-5 text-cyan-400" />
            Network Information
          </h4>

          {/* ASN Information */}
          {data.asn && (
            <div className="mb-8">
              <h5 className="text-lg font-semibold text-gray-300 mb-4">ASN Details</h5>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <InfoCard
                  title="ASN"
                  value={data.asn.asn}
                  icon={<Network className="w-4 h-4 text-blue-500" />}
                  copyable
                  type="asn"
                />
                <InfoCard
                  title="Name"
                  value={data.asn.name}
                  icon={<Server className="w-4 h-4 text-green-500" />}
                />
                <InfoCard
                  title="Domain"
                  value={data.asn.domain}
                  icon={<Globe className="w-4 h-4 text-purple-500" />}
                  copyable
                  type="asn-domain"
                />
                <InfoCard
                  title="Route"
                  value={data.asn.route}
                  icon={<Activity className="w-4 h-4 text-orange-500" />}
                  copyable
                  type="route"
                />
                <InfoCard
                  title="Type"
                  value={data.asn.type}
                  icon={<Info className="w-4 h-4 text-indigo-500" />}
                />
              </div>
            </div>
          )}

          {/* Company Information */}
          {data.company && (
            <div className="mb-8">
              <h5 className="text-lg font-semibold text-gray-300 mb-4">Company Details</h5>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <InfoCard
                  title="Company Name"
                  value={data.company.name}
                  icon={<Server className="w-4 h-4 text-blue-500" />}
                />
                <InfoCard
                  title="Domain"
                  value={data.company.domain}
                  icon={<Globe className="w-4 h-4 text-green-500" />}
                  copyable
                  type="company-domain"
                />
                <InfoCard
                  title="Type"
                  value={data.company.type}
                  icon={<Info className="w-4 h-4 text-purple-500" />}
                />
              </div>
            </div>
          )}

          {/* Carrier Information */}
          {data.carrier && (
            <div className="mb-8">
              <h5 className="text-lg font-semibold text-gray-300 mb-4">Carrier Information</h5>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <InfoCard
                  title="Carrier Name"
                  value={data.carrier.name}
                  icon={<Network className="w-4 h-4 text-blue-500" />}
                />
                <InfoCard
                  title="MCC"
                  value={data.carrier.mcc}
                  icon={<Info className="w-4 h-4 text-green-500" />}
                />
                <InfoCard
                  title="MNC"
                  value={data.carrier.mnc}
                  icon={<Info className="w-4 h-4 text-purple-500" />}
                />
              </div>
            </div>
          )}

          {/* Domains */}
          {data.domains && data.domains.domains.length > 0 && (
            <div>
              <h5 className="text-lg font-semibold text-gray-300 mb-4">
                Associated Domains ({data.domains.total} total)
              </h5>
              <div className="flex flex-wrap gap-2">
                {data.domains.domains.slice(0, 10).map((domain, index) => (
                  <span
                    key={index}
                    className="px-3 py-1 bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 rounded-full text-sm font-medium cursor-pointer hover:bg-cyan-500/20 transition-all"
                    onClick={() => copyToClipboard(domain, `domain-${index}`)}
                    title="Click to copy"
                  >
                    {domain}
                  </span>
                ))}
                {data.domains.domains.length > 10 && (
                  <span className="px-3 py-1 bg-gray-800/50 text-gray-400 rounded-full text-sm border border-gray-700">
                    +{data.domains.domains.length - 10} more
                  </span>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Security Information */}
        <div className="bg-gradient-to-b from-gray-900/50 to-gray-900/20 rounded-2xl p-8 border border-gray-800 backdrop-blur">
          <h4 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
            <Shield className="w-5 h-5 text-cyan-400" />
            Security Information
          </h4>

          {/* Risk Score */}
          {data.security?.risk_score !== undefined && (
            <div className="mb-8 bg-gray-800/30 rounded-xl p-6 border border-gray-700">
              <div className="flex items-center justify-between mb-4">
                <h5 className="text-lg font-semibold text-white">Risk Assessment</h5>
                <div
                  className={`px-3 py-1 rounded-full text-sm font-medium ${
                    risk.level === 'Low'
                      ? 'bg-green-500/20 text-green-400 border border-green-500/30'
                      : risk.level === 'Medium'
                        ? 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/30'
                        : 'bg-red-500/20 text-red-400 border border-red-500/30'
                  }`}
                >
                  {risk.level}
                </div>
              </div>
              <div className="mb-2">
                <div className="flex justify-between text-sm text-gray-400 mb-2">
                  <span>Risk Score</span>
                  <span className="font-semibold text-white">{data.security.risk_score}/100</span>
                </div>
                <div className="w-full bg-gray-700/50 rounded-full h-3 overflow-hidden">
                  <div
                    className={`h-3 rounded-full transition-all ${
                      risk.level === 'Low'
                        ? 'bg-gradient-to-r from-green-500 to-green-400'
                        : risk.level === 'Medium'
                          ? 'bg-gradient-to-r from-yellow-500 to-yellow-400'
                          : 'bg-gradient-to-r from-red-500 to-red-400'
                    }`}
                    style={{ width: `${data.security.risk_score}%` }}
                  ></div>
                </div>
              </div>
              <p className="text-sm text-gray-400 mt-3">{risk.description}</p>
            </div>
          )}

          {/* Security Indicators */}
          {data.security && (
            <div className="mb-8">
              <h5 className="text-lg font-semibold text-gray-300 mb-4">Security Indicators</h5>
              <div className="flex flex-wrap gap-2">
                <SecurityBadge
                  label="VPN"
                  isTrue={data.security.is_vpn ?? data.privacy?.vpn ?? false}
                />
                <SecurityBadge
                  label="Proxy"
                  isTrue={data.security.is_proxy ?? data.privacy?.proxy ?? false}
                />
                <SecurityBadge
                  label="Tor"
                  isTrue={data.security.is_tor ?? data.privacy?.tor ?? false}
                />
                <SecurityBadge
                  label="Hosting"
                  isTrue={data.security.is_hosting ?? data.privacy?.hosting ?? false}
                />
                <SecurityBadge
                  label="Cloud Provider"
                  isTrue={data.security.is_cloud_provider ?? false}
                />
                <SecurityBadge label="Anonymous" isTrue={data.security.is_anonymous ?? false} />
                <SecurityBadge label="Attacker" isTrue={data.security.is_attacker ?? false} />
                <SecurityBadge label="Bogon" isTrue={data.security.is_bogon ?? false} />
              </div>
            </div>
          )}

          {/* VPN/Proxy Detection */}
          {data.privacy && (data.privacy.vpn || data.privacy.proxy || data.privacy.tor) && (
            <div className="mb-8 bg-orange-500/10 border border-orange-500/30 rounded-xl p-6">
              <h5 className="text-lg font-semibold text-orange-400 mb-4 flex items-center gap-2">
                <Eye className="w-5 h-5" />
                Anonymization Detection
              </h5>
              <div className="space-y-3">
                {data.privacy.vpn && (
                  <div className="flex items-center justify-between p-3 bg-orange-500/5 rounded-lg border border-orange-500/20">
                    <div className="flex items-center gap-2">
                      <Lock className="w-4 h-4 text-orange-400" />
                      <span className="text-sm font-medium text-white">VPN Detected</span>
                    </div>
                    <span className="px-2 py-1 bg-orange-500/20 text-orange-400 rounded text-xs font-medium">
                      ACTIVE
                    </span>
                  </div>
                )}
                {data.privacy.proxy && (
                  <div className="flex items-center justify-between p-3 bg-orange-500/5 rounded-lg border border-orange-500/20">
                    <div className="flex items-center gap-2">
                      <Network className="w-4 h-4 text-orange-400" />
                      <span className="text-sm font-medium text-white">Proxy Server</span>
                    </div>
                    <span className="px-2 py-1 bg-orange-500/20 text-orange-400 rounded text-xs font-medium">
                      DETECTED
                    </span>
                  </div>
                )}
                {data.privacy.tor && (
                  <div className="flex items-center justify-between p-3 bg-red-500/10 rounded-lg border border-red-500/30">
                    <div className="flex items-center gap-2">
                      <Shield className="w-4 h-4 text-red-400" />
                      <span className="text-sm font-medium text-white">TOR Exit Node</span>
                    </div>
                    <span className="px-2 py-1 bg-red-500/20 text-red-400 rounded text-xs font-medium">
                      TOR
                    </span>
                  </div>
                )}
                {data.privacy.service && (
                  <div className="text-xs text-gray-400 mt-3 p-3 bg-gray-800/30 rounded-lg border border-gray-700">
                    <strong className="text-white">Service:</strong> {data.privacy.service}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Threat Types / Blacklist */}
          {data.security?.threat_types && data.security.threat_types.length > 0 && (
            <div className="mb-8 bg-red-500/10 border border-red-500/30 rounded-xl p-6">
              <h5 className="text-lg font-semibold text-red-400 mb-4 flex items-center gap-2">
                <AlertCircle className="w-5 h-5" />
                Blacklist Detection
              </h5>
              <div className="space-y-3">
                <div className="flex items-center gap-2 p-3 bg-red-500/5 rounded-lg border border-red-500/20">
                  <AlertTriangle className="w-5 h-5 text-red-400" />
                  <span className="text-sm font-medium text-white">
                    This IP is listed on {data.security.threat_types.length} blacklist(s)
                  </span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {data.security.threat_types.map((rbl, index) => (
                    <span
                      key={index}
                      className="px-3 py-1 bg-red-500/20 text-red-400 rounded-full text-xs font-medium flex items-center gap-1 border border-red-500/30"
                    >
                      <Shield className="w-3 h-3" />
                      {rbl}
                    </span>
                  ))}
                </div>
                <p className="text-xs text-gray-400 mt-3 p-3 bg-gray-800/30 rounded-lg border border-gray-700">
                  ⚠️ Blacklisted IPs may be associated with spam, malware, or malicious activity
                </p>
              </div>
            </div>
          )}

          {/* Abuse Contact */}
          {data.abuse && (
            <div>
              <h5 className="text-lg font-semibold text-gray-300 mb-4">Abuse Contact</h5>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <InfoCard
                  title="Contact Name"
                  value={data.abuse.name}
                  icon={<Info className="w-4 h-4 text-blue-500" />}
                />
                <InfoCard
                  title="Email"
                  value={data.abuse.email}
                  icon={<Info className="w-4 h-4 text-green-500" />}
                  copyable
                  type="abuse-email"
                />
                <InfoCard
                  title="Phone"
                  value={data.abuse.phone}
                  icon={<Info className="w-4 h-4 text-purple-500" />}
                  copyable
                  type="abuse-phone"
                />
                <InfoCard
                  title="Address"
                  value={data.abuse.address}
                  icon={<MapPin className="w-4 h-4 text-red-500" />}
                />
              </div>
            </div>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Subscription Modal */}
      {showSubscriptionModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-gray-900 rounded-2xl border border-gray-800 p-8 max-w-md w-full">
            <div className="text-center mb-6">
              <Lock className="w-16 h-16 text-cyan-400 mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-white mb-2">Subscription Required</h3>
              <p className="text-gray-400">
                IP lookup tools require an active IAMAI subscription. Any active daily, weekly, or
                monthly plan unlocks these tools.
              </p>
            </div>

            <div className="space-y-4 mb-6">
              <div className="bg-gray-800 rounded-lg p-4">
                <div className="flex items-center gap-3 mb-2">
                  <Globe className="w-5 h-5 text-cyan-400" />
                  <span className="font-semibold">Premium Features</span>
                </div>
                <ul className="text-sm text-gray-400 space-y-1">
                  <li>• Detailed IP geolocation</li>
                  <li>• VPN/Proxy detection</li>
                  <li>• Security threat analysis</li>
                  <li>• Bulk IP lookup</li>
                  <li>• Unlimited daily usage</li>
                </ul>
              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => setShowSubscriptionModal(false)}
                className="flex-1 px-4 py-2 bg-gray-800 hover:bg-gray-700 rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  setShowSubscriptionModal(false);
                  onNavigate('ai-lab' as Page);
                }}
                className="flex-1 px-4 py-2 bg-cyan-500 hover:bg-cyan-600 rounded-lg transition-colors font-semibold"
              >
                Subscribe Now
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Usage Badge */}
      {subscriptionStatus?.hasAccess && (
        <div className="fixed top-4 right-4 z-40 bg-gray-900/90 backdrop-blur-sm rounded-lg border border-gray-800 px-4 py-2">
          <div className="flex items-center gap-2 text-sm">
            <Activity className="w-4 h-4 text-green-400" />
            <span className="text-gray-300">Usage: </span>
            <span className="text-green-400 font-semibold">
              {subscriptionStatus.usageCount || 0}
            </span>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="border-b border-gray-800 bg-gradient-to-b from-gray-900 to-black">
        <div className="max-w-7xl mx-auto px-4 py-12 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-cyan-500/10 rounded-full border border-cyan-500/30 mb-4">
              <Globe className="w-4 h-4 text-cyan-400" />
              <span className="text-sm font-medium text-cyan-400">Advanced IP Analysis</span>
            </div>
            <h1 className="text-5xl font-extrabold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-blue-400">
              IP Address Lookup
            </h1>
            <p className="text-lg text-gray-400 max-w-3xl mx-auto">
              Real-time geolocation, security assessment, network information, VPN/proxy detection,
              and threat analysis all in one place
            </p>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-12 sm:px-6 lg:px-8">
        {/* Search Section */}
        <div className="bg-gradient-to-b from-gray-900/50 to-gray-900/20 rounded-2xl border border-gray-800 p-8 mb-12 backdrop-blur">
          <div className="flex flex-col gap-4">
            <label
              htmlFor="ip-search"
              className="flex items-center gap-2 text-sm font-semibold text-gray-300"
            >
              <Search className="w-4 h-4 text-cyan-400" />
              Enter IP Address to Analyze
            </label>
            <div className="flex flex-col sm:flex-row gap-4">
              <input
                id="ip-search"
                type="text"
                value={searchIP}
                onChange={e => setSearchIP(e.target.value)}
                placeholder="e.g., 8.8.8.8 or 1.1.1.1"
                className="flex-1 px-6 py-3 bg-gray-800/50 border border-gray-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-cyan-500/50 focus:border-cyan-500 text-white placeholder-gray-500 transition-all"
                onKeyPress={e => e.key === 'Enter' && searchIPInfo()}
              />
              <button
                onClick={searchIPInfo}
                disabled={searchLoading || !searchIP.trim()}
                className="px-8 py-3 bg-gradient-to-r from-cyan-500 to-blue-500 text-black font-semibold rounded-xl hover:shadow-lg hover:shadow-cyan-500/50 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-2 whitespace-nowrap"
              >
                {searchLoading ? (
                  <>
                    <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin"></div>
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Search className="w-4 h-4" />
                    Analyze IP
                  </>
                )}
              </button>
            </div>
            {searchError && (
              <div className="flex items-center gap-2 p-3 bg-red-500/10 border border-red-500/30 rounded-lg">
                <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0" />
                <p className="text-sm text-red-300">{searchError}</p>
              </div>
            )}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <button
            onClick={() => setShowHistory(!showHistory)}
            className="px-4 py-3 bg-gray-900/50 border border-gray-800 hover:border-cyan-500/50 rounded-xl transition-all flex items-center justify-center gap-2 group"
          >
            <History className="w-4 h-4 text-cyan-400 group-hover:animate-pulse" />
            <span className="text-sm font-medium">History ({history.length})</span>
          </button>
          <button
            onClick={() => setShowBulkLookup(!showBulkLookup)}
            className="px-4 py-3 bg-gray-900/50 border border-gray-800 hover:border-purple-500/50 rounded-xl transition-all flex items-center justify-center gap-2 group"
          >
            <Upload className="w-4 h-4 text-purple-400 group-hover:animate-pulse" />
            <span className="text-sm font-medium">Bulk Lookup</span>
          </button>
          <button
            onClick={() => history.length > 0 && exportHistory()}
            disabled={history.length === 0}
            className="px-4 py-3 bg-gray-900/50 border border-gray-800 hover:border-green-500/50 rounded-xl transition-all flex items-center justify-center gap-2 group disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Download className="w-4 h-4 text-green-400 group-hover:animate-pulse" />
            <span className="text-sm font-medium">Export CSV</span>
          </button>
          <button
            onClick={() => searchResults && exportResults(searchResults, 'ip-info')}
            disabled={!searchResults}
            className="px-4 py-3 bg-gray-900/50 border border-gray-800 hover:border-blue-500/50 rounded-xl transition-all flex items-center justify-center gap-2 group disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Download className="w-4 h-4 text-blue-400 group-hover:animate-pulse" />
            <span className="text-sm font-medium">Export JSON</span>
          </button>
        </div>

        {/* History Panel */}
        {showHistory && history.length > 0 && (
          <div className="bg-gray-900/50 rounded-2xl border border-gray-800 p-6 mb-8">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold flex items-center gap-2">
                <History className="w-5 h-5 text-cyan-400" />
                Recent Lookups ({history.length})
              </h3>
              <button
                onClick={clearHistory}
                className="px-3 py-1 text-sm bg-red-500/10 border border-red-500/30 hover:bg-red-500/20 rounded-lg text-red-400 transition-all flex items-center gap-1"
              >
                <Trash2 className="w-3 h-3" />
                Clear All
              </button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 max-h-96 overflow-y-auto">
              {history.map(entry => {
                const risk = getRiskLevel(entry.riskScore);
                return (
                  <button
                    key={entry.id}
                    onClick={() => loadFromHistory(entry.ip)}
                    className="p-4 bg-gray-800/50 hover:bg-gray-800 border border-gray-700 hover:border-cyan-500/50 rounded-xl transition-all text-left group"
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center gap-2">
                        {entry.flag && <span className="text-lg">{entry.flag}</span>}
                        <span className="font-mono text-cyan-400 font-semibold">{entry.ip}</span>
                      </div>
                      {entry.riskScore !== undefined && (
                        <span
                          className={`text-xs px-2 py-0.5 rounded-full bg-${risk.color}-500/20 text-${risk.color}-400 border border-${risk.color}-500/30`}
                        >
                          {entry.riskScore}
                        </span>
                      )}
                    </div>
                    <div className="text-xs text-gray-400 space-y-1">
                      {entry.city && entry.country && (
                        <div className="flex items-center gap-1">
                          <MapPin className="w-3 h-3" />
                          {entry.city}, {entry.country}
                        </div>
                      )}
                      {entry.org && (
                        <div className="flex items-center gap-1 truncate">
                          <Network className="w-3 h-3" />
                          {entry.org}
                        </div>
                      )}
                      <div className="flex items-center gap-1 text-gray-500 mt-2">
                        <Clock className="w-3 h-3" />
                        {new Date(entry.timestamp).toLocaleString()}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Bulk Lookup Panel */}
        {showBulkLookup && (
          <div className="bg-gray-900/50 rounded-2xl border border-gray-800 p-6 mb-8">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold flex items-center gap-2">
                <Upload className="w-5 h-5 text-purple-400" />
                Bulk IP Lookup
              </h3>
              <span className="text-xs text-gray-400">Max 20 IPs per request</span>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-sm text-gray-400 mb-2">
                  Enter IP addresses (one per line)
                </label>
                <textarea
                  value={bulkInput}
                  onChange={e => setBulkInput(e.target.value)}
                  placeholder="8.8.8.8&#10;1.1.1.1&#10;208.67.222.222&#10;..."
                  className="w-full h-48 px-4 py-3 bg-gray-800/50 border border-gray-700 rounded-xl text-white font-mono text-sm focus:outline-none focus:border-cyan-500 transition-all resize-none"
                />
              </div>
              <div className="flex gap-3">
                <button
                  onClick={bulkLookup}
                  disabled={bulkLoading || !bulkInput.trim()}
                  className="flex-1 px-6 py-3 bg-gradient-to-r from-purple-500 to-pink-500 text-black font-semibold rounded-xl hover:shadow-lg hover:shadow-purple-500/50 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  {bulkLoading ? (
                    <>
                      <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin"></div>
                      Processing...
                    </>
                  ) : (
                    <>
                      <Zap className="w-4 h-4" />
                      Analyze All
                    </>
                  )}
                </button>
                {bulkResults.length > 0 && (
                  <button
                    onClick={() => exportResults(bulkResults, 'bulk-ip-lookup')}
                    className="px-6 py-3 bg-gray-800 hover:bg-gray-700 border border-gray-700 rounded-xl transition-all flex items-center gap-2"
                  >
                    <Download className="w-4 h-4" />
                    Export Results
                  </button>
                )}
              </div>
            </div>

            {/* Bulk Results */}
            {bulkResults.length > 0 && (
              <div className="mt-6 space-y-4 max-h-[600px] overflow-y-auto">
                <h4 className="text-lg font-semibold flex items-center gap-2">
                  <Check className="w-5 h-5 text-green-400" />
                  Found {bulkResults.length} Results
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {bulkResults.map((result, idx) => {
                    const risk = getRiskLevel(result.security?.risk_score);
                    const coords = formatCoordinates(result.loc);
                    return (
                      <div
                        key={idx}
                        className="p-4 bg-gray-800/50 border border-gray-700 rounded-xl hover:border-cyan-500/50 transition-all"
                      >
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex items-center gap-2">
                            {result.flag_emoji && (
                              <span className="text-xl">{result.flag_emoji}</span>
                            )}
                            <span className="font-mono text-cyan-400 font-bold">{result.ip}</span>
                          </div>
                          {result.security?.risk_score !== undefined && (
                            <span
                              className={`text-xs px-2 py-1 rounded-full bg-${risk.color}-500/20 text-${risk.color}-400 border border-${risk.color}-500/30`}
                            >
                              Risk: {result.security.risk_score}
                            </span>
                          )}
                        </div>
                        <div className="space-y-2 text-sm">
                          <div className="flex items-center gap-2 text-gray-300">
                            <MapPin className="w-4 h-4 text-cyan-400" />
                            {result.city && result.country_name
                              ? `${result.city}, ${result.country_name}`
                              : result.country_name || result.country || 'Unknown'}
                          </div>
                          {result.org && (
                            <div className="flex items-center gap-2 text-gray-400 text-xs truncate">
                              <Network className="w-3 h-3" />
                              {result.org}
                            </div>
                          )}
                          {(result.privacy?.vpn ||
                            result.privacy?.proxy ||
                            result.privacy?.tor) && (
                            <div className="flex gap-1 mt-2">
                              {result.privacy.vpn && (
                                <span className="text-xs px-2 py-0.5 bg-red-500/20 text-red-400 border border-red-500/30 rounded">
                                  VPN
                                </span>
                              )}
                              {result.privacy.proxy && (
                                <span className="text-xs px-2 py-0.5 bg-red-500/20 text-red-400 border border-red-500/30 rounded">
                                  Proxy
                                </span>
                              )}
                              {result.privacy.tor && (
                                <span className="text-xs px-2 py-0.5 bg-red-500/20 text-red-400 border border-red-500/30 rounded">
                                  Tor
                                </span>
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Search Results */}
        {searchResults && (
          <div className="mb-12">
            <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
              <TrendingUp className="w-6 h-6 text-cyan-400" />
              Analysis Results for <span className="text-cyan-400">{searchResults.ip}</span>
            </h2>
            {renderIPDetails(searchResults, `Analysis Results for ${searchResults.ip}`)}
          </div>
        )}

        {/* Your IP Information */}
        <div className="space-y-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold mb-3 flex items-center justify-center gap-2">
              <Eye className="w-7 h-7 text-cyan-400" />
              <span>Your Current IP Information</span>
            </h2>
            <p className="text-gray-400">
              Automatically detected information about your current connection and location
            </p>
          </div>

          {loading ? (
            <div className="bg-gradient-to-b from-gray-900/50 to-gray-900/20 rounded-2xl border border-gray-800 p-16 text-center backdrop-blur">
              <div className="w-12 h-12 border-4 border-cyan-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
              <p className="text-gray-400">
                Detecting your IP address and gathering information...
              </p>
              <p className="text-sm text-gray-500 mt-2">This usually takes 2-5 seconds</p>
            </div>
          ) : error ? (
            <div className="bg-gradient-to-b from-gray-900/50 to-gray-900/20 rounded-2xl border border-red-500/20 p-12 text-center backdrop-blur">
              <AlertCircle className="w-12 h-12 text-red-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-white mb-2">
                Error Loading IP Information
              </h3>
              <p className="text-gray-400 mb-6">{error}</p>
              <button
                onClick={fetchCurrentIPInfo}
                className="px-6 py-2 bg-cyan-500 text-black font-semibold rounded-lg hover:bg-cyan-400 transition-colors"
              >
                Try Again
              </button>
            </div>
          ) : (
            ipInfo && renderIPDetails(ipInfo, `Your IP Information (${currentIP})`)
          )}
        </div>

        {/* Advanced Features Section */}
        <div className="mt-16">
          <h3 className="text-3xl font-bold text-center mb-12 text-white">
            Advanced IP Analysis Features
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-gradient-to-br from-gray-900/60 to-gray-900/20 border border-gray-800 rounded-2xl p-6 hover:border-cyan-500/50 transition-all hover:shadow-lg hover:shadow-cyan-500/10">
              <Shield className="w-10 h-10 text-cyan-400 mb-4" />
              <h4 className="font-bold text-white mb-2">Security Analysis</h4>
              <p className="text-sm text-gray-400">
                VPN, proxy, Tor detection and threat assessment with risk scoring
              </p>
            </div>
            <div className="bg-gradient-to-br from-gray-900/60 to-gray-900/20 border border-gray-800 rounded-2xl p-6 hover:border-cyan-500/50 transition-all hover:shadow-lg hover:shadow-cyan-500/10">
              <MapPin className="w-10 h-10 text-cyan-400 mb-4" />
              <h4 className="font-bold text-white mb-2">Geolocation</h4>
              <p className="text-sm text-gray-400">
                Precise location data with coordinates, timezone, and Google Maps integration
              </p>
            </div>
            <div className="bg-gradient-to-br from-gray-900/60 to-gray-900/20 border border-gray-800 rounded-2xl p-6 hover:border-cyan-500/50 transition-all hover:shadow-lg hover:shadow-cyan-500/10">
              <Network className="w-10 h-10 text-cyan-400 mb-4" />
              <h4 className="font-bold text-white mb-2">Network Details</h4>
              <p className="text-sm text-gray-400">
                ISP, ASN, carrier, organization, and associated domains information
              </p>
            </div>
            <div className="bg-gradient-to-br from-gray-900/60 to-gray-900/20 border border-gray-800 rounded-2xl p-6 hover:border-cyan-500/50 transition-all hover:shadow-lg hover:shadow-cyan-500/10">
              <Database className="w-10 h-10 text-cyan-400 mb-4" />
              <h4 className="font-bold text-white mb-2">Real-time Data</h4>
              <p className="text-sm text-gray-400">
                Live updates from multiple IP intelligence and threat databases
              </p>
            </div>
          </div>
        </div>

        {/* API Information */}
        <div className="mt-16 bg-gradient-to-r from-cyan-500/10 via-blue-500/10 to-purple-500/10 rounded-2xl border border-cyan-500/30 p-10 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-cyan-500/10 rounded-full border border-cyan-500/30 mb-6">
            <Zap className="w-4 h-4 text-cyan-400" />
            <span className="text-sm font-medium text-cyan-400">Powered by Premium Sources</span>
          </div>
          <h3 className="text-2xl font-bold mb-4 text-white">Comprehensive IP Intelligence</h3>
          <p className="text-gray-300 mb-8 max-w-3xl mx-auto">
            Our IP analysis combines data from multiple industry-leading sources including IPinfo,
            MaxMind GeoIP2, AbuseIPDB, and proprietary threat intelligence networks to deliver the
            most accurate and comprehensive results available.
          </p>
          <div className="flex flex-wrap justify-center gap-3">
            <span className="bg-gray-800/50 border border-gray-700 px-4 py-2 rounded-full text-sm text-gray-300 hover:border-cyan-500/50 transition-colors">
              📍 IPinfo API
            </span>
            <span className="bg-gray-800/50 border border-gray-700 px-4 py-2 rounded-full text-sm text-gray-300 hover:border-cyan-500/50 transition-colors">
              🌐 MaxMind GeoIP2
            </span>
            <span className="bg-gray-800/50 border border-gray-700 px-4 py-2 rounded-full text-sm text-gray-300 hover:border-cyan-500/50 transition-colors">
              ⚠️ Threat Intelligence
            </span>
            <span className="bg-gray-800/50 border border-gray-700 px-4 py-2 rounded-full text-sm text-gray-300 hover:border-cyan-500/50 transition-colors">
              🔄 Real-time Updates
            </span>
            <span className="bg-gray-800/50 border border-gray-700 px-4 py-2 rounded-full text-sm text-gray-300 hover:border-cyan-500/50 transition-colors">
              🛡️ Blacklist Checks
            </span>
          </div>
        </div>

        {/* FAQ Section */}
        <div className="mt-16">
          <h3 className="text-2xl font-bold mb-8 text-white">Frequently Asked Questions</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {[
              {
                q: 'Is my privacy protected?',
                a: 'Yes. Your data is never stored on our servers. All queries are processed in real-time and immediately discarded.',
              },
              {
                q: 'How accurate is the geolocation?',
                a: 'Our geolocation data is typically accurate to within city-level precision. Some ISPs may show office locations instead of exact user locations.',
              },
              {
                q: 'Can I detect VPN/Proxy usage?',
                a: 'Yes. We check multiple threat databases and ISP records to identify if an IP belongs to known VPN, proxy, or Tor services.',
              },
              {
                q: 'What data sources do you use?',
                a: 'We use IPinfo, MaxMind, AbuseIPDB, and other premium threat intelligence providers for the most accurate data.',
              },
            ].map((item, idx) => (
              <div
                key={idx}
                className="bg-gradient-to-br from-gray-900/50 to-gray-900/20 border border-gray-800 rounded-xl p-6"
              >
                <h4 className="font-semibold text-cyan-400 mb-2">{item.q}</h4>
                <p className="text-gray-400 text-sm">{item.a}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Doctor Network Chat Widget */}
      <DoctorNetworkChat
        currentIPData={{
          ip: currentIP || ipInfo?.ip,
          country: ipInfo?.country_name,
          city: ipInfo?.city,
          org: ipInfo?.org,
          security: ipInfo?.security,
        }}
      />
    </div>
  );
};

export default IPInfoPage;
