import React, { useState, useEffect } from 'react';
import {
  Search,
  Database,
  Clock,
  Globe,
  Shield,
  TrendingUp,
  Download,
  Copy,
  RefreshCw,
  Filter,
  X,
  CheckCircle,
  AlertCircle,
  Info,
  Calendar,
  User,
  Mail,
  Server,
  MapPin,
  ExternalLink,
  History,
} from 'lucide-react';

interface DomainResearchResult {
  domain: string;
  registrar: string;
  createdDate: string;
  expiresDate: string;
  updatedDate: string;
  status: string[];
  nameservers: string[];
  registrant: {
    name?: string;
    organization?: string;
    email?: string;
    phone?: string;
    country?: string;
  };
  admin: {
    name?: string;
    organization?: string;
    email?: string;
  };
  tech: {
    name?: string;
    email?: string;
  };
  dnssec: string;
  age: number;
}

interface HistoricalRecord {
  id: string;
  date: string;
  changes: string[];
  registrar: string;
}

interface RelatedDomain {
  domain: string;
  similarity: number;
  reason: string;
}

interface SearchHistory {
  id: string;
  domain: string;
  timestamp: number;
  success: boolean;
}

const DomainResearchSuitePage: React.FC = () => {
  const [domain, setDomain] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [result, setResult] = useState<DomainResearchResult | null>(null);
  const [activeTab, setActiveTab] = useState<'overview' | 'historical' | 'related' | 'monitoring'>(
    'overview'
  );
  const [searchHistory, setSearchHistory] = useState<SearchHistory[]>([]);
  const [historicalData, setHistoricalData] = useState<HistoricalRecord[]>([]);
  const [relatedDomains, setRelatedDomains] = useState<RelatedDomain[]>([]);
  const [showHistory, setShowHistory] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Stats for dashboard
  const [stats, setStats] = useState({
    totalSearches: 0,
    domainsTracked: 0,
    activeMonitors: 0,
    historicalRecords: 0,
  });

  // Load search history from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('domain_research_history');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setSearchHistory(parsed);
        setStats(prev => ({ ...prev, totalSearches: parsed.length }));
      } catch (e) {
        console.error('Failed to load history:', e);
      }
    }
  }, []);

  // Save history to localStorage
  useEffect(() => {
    if (searchHistory.length > 0) {
      localStorage.setItem('domain_research_history', JSON.stringify(searchHistory.slice(0, 50)));
    }
  }, [searchHistory]);

  const handleSearch = async () => {
    if (!domain.trim()) {
      setError('Please enter a domain name');
      return;
    }

    setIsSearching(true);
    setError(null);
    setResult(null);

    try {
      // Use backend WHOIS endpoint to avoid CORS and keep API key secure
      const response = await fetch(`/api/tools/whois?domain=${encodeURIComponent(domain)}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error(`API Error: ${response.status}`);
      }

      const apiResponse = await response.json();

      if (!apiResponse.success) {
        throw new Error(apiResponse.error || 'Failed to fetch WHOIS data');
      }

      const data = apiResponse.data;

      if (data) {
        // Calculate domain age
        const createdDate = new Date(data.creationDate || data.createdDate);
        const now = new Date();
        const ageInDays = Math.floor(
          (now.getTime() - createdDate.getTime()) / (1000 * 60 * 60 * 24)
        );

        const researchResult: DomainResearchResult = {
          domain: data.domain || domain,
          registrar: data.registrar || 'Unknown',
          createdDate: data.creationDate || data.createdDate || 'N/A',
          expiresDate: data.expirationDate || data.expiresDate || 'N/A',
          updatedDate: data.updatedDate || 'N/A',
          status: data.status || [],
          nameservers: data.nameServers || [],
          registrant: {
            name: data.registrant?.name,
            organization: data.registrant?.organization,
            email: data.registrant?.email,
            phone: data.registrant?.phone,
            country: data.registrant?.country,
          },
          admin: {
            name: data.admin?.name,
            organization: data.admin?.organization,
            email: data.admin?.email,
          },
          tech: {
            name: data.tech?.name,
            email: data.tech?.email,
          },
          dnssec: data.dnssec || 'Not available',
          age: ageInDays,
        };

        setResult(researchResult);

        // Add to search history
        const historyItem: SearchHistory = {
          id: Date.now().toString(),
          domain: domain,
          timestamp: Date.now(),
          success: true,
        };
        setSearchHistory(prev => [historyItem, ...prev]);
        setStats(prev => ({ ...prev, totalSearches: prev.totalSearches + 1 }));

        // Mock historical data (in production, call historical API)
        generateMockHistoricalData(domain);

        // Mock related domains (in production, call related domains API)
        generateMockRelatedDomains(domain);
      } else {
        throw new Error('Domain not found or invalid response');
      }
    } catch (err: any) {
      setError(err.message || 'Failed to fetch domain information');
      const historyItem: SearchHistory = {
        id: Date.now().toString(),
        domain: domain,
        timestamp: Date.now(),
        success: false,
      };
      setSearchHistory(prev => [historyItem, ...prev]);
    } finally {
      setIsSearching(false);
    }
  };

  const generateMockHistoricalData = (domain: string) => {
    const mock: HistoricalRecord[] = [
      {
        id: '1',
        date: '2024-01-15',
        changes: ['Nameserver update', 'Contact information changed'],
        registrar: 'Current Registrar',
      },
      {
        id: '2',
        date: '2023-06-10',
        changes: ['Domain renewed for 2 years'],
        registrar: 'Current Registrar',
      },
      {
        id: '3',
        date: '2022-12-01',
        changes: ['Registrar transferred', 'DNSSEC enabled'],
        registrar: 'Previous Registrar',
      },
    ];
    setHistoricalData(mock);
    setStats(prev => ({ ...prev, historicalRecords: mock.length }));
  };

  const generateMockRelatedDomains = (domain: string) => {
    const baseName = domain.split('.')[0];
    const mock: RelatedDomain[] = [
      { domain: `${baseName}.net`, similarity: 95, reason: 'Different TLD' },
      { domain: `${baseName}.org`, similarity: 95, reason: 'Different TLD' },
      { domain: `www.${domain}`, similarity: 90, reason: 'Subdomain variant' },
      { domain: `${baseName}-inc.com`, similarity: 75, reason: 'Name variation' },
      { domain: `${baseName}online.com`, similarity: 70, reason: 'Name variation' },
    ];
    setRelatedDomains(mock);
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const handleExport = () => {
    if (!result) return;

    const exportData = {
      domain: result.domain,
      searchDate: new Date().toISOString(),
      whoisData: result,
      historicalRecords: historicalData,
      relatedDomains: relatedDomains,
    };

    const dataStr = JSON.stringify(exportData, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `domain-research-${result.domain}-${Date.now()}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleClearHistory = () => {
    if (confirm('Clear all search history?')) {
      setSearchHistory([]);
      localStorage.removeItem('domain_research_history');
      setStats(prev => ({ ...prev, totalSearches: 0 }));
    }
  };

  const formatDate = (dateStr: string) => {
    if (!dateStr || dateStr === 'N/A') return 'N/A';
    try {
      return new Date(dateStr).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
      });
    } catch {
      return dateStr;
    }
  };

  const calculateDaysUntilExpiry = () => {
    if (!result || !result.expiresDate || result.expiresDate === 'N/A') return null;
    try {
      const expiry = new Date(result.expiresDate);
      const now = new Date();
      const days = Math.floor((expiry.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
      return days;
    } catch {
      return null;
    }
  };

  const daysUntilExpiry = calculateDaysUntilExpiry();

  return (
    <div className="min-h-screen bg-black text-white py-8 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <Database className="w-8 h-8 text-cyan-400" />
            <h1 className="text-4xl font-bold bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
              Domain Research Suite
            </h1>
          </div>
          <p className="text-gray-400 text-lg">
            Comprehensive domain intelligence with WHOIS data, historical records, and related
            domain discovery
          </p>
        </div>

        {/* Stats Dashboard */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border border-cyan-500/30 rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-400">Total Searches</span>
              <Search className="w-4 h-4 text-cyan-400" />
            </div>
            <p className="text-2xl font-bold text-white">{stats?.totalSearches || 0}</p>
          </div>
          <div className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border border-purple-500/30 rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-400">Domains Tracked</span>
              <Globe className="w-4 h-4 text-purple-400" />
            </div>
            <p className="text-2xl font-bold text-white">{stats?.domainsTracked || 0}</p>
          </div>
          <div className="bg-gradient-to-br from-green-500/10 to-emerald-500/10 border border-green-500/30 rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-400">Active Monitors</span>
              <TrendingUp className="w-4 h-4 text-green-400" />
            </div>
            <p className="text-2xl font-bold text-white">{stats?.activeMonitors || 0}</p>
          </div>
          <div className="bg-gradient-to-br from-yellow-500/10 to-orange-500/10 border border-yellow-500/30 rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-400">Historical Records</span>
              <History className="w-4 h-4 text-yellow-400" />
            </div>
            <p className="text-2xl font-bold text-white">{stats?.historicalRecords || 0}</p>
          </div>
        </div>

        {/* Search Section */}
        <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6 mb-8">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <label className="block text-sm font-semibold text-gray-300 mb-2">Domain Name</label>
              <input
                type="text"
                value={domain}
                onChange={e => setDomain(e.target.value)}
                onKeyPress={e => e.key === 'Enter' && handleSearch()}
                placeholder="example.com"
                className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:border-cyan-500 focus:outline-none"
              />
            </div>
            <div className="flex gap-2 items-end">
              <button
                onClick={handleSearch}
                disabled={isSearching}
                className="bg-gradient-to-r from-cyan-600 to-purple-600 hover:from-cyan-700 hover:to-purple-700 disabled:from-gray-700 disabled:to-gray-700 text-white font-semibold px-6 py-3 rounded-lg transition-all flex items-center gap-2"
              >
                {isSearching ? (
                  <>
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    Researching...
                  </>
                ) : (
                  <>
                    <Search className="w-5 h-5" />
                    Research Domain
                  </>
                )}
              </button>
              <button
                onClick={() => setShowHistory(!showHistory)}
                className={`p-3 rounded-lg transition-colors ${
                  showHistory
                    ? 'bg-cyan-600 text-white'
                    : 'bg-gray-800 text-gray-400 hover:text-white'
                }`}
              >
                <Clock className="w-5 h-5" />
              </button>
            </div>
          </div>

          {error && (
            <div className="mt-4 bg-red-500/10 border border-red-500/30 rounded-lg p-4 flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
              <p className="text-red-300">{error}</p>
            </div>
          )}
        </div>

        {/* History Sidebar */}
        {showHistory && (
          <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6 mb-8">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-white">Search History</h3>
              <div className="flex gap-2">
                <button
                  onClick={handleClearHistory}
                  className="p-2 rounded-lg bg-gray-800 text-gray-400 hover:text-red-400 transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {searchHistory.map(item => (
                <button
                  key={item.id}
                  onClick={() => {
                    setDomain(item.domain);
                    setShowHistory(false);
                  }}
                  className="w-full text-left p-3 rounded-lg bg-gray-800/50 border border-gray-700 hover:border-cyan-500/30 transition-all"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-white font-medium">{item.domain}</span>
                    {item.success ? (
                      <CheckCircle className="w-4 h-4 text-green-400" />
                    ) : (
                      <AlertCircle className="w-4 h-4 text-red-400" />
                    )}
                  </div>
                  <span className="text-xs text-gray-400">
                    {new Date(item.timestamp).toLocaleString()}
                  </span>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Results Section */}
        {result && (
          <>
            {/* Action Buttons */}
            <div className="flex gap-2 mb-6">
              <button
                onClick={handleExport}
                className="bg-gray-800 hover:bg-gray-700 text-white font-semibold px-4 py-2 rounded-lg transition-colors flex items-center gap-2"
              >
                <Download className="w-4 h-4" />
                Export Report
              </button>
              <button
                onClick={() => handleCopy(JSON.stringify(result, null, 2))}
                className="bg-gray-800 hover:bg-gray-700 text-white font-semibold px-4 py-2 rounded-lg transition-colors flex items-center gap-2"
              >
                <Copy className="w-4 h-4" />
                Copy Data
              </button>
            </div>

            {/* Tabs */}
            <div className="flex gap-2 mb-6 border-b border-gray-800">
              {(['overview', 'historical', 'related', 'monitoring'] as const).map(tab => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`px-4 py-2 font-semibold transition-all ${
                    activeTab === tab
                      ? 'text-cyan-400 border-b-2 border-cyan-400'
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  {tab.charAt(0).toUpperCase() + tab.slice(1)}
                </button>
              ))}
            </div>

            {/* Tab Content */}
            {activeTab === 'overview' && (
              <div className="space-y-6">
                {/* Domain Overview */}
                <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6">
                  <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
                    <Globe className="w-5 h-5 text-cyan-400" />
                    Domain Overview
                  </h3>

                  {/* Expiry Warning */}
                  {daysUntilExpiry !== null && daysUntilExpiry < 60 && (
                    <div
                      className={`mb-4 p-4 rounded-lg border ${
                        daysUntilExpiry < 30
                          ? 'bg-red-500/10 border-red-500/30'
                          : 'bg-yellow-500/10 border-yellow-500/30'
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <AlertCircle
                          className={`w-5 h-5 flex-shrink-0 ${
                            daysUntilExpiry < 30 ? 'text-red-400' : 'text-yellow-400'
                          }`}
                        />
                        <div>
                          <p
                            className={`font-semibold ${
                              daysUntilExpiry < 30 ? 'text-red-300' : 'text-yellow-300'
                            }`}
                          >
                            Domain expiring soon!
                          </p>
                          <p
                            className={`text-sm ${
                              daysUntilExpiry < 30 ? 'text-red-300/80' : 'text-yellow-300/80'
                            }`}
                          >
                            This domain will expire in {daysUntilExpiry} days (
                            {formatDate(result.expiresDate)})
                          </p>
                        </div>
                      </div>
                    </div>
                  )}

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm text-gray-400">Domain</label>
                      <p className="text-white font-semibold text-lg">{result.domain}</p>
                    </div>
                    <div>
                      <label className="text-sm text-gray-400">Registrar</label>
                      <p className="text-white font-semibold">{result.registrar}</p>
                    </div>
                    <div>
                      <label className="text-sm text-gray-400">Created Date</label>
                      <p className="text-white">{formatDate(result.createdDate)}</p>
                    </div>
                    <div>
                      <label className="text-sm text-gray-400">Expires Date</label>
                      <p className="text-white">{formatDate(result.expiresDate)}</p>
                    </div>
                    <div>
                      <label className="text-sm text-gray-400">Updated Date</label>
                      <p className="text-white">{formatDate(result.updatedDate)}</p>
                    </div>
                    <div>
                      <label className="text-sm text-gray-400">Domain Age</label>
                      <p className="text-white">
                        {result.age} days (~{Math.floor(result.age / 365)} years)
                      </p>
                    </div>
                    <div>
                      <label className="text-sm text-gray-400">DNSSEC</label>
                      <p className="text-white">{result.dnssec}</p>
                    </div>
                    <div>
                      <label className="text-sm text-gray-400">Status</label>
                      <div className="flex flex-wrap gap-2 mt-1">
                        {result.status.map((status, idx) => (
                          <span
                            key={idx}
                            className="px-2 py-1 bg-cyan-500/20 text-cyan-400 text-xs rounded-full"
                          >
                            {status}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Nameservers */}
                <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6">
                  <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
                    <Server className="w-5 h-5 text-purple-400" />
                    Nameservers
                  </h3>
                  <div className="space-y-2">
                    {result.nameservers.map((ns, idx) => (
                      <div
                        key={idx}
                        className="flex items-center gap-2 p-3 bg-gray-800/50 rounded-lg"
                      >
                        <span className="text-gray-400 font-mono text-sm">NS{idx + 1}</span>
                        <span className="text-white font-mono">{ns}</span>
                        <button
                          onClick={() => handleCopy(ns)}
                          className="ml-auto p-1 hover:bg-gray-700 rounded transition-colors"
                        >
                          <Copy className="w-4 h-4 text-gray-400" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Contact Information */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {/* Registrant */}
                  <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6">
                    <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                      <User className="w-5 h-5 text-green-400" />
                      Registrant
                    </h3>
                    <div className="space-y-3">
                      {result.registrant.name && (
                        <div>
                          <label className="text-xs text-gray-400">Name</label>
                          <p className="text-white text-sm">{result.registrant.name}</p>
                        </div>
                      )}
                      {result.registrant.organization && (
                        <div>
                          <label className="text-xs text-gray-400">Organization</label>
                          <p className="text-white text-sm">{result.registrant.organization}</p>
                        </div>
                      )}
                      {result.registrant.email && (
                        <div>
                          <label className="text-xs text-gray-400">Email</label>
                          <p className="text-white text-sm">{result.registrant.email}</p>
                        </div>
                      )}
                      {result.registrant.country && (
                        <div>
                          <label className="text-xs text-gray-400">Country</label>
                          <p className="text-white text-sm">{result.registrant.country}</p>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Administrative */}
                  <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6">
                    <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                      <Shield className="w-5 h-5 text-blue-400" />
                      Administrative
                    </h3>
                    <div className="space-y-3">
                      {result.admin.name && (
                        <div>
                          <label className="text-xs text-gray-400">Name</label>
                          <p className="text-white text-sm">{result.admin.name}</p>
                        </div>
                      )}
                      {result.admin.organization && (
                        <div>
                          <label className="text-xs text-gray-400">Organization</label>
                          <p className="text-white text-sm">{result.admin.organization}</p>
                        </div>
                      )}
                      {result.admin.email && (
                        <div>
                          <label className="text-xs text-gray-400">Email</label>
                          <p className="text-white text-sm">{result.admin.email}</p>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Technical */}
                  <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6">
                    <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                      <Mail className="w-5 h-5 text-yellow-400" />
                      Technical
                    </h3>
                    <div className="space-y-3">
                      {result.tech.name && (
                        <div>
                          <label className="text-xs text-gray-400">Name</label>
                          <p className="text-white text-sm">{result.tech.name}</p>
                        </div>
                      )}
                      {result.tech.email && (
                        <div>
                          <label className="text-xs text-gray-400">Email</label>
                          <p className="text-white text-sm">{result.tech.email}</p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'historical' && (
              <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6">
                <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
                  <History className="w-5 h-5 text-cyan-400" />
                  Historical Records
                </h3>
                <div className="space-y-4">
                  {historicalData.map(record => (
                    <div
                      key={record.id}
                      className="p-4 bg-gray-800/50 border border-gray-700 rounded-lg"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-white font-semibold">{record.date}</span>
                        <span className="text-sm text-gray-400">{record.registrar}</span>
                      </div>
                      <ul className="space-y-1">
                        {record.changes.map((change, idx) => (
                          <li key={idx} className="text-sm text-gray-300 flex items-center gap-2">
                            <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full"></span>
                            {change}
                          </li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'related' && (
              <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6">
                <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
                  <Globe className="w-5 h-5 text-purple-400" />
                  Related Domains
                </h3>
                <div className="space-y-3">
                  {relatedDomains.map((related, idx) => (
                    <div
                      key={idx}
                      className="flex items-center justify-between p-4 bg-gray-800/50 border border-gray-700 rounded-lg hover:border-cyan-500/30 transition-all"
                    >
                      <div className="flex-1">
                        <p className="text-white font-semibold">{related.domain}</p>
                        <p className="text-sm text-gray-400">{related.reason}</p>
                      </div>
                      <div className="flex items-center gap-4">
                        <span className="text-cyan-400 font-semibold">{related.similarity}%</span>
                        <button
                          onClick={() => setDomain(related.domain)}
                          className="p-2 bg-cyan-600 hover:bg-cyan-700 rounded-lg transition-colors"
                        >
                          <ExternalLink className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'monitoring' && (
              <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6">
                <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-green-400" />
                  Domain Monitoring
                </h3>
                <div className="text-center py-12">
                  <Info className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                  <p className="text-gray-400 mb-4">Domain monitoring feature coming soon!</p>
                  <p className="text-sm text-gray-500">
                    Set up alerts for domain changes, expiration reminders, and WHOIS updates.
                  </p>
                </div>
              </div>
            )}
          </>
        )}

        {/* Removed API attribution */}
      </div>
    </div>
  );
};

export default DomainResearchSuitePage;
