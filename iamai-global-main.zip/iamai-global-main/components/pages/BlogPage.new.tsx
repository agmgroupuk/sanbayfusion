import React, { useState } from 'react';
import { BlogPost } from '../../constants';

interface BlogPageProps {
  onNavigate: (page: 'home') => void;
  onSelectBlogPost: (post: BlogPost) => void;
}

// NOTE: This file contains a PLACEHOLDER for the 89-year AI history
// The full data is in the original BlogPage.tsx file (15,000+ lines)
// To complete integration:
// 1. Copy the blogPosts object from the original BlogPage.tsx (lines 26-14,650)
// 2. Paste it below, replacing the [...] placeholder
// 3. Delete the original BlogPage.tsx file
// 4. Rename this file to BlogPage.tsx

const BlogPage: React.FC<BlogPageProps> = ({ onNavigate, onSelectBlogPost }) => {
  const [selectedYear, setSelectedYear] = useState<number>(1936);

  const getEra = (year: number) => {
    if (year >= 1936 && year <= 1955) return { name: 'Foundations', color: 'bg-purple-500', icon: '🧮' };
    if (year >= 1956 && year <= 1969) return { name: 'Birth of AI', color: 'bg-blue-500', icon: '🧠' };
    if (year >= 1970 && year <= 1979) return { name: 'Expert Systems', color: 'bg-green-500', icon: '💡' };
    if (year >= 1980 && year <= 1989) return { name: 'AI Winter', color: 'bg-gray-500', icon: '❄️' };
    if (year >= 1990 && year <= 1999) return { name: 'Revival', color: 'bg-orange-500', icon: '🔥' };
    if (year >= 2000 && year <= 2009) return { name: 'Data Era', color: 'bg-cyan-500', icon: '📊' };
    if (year >= 2010 && year <= 2019) return { name: 'Deep Learning', color: 'bg-indigo-500', icon: '🚀' };
    if (year >= 2020 && year <= 2025) return { name: 'Transformers', color: 'bg-pink-500', icon: '✨' };
    return { name: 'Modern', color: 'bg-teal-500', icon: '🤖' };
  };

  // AI History Blog Posts - 89 Years (1936-2025)
  // PLACEHOLDER: Replace [...] below with the full blogPosts object from the original BlogPage.tsx
  const blogPosts: { [key: number]: BlogPost } = [
    // ...PASTE FULL DATA HERE...
  ];

  const getPostByYear = (year: number): BlogPost | null => {
    return blogPosts[year] || null;
  };

  const generateYearEntries = () => {
    const entries: { year: number; display: string; isSpan: boolean }[] = [];
    const availableYears = Object.keys(blogPosts)
      .map(y => parseInt(y))
      .filter(y => !isNaN(y))
      .sort((a, b) => a - b);

    for (const year of availableYears) {
      if (year >= 1936 && year <= 1950) {
        entries.push({ year, display: year.toString(), isSpan: false });
      } else if (year >= 2021) {
        entries.push({ year, display: year.toString(), isSpan: false });
      }
    }

    return entries;
  };

  const yearEntries = generateYearEntries();
  const currentPost = getPostByYear(selectedYear);
  const era = getEra(selectedYear);

  return (
    <div className="min-h-screen bg-black">
      {/* Header Spacer */}
      <div className="h-20"></div>

      <div className="flex h-[calc(100vh-5rem)]">
        {/* Left Sidebar - Years Panel */}
        <div className="w-80 bg-gray-900/50 border-r border-gray-800 flex flex-col">
          {/* Header */}
          <div className="p-6 border-b border-gray-800">
            <h1 className="text-2xl font-bold text-white">AI History Timeline</h1>
            <p className="text-sm text-gray-400 mt-2">
              Explore 89 years of artificial intelligence
            </p>
          </div>

          {/* Years List */}
          <div className="flex-1 overflow-y-auto p-4 space-y-1">
            {yearEntries.map((entry) => {
              const yearEra = getEra(entry.year);
              const isSelected = selectedYear === entry.year;
              const hasPost = getPostByYear(entry.year);

              return (
                <button
                  key={entry.year}
                  onClick={() => setSelectedYear(entry.year)}
                  disabled={!hasPost}
                  className={`w-full p-3 rounded-lg text-left transition-all duration-200 ${
                    isSelected
                      ? 'bg-gray-800 text-white border border-cyan-500/50'
                      : hasPost
                      ? 'bg-gray-800/50 text-gray-300 hover:bg-gray-800 hover:text-white'
                      : 'bg-gray-900/50 text-gray-600 opacity-50 cursor-not-allowed'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <span
                        className={`${yearEra.color} text-white w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold`}
                      >
                        {yearEra.icon}
                      </span>
                      <div>
                        <div className="font-bold text-lg">{entry.display}</div>
                        <div className="text-xs opacity-75">{yearEra.name}</div>
                      </div>
                    </div>
                    {hasPost && <div className="w-2 h-2 rounded-full bg-cyan-400"></div>}
                  </div>
                </button>
              );
            })}
          </div>

          {/* Footer */}
          <div className="p-4 border-t border-gray-800">
            <button
              onClick={() => onNavigate('home')}
              className="w-full bg-gray-800 hover:bg-gray-700 text-white py-2 px-4 rounded-lg transition-colors text-center font-semibold"
            >
              ← Back to Home
            </button>
          </div>
        </div>

        {/* Right Content Area */}
        <div className="flex-1 flex flex-col bg-black">
          {currentPost ? (
            <>
              {/* Content Header */}
              <div className="p-6 bg-gray-900/30 border-b border-gray-800">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <span
                      className={`${era.color} text-white px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1`}
                    >
                      <span>{era.icon}</span>
                      {era.name}
                    </span>
                    <span
                      className="font-bold text-white px-3 py-1 rounded-lg text-sm shadow-md"
                      style={{
                        background: 'linear-gradient(135deg, #06b6d4, #f59e0b)',
                        border: '1px solid rgba(255, 255, 255, 0.2)',
                      }}
                    >
                      {currentPost.year}
                    </span>
                  </div>
                  <div className="text-sm text-gray-400">
                    {currentPost.date}
                    {currentPost.author && ` • By ${currentPost.author}`}
                  </div>
                </div>

                <h1 className="text-3xl font-bold text-white mb-4">{currentPost.title}</h1>
                <p className="text-gray-300 text-lg">{currentPost.excerpt}</p>

                {currentPost.tags && (
                  <div className="flex flex-wrap gap-2 mt-4">
                    {currentPost.tags.map((tag) => (
                      <span
                        key={tag}
                        className="text-cyan-400 px-3 py-1 rounded-full text-sm"
                        style={{ background: 'rgba(6, 182, 212, 0.1)' }}
                      >
                        #{tag}
                      </span>
                    ))}
                  </div>
                )}
              </div>

              {/* Content Body */}
              <div className="flex-1 overflow-y-auto p-6">
                <div
                  className="prose prose-invert prose-lg max-w-none text-gray-300 leading-relaxed"
                  dangerouslySetInnerHTML={{ __html: currentPost.content }}
                />

                {currentPost.references && currentPost.references.length > 0 && (
                  <div className="mt-12 pt-8 border-t border-gray-800">
                    <h3 className="text-lg font-semibold text-cyan-400 mb-4">📚 References</h3>
                    <ul className="space-y-2">
                      {currentPost.references.map((ref, index) => (
                        <li key={index} className="text-sm text-gray-400">
                          {index + 1}. {ref}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>

              {/* Footer Actions */}
              <div className="p-6 border-t border-gray-800 bg-gray-900/30 flex justify-between">
                <button
                  onClick={() => currentPost && onSelectBlogPost(currentPost)}
                  className="text-cyan-400 hover:text-cyan-300 transition-colors font-semibold"
                >
                  📖 Read Full Article →
                </button>
                <button
                  onClick={() => onNavigate('home')}
                  className="text-gray-400 hover:text-cyan-400 transition-colors"
                >
                  Return to Home
                </button>
              </div>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center">
              <div className="text-center text-gray-400">
                <div className="text-6xl mb-4">🤖</div>
                <h2 className="text-2xl font-bold mb-2">No Content Available</h2>
                <p>Content for {selectedYear} is coming soon!</p>
              </div>
            </div>
          )}
        </div>
      </div>

      <style>{`
        .prose-invert h1, .prose-invert h2, .prose-invert h3, .prose-invert h4, .prose-invert h5, .prose-invert h6, .prose-invert strong { color: #fff; }
        .prose-invert a { color: #67e8f9; }
        .prose-invert a:hover { color: #22d3ee; }
        .prose-invert blockquote { border-left-color: #0891b2; color: #9ca3af; }
        .prose-invert p { color: #d1d5db; }
      `}</style>
    </div>
  );
};

export default BlogPage;
