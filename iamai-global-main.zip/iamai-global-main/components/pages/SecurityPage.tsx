import React from 'react';
import { Page } from '../../App';

interface SecurityPageProps {
  onNavigate: (page: Page) => void;
}

const SecurityFeatureCard: React.FC<{ icon: string; title: string; description: string }> = ({ icon, title, description }) => (
    <div className="bg-gray-900/50 p-6 rounded-lg border border-gray-800 flex items-start space-x-4">
        <div className="flex-shrink-0 text-cyan-400 text-2xl mt-1">
            <i className={icon}></i>
        </div>
        <div>
            <h3 className="text-lg font-semibold text-white">{title}</h3>
            <p className="mt-1 text-gray-400">{description}</p>
        </div>
    </div>
);


const SecurityPage: React.FC<SecurityPageProps> = ({ onNavigate }) => {
    const securityFeatures = [
        { icon: 'fa-solid fa-lock', title: 'End-to-End Encryption', description: 'All data, both in transit and at rest, is encrypted using industry-standard protocols like TLS 1.3 and AES-256. Your conversations and data are secure from unauthorized access.' },
        { icon: 'fa-solid fa-shield-halved', title: 'Passwordless Authentication', description: 'We utilize modern, secure authentication methods to protect your account from traditional password-based attacks like phishing and credential stuffing.' },
        { icon: 'fa-solid fa-shield', title: 'Process Isolation', description: 'Every agent runs in its own isolated process, preventing any single point of failure or cross-agent data leakage. This ensures a secure, sandboxed environment for all operations.' },
        { icon: 'fa-solid fa-server', title: 'Secure Infrastructure', description: 'Our platform is built on enterprise-grade cloud infrastructure that complies with rigorous security standards, including regular audits and penetration testing.' },
        { icon: 'fa-solid fa-user-secret', title: 'Privacy by Design', description: 'We build our systems with data privacy as a fundamental principle. We minimize data collection and provide you with control over your information and agent memory.' },
        { icon: 'fa-solid fa-certificate', title: 'Compliance & Audits', description: 'We are committed to meeting and exceeding industry compliance standards such as SOC 2 and GDPR. We conduct regular internal and third-party security audits.' },
    ];

  return (
    <div className="bg-black text-white">
      {/* Hero Section */}
      <section className="py-20 md:py-32 text-center">
        <div className="container mx-auto px-6">
            <div className="mx-auto w-20 h-20 flex items-center justify-center rounded-2xl bg-cyan-900/50 border border-cyan-500/30 mb-6 text-cyan-400">
                <i className="fa-solid fa-shield-halved text-4xl"></i>
            </div>
            <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight mb-4">Security at Our Core</h1>
            <p className="max-w-3xl mx-auto text-lg md:text-xl text-gray-400">
                Your trust is our highest priority. We are committed to building a platform with robust, enterprise-grade security and privacy protections at every level.
            </p>
        </div>
      </section>

      {/* Security Pillars Section */}
      <section className="py-20 md:py-28 bg-[#0a0a0a]">
         <div className="container mx-auto px-6">
            <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8">
                {securityFeatures.map(feature => <SecurityFeatureCard key={feature.title} {...feature} />)}
            </div>
         </div>
      </section>
      
      {/* Responsible Disclosure Section */}
      <section className="py-20 md:py-28 bg-black">
        <div className="container mx-auto px-6">
            <div className="max-w-3xl mx-auto bg-gray-900/50 border border-gray-800 rounded-2xl p-10 text-center">
                 <h2 className="text-3xl font-bold text-white">Responsible Disclosure</h2>
                 <p className="mt-4 text-gray-400">
                    We value the security community. If you believe you have found a security vulnerability in our platform, we encourage you to notify us. We are committed to working with you to resolve the issue promptly.
                 </p>
                 <div className="mt-6">
                    <a href="mailto:security@iamai.global" className="font-semibold text-cyan-400 hover:text-cyan-300">
                        Email us at security@iamai.global <i className="fa-solid fa-arrow-right ml-1"></i>
                    </a>
                 </div>
            </div>
        </div>
      </section>
    </div>
  );
};

export default SecurityPage;
