import React from 'react';
import type { Page } from '../../App';
import { FEATURES, Feature } from '../../constants';

interface FeaturesPageProps {
  onNavigate: (page: Page) => void;
}

const FeatureCard: React.FC<{ feature: Feature }> = ({ feature }) => (
  <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6 flex flex-col items-start space-y-4 hover:border-cyan-500/50 hover:bg-gray-900 transition-all duration-300 transform hover:-translate-y-1">
    <div className="w-12 h-12 flex items-center justify-center rounded-lg bg-gray-800 text-cyan-400">
      <i className={`${feature.icon} text-2xl`}></i>
    </div>
    <h3 className="text-xl font-bold text-white">{feature.name}</h3>
    <p className="text-gray-400 flex-grow">{feature.description}</p>
  </div>
);

const FeatureSpotlight: React.FC<{ title: string; description: string; imageUrl: string; reverse?: boolean }> = ({ title, description, imageUrl, reverse }) => (
    <div className={`flex flex-col md:flex-row items-center gap-12 ${reverse ? 'md:flex-row-reverse' : ''}`}>
        <div className="md:w-1/2">
            <img src={imageUrl} alt={title} className="rounded-2xl shadow-lg shadow-cyan-500/10 object-cover w-full h-auto aspect-video" />
        </div>
        <div className="md:w-1/2">
            <h3 className="text-3xl font-bold text-white mb-4">{title}</h3>
            <p className="text-gray-400 leading-relaxed">{description}</p>
        </div>
    </div>
);


const FeaturesPage: React.FC<FeaturesPageProps> = ({ onNavigate }) => {
  return (
    <div className="bg-black text-white">
      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 md:py-32">
        <div className="absolute inset-0 bg-grid-gray-900 [mask-image:linear-gradient(to_bottom,white_30%,transparent)]"></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-cyan-500/10 rounded-full blur-3xl"></div>
        <div className="container mx-auto px-6 text-center relative z-10">
            <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight mb-4 bg-clip-text text-transparent bg-gradient-to-b from-white to-gray-400">
                A Platform Built for the Future of AI
            </h1>
            <p className="max-w-3xl mx-auto text-lg md:text-xl text-gray-400">
                Explore the powerful, developer-first features that make IA M AI the ultimate platform for building with character-driven agents.
            </p>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-20 md:py-28 bg-[#0a0a0a]">
        <div className="container mx-auto px-6">
            <div className="text-center mb-12">
                <h2 className="text-3xl md:text-4xl font-bold text-white">Core Capabilities</h2>
                <p className="max-w-2xl mx-auto mt-4 text-gray-400">
                    Everything you need to build, deploy, and scale intelligent applications.
                </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {FEATURES.map(feature => <FeatureCard key={feature.name} feature={feature} />)}
            </div>
        </div>
      </section>

      {/* Feature Spotlights */}
      <section className="py-20 md:py-28 bg-black">
        <div className="container mx-auto px-6 space-y-24">
            <FeatureSpotlight 
                title="Multi-Agent Ecosystem"
                description="Go beyond monolithic AI. Our platform enables you to deploy a diverse team of specialized agents, each with a unique persona, role, and skill set. This character-driven approach leads to more effective, nuanced, and engaging user interactions. Agents operate in isolated containers, ensuring security and scalability."
                imageUrl="https://picsum.photos/800/600?random=31"
            />
            <FeatureSpotlight 
                title="Universal Memory System"
                description="Solve the problem of limited context windows. Our innovative Universal Memory provides a persistent, shared context layer that all agents can access. This enables long-term memory, cross-conversational context, and a truly continuous user experience. Agents remember past interactions, learn user preferences, and build on previous knowledge."
                imageUrl="https://picsum.photos/800/600?random=32"
                reverse={true}
            />
            <FeatureSpotlight 
                title="Developer-First Architecture"
                description="Built by developers, for developers. With cloud-native architecture, a robust REST API, and real-time WebSocket streaming, our platform is designed for extensibility. Spin up new agents, integrate with existing workflows, and build custom solutions with an architecture that prioritizes flexibility and control."
                imageUrl="https://picsum.photos/800/600?random=33"
            />
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 md:py-28 bg-black">
        <div className="container mx-auto px-6">
            <div className="bg-gradient-to-r from-cyan-500 to-purple-500 rounded-2xl p-10 md:p-16 text-center">
                <h2 className="text-3xl md:text-4xl font-bold text-black">Ready to Experience These Features?</h2>
                <p className="max-w-2xl mx-auto mt-4 text-gray-800">
                    Sign up today and start building with the most advanced character-driven AI platform.
                </p>
                <div className="mt-8">
                    <button
                        onClick={() => onNavigate('signup')}
                        title="Sign up for a free account"
                        className="bg-black text-white font-semibold px-8 py-3 rounded-full hover:bg-gray-800 transition-all duration-300 transform hover:scale-105"
                    >
                        Get Started for Free
                    </button>
                </div>
            </div>
        </div>
      </section>
    </div>
  );
};

export default FeaturesPage;