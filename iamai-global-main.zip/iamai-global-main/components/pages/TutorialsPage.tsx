import React, { useState, useRef, useEffect } from 'react';
import { Page } from '../../App';
import { Agent } from '../../constants';
import { ALL_AGENTS } from '../../agents';
import { AGENT_UI_DATA } from '../../agents/agentData';

interface TutorialsPageProps {
  onNavigate: (page: Page) => void;
}

interface Tutorial {
  id: string;
  title: string;
  category: 'agent' | 'tool';
  icon: string;
  content?: any; // Agent or tool data
}

const TutorialContent: React.FC<{ agent: Agent }> = ({ agent }) => {
    const agentData = AGENT_UI_DATA[agent.name] || AGENT_UI_DATA.default;
    const themeColor = agentData.themeColor || 'cyan';
    const themeClass = `text-${themeColor}-400`;

    const CapabilityCard: React.FC<{ title: string; description: string; icon: string }> = ({ title, description, icon }) => (
        <div className="bg-gray-800/50 p-4 rounded-lg flex items-start space-x-4">
            <div className={`flex-shrink-0 text-2xl ${themeClass}`}>
                <i className={`fa-solid ${icon}`}></i>
            </div>
            <div>
                <h4 className="font-semibold text-white">{title}</h4>
                <p className="text-sm text-gray-400">{description}</p>
            </div>
        </div>
    );
    
    const PersonalityBar: React.FC<{ label: string; value: number }> = ({ label, value }) => (
         <div>
            <div className="flex justify-between items-baseline mb-1">
                <span className="text-sm font-medium text-gray-300">{label}</span>
                <span className={`text-sm font-bold ${themeClass}`}>{value}/100</span>
            </div>
            <div className="w-full bg-gray-700/50 rounded-full h-2">
                <div 
                    className={`h-2 rounded-full bg-gradient-to-r from-${themeColor}-500 to-${themeColor}-400`}
                    style={{ width: `${value}%`, transition: 'width 0.5s ease-in-out' }}
                ></div>
            </div>
        </div>
    );

    return (
        <article className="prose prose-invert prose-lg max-w-none text-gray-300 leading-relaxed">
            <div className="flex items-center space-x-4 mb-6">
                <div className={`w-16 h-16 flex items-center justify-center rounded-xl bg-gray-800 border border-gray-700 ${themeClass}`}>
                     {agent.icon.startsWith('data:image') ? (
                        <img src={agent.icon} alt={`${agent.name} icon`} className="w-full h-full object-cover rounded-xl" />
                    ) : (
                       <i className={`${agent.icon} text-4xl`}></i>
                    )}
                </div>
                <div>
                    <h1 className="text-4xl font-bold text-white mb-0">{agent.name}</h1>
                    <p className={`mt-1 text-lg font-medium ${themeClass}`}>{agent.role}</p>
                </div>
            </div>

            <h2 className="border-b border-gray-800 pb-2">Overview</h2>
            <p>{agent.description}</p>

            {agentData.capabilitiesDescription && (
                 <>
                    <h2 className="border-b border-gray-800 pb-2 mt-10">Key Capabilities</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 not-prose">
                        {agentData.capabilitiesDescription.map(cap => (
                            <CapabilityCard key={cap.name} title={cap.name} description={cap.description} icon={cap.icon} />
                        ))}
                    </div>
                </>
            )}

            {agent.personalityMatrix && (
                 <>
                    <h2 className="border-b border-gray-800 pb-2 mt-10">Personality Profile</h2>
                    <div className="not-prose space-y-4">
                        <PersonalityBar label="Formality" value={agent.personalityMatrix.formality} />
                        <PersonalityBar label="Humor" value={agent.personalityMatrix.humor} />
                        <PersonalityBar label="Enthusiasm" value={agent.personalityMatrix.enthusiasm} />
                    </div>
                </>
            )}
            
            {agent.examples?.prompts && (
                <>
                    <h2 className="border-b border-gray-800 pb-2 mt-10">Usage Examples</h2>
                    <p>Here are a few examples of how you can interact with {agent.name}:</p>
                    {agent.examples.prompts.map((prompt, index) => (
                        <div key={index} className="my-4 not-prose">
                            <blockquote className="border-l-4 border-cyan-500 bg-gray-800/50 p-4 rounded-r-lg">
                               <p className="font-semibold text-white">You:</p>
                               <p className="text-gray-300 italic">"{prompt}"</p>
                            </blockquote>
                            {agent.examples?.responses?.[index] && (
                                <div className="mt-2 pl-4">
                                    <p className="font-semibold text-white">{agent.name} might respond:</p>
                                    <p className="text-gray-400 italic">"{agent.examples.responses[index]}"</p>
                                </div>
                            )}
                        </div>
                    ))}
                </>
            )}
        </article>
    );
};


// Tool Tutorial Content Component
const ToolTutorialContent: React.FC<{ tool: any }> = ({ tool }) => {
    return (
        <article className="prose prose-invert prose-lg max-w-none text-gray-300 leading-relaxed">
            <div className="flex items-center space-x-4 mb-6">
                <div className="w-16 h-16 flex items-center justify-center rounded-xl bg-gradient-to-br from-cyan-500/20 to-blue-500/20 border border-cyan-500/30 text-cyan-400">
                    <i className={`${tool.icon} text-4xl`}></i>
                </div>
                <div>
                    <h1 className="text-4xl font-bold text-white mb-0">{tool.name}</h1>
                    <p className="mt-1 text-lg font-medium text-cyan-400">{tool.category}</p>
                </div>
            </div>

            <h2 className="border-b border-gray-800 pb-2">Overview</h2>
            <p>{tool.description}</p>

            <h2 className="border-b border-gray-800 pb-2 mt-10">Key Features</h2>
            <ul className="space-y-2">
                {tool.features.map((feature: string, idx: number) => (
                    <li key={idx} className="flex items-start space-x-2">
                        <span className="text-cyan-400 mt-1">✓</span>
                        <span>{feature}</span>
                    </li>
                ))}
            </ul>

            <h2 className="border-b border-gray-800 pb-2 mt-10">How to Use</h2>
            <div className="bg-gray-800/50 p-6 rounded-lg not-prose">
                <ol className="space-y-3 text-gray-300">
                    {tool.steps.map((step: string, idx: number) => (
                        <li key={idx} className="flex items-start space-x-3">
                            <span className="flex-shrink-0 w-6 h-6 rounded-full bg-cyan-500/20 text-cyan-400 flex items-center justify-center text-sm font-bold">
                                {idx + 1}
                            </span>
                            <span className="flex-1">{step}</span>
                        </li>
                    ))}
                </ol>
            </div>

            {tool.examples && (
                <>
                    <h2 className="border-b border-gray-800 pb-2 mt-10">Example Use Cases</h2>
                    <div className="space-y-4 not-prose">
                        {tool.examples.map((example: { title: string; description: string }, idx: number) => (
                            <div key={idx} className="bg-gradient-to-r from-cyan-500/5 to-blue-500/5 border border-cyan-500/20 p-4 rounded-lg">
                                <h4 className="font-semibold text-white mb-2">{example.title}</h4>
                                <p className="text-sm text-gray-400">{example.description}</p>
                            </div>
                        ))}
                    </div>
                </>
            )}

            <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-lg p-6 mt-8 not-prose">
                <h3 className="text-lg font-bold text-cyan-400 mb-2">💡 Pro Tip</h3>
                <p className="text-sm text-gray-300">{tool.proTip}</p>
            </div>
        </article>
    );
};

const TutorialsPage: React.FC<TutorialsPageProps> = ({ onNavigate }) => {
    // Create tutorials list combining agents and tools
    const toolTutorials = [
        {
            id: 'ip-info',
            name: 'IP Info Lookup',
            category: 'Network Tools',
            icon: 'fa-solid fa-globe',
            description: 'Get comprehensive information about any IP address including geolocation, ISP details, security analysis, VPN/Proxy detection, and blacklist checking with interactive Google Maps.',
            features: [
                'Geolocation with Google Maps integration',
                'ISP and Organization identification',
                'Security risk assessment and scoring',
                'VPN/Proxy/TOR detection',
                'Blacklist checking across multiple RBLs',
                'ASN and network information',
                'Hostname resolution and reverse DNS',
            ],
            steps: [
                'Navigate to the Toolbox page from the main menu',
                'Click on "IP Info Lookup" tool',
                'Enter an IPv4 address (e.g., 8.8.8.8) in the search field',
                'Click "Analyze IP" to retrieve comprehensive information',
                'View results including location, security analysis, and network details',
                'Click on the map to see the exact geographical location',
            ],
            examples: [
                { title: 'Security Analysis', description: 'Check if an IP address is listed on spam blacklists or associated with malicious activity before allowing access to your systems.' },
                { title: 'Geotargeting', description: 'Identify visitor locations for content personalization and compliance with regional regulations.' },
                { title: 'Network Debugging', description: 'Troubleshoot connectivity issues by verifying IP ownership, routing, and network paths.' },
            ],
            proTip: 'Use the bulk lookup feature to analyze multiple IPs at once for security audits and network monitoring.'
        },
        {
            id: 'api-tester',
            name: 'API Testing Tool',
            category: 'Development Tools',
            icon: 'fa-solid fa-bolt',
            description: 'Test REST API endpoints with custom headers, authentication, request bodies, and multiple HTTP methods. View real-time responses with syntax highlighting and status codes.',
            features: [
                'All HTTP methods (GET, POST, PUT, DELETE, PATCH, HEAD, OPTIONS)',
                'Custom headers and authentication (Bearer token, API keys)',
                'JSON request body editor with validation',
                'Real-time response viewing with syntax highlighting',
                'Response time measurement',
                'Status code analysis',
                'Copy/paste functionality for easy testing',
            ],
            steps: [
                'Go to Toolbox → API Testing Tool',
                'Enter your API endpoint URL',
                'Select the HTTP method (GET, POST, etc.)',
                'Add custom headers if needed (Authorization, Content-Type, etc.)',
                'Enter request body data for POST/PUT requests (JSON format)',
                'Click "Send Request" to execute',
                'View the response, status code, and response time',
            ],
            examples: [
                { title: 'Testing RESTful APIs', description: 'Quickly test your API endpoints during development without needing Postman or cURL commands.' },
                { title: 'Debugging Integrations', description: 'Troubleshoot third-party API integrations by testing different request parameters and headers.' },
                { title: 'API Documentation Validation', description: 'Verify that your API documentation matches actual API behavior by testing examples.' },
            ],
            proTip: 'Save frequently used requests by bookmarking the tool page with different parameter configurations for quick access.'
        },
        {
            id: 'ssl-checker',
            name: 'SSL Certificate Checker',
            category: 'Security Tools',
            icon: 'fa-solid fa-shield',
            description: 'Verify SSL/TLS certificates, check expiration dates, validate certificate chains, and assess security configuration for any domain.',
            features: [
                'Certificate details and validity period',
                'Expiration warnings and countdown',
                'Chain validation and issuer verification',
                'Security grade assessment',
                'Cipher suite analysis',
                'Protocol support detection (TLS 1.2, 1.3)',
                'Common security issues identification',
            ],
            steps: [
                'Access the SSL Checker from the Toolbox',
                'Enter a domain name (e.g., example.com)',
                'Click "Check SSL" to analyze the certificate',
                'Review certificate details including issuer and expiration date',
                'Check the security grade and recommendations',
                'Address any warnings or security issues identified',
            ],
            examples: [
                { title: 'Certificate Monitoring', description: 'Monitor SSL certificate expiration dates to prevent security warnings and downtime.' },
                { title: 'Security Audits', description: 'Assess SSL/TLS configuration for compliance with security standards like PCI DSS.' },
                { title: 'Troubleshooting SSL Errors', description: 'Diagnose certificate chain issues, mismatched domains, or protocol problems.' },
            ],
            proTip: 'Set up regular checks for your critical domains to get advance warning before certificates expire.'
        },
        {
            id: 'port-scanner',
            name: 'Port Scanner',
            category: 'Network Tools',
            icon: 'fa-solid fa-server',
            description: 'Scan for open ports on a server, identify running services, and detect potential vulnerabilities in network security.',
            features: [
                'Common port scanning (well-known services)',
                'Custom port range specification',
                'Service identification and version detection',
                'Port status detection (open/closed/filtered)',
                'Security assessment and vulnerability warnings',
                'Protocol detection (TCP/UDP)',
                'Bulk scanning for multiple hosts',
            ],
            steps: [
                'Navigate to Toolbox → Port Scanner',
                'Enter the target IP address or hostname',
                'Choose between common ports or custom range',
                'Click "Scan Ports" to begin analysis',
                'Wait for scan completion',
                'Review open ports and identified services',
                'Take action on any security concerns',
            ],
            examples: [
                { title: 'Security Audits', description: 'Identify unnecessary open ports that could be exploited by attackers.' },
                { title: 'Network Troubleshooting', description: 'Verify that required services are accessible on the correct ports.' },
                { title: 'Firewall Testing', description: 'Confirm that firewall rules are correctly blocking unauthorized ports.' },
            ],
            proTip: 'Always get permission before scanning systems you don\'t own. Unauthorized port scanning may be illegal.'
        },
        {
            id: 'email-verify',
            name: 'Email Verification',
            category: 'Validation Tools',
            icon: 'fa-solid fa-envelope-circle-check',
            description: 'Validate email addresses with syntax checking, domain validation, SMTP verification, and disposable email detection.',
            features: [
                'Email syntax validation (RFC 5322 compliant)',
                'Domain existence verification (MX records)',
                'SMTP server validation',
                'Disposable email detection',
                'Bulk verification for multiple emails',
                'Catch-all detection',
                'Role-based email identification',
            ],
            steps: [
                'Open Email Verification tool from Toolbox',
                'Enter email address to verify (or multiple emails, one per line)',
                'Click "Verify Email" to start validation',
                'Check validation results including syntax, domain, and SMTP status',
                'Review any warnings (disposable, invalid, risky)',
                'Export results if verifying in bulk',
            ],
            examples: [
                { title: 'User Registration', description: 'Verify email addresses during signup to prevent fake accounts and improve deliverability.' },
                { title: 'Email List Cleaning', description: 'Clean your email marketing lists to reduce bounce rates and improve sender reputation.' },
                { title: 'Form Validation', description: 'Real-time email validation in web forms to catch typos before submission.' },
            ],
            proTip: 'Use bulk verification to clean large email lists before sending campaigns to improve deliverability rates.'
        },
    ];

    const [selectedTutorial, setSelectedTutorial] = useState<Tutorial | null>(null);
    const contentRef = useRef<HTMLDivElement>(null);

    // Initialize with first tutorial
    useEffect(() => {
        if (!selectedTutorial && ALL_AGENTS.length > 0) {
            setSelectedTutorial({
                id: ALL_AGENTS[0].id,
                title: ALL_AGENTS[0].name,
                category: 'agent',
                icon: ALL_AGENTS[0].icon,
                content: ALL_AGENTS[0]
            });
        }
    }, []);

    const handleTutorialSelect = (tutorial: Tutorial) => {
        setSelectedTutorial(tutorial);
        // Scroll content to top when switching tutorials
        if (contentRef.current) {
            contentRef.current.scrollTop = 0;
        }
        // On mobile, scroll to content after selection
        if (window.innerWidth < 768 && contentRef.current) {
            setTimeout(() => {
                contentRef.current?.scrollIntoView({ 
                    behavior: 'smooth', 
                    block: 'start' 
                });
            }, 100);
        }
    };

    return (
        <div className="bg-black text-white min-h-screen flex flex-col">
            {/* Hero Section */}
            <section className="relative overflow-hidden border-b border-gray-800 flex-shrink-0">
                <div className="absolute inset-0 bg-grid-gray-900 [mask-image:linear-gradient(to_bottom,white_30%,transparent)]"></div>
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-gradient-to-r from-cyan-500/10 to-purple-500/10 rounded-full blur-3xl"></div>
                
                <div className="container mx-auto px-6 py-12 md:py-16 text-center relative z-10">
                    <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-gradient-to-br from-cyan-500/20 to-purple-500/20 mb-4">
                        <i className="fa-solid fa-graduation-cap text-2xl text-cyan-400"></i>
                    </div>
                    <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight mb-3 bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400">
                        Tutorials & Guides
                    </h1>
                    <p className="text-base md:text-lg text-gray-400 max-w-2xl mx-auto">
                        Master our AI agents and developer tools with comprehensive step-by-step tutorials
                    </p>
                </div>
            </section>

            <div className="container mx-auto md:h-screen">
                <div className="flex flex-col md:flex-row md:h-full">
                {/* Sidebar - Moves to top on mobile */}
                <aside className="w-full md:w-72 flex-shrink-0 border-b md:border-b-0 md:border-r border-gray-800 bg-gray-950 overflow-hidden flex flex-col">
                    {/* Scrollable Navigation */}
                    <div className="flex-1 overflow-y-auto px-4 py-4 md:py-6 max-h-[50vh] md:max-h-none">
                        <div className="space-y-4 md:space-y-6">
                        {/* Agents Section */}
                        <div>
                            <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3 px-2">AI Agents</h3>
                                <ul className="space-y-1">
                                    {ALL_AGENTS.map(agent => {
                                        const tutorial: Tutorial = {
                                            id: agent.id,
                                            title: agent.name,
                                            category: 'agent',
                                            icon: agent.icon,
                                            content: agent
                                        };
                                        return (
                                            <li key={agent.id}>
                                                <button
                                                    onClick={() => handleTutorialSelect(tutorial)}
                                                    className={`w-full text-left px-3 py-2 rounded-lg transition-colors flex items-center space-x-3 ${
                                                        selectedTutorial?.id === agent.id
                                                        ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50'
                                                        : 'text-gray-400 hover:bg-gray-800/50 hover:text-gray-300'
                                                    }`}
                                                >
                                                    <span className="w-8 h-8 flex items-center justify-center rounded-md bg-gray-800 flex-shrink-0 text-cyan-400">
                                                        {agent.icon && agent.icon.startsWith('data:image') ? (
                                                            <img src={agent.icon} alt={`${agent.name} icon`} className="w-full h-full object-cover rounded-md" />
                                                        ) : (
                                                            <i className={`${agent.icon} text-sm`}></i>
                                                        )}
                                                    </span>
                                                    <span className="font-medium text-sm">{agent.name}</span>
                                                </button>
                                            </li>
                                        );
                                    })}
                                </ul>
                        </div>

                        {/* Tools Section */}
                        {/* Tools Section */}
                        <div>
                            <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3 px-2">Developer Tools</h3>
                                <ul className="space-y-1">
                                    {toolTutorials.map(tool => {
                                        const tutorial: Tutorial = {
                                            id: tool.id,
                                            title: tool.name,
                                            category: 'tool',
                                            icon: tool.icon,
                                            content: tool
                                        };
                                        return (
                                            <li key={tool.id}>
                                                <button
                                                    onClick={() => handleTutorialSelect(tutorial)}
                                                    className={`w-full text-left px-3 py-2 rounded-lg transition-colors flex items-center space-x-3 ${
                                                        selectedTutorial?.id === tool.id
                                                        ? 'bg-purple-500/20 text-purple-300 border border-purple-500/50'
                                                        : 'text-gray-400 hover:bg-gray-800/50 hover:text-gray-300'
                                                    }`}
                                                >
                                                    <span className="w-8 h-8 flex items-center justify-center rounded-md bg-gray-800 flex-shrink-0 text-purple-400">
                                                        <i className={`${tool.icon} text-sm`}></i>
                                                    </span>
                                                    <span className="font-medium text-sm">{tool.name}</span>
                                                </button>
                                            </li>
                                        );
                                    })}
                                </ul>
                        </div>
                        </div>
                    </div>
                </aside>
                
                {/* Main Content - Scrollable internally on desktop, moves to bottom on mobile */}
                <main ref={contentRef} className="flex-1 overflow-y-auto bg-black md:h-full">
                    <div className="p-6 md:p-12 max-w-5xl mx-auto">
                        {selectedTutorial ? (
                            selectedTutorial.category === 'agent' ? (
                                <TutorialContent agent={selectedTutorial.content} />
                            ) : (
                                <ToolTutorialContent tool={selectedTutorial.content} />
                            )
                        ) : (
                            <div className="text-center py-20">
                                <h2 className="text-3xl font-bold text-white">Select a Tutorial</h2>
                                <p className="text-gray-400 mt-2">Choose an agent or tool from the sidebar to view the tutorial.</p>
                            </div>
                        )}
                        
                        <div className="mt-12 pt-8 border-t border-gray-800">
                            <button onClick={() => onNavigate('home')} title="Return to the homepage" className="text-cyan-400 hover:text-cyan-300 font-semibold transition-colors">
                                &larr; Back to Home
                            </button>
                        </div>
                    </div>
                </main>
                </div>
            </div>

            <style>{`
                .prose-invert h1, .prose-invert h2, .prose-invert h3, .prose-invert strong { color: #fff; }
                .prose-invert p, .prose-invert li { color: #d1d5db; }
                .prose-invert a { color: #67e8f9; }
                .prose-invert a:hover { color: #22d3ee; }
                .prose-invert blockquote { border-left-color: #0891b2; color: #9ca3af; }
                .prose-invert code { color: #f3f4f6; background-color: rgba(255,255,255,0.1); padding: 0.2em 0.4em; border-radius: 6px; }
            `}</style>
        </div>
    );
};

export default TutorialsPage;
