import React, { useState, useEffect } from 'react';
import { ArrowLeft, FileText, Search, Globe, Calendar, User, MapPin, Clock, Download, Copy, Check, AlertTriangle, AlertCircle, Info, CheckCircle, Trash2, Shield, Server } from 'lucide-react';

interface Props { onNavigate?: (page: string) => void }

interface WhoisData {
  domain: string;
  registrar?: string;
  creationDate?: string;
  expirationDate?: string;
  updatedDate?: string;
  status?: string[];
  nameServers?: string[];
  registrant?: {
    name?: string;
    organization?: string;
    email?: string;
    country?: string;
  };
  admin?: {
    name?: string;
    email?: string;
  };
  tech?: {
    name?: string;
    email?: string;
  };
  dnssec?: string;
  rawData?: string;
}

interface WhoisResult {
  domain: string;
  success: boolean;
  data?: WhoisData;
  error?: string;
  daysUntilExpiration?: number;
  expirationStatus?: 'expired' | 'critical' | 'warning' | 'monitor' | 'healthy';
}

interface HistoryEntry {
  id: string;
  domain: string;
  registrar?: string;
  expirationDate?: string;
  daysUntilExpiration?: number;
  expirationStatus?: string;
  timestamp: number;
}

const WhoisLookupPage: React.FC<Props> = ({ onNavigate }) => {
  const [domain, setDomain] = useState('');
  const [bulkInput, setBulkInput] = useState('');
  const [mode, setMode] = useState<'single' | 'bulk'>('single');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<WhoisResult | null>(null);
  const [bulkResults, setBulkResults] = useState<WhoisResult[]>([]);
  const [error, setError] = useState('');
  const [copied, setCopied] = useState(false);
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [activeTab, setActiveTab] = useState<'overview' | 'registrant' | 'technical' | 'raw'>('overview');

  // Load history
  useEffect(() => {
    const stored = localStorage.getItem('whoisHistory');
    if (stored) {
      try {
        setHistory(JSON.parse(stored));
      } catch (e) {
        console.error('Failed to parse WHOIS history:', e);
      }
    }
  }, []);

  // Calculate expiration status
  const calculateExpiration = (expirationDate?: string) => {
    if (!expirationDate) return { daysUntilExpiration: undefined, expirationStatus: undefined };
    
    const expDate = new Date(expirationDate);
    const now = new Date();
    const diffTime = expDate.getTime() - now.getTime();
    const daysUntilExpiration = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    let expirationStatus: 'expired' | 'critical' | 'warning' | 'monitor' | 'healthy';
    if (daysUntilExpiration < 0) expirationStatus = 'expired';
    else if (daysUntilExpiration <= 7) expirationStatus = 'critical';
    else if (daysUntilExpiration <= 30) expirationStatus = 'warning';
    else if (daysUntilExpiration <= 90) expirationStatus = 'monitor';
    else expirationStatus = 'healthy';

    return { daysUntilExpiration, expirationStatus };
  };

  // Add to history
  const addToHistory = (result: WhoisResult) => {
    if (!result.success || !result.data) return;

    const entry: HistoryEntry = {
      id: Date.now().toString(),
      domain: result.domain,
      registrar: result.data.registrar,
      expirationDate: result.data.expirationDate,
      daysUntilExpiration: result.daysUntilExpiration,
      expirationStatus: result.expirationStatus,
      timestamp: Date.now()
    };

    const newHistory = [entry, ...history.filter(h => h.domain !== result.domain)].slice(0, 15);
    setHistory(newHistory);
    localStorage.setItem('whoisHistory', JSON.stringify(newHistory));
  };

  // Single lookup
  const runLookup = async () => {
    if (!domain.trim()) return;
    setLoading(true);
    setError('');
    setResult(null);
    
    try {
      const res = await fetch(`/api/tools/whois?domain=${encodeURIComponent(domain.trim())}`);
      const data = await res.json();
      
      if (data.success && data.data) {
        const { daysUntilExpiration, expirationStatus } = calculateExpiration(data.data.expirationDate);
        const whoisResult: WhoisResult = {
          domain: domain.trim(),
          success: true,
          data: data.data,
          daysUntilExpiration,
          expirationStatus
        };
        setResult(whoisResult);
        addToHistory(whoisResult);
      } else {
        setError(data.error || 'WHOIS lookup failed');
        setResult({ domain: domain.trim(), success: false, error: data.error });
      }
    } catch (e: any) {
      setError(e?.message || 'Network error');
      setResult({ domain: domain.trim(), success: false, error: e?.message });
    } finally {
      setLoading(false);
    }
  };

  // Bulk lookup
  const runBulkLookup = async () => {
    const domains = bulkInput
      .split(/[\n,;]/)
      .map(d => d.trim())
      .filter(d => d.length > 0)
      .slice(0, 20); // Max 20 domains

    if (domains.length === 0) return;

    setLoading(true);
    setError('');
    setBulkResults([]);

    const results: WhoisResult[] = [];

    for (const dom of domains) {
      try {
        const res = await fetch(`/api/tools/whois?domain=${encodeURIComponent(dom)}`);
        const data = await res.json();

        if (data.success && data.data) {
          const { daysUntilExpiration, expirationStatus } = calculateExpiration(data.data.expirationDate);
          const whoisResult: WhoisResult = {
            domain: dom,
            success: true,
            data: data.data,
            daysUntilExpiration,
            expirationStatus
          };
          results.push(whoisResult);
          addToHistory(whoisResult);
        } else {
          results.push({ domain: dom, success: false, error: data.error || 'Failed' });
        }
      } catch (e: any) {
        results.push({ domain: dom, success: false, error: e?.message || 'Network error' });
      }

      // Update progress
      setBulkResults([...results]);
    }

    setLoading(false);
  };

  // Export bulk results
  const exportBulkCSV = () => {
    if (bulkResults.length === 0) return;

    const headers = ['Domain', 'Registrar', 'Expiration Date', 'Days Until Expiration', 'Status', 'Created', 'Updated', 'Name Servers'];
    const rows = bulkResults
      .filter(r => r.success && r.data)
      .map(r => [
        r.domain,
        r.data?.registrar || 'N/A',
        r.data?.expirationDate || 'N/A',
        r.daysUntilExpiration !== undefined ? r.daysUntilExpiration.toString() : 'N/A',
        r.expirationStatus || 'unknown',
        r.data?.creationDate || 'N/A',
        r.data?.updatedDate || 'N/A',
        r.data?.nameServers?.join('; ') || 'N/A'
      ]);

    const csv = [headers, ...rows].map(row => row.map(cell => `"${cell}"`).join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `whois-bulk-${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Download JSON report
  const downloadReport = () => {
    if (!result || !result.data) return;
    const json = JSON.stringify(result, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `whois-${result.domain}-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Copy domain info
  const copyInfo = () => {
    if (!result || !result.data) return;
    const text = `Domain: ${result.domain}\nRegistrar: ${result.data.registrar || 'N/A'}\nExpires: ${result.data.expirationDate || 'N/A'}\nDays Until Expiration: ${result.daysUntilExpiration !== undefined ? result.daysUntilExpiration : 'N/A'}\nStatus: ${result.data.status?.join(', ') || 'N/A'}\nName Servers: ${result.data.nameServers?.join(', ') || 'N/A'}`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Clear history
  const clearHistory = () => {
    setHistory([]);
    localStorage.removeItem('whoisHistory');
  };

  // Get status color
  const getStatusColor = (status?: string) => {
    switch (status) {
      case 'expired': return 'red';
      case 'critical': return 'red';
      case 'warning': return 'orange';
      case 'monitor': return 'yellow';
      case 'healthy': return 'green';
      default: return 'gray';
    }
  };

  // Get status icon
  const getStatusIcon = (status?: string) => {
    switch (status) {
      case 'expired': return <AlertTriangle className="w-5 h-5 text-red-400" />;
      case 'critical': return <AlertTriangle className="w-5 h-5 text-red-400" />;
      case 'warning': return <AlertCircle className="w-5 h-5 text-orange-400" />;
      case 'monitor': return <Info className="w-5 h-5 text-yellow-400" />;
      case 'healthy': return <CheckCircle className="w-5 h-5 text-green-400" />;
      default: return <Info className="w-5 h-5 text-gray-400" />;
    }
  };

  const statusColor = result?.expirationStatus ? getStatusColor(result.expirationStatus) : 'gray';

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <section className="relative overflow-hidden py-12 border-b border-gray-800">
        <div className="absolute inset-0 bg-grid-gray-900 [mask-image:linear-gradient(to_bottom,white_30%,transparent)]"></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-purple-500/10 rounded-full blur-3xl"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <button 
            onClick={() => onNavigate?.('toolbox')} 
            className="mb-6 flex items-center gap-2 text-gray-400 hover:text-cyan-400 transition-colors"
          >
            <ArrowLeft className="w-4 h-4"/> Back to Toolbox
          </button>
          
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 bg-purple-500/20 rounded-lg border border-purple-500/30">
              <Globe className="w-6 h-6 text-purple-400"/>
            </div>
            <div>
              <h1 className="text-3xl md:text-4xl font-bold">WHOIS Domain Lookup</h1>
              <p className="text-gray-400 mt-1">Domain registration & expiration monitoring</p>
            </div>
          </div>

          {/* Stats Dashboard */}
          {result && result.success && result.data && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
              <div className={`bg-gray-900/50 border-2 border-${statusColor}-500/50 rounded-lg p-4`}>
                <div className="text-gray-400 text-sm mb-1">Expiration Status</div>
                <div className="flex items-center gap-2">
                  {getStatusIcon(result.expirationStatus)}
                  <span className={`text-xl font-bold text-${statusColor}-400 capitalize`}>
                    {result.expirationStatus || 'Unknown'}
                  </span>
                </div>
              </div>
              <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-4">
                <div className="text-gray-400 text-sm mb-1">Days Until Expiry</div>
                <div className={`text-2xl font-bold ${result.daysUntilExpiration !== undefined ? (result.daysUntilExpiration < 30 ? 'text-red-400' : result.daysUntilExpiration < 90 ? 'text-yellow-400' : 'text-green-400') : 'text-gray-400'}`}>
                  {result.daysUntilExpiration !== undefined ? result.daysUntilExpiration : 'N/A'}
                </div>
              </div>
              <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-4">
                <div className="text-gray-400 text-sm mb-1">Registrar</div>
                <div className="text-sm font-bold text-cyan-400 truncate" title={result.data.registrar}>
                  {result.data.registrar || 'N/A'}
                </div>
              </div>
              <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-4">
                <div className="text-gray-400 text-sm mb-1">DNSSEC</div>
                <div className={`text-sm font-bold ${result.data.dnssec === 'signed' || result.data.dnssec === 'signedDelegation' ? 'text-green-400' : 'text-gray-400'}`}>
                  {result.data.dnssec || 'unsigned'}
                </div>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Main Content */}
      <section className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-3 gap-6">
            {/* Left Column - Lookup & Results */}
            <div className="lg:col-span-2 space-y-6">
              {/* Mode Selector */}
              <div className="flex gap-2">
                <button
                  onClick={() => setMode('single')}
                  className={`px-4 py-2 rounded-lg font-semibold transition flex items-center gap-2 ${
                    mode === 'single'
                      ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-black'
                      : 'bg-gray-800 text-gray-400 border border-gray-700 hover:border-purple-500/50'
                  }`}
                >
                  <Globe className="w-4 h-4" />
                  Single Domain
                </button>
                <button
                  onClick={() => setMode('bulk')}
                  className={`px-4 py-2 rounded-lg font-semibold transition flex items-center gap-2 ${
                    mode === 'bulk'
                      ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-black'
                      : 'bg-gray-800 text-gray-400 border border-gray-700 hover:border-purple-500/50'
                  }`}
                >
                  <FileText className="w-4 h-4" />
                  Bulk Lookup (Max 20)
                </button>
              </div>

              {/* Single Domain Input */}
              {mode === 'single' && (
                <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
                  <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                    <Search className="w-5 h-5 text-purple-400" />
                    Domain Lookup
                  </h3>
                  
                  <div className="space-y-4">
                    <div className="flex flex-col sm:flex-row gap-3">
                      <input 
                        className="flex-1 px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-purple-500 transition"
                        placeholder="example.com" 
                        value={domain} 
                        onChange={e => setDomain(e.target.value)}
                        onKeyPress={e => e.key === 'Enter' && runLookup()}
                        disabled={loading}
                      />
                      <button 
                        onClick={runLookup} 
                        disabled={loading || !domain.trim()}
                        className="px-6 py-3 rounded-lg bg-gradient-to-r from-purple-500 to-pink-500 text-black font-semibold flex items-center justify-center gap-2 hover:shadow-lg hover:shadow-purple-500/50 transition disabled:opacity-50 w-full sm:w-auto"
                      >
                        {loading ? (
                          <>
                            <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin"></div>
                            Looking up...
                          </>
                        ) : (
                          <>
                            <Search className="w-4 h-4" />
                            Lookup
                          </>
                        )}
                      </button>
                    </div>

                    {error && (
                      <div className="flex items-center gap-2 p-3 bg-red-500/10 border border-red-500/30 rounded-lg">
                        <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0" />
                        <p className="text-sm text-red-300">{error}</p>
                      </div>
                    )}

                    {/* Quick Test Domains */}
                    <div className="flex flex-wrap justify-center gap-2">
                      <span className="text-sm text-gray-400 w-full text-center sm:w-auto sm:text-left">Quick test:</span>
                      {['google.com', 'github.com', 'microsoft.com', 'amazon.com'].map(testDomain => (
                        <button
                          key={testDomain}
                          onClick={() => { setDomain(testDomain); }}
                          className="text-xs px-3 py-1 bg-gray-800 hover:bg-gray-700 border border-gray-700 rounded-full transition"
                        >
                          {testDomain}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Bulk Domain Input */}
              {mode === 'bulk' && (
                <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
                  <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                    <FileText className="w-5 h-5 text-purple-400" />
                    Bulk Domain Lookup
                  </h3>
                  
                  <div className="space-y-4">
                    <textarea 
                      className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-purple-500 transition h-32 resize-none font-mono text-sm"
                      placeholder="Enter domains (one per line or comma-separated, max 20)&#10;example.com&#10;google.com&#10;github.com" 
                      value={bulkInput} 
                      onChange={e => setBulkInput(e.target.value)}
                      disabled={loading}
                    />
                    
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-400">
                        {bulkInput.split(/[\n,;]/).filter(d => d.trim()).length} domains (max 20)
                      </span>
                      <div className="flex gap-2">
                        {bulkResults.length > 0 && (
                          <button
                            onClick={exportBulkCSV}
                            className="px-4 py-2 bg-gray-800 hover:bg-gray-700 rounded-lg border border-gray-700 transition flex items-center gap-2 text-sm"
                          >
                            <Download className="w-4 h-4" />
                            Export CSV
                          </button>
                        )}
                        <button 
                          onClick={runBulkLookup} 
                          disabled={loading || !bulkInput.trim()}
                          className="px-6 py-2 rounded-lg bg-gradient-to-r from-purple-500 to-pink-500 text-black font-semibold flex items-center gap-2 hover:shadow-lg hover:shadow-purple-500/50 transition disabled:opacity-50"
                        >
                          {loading ? (
                            <>
                              <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin"></div>
                              Processing...
                            </>
                          ) : (
                            <>
                              <Search className="w-4 h-4" />
                              Lookup All
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Single Domain Results */}
              {mode === 'single' && result && result.success && result.data && (
                <>
                  {/* Tab Navigation */}
                  <div className="flex flex-wrap justify-center gap-2">
                    {[
                      { id: 'overview', label: 'Overview', icon: <Info className="w-4 h-4" /> },
                      { id: 'registrant', label: 'Registrant', icon: <User className="w-4 h-4" /> },
                      { id: 'technical', label: 'Technical', icon: <Server className="w-4 h-4" /> },
                      { id: 'raw', label: 'Raw Data', icon: <FileText className="w-4 h-4" /> }
                    ].map(tab => (
                      <button
                        key={tab.id}
                        onClick={() => setActiveTab(tab.id as any)}
                        className={`px-4 py-2 rounded-lg font-semibold transition flex items-center gap-2 ${
                          activeTab === tab.id
                            ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-black'
                            : 'bg-gray-800 text-gray-400 border border-gray-700 hover:border-purple-500/50'
                        }`}
                      >
                        {tab.icon}
                        {tab.label}
                      </button>
                    ))}
                  </div>

                  {/* Tab Content */}
                  <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
                    <div className="flex flex-col sm:flex-row items-center justify-between mb-6 gap-4">
                      <h3 className="text-lg font-bold text-center sm:text-left">
                        {activeTab === 'overview' && 'Domain Overview'}
                        {activeTab === 'registrant' && 'Registrant Information'}
                        {activeTab === 'technical' && 'Technical Details'}
                        {activeTab === 'raw' && 'Raw WHOIS Data'}
                      </h3>
                      <div className="flex gap-2">
                        <button
                          onClick={copyInfo}
                          className="px-3 py-2 bg-gray-800 hover:bg-gray-700 rounded-lg border border-gray-700 transition flex items-center gap-2 text-sm"
                        >
                          {copied ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
                          Copy
                        </button>
                        <button
                          onClick={downloadReport}
                          className="px-3 py-2 bg-gray-800 hover:bg-gray-700 rounded-lg border border-gray-700 transition flex items-center gap-2 text-sm"
                        >
                          <Download className="w-4 h-4" />
                          JSON
                        </button>
                      </div>
                    </div>

                    {/* Overview Tab */}
                    {activeTab === 'overview' && (
                      <div className="space-y-4">
                        <div className="grid md:grid-cols-2 gap-4">
                          <div className="p-4 bg-gray-800/50 rounded-lg">
                            <div className="flex items-center gap-2 mb-2 text-purple-400">
                              <Globe className="w-4 h-4" />
                              <span className="font-semibold">Domain</span>
                            </div>
                            <div className="text-white font-mono">{result.domain}</div>
                          </div>

                          <div className="p-4 bg-gray-800/50 rounded-lg">
                            <div className="flex items-center gap-2 mb-2 text-cyan-400">
                              <Shield className="w-4 h-4" />
                              <span className="font-semibold">Registrar</span>
                            </div>
                            <div className="text-white text-sm">{result.data.registrar || 'N/A'}</div>
                          </div>

                          <div className={`p-4 rounded-lg border-2 ${result.expirationStatus === 'expired' || result.expirationStatus === 'critical' ? 'border-red-500/50 bg-red-500/10' : result.expirationStatus === 'warning' ? 'border-orange-500/50 bg-orange-500/10' : 'border-green-500/50 bg-green-500/10'}`}>
                            <div className="flex items-center gap-2 mb-2">
                              <Calendar className={`w-4 h-4 text-${statusColor}-400`} />
                              <span className="font-semibold">Expiration Date</span>
                            </div>
                            <div className={`text-${statusColor}-400 font-bold`}>
                              {result.data.expirationDate ? new Date(result.data.expirationDate).toLocaleDateString() : 'N/A'}
                            </div>
                            {result.daysUntilExpiration !== undefined && (
                              <div className="text-xs text-gray-400 mt-1">
                                {result.daysUntilExpiration < 0 ? 'EXPIRED' : `${result.daysUntilExpiration} days remaining`}
                              </div>
                            )}
                          </div>

                          <div className="p-4 bg-gray-800/50 rounded-lg">
                            <div className="flex items-center gap-2 mb-2 text-green-400">
                              <Calendar className="w-4 h-4" />
                              <span className="font-semibold">Creation Date</span>
                            </div>
                            <div className="text-white">{result.data.creationDate ? new Date(result.data.creationDate).toLocaleDateString() : 'N/A'}</div>
                          </div>
                        </div>

                        {/* Domain Status */}
                        {result.data.status && result.data.status.length > 0 && (
                          <div className="p-4 bg-gray-800/50 rounded-lg">
                            <h4 className="font-semibold mb-3 text-yellow-400">Domain Status</h4>
                            <div className="flex flex-wrap gap-2">
                              {result.data.status.map((status, idx) => (
                                <span key={idx} className="px-3 py-1 bg-yellow-500/20 border border-yellow-500/30 rounded-full text-yellow-400 text-xs font-semibold">
                                  {status}
                                </span>
                              ))}
                            </div>
                          </div>
                        )}

                        {/* Name Servers */}
                        {result.data.nameServers && result.data.nameServers.length > 0 && (
                          <div className="p-4 bg-gray-800/50 rounded-lg">
                            <h4 className="font-semibold mb-3 flex items-center gap-2">
                              <Server className="w-4 h-4 text-cyan-400" />
                              Name Servers ({result.data.nameServers.length})
                            </h4>
                            <div className="space-y-2">
                              {result.data.nameServers.map((ns, idx) => (
                                <div key={idx} className="p-2 bg-gray-900/50 rounded text-sm font-mono text-cyan-400">
                                  {ns}
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Registrant Tab */}
                    {activeTab === 'registrant' && (
                      <div className="space-y-4">
                        {result.data.registrant ? (
                          <div className="grid md:grid-cols-2 gap-4">
                            {result.data.registrant.name && (
                              <div className="p-4 bg-gray-800/50 rounded-lg">
                                <div className="text-gray-400 text-sm mb-1">Name</div>
                                <div className="text-white font-semibold">{result.data.registrant.name}</div>
                              </div>
                            )}
                            {result.data.registrant.organization && (
                              <div className="p-4 bg-gray-800/50 rounded-lg">
                                <div className="text-gray-400 text-sm mb-1">Organization</div>
                                <div className="text-white font-semibold">{result.data.registrant.organization}</div>
                              </div>
                            )}
                            {result.data.registrant.email && (
                              <div className="p-4 bg-gray-800/50 rounded-lg">
                                <div className="text-gray-400 text-sm mb-1">Email</div>
                                <div className="text-cyan-400 font-mono text-sm">{result.data.registrant.email}</div>
                              </div>
                            )}
                            {result.data.registrant.country && (
                              <div className="p-4 bg-gray-800/50 rounded-lg">
                                <div className="text-gray-400 text-sm mb-1">Country</div>
                                <div className="text-white font-semibold flex items-center gap-2">
                                  <MapPin className="w-4 h-4 text-red-400" />
                                  {result.data.registrant.country}
                                </div>
                              </div>
                            )}
                          </div>
                        ) : (
                          <div className="text-gray-400 p-4 bg-gray-800/50 rounded-lg">
                            Registrant information is not publicly available (WHOIS Privacy Protection may be enabled)
                          </div>
                        )}
                      </div>
                    )}

                    {/* Technical Tab */}
                    {activeTab === 'technical' && (
                      <div className="space-y-4">
                        <div className="grid md:grid-cols-2 gap-4">
                          <div className="p-4 bg-gray-800/50 rounded-lg">
                            <div className="text-gray-400 text-sm mb-1">DNSSEC</div>
                            <div className={`font-semibold ${result.data.dnssec === 'signed' || result.data.dnssec === 'signedDelegation' ? 'text-green-400' : 'text-gray-400'}`}>
                              {result.data.dnssec || 'unsigned'}
                            </div>
                          </div>

                          <div className="p-4 bg-gray-800/50 rounded-lg">
                            <div className="text-gray-400 text-sm mb-1">Last Updated</div>
                            <div className="text-white">{result.data.updatedDate ? new Date(result.data.updatedDate).toLocaleDateString() : 'N/A'}</div>
                          </div>
                        </div>

                        {/* Admin Contact */}
                        {result.data.admin && (
                          <div className="p-4 bg-gray-800/50 rounded-lg">
                            <h4 className="font-semibold mb-3 text-cyan-400">Administrative Contact</h4>
                            <div className="space-y-2 text-sm">
                              {result.data.admin.name && <div className="text-white">Name: {result.data.admin.name}</div>}
                              {result.data.admin.email && <div className="text-cyan-400 font-mono">Email: {result.data.admin.email}</div>}
                            </div>
                          </div>
                        )}

                        {/* Tech Contact */}
                        {result.data.tech && (
                          <div className="p-4 bg-gray-800/50 rounded-lg">
                            <h4 className="font-semibold mb-3 text-purple-400">Technical Contact</h4>
                            <div className="space-y-2 text-sm">
                              {result.data.tech.name && <div className="text-white">Name: {result.data.tech.name}</div>}
                              {result.data.tech.email && <div className="text-cyan-400 font-mono">Email: {result.data.tech.email}</div>}
                            </div>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Raw Data Tab */}
                    {activeTab === 'raw' && (
                      <div className="max-h-[600px] overflow-y-auto">
                        <pre className="text-xs text-gray-300 whitespace-pre-wrap break-all font-mono p-4 bg-gray-800/50 rounded-lg">
                          {result.data.rawData || JSON.stringify(result.data, null, 2)}
                        </pre>
                      </div>
                    )}
                  </div>
                </>
              )}

              {/* Bulk Results */}
              {mode === 'bulk' && bulkResults.length > 0 && (
                <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
                  <h3 className="text-lg font-bold mb-4">
                    Bulk Lookup Results ({bulkResults.length})
                  </h3>
                  <div className="space-y-2 max-h-[600px] overflow-y-auto">
                    {bulkResults.map((res, idx) => (
                      <div
                        key={idx}
                        className={`p-4 rounded-lg border-2 ${
                          !res.success
                            ? 'border-red-500/50 bg-red-500/10'
                            : res.expirationStatus === 'expired' || res.expirationStatus === 'critical'
                            ? 'border-red-500/50 bg-red-500/10'
                            : res.expirationStatus === 'warning'
                            ? 'border-orange-500/50 bg-orange-500/10'
                            : 'border-green-500/50 bg-green-500/10'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex-1">
                            <div className="font-bold text-white mb-1 flex items-center gap-2">
                              {getStatusIcon(res.expirationStatus)}
                              {res.domain}
                            </div>
                            {res.success && res.data ? (
                              <div className="text-sm text-gray-400 space-y-1">
                                <div>Registrar: <span className="text-cyan-400">{res.data.registrar || 'N/A'}</span></div>
                                <div>Expires: <span className={`text-${getStatusColor(res.expirationStatus)}-400 font-semibold`}>
                                  {res.data.expirationDate ? new Date(res.data.expirationDate).toLocaleDateString() : 'N/A'}
                                </span></div>
                              </div>
                            ) : (
                              <div className="text-sm text-red-400">Error: {res.error || 'Lookup failed'}</div>
                            )}
                          </div>
                          <div className="text-right">
                            {res.success && res.daysUntilExpiration !== undefined && (
                              <div className={`text-2xl font-bold text-${getStatusColor(res.expirationStatus)}-400`}>
                                {res.daysUntilExpiration}
                              </div>
                            )}
                            {res.success && res.daysUntilExpiration !== undefined && (
                              <div className="text-xs text-gray-400">days left</div>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Right Column - History & Guide */}
            <div className="space-y-6">
              {/* Expiration Alert Guide */}
              <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
                <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                  <AlertCircle className="w-5 h-5 text-yellow-400" />
                  Expiration Status
                </h3>
                <div className="space-y-3 text-sm">
                  <div className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-green-400 mt-0.5" />
                    <div>
                      <div className="font-semibold text-green-400">Healthy</div>
                      <div className="text-gray-400 text-xs">&gt;90 days remaining</div>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <Info className="w-4 h-4 text-yellow-400 mt-0.5" />
                    <div>
                      <div className="font-semibold text-yellow-400">Monitor</div>
                      <div className="text-gray-400 text-xs">30-90 days remaining</div>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 text-orange-400 mt-0.5" />
                    <div>
                      <div className="font-semibold text-orange-400">Warning</div>
                      <div className="text-gray-400 text-xs">7-30 days remaining</div>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <AlertTriangle className="w-4 h-4 text-red-400 mt-0.5" />
                    <div>
                      <div className="font-semibold text-red-400">Critical</div>
                      <div className="text-gray-400 text-xs">&lt;7 days or expired</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Lookup History */}
              {history.length > 0 && (
                <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-bold flex items-center gap-2">
                      <Clock className="w-5 h-5 text-purple-400" />
                      Recent Lookups
                    </h3>
                    <button
                      onClick={clearHistory}
                      className="text-xs text-gray-400 hover:text-red-400 transition flex items-center gap-1"
                    >
                      <Trash2 className="w-3 h-3" />
                      Clear
                    </button>
                  </div>
                  <div className="space-y-2 max-h-96 overflow-y-auto">
                    {history.map(entry => {
                      const entryStatusColor = getStatusColor(entry.expirationStatus);
                      return (
                        <button
                          key={entry.id}
                          onClick={() => { setMode('single'); setDomain(entry.domain); }}
                          className="w-full p-3 bg-gray-800/50 hover:bg-gray-800 border border-gray-700 hover:border-purple-500/50 rounded-lg transition-all text-left"
                        >
                          <div className="font-mono text-purple-400 font-semibold text-sm mb-2 truncate">
                            {entry.domain}
                          </div>
                          {entry.registrar && (
                            <div className="text-xs text-gray-400 mb-1 truncate">
                              {entry.registrar}
                            </div>
                          )}
                          <div className="flex items-center justify-between text-xs">
                            <span className={`px-2 py-1 rounded bg-${entryStatusColor}-500/20 text-${entryStatusColor}-400 font-bold`}>
                              {entry.daysUntilExpiration !== undefined ? `${entry.daysUntilExpiration}d` : 'N/A'}
                            </span>
                            <span className="text-gray-500">
                              {new Date(entry.timestamp).toLocaleDateString()}
                            </span>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Best Practices */}
              <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
                <h3 className="text-lg font-bold mb-4">Domain Best Practices</h3>
                <div className="space-y-3 text-sm text-gray-400">
                  <div><strong className="text-green-400">✓</strong> Renew 30+ days before expiration</div>
                  <div><strong className="text-green-400">✓</strong> Enable auto-renewal</div>
                  <div><strong className="text-green-400">✓</strong> Use WHOIS privacy protection</div>
                  <div><strong className="text-green-400">✓</strong> Enable DNSSEC</div>
                  <div><strong className="text-red-400">✗</strong> Don't let domains expire</div>
                  <div><strong className="text-red-400">✗</strong> Don't ignore renewal notices</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default WhoisLookupPage;
