import React, { useState, useEffect } from 'react';
import {
  Cpu,
  MemoryStick,
  Server,
  Network,
  Users,
  Activity,
  AlertCircle,
  CheckCircle,
  Clock,
  Database,
  Zap,
  TrendingUp,
  Globe,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  RadialBarChart,
  RadialBar,
  Legend,
} from 'recharts';
import { getSocket } from '../../services/socket';

/**
 * IAMAI Platform Status Dashboard
 *
 * Integrated Services & APIs:
 * - AI Providers: OpenAI, Anthropic Claude, Google Gemini, RunwayML, Stability AI, Replicate, HuggingFace
 * - Databases: PostgreSQL (Main), MongoDB (Auth), Redis (Cache)
 * - Services: Authentication, Email (SMTP), WebSocket Server
 * - Payments: Stripe, PayPal
 * - Storage: AWS S3
 * - Geolocation: IPInfo, MaxMind GeoIP
 *
 * AI Agents (17 Total):
 * - AI Girlfriend Pro, EmoAI, PDFMind, CVSmash, ChatRevive, TokBoost, YouGen, AgentX, AutoChat
 * - Comedy Chad, Lazy Larry, Flirty Fiona, Sassy Sarah, Nerdy Neil, Cool Kyle, Zen Master Zara, Gamer Gary
 */

const StatusPage = ({ onNavigate }) => {
  const [systemMetrics, setSystemMetrics] = useState({
    cpu: 68,
    memory: 54,
    disk: 42,
    network: 78,
  });

  const [requestsData, setRequestsData] = useState([
    { time: '00:00', requests: 1200 },
    { time: '04:00', requests: 800 },
    { time: '08:00', requests: 2400 },
    { time: '12:00', requests: 3800 },
    { time: '16:00', requests: 3200 },
    { time: '20:00', requests: 2100 },
  ]);

  const [performanceData, setPerformanceData] = useState([
    { name: 'Response Time', value: 125, fill: '#10B981' },
    { name: 'Throughput', value: 89, fill: '#3B82F6' },
    { name: 'Availability', value: 99.9, fill: '#8B5CF6' },
  ]);

  const [serverLoad, setServerLoad] = useState([
    { server: 'US-East', load: 65, fill: '#EF4444' },
    { server: 'EU-West', load: 45, fill: '#F59E0B' },
    { server: 'Asia-Pacific', load: 78, fill: '#10B981' },
    { server: 'US-West', load: 52, fill: '#3B82F6' },
  ]);

  const [apiStatus, setApiStatus] = useState([
    { name: 'OpenAI API', status: 'Operational', responseTime: 145, requests: 15240 },
    { name: 'Anthropic Claude', status: 'Operational', responseTime: 198, requests: 12680 },
    { name: 'Google Gemini', status: 'Operational', responseTime: 167, requests: 14520 },
    { name: 'RunwayML', status: 'Operational', responseTime: 234, requests: 3840 },
    { name: 'Stability AI', status: 'Operational', responseTime: 189, requests: 5620 },
    { name: 'Replicate', status: 'Operational', responseTime: 276, requests: 2910 },
    { name: 'HuggingFace', status: 'Operational', responseTime: 156, requests: 4780 },
    { name: 'PostgreSQL DB', status: 'Operational', responseTime: 12, requests: 45200 },
    { name: 'MongoDB', status: 'Operational', responseTime: 18, requests: 28400 },
    { name: 'Redis Cache', status: 'Operational', responseTime: 3, requests: 89600 },
    { name: 'Auth Service', status: 'Operational', responseTime: 45, requests: 18920 },
    { name: 'Email Service', status: 'Operational', responseTime: 89, requests: 2340 },
    { name: 'Stripe Payments', status: 'Operational', responseTime: 134, requests: 1560 },
    { name: 'PayPal Payments', status: 'Operational', responseTime: 178, requests: 890 },
    { name: 'AWS S3 Storage', status: 'Operational', responseTime: 98, requests: 6720 },
  ]);

  const [agentStatus, setAgentStatus] = useState([
    { name: 'AI Girlfriend Pro', status: 'Active', load: 78, tasks: 245 },
    { name: 'EmoAI', status: 'Active', load: 52, tasks: 189 },
    { name: 'PDFMind', status: 'Active', load: 91, tasks: 312 },
    { name: 'CVSmash', status: 'Active', load: 45, tasks: 156 },
    { name: 'ChatRevive', status: 'Active', load: 68, tasks: 223 },
    { name: 'TokBoost', status: 'Active', load: 55, tasks: 198 },
    { name: 'YouGen', status: 'Active', load: 62, tasks: 207 },
    { name: 'AgentX', status: 'Active', load: 84, tasks: 289 },
    { name: 'AutoChat', status: 'Active', load: 48, tasks: 167 },
    { name: 'Comedy Chad', status: 'Active', load: 38, tasks: 134 },
    { name: 'Lazy Larry', status: 'Idle', load: 12, tasks: 45 },
    { name: 'Flirty Fiona', status: 'Active', load: 71, tasks: 234 },
    { name: 'Sassy Sarah', status: 'Active', load: 76, tasks: 256 },
    { name: 'Nerdy Neil', status: 'Active', load: 59, tasks: 201 },
    { name: 'Cool Kyle', status: 'Active', load: 53, tasks: 189 },
    { name: 'Zen Master Zara', status: 'Active', load: 41, tasks: 145 },
    { name: 'Gamer Gary', status: 'Active', load: 88, tasks: 298 },
  ]);

  useEffect(() => {
    try {
      const socket = getSocket();

      const handleStatusUpdate = data => {
        if (data.system) {
          setSystemMetrics({
            cpu: data.system.cpuUsage || 0,
            memory: data.system.memoryUsage || 0,
            disk: data.system.diskUsage || 0,
          });
        }
        if (data.apis) {
          setApiStatus(data.apis);
        }
        if (data.agents) {
          setAgentStatus(data.agents);
        }
      };

      // Listen for updates
      socket.on('status:update', handleStatusUpdate);

      // Request initial data and set up interval
      const fetchData = () => socket.emit('status:get');
      fetchData();
      const interval = setInterval(fetchData, 30000);

      // Clean up on component unmount
      return () => {
        clearInterval(interval);
        socket.off('status:update', handleStatusUpdate);
      };
    } catch (error) {
      console.warn('WebSocket connection failed, using mock data:', error);
    }
  }, []);

  // Circular gauge component
  const CircularGauge = ({ value, label, icon: Icon, color }) => {
    const data = [{ name: label, value, fill: color }];
    return (
      <div className="flex flex-col items-center">
        <ResponsiveContainer width={140} height={140}>
          <RadialBarChart
            cx="50%"
            cy="50%"
            innerRadius="70%"
            outerRadius="100%"
            barSize={12}
            data={data}
            startAngle={90}
            endAngle={-270}
          >
            <RadialBar background dataKey="value" cornerRadius={10} />
            <text
              x="50%"
              y="50%"
              textAnchor="middle"
              dominantBaseline="middle"
              className="fill-white text-2xl font-bold"
            >
              {value}%
            </text>
          </RadialBarChart>
        </ResponsiveContainer>
        <div className="mt-2 flex items-center text-sm text-gray-300 font-medium">
          <Icon className="w-4 h-4 mr-2" style={{ color }} />
          {label}
        </div>
      </div>
    );
  };

  const COLORS = ['#EF4444', '#F59E0B', '#10B981', '#3B82F6', '#8B5CF6', '#EC4899'];

  // Calculate overall system health
  const getSystemHealth = () => {
    const avgLoad =
      ((systemMetrics?.cpu || 0) + (systemMetrics?.memory || 0) + (systemMetrics?.disk || 0)) / 3;
    const operationalApis = (apiStatus || []).filter(api => api.status === 'Operational').length;
    const activeAgents = (agentStatus || []).filter(agent => agent.status === 'Active').length;

    if (
      avgLoad < 60 &&
      operationalApis === (apiStatus || []).length &&
      activeAgents === (agentStatus || []).length
    ) {
      return {
        status: 'All Systems Operational',
        color: 'from-green-400 to-emerald-500',
        icon: CheckCircle,
        bgColor: 'bg-green-500/10',
        borderColor: 'border-green-500/30',
      };
    } else if (avgLoad < 80 && operationalApis >= (apiStatus || []).length * 0.8) {
      return {
        status: 'System Performance Optimal',
        color: 'from-blue-400 to-cyan-500',
        icon: Activity,
        bgColor: 'bg-blue-500/10',
        borderColor: 'border-blue-500/30',
      };
    } else if (avgLoad < 90) {
      return {
        status: 'Elevated System Load',
        color: 'from-yellow-400 to-orange-500',
        icon: AlertCircle,
        bgColor: 'bg-yellow-500/10',
        borderColor: 'border-yellow-500/30',
      };
    } else {
      return {
        status: 'System Under Heavy Load',
        color: 'from-red-400 to-pink-500',
        icon: AlertCircle,
        bgColor: 'bg-red-500/10',
        borderColor: 'border-red-500/30',
      };
    }
  };

  const systemHealth = getSystemHealth();
  const StatusIcon = systemHealth.icon;

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Hero Section */}
      <section className="relative overflow-hidden border-b border-gray-800">
        <div className="absolute inset-0 bg-grid-gray-900 [mask-image:linear-gradient(to_bottom,white_30%,transparent)]"></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-to-r from-cyan-500/10 to-purple-500/10 rounded-full blur-3xl"></div>

        <div className="container mx-auto px-6 py-12 md:py-16 relative z-10">
          {/* Status Badge */}
          <div className="flex justify-center mb-6">
            <div
              className={`inline-flex items-center px-6 py-3 rounded-full bg-gradient-to-r ${systemHealth.color} text-white font-bold text-sm sm:text-base shadow-lg`}
            >
              <StatusIcon className="w-5 h-5 sm:w-6 sm:h-6 mr-2 animate-pulse" />
              {systemHealth.status}
            </div>
          </div>

          {/* Title */}
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold text-center mb-4 bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400">
            Platform Status
          </h1>

          {/* Subtitle */}
          <p className="text-center text-gray-400 text-base md:text-lg mb-8 max-w-2xl mx-auto">
            Real-time monitoring dashboard tracking {(apiStatus || []).length} APIs,{' '}
            {(agentStatus || []).length} AI agents, and critical system metrics across all regions.
          </p>

          {/* Quick Stats */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 sm:gap-6 max-w-4xl mx-auto">
            <div className="text-center">
              <div className="text-2xl sm:text-3xl font-bold text-green-400">
                {(apiStatus || []).filter(a => a.status === 'Operational').length}/
                {(apiStatus || []).length}
              </div>
              <div className="text-xs sm:text-sm text-gray-400">APIs Online</div>
            </div>
            <div className="text-center">
              <div className="text-2xl sm:text-3xl font-bold text-cyan-400">
                {(agentStatus || []).filter(a => a.status === 'Active').length}/
                {(agentStatus || []).length}
              </div>
              <div className="text-xs sm:text-sm text-gray-400">Agents Active</div>
            </div>
            <div className="text-center">
              <div className="text-2xl sm:text-3xl font-bold text-purple-400">
                {Math.round(
                  ((systemMetrics?.cpu || 0) +
                    (systemMetrics?.memory || 0) +
                    (systemMetrics?.disk || 0)) /
                    3
                )}
                %
              </div>
              <div className="text-xs sm:text-sm text-gray-400">Avg Load</div>
            </div>
            <div className="text-center">
              <div className="text-2xl sm:text-3xl font-bold text-pink-400">99.9%</div>
              <div className="text-xs sm:text-sm text-gray-400">Uptime</div>
            </div>
          </div>
        </div>
      </section>

      <div className="container mx-auto px-3 sm:px-6 py-6 sm:py-8">
        {/* Hero Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-8">
          <button
            onClick={() => onNavigate('status-analytics')}
            className="w-full sm:w-auto bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white font-bold py-3 px-8 rounded-xl shadow-xl transform hover:scale-105 transition-all duration-200 flex items-center justify-center group"
          >
            <TrendingUp className="mr-2 w-5 h-5 group-hover:rotate-12 transition-transform" />
            View Analytics
          </button>
          <button
            onClick={() => onNavigate('status-api-status')}
            className="w-full sm:w-auto bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700 text-white font-bold py-3 px-8 rounded-xl shadow-xl transform hover:scale-105 transition-all duration-200 flex items-center justify-center group"
          >
            <Network className="mr-2 w-5 h-5 group-hover:scale-110 transition-transform" />
            API Status
          </button>
        </div>

        {/* Main Grid Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 sm:gap-6">
          {/* Left Column - Bar Charts & Metrics */}
          <div className="lg:col-span-3 space-y-4 sm:space-y-6">
            {/* Requests Bar Chart */}
            <div className="bg-gray-900/50 backdrop-blur-sm p-4 sm:p-6 rounded-xl border border-cyan-500/30">
              <h3 className="text-xs sm:text-sm font-bold text-cyan-400 mb-3 uppercase tracking-wider">
                API Requests
              </h3>
              <ResponsiveContainer width="100%" height={180}>
                <BarChart data={requestsData}>
                  <Bar dataKey="requests" radius={[8, 8, 0, 0]}>
                    {requestsData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Bar>
                  <XAxis dataKey="time" tick={{ fill: '#9CA3AF', fontSize: 10 }} />
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Status Indicators */}
            <div className="bg-gray-900/50 backdrop-blur-sm p-4 sm:p-6 rounded-xl border border-purple-500/30">
              <h3 className="text-xs sm:text-sm font-bold text-purple-400 mb-3 uppercase tracking-wider">
                Service Status
              </h3>
              <div className="space-y-2">
                {(apiStatus || []).slice(0, 4).map((api, index) => (
                  <div key={index} className="flex items-center justify-between text-xs">
                    <div className="flex items-center">
                      <div
                        className={`w-2 h-2 rounded-full mr-2 ${api.status === 'Operational' ? 'bg-green-400' : 'bg-red-400'}`}
                      />
                      <span className="text-gray-300">{api.name}</span>
                    </div>
                    <span className="text-green-400 font-semibold">{api.responseTime}ms</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Center Column - Main Charts */}
          <div className="lg:col-span-6 space-y-4">
            {/* Circular Gauges Row */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div className="bg-gray-900/50 backdrop-blur-sm p-3 rounded-xl border border-pink-500/30">
                <CircularGauge
                  value={systemMetrics?.cpu || 0}
                  label="CPU"
                  icon={Cpu}
                  color="#EC4899"
                />
              </div>
              <div className="bg-gray-900/50 backdrop-blur-sm p-3 rounded-xl border border-blue-500/30">
                <CircularGauge
                  value={systemMetrics?.memory || 0}
                  label="Memory"
                  icon={MemoryStick}
                  color="#3B82F6"
                />
              </div>
              <div className="bg-gray-900/50 backdrop-blur-sm p-3 rounded-xl border border-purple-500/30">
                <CircularGauge
                  value={systemMetrics?.disk || 0}
                  label="Storage"
                  icon={Database}
                  color="#8B5CF6"
                />
              </div>
              <div className="bg-gray-900/50 backdrop-blur-sm p-3 rounded-xl border border-cyan-500/30">
                <CircularGauge
                  value={systemMetrics?.network || 0}
                  label="Network"
                  icon={Globe}
                  color="#06B6D4"
                />
              </div>
            </div>

            {/* Area Chart - Performance Trend */}
            <div className="bg-gray-900/50 backdrop-blur-sm p-4 sm:p-6 rounded-xl border border-green-500/30">
              <h3 className="text-xs sm:text-sm font-bold text-green-400 mb-3 uppercase tracking-wider flex items-center">
                <TrendingUp className="w-4 h-4 mr-2" />
                Performance Trend
              </h3>
              <ResponsiveContainer width="100%" height={200}>
                <AreaChart data={requestsData}>
                  <defs>
                    <linearGradient id="colorRequests" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#10B981" stopOpacity={0.8} />
                      <stop offset="95%" stopColor="#10B981" stopOpacity={0.1} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis dataKey="time" tick={{ fill: '#9CA3AF', fontSize: 10 }} />
                  <YAxis tick={{ fill: '#9CA3AF', fontSize: 10 }} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#1F2937',
                      border: '1px solid #374151',
                      borderRadius: '8px',
                    }}
                    labelStyle={{ color: '#9CA3AF' }}
                  />
                  <Area
                    type="monotone"
                    dataKey="requests"
                    stroke="#10B981"
                    fillOpacity={1}
                    fill="url(#colorRequests)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            {/* Line Chart - Agent Activity */}
            <div className="bg-gray-900/50 backdrop-blur-sm p-4 sm:p-6 rounded-xl border border-orange-500/30">
              <h3 className="text-xs sm:text-sm font-bold text-orange-400 mb-3 uppercase tracking-wider flex items-center">
                <Activity className="w-4 h-4 mr-2" />
                Agent Activity
              </h3>
              <ResponsiveContainer width="100%" height={180}>
                <LineChart data={requestsData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis dataKey="time" tick={{ fill: '#9CA3AF', fontSize: 10 }} />
                  <YAxis tick={{ fill: '#9CA3AF', fontSize: 10 }} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#1F2937',
                      border: '1px solid #374151',
                      borderRadius: '8px',
                    }}
                  />
                  <Line
                    type="monotone"
                    dataKey="requests"
                    stroke="#F59E0B"
                    strokeWidth={3}
                    dot={{ fill: '#F59E0B', r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Right Column - Stats & Pie Chart */}
          <div className="lg:col-span-3 space-y-4">
            {/* Big Stats Cards */}
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-gradient-to-br from-pink-500/20 to-pink-600/10 backdrop-blur-sm p-4 rounded-lg border border-pink-500/30">
                <div className="text-3xl font-bold text-pink-400">92%</div>
                <div className="text-xs text-gray-400 mt-1">Uptime</div>
              </div>
              <div className="bg-gradient-to-br from-cyan-500/20 to-cyan-600/10 backdrop-blur-sm p-4 rounded-lg border border-cyan-500/30">
                <div className="text-3xl font-bold text-cyan-400">58%</div>
                <div className="text-xs text-gray-400 mt-1">Load</div>
              </div>
              <div className="bg-gradient-to-br from-orange-500/20 to-orange-600/10 backdrop-blur-sm p-4 rounded-lg border border-orange-500/30">
                <div className="text-3xl font-bold text-orange-400">47%</div>
                <div className="text-xs text-gray-400 mt-1">Cache Hit</div>
              </div>
              <div className="bg-gradient-to-br from-green-500/20 to-green-600/10 backdrop-blur-sm p-4 rounded-lg border border-green-500/30">
                <div className="text-3xl font-bold text-green-400">23K</div>
                <div className="text-xs text-gray-400 mt-1">Users</div>
              </div>
            </div>

            {/* Server Load Bar Chart */}
            <div className="bg-gray-900/50 backdrop-blur-sm p-4 sm:p-6 rounded-xl border border-blue-500/30">
              <h3 className="text-xs sm:text-sm font-bold text-blue-400 mb-3 uppercase tracking-wider">
                Server Load
              </h3>
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={serverLoad} layout="vertical">
                  <XAxis type="number" tick={{ fill: '#9CA3AF', fontSize: 10 }} />
                  <YAxis
                    dataKey="server"
                    type="category"
                    tick={{ fill: '#9CA3AF', fontSize: 10 }}
                    width={80}
                  />
                  <Bar dataKey="load" radius={[0, 8, 8, 0]}>
                    {serverLoad.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.fill} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Agent Tasks */}
            <div className="bg-gray-900/50 backdrop-blur-sm p-4 sm:p-6 rounded-xl border border-purple-500/30">
              <h3 className="text-xs sm:text-sm font-bold text-purple-400 mb-3 uppercase tracking-wider">
                Active Agents
              </h3>
              <div className="space-y-2">
                {(agentStatus || []).map((agent, index) => (
                  <div key={index} className="flex items-center justify-between text-xs">
                    <div className="flex items-center">
                      <Zap className="w-3 h-3 mr-2" style={{ color: COLORS[index] }} />
                      <span className="text-gray-300">{agent.name}</span>
                    </div>
                    <span className="font-semibold" style={{ color: COLORS[index] }}>
                      {agent.tasks}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StatusPage;
