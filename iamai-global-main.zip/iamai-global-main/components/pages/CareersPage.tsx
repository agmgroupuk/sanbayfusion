import React from 'react';
import { Page } from '../../App';

interface CareersPageProps {
  onNavigate: (page: Page) => void;
}

const ValueCard: React.FC<{ icon: string, title: string, description: string }> = ({ icon, title, description }) => (
    <div className="bg-transparent p-6 flex items-start space-x-4">
        <div className="flex-shrink-0 text-cyan-400 text-2xl">
            <i className={icon}></i>
        </div>
        <div>
            <h3 className="text-lg font-semibold text-white">{title}</h3>
            <p className="mt-1 text-gray-400">{description}</p>
        </div>
    </div>
);

const JobListing: React.FC<{ title: string, department: string, location: string, onApply: () => void }> = ({ title, department, location, onApply }) => (
    <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6 flex flex-col sm:flex-row justify-between items-start sm:items-center hover:border-cyan-500/50 transition-colors">
        <div>
            <h3 className="text-xl font-bold text-white">{title}</h3>
            <p className="text-gray-400 mt-1">{department} &middot; {location}</p>
        </div>
        <button 
          onClick={onApply}
          title={`Apply for the ${title} position`} 
          className="mt-4 sm:mt-0 bg-gradient-to-r from-cyan-500 to-purple-500 text-black font-semibold px-6 py-2.5 rounded-full hover:shadow-lg hover:shadow-cyan-500/50 transition-all duration-300 flex-shrink-0"
        >
            Apply Now
        </button>
    </div>
);


const CareersPage: React.FC<CareersPageProps> = ({ onNavigate }) => {
    const values = [
        { icon: 'fa-solid fa-rocket', title: 'Innovate Fearlessly', description: 'We tackle ambitious challenges and push the boundaries of AI to create groundbreaking technology.' },
        { icon: 'fa-solid fa-users', title: 'Collaborate Radically', description: 'Our best work comes from diverse teams working together with trust and respect.' },
        { icon: 'fa-solid fa-brain', title: 'Embrace Curiosity', description: 'We are lifelong learners who are passionate about exploring new ideas and developing our skills.' },
        { icon: 'fa-solid fa-hand-holding-heart', title: 'Act with Integrity', description: 'We are committed to building ethical, transparent, and responsible AI that benefits everyone.' },
    ];
    
    const openPositions = [
        { title: 'Senior AI Engineer', department: 'Engineering', location: 'Remote' },
        { title: 'Frontend Developer (React)', department: 'Engineering', location: 'Remote' },
        { title: 'UX/UI Designer', department: 'Design', location: 'Remote' },
        { title: 'Product Manager - Agent Platform', department: 'Product', location: 'Remote' },
        { title: 'Developer Advocate', department: 'Marketing', location: 'Remote' },
    ];

  return (
    <div className="bg-black text-white">
      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 md:py-32">
        <div className="absolute inset-0 bg-grid-gray-900 [mask-image:linear-gradient(to_bottom,white_30%,transparent)]"></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-cyan-500/10 rounded-full blur-3xl"></div>
        <div className="container mx-auto px-6 text-center relative z-10">
            <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight mb-4">
                Shape the Future of AI With Us
            </h1>
            <p className="max-w-3xl mx-auto text-lg md:text-xl text-gray-400">
                We are building the next generation of human-AI interaction. If you are passionate, driven, and want to solve meaningful problems, we want to hear from you.
            </p>
        </div>
      </section>

      {/* Why Join Us Section */}
      <section className="py-20 md:py-28 bg-[#0a0a0a]">
         <div className="container mx-auto px-6">
            <div className="text-center mb-12">
                <h2 className="text-3xl md:text-4xl font-bold text-white">Why You'll Love Working Here</h2>
            </div>
            <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-10">
                {values.map(value => <ValueCard key={value.title} {...value} />)}
            </div>
         </div>
      </section>
      
      {/* Open Positions Section */}
      <section className="py-20 md:py-28 bg-black">
        <div className="container mx-auto px-6">
            <div className="text-center mb-12">
                 <h2 className="text-3xl md:text-4xl font-bold text-white">Open Positions</h2>
                 <p className="max-w-2xl mx-auto mt-4 text-gray-400">
                    We're always looking for talented people to join our team. Explore our current openings below.
                 </p>
            </div>
            <div className="max-w-4xl mx-auto space-y-6">
                 {openPositions.map(job => <JobListing key={job.title} {...job} onApply={() => onNavigate('career-application')} />)}
                 <div className="text-center pt-8">
                     <p className="text-gray-400">Don't see a role that fits? <a href="#" className="text-cyan-400 hover:underline">Get in touch</a>, we'd still love to hear from you.</p>
                 </div>
            </div>
        </div>
      </section>
    </div>
  );
};

export default CareersPage;