import React, { useState } from 'react';
import { Page } from '../../App';
import { ChevronLeft, ChevronRight, Check, Upload, X } from 'lucide-react';

interface CareerApplicationPageProps {
  onNavigate: (page: Page) => void;
}

interface FormData {
  // Personal Information
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  
  // Address Information
  street: string;
  city: string;
  state: string;
  zipCode: string;
  country: string;
  
  // Professional Summary
  professionalSummary: string;
  
  // Work Experience
  workExperiences: Array<{
    company: string;
    position: string;
    startDate: string;
    endDate: string;
    currentlyWorking: boolean;
    description: string;
  }>;
  
  // Education
  educations: Array<{
    school: string;
    degree: string;
    field: string;
    graduationDate: string;
  }>;
  
  // Skills
  skills: string;
  
  // File Uploads
  attachments: File[];
}

const CareerApplicationPage: React.FC<CareerApplicationPageProps> = ({ onNavigate }) => {
  const [currentStep, setCurrentStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState<FormData>({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    street: '',
    city: '',
    state: '',
    zipCode: '',
    country: '',
    professionalSummary: '',
    workExperiences: [{ company: '', position: '', startDate: '', endDate: '', currentlyWorking: false, description: '' }],
    educations: [{ school: '', degree: '', field: '', graduationDate: '' }],
    skills: '',
    attachments: [],
  });

  const totalSteps = 7;

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked : value
    }));
  };

  const handleWorkExperienceChange = (index: number, field: string, value: string | boolean) => {
    setFormData(prev => ({
      ...prev,
      workExperiences: prev.workExperiences.map((exp, i) =>
        i === index ? { ...exp, [field]: value } : exp
      )
    }));
  };

  const handleEducationChange = (index: number, field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      educations: prev.educations.map((edu, i) =>
        i === index ? { ...edu, [field]: value } : edu
      )
    }));
  };

  const addWorkExperience = () => {
    setFormData(prev => ({
      ...prev,
      workExperiences: [...prev.workExperiences, { company: '', position: '', startDate: '', endDate: '', currentlyWorking: false, description: '' }]
    }));
  };

  const removeWorkExperience = (index: number) => {
    setFormData(prev => ({
      ...prev,
      workExperiences: prev.workExperiences.filter((_, i) => i !== index)
    }));
  };

  const addEducation = () => {
    setFormData(prev => ({
      ...prev,
      educations: [...prev.educations, { school: '', degree: '', field: '', graduationDate: '' }]
    }));
  };

  const removeEducation = (index: number) => {
    setFormData(prev => ({
      ...prev,
      educations: prev.educations.filter((_, i) => i !== index)
    }));
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      setFormData(prev => ({
        ...prev,
        attachments: [...prev.attachments, ...Array.from(files)]
      }));
    }
  };

  const removeAttachment = (index: number) => {
    setFormData(prev => ({
      ...prev,
      attachments: prev.attachments.filter((_, i) => i !== index)
    }));
  };

  const isStepValid = (step: number) => {
    switch (step) {
      case 1:
        return formData.firstName.trim() && formData.lastName.trim() && formData.email.trim() && formData.phone.trim();
      case 2:
        return formData.street.trim() && formData.city.trim() && formData.state.trim() && formData.zipCode.trim() && formData.country.trim();
      case 3:
        return formData.professionalSummary.trim().length > 20;
      case 4:
        return formData.workExperiences.every(exp => exp.company.trim() && exp.position.trim() && exp.startDate && exp.description.trim());
      case 5:
        return formData.educations.every(edu => edu.school.trim() && edu.degree.trim() && edu.field.trim() && edu.graduationDate);
      case 6:
        return formData.skills.trim().length > 0;
      case 7:
        return true; // File upload is optional but form can be submitted
      default:
        return false;
    }
  };

  const handleNext = () => {
    if (isStepValid(currentStep) && currentStep < totalSteps) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePrevious = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!isStepValid(7)) {
      alert('Please complete all required fields');
      return;
    }

    setIsSubmitting(true);
    
    try {
      // Simulate form submission
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Here you would normally send formData to your backend
      console.log('Application submitted:', formData);
      
      setSubmitted(true);
      setTimeout(() => {
        onNavigate('careers');
      }, 3000);
    } catch (error) {
      console.error('Error submitting application:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (submitted) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center">
        <div className="max-w-md w-full mx-auto px-6 text-center">
          <div className="mb-6 flex justify-center">
            <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-emerald-500 rounded-full flex items-center justify-center">
              <Check className="w-8 h-8 text-white" />
            </div>
          </div>
          <h1 className="text-3xl font-bold text-white mb-4">Application Submitted!</h1>
          <p className="text-gray-400 mb-2">
            Thank you for applying to IA M AI. We've received your application and will review it carefully.
          </p>
          <p className="text-gray-500 text-sm">
            We'll get back to you within 5-7 business days.
          </p>
          <p className="text-gray-600 text-xs mt-6">Redirecting to careers page...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <div className="bg-[#0a0a0a] border-b border-gray-800 py-8">
        <div className="container mx-auto px-6">
          <button
            onClick={() => onNavigate('careers')}
            className="flex items-center gap-2 text-cyan-400 hover:text-cyan-300 transition-colors mb-6"
          >
            <ChevronLeft className="w-5 h-5" />
            Back to Careers
          </button>
          <h1 className="text-3xl md:text-4xl font-bold mb-2">Career Application</h1>
          <p className="text-gray-400">Step {currentStep} of {totalSteps} - Complete your application</p>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="bg-black py-6 border-b border-gray-800">
        <div className="container mx-auto px-6">
          <div className="flex items-center justify-between mb-4">
            {Array.from({ length: totalSteps }, (_, i) => (
              <React.Fragment key={i + 1}>
                <button
                  onClick={() => i + 1 < currentStep && setCurrentStep(i + 1)}
                  className={`w-10 h-10 rounded-full flex items-center justify-center font-bold transition-all ${
                    i + 1 < currentStep
                      ? 'bg-green-500 text-white cursor-pointer hover:bg-green-600'
                      : i + 1 === currentStep
                      ? 'bg-cyan-500 text-black'
                      : 'bg-gray-800 text-gray-400'
                  }`}
                >
                  {i + 1 < currentStep ? '✓' : i + 1}
                </button>
                {i < totalSteps - 1 && (
                  <div className={`flex-1 h-1 mx-2 ${i + 1 < currentStep ? 'bg-green-500' : 'bg-gray-800'}`}></div>
                )}
              </React.Fragment>
            ))}
          </div>
        </div>
      </div>

      {/* Form Content */}
      <div className="py-12">
        <div className="container mx-auto px-6">
          <div className="max-w-3xl mx-auto bg-gray-900/50 border border-gray-800 rounded-2xl p-8">
            <form onSubmit={handleSubmit}>
              {/* Step 1: Personal Information */}
              {currentStep === 1 && (
                <div className="space-y-6">
                  <h2 className="text-2xl font-bold text-white mb-6">Personal Information</h2>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-semibold text-gray-300 mb-2">
                        First Name <span className="text-red-400">*</span>
                      </label>
                      <input
                        type="text"
                        name="firstName"
                        value={formData.firstName}
                        onChange={handleInputChange}
                        placeholder="John"
                        className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500/50 focus:ring-2 focus:ring-cyan-500/20 transition-all"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-gray-300 mb-2">
                        Last Name <span className="text-red-400">*</span>
                      </label>
                      <input
                        type="text"
                        name="lastName"
                        value={formData.lastName}
                        onChange={handleInputChange}
                        placeholder="Doe"
                        className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500/50 focus:ring-2 focus:ring-cyan-500/20 transition-all"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-300 mb-2">
                      Email <span className="text-red-400">*</span>
                    </label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      placeholder="john@example.com"
                      className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500/50 focus:ring-2 focus:ring-cyan-500/20 transition-all"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-300 mb-2">
                      Phone Number <span className="text-red-400">*</span>
                    </label>
                    <input
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleInputChange}
                      placeholder="+1 (555) 123-4567"
                      className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500/50 focus:ring-2 focus:ring-cyan-500/20 transition-all"
                      required
                    />
                  </div>
                </div>
              )}

              {/* Step 2: Address Information */}
              {currentStep === 2 && (
                <div className="space-y-6">
                  <h2 className="text-2xl font-bold text-white mb-6">Address Information</h2>
                  
                  <div>
                    <label className="block text-sm font-semibold text-gray-300 mb-2">
                      Street Address <span className="text-red-400">*</span>
                    </label>
                    <input
                      type="text"
                      name="street"
                      value={formData.street}
                      onChange={handleInputChange}
                      placeholder="123 Main Street"
                      className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500/50 focus:ring-2 focus:ring-cyan-500/20 transition-all"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-semibold text-gray-300 mb-2">
                        City <span className="text-red-400">*</span>
                      </label>
                      <input
                        type="text"
                        name="city"
                        value={formData.city}
                        onChange={handleInputChange}
                        placeholder="San Francisco"
                        className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500/50 focus:ring-2 focus:ring-cyan-500/20 transition-all"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-gray-300 mb-2">
                        State <span className="text-red-400">*</span>
                      </label>
                      <input
                        type="text"
                        name="state"
                        value={formData.state}
                        onChange={handleInputChange}
                        placeholder="CA"
                        className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500/50 focus:ring-2 focus:ring-cyan-500/20 transition-all"
                        required
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-semibold text-gray-300 mb-2">
                        ZIP Code <span className="text-red-400">*</span>
                      </label>
                      <input
                        type="text"
                        name="zipCode"
                        value={formData.zipCode}
                        onChange={handleInputChange}
                        placeholder="94105"
                        className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500/50 focus:ring-2 focus:ring-cyan-500/20 transition-all"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-gray-300 mb-2">
                        Country <span className="text-red-400">*</span>
                      </label>
                      <input
                        type="text"
                        name="country"
                        value={formData.country}
                        onChange={handleInputChange}
                        placeholder="United States"
                        className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500/50 focus:ring-2 focus:ring-cyan-500/20 transition-all"
                        required
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Step 3: Professional Summary */}
              {currentStep === 3 && (
                <div className="space-y-6">
                  <h2 className="text-2xl font-bold text-white mb-6">Professional Summary</h2>
                  
                  <div>
                    <label className="block text-sm font-semibold text-gray-300 mb-2">
                      Professional Summary <span className="text-red-400">*</span>
                    </label>
                    <p className="text-xs text-gray-500 mb-3">Minimum 20 characters</p>
                    <textarea
                      name="professionalSummary"
                      value={formData.professionalSummary}
                      onChange={handleInputChange}
                      placeholder="Write a brief overview of your professional background, skills, and career goals..."
                      rows={8}
                      className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500/50 focus:ring-2 focus:ring-cyan-500/20 transition-all resize-none"
                      required
                    />
                    <p className="text-xs text-gray-500 mt-2">{formData.professionalSummary.length} characters</p>
                  </div>
                </div>
              )}

              {/* Step 4: Work Experience */}
              {currentStep === 4 && (
                <div className="space-y-6">
                  <h2 className="text-2xl font-bold text-white mb-6">Work Experience</h2>
                  
                  {formData.workExperiences.map((exp, idx) => (
                    <div key={idx} className="bg-gray-800/30 border border-gray-700 rounded-lg p-6 space-y-4">
                      <div className="flex justify-between items-center mb-4">
                        <h3 className="text-lg font-semibold text-cyan-400">Experience {idx + 1}</h3>
                        {formData.workExperiences.length > 1 && (
                          <button
                            type="button"
                            onClick={() => removeWorkExperience(idx)}
                            className="text-red-400 hover:text-red-300 transition-colors"
                          >
                            <X className="w-5 h-5" />
                          </button>
                        )}
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-semibold text-gray-300 mb-2">
                            Company <span className="text-red-400">*</span>
                          </label>
                          <input
                            type="text"
                            value={exp.company}
                            onChange={(e) => handleWorkExperienceChange(idx, 'company', e.target.value)}
                            placeholder="Company Name"
                            className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white placeholder-gray-400 focus:outline-none focus:border-cyan-500/50 transition-all"
                            required
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-semibold text-gray-300 mb-2">
                            Position <span className="text-red-400">*</span>
                          </label>
                          <input
                            type="text"
                            value={exp.position}
                            onChange={(e) => handleWorkExperienceChange(idx, 'position', e.target.value)}
                            placeholder="Job Title"
                            className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white placeholder-gray-400 focus:outline-none focus:border-cyan-500/50 transition-all"
                            required
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-semibold text-gray-300 mb-2">
                            Start Date <span className="text-red-400">*</span>
                          </label>
                          <input
                            type="month"
                            value={exp.startDate}
                            onChange={(e) => handleWorkExperienceChange(idx, 'startDate', e.target.value)}
                            className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white focus:outline-none focus:border-cyan-500/50 transition-all"
                            required
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-semibold text-gray-300 mb-2">
                            End Date {!exp.currentlyWorking && <span className="text-red-400">*</span>}
                          </label>
                          <input
                            type="month"
                            value={exp.endDate}
                            onChange={(e) => handleWorkExperienceChange(idx, 'endDate', e.target.value)}
                            disabled={exp.currentlyWorking}
                            className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white focus:outline-none focus:border-cyan-500/50 transition-all disabled:opacity-50"
                          />
                        </div>
                      </div>

                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={exp.currentlyWorking}
                          onChange={(e) => handleWorkExperienceChange(idx, 'currentlyWorking', e.target.checked)}
                          className="w-4 h-4 rounded border border-gray-600 bg-gray-700 accent-cyan-500"
                        />
                        <span className="text-sm text-gray-300">I currently work here</span>
                      </label>

                      <div>
                        <label className="block text-sm font-semibold text-gray-300 mb-2">
                          Description <span className="text-red-400">*</span>
                        </label>
                        <textarea
                          value={exp.description}
                          onChange={(e) => handleWorkExperienceChange(idx, 'description', e.target.value)}
                          placeholder="Describe your responsibilities and achievements..."
                          rows={4}
                          className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white placeholder-gray-400 focus:outline-none focus:border-cyan-500/50 transition-all resize-none"
                          required
                        />
                      </div>
                    </div>
                  ))}

                  <button
                    type="button"
                    onClick={addWorkExperience}
                    className="w-full py-2 border border-dashed border-cyan-500/50 text-cyan-400 rounded-lg hover:bg-cyan-500/10 transition-all"
                  >
                    + Add Another Work Experience
                  </button>
                </div>
              )}

              {/* Step 5: Education */}
              {currentStep === 5 && (
                <div className="space-y-6">
                  <h2 className="text-2xl font-bold text-white mb-6">Education</h2>
                  
                  {formData.educations.map((edu, idx) => (
                    <div key={idx} className="bg-gray-800/30 border border-gray-700 rounded-lg p-6 space-y-4">
                      <div className="flex justify-between items-center mb-4">
                        <h3 className="text-lg font-semibold text-cyan-400">Education {idx + 1}</h3>
                        {formData.educations.length > 1 && (
                          <button
                            type="button"
                            onClick={() => removeEducation(idx)}
                            className="text-red-400 hover:text-red-300 transition-colors"
                          >
                            <X className="w-5 h-5" />
                          </button>
                        )}
                      </div>

                      <div>
                        <label className="block text-sm font-semibold text-gray-300 mb-2">
                          School/University <span className="text-red-400">*</span>
                        </label>
                        <input
                          type="text"
                          value={edu.school}
                          onChange={(e) => handleEducationChange(idx, 'school', e.target.value)}
                          placeholder="University Name"
                          className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white placeholder-gray-400 focus:outline-none focus:border-cyan-500/50 transition-all"
                          required
                        />
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-semibold text-gray-300 mb-2">
                            Degree <span className="text-red-400">*</span>
                          </label>
                          <select
                            value={edu.degree}
                            onChange={(e) => handleEducationChange(idx, 'degree', e.target.value)}
                            className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white focus:outline-none focus:border-cyan-500/50 transition-all"
                            required
                          >
                            <option value="">Select Degree</option>
                            <option value="High School">High School</option>
                            <option value="Associate">Associate's</option>
                            <option value="Bachelor">Bachelor's</option>
                            <option value="Master">Master's</option>
                            <option value="PhD">PhD</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-sm font-semibold text-gray-300 mb-2">
                            Field of Study <span className="text-red-400">*</span>
                          </label>
                          <input
                            type="text"
                            value={edu.field}
                            onChange={(e) => handleEducationChange(idx, 'field', e.target.value)}
                            placeholder="Computer Science"
                            className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white placeholder-gray-400 focus:outline-none focus:border-cyan-500/50 transition-all"
                            required
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-sm font-semibold text-gray-300 mb-2">
                          Graduation Date <span className="text-red-400">*</span>
                        </label>
                        <input
                          type="month"
                          value={edu.graduationDate}
                          onChange={(e) => handleEducationChange(idx, 'graduationDate', e.target.value)}
                          className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white focus:outline-none focus:border-cyan-500/50 transition-all"
                          required
                        />
                      </div>
                    </div>
                  ))}

                  <button
                    type="button"
                    onClick={addEducation}
                    className="w-full py-2 border border-dashed border-cyan-500/50 text-cyan-400 rounded-lg hover:bg-cyan-500/10 transition-all"
                  >
                    + Add Another Education
                  </button>
                </div>
              )}

              {/* Step 6: Skills */}
              {currentStep === 6 && (
                <div className="space-y-6">
                  <h2 className="text-2xl font-bold text-white mb-6">Skills</h2>
                  
                  <div>
                    <label className="block text-sm font-semibold text-gray-300 mb-2">
                      Skills <span className="text-red-400">*</span>
                    </label>
                    <p className="text-xs text-gray-500 mb-3">Enter skills separated by commas (e.g., React, TypeScript, Node.js)</p>
                    <textarea
                      name="skills"
                      value={formData.skills}
                      onChange={handleInputChange}
                      placeholder="List your technical and professional skills..."
                      rows={8}
                      className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500/50 focus:ring-2 focus:ring-cyan-500/20 transition-all resize-none"
                      required
                    />
                  </div>
                </div>
              )}

              {/* Step 7: File Upload */}
              {currentStep === 7 && (
                <div className="space-y-6">
                  <h2 className="text-2xl font-bold text-white mb-6">Upload Documents</h2>
                  <p className="text-sm text-gray-400 mb-4">Optionally upload your resume, cover letter, or other supporting documents</p>
                  
                  <div className="border-2 border-dashed border-cyan-500/50 rounded-lg p-8 text-center hover:border-cyan-400 transition-colors cursor-pointer" onClick={() => document.getElementById('file-input')?.click()}>
                    <Upload className="w-12 h-12 text-cyan-400 mx-auto mb-4" />
                    <p className="text-white font-semibold mb-1">Drop files here or click to upload</p>
                    <p className="text-sm text-gray-400">PDF, DOC, DOCX (Max 10MB each)</p>
                    <input
                      id="file-input"
                      type="file"
                      multiple
                      onChange={handleFileUpload}
                      accept=".pdf,.doc,.docx"
                      className="hidden"
                    />
                  </div>

                  {formData.attachments.length > 0 && (
                    <div className="bg-gray-800/30 border border-gray-700 rounded-lg p-6">
                      <h3 className="text-lg font-semibold text-white mb-4">Attached Files ({formData.attachments.length})</h3>
                      <div className="space-y-2">
                        {formData.attachments.map((file, idx) => (
                          <div key={idx} className="flex items-center justify-between bg-gray-700/50 p-3 rounded">
                            <div className="flex items-center gap-2 flex-1">
                              <span className="text-gray-400">📄</span>
                              <div className="flex-1 min-w-0">
                                <p className="text-white text-sm truncate">{file.name}</p>
                                <p className="text-gray-500 text-xs">{(file.size / 1024).toFixed(2)} KB</p>
                              </div>
                            </div>
                            <button
                              type="button"
                              onClick={() => removeAttachment(idx)}
                              className="text-red-400 hover:text-red-300 transition-colors ml-4"
                            >
                              <X className="w-5 h-5" />
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Navigation Buttons */}
              <div className="flex justify-between items-center mt-8 pt-8 border-t border-gray-700">
                <button
                  type="button"
                  onClick={handlePrevious}
                  disabled={currentStep === 1}
                  className="flex items-center gap-2 px-6 py-3 bg-gray-800 text-white rounded-lg hover:bg-gray-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <ChevronLeft className="w-5 h-5" />
                  Previous
                </button>

                {currentStep < totalSteps ? (
                  <button
                    type="button"
                    onClick={handleNext}
                    disabled={!isStepValid(currentStep)}
                    className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-cyan-500 to-purple-500 text-black font-semibold rounded-lg hover:shadow-lg hover:shadow-cyan-500/50 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    Next
                    <ChevronRight className="w-5 h-5" />
                  </button>
                ) : (
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="px-8 py-3 bg-gradient-to-r from-green-500 to-emerald-500 text-white font-semibold rounded-lg hover:shadow-lg hover:shadow-green-500/50 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {isSubmitting ? 'Submitting...' : 'Submit Application'}
                  </button>
                )}
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CareerApplicationPage;
