import React, { useState, useEffect } from 'react';
import { ArrowLeft, Network, Search, Clock, Globe, Server, CheckCircle, XCircle, AlertCircle, Copy, Download, RefreshCw, Zap } from 'lucide-react';

interface Props { onNavigate?: (page: string) => void }

const RECORD_TYPES = ['A','AAAA','CNAME','MX','NS','SOA','SRV','TXT'] as const;

interface DNSResult {
  type: string;
  domain: string;
  result: any;
  timestamp?: string;
  responseTime?: number;
}

interface HistoryEntry extends DNSResult {
  id: string;
}

const DNSLookupPage: React.FC<Props> = ({ onNavigate }) => {
  const [domain, setDomain] = useState('');
  const [type, setType] = useState<typeof RECORD_TYPES[number]>('A');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<DNSResult | null>(null);
  const [error, setError] = useState<string>('');
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [autoRefresh, setAutoRefresh] = useState(false);
  const [refreshInterval, setRefreshInterval] = useState(30);
  const [copied, setCopied] = useState(false);

  // Auto-refresh functionality
  useEffect(() => {
    if (!autoRefresh || !domain.trim()) return;
    
    const timer = setInterval(() => {
      runLookup();
    }, refreshInterval * 1000);

    return () => clearInterval(timer);
  }, [autoRefresh, refreshInterval, domain, type]);

  const runLookup = async () => {
    if (!domain.trim()) return;
    setLoading(true); 
    setError(''); 
    
    const startTime = Date.now();
    
    try {
      const res = await fetch(`/api/tools/dns?domain=${encodeURIComponent(domain.trim())}&type=${type}`);
      const data = await res.json();
      const responseTime = Date.now() - startTime;
      
      if (data.success) {
        const newResult: DNSResult = {
          ...data.data,
          timestamp: new Date().toISOString(),
          responseTime
        };
        setResult(newResult);
        
        // Add to history
        const historyEntry: HistoryEntry = {
          ...newResult,
          id: Date.now().toString()
        };
        setHistory(prev => [historyEntry, ...prev.slice(0, 9)]); // Keep last 10
      } else {
        setError(data.error || 'DNS lookup failed');
      }
    } catch (e: any) {
      setError(e?.message || 'Network error');
    } finally { 
      setLoading(false); 
    }
  };

  const copyToClipboard = () => {
    if (result) {
      navigator.clipboard.writeText(JSON.stringify(result, null, 2));
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const downloadResult = () => {
    if (result) {
      const blob = new Blob([JSON.stringify(result, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `dns-${domain}-${type}-${Date.now()}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }
  };

  const loadFromHistory = (entry: HistoryEntry) => {
    setDomain(entry.domain);
    setType(entry.type as typeof RECORD_TYPES[number]);
    setResult(entry);
  };

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <section className="relative overflow-hidden py-12 border-b border-gray-800">
        <div className="absolute inset-0 bg-grid-gray-900 [mask-image:linear-gradient(to_bottom,white_30%,transparent)]"></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-cyan-500/10 rounded-full blur-3xl"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <button 
            onClick={() => onNavigate?.('toolbox')} 
            className="mb-6 flex items-center gap-2 text-gray-400 hover:text-cyan-400 transition-colors"
          >
            <ArrowLeft className="w-4 h-4"/> Back to Toolbox
          </button>
          
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 bg-cyan-500/20 rounded-lg border border-cyan-500/30">
              <Network className="w-6 h-6 text-cyan-400"/>
            </div>
            <div>
              <h1 className="text-3xl md:text-4xl font-bold">DNS Lookup</h1>
              <p className="text-gray-400 mt-1">Resolve DNS records with real-time monitoring</p>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
            <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-4">
              <div className="text-gray-400 text-sm mb-1">Queries Today</div>
              <div className="text-2xl font-bold text-cyan-400">{history.length}</div>
            </div>
            <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-4">
              <div className="text-gray-400 text-sm mb-1">Avg Response</div>
              <div className="text-2xl font-bold text-green-400">
                {result?.responseTime ? `${result.responseTime}ms` : '--'}
              </div>
            </div>
            <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-4">
              <div className="text-gray-400 text-sm mb-1">Record Types</div>
              <div className="text-2xl font-bold text-purple-400">{RECORD_TYPES.length}</div>
            </div>
            <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-4">
              <div className="text-gray-400 text-sm mb-1">Auto-Refresh</div>
              <div className="text-2xl font-bold">{autoRefresh ? '🟢' : '⚪'}</div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-3 gap-6">
            {/* Left Column - Query Form */}
            <div className="lg:col-span-2 space-y-6">
              {/* Query Input */}
              <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
                <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
                  <Search className="w-5 h-5 text-cyan-400" />
                  Query DNS Records
                </h2>
                
                <div className="space-y-4">
                  <div className="flex flex-col sm:flex-row gap-3">
                    <input 
                      className="flex-1 px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500 transition" 
                      placeholder="example.com" 
                      value={domain} 
                      onChange={e => setDomain(e.target.value)}
                      onKeyPress={e => e.key === 'Enter' && runLookup()}
                    />
                    <select 
                      className="px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-cyan-500 transition w-full sm:w-auto" 
                      value={type} 
                      onChange={e => setType(e.target.value as any)}
                    >
                      {RECORD_TYPES.map(t => <option key={t} value={t}>{t} Record</option>)}
                    </select>
                  </div>

                  <button 
                    onClick={runLookup} 
                    disabled={loading || !domain.trim()}
                    className="w-full px-6 py-3 rounded-lg bg-gradient-to-r from-cyan-500 to-purple-500 text-black font-semibold flex items-center justify-center gap-2 hover:shadow-lg hover:shadow-cyan-500/50 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                  >
                    {loading ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin"/>
                        Resolving...
                      </>
                    ) : (
                      <>
                        <Search className="w-4 h-4"/>
                        Lookup DNS
                      </>
                    )}
                  </button>

                  {/* Auto-refresh controls */}
                  <div className="flex items-center justify-between p-4 bg-gray-800/50 rounded-lg border border-gray-700">
                    <div className="flex items-center gap-3">
                      <input
                        type="checkbox"
                        id="autoRefresh"
                        checked={autoRefresh}
                        onChange={e => setAutoRefresh(e.target.checked)}
                        className="w-4 h-4"
                      />
                      <label htmlFor="autoRefresh" className="text-sm text-gray-300">
                        Auto-refresh every
                      </label>
                      <select
                        value={refreshInterval}
                        onChange={e => setRefreshInterval(Number(e.target.value))}
                        className="px-2 py-1 bg-gray-700 border border-gray-600 rounded text-sm"
                        disabled={!autoRefresh}
                      >
                        <option value={10}>10s</option>
                        <option value={30}>30s</option>
                        <option value={60}>1m</option>
                        <option value={300}>5m</option>
                      </select>
                    </div>
                    {autoRefresh && (
                      <div className="flex items-center gap-2 text-green-400 text-sm">
                        <Zap className="w-4 h-4 animate-pulse" />
                        Live monitoring
                      </div>
                    )}
                  </div>
                </div>

                {error && (
                  <div className="mt-4 p-4 bg-red-500/10 border border-red-500/30 rounded-lg flex items-start gap-3">
                    <XCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
                    <div>
                      <div className="font-semibold text-red-400">Error</div>
                      <div className="text-sm text-red-300">{error}</div>
                    </div>
                  </div>
                )}
              </div>

              {/* Results */}
              {result && (
                <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-bold flex items-center gap-2">
                      <CheckCircle className="w-5 h-5 text-green-400" />
                      DNS Records
                    </h2>
                    <div className="flex gap-2">
                      <button
                        onClick={copyToClipboard}
                        className="p-2 bg-gray-800 hover:bg-gray-700 rounded-lg border border-gray-700 transition"
                        title="Copy to clipboard"
                      >
                        {copied ? <CheckCircle className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
                      </button>
                      <button
                        onClick={downloadResult}
                        className="p-2 bg-gray-800 hover:bg-gray-700 rounded-lg border border-gray-700 transition"
                        title="Download JSON"
                      >
                        <Download className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  <div className="space-y-4">
                    {/* Info Cards */}
                    <div className="grid grid-cols-2 gap-4">
                      <div className="p-3 bg-gray-800/50 rounded-lg border border-gray-700">
                        <div className="text-xs text-gray-400 mb-1">Domain</div>
                        <div className="font-mono text-sm text-cyan-400">{result.domain}</div>
                      </div>
                      <div className="p-3 bg-gray-800/50 rounded-lg border border-gray-700">
                        <div className="text-xs text-gray-400 mb-1">Record Type</div>
                        <div className="font-mono text-sm text-purple-400">{result.type}</div>
                      </div>
                      <div className="p-3 bg-gray-800/50 rounded-lg border border-gray-700">
                        <div className="text-xs text-gray-400 mb-1">Response Time</div>
                        <div className="font-mono text-sm text-green-400">{result.responseTime}ms</div>
                      </div>
                      <div className="p-3 bg-gray-800/50 rounded-lg border border-gray-700">
                        <div className="text-xs text-gray-400 mb-1">Timestamp</div>
                        <div className="font-mono text-sm text-gray-300">
                          {result.timestamp ? new Date(result.timestamp).toLocaleTimeString() : '--'}
                        </div>
                      </div>
                    </div>

                    {/* Results */}
                    <div className="p-4 bg-black rounded-lg border border-gray-700 overflow-auto max-h-96">
                      <pre className="text-sm text-gray-300 whitespace-pre-wrap break-all font-mono">
                        {JSON.stringify(result.result, null, 2)}
                      </pre>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Right Column - History & Info */}
            <div className="space-y-6">
              {/* Quick Actions */}
              <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
                <h3 className="text-lg font-bold mb-4">Quick Lookup</h3>
                <div className="space-y-2">
                  {['google.com', 'github.com', 'cloudflare.com'].map(d => (
                    <button
                      key={d}
                      onClick={() => {
                        setDomain(d);
                        setTimeout(runLookup, 100);
                      }}
                      className="w-full px-4 py-2 text-left bg-gray-800/50 hover:bg-gray-800 border border-gray-700 hover:border-cyan-500/50 rounded-lg transition text-sm"
                    >
                      {d}
                    </button>
                  ))}
                </div>
              </div>

              {/* History */}
              {history.length > 0 && (
                <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-bold flex items-center gap-2">
                      <Clock className="w-5 h-5 text-cyan-400" />
                      Recent Queries
                    </h3>
                    <button
                      onClick={() => setHistory([])}
                      className="text-xs text-gray-400 hover:text-red-400 transition"
                    >
                      Clear
                    </button>
                  </div>
                  <div className="space-y-2 max-h-96 overflow-auto">
                    {history.map(entry => (
                      <button
                        key={entry.id}
                        onClick={() => loadFromHistory(entry)}
                        className="w-full p-3 text-left bg-gray-800/50 hover:bg-gray-800 border border-gray-700 hover:border-cyan-500/50 rounded-lg transition"
                      >
                        <div className="flex items-center justify-between">
                          <div className="font-mono text-sm text-cyan-400">{entry.domain}</div>
                          <div className="text-xs text-purple-400">{entry.type}</div>
                        </div>
                        <div className="text-xs text-gray-500 mt-1">
                          {entry.timestamp ? new Date(entry.timestamp).toLocaleString() : ''}
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Info Panel */}
              <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
                <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                  <Globe className="w-5 h-5 text-cyan-400" />
                  DNS Record Types
                </h3>
                <div className="space-y-3 text-sm">
                  {[
                    { type: 'A', desc: 'IPv4 address' },
                    { type: 'AAAA', desc: 'IPv6 address' },
                    { type: 'CNAME', desc: 'Canonical name' },
                    { type: 'MX', desc: 'Mail exchange' },
                    { type: 'NS', desc: 'Name server' },
                    { type: 'TXT', desc: 'Text record' },
                  ].map(({ type: t, desc }) => (
                    <div key={t} className="flex items-start gap-2">
                      <div className="w-16 px-2 py-1 bg-cyan-500/10 border border-cyan-500/30 rounded text-cyan-400 text-xs font-mono text-center">
                        {t}
                      </div>
                      <div className="flex-1 text-gray-400 leading-relaxed">{desc}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default DNSLookupPage;
