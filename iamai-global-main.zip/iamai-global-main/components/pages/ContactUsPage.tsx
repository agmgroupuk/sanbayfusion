import React, { useState } from 'react';
import { Page } from '../../App';

interface ContactUsPageProps {
  onNavigate: (page: Page) => void;
}

const ContactUsPage: React.FC<ContactUsPageProps> = ({ onNavigate }) => {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    message: ''
  });
  const [submitSuccess, setSubmitSuccess] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate form submission
    console.log('Form submitted:', formData);
    setSubmitSuccess(true);
    setFormData({ name: '', phone: '', email: '', message: '' });
    setTimeout(() => setSubmitSuccess(false), 3000);
  };

  const socialLinks = [
    { name: 'Facebook', icon: 'fab fa-facebook', url: '#', color: 'hover:text-blue-500' },
    { name: 'Instagram', icon: 'fab fa-instagram', url: '#', color: 'hover:text-pink-500' },
    { name: 'TikTok', icon: 'fab fa-tiktok', url: '#', color: 'hover:text-white' },
    { name: 'Telegram', icon: 'fab fa-telegram', url: '#', color: 'hover:text-blue-400' },
    { name: 'Line', icon: 'fab fa-line', url: '#', color: 'hover:text-green-500' },
    { name: 'X (Twitter)', icon: 'fab fa-x-twitter', url: '#', color: 'hover:text-white' },
    { name: 'GitHub', icon: 'fab fa-github', url: '#', color: 'hover:text-gray-300' },
  ];

  return (
    <div className="bg-black text-white min-h-screen py-20 md:py-28">
      <div className="container mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">Get in Touch</h1>
          <p className="max-w-2xl mx-auto text-gray-400">
            Have a question, a partnership proposal, or just want to say hello? We'd love to hear from you. Reach out to us through any of our channels below.
          </p>
        </div>

        {/* Three-Panel Layout */}
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          
          {/* Left Panel - Social Media & Company Details */}
          <div className="bg-gradient-to-br from-gray-900/50 to-gray-900/30 border border-cyan-500/20 rounded-2xl p-8 hover:border-cyan-500/50 transition-all duration-300">
            <h2 className="text-2xl font-bold text-white mb-8 flex items-center">
              <span className="inline-flex items-center justify-center w-10 h-10 bg-cyan-500/20 rounded-lg mr-3">
                <i className="fas fa-link text-cyan-400"></i>
              </span>
              Connect With Us
            </h2>

            {/* Social Media Icons */}
            <div className="mb-12">
              <p className="text-sm font-semibold text-gray-400 uppercase tracking-wide mb-6">Follow us on social</p>
              <div className="grid grid-cols-3 gap-4">
                {socialLinks.map((social) => (
                  <a
                    key={social.name}
                    href={social.url}
                    title={`Follow us on ${social.name}`}
                    className={`flex flex-col items-center justify-center p-4 bg-gray-800/50 border border-gray-700 rounded-xl transition-all duration-300 hover:bg-gray-800 hover:border-cyan-500/50 ${social.color}`}
                  >
                    <i className={`${social.icon} text-2xl mb-2`}></i>
                    <span className="text-xs text-gray-400 hover:text-white transition-colors">{social.name}</span>
                  </a>
                ))}
              </div>
            </div>

            {/* Company Details */}
            <div className="pt-8 border-t border-gray-800">
              <p className="text-sm font-semibold text-gray-400 uppercase tracking-wide mb-6">Company</p>
              <div className="space-y-4">
                <div>
                  <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Company Name</p>
                  <p className="text-white font-medium">IA M AI</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Industry</p>
                  <p className="text-white font-medium">AI & Machine Learning</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Founded</p>
                  <p className="text-white font-medium">2024</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Focus</p>
                  <p className="text-white font-medium">Multi-Agent AI Platform</p>
                </div>
              </div>
            </div>
          </div>

          {/* Center Panel - Contact Form */}
          <div className="bg-gradient-to-br from-gray-900/50 to-gray-900/30 border border-cyan-500/20 rounded-2xl p-8 hover:border-cyan-500/50 transition-all duration-300">
            <h2 className="text-2xl font-bold text-white mb-8 flex items-center">
              <span className="inline-flex items-center justify-center w-10 h-10 bg-cyan-500/20 rounded-lg mr-3">
                <i className="fas fa-envelope text-cyan-400"></i>
              </span>
              Send a Message
            </h2>

            {submitSuccess && (
              <div className="mb-6 p-4 bg-green-500/20 border border-green-500/50 rounded-lg text-green-400 text-sm">
                ✓ Thank you! We've received your message and will get back to you soon.
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-300 mb-2">
                  Full Name <span className="text-red-400">*</span>
                </label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  required
                  className="w-full bg-gray-800/50 border border-gray-700 rounded-lg p-3 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent transition-all"
                  placeholder="Your full name"
                />
              </div>

              <div>
                <label htmlFor="phone" className="block text-sm font-medium text-gray-300 mb-2">
                  Phone Number <span className="text-red-400">*</span>
                </label>
                <input
                  type="tel"
                  id="phone"
                  name="phone"
                  value={formData.phone}
                  onChange={handleInputChange}
                  required
                  className="w-full bg-gray-800/50 border border-gray-700 rounded-lg p-3 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent transition-all"
                  placeholder="+1 (555) 000-0000"
                />
              </div>

              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-300 mb-2">
                  Email Address <span className="text-red-400">*</span>
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  required
                  className="w-full bg-gray-800/50 border border-gray-700 rounded-lg p-3 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent transition-all"
                  placeholder="you@example.com"
                />
              </div>

              <div>
                <label htmlFor="message" className="block text-sm font-medium text-gray-300 mb-2">
                  Message <span className="text-red-400">*</span>
                </label>
                <textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleInputChange}
                  required
                  rows={6}
                  className="w-full bg-gray-800/50 border border-gray-700 rounded-lg p-3 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent transition-all resize-none"
                  placeholder="Your message here..."
                ></textarea>
              </div>

              <button
                type="submit"
                title="Send your message to our team"
                className="w-full px-6 py-3 bg-gradient-to-r from-cyan-500 to-cyan-400 text-black font-semibold rounded-lg hover:from-cyan-400 hover:to-cyan-300 transition-all duration-300 flex items-center justify-center space-x-2"
              >
                <i className="fas fa-paper-plane"></i>
                <span>Send Message</span>
              </button>
            </form>
          </div>

          {/* Right Panel - Contact Information */}
          <div className="bg-gradient-to-br from-gray-900/50 to-gray-900/30 border border-cyan-500/20 rounded-2xl p-8 hover:border-cyan-500/50 transition-all duration-300">
            <h2 className="text-2xl font-bold text-white mb-8 flex items-center">
              <span className="inline-flex items-center justify-center w-10 h-10 bg-cyan-500/20 rounded-lg mr-3">
                <i className="fas fa-info-circle text-cyan-400"></i>
              </span>
              Contact Info
            </h2>

            {/* Address Section */}
            <div className="mb-8">
              <div className="flex items-start space-x-4 mb-6">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-10 w-10 rounded-lg bg-cyan-500/20 text-cyan-400">
                    <i className="fas fa-map-marker-alt"></i>
                  </div>
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-2">Address</h3>
                  <p className="text-white font-medium">123 AI Avenue</p>
                  <p className="text-white font-medium">Innovation City, IC 10101</p>
                  <p className="text-gray-400 text-sm mt-1">United States</p>
                </div>
              </div>

              {/* Phone Section */}
              <div className="flex items-start space-x-4 mb-6">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-10 w-10 rounded-lg bg-cyan-500/20 text-cyan-400">
                    <i className="fas fa-phone"></i>
                  </div>
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-2">Phone</h3>
                  <a href="tel:+15550000000" className="text-white font-medium hover:text-cyan-400 transition-colors">
                    +1 (555) 000-0000
                  </a>
                  <p className="text-gray-400 text-sm">Monday - Friday, 9AM - 6PM EST</p>
                </div>
              </div>

              {/* Email Section */}
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-10 w-10 rounded-lg bg-cyan-500/20 text-cyan-400">
                    <i className="fas fa-envelope"></i>
                  </div>
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-2">Email</h3>
                  <a href="mailto:hello@iamai.global" className="text-white font-medium hover:text-cyan-400 transition-colors">
                    hello@iamai.global
                  </a>
                  <p className="text-gray-400 text-sm">We'll respond within 24 hours</p>
                </div>
              </div>
            </div>

            {/* Partners Section */}
            <div className="pt-8 border-t border-gray-800">
              <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-4">Our Partners</h3>
              <div className="space-y-2 text-gray-400 text-sm">
                <p>• Strategic AI Partners</p>
                <p>• Enterprise Solutions</p>
                <p>• Tech Ecosystem Leaders</p>
                <p className="pt-2 text-xs text-gray-500 italic">More details coming soon...</p>
              </div>
            </div>
          </div>
        </div>

        {/* Back to Home Button */}
        <div className="flex justify-center pt-12 border-t border-gray-800 mt-16">
          <button
            onClick={() => onNavigate('home')}
            title="Return to the homepage"
            className="inline-flex items-center space-x-2 px-6 py-3 bg-gray-900/50 border border-gray-700 rounded-lg text-white hover:border-cyan-500/50 hover:bg-gray-900 transition-all duration-300 font-medium"
          >
            <i className="fas fa-arrow-left"></i>
            <span>Back to Home</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default ContactUsPage;