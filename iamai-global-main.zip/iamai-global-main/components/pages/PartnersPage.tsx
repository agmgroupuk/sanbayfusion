import React from 'react';
import { Page } from '../../App';

interface PartnersPageProps {
  onNavigate: (page: Page) => void;
}

const PartnerCard: React.FC<{ name: string, logoUrl: string, description: string }> = ({ name, logoUrl, description }) => (
    <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6 flex flex-col items-start space-y-4 hover:border-cyan-500/50 hover:bg-gray-900 transition-all duration-300">
        <img src={logoUrl} alt={`${name} logo`} className="h-10 grayscale opacity-70 group-hover:grayscale-0 group-hover:opacity-100 transition-all" />
        <h3 className="text-xl font-bold text-white pt-2">{name}</h3>
        <p className="text-gray-400 flex-grow">{description}</p>
        <a href="#" title={`Learn more about our partnership with ${name}`} className="mt-auto text-cyan-400 font-semibold hover:text-cyan-300 transition-colors">
            Learn More &rarr;
        </a>
    </div>
);

const IntegrationCard: React.FC<{ name: string, icon: string }> = ({ name, icon }) => (
    <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6 flex items-center space-x-4">
        <i className={`${icon} text-4xl`}></i>
        <span className="text-lg font-semibold text-white">{name}</span>
    </div>
);

const PartnersPage: React.FC<PartnersPageProps> = ({ onNavigate }) => {
  const techPartners = [
    { name: 'Ollama', logoUrl: 'https://ollama.com/public/ollama.png', description: 'Powering our on-premise and local-first AI capabilities with high-performance, open-source models.' },
    { name: 'Vercel', logoUrl: 'https://assets.vercel.com/image/upload/v1662130559/nextjs/Icon_light_background.png', description: 'Our frontend is deployed on Vercel, ensuring fast global delivery and seamless scaling for our web application.' },
    { name: 'Google Cloud', logoUrl: 'https://www.gstatic.com/devrel-devsite/prod/v871f7fe61a8f3c713620448143169b81b891823152c10a20a3222a7f058d8692/cloud/images/cloud-logo.svg', description: 'Leveraging Google\'s cutting-edge infrastructure and AI services like Gemini for high-demand, scalable agent operations.' },
  ];

  const integrationPartners = [
      { name: 'Slack', icon: 'fab fa-slack text-[#4A154B]' },
      { name: 'Trello', icon: 'fab fa-trello text-[#0079BF]' },
      { name: 'Zapier', icon: 'fa-solid fa-bolt text-[#FF4A00]' },
      { name: 'GitHub', icon: 'fab fa-github text-white' },
      { name: 'HubSpot', icon: 'fab fa-hubspot text-[#FF7A59]' },
      { name: 'Notion', icon: 'fa-solid fa-file-invoice text-white' },
  ];


  return (
    <div className="bg-black text-white">
      {/* Hero Section */}
      <section className="py-20 md:py-32 text-center">
        <div className="container mx-auto px-6">
            <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight mb-4">Our Partners</h1>
            <p className="max-w-3xl mx-auto text-lg md:text-xl text-gray-400">
                We collaborate with industry leaders to build a robust and extensible ecosystem. Together, we are pushing the boundaries of what's possible with AI.
            </p>
        </div>
      </section>

      {/* Technology Partners Section */}
      <section className="py-20 md:py-28 bg-[#0a0a0a]">
         <div className="container mx-auto px-6">
            <div className="text-center mb-12">
                <h2 className="text-3xl md:text-4xl font-bold text-white">Featured Technology Partners</h2>
                <p className="max-w-2xl mx-auto mt-4 text-gray-400">
                    The core technologies that power the IA M AI platform.
                </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {techPartners.map(partner => <PartnerCard key={partner.name} {...partner} />)}
            </div>
         </div>
      </section>

      {/* Integration Partners Section */}
      <section className="py-20 md:py-28 bg-black">
         <div className="container mx-auto px-6">
            <div className="text-center mb-12">
                <h2 className="text-3xl md:text-4xl font-bold text-white">Integration Ecosystem</h2>
                <p className="max-w-2xl mx-auto mt-4 text-gray-400">
                    Connect your agents to the tools you use every day.
                </p>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                {integrationPartners.map(partner => <IntegrationCard key={partner.name} {...partner} />)}
            </div>
         </div>
      </section>

       {/* Become a Partner CTA */}
      <section className="py-20 md:py-28 bg-black">
        <div className="container mx-auto px-6">
            <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-10 md:p-16 text-center">
                <h2 className="text-3xl md:text-4xl font-bold text-white">Become a Partner</h2>
                <p className="max-w-2xl mx-auto mt-4 text-gray-400">
                    Interested in integrating with our platform or building on top of our agent ecosystem? We'd love to hear from you.
                </p>
                <div className="mt-8">
                    <button
                        onClick={() => onNavigate('contact')}
                        title="Contact us to discuss partnership opportunities"
                        className="bg-cyan-500 text-black font-semibold px-8 py-3 rounded-full hover:bg-cyan-400 transition-all duration-300 transform hover:scale-105"
                    >
                        Contact Us
                    </button>
                </div>
            </div>
        </div>
      </section>
    </div>
  );
};

export default PartnersPage;
