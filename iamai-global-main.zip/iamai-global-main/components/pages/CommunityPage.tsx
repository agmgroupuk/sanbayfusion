import React from 'react';
import { Page } from '../../App';

interface CommunityPageProps {
  onNavigate: (page: Page) => void;
}

interface CommunityCardProps {
    icon: string;
    platform: string;
    description: string;
    buttonText: string;
    href: string;
    colorClasses: string;
    onForumsClick?: () => void;
}

const CommunityCard: React.FC<CommunityCardProps> = ({ icon, platform, description, buttonText, href, colorClasses, onForumsClick }) => (
    <div className={`bg-gray-900/50 border border-gray-800 rounded-2xl p-8 flex flex-col items-center text-center transform hover:-translate-y-2 transition-transform duration-300 ${colorClasses}`}>
        <div className="text-6xl mb-4">
            <i className={icon}></i>
        </div>
        <h3 className="text-2xl font-bold text-white">{platform}</h3>
        <p className="text-gray-400 my-4 flex-grow">{description}</p>
        {href === '#internal' ? (
          <button
            onClick={onForumsClick}
            title={`Visit our ${platform}`}
            className="mt-4 bg-white text-black font-semibold px-8 py-3 rounded-full hover:bg-gray-200 transition-colors duration-300"
          >
            {buttonText}
          </button>
        ) : (
          <a href={href} target="_blank" rel="noopener noreferrer" title={`Join our ${platform} community`} className="mt-4 bg-white text-black font-semibold px-8 py-3 rounded-full hover:bg-gray-200 transition-colors duration-300">
            {buttonText}
          </a>
        )}
    </div>
);

const CommunityPage: React.FC<CommunityPageProps> = ({ onNavigate }) => {
  const communities = [
    { platform: 'Discord', icon: 'fab fa-discord', description: 'Chat with the team and other developers in real-time. The best place for support and collaboration.', buttonText: 'Join Server', href: 'https://discord.gg/onelastai', colorClasses: 'hover:border-indigo-500/50' },
    { platform: 'GitHub', icon: 'fab fa-github', description: 'Contribute to our open-source projects, report issues, and explore the codebase.', buttonText: 'Follow Us', href: 'https://github.com/1-manarmy', colorClasses: 'hover:border-gray-500/50' },
    { platform: 'Twitter', icon: 'fab fa-x-twitter', description: 'Stay up to date with the latest news, announcements, and product updates.', buttonText: 'Follow @iamai', href: 'https://x.com/onelastai', colorClasses: 'hover:border-sky-500/50' },
    { platform: 'Instagram', icon: 'fab fa-instagram', description: 'Follow us for behind-the-scenes content, updates, and community highlights.', buttonText: 'Follow Us', href: 'https://instagram.com/onelastai', colorClasses: 'hover:border-pink-500/50' },
    { platform: 'Facebook', icon: 'fab fa-facebook', description: 'Connect with us on Facebook for news, events, and community engagement.', buttonText: 'Like Page', href: 'https://facebook.com/onelastai', colorClasses: 'hover:border-blue-500/50' },
    { platform: 'Telegram', icon: 'fab fa-telegram', description: 'Join our Telegram channel for instant updates and real-time discussions.', buttonText: 'Join Channel', href: 'https://t.me/onelastai', colorClasses: 'hover:border-cyan-500/50' },
    { platform: 'Line', icon: 'fab fa-line', description: 'Connect with us on Line for exclusive updates and community features.', buttonText: 'Add Friend', href: 'https://line.me/ti/p/onelastai', colorClasses: 'hover:border-green-500/50' },
    { platform: 'Forums', icon: 'fa-solid fa-comments', description: 'Participate in long-form discussions, share your projects, and ask questions in our official forums.', buttonText: 'Visit Forums', href: '#internal', colorClasses: 'hover:border-cyan-500/50' },
  ];
    
  return (
    <div className="bg-black text-white">
      {/* Hero Section */}
      <section className="py-20 md:py-32 text-center">
        <div className="container mx-auto px-6">
            <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight mb-4">
                Join Our Developer Community
            </h1>
            <p className="max-w-3xl mx-auto text-lg md:text-xl text-gray-400">
                Connect, collaborate, and create with thousands of developers and AI enthusiasts from around the world.
            </p>
        </div>
      </section>

      {/* Community Links Section */}
       <section className="py-20 md:py-28 bg-[#0a0a0a]">
         <div className="container mx-auto px-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                {communities.map(community => (
                  <CommunityCard 
                    key={community.platform} 
                    {...community}
                    onForumsClick={() => onNavigate('forums' as Page)}
                  />
                ))}
            </div>
         </div>
      </section>

      {/* Back to Home Button */}
        <div className="text-center py-20">
          <button onClick={() => onNavigate('home')} title="Return to the homepage" className="text-cyan-400 hover:text-cyan-300 font-semibold transition-colors duration-300">
            &larr; Back to Home
          </button>
        </div>
    </div>
  );
};

export default CommunityPage;