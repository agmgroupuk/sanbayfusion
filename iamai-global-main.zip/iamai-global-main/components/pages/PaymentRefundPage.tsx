import React, { useState } from 'react';
import { Page } from '../../App';
import {
  ArrowLeft,
  CreditCard,
  DollarSign,
  Shield,
  Clock,
  XCircle,
  CheckCircle,
  AlertCircle,
  X,
  ExternalLink,
  BookOpen,
  Lock,
  RefreshCw,
  Smartphone,
  Globe,
  FileText,
  Ban,
} from 'lucide-react';

interface PaymentRefundPageProps {
  onNavigate: (page: Page) => void;
}

interface PaymentArticle {
  id: string;
  title: string;
  icon: React.ReactNode;
  excerpt: string;
  category: string;
  content: {
    introduction: string;
    sections: {
      heading: string;
      paragraphs: string[];
      list?: string[];
    }[];
    conclusion?: string;
  };
}

const PaymentRefundPage: React.FC<PaymentRefundPageProps> = ({ onNavigate }) => {
  const [selectedArticle, setSelectedArticle] = useState<PaymentArticle | null>(null);
  const [activeCategory, setActiveCategory] = useState<string>('all');

  const articles: PaymentArticle[] = [
    {
      id: 'payment-methods',
      title: 'Accepted Payment Methods',
      icon: <CreditCard className="w-6 h-6 text-cyan-400" />,
      excerpt:
        'Payment options available on IA M AI platform through our trusted payment providers.',
      category: 'Payment',
      content: {
        introduction:
          'IA M AI accepts multiple payment methods through our secure payment providers, PayPal and Stripe. We prioritize security and convenience to ensure a smooth payment experience for users worldwide.',
        sections: [
          {
            heading: 'Payment Providers',
            paragraphs: [
              'We partner with industry-leading payment processors to ensure secure, reliable, and compliant payment processing for all transactions on our platform.',
            ],
            list: [
              '💳 Stripe: Primary payment processor for cards and digital wallets',
              '💰 PayPal: Alternative payment option for PayPal account holders',
              '🔒 PCI DSS Level 1 Certified: Highest level of payment security',
              '🌍 Global Coverage: Accept payments from users worldwide',
              '🛡️ Fraud Protection: Advanced fraud detection and prevention',
              '🔐 3D Secure: Additional authentication layer for card payments',
              '✅ No card data storage: We never see or store full card numbers',
            ],
          },
          {
            heading: 'Credit & Debit Cards (via Stripe)',
            paragraphs: [
              'We accept all major credit and debit cards through our Stripe integration. Card payments are processed securely with industry-standard encryption.',
            ],
            list: [
              '💳 Visa: All Visa credit and debit cards worldwide',
              '💳 Mastercard: All Mastercard credit and debit cards',
              '💳 American Express: Amex cards accepted globally',
              '💳 Discover: Discover cards (primarily US)',
              '💳 Diners Club: International Diners Club cards',
              '💳 JCB: Japanese Credit Bureau cards',
              '💳 UnionPay: China UnionPay cards',
              '🔒 Secure Processing: End-to-end encryption',
              '🔐 Tokenization: Card data tokenized for security',
              '⚡ Instant Authorization: Real-time payment verification',
            ],
          },
          {
            heading: 'Digital Wallets & Alternative Methods',
            paragraphs: [
              'In addition to traditional cards, we support various digital wallet and alternative payment methods for added convenience.',
            ],
            list: [
              '🍎 Apple Pay: Quick, secure payments on iOS and Safari',
              '📱 Google Pay: Fast checkout on Android and Chrome',
              '🔷 PayPal: Pay with your PayPal balance or linked accounts',
              '💰 PayPal Credit: Buy now, pay later through PayPal',
              '🌐 Link by Stripe: One-click payments across sites',
              '💳 Click to Pay: Secure card-on-file network',
              '⚡ All methods offer instant payment confirmation',
            ],
          },
          {
            heading: 'International Payments',
            paragraphs: [
              'We accept payments in multiple currencies and from customers in over 135 countries through our payment providers.',
            ],
            list: [
              '🌍 135+ Countries: Global payment acceptance',
              '💱 Multi-Currency: Pay in your local currency',
              '🔄 Auto-Conversion: Currency converted at competitive rates',
              '💵 Primary Currency: USD (US Dollars)',
              '💶 EUR, GBP, JPY, CAD, AUD: Major currencies supported',
              '🏦 Local Payment Methods: Available in select regions',
              '📊 Transparent Rates: Exchange rates displayed before payment',
              '✅ No hidden currency fees from IA M AI',
            ],
          },
          {
            heading: 'Payment Security Features',
            paragraphs: [
              'Every payment on IA M AI is protected by multiple layers of security to prevent fraud and unauthorized transactions.',
            ],
            list: [
              '🔒 SSL/TLS Encryption: All payment pages encrypted',
              '🛡️ 3D Secure (3DS): Additional verification for cards',
              '📱 OTP Verification: One-Time Password for added security',
              '🔐 Tokenization: Sensitive data replaced with secure tokens',
              '🚨 Fraud Detection: AI-powered fraud prevention',
              '📍 Address Verification: AVS checks for card billing addresses',
              '🔢 CVV Required: Card security code verified',
              '⚠️ Suspicious Activity Alerts: Real-time fraud monitoring',
              '🛡️ PSD2 Compliant: Strong Customer Authentication (SCA)',
            ],
          },
          {
            heading: 'Unsupported Payment Methods',
            paragraphs: [
              'For security and compliance reasons, we do not accept certain payment methods:',
            ],
            list: [
              '❌ Cryptocurrency: Bitcoin, Ethereum, etc. not accepted',
              '❌ Wire Transfers: Not supported for subscriptions',
              '❌ Cash/Money Orders: Digital payments only',
              '❌ Prepaid Cards: Some prepaid cards may be declined',
              '❌ Bank Drafts: Not available for subscription billing',
              '⚠️ Note: Payment methods may vary by country',
              '📧 Contact us for enterprise/custom payment arrangements',
            ],
          },
        ],
        conclusion:
          'We accept a wide variety of payment methods through secure providers PayPal and Stripe. All transactions are protected with industry-leading security measures including OTP verification.',
      },
    },
    {
      id: 'pricing-structure',
      title: 'Pricing & Subscription Plans',
      icon: <DollarSign className="w-6 h-6 text-cyan-400" />,
      excerpt: 'Our pricing model, minimum pricing, and subscription options for AI services.',
      category: 'Payment',
      content: {
        introduction:
          'IA M AI offers flexible, affordable pricing for our multi-agent AI platform. With a minimum subscription price of just $1, you can test our services for a day without commitment.',
        sections: [
          {
            heading: 'Minimum Pricing: $1 Test Period',
            paragraphs: [
              'Unlike traditional platforms with complicated free trials, we offer a straightforward $1 minimum subscription. This allows you to test any of our 17 AI agents for one day and decide if our services meet your needs.',
            ],
            list: [
              '💵 $1 Minimum: Lowest possible entry point',
              '📅 24-Hour Access: Full platform access for one day',
              '🤖 All 17 Agents: Test every AI agent included',
              '⚡ No Trial Limitations: Full features, no restrictions',
              '🚫 No Credit Card Tricks: Simple, honest pricing',
              '🔄 Automatically Expires: No auto-renewal at $1',
              '✅ Risk-Free Testing: Minimal commitment required',
              '📊 Full Feature Access: Everything works during test period',
              '💡 Decide Before Committing: Try before buying full subscription',
            ],
          },
          {
            heading: 'Subscription Plans',
            paragraphs: [
              'After your test period, choose from our simple per-agent subscription plans designed for different usage levels and needs.',
            ],
            list: [
              '📅 Daily Plan: $1 per agent for 24-hour access',
              '- Ideal for short-term testing or occasional deep dives',
              '- Full access to the selected agent for one day',
              '',
              '📆 Weekly Plan: $5 per agent for 7-day access',
              '- Great for active projects and recurring workflows',
              '- More cost-effective than buying daily access repeatedly',
              '',
              '🗓️ Monthly Plan: $19 per agent for 30-day access',
              '- Best value for regular users and teams',
              '- Simplified budgeting with predictable monthly cost',
              '',
              '🚫 No Free Plan: All access is subscription-based; there is no free subscription tier',
              '🏢 Enterprise & Custom: For larger teams or special requirements, contact sales@iamai.global for custom or volume pricing',
            ],
          },
          {
            heading: 'Why No Traditional Free Trial?',
            paragraphs: [
              "We've replaced the traditional free trial model with our $1 test period for several important reasons that benefit both you and our platform.",
            ],
            list: [
              '🤖 AI Service Costs: Each AI interaction incurs real API costs',
              '💡 Agent Processing: Our 17 specialized agents require computational resources',
              '⚖️ Fair Use: $1 ensures serious testers, prevents abuse',
              '🚫 No Dark Patterns: No forgotten trials auto-renewing at full price',
              '✅ Honest Approach: Transparent about costs from day one',
              '🔐 Reduced Fraud: Minimal payment deters fake accounts',
              '💳 Valid Payment Method: Ensures account authenticity',
              '🎯 Quality Over Quantity: Attract genuine users',
              '📊 Better Experience: Resources allocated to paying users',
            ],
          },
          {
            heading: 'Purchase Duration & Expiration',
            paragraphs: [
              'Each purchase grants time-limited access. No recurring charges or auto-renewal. When access expires, you can repurchase at any time.',
            ],
            list: [
              '⏱️ Daily Access: 24 hours from purchase',
              '📅 Weekly Access: 7 days from purchase',
              '📅 Monthly Access: 30 days from purchase',
              '🔄 No Auto-Renewal: One-time payment only',
              '⏰ Expiration Notice: Email reminder when access ends',
              '🚫 No Recurring Charges: Never charged again unless you repurchase',
              '📧 Confirmation Emails: Receipt for every purchase',
              '💳 New Purchase: Use any payment method',
              '📊 Access Tracking: Monitor your active purchases in dashboard',
            ],
          },
          {
            heading: 'Price Changes & Active Purchases',
            paragraphs: [
              'If we change prices, active purchases are unaffected. You keep access for the duration you paid for.',
            ],
            list: [
              '📢 30-Day Notice: Advance warning of price changes',
              '🔒 Current Purchase Protected: Your access duration honored',
              '✅ No Retroactive Changes: Paid access remains valid',
              '📧 Email Notification: Detailed explanation of changes',
              '💰 New Purchases: Use current listed prices',
              '⚖️ Fair Approach: Honor all paid purchases',
              '📊 Transparent Pricing: Always clearly displayed',
            ],
          },
          {
            heading: 'Educational & Non-Profit Discounts',
            paragraphs: [
              'We offer special pricing for students, educators, and non-profit organizations to make AI accessible to those who need it most.',
            ],
            list: [
              '🎓 Student Discount: 50% off Pro plan with valid student ID',
              '👨‍🏫 Educator Discount: 50% off for teachers and professors',
              '🏫 Educational Institutions: Custom enterprise pricing',
              '❤️ Non-Profit Discount: 30% off for registered non-profits',
              '📧 Apply: Email discounts@iamai.global with verification',
              '📋 Verification Required: Student ID, .edu email, or non-profit docs',
              '⏰ Annual Renewal: Re-verification required yearly',
              '✅ Same Features: Full access to all Pro features',
            ],
          },
        ],
        conclusion:
          'Our $1 minimum pricing offers risk-free testing of our AI services. No complicated free trials—just straightforward, honest pricing that respects your time and money.',
      },
    },
    {
      id: 'payment-process',
      title: 'Payment Process & Security',
      icon: <Lock className="w-6 h-6 text-cyan-400" />,
      excerpt: 'Step-by-step payment flow and security measures including OTP verification.',
      category: 'Payment',
      content: {
        introduction:
          'IA M AI employs a secure, multi-layered payment process to protect your financial information. Our payment flow includes OTP (One-Time Password) verification for enhanced security.',
        sections: [
          {
            heading: 'Payment Flow Overview',
            paragraphs: [
              'Our payment process is designed to be simple yet secure, with multiple checkpoints to verify your identity and prevent fraud.',
            ],
            list: [
              '1️⃣ Select Plan: Choose subscription term (Daily, Weekly, Monthly)',
              '2️⃣ Enter Payment Details: Card info or PayPal login',
              '3️⃣ Billing Information: Confirm billing address',
              '4️⃣ Review Order: Verify plan details and pricing',
              '5️⃣ OTP Verification: Receive and enter one-time password',
              '6️⃣ Payment Processing: Secure transaction through Stripe/PayPal',
              '7️⃣ Confirmation: Instant email receipt and account activation',
              '8️⃣ Access Granted: Immediate platform access',
              '⏱️ Total Time: Typically under 2 minutes',
            ],
          },
          {
            heading: 'OTP (One-Time Password) Security',
            paragraphs: [
              'We implement OTP verification as an additional security layer for all payment transactions. This two-factor authentication ensures that only you can authorize payments on your account.',
            ],
            list: [
              '📱 SMS OTP: 6-digit code sent to your registered phone',
              '📧 Email OTP: Alternative code sent to your email',
              '⏰ 5-Minute Validity: Code expires after 5 minutes',
              '🔐 One-Time Use: Each code works only once',
              '🔄 Resend Option: Request new code if needed',
              '✅ Required for: New subscriptions, plan upgrades, payment changes',
              '🛡️ Fraud Prevention: Blocks unauthorized payment attempts',
              '📱 Phone Verification: Phone number verified during signup',
              '🚨 Failed Attempts: Account temporarily locked after 3 wrong codes',
              '💡 Why OTP?: Protects against stolen cards and account takeovers',
            ],
          },
          {
            heading: '3D Secure Authentication',
            paragraphs: [
              'In addition to OTP, we support 3D Secure (3DS) for card payments, an additional verification layer required by many banks and card issuers.',
            ],
            list: [
              '🔐 3DS 2.0: Latest version of 3D Secure protocol',
              '🏦 Bank Verification: Your bank confirms transaction',
              '📱 Mobile Authentication: Fingerprint, Face ID, or PIN',
              '✅ Mandatory: Required for European cards (PSD2)',
              '🌍 Global Standard: Used worldwide by banks',
              '⚡ Frictionless Flow: Most transactions approved instantly',
              '🚨 Challenge Flow: Additional verification if flagged',
              '🛡️ Liability Shift: Bank assumes fraud liability after 3DS',
              '💳 Card Support: Visa Secure, Mastercard ID Check, Amex SafeKey',
            ],
          },
          {
            heading: 'Secure Payment Form',
            paragraphs: [
              'Our payment forms are designed with security best practices to protect your sensitive information during entry and transmission.',
            ],
            list: [
              '🔒 Hosted Payment Page: Forms hosted by Stripe (not our servers)',
              '🛡️ PCI Compliance: We never see full card numbers',
              '🔐 End-to-End Encryption: Data encrypted from browser to processor',
              '🚫 No Storage: Card data not stored in our database',
              '💾 Tokenization: Stripe tokens used for recurring billing',
              '✅ Auto-Fill Safe: Works with browser password managers',
              '📱 Mobile Optimized: Touch-friendly payment forms',
              '🔍 Real-Time Validation: Catch errors before submission',
              '⚠️ Clear Error Messages: Specific guidance if payment fails',
            ],
          },
          {
            heading: 'Payment Confirmation & Receipts',
            paragraphs: [
              'After successful payment, you receive immediate confirmation through multiple channels and can access receipts anytime.',
            ],
            list: [
              '✅ Instant Confirmation: On-screen success message',
              '📧 Email Receipt: Detailed transaction email within minutes',
              '📊 Account Dashboard: View all transactions in billing section',
              '💳 Receipt Details: Date, amount, payment method, plan',
              '📄 Invoice Available: PDF invoice for business/tax purposes',
              '🔢 Transaction ID: Unique identifier for each payment',
              '📥 Download Receipts: Export for record-keeping',
              '📧 Receipt Email: Sent to account email address',
              '🔄 Re-send Receipt: Request duplicate via support',
            ],
          },
          {
            heading: 'Failed Payment Handling',
            paragraphs: [
              'If a payment fails, we have processes in place to notify you and provide opportunities to resolve the issue without immediate service disruption.',
            ],
            list: [
              '🚨 Immediate Notification: Email alert of failed payment',
              '🔄 Automatic Retry: System retries payment after 3 days',
              '📧 Multiple Reminders: Emails at 3, 7, and 14 days',
              '⏰ Grace Period: 7 days to update payment method',
              '💳 Update Card: Easy payment method update in settings',
              '📞 Support Contact: Reach out for assistance',
              '⚠️ Service Suspension: Account limited after grace period',
              '🔓 Instant Reactivation: Service restored upon payment',
              '🗑️ Account Closure: Account deleted after 30 days unpaid',
            ],
          },
        ],
        conclusion:
          'Our payment process prioritizes security without sacrificing convenience. OTP verification, 3D Secure, and PCI-compliant processing ensure your payments are safe and secure.',
      },
    },
    {
      id: 'refund-policy',
      title: 'No Refund Policy',
      icon: <XCircle className="w-6 h-6 text-cyan-400" />,
      excerpt: 'Our no-refund policy for AI services and the reasons behind this approach.',
      category: 'Refund',
      content: {
        introduction:
          "IA M AI operates a strict no-refund policy for all subscriptions and purchases. This section explains our policy, the reasons behind it, and the alternatives we offer to ensure you're satisfied with our service.",
        sections: [
          {
            heading: 'No Refund Policy Statement',
            paragraphs: [
              'All payments made to IA M AI for subscriptions, upgrades, or any other services are final and non-refundable. This policy applies to all payment methods and subscription tiers.',
            ],
            list: [
              '🚫 No Refunds: All sales are final',
              '💳 All Payment Methods: Policy applies to cards, PayPal, etc.',
              '📅 All Subscription Tiers: Free trial substitute, Pro, Enterprise',
              '⏰ No Partial Refunds: No pro-rated refunds for partial months',
              '🔄 No Trial Refunds: Even $1 test subscriptions are non-refundable',
              '🎁 No Exceptions: Policy applies universally to all users',
              '⚖️ Legally Binding: Agreed to at purchase',
              '📧 Clearly Communicated: Displayed before payment confirmation',
              '✅ By purchasing, you acknowledge and accept this policy',
            ],
          },
          {
            heading: 'Why No Refunds?',
            paragraphs: [
              'Our no-refund policy exists for legitimate operational and practical reasons related to the nature of AI services and platform sustainability.',
            ],
            list: [
              '🤖 Instant AI Service Consumption: AI processing begins immediately',
              '💰 Real API Costs: Each AI interaction costs us money (OpenAI, Mistral, etc.)',
              '⚡ Immediate Value Delivered: You access services instantly upon payment',
              '📊 Resources Allocated: Computational resources assigned to your account',
              '🔐 Account Access Granted: Platform features unlocked immediately',
              '💡 Cannot "Un-consume" Service: AI conversations already generated',
              '⚖️ Prevents Abuse: Stops users from exploiting services then refunding',
              '🚫 Not Physical Goods: Digital services consumed in real-time',
              '💸 Operational Costs: Payment processing fees are non-recoverable',
              '🎯 $1 Test Option: We offer ultra-low-risk testing alternative',
            ],
          },
          {
            heading: 'Alternative to Refunds: $1 Test Period',
            paragraphs: [
              'Instead of offering refunds, we provide an extremely affordable $1 test subscription so you can evaluate our services with minimal financial risk before committing to a full subscription.',
            ],
            list: [
              '💵 Only $1: Minimal financial commitment',
              '📅 24-Hour Access: Full day to test all features',
              '🤖 All 17 Agents: Try every AI agent',
              '✅ Full Features: No limitations during test',
              "🚫 No Auto-Renewal: $1 test doesn't auto-renew",
              "💡 Informed Decision: Know exactly what you're buying",
              '⚖️ Fair Approach: Better than "free trial" with hidden auto-billing',
              '🎯 Try Before You Buy: Test thoroughly before committing',
              '📊 Risk-Minimized: Just $1 to evaluate entire platform',
            ],
          },
          {
            heading: 'Subscription Cancellation',
            paragraphs: [
              "While we don't offer refunds, you can cancel your subscription at any time to prevent future charges. Cancellation is simple and penalty-free.",
            ],
            list: [
              '🚫 Cancel Anytime: No cancellation fees',
              '⚙️ Self-Service: Cancel in account settings instantly',
              '📅 Access Continues: Keep access until period ends',
              '🔄 No Auto-Renewal: Future charges stopped',
              '📧 Confirmation Email: Cancellation confirmed via email',
              '💡 Example: Cancel on Jan 15, keep access until Feb 1',
              '🔓 Reactivate Anytime: Can re-subscribe later',
              '📊 Clear Communication: Status visible in dashboard',
              '✅ Fair Approach: You get what you paid for',
            ],
          },
          {
            heading: 'Exceptional Circumstances',
            paragraphs: [
              'While our policy is generally strict, we may consider exceptions in very rare, exceptional circumstances at our sole discretion.',
            ],
            list: [
              '🔧 Technical Issues: Major platform outages preventing service use',
              '🚨 Our Error: If we charged you incorrectly (wrong amount, duplicate)',
              '⚖️ Legal Requirements: If refund required by applicable law',
              '🏥 Extenuating Circumstances: Serious issues (evaluated case-by-case)',
              '📧 Contact Support: Email refunds@iamai.global with details',
              '📋 Documentation Required: Proof of issue/circumstances',
              '⏱️ Review Period: Response within 5 business days',
              '🎯 Our Discretion: Final decision rests with IA M AI',
              '🚫 Not Guaranteed: Exceptions are rare and not promised',
            ],
          },
          {
            heading: 'Chargebacks & Disputes',
            paragraphs: [
              'Filing a chargeback or payment dispute instead of contacting us first may result in immediate account termination and legal consequences.',
            ],
            list: [
              '⚠️ Contact Us First: Reach out before filing dispute',
              '🚨 Chargeback = Account Termination: Immediate permanent ban',
              '⚖️ Documented Service Delivery: We have proof of service provided',
              '💳 Dispute Fees: Banks charge us for disputes',
              '🚫 Blacklisted: Cannot create new account after chargeback',
              '📧 Legal Action: We may pursue legal remedies',
              '💰 Collection: Unpaid balances sent to collections',
              '📋 Credit Impact: May affect your credit score',
              '✅ Better Approach: Email support@iamai.global to resolve issues',
              '🤝 Work Together: We want to solve problems, not fight',
            ],
          },
          {
            heading: 'Your Consumer Rights',
            paragraphs: [
              'Depending on your location, you may have consumer protection rights that supersede our policy. We respect these legal rights.',
            ],
            list: [
              '🇪🇺 EU Consumer Rights: 14-day withdrawal period (with exceptions)',
              '🇬🇧 UK Consumer Law: Similar protections as EU',
              '🇦🇺 Australian Consumer Law: Guarantees apply',
              '🇺🇸 US State Laws: Vary by state (CA, NY have stronger protections)',
              '⚖️ Legal Compliance: We comply with applicable local laws',
              '📧 Exercise Rights: Contact legal@iamai.global',
              '📋 Documentation: Provide proof of residency',
              '🌍 International: Rights vary by country',
              '✅ We respect legally mandated consumer protections',
            ],
          },
        ],
        conclusion:
          'We maintain a strict no-refund policy due to the instant consumption nature of AI services. Our $1 test period offers a fair alternative, allowing you to evaluate our platform with minimal risk before committing to a full subscription.',
      },
    },
    {
      id: 'billing-issues',
      title: 'Billing Issues & Support',
      icon: <AlertCircle className="w-6 h-6 text-cyan-400" />,
      excerpt: 'How to resolve billing problems, payment errors, and get payment support.',
      category: 'Support',
      content: {
        introduction:
          "If you encounter billing issues, payment errors, or have questions about charges, we're here to help. This article explains common issues and how to resolve them.",
        sections: [
          {
            heading: 'Common Payment Errors',
            paragraphs: [
              'Most payment failures are due to common issues that can be easily resolved. Here are the most frequent errors and their solutions.',
            ],
            list: [
              '❌ Insufficient Funds: Check account balance',
              '❌ Expired Card: Update card expiration date',
              '❌ Incorrect CVV: Verify 3-digit security code',
              '❌ Wrong Billing Address: Ensure address matches bank records',
              '❌ Bank Decline: Contact your bank (often fraud protection)',
              '❌ International Card Block: Enable international transactions',
              '❌ Daily Limit Reached: Wait or contact bank to raise limit',
              '❌ 3D Secure Failed: Complete bank authentication',
              '❌ OTP Timeout: Request new OTP code',
              '❌ Card Not Supported: Try different card or PayPal',
            ],
          },
          {
            heading: 'Duplicate Charges',
            paragraphs: [
              "If you believe you were charged twice or see duplicate transactions, don't panic. Here's what to know:",
            ],
            list: [
              '⏰ Authorization Holds: May appear as duplicates initially',
              '🏦 Bank Processing: Holds drop off within 1-5 business days',
              '🔍 Check Transaction ID: Compare IDs to identify actual duplicate',
              '📧 Contact Support: Email billing@iamai.global immediately',
              '📋 Provide Details: Transaction IDs, amounts, dates, screenshots',
              "⏱️ Investigation: We'll investigate within 24 hours",
              '💰 Refund if Duplicate: Genuine duplicates refunded within 5-10 days',
              '🚨 Our Error: Immediate refund for confirmed mistakes',
              '📊 Bank Statement: Wait 3-5 days for final statement',
            ],
          },
          {
            heading: 'Unrecognized Charges',
            paragraphs: [
              "If you see a charge from IA M AI that you don't recognize, here's how to investigate before disputing.",
            ],
            list: [
              '🔍 Check Account: Log in to see active subscriptions',
              '👥 Family Members: Did someone else use your card?',
              '📧 Check Email: Search for receipts from billing@iamai.global',
              '📅 Subscription Renewal: Could be automatic renewal',
              '🎁 Gift Subscription: Did someone gift you a subscription?',
              '💳 Multiple Cards: Check if charged to different card',
              '🕐 Time Zone: Charge date may differ from purchase date',
              '📧 Contact Us First: Email billing@iamai.global before disputing',
              '📋 Provide Info: Date, amount, last 4 digits of card',
              '⏱️ Quick Response: We respond to billing inquiries within 24 hours',
            ],
          },
          {
            heading: 'Updating Payment Information',
            paragraphs: [
              "You can update your payment method at any time through your account settings. Here's how:",
            ],
            list: [
              '⚙️ Account Settings: Click profile → Billing → Payment Methods',
              '💳 Add New Card: Enter new card details securely',
              '🗑️ Remove Old Card: Delete outdated payment methods',
              '🔄 Set Default: Choose primary payment method',
              '✅ Verify New Card: Small authorization hold to confirm',
              '📧 Confirmation Email: Update confirmed via email',
              '🔐 Secure Process: All updates encrypted and secure',
              '⏱️ Takes Effect: Next renewal uses new payment method',
              '🚨 Before Expiry: Update cards before expiration to avoid disruption',
            ],
          },
          {
            heading: 'Canceling Active Access',
            paragraphs: [
              "If you want to cancel an active purchase early, here's what happens.",
            ],
            list: [
              '🚫 Cancel Anytime: No penalties or fees',
              '⏱️ Access Ends: Immediately upon cancellation',
              '💰 No Refunds: Unused time is not refunded (see refund policy)',
              '🔄 Repurchase Later: Can buy again after cancellation',
              '📧 Email Confirmation: Cancellation receipt sent',
              '📊 View in Dashboard: Track all your active purchases',
              '💡 Tip: Let it expire naturally if near end date',
            ],
          },
          {
            heading: 'Contact Billing Support',
            paragraphs: [
              'For any billing issue not covered above or if you need personalized assistance, our billing support team is ready to help.',
            ],
            list: [
              '📧 Email: billing@iamai.global',
              '⏱️ Response Time: Within 24 hours (usually faster)',
              '🕐 Business Hours: Mon-Fri 9am-6pm EST',
              '📋 Include: Account email, transaction ID, description of issue',
              '🔐 Security: We may ask verification questions',
              '💬 Live Chat: Available for Pro/Enterprise users',
              '📞 Phone Support: Enterprise customers only',
              '🌍 Multi-Language: English, Spanish, French, German, Chinese',
              '📊 Escalation: Complex issues escalated to senior team',
              '✅ Our Commitment: Resolve billing issues promptly and fairly',
            ],
          },
        ],
        conclusion:
          "Most billing issues can be resolved quickly by updating your payment method or contacting our support team. We're committed to providing clear, helpful assistance with any payment concerns.",
      },
    },
    {
      id: 'tax-invoices',
      title: 'Taxes & Invoices',
      icon: <FileText className="w-6 h-6 text-cyan-400" />,
      excerpt: 'Tax collection, invoice generation, and documentation for business expenses.',
      category: 'Documentation',
      content: {
        introduction:
          'IA M AI handles tax collection where required by law and provides detailed invoices for all transactions. This article covers tax obligations and how to access your invoices.',
        sections: [
          {
            heading: 'Sales Tax / VAT Collection',
            paragraphs: [
              'Depending on your location, we may be required to collect sales tax, VAT, or other consumption taxes on your subscription.',
            ],
            list: [
              '🇺🇸 US Sales Tax: Collected in states where we have nexus',
              '🇪🇺 EU VAT: 20-25% VAT for EU consumers',
              '🇬🇧 UK VAT: 20% VAT for UK customers',
              '🇨🇦 Canadian GST/HST: Varies by province',
              '🇦🇺 Australian GST: 10% GST applied',
              '🌍 Other Countries: Tax rates vary by jurisdiction',
              '💰 Tax Added at Checkout: Clearly displayed before payment',
              '🏢 Business VAT: Provide VAT ID to potentially avoid charges',
              '📋 Tax Documentation: Included on invoices and receipts',
              "⚖️ Legal Compliance: We collect only what's legally required",
            ],
          },
          {
            heading: 'Business VAT Numbers (EU)',
            paragraphs: [
              'EU businesses can provide their VAT identification number to apply reverse charge mechanism and avoid VAT charges.',
            ],
            list: [
              '🏢 B2B Transactions: Reverse charge applies with valid VAT ID',
              '📋 Provide VAT Number: Enter in billing settings',
              '✅ VIES Validation: We verify VAT ID with EU database',
              '🚫 Invalid VAT: Standard VAT applied if validation fails',
              '📧 Update VAT ID: Change anytime in account settings',
              "💰 No Refunds: VAT paid can't be refunded if ID added later",
              '📊 Invoices: VAT ID shown on invoices when provided',
              '⚖️ Your Responsibility: Report under reverse charge in your country',
              '🇪🇺 Intra-EU Supply: No VAT when valid VAT ID provided',
            ],
          },
          {
            heading: 'Invoice Generation',
            paragraphs: [
              'We automatically generate detailed invoices for every transaction. Invoices are available immediately after payment.',
            ],
            list: [
              '📧 Email Invoice: Sent to account email within minutes',
              '📥 Download PDF: Access in billing dashboard anytime',
              '📋 Invoice Details: Date, transaction ID, items, amounts, taxes',
              '🏢 Business Information: Your billing details',
              '🏛️ Our Information: IA M AI company details and tax ID',
              '💳 Payment Method: Card type or PayPal shown',
              '🔢 Sequential Numbering: Unique invoice numbers',
              '📊 Tax Breakdown: Subtotal, tax amount, and total clearly shown',
              '🌐 Multi-Currency: Invoice in payment currency',
            ],
          },
          {
            heading: 'Accessing Past Invoices',
            paragraphs: [
              'All your invoices are stored and accessible anytime through your account for tax and record-keeping purposes.',
            ],
            list: [
              '⚙️ Account Settings: Click profile → Billing → Invoices',
              '📅 Full History: Access all invoices since account creation',
              '🔍 Search & Filter: Find invoices by date, amount, or invoice number',
              '📥 Bulk Download: Download multiple invoices at once',
              '📧 Re-send Email: Request invoice copy via email',
              '💾 Permanent Storage: Invoices never deleted',
              '📊 Export Options: PDF or CSV formats',
              '🔐 Secure Access: Only account owner can view invoices',
              '🏢 Perfect for: Expense reports, accounting, tax filing',
            ],
          },
          {
            heading: 'Business Expense Deductions',
            paragraphs: [
              'IA M AI subscriptions may be tax-deductible as a business expense in many jurisdictions. Our invoices provide necessary documentation.',
            ],
            list: [
              '💼 Business Use: Deductible if used for business purposes',
              '📋 Proper Documentation: Our invoices meet accounting standards',
              '🏢 Company Name: Add business name in billing settings',
              '🌐 Business Address: Ensure correct billing address',
              '💰 Tax Deduction: Consult your accountant for eligibility',
              '📊 Clear Records: Detailed invoices for audit compliance',
              '🇺🇸 US: May be deductible under business software expenses',
              '🇪🇺 EU: VAT deductible for registered businesses',
              '⚖️ Not Tax Advice: Consult qualified tax professional',
              '📧 Questions: Contact accounting@iamai.global',
            ],
          },
          {
            heading: 'Tax Exemption Certificates',
            paragraphs: [
              'If you have a valid tax exemption certificate, you may be exempt from sales tax in certain jurisdictions.',
            ],
            list: [
              '📜 Submit Certificate: Email to tax@iamai.global',
              '🏛️ Government Issued: Must be valid, current certificate',
              '🔍 Verification: We verify with relevant tax authority',
              '✅ Approval Process: Review within 5 business days',
              '📅 Future Purchases: Exemption applies to future charges only',
              '🚫 No Retroactive: Tax already paid not refunded',
              '⏰ Annual Renewal: Re-submit annually or as required',
              '📋 Supported: US resale certificates, 501(c)(3) exemptions',
              '🌍 International: Varies by country and type',
              '📧 Questions: Contact tax@iamai.global',
            ],
          },
        ],
        conclusion:
          'We handle tax collection in compliance with local laws and provide professional invoices for all transactions. Access your invoices anytime for business expense documentation and tax filing.',
      },
    },
    {
      id: 'payment-security',
      title: 'Payment Data Security',
      icon: <Shield className="w-6 h-6 text-cyan-400" />,
      excerpt: 'How we protect your payment information and comply with security standards.',
      category: 'Security',
      content: {
        introduction:
          'Protecting your financial information is our highest priority. IA M AI implements industry-leading security measures and complies with international payment security standards.',
        sections: [
          {
            heading: 'PCI DSS Compliance',
            paragraphs: [
              'We are PCI DSS (Payment Card Industry Data Security Standard) Level 1 compliant through our payment providers Stripe and PayPal.',
            ],
            list: [
              '🏆 Level 1 Compliance: Highest level of PCI DSS certification',
              '🔐 Annual Audits: Regular third-party security assessments',
              '📋 12 Requirements: Full compliance with all PCI requirements',
              '🛡️ Secure Network: Firewalls and network segmentation',
              '🔒 Data Encryption: Cardholder data encrypted at rest and in transit',
              '💳 No Card Storage: We never store full card numbers',
              '🔑 Access Controls: Strict limits on who can access payment data',
              '🔍 Monitoring: Continuous security monitoring and logging',
              '📊 Vulnerability Scanning: Regular security scans',
              '✅ Certified Providers: Stripe and PayPal PCI Level 1 certified',
            ],
          },
          {
            heading: 'Data Encryption',
            paragraphs: [
              'All payment data is encrypted using the strongest available encryption standards throughout the entire payment process.',
            ],
            list: [
              '🔒 TLS 1.3: Latest transport layer security protocol',
              '🔐 AES-256: Military-grade encryption for stored data',
              '🗝️ RSA 4096-bit Keys: Strong key encryption',
              '📡 End-to-End: Encryption from browser to payment processor',
              '💳 Tokenization: Card data replaced with secure tokens',
              '🚫 Never Plain Text: Payment info never stored unencrypted',
              '🔄 Key Rotation: Encryption keys regularly updated',
              "🛡️ Perfect Forward Secrecy: Past sessions can't be decrypted",
              '✅ Industry Standard: Exceeds minimum security requirements',
            ],
          },
          {
            heading: 'Tokenization & Data Storage',
            paragraphs: [
              'We use tokenization to store payment methods securely without keeping sensitive card data on our servers.',
            ],
            list: [
              '🔑 Payment Tokens: Card data replaced with random tokens',
              '🏦 Stripe Vault: Actual card data stored securely by Stripe',
              '🚫 No Full Numbers: We never see or store complete card numbers',
              '🔐 Token Security: Tokens are useless if intercepted',
              '💾 What We Store: Only last 4 digits and card brand',
              '🔄 Recurring Billing: Tokens used for subscription renewals',
              '🗑️ Token Deletion: Tokens deleted when you remove payment method',
              '✅ PCI Compliant: Tokenization reduces compliance scope',
              "🛡️ Breach Protection: Stolen tokens can't be used elsewhere",
            ],
          },
          {
            heading: 'Fraud Detection & Prevention',
            paragraphs: [
              'Advanced AI-powered fraud detection systems monitor all transactions in real-time to protect against fraudulent activity.',
            ],
            list: [
              '🤖 Machine Learning: AI algorithms detect suspicious patterns',
              '⚡ Real-Time Analysis: Every transaction analyzed instantly',
              '🚨 Risk Scoring: Transactions rated for fraud probability',
              '🔍 Behavioral Analysis: Unusual activity flagged automatically',
              '🌍 Geolocation Checks: Verify location matches typical patterns',
              '💳 Device Fingerprinting: Recognize trusted devices',
              '📊 Velocity Limits: Multiple rapid attempts blocked',
              '🏦 Bank Integration: Fraud data shared with issuing banks',
              '👤 Manual Review: High-risk transactions reviewed by team',
              '🛡️ Low False Positives: Legitimate purchases rarely blocked',
            ],
          },
          {
            heading: 'Secure Development Practices',
            paragraphs: [
              'Our development team follows secure coding practices and regularly audits our payment integration for vulnerabilities.',
            ],
            list: [
              '👨‍💻 Secure Code Reviews: All payment code peer-reviewed',
              '🧪 Penetration Testing: Regular security testing by experts',
              '🐛 Bug Bounty Program: Security researchers rewarded for findings',
              '📚 OWASP Top 10: Protection against common web vulnerabilities',
              '🔐 Input Validation: All user inputs sanitized',
              '🚫 SQL Injection Protection: Parameterized queries only',
              '🛡️ XSS Prevention: Output encoding and CSP headers',
              '🔒 CSRF Protection: Anti-CSRF tokens on all forms',
              '📊 Security Headers: HSTS, X-Frame-Options, etc.',
              '✅ Continuous Improvement: Regular security updates',
            ],
          },
          {
            heading: 'Data Access Controls',
            paragraphs: [
              'Strict access controls ensure only authorized personnel can access payment-related systems and data.',
            ],
            list: [
              '🔐 Role-Based Access: Minimum necessary permissions',
              '👤 Individual Accounts: No shared credentials',
              '🔑 2FA Required: Multi-factor authentication mandatory',
              '📋 Access Logs: All access attempts logged and audited',
              '⏰ Session Timeouts: Automatic logout after inactivity',
              '🚫 Principle of Least Privilege: Restrictive default permissions',
              '🔍 Regular Audits: Access rights reviewed quarterly',
              '🚨 Immediate Revocation: Ex-employees lose access instantly',
              '🏢 Background Checks: All team members screened',
              '📚 Security Training: Mandatory training for all staff',
            ],
          },
          {
            heading: 'Breach Response Plan',
            paragraphs: [
              'In the unlikely event of a security incident, we have comprehensive procedures to respond quickly and protect your data.',
            ],
            list: [
              '🚨 Incident Response Team: Dedicated security response team',
              '⏱️ Rapid Response: Incidents addressed within hours',
              '🔍 Investigation: Thorough forensic analysis',
              '📧 User Notification: Affected users notified promptly',
              '🏦 Bank Notification: Payment processors and banks informed',
              '⚖️ Regulatory Compliance: Authorities notified as required',
              '🛡️ Containment: Immediate steps to limit damage',
              '🔄 Remediation: Vulnerabilities patched immediately',
              '📊 Post-Incident Review: Learn and improve from incidents',
              '💰 Liability Coverage: Cyber insurance in place',
            ],
          },
        ],
        conclusion:
          'Your payment security is paramount. Through PCI DSS compliance, encryption, tokenization, and advanced fraud detection, we ensure your financial information is protected with bank-level security.',
      },
    },
  ];

  const categories = ['all', 'Payment', 'Refund', 'Support', 'Documentation', 'Security'];

  const filteredArticles =
    activeCategory === 'all'
      ? articles
      : articles.filter(article => article.category === activeCategory);

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <header className="border-b border-gray-800 bg-[#0a0a0a] sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <button
              onClick={() => onNavigate('home')}
              className="flex items-center gap-2 text-cyan-400 hover:text-cyan-300 transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
              <span className="text-sm">Back to Home</span>
            </button>
            <h1 className="text-2xl md:text-3xl font-bold text-white">Payment & Refund Policy</h1>
            <div className="w-20"></div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-12">
        <div className="max-w-7xl mx-auto">
          {/* Introduction */}
          <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-8 mb-8">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-3 bg-cyan-900/50 border border-cyan-500/30 rounded-xl">
                <CreditCard className="w-8 h-8 text-cyan-400" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-white">Payment & Refund Policy</h2>
                <p className="text-gray-500">Last updated: November 2025</p>
              </div>
            </div>
            <p className="text-gray-400 leading-relaxed mb-4">
              Welcome to <span className="text-cyan-400 font-semibold">IA M AI\'s</span> Payment and
              Refund Policy. We accept payments through PayPal and Stripe, with secure OTP
              verification for all transactions. Our $1 minimum pricing allows risk-free testing of
              our AI services.
            </p>
            <div className="bg-red-900/20 border border-red-500/30 rounded-xl p-4 mt-4">
              <div className="flex items-start gap-3">
                <Ban className="w-6 h-6 text-red-400 flex-shrink-0 mt-1" />
                <div>
                  <p className="text-red-400 font-semibold mb-1">No Refund Policy</p>
                  <p className="text-gray-400 text-sm">
                    All payments are final and non-refundable. We offer a $1 test subscription to
                    evaluate our services before committing to a full subscription.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Category Filters */}
          <div className="mb-8">
            <h3 className="text-lg font-semibold mb-4 text-white">Browse by Category</h3>
            <div className="flex flex-wrap gap-2">
              {categories.map(category => (
                <button
                  key={category}
                  onClick={() => setActiveCategory(category)}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                    activeCategory === category
                      ? 'bg-cyan-500 text-black shadow-lg'
                      : 'bg-gray-900/50 text-gray-400 hover:bg-gray-800 border border-gray-800 hover:text-cyan-400'
                  }`}
                >
                  {category === 'all' ? '📋 All Articles' : category}
                </button>
              ))}
            </div>
          </div>

          {/* Article Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            {filteredArticles.map(article => (
              <div
                key={article.id}
                className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6 hover:border-cyan-500/50 transition-all cursor-pointer group"
                onClick={() => setSelectedArticle(article)}
              >
                <div className="flex items-start gap-4 mb-4">
                  <div className="p-3 bg-cyan-900/50 border border-cyan-500/30 rounded-xl group-hover:bg-cyan-500/20 transition-colors">
                    {article.icon}
                  </div>
                  <div className="flex-1">
                    <h3 className="text-lg font-bold text-white group-hover:text-cyan-400 transition-colors mb-1">
                      {article.title}
                    </h3>
                    <span className="inline-block px-2 py-1 bg-gray-800 text-cyan-400 text-xs rounded-full">
                      {article.category}
                    </span>
                  </div>
                </div>
                <p className="text-gray-400 text-sm mb-4 line-clamp-3">{article.excerpt}</p>
                <div className="flex items-center gap-2 text-cyan-400 text-sm font-medium group-hover:text-cyan-300 transition-colors">
                  <BookOpen className="w-4 h-4" />
                  <span>Read Full Article</span>
                  <ExternalLink className="w-3 h-3 ml-auto" />
                </div>
              </div>
            ))}
          </div>

          {/* Contact Information */}
          <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-8">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-3 bg-cyan-900/50 border border-cyan-500/30 rounded-xl">
                <AlertCircle className="w-6 h-6 text-cyan-400" />
              </div>
              <h2 className="text-2xl font-bold text-white">Payment Support</h2>
            </div>
            <p className="text-gray-400 mb-4">
              Need help with billing, payment issues, or have questions about our policies? Contact
              our billing support team:
            </p>
            <div className="space-y-2 text-gray-400">
              <p>
                <span className="text-cyan-400 font-semibold">Billing Issues:</span>{' '}
                billing@iamai.global
              </p>
              <p>
                <span className="text-cyan-400 font-semibold">Refund Requests:</span>{' '}
                refunds@iamai.global
              </p>
              <p>
                <span className="text-cyan-400 font-semibold">Tax Questions:</span> tax@iamai.global
              </p>
              <p>
                <span className="text-cyan-400 font-semibold">General Support:</span>{' '}
                support@iamai.global
              </p>
            </div>
          </div>
        </div>
      </main>

      {/* Article Modal */}
      {selectedArticle && (
        <div
          className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4 animate-fadeIn"
          onClick={() => setSelectedArticle(null)}
        >
          <div
            className="bg-[#0a0a0a] border border-gray-800 rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden"
            onClick={e => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="sticky top-0 bg-[#0a0a0a] border-b border-gray-800 p-6 flex items-start justify-between z-10">
              <div className="flex items-start gap-4 flex-1">
                <div className="p-3 bg-cyan-900/50 border border-cyan-500/30 rounded-xl flex-shrink-0">
                  {selectedArticle.icon}
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-white mb-2">{selectedArticle.title}</h2>
                  <span className="inline-block px-3 py-1 bg-gray-800 text-cyan-400 text-sm rounded-full">
                    {selectedArticle.category}
                  </span>
                </div>
              </div>
              <button
                onClick={() => setSelectedArticle(null)}
                className="p-2 hover:bg-gray-800 rounded-lg transition-colors flex-shrink-0"
              >
                <X className="w-6 h-6 text-gray-400 hover:text-white" />
              </button>
            </div>

            {/* Modal Content - Scrollable */}
            <div className="overflow-y-auto max-h-[calc(90vh-140px)] p-6 space-y-6">
              {/* Introduction */}
              {selectedArticle.content.introduction && (
                <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-6">
                  <p className="text-gray-400 leading-relaxed">
                    {selectedArticle.content.introduction}
                  </p>
                </div>
              )}

              {/* Sections */}
              {selectedArticle.content.sections.map((section, index) => (
                <div key={index} className="space-y-4">
                  <h3 className="text-xl font-bold text-white flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-cyan-900/50 border border-cyan-500/30 flex items-center justify-center text-cyan-400 text-sm font-bold">
                      {index + 1}
                    </div>
                    {section.heading}
                  </h3>

                  {section.paragraphs.map((paragraph, pIndex) => (
                    <p key={pIndex} className="text-gray-400 leading-relaxed pl-10">
                      {paragraph}
                    </p>
                  ))}

                  {section.list && section.list.length > 0 && (
                    <ul className="space-y-2 pl-10">
                      {section.list.map((item, itemIndex) => (
                        <li key={itemIndex} className="flex items-start gap-3">
                          <CheckCircle className="w-5 h-5 text-cyan-400 flex-shrink-0 mt-0.5" />
                          <span className="text-gray-400 text-sm">{item}</span>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              ))}

              {/* Conclusion */}
              {selectedArticle.content.conclusion && (
                <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-6 mt-8">
                  <div className="flex items-start gap-3">
                    <AlertCircle className="w-6 h-6 text-cyan-400 flex-shrink-0 mt-1" />
                    <p className="text-gray-400 leading-relaxed font-medium">
                      {selectedArticle.content.conclusion}
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PaymentRefundPage;
