import React, { useState, useEffect } from 'react';
import {
  Search,
  Check,
  X,
  Globe,
  TrendingUp,
  Activity,
  Clock,
  Info,
  Copy,
  Download,
} from 'lucide-react';

interface DomainAvailability {
  domain: string;
  tld: string;
  available: boolean;
  price?: number;
  premium: boolean;
  registrar?: string;
}

interface BulkResult {
  results: DomainAvailability[];
  availableCount: number;
  takenCount: number;
  totalChecked: number;
}

interface HistoryItem {
  id: string;
  domain: string;
  timestamp: number;
  available: boolean;
  status: 'success' | 'error';
}

const DomainAvailabilityPage: React.FC = () => {
  const [domain, setDomain] = useState('');
  const [bulkDomains, setBulkDomains] = useState('');
  const [selectedTlds, setSelectedTlds] = useState<string[]>(['.com', '.net', '.org']);
  const [activeTab, setActiveTab] = useState<'single' | 'bulk'>('single');
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<DomainAvailability | null>(null);
  const [bulkResult, setBulkResult] = useState<BulkResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [showHistory, setShowHistory] = useState(false);

  const popularTlds = [
    '.com',
    '.net',
    '.org',
    '.io',
    '.co',
    '.app',
    '.dev',
    '.ai',
    '.tech',
    '.online',
    '.site',
    '.store',
    '.blog',
    '.info',
    '.biz',
  ];

  const [stats, setStats] = useState({
    totalChecks: 0,
    availableDomains: 0,
    takenDomains: 0,
    successRate: 0,
  });

  useEffect(() => {
    const savedHistory = localStorage.getItem('domainAvailHistory');
    if (savedHistory) setHistory(JSON.parse(savedHistory));
    const savedStats = localStorage.getItem('domainAvailStats');
    if (savedStats) setStats(JSON.parse(savedStats));
  }, []);

  useEffect(() => {
    if (history.length > 0) {
      localStorage.setItem('domainAvailHistory', JSON.stringify(history.slice(0, 100)));
      updateStats();
    }
  }, [history]);

  const updateStats = () => {
    const successItems = history.filter(h => h.status === 'success');
    const availCount = successItems.filter(h => h.available).length;
    const takenCount = successItems.filter(h => !h.available).length;
    const successRate =
      successItems.length > 0 ? Math.round((availCount / successItems.length) * 100) : 0;

    const newStats = {
      totalChecks: history.length,
      availableDomains: availCount,
      takenDomains: takenCount,
      successRate,
    };

    setStats(newStats);
    localStorage.setItem('domainAvailStats', JSON.stringify(newStats));
  };

  const handleCheck = async () => {
    if (!domain.trim()) {
      setError('Please enter a domain name');
      return;
    }

    setIsLoading(true);
    setError(null);
    setResult(null);

    try {
      const cleanDomain = domain
        .replace(/^https?:\/\//, '')
        .replace(/\/$/, '')
        .toLowerCase();

      const response = await fetch(
        `/api/tools/domain-availability?domain=${encodeURIComponent(cleanDomain)}`
      );

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `API Error: ${response.status}`);
      }

      const data = await response.json();

      if (!data.success) {
        throw new Error(data.error || 'Failed to check domain availability');
      }

      const availData: DomainAvailability = {
        domain: data.domain,
        tld: data.tld,
        available: data.available,
        price: data.price,
        premium: data.premium,
        registrar: data.registrar,
      };

      setResult(availData);

      const historyItem: HistoryItem = {
        id: Date.now().toString(),
        domain: cleanDomain,
        timestamp: Date.now(),
        available: data.available,
        status: 'success',
      };

      setHistory(prev => [historyItem, ...prev]);
    } catch (err: any) {
      setError(err.message || 'Failed to check domain availability');
      const historyItem: HistoryItem = {
        id: Date.now().toString(),
        domain,
        timestamp: Date.now(),
        available: false,
        status: 'error',
      };
      setHistory(prev => [historyItem, ...prev]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleBulkCheck = async () => {
    if (!bulkDomains.trim()) {
      setError('Please enter at least one domain name');
      return;
    }

    setIsLoading(true);
    setError(null);
    setBulkResult(null);

    try {
      const baseDomains = bulkDomains
        .split('\n')
        .map(d => d.trim())
        .filter(Boolean);

      const results: DomainAvailability[] = [];

      for (const baseDomain of baseDomains) {
        for (const tld of selectedTlds) {
          const fullDomain = baseDomain.includes('.') ? baseDomain : `${baseDomain}${tld}`;

          try {
            const response = await fetch(
              `/api/tools/domain-availability?domain=${encodeURIComponent(fullDomain)}`
            );

            if (response.ok) {
              const data = await response.json();

              if (data.success) {
                results.push({
                  domain: data.domain,
                  tld: data.tld,
                  available: data.available,
                  price: data.price,
                  premium: data.premium,
                  registrar: data.registrar,
                });

                // Add to history
                const historyItem: HistoryItem = {
                  id: `${Date.now()}-${fullDomain}`,
                  domain: fullDomain,
                  timestamp: Date.now(),
                  available: data.available,
                  status: 'success',
                };
                setHistory(prev => [historyItem, ...prev]);
              }
            }
          } catch (err) {
            console.error(`Failed to check ${fullDomain}:`, err);
          }
        }
      }

      const availCount = results.filter(r => r.available).length;
      const takenCount = results.length - availCount;

      setBulkResult({
        results,
        availableCount: availCount,
        takenCount,
        totalChecked: results.length,
      });
    } catch (err: any) {
      setError(err.message || 'Failed to check domain availability');
    } finally {
      setIsLoading(false);
    }
  };

  const toggleTld = (tld: string) => {
    if (selectedTlds.includes(tld)) {
      setSelectedTlds(selectedTlds.filter(t => t !== tld));
    } else {
      setSelectedTlds([...selectedTlds, tld]);
    }
  };

  const exportBulkResults = () => {
    if (!bulkResult) return;
    const csvContent = [
      'Domain,TLD,Available,Price,Premium',
      ...bulkResult.results.map(
        r =>
          `${r.domain},${r.tld},${r.available ? 'Yes' : 'No'},${r.price ? '$' + r.price : 'N/A'},${r.premium ? 'Yes' : 'No'}`
      ),
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `domain_availability_${Date.now()}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const formatTimestamp = (timestamp: number) => {
    const date = new Date(timestamp);
    return date.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <div className="min-h-screen bg-black text-white p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 bg-gradient-to-br from-cyan-500/10 to-blue-500/10 rounded-xl">
              <Globe className="w-8 h-8 text-cyan-400" />
            </div>
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-cyan-400 via-blue-400 to-purple-400 bg-clip-text text-transparent">
                Domain Availability Checker
              </h1>
              <p className="text-gray-400 mt-1">
                Find your perfect domain name across multiple TLDs
              </p>
            </div>
          </div>

          <div className="bg-gradient-to-br from-cyan-500/5 to-blue-500/5 border border-cyan-500/20 rounded-xl p-4">
            <div className="flex items-start gap-3">
              <Info className="w-5 h-5 text-cyan-400 mt-0.5 flex-shrink-0" />
              <div className="text-sm text-gray-300">
                <p className="font-semibold text-cyan-400 mb-1">About Domain Availability</p>
                <p>
                  Check if domain names are available for registration across multiple TLDs. Get
                  pricing information and identify premium domains. Powered by{' '}
                  <span className="text-cyan-400 font-semibold">IA M AI Global Platform</span>.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Stats Dashboard */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border border-cyan-500/20 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <Search className="w-5 h-5 text-cyan-400" />
              <TrendingUp className="w-4 h-4 text-cyan-400/50" />
            </div>
            <div className="text-2xl font-bold text-cyan-400">{stats?.totalChecks || 0}</div>
            <div className="text-sm text-gray-400 mt-1">Total Checks</div>
          </div>

          <div className="bg-gradient-to-br from-green-500/10 to-emerald-500/10 border border-green-500/20 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <Check className="w-5 h-5 text-green-400" />
              <Activity className="w-4 h-4 text-green-400/50" />
            </div>
            <div className="text-2xl font-bold text-green-400">{stats.availableDomains}</div>
            <div className="text-sm text-gray-400 mt-1">Available</div>
          </div>

          <div className="bg-gradient-to-br from-red-500/10 to-pink-500/10 border border-red-500/20 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <X className="w-5 h-5 text-red-400" />
              <Activity className="w-4 h-4 text-red-400/50" />
            </div>
            <div className="text-2xl font-bold text-red-400">{stats.takenDomains}</div>
            <div className="text-sm text-gray-400 mt-1">Taken</div>
          </div>

          <div className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border border-purple-500/20 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <TrendingUp className="w-5 h-5 text-purple-400" />
              <Activity className="w-4 h-4 text-purple-400/50" />
            </div>
            <div className="text-2xl font-bold text-purple-400">{stats.successRate}%</div>
            <div className="text-sm text-gray-400 mt-1">Success Rate</div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Tabs */}
            <div className="flex gap-2 bg-gray-900 border border-gray-800 rounded-xl p-2">
              <button
                onClick={() => setActiveTab('single')}
                className={`flex-1 px-4 py-3 rounded-lg font-semibold transition-all ${
                  activeTab === 'single'
                    ? 'bg-gradient-to-r from-cyan-500 to-blue-500 text-white'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                Single Domain
              </button>
              <button
                onClick={() => setActiveTab('bulk')}
                className={`flex-1 px-4 py-3 rounded-lg font-semibold transition-all ${
                  activeTab === 'bulk'
                    ? 'bg-gradient-to-r from-cyan-500 to-blue-500 text-white'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                Bulk Check
              </button>
            </div>

            {/* Single Domain Check */}
            {activeTab === 'single' && (
              <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
                <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                  <Search className="w-5 h-5 text-cyan-400" />
                  Check Single Domain
                </h2>
                <div className="flex flex-col sm:flex-row gap-3">
                  <input
                    type="text"
                    value={domain}
                    onChange={e => setDomain(e.target.value)}
                    onKeyPress={e => e.key === 'Enter' && !isLoading && handleCheck()}
                    placeholder="Enter domain name (e.g., mywebsite.com)"
                    className="flex-1 px-4 py-3 bg-black border border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500 text-white placeholder-gray-500"
                    disabled={isLoading}
                  />
                  <button
                    onClick={handleCheck}
                    disabled={isLoading}
                    className="px-6 py-3 bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 disabled:from-gray-600 disabled:to-gray-700 rounded-lg font-semibold transition-all duration-200 flex items-center justify-center gap-2 whitespace-nowrap w-full sm:w-auto"
                  >
                    {isLoading ? (
                      <>
                        <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        Checking...
                      </>
                    ) : (
                      <>
                        <Search className="w-5 h-5" />
                        Check
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}

            {/* Bulk Check */}
            {activeTab === 'bulk' && (
              <div className="bg-gray-900 border border-gray-800 rounded-xl p-6 space-y-4">
                <h2 className="text-xl font-semibold flex items-center gap-2">
                  <Search className="w-5 h-5 text-cyan-400" />
                  Bulk Domain Check
                </h2>

                <div>
                  <label className="text-sm text-gray-400 mb-2 block">
                    Domain Names (one per line)
                  </label>
                  <textarea
                    value={bulkDomains}
                    onChange={e => setBulkDomains(e.target.value)}
                    placeholder={'mysite\nbusiness\ncompany'}
                    rows={5}
                    className="w-full px-4 py-3 bg-black border border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500 text-white placeholder-gray-500 font-mono text-sm"
                    disabled={isLoading}
                  />
                </div>

                <div>
                  <label className="text-sm text-gray-400 mb-2 block">Select TLDs to Check</label>
                  <div className="flex flex-wrap gap-2">
                    {popularTlds.map(tld => (
                      <button
                        key={tld}
                        onClick={() => toggleTld(tld)}
                        className={`px-3 py-1.5 rounded-lg border font-medium text-sm transition-colors ${
                          selectedTlds.includes(tld)
                            ? 'bg-cyan-500/20 border-cyan-500/50 text-cyan-400'
                            : 'bg-gray-800 border-gray-700 text-gray-400 hover:border-gray-600'
                        }`}
                      >
                        {tld}
                      </button>
                    ))}
                  </div>
                </div>

                <button
                  onClick={handleBulkCheck}
                  disabled={isLoading || selectedTlds.length === 0}
                  className="w-full px-6 py-3 bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 disabled:from-gray-600 disabled:to-gray-700 rounded-lg font-semibold transition-all duration-200 flex items-center justify-center gap-2"
                >
                  {isLoading ? (
                    <>
                      <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      Checking...
                    </>
                  ) : (
                    <>
                      <Search className="w-5 h-5" />
                      Check All ({selectedTlds.length} TLDs)
                    </>
                  )}
                </button>
              </div>
            )}

            {/* Error */}
            {error && (
              <div className="bg-gradient-to-br from-red-500/10 to-pink-500/10 border border-red-500/30 rounded-xl p-4">
                <div className="flex items-center gap-3">
                  <X className="w-5 h-5 text-red-400" />
                  <p className="text-red-400">{error}</p>
                </div>
              </div>
            )}

            {/* Single Result */}
            {result && activeTab === 'single' && (
              <div
                className={`border rounded-xl p-6 ${
                  result.available
                    ? 'bg-gradient-to-br from-green-500/10 to-emerald-500/10 border-green-500/30'
                    : 'bg-gradient-to-br from-red-500/10 to-pink-500/10 border-red-500/30'
                }`}
              >
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-semibold flex items-center gap-2">
                    {result.available ? (
                      <Check className="w-6 h-6 text-green-400" />
                    ) : (
                      <X className="w-6 h-6 text-red-400" />
                    )}
                    {result.available ? 'Domain Available!' : 'Domain Taken'}
                  </h2>
                  <button
                    onClick={() => copyToClipboard(result.domain)}
                    className="p-2 bg-gray-800 hover:bg-gray-700 border border-gray-700 rounded-lg"
                  >
                    <Copy className="w-4 h-4" />
                  </button>
                </div>

                <div className="text-2xl font-bold mb-4">{result.domain}</div>

                {result.available && (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-400">Estimated Price:</span>
                      <span className="text-xl font-bold text-green-400">
                        $
                        {typeof result.price === 'object'
                          ? JSON.stringify(result.price)
                          : result.price || '0'}
                      </span>
                    </div>
                    {result.premium && (
                      <div className="px-3 py-2 bg-yellow-500/20 border border-yellow-500/30 rounded-lg text-yellow-400 text-sm font-semibold">
                        ⭐ Premium Domain
                      </div>
                    )}
                    <button className="w-full px-4 py-3 bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 rounded-lg font-semibold transition-all">
                      Register Domain
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* Bulk Results */}
            {bulkResult && activeTab === 'bulk' && (
              <div className="space-y-4">
                <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-semibold">Bulk Check Results</h2>
                    <button
                      onClick={exportBulkResults}
                      className="px-4 py-2 bg-gradient-to-r from-cyan-500/20 to-blue-500/20 border border-cyan-500/30 rounded-lg flex items-center gap-2 hover:from-cyan-500/30 hover:to-blue-500/30"
                    >
                      <Download className="w-4 h-4" />
                      Export CSV
                    </button>
                  </div>

                  <div className="grid grid-cols-3 gap-4 mb-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-cyan-400">
                        {bulkResult.totalChecked}
                      </div>
                      <div className="text-sm text-gray-400">Total Checked</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-green-400">
                        {bulkResult.availableCount}
                      </div>
                      <div className="text-sm text-gray-400">Available</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-red-400">{bulkResult.takenCount}</div>
                      <div className="text-sm text-gray-400">Taken</div>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  {bulkResult.results.map((item, idx) => (
                    <div
                      key={idx}
                      className={`p-4 border rounded-lg flex items-center justify-between ${
                        item.available
                          ? 'bg-green-500/5 border-green-500/20'
                          : 'bg-red-500/5 border-red-500/20'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        {item.available ? (
                          <Check className="w-5 h-5 text-green-400" />
                        ) : (
                          <X className="w-5 h-5 text-red-400" />
                        )}
                        <div>
                          <div className="font-medium">{item.domain}</div>
                          {item.available && item.price && (
                            <div className="text-sm text-gray-400">
                              $
                              {typeof item.price === 'object'
                                ? JSON.stringify(item.price)
                                : item.price || '0'}
                              /year
                            </div>
                          )}
                        </div>
                      </div>
                      {item.premium && (
                        <span className="px-2 py-1 bg-yellow-500/20 text-yellow-400 rounded text-xs font-bold">
                          Premium
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* History Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-gray-900 border border-gray-800 rounded-xl p-6 sticky top-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold flex items-center gap-2">
                  <Clock className="w-5 h-5 text-cyan-400" />
                  Recent Checks
                </h2>
                <button
                  onClick={() => setShowHistory(!showHistory)}
                  className="text-sm text-cyan-400 hover:text-cyan-300"
                >
                  {showHistory ? 'Hide' : 'Show'}
                </button>
              </div>

              {showHistory && (
                <div className="space-y-2 max-h-[600px] overflow-y-auto custom-scrollbar">
                  {history.length === 0 ? (
                    <p className="text-gray-500 text-sm text-center py-8">No check history yet</p>
                  ) : (
                    history.slice(0, 50).map(item => (
                      <div
                        key={item.id}
                        onClick={() => setDomain(item.domain)}
                        className="p-3 rounded-lg border bg-gray-800/50 border-gray-700 hover:bg-gray-800 cursor-pointer transition-colors"
                      >
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-sm font-medium truncate">{item.domain}</span>
                          {item.available ? (
                            <Check className="w-4 h-4 text-green-400 flex-shrink-0" />
                          ) : (
                            <X className="w-4 h-4 text-red-400 flex-shrink-0" />
                          )}
                        </div>
                        <div className="text-xs text-gray-500">
                          {formatTimestamp(item.timestamp)}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 6px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: #1f2937; border-radius: 3px; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #4b5563; border-radius: 3px; }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: #6b7280; }
      `}</style>
    </div>
  );
};

export default DomainAvailabilityPage;
