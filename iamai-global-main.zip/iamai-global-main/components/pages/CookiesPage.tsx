import React, { useState } from 'react';
import { Page } from '../../App';
import { ArrowLeft, Cookie, Lock, Settings, Zap, Globe, Shield, Eye, Clock, Ban, CheckCircle, X, ExternalLink, BookOpen, AlertCircle, FileText } from 'lucide-react';

interface CookiesPageProps {
  onNavigate: (page: Page) => void;
}

interface CookieArticle {
  id: string;
  title: string;
  icon: React.ReactNode;
  excerpt: string;
  category: string;
  content: {
    introduction: string;
    sections: {
      heading: string;
      paragraphs: string[];
      list?: string[];
    }[];
    conclusion?: string;
  };
}

const CookiesPage: React.FC<CookiesPageProps> = ({ onNavigate }) => {
  const [selectedArticle, setSelectedArticle] = useState<CookieArticle | null>(null);
  const [activeCategory, setActiveCategory] = useState<string>('all');

  const articles: CookieArticle[] = [
    {
      id: 'what-cookies',
      title: 'What Are Cookies?',
      icon: <Cookie className="w-6 h-6 text-cyan-400" />,
      excerpt: 'Understanding cookies, how they work, and why websites use them.',
      category: 'Basics',
      content: {
        introduction: 'Cookies are small text files stored on your device when you visit websites. They are fundamental to modern web experiences, enabling personalization, security, and functionality.',
        sections: [
          {
            heading: 'Definition & Technical Overview',
            paragraphs: [
              'A cookie is a small piece of data (typically less than 4KB) that a website sends to your browser. Your browser stores the cookie and sends it back to the server with subsequent requests.',
              'Cookies contain information like session IDs, preferences, or tracking data. They cannot execute code, contain viruses, or access your personal files.'
            ],
            list: [
              '📁 Stored by your web browser on your device',
              '🔤 Contain text data in key-value pairs',
              '📏 Maximum size: 4KB per cookie',
              '📊 Each domain can set multiple cookies',
              '🔒 Cannot access data from other websites',
              '🚫 Cannot read files or spread viruses',
              '⏱️ Have expiration dates (or deleted when browser closes)',
              '🔄 Sent to server with every request to that domain'
            ]
          },
          {
            heading: 'How Cookies Work',
            paragraphs: [
              'When you visit IA M AI, our server sends cookies to your browser with HTTP response headers. Your browser stores these cookies and includes them in subsequent requests.'
            ],
            list: [
              '1️⃣ You visit iamai.global',
              '2️⃣ Server sends Set-Cookie header with response',
              '3️⃣ Your browser stores the cookie',
              '4️⃣ Browser includes cookie in future requests',
              '5️⃣ Server reads cookie and recognizes you',
              '6️⃣ Personalized experience delivered',
              '🔄 Process repeats for each page view'
            ]
          },
          {
            heading: 'Types of Cookies by Lifespan',
            paragraphs: [
              'Cookies can be temporary or persistent based on how long they last:'
            ],
            list: [
              '🕐 Session Cookies: Deleted when you close your browser',
              '🕐 Persistent Cookies: Remain for days, months, or years',
              '⏰ Session cookies used for: Login state, shopping carts',
              '⏰ Persistent cookies used for: Preferences, analytics, "Remember Me" features'
            ]
          },
          {
            heading: 'Types of Cookies by Source',
            paragraphs: [
              'Cookies are categorized based on who sets them:'
            ],
            list: [
              '🏠 First-Party Cookies: Set by iamai.global directly',
              '🌐 Third-Party Cookies: Set by external services (ads, analytics)',
              '✅ First-party: Essential for platform functionality',
              '⚠️ Third-party: Often used for tracking and advertising',
              '🚫 You can block third-party cookies in browser settings'
            ]
          }
        ],
        conclusion: 'Cookies are essential web technology that enable modern online experiences. Understanding them helps you make informed decisions about your privacy.'
      }
    },
    {
      id: 'cookie-types-we-use',
      title: 'Types of Cookies We Use',
      icon: <Settings className="w-6 h-6 text-cyan-400" />,
      excerpt: 'Detailed breakdown of cookie categories used on IA M AI platform.',
      category: 'Our Usage',
      content: {
        introduction: 'IA M AI uses various types of cookies to provide services, improve your experience, and analyze platform usage. This article explains each category and its purpose.',
        sections: [
          {
            heading: 'Strictly Necessary Cookies',
            paragraphs: [
              'These cookies are essential for the platform to function. They cannot be disabled as the site would not work without them. These cookies do not require your consent under GDPR.'
            ],
            list: [
              '🔐 Authentication: Keep you logged in securely',
              '🛡️ Security: CSRF protection, session validation',
              '🔑 Session Management: Maintain your active session',
              '⚖️ Load Balancing: Distribute traffic across servers',
              '🚦 Rate Limiting: Prevent abuse and ensure fair use',
              '📋 Form Submissions: Remember form data between pages',
              '🍪 Cookie Consent: Remember your cookie preferences',
              '⏱️ Lifespan: Session cookies (deleted when browser closes) or up to 30 days'
            ]
          },
          {
            heading: 'Functional Cookies',
            paragraphs: [
              'These cookies enhance functionality and personalization but are not essential. You can usually control these through cookie settings.'
            ],
            list: [
              '🎨 Theme Preferences: Remember dark/light mode choice',
              '🌐 Language Settings: Store your language preference',
              '🔊 Accessibility: Remember font size, contrast settings',
              '💬 AI Agent Preferences: Remember favorite agents',
              '📱 Layout Preferences: Sidebar collapsed/expanded state',
              '🎯 Personalization: Customized homepage layout',
              '⏱️ Lifespan: 30 days to 1 year',
              '🔧 You can disable these in cookie settings (some features may be affected)'
            ]
          },
          {
            heading: 'Performance & Analytics Cookies',
            paragraphs: [
              'These cookies help us understand how users interact with our platform so we can improve it. They collect aggregated, anonymous data.'
            ],
            list: [
              '📊 Google Analytics: Usage patterns and traffic analysis',
              '📈 Performance Monitoring: Page load times, errors',
              '🔍 Feature Usage: Which features are most popular',
              '🎯 A/B Testing: Compare different interface designs',
              '📉 Error Tracking: Identify and fix bugs',
              '👥 Visitor Counts: Unique vs. returning visitors',
              '🗺️ Navigation Paths: How users navigate the site',
              '⏱️ Lifespan: Up to 2 years',
              '🔧 You can opt-out in cookie settings or use browser Do Not Track'
            ]
          },
          {
            heading: 'Marketing & Advertising Cookies',
            paragraphs: [
              'These cookies are used to deliver relevant advertisements and measure campaign effectiveness. They require your explicit consent.'
            ],
            list: [
              '🎯 Behavioral Targeting: Ads based on browsing behavior',
              '🔄 Retargeting: Show ads to previous visitors',
              '📊 Campaign Tracking: Measure ad effectiveness',
              '🤝 Partner Networks: Coordinate ads across platforms',
              '📈 Conversion Tracking: Track sign-ups from ads',
              '🎬 Social Media: Enable sharing and show relevant ads',
              '⏱️ Lifespan: 30 days to 13 months',
              '✅ Requires explicit opt-in consent',
              '🚫 You can reject all marketing cookies'
            ]
          },
          {
            heading: 'Third-Party Cookies',
            paragraphs: [
              'Some cookies are set by external services we integrate with. We carefully vet all third parties and they must comply with our privacy standards.'
            ],
            list: [
              '🤖 AI Providers: Mistral AI, OpenAI, Google Gemini',
              '💳 Payment Processing: Stripe (secure checkout)',
              '📧 Email Services: Newsletter and transactional emails',
              '💬 Support Chat: Customer support widget',
              '📊 Analytics: Google Analytics, privacy-focused alternatives',
              '🔗 Social Media: Facebook, Twitter, LinkedIn embed cookies',
              '📹 Video Embeds: YouTube, Vimeo player cookies',
              '✅ All third parties bound by contracts with privacy requirements',
              '🔧 You can block third-party cookies in browser settings'
            ]
          }
        ],
        conclusion: 'We categorize cookies clearly and give you control over non-essential cookies. Strictly necessary cookies ensure the platform works, while others enhance your experience or help us improve.'
      }
    },
    {
      id: 'why-use-cookies',
      title: 'Why We Use Cookies',
      icon: <Zap className="w-6 h-6 text-cyan-400" />,
      excerpt: 'The purposes and benefits of cookies for users and platform functionality.',
      category: 'Our Usage',
      content: {
        introduction: 'Cookies enable IA M AI to provide a seamless, personalized, and secure experience. This article explains the specific purposes cookies serve on our platform.',
        sections: [
          {
            heading: 'Authentication & Security',
            paragraphs: [
              'Cookies are essential for keeping your account secure and you logged in as you navigate the platform.'
            ],
            list: [
              '🔐 Session Management: Maintain your logged-in state',
              '🛡️ CSRF Protection: Prevent cross-site request forgery attacks',
              '🔑 Token Storage: Securely store authentication tokens',
              '🚦 Rate Limiting: Prevent brute force and DDoS attacks',
              '👤 User Identification: Associate actions with your account',
              '⏰ Session Timeout: Auto-logout after inactivity for security',
              '🔄 Remember Me: Optional persistent login',
              '🚨 Suspicious Activity Detection: Flag unusual behavior'
            ]
          },
          {
            heading: 'Personalization & Preferences',
            paragraphs: [
              'Cookies remember your preferences so you don\'t have to reconfigure settings every visit.'
            ],
            list: [
              '🎨 Theme: Dark mode vs. light mode preference',
              '🌐 Language: Remember your language choice',
              '💬 AI Agent: Remember favorite agents and recent conversations',
              '🔊 Accessibility: Font size, contrast, screen reader settings',
              '📱 Layout: Sidebar state, dashboard customization',
              '🎵 Media: Volume levels, playback preferences',
              '📍 Location: Time zone for timestamps',
              '🔔 Notifications: Notification preferences and settings'
            ]
          },
          {
            heading: 'Platform Performance',
            paragraphs: [
              'Cookies help us optimize performance and deliver a fast, smooth experience.'
            ],
            list: [
              '⚡ Caching: Reduce server load and speed up page loads',
              '⚖️ Load Balancing: Distribute traffic efficiently',
              '🔄 State Management: Remember form data and navigation state',
              '📊 Performance Monitoring: Identify slow pages and errors',
              '🐛 Error Tracking: Collect error reports with context',
              '🚀 Optimization: A/B test performance improvements',
              '💾 Resource Loading: Optimize asset delivery'
            ]
          },
          {
            heading: 'Analytics & Improvement',
            paragraphs: [
              'Analytics cookies help us understand how users interact with our platform so we can make it better.'
            ],
            list: [
              '📈 Usage Patterns: Understand which features are popular',
              '🗺️ User Journeys: See how users navigate the platform',
              '🎯 Feature Adoption: Measure new feature usage',
              '👥 Demographics: Anonymous aggregate user data',
              '📉 Drop-off Points: Identify where users encounter difficulties',
              '⏱️ Time on Site: Understand engagement levels',
              '🔍 Search Behavior: Improve search functionality',
              '💡 Insights: Data-driven product decisions'
            ]
          },
          {
            heading: 'Communication & Support',
            paragraphs: [
              'Cookies power customer support and communication features.'
            ],
            list: [
              '💬 Live Chat: Maintain conversation context',
              '📧 Email Campaigns: Track email engagement (with consent)',
              '🔔 Notifications: Deliver real-time updates',
              '📲 Push Notifications: Browser notification permission',
              '🎫 Support Tickets: Associate tickets with your account',
              '💭 Feedback: Collect and attribute user feedback',
              '📞 Contact History: Remember previous interactions'
            ]
          },
          {
            heading: 'Compliance & Legal',
            paragraphs: [
              'Cookies help us comply with legal obligations and protect against fraud.'
            ],
            list: [
              '📋 Consent Management: Remember your cookie preferences',
              '⚖️ Legal Requirements: Audit trails for compliance',
              '🚨 Fraud Detection: Identify suspicious patterns',
              '🔍 Abuse Prevention: Detect and prevent platform abuse',
              '📊 Regulatory Reporting: Data for required reports',
              '🛡️ Terms Acceptance: Track acceptance of updated terms'
            ]
          }
        ],
        conclusion: 'Cookies serve critical purposes from security to personalization. While some are essential, we give you control over non-essential cookies and explain clearly how each type benefits your experience.'
      }
    },
    {
      id: 'cookie-management',
      title: 'Managing Cookie Preferences',
      icon: <Shield className="w-6 h-6 text-cyan-400" />,
      excerpt: 'How to control cookies on IA M AI and in your browser settings.',
      category: 'Your Control',
      content: {
        introduction: 'You have full control over cookie settings. This article explains how to manage cookies on IA M AI and in your browser.',
        sections: [
          {
            heading: 'IA M AI Cookie Settings',
            paragraphs: [
              'We provide a user-friendly cookie consent banner and settings panel where you can control non-essential cookies.'
            ],
            list: [
              '🍪 Cookie Banner: Appears on first visit',
              '✅ Accept All: Allow all cookies for best experience',
              '🚫 Reject Non-Essential: Only strictly necessary cookies',
              '⚙️ Customize: Choose which categories to allow',
              '🔧 Cookie Settings: Access anytime from footer or account settings',
              '💾 Preferences Saved: Your choices remembered for 12 months',
              '🔄 Update Anytime: Change settings whenever you want',
              '📋 Cookie List: See all cookies we use with descriptions'
            ]
          },
          {
            heading: 'Browser Cookie Controls',
            paragraphs: [
              'All modern browsers provide built-in cookie management tools. Here\'s how to access them in popular browsers:'
            ],
            list: [
              '🌐 Google Chrome: Menu → Settings → Privacy and Security → Cookies and Site Data',
              '🦊 Mozilla Firefox: Menu → Options → Privacy & Security → Cookies and Site Data',
              '🧭 Safari: Safari → Preferences → Privacy → Manage Website Data',
              '🌊 Microsoft Edge: Menu → Settings → Cookies and Site Permissions',
              '🎭 Opera: Menu → Settings → Privacy & Security → Cookies',
              '🦁 Brave: Menu → Settings → Shields → Cookie Control'
            ]
          },
          {
            heading: 'Browser Cookie Options',
            paragraphs: [
              'Most browsers offer several levels of cookie control:'
            ],
            list: [
              '✅ Allow All Cookies: Default setting',
              '🚫 Block All Cookies: May break many websites',
              '🌐 Block Third-Party Cookies: Allow first-party, block third-party',
              '🔒 Private/Incognito Mode: Cookies deleted when browser closes',
              '🗑️ Clear Cookies: Delete existing cookies',
              '⚙️ Per-Site Settings: Allow/block cookies for specific websites',
              '🚫 Do Not Track: Request websites not to track you (advisory only)',
              '⏰ Auto-Delete: Automatically clear cookies on browser close'
            ]
          },
          {
            heading: 'Deleting Cookies',
            paragraphs: [
              'You can delete cookies at any time. Here\'s what happens:'
            ],
            list: [
              '🗑️ Clear All Cookies: Logs you out of all websites',
              '🗂️ Clear Specific Site: Delete only IA M AI cookies',
              '⏰ Clear from Time Range: Delete cookies from specific period',
              '🔄 Effect: You\'ll need to log in again and reconfigure preferences',
              '💾 Caution: Some functionality may not work until you accept cookies',
              '📋 You can re-accept cookies after deletion'
            ]
          },
          {
            heading: 'Mobile Device Cookie Management',
            paragraphs: [
              'Mobile browsers also provide cookie controls:'
            ],
            list: [
              '📱 iOS Safari: Settings → Safari → Block All Cookies',
              '🤖 Android Chrome: Chrome → Settings → Site Settings → Cookies',
              '🍎 iOS Chrome: Chrome → Settings → Content Settings → Block Cookies',
              '📲 Mobile Firefox: Firefox → Settings → Privacy → Cookies',
              '📱 In-App Browsers: May have limited cookie controls',
              '⚙️ App Settings: IA M AI mobile app has in-app cookie preferences'
            ]
          },
          {
            heading: 'Impact of Blocking Cookies',
            paragraphs: [
              'Blocking or deleting cookies affects your experience. Here\'s what to expect:'
            ],
            list: [
              '🔐 Authentication Issues: May be logged out frequently',
              '🎨 Lost Preferences: Theme, language reset to defaults',
              '🚫 Broken Features: Some functionality may not work',
              '📊 No Personalization: Generic experience without customization',
              '🔄 Repeated Consent: Cookie banner appears every visit',
              '💬 Lost State: Shopping carts, forms may lose data',
              '⚠️ Strictly necessary cookies: Cannot be disabled without breaking the site'
            ]
          },
          {
            heading: 'Advanced Privacy Tools',
            paragraphs: [
              'Privacy-focused users can use additional tools for cookie control:'
            ],
            list: [
              '🦡 Browser Extensions: Privacy Badger, uBlock Origin, Ghostery',
              '🌐 Privacy Browsers: Brave, Tor Browser, DuckDuckGo',
              '🔒 VPN Services: Hide IP address (doesn\'t block cookies)',
              '🚫 Anti-Tracking: Built-in tracker blocking in modern browsers',
              '📵 Container Tabs: Firefox Multi-Account Containers',
              '🗑️ Auto-Delete Extensions: Cookie AutoDelete',
              '✅ We respect Do Not Track and Global Privacy Control signals',
              '🛡️ All these tools are compatible with IA M AI'
            ]
          }
        ],
        conclusion: 'You have complete control over cookies through our settings and your browser. Choose the level of privacy that\'s right for you, keeping in mind that blocking cookies may impact functionality.'
      }
    },
    {
      id: 'third-party-cookies',
      title: 'Third-Party Cookies & Services',
      icon: <Globe className="w-6 h-6 text-cyan-400" />,
      excerpt: 'External services that use cookies on our platform and their purposes.',
      category: 'Third-Party',
      content: {
        introduction: 'IA M AI integrates with trusted third-party services that may set cookies to provide functionality. This article details these services and their cookie usage.',
        sections: [
          {
            heading: 'Analytics & Measurement',
            paragraphs: [
              'We use analytics services to understand platform usage and improve the user experience.'
            ],
            list: [
              '📊 Google Analytics: Website traffic and user behavior analysis',
              '📈 Purpose: Understand popular features, user journeys, demographics',
              '🍪 Cookies: _ga, _gat, _gid (up to 2 years)',
              '🔒 Privacy: IP anonymization enabled',
              '🚫 Opt-Out: Google Analytics Opt-out Browser Add-on available',
              '📋 Privacy Policy: https://policies.google.com/privacy',
              '🔗 More Info: https://support.google.com/analytics/answer/6004245'
            ]
          },
          {
            heading: 'Payment Processing',
            paragraphs: [
              'Secure payment processing requires cookies for fraud prevention and transaction security.'
            ],
            list: [
              '💳 Stripe: Payment processing and billing',
              '🛡️ Purpose: Fraud detection, secure checkout, payment method storage',
              '🍪 Cookies: stripe_mid, stripe_sid, __stripe_sid',
              '🔒 Security: PCI DSS Level 1 certified',
              '💰 No Card Storage: We never see full card numbers',
              '📋 Privacy Policy: https://stripe.com/privacy',
              '🌐 Compliance: GDPR compliant with EU-U.S. Data Privacy Framework'
            ]
          },
          {
            heading: 'AI Service Providers',
            paragraphs: [
              'Our AI agents are powered by leading AI providers who may use cookies for service delivery.'
            ],
            list: [
              '🤖 Mistral AI: European AI provider',
              '🤖 OpenAI: GPT-powered agents',
              '🤖 Google Gemini: Advanced AI capabilities',
              '🤖 Anthropic Claude: AI conversation and analysis',
              '🍪 Purpose: Session management, rate limiting, abuse prevention',
              '🔒 Data Minimization: Only necessary data shared',
              '📋 Each has separate privacy policy (linked in Privacy Policy page)',
              '✅ All bound by data processing agreements'
            ]
          },
          {
            heading: 'Communication & Support',
            paragraphs: [
              'Customer support and email services use cookies for functionality.'
            ],
            list: [
              '💬 Support Chat Widget: Real-time customer support',
              '📧 Email Service Provider: Newsletter and transactional emails',
              '🍪 Purpose: Maintain chat sessions, track email opens (with consent)',
              '🔔 Notifications: Web push notification services',
              '📊 Email Analytics: Click tracking, engagement metrics (opt-in)',
              '🚫 Unsubscribe: Available in every marketing email',
              '✅ Privacy-focused providers prioritized'
            ]
          },
          {
            heading: 'Content Delivery & Hosting',
            paragraphs: [
              'Infrastructure providers ensure fast, reliable service delivery.'
            ],
            list: [
              '☁️ AWS CloudFront: Content delivery network (CDN)',
              '🛡️ Cloudflare: DDoS protection and security',
              '🍪 Purpose: Load balancing, geo-routing, security',
              '⚡ Performance: Faster page loads globally',
              '🔒 Security: Protection against attacks',
              '📋 Privacy policies available from providers'
            ]
          },
          {
            heading: 'Social Media & Sharing',
            paragraphs: [
              'Social media cookies enable sharing and may be used for advertising.'
            ],
            list: [
              '📘 Facebook: Social sharing, login, pixel tracking',
              '🐦 Twitter: Tweet embeds, social sharing',
              '💼 LinkedIn: Professional sharing, analytics',
              '🍪 Purpose: Social features, behavioral advertising',
              '🎯 Tracking: May track across websites for ad targeting',
              '🚫 Control: Block third-party cookies or use social blockers',
              '✅ Only loaded if you consent to marketing cookies',
              '📋 Privacy policies: facebook.com/privacy, twitter.com/privacy, linkedin.com/legal/privacy-policy'
            ]
          },
          {
            heading: 'Video & Media Embeds',
            paragraphs: [
              'Embedded content from platforms like YouTube uses cookies.'
            ],
            list: [
              '📹 YouTube: Video embeds and playback',
              '🎬 Vimeo: Alternative video hosting',
              '🍪 Purpose: Video playback, recommendations, analytics',
              '🎯 Advertising: May show ads based on viewing history',
              '🔒 Privacy-Enhanced Mode: We use youtube-nocookie.com where possible',
              '🚫 Control: Block or delete third-party cookies',
              '📋 Privacy: youtube.com/privacy, vimeo.com/privacy'
            ]
          }
        ],
        conclusion: 'We carefully vet all third-party services and require them to comply with privacy standards. You can control third-party cookies through our settings or browser controls.'
      }
    },
    {
      id: 'cookie-duration',
      title: 'Cookie Duration & Retention',
      icon: <Clock className="w-6 h-6 text-cyan-400" />,
      excerpt: 'How long different cookies last and when they are deleted.',
      category: 'Technical',
      content: {
        introduction: 'Cookies have varying lifespans depending on their purpose. This article explains retention periods for different types of cookies we use.',
        sections: [
          {
            heading: 'Session Cookies',
            paragraphs: [
              'Session cookies are temporary and automatically deleted when you close your browser.'
            ],
            list: [
              '🕐 Lifespan: Until browser window/tab closes',
              '🔐 Purpose: Authentication, shopping cart, form data',
              '🗑️ Deletion: Automatic upon browser close',
              '💾 Storage: Memory only (not written to disk)',
              '✅ Examples: session_id, csrf_token, temp_cart',
              '🔄 Created: Fresh cookie on each browser session',
              '🚫 No Persistent Tracking: Clean slate each visit'
            ]
          },
          {
            heading: 'Short-Term Cookies (24 hours - 30 days)',
            paragraphs: [
              'Short-term cookies provide convenience while minimizing long-term tracking.'
            ],
            list: [
              '⏰ Lifespan: 1-30 days',
              '🎯 Purpose: Remember me, recent searches, preferences',
              '🔐 Security: Short-lived auth tokens',
              '📊 Analytics: Recent visitor identification',
              '✅ Examples: remember_me (14 days), recent_agents (7 days)',
              '🗑️ Auto-Delete: Expires after inactivity period',
              '🔄 Renewable: Extended with each visit'
            ]
          },
          {
            heading: 'Medium-Term Cookies (1-12 months)',
            paragraphs: [
              'Medium-term cookies balance functionality with privacy considerations.'
            ],
            list: [
              '⏰ Lifespan: 30 days - 12 months',
              '🎨 Purpose: Theme, language, layout preferences',
              '🍪 Cookie Consent: Remember your choices (12 months)',
              '📊 Analytics: Unique visitor tracking (13 months max per GDPR)',
              '✅ Examples: theme_preference (6 months), cookie_consent (12 months)',
              '🗑️ Renewal: Extended with each interaction',
              '🔒 GDPR Compliance: 13-month maximum for analytics'
            ]
          },
          {
            heading: 'Long-Term Cookies (1-2 years)',
            paragraphs: [
              'Long-term cookies are used sparingly and only when necessary for functionality or analytics.'
            ],
            list: [
              '⏰ Lifespan: 12-24 months',
              '📊 Purpose: Long-term analytics, campaign attribution',
              '🎯 Marketing: Conversion tracking, user journey analysis',
              '✅ Examples: _ga (Google Analytics, 2 years)',
              '🚫 Require Consent: Must opt-in for long-term tracking cookies',
              '🗑️ Can Delete: Clear anytime in browser or our settings',
              '📋 GDPR Requirement: Explicit consent needed'
            ]
          },
          {
            heading: 'Persistent Cookie Management',
            paragraphs: [
              'How we manage persistent cookies to respect your privacy:'
            ],
            list: [
              '🔄 Automatic Cleanup: Expired cookies deleted daily',
              '📅 Expiration Dates: All cookies have clear expiry',
              '🗑️ User Deletion: Respect immediate deletion requests',
              '🔒 Secure Flag: HTTPS-only cookies when possible',
              '🚫 HttpOnly: Prevent JavaScript access where appropriate',
              '🎯 SameSite: CSRF protection attributes',
              '📊 Audit Trail: Log cookie creation and deletion',
              '🔍 Regular Review: Assess cookie necessity quarterly'
            ]
          },
          {
            heading: 'Cookie Retention by Category',
            paragraphs: [
              'Summary of retention periods by cookie category:'
            ],
            list: [
              '🔐 Strictly Necessary: Session to 30 days',
              '🎨 Functional: 30 days to 12 months',
              '📊 Analytics: Up to 26 months (anonymized after 14)',
              '🎯 Marketing: 30 days to 13 months (with consent)',
              '🌐 Third-Party: Varies (see Third-Party section)',
              '🍪 Consent: 12 months (then re-prompt)',
              '⚡ Performance: Session to 90 days',
              '🛡️ Security: Session to 30 days'
            ]
          },
          {
            heading: 'Your Control Over Retention',
            paragraphs: [
              'You can control how long cookies are stored:'
            ],
            list: [
              '🗑️ Delete Anytime: Browser settings or our cookie manager',
              '🚫 Block Persistent: Allow only session cookies in browser',
              '⏰ Auto-Delete: Browser extensions for automatic cleanup',
              '🔄 Regular Clearing: Set browser to clear on close',
              '🍪 Selective Deletion: Delete specific cookie categories',
              '📋 Export Data: Request data including cookie history',
              '✅ Re-consent: Cookie banner reappears after consent expiry'
            ]
          }
        ],
        conclusion: 'Cookie duration is carefully managed to balance functionality with privacy. Short-term cookies provide convenience, while long-term cookies require your consent and can be deleted anytime.'
      }
    },
    {
      id: 'cookie-security',
      title: 'Cookie Security & Privacy',
      icon: <Lock className="w-6 h-6 text-cyan-400" />,
      excerpt: 'Security measures we implement to protect cookie data and your privacy.',
      category: 'Security',
      content: {
        introduction: 'Cookies can present security and privacy risks if not properly secured. IA M AI implements industry best practices to protect cookie data and your privacy.',
        sections: [
          {
            heading: 'Cookie Security Attributes',
            paragraphs: [
              'We use advanced cookie attributes to prevent unauthorized access and attacks.'
            ],
            list: [
              '🔒 Secure Flag: Cookies only transmitted over HTTPS',
              '🚫 HttpOnly: Prevents JavaScript access (XSS protection)',
              '🛡️ SameSite: CSRF protection (Strict or Lax)',
              '⏰ Short Expiration: Minimize exposure window for sensitive cookies',
              '🔐 Domain Scoping: Cookies limited to iamai.global',
              '📍 Path Restrictions: Cookies only sent to specific paths',
              '✅ TLS 1.3: Latest encryption for cookie transmission',
              '🗝️ Strong Tokens: Cryptographically secure random values'
            ]
          },
          {
            heading: 'Protection Against Common Attacks',
            paragraphs: [
              'Our cookie implementation defends against well-known security threats.'
            ],
            list: [
              '🛡️ Cross-Site Scripting (XSS): HttpOnly flag prevents script access',
              '🚫 Cross-Site Request Forgery (CSRF): SameSite attribute and tokens',
              '👤 Session Hijacking: Secure flag + short sessions + IP validation',
              '🔐 Cookie Theft: Encryption and secure transmission',
              '⏰ Session Fixation: New session ID on authentication',
              '🕵️ Man-in-the-Middle: HTTPS enforced, HSTS enabled',
              '🔄 Replay Attacks: Nonce values and timestamps',
              '📊 Cookie Tossing: Domain and path scoping'
            ]
          },
          {
            heading: 'Data Minimization',
            paragraphs: [
              'We only store necessary information in cookies to minimize privacy risks.'
            ],
            list: [
              '🔑 Session IDs: Only opaque tokens, not personal data',
              '🚫 No Sensitive Data: Never store passwords, credit cards in cookies',
              '📊 Minimal Identifiers: Pseudonymous IDs where possible',
              '🔒 Server-Side Storage: Actual data stored securely on server',
              '✅ Cookie as Key: Cookie references server-side session data',
              '🗑️ Regular Cleanup: Expired sessions and cookies deleted',
              '📉 Small Size: Cookies kept under 1KB when possible'
            ]
          },
          {
            heading: 'Encryption & Hashing',
            paragraphs: [
              'Sensitive cookie values are encrypted or hashed for additional protection.'
            ],
            list: [
              '🔐 Transport Encryption: TLS 1.3 for all transmissions',
              '🔑 Token Encryption: AES-256 encryption for sensitive tokens',
              '🗝️ Signed Cookies: HMAC signatures prevent tampering',
              '🔒 Hashed IDs: SHA-256 hashing for user identifiers',
              '🛡️ Key Rotation: Encryption keys rotated regularly',
              '✅ Perfect Forward Secrecy: TLS configuration protects past sessions',
              '🚫 No Reversible Data: One-way hashing where appropriate'
            ]
          },
          {
            heading: 'Privacy by Design',
            paragraphs: [
              'Cookie privacy is built into our systems from the ground up.'
            ],
            list: [
              '🎯 Purpose Limitation: Cookies used only for stated purposes',
              '⏰ Storage Limitation: Automatic expiration and deletion',
              '🔒 Access Control: Strict controls on who can access cookie data',
              '📋 Audit Logs: All cookie-related actions logged',
              '🔍 Privacy Reviews: Regular assessments of cookie usage',
              '✅ Transparency: Clear cookie list and purposes',
              '🚫 No Repurposing: Cookies not used for undisclosed purposes',
              '📊 Minimal Tracking: Only essential user identification'
            ]
          },
          {
            heading: 'User Control & Transparency',
            paragraphs: [
              'We give you full visibility and control over cookie security.'
            ],
            list: [
              '🍪 Cookie Manager: See all active cookies',
              '📋 Cookie Details: Name, purpose, expiration, domain',
              '🗑️ Delete Individual: Remove specific cookies',
              '🚫 Block Categories: Disable cookie types',
              '🔔 Breach Notification: Alert if cookie data compromised',
              '🔐 2FA Option: Extra security layer for accounts',
              '✅ Regular Updates: Security improvements deployed continuously',
              '📧 Contact: security@iamai.global for concerns'
            ]
          }
        ],
        conclusion: 'Cookie security is paramount. We implement multiple layers of protection to ensure cookie data remains secure and your privacy is respected. Report any security concerns immediately.'
      }
    },
    {
      id: 'do-not-track',
      title: 'Do Not Track & Global Privacy Control',
      icon: <Ban className="w-6 h-6 text-cyan-400" />,
      excerpt: 'How we respond to privacy signals like Do Not Track and Global Privacy Control.',
      category: 'Your Control',
      content: {
        introduction: 'Modern browsers support privacy signals that allow you to indicate your tracking preferences. This article explains how IA M AI responds to these signals.',
        sections: [
          {
            heading: 'What is Do Not Track (DNT)?',
            paragraphs: [
              'Do Not Track is a browser setting that sends a signal to websites requesting that they not track your browsing activity. While there\'s no legal requirement to honor DNT, we respect user privacy preferences.'
            ],
            list: [
              '📡 Browser Setting: Enable in privacy preferences',
              '🚦 HTTP Header: DNT: 1 sent with requests',
              '❓ Advisory Only: No legal enforcement',
              '🌐 Browser Support: All major browsers',
              '📊 Not Universally Honored: Many sites ignore DNT',
              '✅ IA M AI: We honor DNT for non-essential cookies',
              '🔐 Note: Strictly necessary cookies still required'
            ]
          },
          {
            heading: 'Global Privacy Control (GPC)',
            paragraphs: [
              'Global Privacy Control is a newer, legally binding privacy signal under laws like CCPA and GDPR. It communicates your opt-out preferences to websites.'
            ],
            list: [
              '⚖️ Legally Binding: Must be honored under CCPA, GDPR',
              '🌍 Growing Adoption: Newer standard with strong backing',
              '🔧 Implementation: Browser extensions and privacy browsers',
              '📡 Signal: Sec-GPC: 1 HTTP header',
              '✅ IA M AI: Full GPC compliance',
              '🚫 Effect: Opts you out of data selling and non-essential tracking',
              '🔐 Strictly Necessary: Still functional for platform operation'
            ]
          },
          {
            heading: 'How IA M AI Honors Privacy Signals',
            paragraphs: [
              'When we detect DNT or GPC signals, we automatically adjust your privacy settings.'
            ],
            list: [
              '🚫 Marketing Cookies: Automatically blocked',
              '📊 Analytics: Only essential, no behavioral tracking',
              '🎯 No Profiling: Personalized ads disabled',
              '🍪 Functional Cookies: Still allowed (with option to disable)',
              '🔐 Necessary Cookies: Required for platform operation',
              '⚙️ Override: You can still manually enable categories in settings',
              '📋 Honored Immediately: No consent banner needed',
              '✅ Status Indicator: Privacy settings show signal detected'
            ]
          },
          {
            heading: 'How to Enable Privacy Signals',
            paragraphs: [
              'Enable Do Not Track or Global Privacy Control in your browser or via extensions.'
            ],
            list: [
              '🌐 Chrome: Settings → Privacy → Send Do Not Track',
              '🦊 Firefox: Preferences → Privacy → Tell websites not to track',
              '🧭 Safari: Preferences → Privacy → Ask websites not to track',
              '🌊 Edge: Settings → Privacy → Send Do Not Track',
              '🔌 GPC Extension: Install OptMeowt or Privacy Badger',
              '🦁 Brave: Built-in GPC support',
              '🎭 DuckDuckGo: Automatic GPC in mobile app',
              '✅ Verify: Use privacy testing tools to confirm signals'
            ]
          },
          {
            heading: 'Limitations of Privacy Signals',
            paragraphs: [
              'While we respect privacy signals, there are practical limitations to be aware of.'
            ],
            list: [
              '🔐 Necessary Cookies: Cannot be disabled without breaking functionality',
              '🌍 Third-Party Respect: Not all partners honor signals',
              '📊 Aggregate Data: Anonymous analytics may still be collected',
              '⚖️ Legal Requirements: Some data processing legally required',
              '🎯 Context Loss: May reduce personalization and convenience',
              '🔄 Manual Override: You can enable features individually',
              '🚫 Not Comprehensive: Signals don\'t cover all privacy aspects',
              '✅ Supplement: Use with other privacy tools for best protection'
            ]
          },
          {
            heading: 'Other Privacy Settings',
            paragraphs: [
              'Privacy signals complement other privacy controls available to you.'
            ],
            list: [
              '🍪 Cookie Manager: Granular control over specific cookies',
              '🚫 Opt-Out Links: Individual service opt-outs',
              '📧 Email Unsubscribe: Marketing communication controls',
              '🔐 Account Privacy: In-app privacy settings',
              '🗑️ Data Deletion: Right to erasure under GDPR',
              '📋 Data Export: Download your data',
              '⚙️ Preference Center: Centralized privacy dashboard',
              '📧 Contact DPO: privacy@iamai.global for assistance'
            ]
          },
          {
            heading: 'Our Privacy Commitment',
            paragraphs: [
              'Beyond legal requirements, we are committed to respecting your privacy choices.'
            ],
            list: [
              '✅ Default Respect: Honor privacy signals out of the box',
              '🔐 Minimal Collection: Only necessary data collected',
              '🚫 No Dark Patterns: No tricks to override your choices',
              '📋 Clear Communication: Transparent about data practices',
              '🔍 Regular Audits: Verify compliance with privacy signals',
              '🤝 Good Faith: Interpret ambiguous situations in your favor',
              '📧 Accessible Support: Easy to contact with privacy concerns',
              '🌍 Leading by Example: Advocate for stronger privacy standards'
            ]
          }
        ],
        conclusion: 'IA M AI fully respects Do Not Track and Global Privacy Control signals. When we detect these signals, we automatically adjust your privacy settings to honor your preferences while maintaining essential functionality.'
      }
    }
  ];

  const categories = ['all', 'Basics', 'Our Usage', 'Your Control', 'Third-Party', 'Technical', 'Security'];

  const filteredArticles = activeCategory === 'all' 
    ? articles 
    : articles.filter(article => article.category === activeCategory);

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <header className="border-b border-gray-800 bg-[#0a0a0a] sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <button
              onClick={() => onNavigate('home')}
              className="flex items-center gap-2 text-cyan-400 hover:text-cyan-300 transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
              <span className="text-sm">Back to Home</span>
            </button>
            <h1 className="text-2xl md:text-3xl font-bold text-white">
              Cookie Policy
            </h1>
            <div className="w-20"></div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-12">
        <div className="max-w-7xl mx-auto">
          {/* Introduction */}
          <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-8 mb-8">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-3 bg-cyan-900/50 border border-cyan-500/30 rounded-xl">
                <Cookie className="w-8 h-8 text-cyan-400" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-white">Cookie Policy</h2>
                <p className="text-gray-500">Last updated: November 2025</p>
              </div>
            </div>
            <p className="text-gray-400 leading-relaxed mb-4">
              This <span className="text-cyan-400 font-semibold">Cookie Policy</span> explains what cookies are, how IA M AI uses them, and how you can control your cookie preferences. 
              Cookies help us provide a better, faster, and more secure experience on our platform.
            </p>
            <p className="text-gray-500 text-sm">
              By using IA M AI, you consent to our use of strictly necessary cookies. For non-essential cookies, you can customize your preferences in our cookie settings.
            </p>
          </div>

          {/* Category Filters */}
          <div className="mb-8">
            <h3 className="text-lg font-semibold mb-4 text-white">Browse by Category</h3>
            <div className="flex flex-wrap gap-2">
              {categories.map((category) => (
                <button
                  key={category}
                  onClick={() => setActiveCategory(category)}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                    activeCategory === category
                      ? 'bg-cyan-500 text-black shadow-lg'
                      : 'bg-gray-900/50 text-gray-400 hover:bg-gray-800 border border-gray-800 hover:text-cyan-400'
                  }`}
                >
                  {category === 'all' ? '📋 All Articles' : category}
                </button>
              ))}
            </div>
          </div>

          {/* Article Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            {filteredArticles.map((article) => (
              <div
                key={article.id}
                className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6 hover:border-cyan-500/50 transition-all cursor-pointer group"
                onClick={() => setSelectedArticle(article)}
              >
                <div className="flex items-start gap-4 mb-4">
                  <div className="p-3 bg-cyan-900/50 border border-cyan-500/30 rounded-xl group-hover:bg-cyan-500/20 transition-colors">
                    {article.icon}
                  </div>
                  <div className="flex-1">
                    <h3 className="text-lg font-bold text-white group-hover:text-cyan-400 transition-colors mb-1">
                      {article.title}
                    </h3>
                    <span className="inline-block px-2 py-1 bg-gray-800 text-cyan-400 text-xs rounded-full">
                      {article.category}
                    </span>
                  </div>
                </div>
                <p className="text-gray-400 text-sm mb-4 line-clamp-3">
                  {article.excerpt}
                </p>
                <div className="flex items-center gap-2 text-cyan-400 text-sm font-medium group-hover:text-cyan-300 transition-colors">
                  <BookOpen className="w-4 h-4" />
                  <span>Read Full Article</span>
                  <ExternalLink className="w-3 h-3 ml-auto" />
                </div>
              </div>
            ))}
          </div>

          {/* Contact Information */}
          <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-8">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-3 bg-cyan-900/50 border border-cyan-500/30 rounded-xl">
                <AlertCircle className="w-6 h-6 text-cyan-400" />
              </div>
              <h2 className="text-2xl font-bold text-white">Questions About Cookies?</h2>
            </div>
            <p className="text-gray-400 mb-4">
              If you have questions about our cookie usage or need help managing your preferences, contact us:
            </p>
            <div className="space-y-2 text-gray-400">
              <p><span className="text-cyan-400 font-semibold">Privacy Team:</span> privacy@iamai.global</p>
              <p><span className="text-cyan-400 font-semibold">Cookie Settings:</span> Available in footer and account settings</p>
              <p><span className="text-cyan-400 font-semibold">General Inquiries:</span> contact@iamai.global</p>
            </div>
          </div>
        </div>
      </main>

      {/* Article Modal */}
      {selectedArticle && (
        <div 
          className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4 animate-fadeIn"
          onClick={() => setSelectedArticle(null)}
        >
          <div 
            className="bg-[#0a0a0a] border border-gray-800 rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="sticky top-0 bg-[#0a0a0a] border-b border-gray-800 p-6 flex items-start justify-between z-10">
              <div className="flex items-start gap-4 flex-1">
                <div className="p-3 bg-cyan-900/50 border border-cyan-500/30 rounded-xl flex-shrink-0">
                  {selectedArticle.icon}
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-white mb-2">{selectedArticle.title}</h2>
                  <span className="inline-block px-3 py-1 bg-gray-800 text-cyan-400 text-sm rounded-full">
                    {selectedArticle.category}
                  </span>
                </div>
              </div>
              <button
                onClick={() => setSelectedArticle(null)}
                className="p-2 hover:bg-gray-800 rounded-lg transition-colors flex-shrink-0"
              >
                <X className="w-6 h-6 text-gray-400 hover:text-white" />
              </button>
            </div>

            {/* Modal Content - Scrollable */}
            <div className="overflow-y-auto max-h-[calc(90vh-140px)] p-6 space-y-6">
              {/* Introduction */}
              {selectedArticle.content.introduction && (
                <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-6">
                  <p className="text-gray-400 leading-relaxed">{selectedArticle.content.introduction}</p>
                </div>
              )}

              {/* Sections */}
              {selectedArticle.content.sections.map((section, index) => (
                <div key={index} className="space-y-4">
                  <h3 className="text-xl font-bold text-white flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-cyan-900/50 border border-cyan-500/30 flex items-center justify-center text-cyan-400 text-sm font-bold">
                      {index + 1}
                    </div>
                    {section.heading}
                  </h3>
                  
                  {section.paragraphs.map((paragraph, pIndex) => (
                    <p key={pIndex} className="text-gray-400 leading-relaxed pl-10">
                      {paragraph}
                    </p>
                  ))}

                  {section.list && section.list.length > 0 && (
                    <ul className="space-y-2 pl-10">
                      {section.list.map((item, itemIndex) => (
                        <li key={itemIndex} className="flex items-start gap-3">
                          <CheckCircle className="w-5 h-5 text-cyan-400 flex-shrink-0 mt-0.5" />
                          <span className="text-gray-400 text-sm">{item}</span>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              ))}

              {/* Conclusion */}
              {selectedArticle.content.conclusion && (
                <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-6 mt-8">
                  <div className="flex items-start gap-3">
                    <AlertCircle className="w-6 h-6 text-cyan-400 flex-shrink-0 mt-1" />
                    <p className="text-gray-400 leading-relaxed font-medium">{selectedArticle.content.conclusion}</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CookiesPage;
