import React from 'react';

interface ConsentBannerProps {
  onConsent: (consent: 'accepted' | 'declined') => void;
}

const ConsentBanner: React.FC<ConsentBannerProps> = ({ onConsent }) => {
  return (
    <div className="fixed bottom-0 left-0 right-0 bg-gray-900/80 backdrop-blur-sm border-t border-gray-800 z-50 animate-slideInUp">
      <div className="container mx-auto px-6 py-4">
        <div className="md:flex items-center justify-between">
          <p className="text-gray-300 text-sm mb-4 md:mb-0 md:mr-6">
            We use cookies to enhance your experience, analyze site traffic, and personalize content. By clicking "Accept", you agree to our use of cookies.
          </p>
          <div className="flex items-center space-x-4 flex-shrink-0">
            <button
              onClick={() => onConsent('declined')}
              title="Decline the use of non-essential cookies"
              className="px-5 py-2 text-sm text-gray-300 border border-gray-600 rounded-full hover:bg-gray-800 transition-colors duration-300"
            >
              Decline
            </button>
            <button
              onClick={() => onConsent('accepted')}
              title="Accept the use of cookies"
              className="px-5 py-2 text-sm bg-cyan-500 text-black font-semibold rounded-full hover:bg-cyan-400 transition-colors duration-300"
            >
              Accept
            </button>
          </div>
        </div>
      </div>
       <style>{`
            @keyframes slideInUp {
                from { transform: translateY(100%); }
                to { transform: translateY(0); }
            }
            .animate-slideInUp { animation: slideInUp 0.5s ease-out forwards; }
        `}</style>
    </div>
  );
};

export default ConsentBanner;