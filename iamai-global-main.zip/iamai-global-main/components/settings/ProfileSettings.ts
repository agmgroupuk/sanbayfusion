export interface UserProfile {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  bio?: string;
  preferences: UserPreferences;
  createdAt: Date;
  lastActive: Date;
}

export interface UserPreferences {
  theme: 'light' | 'dark' | 'system';
  language: string;
  timezone: string;
  notifications: NotificationSettings;
  privacy: PrivacySettings;
}

export interface NotificationSettings {
  email: boolean;
  push: boolean;
  desktop: boolean;
  sound: boolean;
}

export interface PrivacySettings {
  profileVisibility: 'public' | 'private';
  shareUsageData: boolean;
  allowAnalytics: boolean;
}

export interface ProfileSettingsState {
  profile: UserProfile;
  isLoading: boolean;
  isSaving: boolean;
  errors: Record<string, string>;
  hasChanges: boolean;
  avatarUpload: {
    isUploading: boolean;
    preview?: string;
  };
}

export class ProfileSettingsService {
  private listeners: Set<(state: ProfileSettingsState) => void> = new Set();
  private state: ProfileSettingsState;
  private originalProfile: UserProfile;

  constructor(initialProfile: UserProfile) {
    this.originalProfile = { ...initialProfile };
    this.state = {
      profile: { ...initialProfile },
      isLoading: false,
      isSaving: false,
      errors: {},
      hasChanges: false,
      avatarUpload: {
        isUploading: false,
      },
    };
  }

  updateProfile(updates: Partial<UserProfile>): void {
    const newProfile = { ...this.state.profile, ...updates };
    const hasChanges = this.detectChanges(newProfile, this.originalProfile);

    this.updateState({
      ...this.state,
      profile: newProfile,
      hasChanges,
      errors: {}, // Clear errors when making changes
    });
  }

  updatePreferences(updates: Partial<UserPreferences>): void {
    const newPreferences = { ...this.state.profile.preferences, ...updates };
    this.updateProfile({ preferences: newPreferences });
  }

  updateNotificationSettings(updates: Partial<NotificationSettings>): void {
    const newSettings = { ...this.state.profile.preferences.notifications, ...updates };
    this.updatePreferences({ notifications: newSettings });
  }

  updatePrivacySettings(updates: Partial<PrivacySettings>): void {
    const newSettings = { ...this.state.profile.preferences.privacy, ...updates };
    this.updatePreferences({ privacy: newSettings });
  }

  private detectChanges(current: UserProfile, original: UserProfile): boolean {
    return JSON.stringify(current) !== JSON.stringify(original);
  }

  validateProfile(): boolean {
    const errors: Record<string, string> = {};

    // Name validation
    if (!this.state.profile.name?.trim()) {
      errors.name = 'Name is required';
    } else if (this.state.profile.name.length < 2) {
      errors.name = 'Name must be at least 2 characters';
    }

    // Email validation
    if (!this.state.profile.email?.trim()) {
      errors.email = 'Email is required';
    } else if (!this.isValidEmail(this.state.profile.email)) {
      errors.email = 'Please enter a valid email address';
    }

    // Bio validation (optional but limit length)
    if (this.state.profile.bio && this.state.profile.bio.length > 500) {
      errors.bio = 'Bio must be less than 500 characters';
    }

    this.updateState({ ...this.state, errors });
    return Object.keys(errors).length === 0;
  }

  private isValidEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  async uploadAvatar(file: File): Promise<{ success: boolean; url?: string; error?: string }> {
    if (!this.validateAvatarFile(file)) {
      return { success: false, error: 'Invalid file type or size' };
    }

    this.updateState({
      ...this.state,
      avatarUpload: {
        isUploading: true,
        preview: URL.createObjectURL(file),
      },
    });

    try {
      const result = await this.performAvatarUpload(file);

      if (result.success && result.url) {
        this.updateProfile({ avatar: result.url });
        this.updateState({
          ...this.state,
          avatarUpload: { isUploading: false },
        });
      } else {
        this.updateState({
          ...this.state,
          avatarUpload: { isUploading: false },
          errors: { avatar: result.error || 'Upload failed' },
        });
      }

      return result;
    } catch (error) {
      console.error('Avatar upload failed:', error);
      this.updateState({
        ...this.state,
        avatarUpload: { isUploading: false },
        errors: { avatar: 'Upload failed' },
      });
      return { success: false, error: 'Upload failed' };
    }
  }

  private validateAvatarFile(file: File): boolean {
    const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    const maxSize = 5 * 1024 * 1024; // 5MB

    return allowedTypes.includes(file.type) && file.size <= maxSize;
  }

  private async performAvatarUpload(
    file: File
  ): Promise<{ success: boolean; url?: string; error?: string }> {
    // Mock upload - replace with actual upload service
    return new Promise(resolve => {
      setTimeout(() => {
        // Simulate successful upload
        const mockUrl = `https://example.com/avatars/${Date.now()}_${file.name}`;
        resolve({ success: true, url: mockUrl });
      }, 2000);
    });
  }

  removeAvatar(): void {
    this.updateProfile({ avatar: undefined });
  }

  async saveProfile(): Promise<{ success: boolean; error?: string }> {
    if (!this.validateProfile()) {
      return { success: false, error: 'Please fix the form errors' };
    }

    this.updateState({ ...this.state, isSaving: true });

    try {
      const result = await this.performProfileSave(this.state.profile);

      if (result.success) {
        this.originalProfile = { ...this.state.profile };
        this.updateState({
          ...this.state,
          isSaving: false,
          hasChanges: false,
        });
      } else {
        this.updateState({
          ...this.state,
          isSaving: false,
          errors: { general: result.error || 'Save failed' },
        });
      }

      return result;
    } catch (error) {
      console.error('Profile save failed:', error);
      this.updateState({
        ...this.state,
        isSaving: false,
        errors: { general: 'Save failed' },
      });
      return { success: false, error: 'Save failed' };
    }
  }

  private async performProfileSave(
    profile: UserProfile
  ): Promise<{ success: boolean; error?: string }> {
    // Mock save - replace with actual API call
    return new Promise(resolve => {
      setTimeout(() => {
        resolve({ success: true });
      }, 1500);
    });
  }

  resetChanges(): void {
    this.updateState({
      ...this.state,
      profile: { ...this.originalProfile },
      hasChanges: false,
      errors: {},
    });
  }

  exportData(): string {
    const exportData = {
      profile: this.state.profile,
      exportedAt: new Date().toISOString(),
    };
    return JSON.stringify(exportData, null, 2);
  }

  async deleteAccount(): Promise<{ success: boolean; error?: string }> {
    // This would typically require additional confirmation
    try {
      const result = await this.performAccountDeletion();
      return result;
    } catch (error) {
      console.error('Account deletion failed:', error);
      return { success: false, error: 'Account deletion failed' };
    }
  }

  private async performAccountDeletion(): Promise<{ success: boolean; error?: string }> {
    // Mock deletion - replace with actual API call
    return new Promise(resolve => {
      setTimeout(() => {
        resolve({ success: true });
      }, 2000);
    });
  }

  getFormattedProfile(): Record<string, string> {
    const profile = this.state.profile;
    return {
      name: profile.name || '',
      email: profile.email || '',
      bio: profile.bio || '',
      memberSince: profile.createdAt.toLocaleDateString(),
      lastActive: profile.lastActive.toLocaleDateString(),
    };
  }

  getState(): ProfileSettingsState {
    return { ...this.state };
  }

  subscribe(listener: (state: ProfileSettingsState) => void): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private updateState(newState: ProfileSettingsState): void {
    this.state = newState;
    this.listeners.forEach(listener => listener(this.state));
  }

  destroy(): void {
    this.listeners.clear();
  }
}
