import React from 'react';
import { ALL_AGENTS } from '../agents';
import { Agent } from '../constants';
import type { Page } from '../App';

interface AgentCardProps {
  agent: Agent;
  onNavigate: (page: Page) => void;
  onSelectAgentForSubscription?: (agent: Agent) => void;
  isLoggedIn?: boolean;
}

// Map agent IDs to their dedicated page routes
const getAgentPageRoute = (agentId: string): Page => {
  const agentRoutes: Record<string, Page> = {
    'ai-girlfriend': 'ai-girlfriend',
    'emo-ai': 'emo-ai',
    'pdf-mind': 'pdf-mind',
    'chat-revive': 'chat-revive',
    'tok-boost': 'tok-boost',
    'you-gen': 'you-gen',
    'agent-x': 'agent-x',
    'auto-chat': 'auto-chat',
    'cv-smash': 'cv-smash',
    'comedian': 'comedian',
    'lazy': 'lazy',
    'flirt': 'flirt',
    'sassy': 'sassy',
    'nerd': 'nerd',
    'cool': 'cool',
    'zen': 'zen',
    'gamer': 'gamer',
  };
  return agentRoutes[agentId] || 'home';
};

const AgentCard: React.FC<AgentCardProps> = ({ agent, onNavigate, onSelectAgentForSubscription, isLoggedIn }) => {
  const handleGetStarted = () => {
    // Use the proper handler which checks authentication
    if (onSelectAgentForSubscription) {
      onSelectAgentForSubscription(agent);
    } else {
      // Fallback to direct navigation (shouldn't happen)
      window.location.href = `/subscribe?agent=${agent.id}`;
    }
  };

  return (
    <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6 flex flex-col items-start space-y-4 hover:border-cyan-500/50 hover:bg-gray-900 transition-all duration-300 transform hover:-translate-y-1">
      <div className="w-12 h-12 flex items-center justify-center rounded-lg bg-gray-800 text-cyan-400">
        {agent.icon && agent.icon.startsWith('data:image') ? (
          <img src={agent.icon} alt={`${agent.name} icon`} className="w-full h-full object-cover rounded-lg" />
        ) : (
          <i className={`${agent.icon} text-3xl`}></i>
        )}
      </div>
      <h3 className="text-xl font-bold text-white">{agent.name}</h3>
      <p className="text-cyan-400 text-sm font-medium">{agent.role}</p>
      <p className="text-gray-400 flex-grow">{agent.description}</p>
      <button 
        onClick={handleGetStarted} 
        title={`Subscribe to ${agent.name}`} 
        className="mt-auto px-4 py-2 bg-cyan-600 hover:bg-cyan-700 text-white font-semibold rounded-lg transition-colors"
      >
        Subscribe Now
      </button>
    </div>
  );
};

interface AgentsSectionProps {
  onNavigate: (page: Page) => void;
  onSelectAgentForSubscription?: (agent: Agent) => void;
  isLoggedIn?: boolean;
}

const AgentsSection: React.FC<AgentsSectionProps> = ({ onNavigate, onSelectAgentForSubscription, isLoggedIn }) => {
  // Display only the first 6 agents on homepage
  const displayedAgents = ALL_AGENTS.slice(0, 6);
  
  return (
    <section id="agents" className="py-20 md:py-28 bg-[#0a0a0a]">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-white">A Character for Every Task</h2>
          <p className="max-w-2xl mx-auto mt-4 text-gray-400">
            Our agents are more than just tools; they are specialized personas designed to excel in their unique domains.
          </p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {displayedAgents.map((agent) => (
            <AgentCard key={agent.id} agent={agent} onNavigate={onNavigate} onSelectAgentForSubscription={onSelectAgentForSubscription} isLoggedIn={isLoggedIn} />
          ))}
        </div>
        
        {/* View All Agents Button */}
        <div className="flex justify-center mt-12">
          <button
            onClick={() => onNavigate('agents')}
            className="group relative px-8 py-4 bg-gradient-to-r from-cyan-500 to-blue-500 text-white font-semibold rounded-xl overflow-hidden transition-all duration-300 hover:shadow-2xl hover:shadow-cyan-500/50 hover:scale-105"
          >
            <span className="relative z-10 flex items-center gap-2">
              Explore All {ALL_AGENTS.length} Agents
              <svg 
                className="w-5 h-5 transition-transform group-hover:translate-x-1" 
                fill="none" 
                stroke="currentColor" 
                viewBox="0 0 24 24"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
              </svg>
            </span>
            <div className="absolute inset-0 bg-gradient-to-r from-blue-500 to-cyan-500 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
          </button>
        </div>
      </div>
    </section>
  );
};

export default AgentsSection;