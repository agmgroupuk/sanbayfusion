import React from 'react';
import HeroSection from './HeroSection';
import AgentsSection from './AgentsSection.tsx';
import FeaturesSection from './FeaturesSection.tsx';
import HowItWorksSection from './HowItWorksSection';
import SolutionsSection from './SolutionsSection';
import TestimonialsSection from './TestimonialsSection';
import CallToActionSection from './CallToActionSection';
import PricingSection from './PricingSection';
import { Agent, BlogPost } from '../constants';
import DeveloperToolsSection from './homepage/DeveloperToolsSection';
import TerminalSection from './homepage/TerminalSection';
import StatsSection from './homepage/StatsSection';
import TemplatesSection from './homepage/TemplatesSection';
import NewsSection from './homepage/NewsSection';
import FAQSection from './homepage/FAQSection';
import FeaturedAgentSection from './homepage/FeaturedAgentSection';
import CanvasSection from './homepage/CanvasSection';
import DatabasePopulateSection from './homepage/DatabasePopulateSection';
import type { Page } from '../App';

interface HomePageProps {
  onSelectAgentForSubscription: (agent: Agent) => void;
  onNavigate: (page: Page) => void;
  onSelectBlogPost: (post: BlogPost) => void;
  isLoggedIn?: boolean;
}

const HomePage: React.FC<HomePageProps> = ({
  onSelectAgentForSubscription,
  onNavigate,
  onSelectBlogPost,
  isLoggedIn = false,
}) => {
  return (
    <>
      <HeroSection onNavigate={onNavigate} />
      <DeveloperToolsSection />
      <AgentsSection
        onNavigate={onNavigate}
        onSelectAgentForSubscription={onSelectAgentForSubscription}
        isLoggedIn={isLoggedIn}
      />
      <FeaturedAgentSection onNavigate={onNavigate} />
      <CanvasSection onNavigate={onNavigate} />
      <DatabasePopulateSection onNavigate={onNavigate} />
      <TerminalSection />
      <FeaturesSection />
      <StatsSection />
      <TemplatesSection onNavigate={onNavigate} />
      <HowItWorksSection />
      <SolutionsSection />
      <TestimonialsSection />
      <PricingSection onNavigate={onNavigate} />
      <NewsSection onNavigate={onNavigate} />
      <FAQSection onNavigate={() => onNavigate('faq')} />
      <CallToActionSection onNavigate={onNavigate} />
    </>
  );
};

export default HomePage;
