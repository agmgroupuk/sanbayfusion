import React, { useState, useRef, useEffect } from 'react';
import { Page } from '../../App';
import {
  ArrowLeft,
  Play,
  Wand2,
  Copy,
  Download,
  Trash2,
  RefreshCw,
  BookOpen,
  Lightbulb,
  Thermometer,
  Hash,
  Zap,
  Settings,
  ChevronDown,
  ChevronRight,
  Check,
  AlertCircle,
  Info,
  Sparkles,
  MessageSquare,
  Clock,
  DollarSign,
  Lock,
  Crown,
} from 'lucide-react';
import { aiLabService } from '../../services/aiLabService';
import { authService } from '../../services/authService';

interface AILabPromptPageProps {
  onNavigate: (page: Page) => void;
}

interface PromptTemplate {
  id: string;
  name: string;
  category: string;
  description: string;
  systemMessage: string;
  userPrompt: string;
  parameters: {
    temperature: number;
    maxTokens: number;
    topP: number;
  };
  tags: string[];
}

interface BestPractice {
  title: string;
  description: string;
  example: string;
  icon: React.ReactNode;
}

interface TestResult {
  prompt: string;
  response: string;
  tokens: number;
  cost: number;
  latency: number;
  timestamp: number;
}

interface SubscriptionStatus {
  hasActiveSubscription: boolean;
  subscriptionType: string | null;
  isLoading: boolean;
}

const AILabPromptPage: React.FC<AILabPromptPageProps> = ({ onNavigate }) => {
  // State
  const [selectedTemplate, setSelectedTemplate] = useState<PromptTemplate | null>(null);
  const [prompt, setPrompt] = useState('');
  const [systemMessage, setSystemMessage] = useState('You are a helpful AI assistant.');
  const [temperature, setTemperature] = useState(0.7);
  const [maxTokens, setMaxTokens] = useState(500);
  const [topP, setTopP] = useState(1);
  const [frequencyPenalty, setFrequencyPenalty] = useState(0);
  const [presencePenalty, setPresencePenalty] = useState(0);
  const [result, setResult] = useState<TestResult | null>(null);
  const [isRunning, setIsRunning] = useState(false);
  const [showBestPractices, setShowBestPractices] = useState(true);
  const [activeCategory, setActiveCategory] = useState('all');
  const [subscriptionStatus, setSubscriptionStatus] = useState<SubscriptionStatus>({
    hasActiveSubscription: false,
    subscriptionType: null,
    isLoading: false,
  });
  const [showSubscriptionModal, setShowSubscriptionModal] = useState(true);

  const promptRef = useRef<HTMLTextAreaElement>(null);

  // Check subscription status
  useEffect(() => {
    const checkSubscription = async () => {
      try {
        if (!authService.isAuthenticated()) {
          setShowSubscriptionModal(true);
          return;
        }
        // For testing: force no subscription
        setSubscriptionStatus({
          hasActiveSubscription: false,
          subscriptionType: null,
          isLoading: false,
        });
      } catch (error) {
        console.error('Error checking subscription:', error);
      }
    };
    checkSubscription();
  }, []);

  // Best Practices
  const bestPractices: BestPractice[] = [
    {
      title: 'Be Specific',
      description: 'Clearly define the task and expected output format',
      example:
        'Instead of "Write about dogs", try "Write a 200-word informative paragraph about Golden Retrievers, focusing on their temperament and care requirements."',
      icon: <Lightbulb className="w-5 h-5" />,
    },
    {
      title: 'Provide Context',
      description: 'Give the AI background information it needs',
      example:
        'Add context like "You are an expert veterinarian with 15 years of experience" or "This is for a children\'s educational website"',
      icon: <BookOpen className="w-5 h-5" />,
    },
    {
      title: 'Use Examples',
      description: 'Show the AI what you want with examples (few-shot learning)',
      example: 'Include 1-3 examples of the desired output format before asking for a new one',
      icon: <MessageSquare className="w-5 h-5" />,
    },
    {
      title: 'Control Creativity',
      description: 'Adjust temperature based on task type',
      example:
        'Use low temperature (0.1-0.3) for factual/analytical tasks, high (0.7-1.0) for creative writing',
      icon: <Thermometer className="w-5 h-5" />,
    },
  ];

  // Prompt Templates
  const templates: PromptTemplate[] = [
    {
      id: 'summarize',
      name: 'Text Summarization',
      category: 'Content',
      description: 'Condense long text into key points',
      systemMessage:
        'You are an expert at creating concise, accurate summaries. Extract the most important information while maintaining context.',
      userPrompt: 'Summarize the following text in 3-5 bullet points:\n\n[Paste your text here]',
      parameters: { temperature: 0.3, maxTokens: 300, topP: 0.9 },
      tags: ['content', 'analysis'],
    },
    {
      id: 'translate',
      name: 'Language Translation',
      category: 'Language',
      description: 'Translate text with context awareness',
      systemMessage:
        'You are a professional translator fluent in multiple languages. Maintain tone, context, and cultural nuances.',
      userPrompt: 'Translate the following text from English to [TARGET_LANGUAGE]:\n\n[Your text]',
      parameters: { temperature: 0.2, maxTokens: 800, topP: 0.95 },
      tags: ['language', 'translation'],
    },
    {
      id: 'code-explain',
      name: 'Code Explanation',
      category: 'Development',
      description: 'Explain code in simple terms',
      systemMessage:
        'You are an experienced software engineer who excels at explaining complex code in simple, beginner-friendly terms.',
      userPrompt: 'Explain what this code does, step by step:\n\n```\n[Paste code here]\n```',
      parameters: { temperature: 0.4, maxTokens: 600, topP: 0.9 },
      tags: ['coding', 'education'],
    },
    {
      id: 'creative-story',
      name: 'Creative Writing',
      category: 'Creative',
      description: 'Generate creative stories and narratives',
      systemMessage:
        'You are a creative storyteller with a vivid imagination. Write engaging, descriptive narratives that captivate readers.',
      userPrompt:
        'Write a short story (300 words) about [TOPIC/THEME]:\n\nStyle: [dramatic/humorous/mysterious]\nSetting: [location and time]\nMain character: [description]',
      parameters: { temperature: 0.9, maxTokens: 800, topP: 0.95 },
      tags: ['creative', 'writing'],
    },
    {
      id: 'brainstorm',
      name: 'Brainstorming Ideas',
      category: 'Productivity',
      description: 'Generate diverse ideas and solutions',
      systemMessage:
        'You are a creative brainstorming partner who generates diverse, innovative ideas. Think outside the box.',
      userPrompt:
        'Generate 10 creative ideas for [TOPIC/PROBLEM]:\n\nContext: [background information]\nGoal: [what you want to achieve]\nConstraints: [any limitations]',
      parameters: { temperature: 0.8, maxTokens: 500, topP: 0.9 },
      tags: ['productivity', 'creativity'],
    },
    {
      id: 'email-draft',
      name: 'Professional Email',
      category: 'Business',
      description: 'Compose professional emails',
      systemMessage:
        'You are a professional business communications expert. Write clear, polite, and effective emails.',
      userPrompt:
        'Write a professional email:\n\nTo: [recipient]\nPurpose: [reason for email]\nTone: [formal/casual/friendly]\nKey points: [list main points]',
      parameters: { temperature: 0.5, maxTokens: 400, topP: 0.9 },
      tags: ['business', 'communication'],
    },
    {
      id: 'seo-content',
      name: 'SEO Content',
      category: 'Marketing',
      description: 'Create SEO-optimized content',
      systemMessage:
        'You are an SEO content strategist. Create engaging content optimized for search engines while maintaining natural readability.',
      userPrompt:
        'Write SEO-optimized content about [TOPIC]:\n\nTarget keyword: [keyword]\nLength: [word count]\nAudience: [target audience]\nTone: [professional/casual/technical]',
      parameters: { temperature: 0.6, maxTokens: 1000, topP: 0.9 },
      tags: ['marketing', 'seo'],
    },
    {
      id: 'debug-code',
      name: 'Code Debugging',
      category: 'Development',
      description: 'Find and fix code issues',
      systemMessage:
        'You are an expert debugger. Analyze code, identify issues, and provide clear solutions with explanations.',
      userPrompt:
        'Debug this code and explain the issue:\n\n```\n[Paste buggy code]\n```\n\nError message: [if any]\nExpected behavior: [what should happen]',
      parameters: { temperature: 0.2, maxTokens: 700, topP: 0.9 },
      tags: ['coding', 'debugging'],
    },
  ];

  // Categories
  const categories = [
    { id: 'all', label: 'All Templates', count: templates.length },
    {
      id: 'Content',
      label: 'Content',
      count: templates.filter(t => t.category === 'Content').length,
    },
    {
      id: 'Language',
      label: 'Language',
      count: templates.filter(t => t.category === 'Language').length,
    },
    {
      id: 'Development',
      label: 'Development',
      count: templates.filter(t => t.category === 'Development').length,
    },
    {
      id: 'Creative',
      label: 'Creative',
      count: templates.filter(t => t.category === 'Creative').length,
    },
    {
      id: 'Productivity',
      label: 'Productivity',
      count: templates.filter(t => t.category === 'Productivity').length,
    },
    {
      id: 'Business',
      label: 'Business',
      count: templates.filter(t => t.category === 'Business').length,
    },
    {
      id: 'Marketing',
      label: 'Marketing',
      count: templates.filter(t => t.category === 'Marketing').length,
    },
  ];

  const filteredTemplates =
    activeCategory === 'all' ? templates : templates.filter(t => t.category === activeCategory);

  // Auto-resize textarea
  useEffect(() => {
    if (promptRef.current) {
      promptRef.current.style.height = 'auto';
      promptRef.current.style.height = promptRef.current.scrollHeight + 'px';
    }
  }, [prompt]);

  // Apply template
  const applyTemplate = (template: PromptTemplate) => {
    setSelectedTemplate(template);
    setPrompt(template.userPrompt);
    setSystemMessage(template.systemMessage);
    setTemperature(template.parameters.temperature);
    setMaxTokens(template.parameters.maxTokens);
    setTopP(template.parameters.topP);
  };

  // Run prompt
  const runPrompt = async () => {
    if (!prompt.trim()) return;

    setIsRunning(true);
    const startTime = Date.now();

    try {
      // Use real AI through backend proxy (default to GPT-4)
      const result = await aiLabService.generateCompletion({
        provider: 'openai',
        model: 'gpt-4',
        prompt: prompt,
        systemPrompt: systemMessage,
        temperature: temperature,
        maxTokens: maxTokens,
      });

      if (!result.success) {
        throw new Error(result.error || 'Failed to generate response');
      }

      const tokens =
        result.tokensUsed?.total ||
        Math.floor((prompt.length + (result.response?.length || 0)) / 4);
      const cost = (tokens / 1_000_000) * 20; // Approximate cost

      const testResult: TestResult = {
        prompt,
        response: result.response || 'No response',
        tokens,
        cost,
        latency: Date.now() - startTime,
        timestamp: Date.now(),
      };

      setResult(testResult);
      setIsRunning(false);

      // Save to history
      saveToHistory(testResult);
    } catch (error) {
      console.error('Error generating response:', error);
      setResult({
        prompt,
        response: `Error: ${error instanceof Error ? error.message : 'Unknown error'}`,
        tokens: 0,
        cost: 0,
        latency: Date.now() - startTime,
        timestamp: Date.now(),
      });
      setIsRunning(false);
    }
  };

  // Save to history
  const saveToHistory = (result: TestResult) => {
    try {
      const history = JSON.parse(localStorage.getItem('ailab_global_history') || '[]');
      history.push({
        type: 'prompt-engineering',
        ...result,
        parameters: { temperature, maxTokens, topP, frequencyPenalty, presencePenalty },
        systemMessage,
      });
      localStorage.setItem('ailab_global_history', JSON.stringify(history));
    } catch (e) {
      console.error('Failed to save to history:', e);
    }
  };

  // Copy result
  const copyResult = () => {
    if (result) {
      navigator.clipboard.writeText(result.response);
    }
  };

  // Download result
  const downloadResult = () => {
    if (!result) return;

    const data = {
      prompt: result.prompt,
      systemMessage,
      parameters: { temperature, maxTokens, topP, frequencyPenalty, presencePenalty },
      response: result.response,
      metrics: {
        tokens: result.tokens,
        cost: result.cost,
        latency: result.latency,
      },
      timestamp: new Date(result.timestamp).toISOString(),
    };

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `prompt-result-${Date.now()}.json`;
    a.click();
  };

  return (
    <div className="min-h-screen bg-black text-white pb-20">
      {/* Subscription Modal */}
      {showSubscriptionModal && (
        <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-gray-900 border border-gray-800 rounded-2xl p-8 max-w-md w-full text-center">
            <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-purple-500 to-pink-600 rounded-full flex items-center justify-center">
              <Wand2 className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-white mb-3">
              Prompt Engineering Access Required
            </h2>
            <p className="text-gray-400 mb-6">
              The Prompt Engineering Lab is a premium feature. Subscribe to unlock access to
              advanced prompt templates and optimization tools.
            </p>
            <div className="space-y-3">
              <button
                onClick={() => (window.location.href = '/pricing')}
                className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white px-6 py-3 rounded-lg font-semibold hover:from-purple-500 hover:to-pink-500 transition-all"
              >
                Upgrade Now
              </button>
              <button
                onClick={() => onNavigate('ai-lab' as Page)}
                className="w-full bg-gray-800 hover:bg-gray-700 text-white px-6 py-3 rounded-lg font-semibold transition-all"
              >
                Back to AI Lab
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Full Page Barrier for Non-Subscribers */}
      {!subscriptionStatus.hasActiveSubscription && (
        <div className="fixed inset-0 z-40 bg-black/90 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-gray-900 border border-purple-500/30 rounded-2xl p-8 max-w-lg w-full text-center">
            <div className="w-20 h-20 mx-auto mb-6 bg-gradient-to-r from-purple-500 to-pink-600 rounded-full flex items-center justify-center">
              <Lock className="w-10 h-10 text-white" />
            </div>
            <h2 className="text-3xl font-bold text-white mb-4">Premium Feature Locked</h2>
            <p className="text-gray-400 mb-6 text-lg">
              Prompt Engineering Lab requires an active subscription. Master the art of AI prompting
              with professional templates and techniques.
            </p>
            <div className="bg-purple-500/10 border border-purple-500/30 rounded-lg p-4 mb-6">
              <p className="text-purple-400 font-semibold">✨ Prompt Lab Features:</p>
              <ul className="text-sm text-gray-300 mt-2 space-y-1 text-left">
                <li>• Professional prompt templates</li>
                <li>• Advanced parameter tuning</li>
                <li>• Best practices & techniques</li>
                <li>• Prompt optimization tools</li>
              </ul>
            </div>
            <button
              onClick={() => setShowSubscriptionModal(true)}
              className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white px-6 py-4 rounded-xl font-bold text-lg hover:from-purple-500 hover:to-pink-500 transition-all shadow-lg"
            >
              Unlock Prompt Lab
            </button>
          </div>
        </div>
      )}
      {/* Header */}
      <div className="sticky top-0 z-40 bg-black/95 backdrop-blur-xl border-b border-gray-800">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={() => onNavigate('ai-lab' as Page)}
                className="p-2 hover:bg-gray-800 rounded-lg transition-colors"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
              <div>
                <h1 className="text-2xl font-bold text-white flex items-center gap-2">
                  <Wand2 className="w-6 h-6 text-cyan-400" />
                  Prompt Engineering Lab
                </h1>
                <p className="text-sm text-gray-400">
                  Master the art of crafting effective prompts
                </p>
              </div>
            </div>

            <button
              onClick={() => setShowBestPractices(!showBestPractices)}
              className="px-4 py-2 bg-gray-800 hover:bg-gray-700 rounded-lg text-sm font-medium transition-colors flex items-center gap-2"
            >
              <Lightbulb className="w-4 h-4" />
              {showBestPractices ? 'Hide' : 'Show'} Best Practices
            </button>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-6 py-8">
        <div className="grid lg:grid-cols-12 gap-8">
          {/* Left Sidebar - Templates */}
          <div className="lg:col-span-3 space-y-6">
            <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-6">
              <h3 className="text-lg font-semibold text-white mb-4">Prompt Templates</h3>

              {/* Category Filters */}
              <div className="flex flex-wrap gap-2 mb-4">
                {categories.slice(0, 4).map(cat => (
                  <button
                    key={cat.id}
                    onClick={() => setActiveCategory(cat.id)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                      activeCategory === cat.id
                        ? 'bg-cyan-500 text-black'
                        : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
                    }`}
                  >
                    {cat.label}
                  </button>
                ))}
              </div>

              {/* Template List */}
              <div className="space-y-2 max-h-[600px] overflow-y-auto">
                {filteredTemplates.map(template => (
                  <button
                    key={template.id}
                    onClick={() => applyTemplate(template)}
                    className={`w-full text-left p-4 rounded-xl border-2 transition-all ${
                      selectedTemplate?.id === template.id
                        ? 'bg-cyan-500/20 border-cyan-500'
                        : 'bg-gray-800/50 border-gray-700 hover:border-gray-600'
                    }`}
                  >
                    <p className="font-semibold text-white mb-1">{template.name}</p>
                    <p className="text-xs text-gray-400 mb-2">{template.description}</p>
                    <div className="flex flex-wrap gap-1">
                      {template.tags.map(tag => (
                        <span
                          key={tag}
                          className="px-2 py-0.5 bg-gray-900 text-gray-400 rounded text-xs"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Center - Editor */}
          <div className="lg:col-span-6 space-y-6">
            {/* System Message */}
            <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-6">
              <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                <Settings className="w-5 h-5 text-cyan-400" />
                System Message
              </h3>
              <textarea
                value={systemMessage}
                onChange={e => setSystemMessage(e.target.value)}
                disabled={isRunning}
                placeholder="Define the AI's role, behavior, and context..."
                className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-cyan-500 resize-none"
                rows={3}
              />
            </div>

            {/* User Prompt */}
            <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-white">Your Prompt</h3>
                <span className="text-sm text-gray-400">
                  ~{Math.ceil((prompt.length + systemMessage.length) / 4)} tokens
                </span>
              </div>
              <textarea
                ref={promptRef}
                value={prompt}
                onChange={e => setPrompt(e.target.value)}
                disabled={isRunning}
                placeholder="Enter your prompt here... Be specific, provide context, and use examples."
                className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-cyan-500 resize-none min-h-[150px]"
              />

              {/* Parameters */}
              <div className="mt-4 grid grid-cols-2 gap-4">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-sm text-gray-400">Temperature</label>
                    <span className="text-sm text-cyan-400 font-mono">{temperature}</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="2"
                    step="0.1"
                    value={temperature}
                    onChange={e => setTemperature(parseFloat(e.target.value))}
                    disabled={isRunning}
                    className="w-full"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-sm text-gray-400">Max Tokens</label>
                    <span className="text-sm text-cyan-400 font-mono">{maxTokens}</span>
                  </div>
                  <input
                    type="range"
                    min="50"
                    max="4000"
                    step="50"
                    value={maxTokens}
                    onChange={e => setMaxTokens(parseInt(e.target.value))}
                    disabled={isRunning}
                    className="w-full"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-sm text-gray-400">Top P</label>
                    <span className="text-sm text-cyan-400 font-mono">{topP}</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.05"
                    value={topP}
                    onChange={e => setTopP(parseFloat(e.target.value))}
                    disabled={isRunning}
                    className="w-full"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-sm text-gray-400">Frequency Penalty</label>
                    <span className="text-sm text-cyan-400 font-mono">{frequencyPenalty}</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="2"
                    step="0.1"
                    value={frequencyPenalty}
                    onChange={e => setFrequencyPenalty(parseFloat(e.target.value))}
                    disabled={isRunning}
                    className="w-full"
                  />
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center justify-between mt-6">
                <button
                  onClick={() => {
                    setPrompt('');
                    setResult(null);
                  }}
                  disabled={isRunning || !prompt}
                  className="px-4 py-2 text-sm text-gray-400 hover:text-white hover:bg-gray-800 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <Trash2 className="w-4 h-4 inline mr-2" />
                  Clear
                </button>

                <button
                  onClick={runPrompt}
                  disabled={isRunning || !prompt.trim()}
                  className="px-8 py-3 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 disabled:from-gray-700 disabled:to-gray-700 text-white font-semibold rounded-xl shadow-lg transition-all disabled:cursor-not-allowed flex items-center gap-2"
                >
                  {isRunning ? (
                    <>
                      <RefreshCw className="w-5 h-5 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <Play className="w-5 h-5" />
                      Run Test
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Result */}
            {result && (
              <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-white">Result</h3>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={copyResult}
                      className="p-2 hover:bg-gray-800 rounded-lg transition-colors"
                    >
                      <Copy className="w-4 h-4" />
                    </button>
                    <button
                      onClick={downloadResult}
                      className="p-2 hover:bg-gray-800 rounded-lg transition-colors"
                    >
                      <Download className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-4 mb-4 max-h-[400px] overflow-y-auto">
                  <p className="text-sm text-gray-300 whitespace-pre-wrap leading-relaxed">
                    {result.response}
                  </p>
                </div>

                {/* Metrics */}
                <div className="grid grid-cols-4 gap-3">
                  <div className="text-center p-3 bg-gray-800/50 rounded-lg">
                    <Hash className="w-4 h-4 mx-auto mb-1 text-gray-400" />
                    <p className="text-xs text-gray-400">Tokens</p>
                    <p className="text-sm font-semibold text-white">{result.tokens}</p>
                  </div>
                  <div className="text-center p-3 bg-gray-800/50 rounded-lg">
                    <Clock className="w-4 h-4 mx-auto mb-1 text-gray-400" />
                    <p className="text-xs text-gray-400">Latency</p>
                    <p className="text-sm font-semibold text-white">{result.latency}ms</p>
                  </div>
                  <div className="text-center p-3 bg-gray-800/50 rounded-lg">
                    <DollarSign className="w-4 h-4 mx-auto mb-1 text-gray-400" />
                    <p className="text-xs text-gray-400">Cost</p>
                    <p className="text-sm font-semibold text-white">${result.cost.toFixed(6)}</p>
                  </div>
                  <div className="text-center p-3 bg-gray-800/50 rounded-lg">
                    <Sparkles className="w-4 h-4 mx-auto mb-1 text-gray-400" />
                    <p className="text-xs text-gray-400">Quality</p>
                    <p className="text-sm font-semibold text-white">Good</p>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Right Sidebar - Best Practices */}
          {showBestPractices && (
            <div className="lg:col-span-3 space-y-6">
              <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-6">
                <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                  <Lightbulb className="w-5 h-5 text-yellow-400" />
                  Best Practices
                </h3>

                <div className="space-y-4">
                  {bestPractices.map((practice, index) => (
                    <div key={index} className="border border-gray-800 rounded-lg p-4">
                      <div className="flex items-start gap-3 mb-2">
                        <div className="text-cyan-400 mt-1">{practice.icon}</div>
                        <div className="flex-1">
                          <h4 className="font-semibold text-white mb-1">{practice.title}</h4>
                          <p className="text-sm text-gray-400 mb-3">{practice.description}</p>
                          <div className="bg-gray-800/50 border border-gray-700 rounded p-3">
                            <p className="text-xs text-gray-400 leading-relaxed">
                              {practice.example}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Tips */}
                <div className="mt-6 p-4 bg-cyan-500/10 border border-cyan-500/30 rounded-lg">
                  <div className="flex items-start gap-2">
                    <Info className="w-4 h-4 text-cyan-400 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-sm font-semibold text-cyan-400 mb-1">Pro Tip</p>
                      <p className="text-xs text-gray-400 leading-relaxed">
                        Experiment with different parameter combinations. Low temperature works best
                        for factual tasks, while higher temperature generates more creative
                        responses.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AILabPromptPage;
