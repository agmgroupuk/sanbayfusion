// AI Lab Component - Subscription-Gated AI Laboratory with Complete Data Tracking
// Comprehensive AI lab interface with 17 AI tools and subscription validation

import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  FaFlask,
  FaSwords,
  FaCode,
  FaBrain,
  FaChartLine,
  FaCog,
  FaRocket,
  FaSearch,
  FaMicroscope,
  FaLightbulb,
  FaCalculator,
  FaStopwatch,
  FaEye,
  FaRobot,
  FaCrown,
  FaLock,
  FaCheck,
} from 'react-icons/fa';
import { toast } from 'react-toastify';
import { authService } from '../../services/authService';

const AILab = () => {
  const [user, setUser] = useState(null);
  const [subscription, setSubscription] = useState(null);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [loading, setLoading] = useState(true);
  const [experiments, setExperiments] = useState([]);
  const [usageStats, setUsageStats] = useState(null);

  // ============================================
  // AI LAB TOOLS CONFIGURATION
  // ============================================

  const aiLabTools = [
    {
      id: 'playground',
      name: 'AI Playground',
      description: 'Compare multiple AI models side by side',
      icon: FaFlask,
      category: 'core',
      requiredTier: 'daily',
      color: 'from-blue-500 to-purple-600',
      features: ['Multi-model comparison', 'Real-time testing', 'Quality scoring'],
    },
    {
      id: 'battle-arena',
      name: 'AI Battle Arena',
      description: 'Head-to-head AI model competitions',
      icon: FaSwords,
      category: 'advanced',
      requiredTier: 'weekly',
      color: 'from-red-500 to-pink-600',
      features: ['Model vs model', 'Performance metrics', 'Winner analysis'],
    },
    {
      id: 'prompt-engineering',
      name: 'Prompt Engineering Lab',
      description: 'Optimize and refine your prompts',
      icon: FaLightbulb,
      category: 'advanced',
      requiredTier: 'monthly',
      color: 'from-yellow-500 to-orange-600',
      features: ['Prompt optimization', 'A/B testing', 'Performance insights'],
    },
    {
      id: 'code-playground',
      name: 'Code Playground',
      description: 'AI-powered code analysis and optimization',
      icon: FaCode,
      category: 'tools',
      requiredTier: 'daily',
      color: 'from-green-500 to-blue-600',
      features: ['Code explanation', 'Bug detection', 'Optimization suggestions'],
    },
    {
      id: 'sentiment-analysis',
      name: 'Sentiment Analysis Lab',
      description: 'Advanced emotion and sentiment detection',
      icon: FaBrain,
      category: 'tools',
      requiredTier: 'daily',
      color: 'from-purple-500 to-pink-600',
      features: ['Multi-model analysis', 'Emotion detection', 'Confidence scores'],
    },
    {
      id: 'transformer-visualizer',
      name: 'Transformer Visualizer',
      description: 'Visualize transformer architecture and attention',
      icon: FaEye,
      category: 'research',
      requiredTier: 'monthly',
      color: 'from-indigo-500 to-purple-600',
      features: ['Attention patterns', 'Layer analysis', 'Token embeddings'],
    },
    {
      id: 'cost-calculator',
      name: 'Model Cost Calculator',
      description: 'Compare costs across different AI models',
      icon: FaCalculator,
      category: 'tools',
      requiredTier: 'daily',
      color: 'from-green-400 to-blue-500',
      features: ['Cost comparison', 'Usage estimation', 'ROI analysis'],
    },
    {
      id: 'latency-benchmark',
      name: 'Latency Benchmark',
      description: 'Test model response times and performance',
      icon: FaStopwatch,
      category: 'advanced',
      requiredTier: 'monthly',
      color: 'from-orange-500 to-red-600',
      features: ['Performance testing', 'Latency analysis', 'Throughput metrics'],
    },
    {
      id: 'research-assistant',
      name: 'AI Research Assistant',
      description: 'AI-powered research and information gathering',
      icon: FaSearch,
      category: 'research',
      requiredTier: 'monthly',
      color: 'from-blue-400 to-indigo-600',
      features: ['Research queries', 'Source verification', 'Synthesis reports'],
    },
    {
      id: 'performance-analytics',
      name: 'Performance Analytics',
      description: 'Comprehensive model performance insights',
      icon: FaChartLine,
      category: 'advanced',
      requiredTier: 'monthly',
      color: 'from-teal-500 to-green-600',
      features: ['Performance metrics', 'Trend analysis', 'Optimization tips'],
    },
  ];

  // ============================================
  // SUBSCRIPTION PLANS
  // ============================================

  const subscriptionPlans = [
    {
      id: 'daily',
      name: 'Daily Pass',
      price: '$1',
      duration: '1 day',
      color: 'from-blue-500 to-blue-600',
      features: [
        'Unlimited experiments',
        'AI Playground access',
        'Code Playground (basic)',
        'Sentiment Analysis',
        'Cost Calculator',
        'Compare up to 2 models',
      ],
      recommended: false,
    },
    {
      id: 'weekly',
      name: 'Weekly Pro',
      price: '$5',
      duration: '7 days',
      color: 'from-purple-500 to-purple-600',
      features: [
        'Unlimited experiments',
        'AI Battle Arena access',
        'Advanced Code Playground',
        'Export results',
        'Save templates',
        'Compare up to 3 models',
        'Everything in Daily Pass',
      ],
      recommended: true,
    },
    {
      id: 'monthly',
      name: 'Monthly Premium',
      price: '$19',
      duration: '30 days',
      color: 'from-gradient-start to-gradient-end',
      features: [
        'Unlimited experiments',
        'AI Research Assistant',
        'Transformer Visualizer',
        'Performance Analytics',
        'Latency Benchmarking',
        'Prompt Engineering Lab',
        'Compare up to 5 models',
        'Priority support',
        'Everything in Weekly Pro',
      ],
      recommended: false,
    },
  ];

  // NOTE: Only 3 plans offered per agent: Daily ($1), Weekly ($5), Monthly ($19)
  // Each agent requires a separate subscription

  // ============================================
  // DATA FETCHING
  // ============================================

  const fetchSubscriptionStatus = useCallback(async () => {
    try {
      if (!authService.isAuthenticated()) {
        setLoading(false);
        return;
      }

      // Use unified IAMAI subscription endpoint – any active plan unlocks AI Lab
      const response = await authService.authenticatedFetch('/api/subscription/current');
      const data = await response.json();

      if (response.ok) {
        const hasActiveSubscription = Boolean(data?.subscription && data.status === 'ACTIVE');

        // Normalize into the shape this legacy component expects
        setSubscription({
          hasSubscription: hasActiveSubscription,
          subscription: {
            type: hasActiveSubscription
              ? (data.subscription.plan || 'monthly').toLowerCase()
              : 'none',
          },
          usage: {
            current: {
              // Detailed AI Lab usage now lives in newer dashboards; keep legacy view minimal
              todayExperiments: 0,
            },
          },
          permissions: {
            // Use a safe default; actual limits are enforced server-side
            maxExperimentsPerDay: 0,
          },
        });
      } else {
        setSubscription({
          hasSubscription: false,
        });
      }
    } catch (error) {
      console.error('Error fetching subscription status:', error);
      setSubscription({
        hasSubscription: false,
      });
    }
  }, []);

  const fetchDashboardData = useCallback(async () => {
    try {
      if (!authService.isAuthenticated()) return;

      const response = await authService.authenticatedFetch('/api/ai-lab/dashboard');

      const data = await response.json();

      if (data.success) {
        setExperiments(data.dashboard.recentExperiments || []);
        setUsageStats(data.dashboard.usageStats);
      }
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    }
  }, []);

  useEffect(() => {
    const initializeAILab = async () => {
      setLoading(true);
      await fetchSubscriptionStatus();
      await fetchDashboardData();
      setLoading(false);
    };

    initializeAILab();
  }, [fetchSubscriptionStatus, fetchDashboardData]);

  // ============================================
  // SUBSCRIPTION MANAGEMENT
  // ============================================

  const handleSubscribe = async planId => {
    try {
      if (!authService.isAuthenticated()) {
        toast.error('Please login to subscribe');
        return;
      }

      // Legacy AI Lab-specific purchase routes have been removed.
      // AI Lab access is now included with any active IAMAI subscription.
      toast.info(
        "AI Lab is included with any active IAMAI subscription. You'll be redirected to the main subscription page."
      );

      // Redirect users to the unified subscription / pricing page
      setTimeout(() => {
        window.location.href = '/pricing';
      }, 500);
    } catch (error) {
      console.error('Subscription redirect error:', error);
      toast.error('Unable to open subscription page');
    }
  };

  // ============================================
  // TOOL ACCESS CHECK
  // ============================================

  const canAccessTool = tool => {
    // Any active subscription unlocks all AI Lab experiments
    return subscription?.hasSubscription || false;
  };

  // ============================================
  // RENDER COMPONENTS
  // ============================================

  const renderSubscriptionPlans = () => (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {subscriptionPlans.map(plan => (
        <motion.div
          key={plan.id}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className={`relative bg-white rounded-2xl shadow-xl overflow-hidden transform hover:scale-105 transition-all duration-300 ${
            plan.recommended ? 'ring-4 ring-purple-500 ring-opacity-50' : ''
          }`}
        >
          {plan.recommended && (
            <div className="absolute top-0 left-0 right-0 bg-gradient-to-r from-purple-500 to-pink-500 text-white text-center py-2 font-semibold">
              <FaCrown className="inline-block mr-2" />
              Most Popular
            </div>
          )}

          <div
            className={`bg-gradient-to-br ${plan.color} p-6 text-white ${plan.recommended ? 'pt-12' : ''}`}
          >
            <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
            <div className="text-3xl font-extrabold mb-1">{plan.price}</div>
            <div className="text-sm opacity-80">per {plan.duration}</div>
          </div>

          <div className="p-6">
            <ul className="space-y-3 mb-6">
              {plan.features.map((feature, idx) => (
                <li key={idx} className="flex items-start">
                  <FaCheck className="text-green-500 mt-1 mr-3 flex-shrink-0" />
                  <span className="text-sm text-gray-700">
                    {typeof feature === 'string'
                      ? feature
                      : feature?.name || feature?.title || 'Feature'}
                  </span>
                </li>
              ))}
            </ul>

            <button
              onClick={() => handleSubscribe(plan.id)}
              disabled={loading}
              className={`w-full py-3 px-4 rounded-xl font-semibold transition-all duration-200 ${
                plan.recommended
                  ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white hover:from-purple-600 hover:to-pink-600'
                  : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
              } ${loading ? 'opacity-50 cursor-not-allowed' : 'hover:shadow-lg'}`}
            >
              {loading ? 'Processing...' : 'Subscribe Now'}
            </button>
          </div>
        </motion.div>
      ))}
    </div>
  );

  const renderDashboard = () => (
    <div className="space-y-8">
      {/* Subscription Status */}
      <div className="bg-white rounded-2xl shadow-lg p-6">
        <h2 className="text-2xl font-bold mb-4 flex items-center">
          <FaCrown className="mr-3 text-yellow-500" />
          Subscription Status
        </h2>

        {subscription?.hasSubscription ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-green-500 mb-2">Active</div>
              <div className="text-gray-600">
                {subscription.subscription.type.charAt(0).toUpperCase() +
                  subscription.subscription.type.slice(1)}{' '}
                Plan
              </div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-500 mb-2">
                {subscription.usage?.current?.todayExperiments || 0}
              </div>
              <div className="text-gray-600">Experiments Today</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-500 mb-2">
                {subscription.permissions?.maxExperimentsPerDay || 0}
              </div>
              <div className="text-gray-600">Daily Limit</div>
            </div>
          </div>
        ) : (
          <div className="text-center py-8">
            <FaLock className="text-6xl text-gray-300 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-700 mb-2">AI Lab Access Required</h3>
            <p className="text-gray-600 mb-6">
              Subscribe to unlock all AI Lab tools and start experimenting!
            </p>
            <button
              onClick={() => setActiveTab('subscribe')}
              className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-8 py-3 rounded-xl font-semibold hover:from-purple-600 hover:to-pink-600 transition-all duration-200"
            >
              View Plans
            </button>
          </div>
        )}
      </div>

      {/* Recent Experiments */}
      {experiments.length > 0 && (
        <div className="bg-white rounded-2xl shadow-lg p-6">
          <h2 className="text-2xl font-bold mb-4 flex items-center">
            <FaFlask className="mr-3 text-blue-500" />
            Recent Experiments
          </h2>

          <div className="space-y-4">
            {experiments.slice(0, 5).map((exp, idx) => (
              <div
                key={idx}
                className="flex items-center justify-between p-4 bg-gray-50 rounded-xl"
              >
                <div>
                  <h3 className="font-semibold">
                    {exp.experiment?.title || 'Untitled Experiment'}
                  </h3>
                  <p className="text-sm text-gray-600">
                    Type: {exp.experiment?.type} • {new Date(exp.createdAt).toLocaleDateString()}
                  </p>
                </div>
                <div className="text-right">
                  <div className="text-sm font-medium text-green-600">
                    {exp.results?.length || 0} results
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );

  const renderToolsGrid = () => (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {aiLabTools.map(tool => {
        const IconComponent = tool.icon;
        const hasAccess = canAccessTool(tool);

        return (
          <motion.div
            key={tool.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className={`bg-white rounded-2xl shadow-lg overflow-hidden transform hover:scale-105 transition-all duration-300 ${
              !hasAccess ? 'opacity-60' : ''
            }`}
          >
            <div className={`bg-gradient-to-br ${tool.color} p-6 text-white relative`}>
              {!hasAccess && <FaLock className="absolute top-4 right-4 text-white/70" />}
              <IconComponent className="text-4xl mb-4" />
              <h3 className="text-xl font-bold mb-2">{tool.name}</h3>
              <p className="text-sm opacity-90">{tool.description}</p>
            </div>

            <div className="p-6">
              <div className="space-y-2 mb-4">
                {tool.features.map((feature, idx) => (
                  <div key={idx} className="flex items-center text-sm text-gray-600">
                    <FaCheck className="text-green-500 mr-2" />
                    {typeof feature === 'string'
                      ? feature
                      : feature?.name || feature?.title || 'Feature'}
                  </div>
                ))}
              </div>

              <button
                disabled={!hasAccess}
                className={`w-full py-3 px-4 rounded-xl font-semibold transition-all duration-200 ${
                  hasAccess
                    ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white hover:from-blue-600 hover:to-purple-700'
                    : 'bg-gray-200 text-gray-500 cursor-not-allowed'
                }`}
                onClick={() => {
                  if (hasAccess) {
                    toast.info(`${tool.name} coming soon!`);
                  } else {
                    setActiveTab('subscribe');
                    toast.warning('AI Lab access requires an active subscription');
                  }
                }}
              >
                {hasAccess ? 'Launch Tool' : 'Subscription Required'}
              </button>
            </div>
          </motion.div>
        );
      })}
    </div>
  );

  // ============================================
  // MAIN RENDER
  // ============================================

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-purple-500 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading AI Lab...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      {/* Header */}
      <div className="bg-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <FaMicroscope className="text-3xl text-purple-600 mr-3" />
              <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                AI Lab
              </h1>
            </div>

            <nav className="flex space-x-8">
              {['dashboard', 'tools', 'subscribe'].map(tab => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    activeTab === tab
                      ? 'text-purple-600 bg-purple-100'
                      : 'text-gray-600 hover:text-purple-600'
                  }`}
                >
                  {tab.charAt(0).toUpperCase() + tab.slice(1)}
                </button>
              ))}
            </nav>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
          >
            {activeTab === 'dashboard' && renderDashboard()}
            {activeTab === 'tools' && renderToolsGrid()}
            {activeTab === 'subscribe' && (
              <div>
                <div className="text-center mb-12">
                  <h2 className="text-4xl font-bold mb-4">Choose Your AI Lab Plan</h2>
                  <p className="text-xl text-gray-600">
                    Unlock the full potential of AI with our comprehensive lab tools
                  </p>
                </div>
                {renderSubscriptionPlans()}
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
};

export default AILab;
