import React, { useState, useEffect, useRef } from 'react';
import { Page } from '../../App';
import {
  ArrowLeft,
  Swords,
  Play,
  RefreshCw,
  Trophy,
  Zap,
  Clock,
  Hash,
  DollarSign,
  ThumbsUp,
  ThumbsDown,
  Users,
  Target,
  Crown,
  Flame,
  Download,
  Share2,
  AlertCircle,
  Sparkles,
  MessageSquare,
  ChevronRight,
  Award,
  TrendingUp,
  Lock,
} from 'lucide-react';
import { aiLabService } from '../../services/aiLabService';
import { authService } from '../../services/authService';

interface AILabBattlePageProps {
  onNavigate: (page: Page) => void;
}

interface Model {
  id: string;
  name: string;
  provider: string;
  color: string;
  icon: string;
  wins: number;
  losses: number;
  avgScore: number;
}

interface BattleRound {
  roundNumber: number;
  topic: string;
  model1Response: string;
  model2Response: string;
  model1Score: number;
  model2Score: number;
  winner: 'model1' | 'model2' | 'tie' | null;
  timestamp: number;
  tokens: { model1: number; model2: number };
  latency: { model1: number; model2: number };
}

interface Battle {
  id: string;
  model1: Model;
  model2: Model;
  topic: string;
  rounds: BattleRound[];
  currentRound: number;
  totalRounds: number;
  status: 'setup' | 'active' | 'completed';
  overallWinner: 'model1' | 'model2' | 'tie' | null;
  startTime: number;
  endTime: number | null;
}

interface SubscriptionStatus {
  hasActiveSubscription: boolean;
  subscriptionType: string | null;
  isLoading: boolean;
}

interface SubscriptionStatus {
  hasActiveSubscription: boolean;
  subscriptionType: string | null;
  isLoading: boolean;
}

const AILabBattlePage: React.FC<AILabBattlePageProps> = ({ onNavigate }) => {
  // Available Models
  const models: Model[] = [
    {
      id: 'gpt-4-turbo',
      name: 'GPT-4 Turbo',
      provider: 'OpenAI',
      color: 'from-green-500 to-emerald-600',
      icon: '🤖',
      wins: 142,
      losses: 98,
      avgScore: 8.7,
    },
    {
      id: 'claude-3-haiku-20240307',
      name: 'Claude 3 Haiku',
      provider: 'Anthropic',
      color: 'from-purple-500 to-pink-600',
      icon: '🧠',
      wins: 156,
      losses: 84,
      avgScore: 9.1,
    },
    {
      id: 'gemini-pro-latest',
      name: 'Gemini Pro',
      provider: 'Google',
      color: 'from-blue-500 to-cyan-600',
      icon: '💎',
      wins: 128,
      losses: 112,
      avgScore: 8.4,
    },
    {
      id: 'mistral-large-latest',
      name: 'Mistral Large',
      provider: 'Mistral',
      color: 'from-orange-500 to-red-600',
      icon: '🌪️',
      wins: 134,
      losses: 106,
      avgScore: 8.5,
    },
  ];

  // State
  const [battle, setBattle] = useState<Battle | null>(null);
  const [selectedModel1, setSelectedModel1] = useState<Model | null>(null);
  const [selectedModel2, setSelectedModel2] = useState<Model | null>(null);
  const [topic, setTopic] = useState('');
  const [totalRounds, setTotalRounds] = useState(3);
  const [isProcessing, setIsProcessing] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const [userVotes, setUserVotes] = useState<Record<number, 'model1' | 'model2' | 'tie'>>({});
  const [subscriptionStatus, setSubscriptionStatus] = useState<SubscriptionStatus>({
    hasActiveSubscription: false,
    subscriptionType: null,
    isLoading: false,
  });
  const [showSubscriptionModal, setShowSubscriptionModal] = useState(true);

  const battleAreaRef = useRef<HTMLDivElement>(null);

  // Check subscription status
  useEffect(() => {
    const checkSubscription = async () => {
      try {
        if (!authService.isAuthenticated()) {
          setShowSubscriptionModal(true);
          return;
        }
        // For testing: force no subscription
        setSubscriptionStatus({
          hasActiveSubscription: false,
          subscriptionType: null,
          isLoading: false,
        });
      } catch (error) {
        console.error('Error checking subscription:', error);
      }
    };
    checkSubscription();
  }, []);

  // Popular Topics
  const popularTopics = [
    'The future of artificial intelligence',
    'Climate change solutions',
    'Space exploration priorities',
    'The impact of social media',
    'Ethical dilemmas in technology',
    'Best programming language for beginners',
    'Universal basic income pros and cons',
    'The future of work and automation',
  ];

  // Start Battle
  const startBattle = () => {
    if (!selectedModel1 || !selectedModel2 || !topic.trim()) return;

    const newBattle: Battle = {
      id: `battle-${Date.now()}`,
      model1: selectedModel1,
      model2: selectedModel2,
      topic: topic,
      rounds: [],
      currentRound: 0,
      totalRounds,
      status: 'setup',
      overallWinner: null,
      startTime: Date.now(),
      endTime: null,
    };

    setBattle(newBattle);
    setShowResults(false);
    setUserVotes({});

    // Start first round
    setTimeout(() => {
      runRound(newBattle, 1);
    }, 1000);
  };

  // Run Single Round
  const runRound = async (currentBattle: Battle, roundNumber: number) => {
    setBattle(prev => (prev ? { ...prev, status: 'active', currentRound: roundNumber } : null));
    setIsProcessing(true);

    try {
      // Get provider names from model IDs
      const getProvider = (modelId: string): string => {
        const model = models.find(m => m.id === modelId);
        return model?.provider.toLowerCase().replace(' ', '') || 'openai';
      };

      // Generate real AI responses using backend proxy
      const prompt = `This is round ${roundNumber} of ${currentBattle.totalRounds} in a debate about: "${currentBattle.topic}". ${roundNumber === 1 ? 'Present your initial argument.' : roundNumber === currentBattle.totalRounds ? 'Present your final argument and conclusion.' : 'Continue building your argument.'}`;

      const [result1, result2] = await Promise.all([
        aiLabService.generateCompletion({
          provider: getProvider(currentBattle.model1.id),
          model: currentBattle.model1.id,
          prompt: prompt,
          systemPrompt: `You are ${currentBattle.model1.name} participating in a debate. Be persuasive, well-reasoned, and provide specific examples. Keep your response concise (2-3 paragraphs).`,
          temperature: 0.8,
          maxTokens: 300,
        }),
        aiLabService.generateCompletion({
          provider: getProvider(currentBattle.model2.id),
          model: currentBattle.model2.id,
          prompt: prompt,
          systemPrompt: `You are ${currentBattle.model2.name} participating in a debate. Be persuasive, well-reasoned, and provide specific examples. Keep your response concise (2-3 paragraphs).`,
          temperature: 0.8,
          maxTokens: 300,
        }),
      ]);

      const newRound: BattleRound = {
        roundNumber,
        topic: currentBattle.topic,
        model1Response: result1.success
          ? result1.response || 'No response'
          : `Error: ${result1.error}`,
        model2Response: result2.success
          ? result2.response || 'No response'
          : `Error: ${result2.error}`,
        model1Score: 0,
        model2Score: 0,
        winner: null,
        timestamp: Date.now(),
        tokens: {
          model1: result1.tokensUsed?.total || 0,
          model2: result2.tokensUsed?.total || 0,
        },
        latency: {
          model1: 1500 + Math.random() * 500, // Approximate latency
          model2: 1500 + Math.random() * 500,
        },
      };

      setBattle(prev => {
        if (!prev) return null;
        const updatedRounds = [...prev.rounds, newRound];
        return { ...prev, rounds: updatedRounds };
      });
    } catch (error) {
      console.error('Error in battle round:', error);
      // Create error round
      const errorRound: BattleRound = {
        roundNumber,
        topic: currentBattle.topic,
        model1Response: 'Error generating response',
        model2Response: 'Error generating response',
        model1Score: 0,
        model2Score: 0,
        winner: null,
        timestamp: Date.now(),
        tokens: { model1: 0, model2: 0 },
        latency: { model1: 0, model2: 0 },
      };

      setBattle(prev => {
        if (!prev) return null;
        return { ...prev, rounds: [...prev.rounds, errorRound] };
      });
    }

    setIsProcessing(false);

    // Scroll to latest round
    setTimeout(() => {
      if (battleAreaRef.current) {
        battleAreaRef.current.scrollTop = battleAreaRef.current.scrollHeight;
      }
    }, 100);
  };

  // Generate Mock Responses (Keep as fallback - but we now use real AI)
  const generateMockResponses = (topic: string, round: number) => {
    const perspectives = [
      {
        model1: `In round ${round}, I'd argue that ${topic.toLowerCase()} presents a unique opportunity for innovation. The key factors to consider are scalability, ethical implications, and long-term sustainability. We must approach this with both optimism and caution, ensuring that technological advancement serves humanity's best interests.`,
        model2: `For round ${round}, I take a different stance on ${topic.toLowerCase()}. While innovation is important, we must prioritize human welfare and environmental impact. The rapid pace of change requires robust regulatory frameworks and careful consideration of unintended consequences. Progress without responsibility is dangerous.`,
      },
      {
        model1: `Building on the previous points in round ${round}, I believe that ${topic.toLowerCase()} offers solutions we cannot ignore. Data-driven approaches, combined with ethical guidelines, can help us navigate complex challenges. The potential benefits far outweigh the risks if we implement proper safeguards and maintain transparency.`,
        model2: `I respectfully disagree with that optimistic view in round ${round}. Regarding ${topic.toLowerCase()}, history shows us that unchecked enthusiasm leads to problems. We need democratic oversight, diverse perspectives in decision-making, and time to understand long-term implications. Moving too fast risks leaving vulnerable populations behind.`,
      },
      {
        model1: `In this final round ${round}, let me synthesize my position on ${topic.toLowerCase()}. The evidence supports a balanced approach that embraces progress while maintaining ethical standards. Through collaboration between technologists, policymakers, and communities, we can create positive outcomes that benefit everyone.`,
        model2: `Concluding round ${round}, my stance on ${topic.toLowerCase()} emphasizes precaution and inclusivity. Rather than rushing forward, we should engage in meaningful dialogue with all stakeholders. The best path forward is one that prioritizes human dignity, environmental stewardship, and equitable access to benefits.`,
      },
    ];

    const index = Math.min(round - 1, perspectives.length - 1);
    return perspectives[index];
  };

  // Submit Vote
  const submitVote = (roundNumber: number, winner: 'model1' | 'model2' | 'tie') => {
    setUserVotes(prev => ({ ...prev, [roundNumber]: winner }));

    setBattle(prev => {
      if (!prev) return null;

      const updatedRounds = prev.rounds.map(round => {
        if (round.roundNumber === roundNumber) {
          const scores = calculateScores(winner);
          return {
            ...round,
            model1Score: scores.model1,
            model2Score: scores.model2,
            winner,
          };
        }
        return round;
      });

      return { ...prev, rounds: updatedRounds };
    });
  };

  // Calculate Scores
  const calculateScores = (
    winner: 'model1' | 'model2' | 'tie'
  ): { model1: number; model2: number } => {
    if (winner === 'model1') return { model1: 10, model2: 0 };
    if (winner === 'model2') return { model1: 0, model2: 10 };
    return { model1: 5, model2: 5 }; // tie
  };

  // Calculate Final Winner
  const calculateWinner = () => {
    if (!battle) return;

    const model1Total = battle.rounds.reduce((sum, r) => sum + r.model1Score, 0);
    const model2Total = battle.rounds.reduce((sum, r) => sum + r.model2Score, 0);

    let winner: 'model1' | 'model2' | 'tie';
    if (model1Total > model2Total) winner = 'model1';
    else if (model2Total > model1Total) winner = 'model2';
    else winner = 'tie';

    setBattle(prev =>
      prev
        ? {
            ...prev,
            status: 'completed',
            overallWinner: winner,
            endTime: Date.now(),
          }
        : null
    );

    setShowResults(true);
    saveBattleHistory();
  };

  // Save Battle History
  const saveBattleHistory = () => {
    if (!battle) return;

    try {
      const history = JSON.parse(localStorage.getItem('ailab_global_history') || '[]');
      history.push({
        type: 'battle',
        ...battle,
        timestamp: Date.now(),
      });
      localStorage.setItem('ailab_global_history', JSON.stringify(history));
    } catch (e) {
      console.error('Failed to save battle:', e);
    }
  };

  // Next Round
  const nextRound = () => {
    if (!battle || battle.currentRound >= battle.totalRounds) return;
    runRound(battle, battle.currentRound + 1);
  };

  // Reset Battle
  const resetBattle = () => {
    setBattle(null);
    setSelectedModel1(null);
    setSelectedModel2(null);
    setTopic('');
    setShowResults(false);
    setUserVotes({});
  };

  // Get Total Scores
  const getTotalScores = () => {
    if (!battle) return { model1: 0, model2: 0 };
    return {
      model1: battle.rounds.reduce((sum, r) => sum + r.model1Score, 0),
      model2: battle.rounds.reduce((sum, r) => sum + r.model2Score, 0),
    };
  };

  const totalScores = getTotalScores();

  return (
    <div className="min-h-screen bg-black text-white pb-20">
      {/* Subscription Modal */}
      {showSubscriptionModal && (
        <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-gray-900 border border-gray-800 rounded-2xl p-8 max-w-md w-full text-center">
            <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-red-500 to-orange-600 rounded-full flex items-center justify-center">
              <Swords className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-white mb-3">AI Battle Arena Access Required</h2>
            <p className="text-gray-400 mb-6">
              The AI Battle Arena is a premium feature. Subscribe to unlock access to model
              competitions and advanced testing capabilities.
            </p>
            <div className="space-y-3">
              <button
                onClick={() => (window.location.href = '/pricing')}
                className="w-full bg-gradient-to-r from-red-600 to-orange-600 text-white px-6 py-3 rounded-lg font-semibold hover:from-red-500 hover:to-orange-500 transition-all"
              >
                Upgrade Now
              </button>
              <button
                onClick={() => onNavigate('ai-lab' as Page)}
                className="w-full bg-gray-800 hover:bg-gray-700 text-white px-6 py-3 rounded-lg font-semibold transition-all"
              >
                Back to AI Lab
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Full Page Barrier for Non-Subscribers */}
      {!subscriptionStatus.hasActiveSubscription && (
        <div className="fixed inset-0 z-40 bg-black/90 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-gray-900 border border-red-500/30 rounded-2xl p-8 max-w-lg w-full text-center">
            <div className="w-20 h-20 mx-auto mb-6 bg-gradient-to-r from-red-500 to-orange-600 rounded-full flex items-center justify-center">
              <Lock className="w-10 h-10 text-white" />
            </div>
            <h2 className="text-3xl font-bold text-white mb-4">Premium Feature Locked</h2>
            <p className="text-gray-400 mb-6 text-lg">
              AI Battle Arena requires an active subscription. Watch AI models compete in real-time
              debates and advanced testing scenarios.
            </p>
            <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4 mb-6">
              <p className="text-red-400 font-semibold">🔥 Battle Arena Features:</p>
              <ul className="text-sm text-gray-300 mt-2 space-y-1 text-left">
                <li>• Real-time AI model competitions</li>
                <li>• Multi-round debate scenarios</li>
                <li>• Performance analytics & scoring</li>
                <li>• Export battle results</li>
              </ul>
            </div>
            <button
              onClick={() => setShowSubscriptionModal(true)}
              className="w-full bg-gradient-to-r from-red-600 to-orange-600 text-white px-6 py-4 rounded-xl font-bold text-lg hover:from-red-500 hover:to-orange-500 transition-all shadow-lg"
            >
              Unlock Battle Arena
            </button>
          </div>
        </div>
      )}
      {/* Header */}
      <div className="sticky top-0 z-40 bg-black/95 backdrop-blur-xl border-b border-gray-800">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={() => onNavigate('ai-lab' as Page)}
                className="p-2 hover:bg-gray-800 rounded-lg transition-colors"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
              <div>
                <h1 className="text-2xl font-bold text-white flex items-center gap-2">
                  <Swords className="w-6 h-6 text-red-400" />
                  AI Battle Arena
                </h1>
                <p className="text-sm text-gray-400">
                  Watch AI models compete in real-time debates
                </p>
              </div>
            </div>

            {battle && (
              <div className="flex items-center gap-3">
                <div className="px-4 py-2 bg-gray-900 border border-gray-800 rounded-lg">
                  <span className="text-sm text-gray-400">Round </span>
                  <span className="text-lg font-bold text-cyan-400">
                    {battle.currentRound}/{battle.totalRounds}
                  </span>
                </div>
                <button
                  onClick={resetBattle}
                  className="px-4 py-2 bg-red-500/20 hover:bg-red-500/30 border border-red-500/50 text-red-400 rounded-lg transition-colors"
                >
                  New Battle
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="container mx-auto px-6 py-8">
        {!battle ? (
          // Setup Phase
          <div className="max-w-5xl mx-auto">
            {/* Model Selection */}
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
                <Target className="w-6 h-6 text-cyan-400" />
                Choose Your Fighters
              </h2>

              <div className="grid md:grid-cols-2 gap-6">
                {/* Model 1 Selection */}
                <div>
                  <label className="block text-sm font-semibold text-gray-400 mb-3">
                    Fighter 1
                  </label>
                  <div className="space-y-3">
                    {models.map(model => (
                      <button
                        key={`m1-${model.id}`}
                        onClick={() => setSelectedModel1(model)}
                        disabled={selectedModel2?.id === model.id}
                        className={`w-full p-4 rounded-xl border-2 transition-all text-left ${
                          selectedModel1?.id === model.id
                            ? `bg-gradient-to-r ${model.color} border-transparent shadow-lg`
                            : 'bg-gray-900/50 border-gray-800 hover:border-gray-700'
                        } ${selectedModel2?.id === model.id ? 'opacity-50 cursor-not-allowed' : ''}`}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <span className="text-3xl">{model.icon}</span>
                            <div>
                              <p className="font-semibold text-white">{model.name}</p>
                              <p className="text-xs text-gray-400">{model.provider}</p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="text-xs text-gray-400">Win Rate</p>
                            <p className="text-sm font-bold text-white">
                              {((model.wins / (model.wins + model.losses)) * 100).toFixed(0)}%
                            </p>
                          </div>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Model 2 Selection */}
                <div>
                  <label className="block text-sm font-semibold text-gray-400 mb-3">
                    Fighter 2
                  </label>
                  <div className="space-y-3">
                    {models.map(model => (
                      <button
                        key={`m2-${model.id}`}
                        onClick={() => setSelectedModel2(model)}
                        disabled={selectedModel1?.id === model.id}
                        className={`w-full p-4 rounded-xl border-2 transition-all text-left ${
                          selectedModel2?.id === model.id
                            ? `bg-gradient-to-r ${model.color} border-transparent shadow-lg`
                            : 'bg-gray-900/50 border-gray-800 hover:border-gray-700'
                        } ${selectedModel1?.id === model.id ? 'opacity-50 cursor-not-allowed' : ''}`}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <span className="text-3xl">{model.icon}</span>
                            <div>
                              <p className="font-semibold text-white">{model.name}</p>
                              <p className="text-xs text-gray-400">{model.provider}</p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="text-xs text-gray-400">Avg Score</p>
                            <p className="text-sm font-bold text-white">{model.avgScore}/10</p>
                          </div>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Battle Configuration */}
            <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-6 mb-6">
              <h3 className="text-lg font-semibold text-white mb-4">Battle Topic</h3>

              <textarea
                value={topic}
                onChange={e => setTopic(e.target.value)}
                placeholder="Enter a debate topic or question..."
                className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-cyan-500 resize-none mb-4"
                rows={3}
              />

              {/* Popular Topics */}
              <div className="mb-4">
                <p className="text-sm text-gray-400 mb-2">Popular Topics:</p>
                <div className="flex flex-wrap gap-2">
                  {popularTopics.slice(0, 4).map((t, i) => (
                    <button
                      key={i}
                      onClick={() => setTopic(t)}
                      className="px-3 py-1.5 bg-gray-800 hover:bg-gray-700 border border-gray-700 rounded-lg text-xs text-gray-300 transition-colors"
                    >
                      {t}
                    </button>
                  ))}
                </div>
              </div>

              {/* Rounds */}
              <div>
                <label className="block text-sm font-semibold text-gray-400 mb-2">
                  Number of Rounds: {totalRounds}
                </label>
                <input
                  type="range"
                  min="1"
                  max="5"
                  value={totalRounds}
                  onChange={e => setTotalRounds(parseInt(e.target.value))}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-gray-500 mt-1">
                  <span>1 (Quick)</span>
                  <span>3 (Standard)</span>
                  <span>5 (Epic)</span>
                </div>
              </div>
            </div>

            {/* Start Battle Button */}
            <button
              onClick={startBattle}
              disabled={!selectedModel1 || !selectedModel2 || !topic.trim()}
              className="w-full py-4 bg-gradient-to-r from-red-600 to-orange-600 hover:from-red-500 hover:to-orange-500 disabled:from-gray-700 disabled:to-gray-700 text-white font-bold text-lg rounded-xl shadow-lg transition-all disabled:cursor-not-allowed flex items-center justify-center gap-3"
            >
              <Flame className="w-6 h-6" />
              Start Battle!
            </button>
          </div>
        ) : (
          // Battle Phase
          <div className="max-w-7xl mx-auto">
            {/* Scoreboard */}
            <div className="grid grid-cols-3 gap-4 mb-6">
              {/* Model 1 Stats */}
              <div className={`bg-gradient-to-br ${selectedModel1!.color} p-6 rounded-xl`}>
                <div className="flex items-center gap-3 mb-4">
                  <span className="text-4xl">{selectedModel1!.icon}</span>
                  <div>
                    <p className="font-bold text-white text-lg">{selectedModel1!.name}</p>
                    <p className="text-sm opacity-90">{selectedModel1!.provider}</p>
                  </div>
                </div>
                <div className="text-center">
                  <p className="text-5xl font-bold text-white mb-1">{totalScores.model1}</p>
                  <p className="text-sm opacity-90">Points</p>
                </div>
              </div>

              {/* VS */}
              <div className="bg-gray-900/50 border border-gray-800 rounded-xl flex items-center justify-center">
                <div className="text-center">
                  <Swords className="w-12 h-12 text-red-400 mx-auto mb-2" />
                  <p className="text-2xl font-bold text-white">VS</p>
                  <p className="text-sm text-gray-400 mt-2">
                    {battle.status === 'active'
                      ? 'Battle in Progress'
                      : battle.status === 'completed'
                        ? 'Battle Complete'
                        : 'Ready to Start'}
                  </p>
                </div>
              </div>

              {/* Model 2 Stats */}
              <div className={`bg-gradient-to-br ${selectedModel2!.color} p-6 rounded-xl`}>
                <div className="flex items-center gap-3 mb-4">
                  <span className="text-4xl">{selectedModel2!.icon}</span>
                  <div>
                    <p className="font-bold text-white text-lg">{selectedModel2!.name}</p>
                    <p className="text-sm opacity-90">{selectedModel2!.provider}</p>
                  </div>
                </div>
                <div className="text-center">
                  <p className="text-5xl font-bold text-white mb-1">{totalScores.model2}</p>
                  <p className="text-sm opacity-90">Points</p>
                </div>
              </div>
            </div>

            {/* Battle Arena */}
            <div
              ref={battleAreaRef}
              className="bg-gray-900/50 border border-gray-800 rounded-xl p-6 mb-6 max-h-[600px] overflow-y-auto"
            >
              <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-cyan-400" />
                Topic: {battle.topic}
              </h3>

              {battle.rounds.length === 0 && (
                <div className="text-center py-12 text-gray-400">
                  <Sparkles className="w-16 h-16 mx-auto mb-4 opacity-30" />
                  <p>Waiting for first round...</p>
                </div>
              )}

              {/* Rounds */}
              <div className="space-y-6">
                {battle.rounds.map(round => (
                  <div key={round.roundNumber} className="border border-gray-800 rounded-xl p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="text-lg font-bold text-white">Round {round.roundNumber}</h4>
                      {round.winner && (
                        <div
                          className={`px-3 py-1 rounded-full text-sm font-semibold ${
                            round.winner === 'model1'
                              ? 'bg-green-500/20 text-green-400'
                              : round.winner === 'model2'
                                ? 'bg-purple-500/20 text-purple-400'
                                : 'bg-yellow-500/20 text-yellow-400'
                          }`}
                        >
                          {round.winner === 'tie'
                            ? '🤝 Tie'
                            : round.winner === 'model1'
                              ? `🏆 ${selectedModel1!.name}`
                              : `🏆 ${selectedModel2!.name}`}
                        </div>
                      )}
                    </div>

                    <div className="grid md:grid-cols-2 gap-4 mb-4">
                      {/* Model 1 Response */}
                      <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-4">
                        <div className="flex items-center gap-2 mb-3">
                          <span className="text-2xl">{selectedModel1!.icon}</span>
                          <span className="font-semibold text-white">{selectedModel1!.name}</span>
                        </div>
                        <p className="text-sm text-gray-300 leading-relaxed mb-3">
                          {round.model1Response}
                        </p>
                        <div className="flex items-center gap-3 text-xs text-gray-500">
                          <span>
                            <Clock className="w-3 h-3 inline" /> {Math.round(round.latency.model1)}
                            ms
                          </span>
                          <span>
                            <Hash className="w-3 h-3 inline" /> {round.tokens.model1} tokens
                          </span>
                        </div>
                      </div>

                      {/* Model 2 Response */}
                      <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-4">
                        <div className="flex items-center gap-2 mb-3">
                          <span className="text-2xl">{selectedModel2!.icon}</span>
                          <span className="font-semibold text-white">{selectedModel2!.name}</span>
                        </div>
                        <p className="text-sm text-gray-300 leading-relaxed mb-3">
                          {round.model2Response}
                        </p>
                        <div className="flex items-center gap-3 text-xs text-gray-500">
                          <span>
                            <Clock className="w-3 h-3 inline" /> {Math.round(round.latency.model2)}
                            ms
                          </span>
                          <span>
                            <Hash className="w-3 h-3 inline" /> {round.tokens.model2} tokens
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Voting */}
                    {!userVotes[round.roundNumber] && battle.status === 'active' && (
                      <div className="flex items-center justify-center gap-3">
                        <button
                          onClick={() => submitVote(round.roundNumber, 'model1')}
                          className="px-6 py-2 bg-green-500/20 hover:bg-green-500/30 border border-green-500/50 text-green-400 rounded-lg transition-colors flex items-center gap-2"
                        >
                          <ThumbsUp className="w-4 h-4" />
                          Vote {selectedModel1!.name}
                        </button>
                        <button
                          onClick={() => submitVote(round.roundNumber, 'tie')}
                          className="px-6 py-2 bg-yellow-500/20 hover:bg-yellow-500/30 border border-yellow-500/50 text-yellow-400 rounded-lg transition-colors"
                        >
                          Tie
                        </button>
                        <button
                          onClick={() => submitVote(round.roundNumber, 'model2')}
                          className="px-6 py-2 bg-purple-500/20 hover:bg-purple-500/30 border border-purple-500/50 text-purple-400 rounded-lg transition-colors flex items-center gap-2"
                        >
                          <ThumbsUp className="w-4 h-4" />
                          Vote {selectedModel2!.name}
                        </button>
                      </div>
                    )}

                    {userVotes[round.roundNumber] && (
                      <div className="text-center text-sm text-gray-400">✓ Vote recorded</div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Controls */}
            <div className="flex items-center justify-center gap-4">
              {battle.status === 'active' && battle.currentRound < battle.totalRounds && (
                <button
                  onClick={nextRound}
                  disabled={isProcessing || !userVotes[battle.currentRound]}
                  className="px-8 py-4 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 disabled:from-gray-700 disabled:to-gray-700 text-white font-bold rounded-xl shadow-lg transition-all disabled:cursor-not-allowed flex items-center gap-2"
                >
                  {isProcessing ? (
                    <>
                      <RefreshCw className="w-5 h-5 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    <>
                      <ChevronRight className="w-5 h-5" />
                      Next Round
                    </>
                  )}
                </button>
              )}

              {battle.currentRound === battle.totalRounds &&
                battle.rounds.length === battle.totalRounds &&
                Object.keys(userVotes).length === battle.totalRounds &&
                battle.status !== 'completed' && (
                  <button
                    onClick={calculateWinner}
                    className="px-8 py-4 bg-gradient-to-r from-yellow-600 to-orange-600 hover:from-yellow-500 hover:to-orange-500 text-white font-bold rounded-xl shadow-lg transition-all flex items-center gap-2"
                  >
                    <Trophy className="w-5 h-5" />
                    Declare Winner!
                  </button>
                )}
            </div>

            {/* Results Modal */}
            {showResults && battle.overallWinner && (
              <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-6">
                <div className="bg-gray-900 border border-gray-800 rounded-2xl p-8 max-w-2xl w-full">
                  <div className="text-center mb-6">
                    <Crown className="w-16 h-16 text-yellow-400 mx-auto mb-4" />
                    <h2 className="text-3xl font-bold text-white mb-2">Battle Complete!</h2>
                    <p className="text-gray-400">Winner has been determined</p>
                  </div>

                  <div className="bg-gradient-to-r from-yellow-500/20 to-orange-500/20 border border-yellow-500/30 rounded-xl p-6 mb-6">
                    <p className="text-sm text-gray-400 mb-2 text-center">Champion</p>
                    {battle.overallWinner === 'tie' ? (
                      <div className="text-center">
                        <p className="text-4xl font-bold text-yellow-400 mb-2">It's a Tie!</p>
                        <p className="text-gray-300">Both models performed equally well</p>
                      </div>
                    ) : (
                      <div className="text-center">
                        <p className="text-5xl mb-3">
                          {battle.overallWinner === 'model1'
                            ? selectedModel1!.icon
                            : selectedModel2!.icon}
                        </p>
                        <p className="text-3xl font-bold text-white mb-2">
                          {battle.overallWinner === 'model1'
                            ? selectedModel1!.name
                            : selectedModel2!.name}
                        </p>
                        <p className="text-xl text-cyan-400">
                          {battle.overallWinner === 'model1'
                            ? totalScores.model1
                            : totalScores.model2}{' '}
                          Points
                        </p>
                      </div>
                    )}
                  </div>

                  <div className="grid grid-cols-2 gap-4 mb-6">
                    <div className="text-center p-4 bg-gray-800/50 rounded-lg">
                      <p className="text-sm text-gray-400 mb-1">Total Rounds</p>
                      <p className="text-2xl font-bold text-white">{battle.totalRounds}</p>
                    </div>
                    <div className="text-center p-4 bg-gray-800/50 rounded-lg">
                      <p className="text-sm text-gray-400 mb-1">Duration</p>
                      <p className="text-2xl font-bold text-white">
                        {Math.round((battle.endTime! - battle.startTime) / 1000)}s
                      </p>
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <button
                      onClick={resetBattle}
                      className="flex-1 px-6 py-3 bg-cyan-600 hover:bg-cyan-500 text-white font-semibold rounded-xl transition-colors"
                    >
                      New Battle
                    </button>
                    <button
                      onClick={() => setShowResults(false)}
                      className="flex-1 px-6 py-3 bg-gray-800 hover:bg-gray-700 text-white font-semibold rounded-xl transition-colors"
                    >
                      Close
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default AILabBattlePage;
