import React, { useState, useEffect } from 'react';
import {
  BookOpen,
  Star,
  Download,
  Upload,
  Share2,
  Heart,
  Search,
  Filter,
  Plus,
  Eye,
  Copy,
  Trash2,
  Edit2,
  Info,
  Lock,
  Crown,
} from 'lucide-react';
import { authService } from '../../services/authService';

interface Template {
  id: string;
  title: string;
  description: string;
  category: string;
  prompt: string;
  variables: string[];
  author: string;
  rating: number;
  downloads: number;
  favorites: number;
  createdAt: number;
  isPublic: boolean;
  isFavorite: boolean;
}

interface Category {
  id: string;
  name: string;
  icon: string;
  color: string;
}

interface SubscriptionStatus {
  hasAccess: boolean;
  type: string;
  expiresAt?: Date;
  usageToday: number;
  usageLimit: number;
  hasActiveSubscription: boolean;
}

const CATEGORIES: Category[] = [
  { id: 'all', name: 'All Templates', icon: '📚', color: 'cyan' },
  { id: 'writing', name: 'Writing', icon: '✍️', color: 'blue' },
  { id: 'coding', name: 'Coding', icon: '💻', color: 'green' },
  { id: 'business', name: 'Business', icon: '💼', color: 'purple' },
  { id: 'education', name: 'Education', icon: '🎓', color: 'yellow' },
  { id: 'creative', name: 'Creative', icon: '🎨', color: 'pink' },
  { id: 'personal', name: 'Personal', icon: '👤', color: 'orange' },
];

const SAMPLE_TEMPLATES: Template[] = [
  {
    id: 'template-1',
    title: 'Blog Post Outline',
    description: 'Generate a comprehensive blog post outline with key points and structure',
    category: 'writing',
    prompt:
      'Create a detailed blog post outline about {topic} targeting {audience}. Include an introduction, 5 main sections with key points, and a conclusion.',
    variables: ['topic', 'audience'],
    author: 'AI Lab Community',
    rating: 4.8,
    downloads: 1234,
    favorites: 567,
    createdAt: Date.now() - 7 * 24 * 60 * 60 * 1000,
    isPublic: true,
    isFavorite: false,
  },
  {
    id: 'template-2',
    title: 'Code Review Assistant',
    description: 'Get detailed code review feedback with suggestions for improvement',
    category: 'coding',
    prompt:
      'Review this {language} code and provide feedback on:\n1. Code quality and style\n2. Performance optimizations\n3. Security concerns\n4. Best practices\n\nCode:\n{code}',
    variables: ['language', 'code'],
    author: 'DevTools',
    rating: 4.9,
    downloads: 2456,
    favorites: 890,
    createdAt: Date.now() - 14 * 24 * 60 * 60 * 1000,
    isPublic: true,
    isFavorite: true,
  },
  {
    id: 'template-3',
    title: 'Product Description',
    description: 'Create compelling product descriptions that convert',
    category: 'business',
    prompt:
      'Write a compelling product description for {product_name}. Target audience: {target_audience}. Key features: {features}. Use persuasive language and highlight benefits.',
    variables: ['product_name', 'target_audience', 'features'],
    author: 'Marketing Pro',
    rating: 4.6,
    downloads: 987,
    favorites: 432,
    createdAt: Date.now() - 21 * 24 * 60 * 60 * 1000,
    isPublic: true,
    isFavorite: false,
  },
];

const AILabTemplatesPage: React.FC<{ onNavigate: (page: string) => void }> = ({ onNavigate }) => {
  // Subscription State
  const [subscriptionStatus, setSubscriptionStatus] = useState<SubscriptionStatus>({
    hasAccess: false,
    type: 'free',
    usageToday: 0,
    usageLimit: 0,
    hasActiveSubscription: false,
  });

  // Check subscription status
  useEffect(() => {
    const checkSubscription = async () => {
      try {
        const hasActiveSubscription = false; // Set to false for testing subscription barrier
        setSubscriptionStatus({
          hasAccess: hasActiveSubscription,
          type: hasActiveSubscription ? 'premium' : 'free',
          usageToday: 0,
          usageLimit: hasActiveSubscription ? 1000 : 5,
          hasActiveSubscription,
        });
      } catch (error) {
        console.error('Error checking subscription:', error);
      }
    };
    checkSubscription();
  }, []);

  const [templates, setTemplates] = useState<Template[]>(SAMPLE_TEMPLATES);
  const [filteredTemplates, setFilteredTemplates] = useState<Template[]>(SAMPLE_TEMPLATES);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [showFavoritesOnly, setShowFavoritesOnly] = useState(false);
  const [sortBy, setSortBy] = useState<'recent' | 'popular' | 'rating'>('popular');
  const [selectedTemplate, setSelectedTemplate] = useState<Template | null>(null);
  const [showNewTemplateForm, setShowNewTemplateForm] = useState(false);
  const [showInfo, setShowInfo] = useState(false);

  // Form state
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: 'writing',
    prompt: '',
    variables: [] as string[],
    isPublic: true,
  });

  // Load templates from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('ailab_templates');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setTemplates([...SAMPLE_TEMPLATES, ...parsed]);
      } catch (e) {
        console.error('Failed to load templates:', e);
      }
    }
  }, []);

  // Apply filters
  useEffect(() => {
    let filtered = [...templates];

    // Category filter
    if (selectedCategory !== 'all') {
      filtered = filtered.filter(t => t.category === selectedCategory);
    }

    // Favorites filter
    if (showFavoritesOnly) {
      filtered = filtered.filter(t => t.isFavorite);
    }

    // Search filter
    if (searchTerm.trim()) {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter(
        t =>
          t.title.toLowerCase().includes(term) ||
          t.description.toLowerCase().includes(term) ||
          t.prompt.toLowerCase().includes(term)
      );
    }

    // Sort
    switch (sortBy) {
      case 'recent':
        filtered.sort((a, b) => b.createdAt - a.createdAt);
        break;
      case 'popular':
        filtered.sort((a, b) => b.downloads - a.downloads);
        break;
      case 'rating':
        filtered.sort((a, b) => b.rating - a.rating);
        break;
    }

    setFilteredTemplates(filtered);
  }, [templates, selectedCategory, showFavoritesOnly, searchTerm, sortBy]);

  // Save templates
  const saveTemplates = (updatedTemplates: Template[]) => {
    setTemplates(updatedTemplates);
    const userTemplates = updatedTemplates.filter(t => !SAMPLE_TEMPLATES.find(s => s.id === t.id));
    localStorage.setItem('ailab_templates', JSON.stringify(userTemplates));
  };

  // Toggle favorite
  const toggleFavorite = (templateId: string) => {
    const updated = templates.map(t =>
      t.id === templateId ? { ...t, isFavorite: !t.isFavorite } : t
    );
    saveTemplates(updated);
  };

  // Use template (increment downloads)
  const useTemplate = (template: Template) => {
    const updated = templates.map(t =>
      t.id === template.id ? { ...t, downloads: t.downloads + 1 } : t
    );
    saveTemplates(updated);

    // Copy prompt to clipboard
    navigator.clipboard.writeText(template.prompt);
  };

  // Add new template
  const addTemplate = () => {
    if (!formData.title.trim() || !formData.prompt.trim()) {
      alert('Please fill in title and prompt');
      return;
    }

    // Extract variables from prompt
    const variableMatches = formData.prompt.match(/\{([^}]+)\}/g);
    const variables = variableMatches ? variableMatches.map(v => v.replace(/[{}]/g, '')) : [];

    const newTemplate: Template = {
      id: `template-${Date.now()}`,
      title: formData.title,
      description: formData.description,
      category: formData.category,
      prompt: formData.prompt,
      variables,
      author: 'You',
      rating: 0,
      downloads: 0,
      favorites: 0,
      createdAt: Date.now(),
      isPublic: formData.isPublic,
      isFavorite: false,
    };

    saveTemplates([...templates, newTemplate]);
    resetForm();
    setShowNewTemplateForm(false);
  };

  // Delete template
  const deleteTemplate = (templateId: string) => {
    if (confirm('Are you sure you want to delete this template?')) {
      const updated = templates.filter(t => t.id !== templateId);
      saveTemplates(updated);
      if (selectedTemplate?.id === templateId) {
        setSelectedTemplate(null);
      }
    }
  };

  // Reset form
  const resetForm = () => {
    setFormData({
      title: '',
      description: '',
      category: 'writing',
      prompt: '',
      variables: [],
      isPublic: true,
    });
  };

  // Export templates
  const exportTemplates = () => {
    const data = {
      exported: new Date().toISOString(),
      templates: templates.filter(t => t.author === 'You'),
    };

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ailab-templates-${Date.now()}.json`;
    a.click();
  };

  // Import templates
  const importTemplates = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = e => {
      try {
        const data = JSON.parse(e.target?.result as string);
        if (data.templates && Array.isArray(data.templates)) {
          saveTemplates([...templates, ...data.templates]);
        }
      } catch (err) {
        alert('Failed to import templates');
      }
    };
    reader.readAsText(file);
  };

  // Render rating stars
  const renderStars = (rating: number) => {
    const stars = [];
    for (let i = 0; i < 5; i++) {
      stars.push(
        <Star
          key={i}
          className={`w-4 h-4 ${
            i < Math.floor(rating) ? 'fill-yellow-400 text-yellow-400' : 'text-gray-600'
          }`}
        />
      );
    }
    return stars;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 text-white relative">
      {/* Subscription Access Barrier */}
      {!subscriptionStatus.hasActiveSubscription && (
        <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-gray-900 border border-gray-800 rounded-2xl p-8 max-w-md w-full text-center">
            <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-pink-500 to-rose-600 rounded-full flex items-center justify-center">
              <Crown className="w-8 h-8 text-black" />
            </div>
            <h2 className="text-2xl font-bold text-white mb-3">Templates Lab Access Required</h2>
            <p className="text-gray-400 mb-6">
              Professional Prompt Templates & Library is a premium feature. Subscribe to unlock the
              complete template library, custom templates, and professional prompt collections.
            </p>
            <div className="flex flex-col gap-3 mb-6">
              <div className="flex items-center gap-2 text-sm text-gray-300">
                <Lock className="w-4 h-4 text-pink-400" />
                <span>Professional template library</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-300">
                <BookOpen className="w-4 h-4 text-rose-400" />
                <span>Custom template creation</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-300">
                <Star className="w-4 h-4 text-pink-400" />
                <span>Premium prompt collections</span>
              </div>
            </div>
            <div className="flex flex-col sm:flex-row gap-3">
              <button
                onClick={() => onNavigate('subscription')}
                className="flex-1 bg-gradient-to-r from-pink-600 to-rose-600 text-white px-6 py-3 rounded-lg font-semibold hover:from-pink-500 hover:to-rose-500 transition-all flex items-center justify-center gap-2"
              >
                <Crown className="w-4 h-4" />
                Subscribe Now
              </button>
              <button
                onClick={() => onNavigate('ai-lab')}
                className="flex-1 bg-gray-800 hover:bg-gray-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors"
              >
                Back to Lab
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="border-b border-cyan-500/20 bg-black/40 backdrop-blur-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => onNavigate('ai-lab')}
                className="text-cyan-400 hover:text-cyan-300 transition-colors"
              >
                ← Back to Hub
              </button>
              <div className="flex items-center space-x-2">
                <BookOpen className="w-6 h-6 text-cyan-400" />
                <h1 className="text-2xl font-bold bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent">
                  Template Library
                </h1>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <button
                onClick={() => setShowInfo(!showInfo)}
                className="p-2 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/20 transition-colors border border-cyan-500/30"
              >
                <Info className="w-5 h-5 text-cyan-400" />
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Sidebar */}
          <div className="space-y-6">
            {/* Actions */}
            <div className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm rounded-xl border border-cyan-500/20 p-6">
              <div className="space-y-3">
                <button
                  onClick={() => setShowNewTemplateForm(!showNewTemplateForm)}
                  className="w-full py-3 bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 rounded-lg font-semibold transition-all flex items-center justify-center space-x-2"
                >
                  <Plus className="w-5 h-5" />
                  <span>New Template</span>
                </button>
                <button
                  onClick={exportTemplates}
                  className="w-full py-3 bg-gray-700/50 hover:bg-gray-700 rounded-lg font-semibold transition-all flex items-center justify-center space-x-2"
                >
                  <Download className="w-5 h-5" />
                  <span>Export</span>
                </button>
                <label className="w-full py-3 bg-gray-700/50 hover:bg-gray-700 rounded-lg font-semibold transition-all flex items-center justify-center space-x-2 cursor-pointer">
                  <Upload className="w-5 h-5" />
                  <span>Import</span>
                  <input type="file" accept=".json" onChange={importTemplates} className="hidden" />
                </label>
              </div>
            </div>

            {/* Categories */}
            <div className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm rounded-xl border border-cyan-500/20 p-6">
              <h2 className="text-lg font-semibold mb-4 flex items-center">
                <Filter className="w-5 h-5 text-cyan-400 mr-2" />
                Categories
              </h2>
              <div className="space-y-2">
                {CATEGORIES.map(category => {
                  const count = templates.filter(
                    t => category.id === 'all' || t.category === category.id
                  ).length;

                  return (
                    <button
                      key={category.id}
                      onClick={() => setSelectedCategory(category.id)}
                      className={`w-full p-3 rounded-lg border transition-all text-left ${
                        selectedCategory === category.id
                          ? `bg-${category.color}-500/20 border-${category.color}-400`
                          : 'bg-gray-800/50 border-gray-700 hover:border-gray-600'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <span>{category.icon}</span>
                          <span className="text-sm">{category.name}</span>
                        </div>
                        <span className="text-xs text-gray-400">{count}</span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Filters */}
            <div className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm rounded-xl border border-cyan-500/20 p-6">
              <h2 className="text-lg font-semibold mb-4">Filters</h2>
              <div className="space-y-3">
                <button
                  onClick={() => setShowFavoritesOnly(!showFavoritesOnly)}
                  className={`w-full p-3 rounded-lg border transition-all flex items-center justify-between ${
                    showFavoritesOnly
                      ? 'bg-pink-500/20 border-pink-400'
                      : 'bg-gray-800/50 border-gray-700 hover:border-gray-600'
                  }`}
                >
                  <span className="text-sm">Favorites Only</span>
                  <Heart
                    className={`w-4 h-4 ${showFavoritesOnly ? 'fill-pink-400 text-pink-400' : ''}`}
                  />
                </button>

                <div>
                  <label className="text-sm text-gray-400 mb-2 block">Sort By</label>
                  <select
                    value={sortBy}
                    onChange={e => setSortBy(e.target.value as any)}
                    className="w-full px-3 py-2 bg-black/40 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-cyan-500"
                  >
                    <option value="popular">Most Popular</option>
                    <option value="rating">Highest Rated</option>
                    <option value="recent">Most Recent</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Info Panel */}
            {showInfo && (
              <div className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm rounded-xl border border-cyan-500/20 p-6">
                <h2 className="text-lg font-semibold mb-4 flex items-center">
                  <Info className="w-5 h-5 text-cyan-400 mr-2" />
                  About Templates
                </h2>
                <div className="space-y-3 text-sm text-gray-300">
                  <p>Browse, create, and share prompt templates for AI interactions.</p>
                  <div>
                    <div className="font-semibold text-white mb-1">Features:</div>
                    <ul className="list-disc list-inside space-y-1 text-gray-400">
                      <li>Community marketplace</li>
                      <li>Custom variables</li>
                      <li>Import/Export templates</li>
                      <li>Rating & favorites</li>
                      <li>Category filtering</li>
                    </ul>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3 space-y-6">
            {/* Search Bar */}
            <div className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm rounded-xl border border-cyan-500/20 p-4">
              <div className="flex items-center space-x-3">
                <Search className="w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={e => setSearchTerm(e.target.value)}
                  placeholder="Search templates..."
                  className="flex-1 bg-transparent border-none text-white placeholder-gray-500 focus:outline-none"
                />
              </div>
            </div>

            {/* New Template Form */}
            {showNewTemplateForm && (
              <div className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm rounded-xl border border-cyan-500/20 p-6">
                <h2 className="text-lg font-semibold mb-4">Create New Template</h2>
                <div className="space-y-4">
                  <div>
                    <label className="text-sm text-gray-400 mb-2 block">Title</label>
                    <input
                      type="text"
                      value={formData.title}
                      onChange={e => setFormData({ ...formData, title: e.target.value })}
                      placeholder="Template title"
                      className="w-full px-4 py-3 bg-black/40 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500"
                    />
                  </div>
                  <div>
                    <label className="text-sm text-gray-400 mb-2 block">Description</label>
                    <textarea
                      value={formData.description}
                      onChange={e => setFormData({ ...formData, description: e.target.value })}
                      placeholder="Brief description"
                      className="w-full h-20 px-4 py-3 bg-black/40 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500 resize-none"
                    />
                  </div>
                  <div>
                    <label className="text-sm text-gray-400 mb-2 block">Category</label>
                    <select
                      value={formData.category}
                      onChange={e => setFormData({ ...formData, category: e.target.value })}
                      className="w-full px-4 py-3 bg-black/40 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-cyan-500"
                    >
                      {CATEGORIES.filter(c => c.id !== 'all').map(c => (
                        <option key={c.id} value={c.id}>
                          {c.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="text-sm text-gray-400 mb-2 block">
                      Prompt (use {'{variable}'} for dynamic values)
                    </label>
                    <textarea
                      value={formData.prompt}
                      onChange={e => setFormData({ ...formData, prompt: e.target.value })}
                      placeholder="Your prompt template with {variables}..."
                      className="w-full h-32 px-4 py-3 bg-black/40 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500 resize-none"
                    />
                  </div>
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      checked={formData.isPublic}
                      onChange={e => setFormData({ ...formData, isPublic: e.target.checked })}
                      className="rounded"
                    />
                    <label className="text-sm">Make public (share with community)</label>
                  </div>
                  <div className="flex space-x-3">
                    <button
                      onClick={addTemplate}
                      className="flex-1 py-3 bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 rounded-lg font-semibold transition-all"
                    >
                      Create Template
                    </button>
                    <button
                      onClick={() => setShowNewTemplateForm(false)}
                      className="flex-1 py-3 bg-gray-700/50 hover:bg-gray-700 rounded-lg font-semibold transition-all"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Results Count */}
            <div className="text-sm text-gray-400">
              Showing {filteredTemplates.length} of {templates.length} templates
            </div>

            {/* Templates Grid */}
            {filteredTemplates.length === 0 ? (
              <div className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm rounded-xl border border-cyan-500/20 p-12 text-center">
                <BookOpen className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">No Templates Found</h3>
                <p className="text-gray-400">
                  Try adjusting your filters or create a new template.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filteredTemplates.map(template => (
                  <div
                    key={template.id}
                    className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm rounded-xl border border-gray-700 hover:border-cyan-500/50 transition-all p-6 cursor-pointer"
                    onClick={() =>
                      setSelectedTemplate(selectedTemplate?.id === template.id ? null : template)
                    }
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <h3 className="font-semibold text-lg mb-1">{template.title}</h3>
                        <p className="text-sm text-gray-400 line-clamp-2">{template.description}</p>
                      </div>
                      <button
                        onClick={e => {
                          e.stopPropagation();
                          toggleFavorite(template.id);
                        }}
                        className="p-2 hover:bg-gray-700/50 rounded-lg transition-colors"
                      >
                        <Heart
                          className={`w-5 h-5 ${template.isFavorite ? 'fill-pink-400 text-pink-400' : 'text-gray-400'}`}
                        />
                      </button>
                    </div>

                    <div className="flex items-center space-x-4 mb-3 text-sm">
                      <div className="flex items-center space-x-1">
                        {renderStars(template.rating)}
                        <span className="text-gray-400 ml-1">{template.rating.toFixed(1)}</span>
                      </div>
                      <div className="text-gray-400">{template.downloads} uses</div>
                    </div>

                    {selectedTemplate?.id === template.id && (
                      <div className="mt-4 pt-4 border-t border-gray-700 space-y-3">
                        <div>
                          <div className="text-xs text-gray-400 mb-1">Variables:</div>
                          <div className="flex flex-wrap gap-2">
                            {template.variables.map(v => (
                              <span
                                key={v}
                                className="px-2 py-1 bg-cyan-500/20 text-cyan-400 text-xs rounded"
                              >
                                {'{' + v + '}'}
                              </span>
                            ))}
                          </div>
                        </div>
                        <div>
                          <div className="text-xs text-gray-400 mb-1">Prompt:</div>
                          <div className="p-3 bg-black/40 rounded text-sm text-gray-300 max-h-32 overflow-y-auto">
                            {template.prompt}
                          </div>
                        </div>
                        <div className="flex space-x-2">
                          <button
                            onClick={e => {
                              e.stopPropagation();
                              useTemplate(template);
                            }}
                            className="flex-1 py-2 bg-cyan-500/20 hover:bg-cyan-500/30 rounded-lg transition-colors border border-cyan-500/30 flex items-center justify-center space-x-2"
                          >
                            <Copy className="w-4 h-4" />
                            <span className="text-sm">Use Template</span>
                          </button>
                          {template.author === 'You' && (
                            <button
                              onClick={e => {
                                e.stopPropagation();
                                deleteTemplate(template.id);
                              }}
                              className="p-2 bg-red-500/20 hover:bg-red-500/30 rounded-lg transition-colors border border-red-500/30"
                            >
                              <Trash2 className="w-4 h-4 text-red-400" />
                            </button>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AILabTemplatesPage;
