import React, { useState, useEffect } from 'react';
import {
  Calculator,
  DollarSign,
  TrendingUp,
  Clock,
  BarChart3,
  PieChart,
  Zap,
  AlertCircle,
  Download,
  Copy,
  History,
  Info,
  RefreshCw,
  Lock,
  Crown,
} from 'lucide-react';
import { authService } from '../../services/authService';

interface TokenizerType {
  id: string;
  name: string;
  provider: string;
  icon: string;
}

interface ModelPricing {
  id: string;
  name: string;
  provider: string;
  inputCostPer1M: number;
  outputCostPer1M: number;
  contextWindow: number;
  color: string;
}

interface CostResult {
  id: string;
  modelId: string;
  modelName: string;
  text: string;
  tokenCount: number;
  inputTokens: number;
  outputTokens: number;
  inputCost: number;
  outputCost: number;
  totalCost: number;
  timestamp: number;
}

interface BudgetTracking {
  monthlyBudget: number;
  currentSpend: number;
  projectedSpend: number;
  daysRemaining: number;
}

interface SubscriptionStatus {
  hasActiveSubscription: boolean;
  subscriptionType: string | null;
  isLoading: boolean;
}

interface SubscriptionStatus {
  hasActiveSubscription: boolean;
  subscriptionType: string | null;
  isLoading: boolean;
}

const TOKENIZERS: TokenizerType[] = [
  { id: 'gpt4', name: 'GPT-4 Tokenizer', provider: 'OpenAI', icon: '🤖' },
  { id: 'claude', name: 'Claude Tokenizer', provider: 'Anthropic', icon: '🧠' },
  { id: 'gemini', name: 'Gemini Tokenizer', provider: 'Google', icon: '✨' },
  { id: 'llama', name: 'Llama Tokenizer', provider: 'Meta', icon: '🦙' },
  { id: 'mistral', name: 'Mistral Tokenizer', provider: 'Mistral AI', icon: '🌪️' },
  { id: 'cohere', name: 'Cohere Tokenizer', provider: 'Cohere', icon: '🔷' },
];

const MODEL_PRICING: ModelPricing[] = [
  {
    id: 'gpt4-turbo',
    name: 'GPT-4 Turbo',
    provider: 'OpenAI',
    inputCostPer1M: 10.0,
    outputCostPer1M: 30.0,
    contextWindow: 128000,
    color: 'emerald',
  },
  {
    id: 'gpt4',
    name: 'GPT-4',
    provider: 'OpenAI',
    inputCostPer1M: 30.0,
    outputCostPer1M: 60.0,
    contextWindow: 8192,
    color: 'green',
  },
  {
    id: 'gpt35-turbo',
    name: 'GPT-3.5 Turbo',
    provider: 'OpenAI',
    inputCostPer1M: 0.5,
    outputCostPer1M: 1.5,
    contextWindow: 16385,
    color: 'teal',
  },
  {
    id: 'claude-opus',
    name: 'Claude 3 Opus',
    provider: 'Anthropic',
    inputCostPer1M: 15.0,
    outputCostPer1M: 75.0,
    contextWindow: 200000,
    color: 'orange',
  },
  {
    id: 'claude-sonnet',
    name: 'Claude 3 Sonnet',
    provider: 'Anthropic',
    inputCostPer1M: 3.0,
    outputCostPer1M: 15.0,
    contextWindow: 200000,
    color: 'amber',
  },
  {
    id: 'claude-haiku',
    name: 'Claude 3 Haiku',
    provider: 'Anthropic',
    inputCostPer1M: 0.25,
    outputCostPer1M: 1.25,
    contextWindow: 200000,
    color: 'yellow',
  },
  {
    id: 'gemini-ultra',
    name: 'Gemini Ultra',
    provider: 'Google',
    inputCostPer1M: 12.0,
    outputCostPer1M: 36.0,
    contextWindow: 1000000,
    color: 'blue',
  },
  {
    id: 'gemini-pro',
    name: 'Gemini Pro',
    provider: 'Google',
    inputCostPer1M: 0.5,
    outputCostPer1M: 1.5,
    contextWindow: 1000000,
    color: 'indigo',
  },
  {
    id: 'llama-70b',
    name: 'Llama 3 70B',
    provider: 'Meta',
    inputCostPer1M: 0.65,
    outputCostPer1M: 0.8,
    contextWindow: 8192,
    color: 'purple',
  },
  {
    id: 'llama-8b',
    name: 'Llama 3 8B',
    provider: 'Meta',
    inputCostPer1M: 0.2,
    outputCostPer1M: 0.2,
    contextWindow: 8192,
    color: 'violet',
  },
  {
    id: 'mistral-large',
    name: 'Mistral Large',
    provider: 'Mistral AI',
    inputCostPer1M: 8.0,
    outputCostPer1M: 24.0,
    contextWindow: 32000,
    color: 'rose',
  },
  {
    id: 'mistral-medium',
    name: 'Mistral Medium',
    provider: 'Mistral AI',
    inputCostPer1M: 2.7,
    outputCostPer1M: 8.1,
    contextWindow: 32000,
    color: 'pink',
  },
];

const AILabCostCalculatorPage: React.FC<{ onNavigate: (page: string) => void }> = ({
  onNavigate,
}) => {
  const [text, setText] = useState('');
  const [selectedTokenizer, setSelectedTokenizer] = useState<string>('gpt4');
  const [selectedModels, setSelectedModels] = useState<string[]>([
    'gpt4-turbo',
    'claude-sonnet',
    'gemini-pro',
  ]);
  const [inputOutputRatio, setInputOutputRatio] = useState<number>(2); // Output is 2x input by default
  const [results, setResults] = useState<CostResult[]>([]);
  const [history, setHistory] = useState<CostResult[]>([]);
  const [monthlyBudget, setMonthlyBudget] = useState<number>(100);
  const [showInfo, setShowInfo] = useState(false);
  const [loading, setLoading] = useState(false);
  const [subscriptionStatus, setSubscriptionStatus] = useState<SubscriptionStatus>({
    hasActiveSubscription: false,
    subscriptionType: null,
    isLoading: false,
  });
  const [showSubscriptionModal, setShowSubscriptionModal] = useState(true);

  // Load history from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('ailab_cost_history');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setHistory(parsed.filter((h: any) => h.type === 'cost').slice(0, 10));
      } catch (e) {
        console.error('Failed to load history:', e);
      }
    }
  }, []);

  // Check subscription status
  useEffect(() => {
    const checkSubscription = async () => {
      try {
        if (!authService.isAuthenticated()) {
          setShowSubscriptionModal(true);
          return;
        }
        // For testing: force no subscription
        setSubscriptionStatus({
          hasActiveSubscription: false,
          subscriptionType: null,
          isLoading: false,
        });
      } catch (error) {
        console.error('Error checking subscription:', error);
      }
    };
    checkSubscription();
  }, []);

  // Save to history
  const saveToHistory = (newResults: CostResult[]) => {
    const updated = [...newResults, ...history].slice(0, 10);
    setHistory(updated);

    const allHistory = JSON.parse(localStorage.getItem('ailab_global_history') || '[]');
    const filtered = allHistory.filter((h: any) => h.type !== 'cost');
    localStorage.setItem(
      'ailab_global_history',
      JSON.stringify([...updated.map(r => ({ ...r, type: 'cost' })), ...filtered])
    );
  };

  // Mock token counting function
  const countTokens = (text: string, tokenizer: string): number => {
    // Simple approximation: ~4 chars per token for GPT, ~3.5 for Claude, ~4.5 for others
    const ratios: { [key: string]: number } = {
      gpt4: 4,
      claude: 3.5,
      gemini: 4.2,
      llama: 4.3,
      mistral: 4.1,
      cohere: 3.8,
    };
    const ratio = ratios[tokenizer] || 4;
    return Math.ceil(text.length / ratio);
  };

  // Calculate costs
  const calculateCosts = () => {
    if (!text.trim()) {
      return;
    }

    setLoading(true);

    setTimeout(() => {
      const tokenCount = countTokens(text, selectedTokenizer);
      const inputTokens = tokenCount;
      const outputTokens = Math.ceil(tokenCount * inputOutputRatio);

      const newResults: CostResult[] = selectedModels.map(modelId => {
        const model = MODEL_PRICING.find(m => m.id === modelId)!;
        const inputCost = (inputTokens / 1000000) * model.inputCostPer1M;
        const outputCost = (outputTokens / 1000000) * model.outputCostPer1M;
        const totalCost = inputCost + outputCost;

        return {
          id: `${Date.now()}-${modelId}`,
          modelId,
          modelName: model.name,
          text: text.substring(0, 100),
          tokenCount: inputTokens + outputTokens,
          inputTokens,
          outputTokens,
          inputCost,
          outputCost,
          totalCost,
          timestamp: Date.now(),
        };
      });

      setResults(newResults);
      saveToHistory(newResults);
      setLoading(false);
    }, 800);
  };

  // Calculate budget tracking
  const calculateBudget = (): BudgetTracking => {
    const today = new Date();
    const daysInMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0).getDate();
    const dayOfMonth = today.getDate();
    const daysRemaining = daysInMonth - dayOfMonth;

    const currentSpend = history.reduce((sum, h) => sum + h.totalCost, 0);
    const dailyAverage = currentSpend / dayOfMonth;
    const projectedSpend = currentSpend + dailyAverage * daysRemaining;

    return {
      monthlyBudget,
      currentSpend,
      projectedSpend,
      daysRemaining,
    };
  };

  const budget = calculateBudget();
  const budgetPercentage = (budget.currentSpend / budget.monthlyBudget) * 100;
  const projectedPercentage = (budget.projectedSpend / budget.monthlyBudget) * 100;

  // Toggle model selection
  const toggleModel = (modelId: string) => {
    if (selectedModels.includes(modelId)) {
      if (selectedModels.length > 1) {
        setSelectedModels(selectedModels.filter(id => id !== modelId));
      }
    } else {
      setSelectedModels([...selectedModels, modelId]);
    }
  };

  // Export results
  const exportResults = () => {
    const data = {
      timestamp: new Date().toISOString(),
      text: text.substring(0, 100),
      tokenizer: TOKENIZERS.find(t => t.id === selectedTokenizer)?.name,
      inputOutputRatio,
      results: results.map(r => ({
        model: r.modelName,
        inputTokens: r.inputTokens,
        outputTokens: r.outputTokens,
        totalTokens: r.tokenCount,
        inputCost: `$${r.inputCost.toFixed(6)}`,
        outputCost: `$${r.outputCost.toFixed(6)}`,
        totalCost: `$${r.totalCost.toFixed(6)}`,
      })),
    };

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `cost-calculator-${Date.now()}.json`;
    a.click();
  };

  // Copy results
  const copyResults = () => {
    const text = results
      .map(
        r =>
          `${r.modelName}: ${r.tokenCount} tokens = $${r.totalCost.toFixed(6)} (Input: $${r.inputCost.toFixed(6)}, Output: $${r.outputCost.toFixed(6)})`
      )
      .join('\n');
    navigator.clipboard.writeText(text);
  };

  // Sample texts
  const sampleTexts = [
    { label: 'Short Query', text: 'What is the capital of France?' },
    {
      label: 'Medium Prompt',
      text: 'Write a detailed analysis of the economic impact of artificial intelligence on the job market, considering both positive and negative effects. Include specific examples and data points where possible.',
    },
    {
      label: 'Long Document',
      text: 'In recent years, artificial intelligence has undergone a remarkable transformation, evolving from simple rule-based systems to sophisticated neural networks capable of understanding and generating human-like text, recognizing complex patterns in images, and even creating original art and music. This technological revolution has been driven by advances in deep learning, increased computational power, and the availability of massive datasets. Companies across various industries are now integrating AI into their operations, from customer service chatbots to predictive analytics in healthcare. However, this rapid advancement has also raised important questions about ethics, privacy, job displacement, and the long-term implications of increasingly autonomous systems. As we continue to push the boundaries of what machines can do, it becomes crucial to develop frameworks for responsible AI development and deployment that prioritize human welfare, transparency, and accountability. The future of AI will likely be shaped by our ability to balance innovation with careful consideration of its societal impact.',
    },
    {
      label: 'Code Block',
      text: 'function calculateFibonacci(n) {\n  if (n <= 1) return n;\n  let prev = 0, curr = 1;\n  for (let i = 2; i <= n; i++) {\n    let next = prev + curr;\n    prev = curr;\n    curr = next;\n  }\n  return curr;\n}\n\nconsole.log(calculateFibonacci(10));',
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 text-white">
      {/* Subscription Access Barrier */}
      {!subscriptionStatus.hasActiveSubscription && (
        <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-gray-900 border border-gray-800 rounded-2xl p-8 max-w-md w-full text-center">
            <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-green-500 to-blue-600 rounded-full flex items-center justify-center">
              <Calculator className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-white mb-3">Cost Calculator Access Required</h2>
            <p className="text-gray-400 mb-6">
              The Token & Cost Calculator is a premium feature. Subscribe to unlock advanced pricing
              analysis and budget tracking capabilities.
            </p>
            <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-4 mb-6">
              <p className="text-blue-400 font-semibold mb-2">💰 Premium Features:</p>
              <ul className="text-sm text-gray-300 space-y-1 text-left">
                <li>• Multi-model cost comparison</li>
                <li>• Budget tracking & projections</li>
                <li>• Usage history & analytics</li>
                <li>• Export cost reports</li>
              </ul>
            </div>
            <div className="space-y-3">
              <button
                onClick={() => (window.location.href = '/pricing')}
                className="w-full bg-gradient-to-r from-green-600 to-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:from-green-500 hover:to-blue-500 transition-all"
              >
                Upgrade Now
              </button>
              <button
                onClick={() => window.history.back()}
                className="w-full bg-gray-800 hover:bg-gray-700 text-white px-6 py-3 rounded-lg font-semibold transition-all"
              >
                Back to AI Lab
              </button>
            </div>
          </div>
        </div>
      )}
      {/* Header */}
      <div className="border-b border-cyan-500/20 bg-black/40 backdrop-blur-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => onNavigate('ai-lab')}
                className="text-cyan-400 hover:text-cyan-300 transition-colors"
              >
                ← Back to Hub
              </button>
              <div className="flex items-center space-x-2">
                <Calculator className="w-6 h-6 text-cyan-400" />
                <h1 className="text-2xl font-bold bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent">
                  Token & Cost Calculator
                </h1>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <button
                onClick={() => setShowInfo(!showInfo)}
                className="p-2 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/20 transition-colors border border-cyan-500/30"
              >
                <Info className="w-5 h-5 text-cyan-400" />
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Main Calculator */}
          <div className="lg:col-span-3 space-y-6">
            {/* Tokenizer Selection */}
            <div className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm rounded-xl border border-cyan-500/20 p-6">
              <h2 className="text-lg font-semibold mb-4 flex items-center">
                <Zap className="w-5 h-5 text-yellow-400 mr-2" />
                Select Tokenizer
              </h2>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {TOKENIZERS.map(tokenizer => (
                  <button
                    key={tokenizer.id}
                    onClick={() => setSelectedTokenizer(tokenizer.id)}
                    className={`p-4 rounded-lg border transition-all ${
                      selectedTokenizer === tokenizer.id
                        ? 'bg-cyan-500/20 border-cyan-400 shadow-lg shadow-cyan-500/20'
                        : 'bg-gray-800/50 border-gray-700 hover:border-cyan-500/50'
                    }`}
                  >
                    <div className="text-2xl mb-2">{tokenizer.icon}</div>
                    <div className="font-medium text-sm">{tokenizer.name}</div>
                    <div className="text-xs text-gray-400">{tokenizer.provider}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Text Input */}
            <div className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm rounded-xl border border-cyan-500/20 p-6">
              <h2 className="text-lg font-semibold mb-4">Input Text</h2>
              <textarea
                value={text}
                onChange={e => setText(e.target.value)}
                placeholder="Enter your text here to calculate token count and costs..."
                className="w-full h-40 px-4 py-3 bg-black/40 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/20 resize-none"
              />
              <div className="mt-4 flex items-center justify-between">
                <div className="text-sm text-gray-400">{text.length} characters</div>
                <div className="flex space-x-2">
                  {sampleTexts.map(sample => (
                    <button
                      key={sample.label}
                      onClick={() => setText(sample.text)}
                      className="px-3 py-1 text-xs bg-gray-700/50 hover:bg-gray-700 rounded-lg transition-colors border border-gray-600"
                    >
                      {sample.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Model Selection */}
            <div className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm rounded-xl border border-cyan-500/20 p-6">
              <h2 className="text-lg font-semibold mb-4 flex items-center">
                <BarChart3 className="w-5 h-5 text-blue-400 mr-2" />
                Select Models for Comparison
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                {MODEL_PRICING.map(model => (
                  <button
                    key={model.id}
                    onClick={() => toggleModel(model.id)}
                    className={`p-4 rounded-lg border transition-all text-left ${
                      selectedModels.includes(model.id)
                        ? `bg-${model.color}-500/20 border-${model.color}-400`
                        : 'bg-gray-800/50 border-gray-700 hover:border-gray-600'
                    }`}
                  >
                    <div className="font-medium text-sm mb-1">{model.name}</div>
                    <div className="text-xs text-gray-400 mb-2">{model.provider}</div>
                    <div className="text-xs space-y-1">
                      <div>In: ${model.inputCostPer1M.toFixed(2)}/1M</div>
                      <div>Out: ${model.outputCostPer1M.toFixed(2)}/1M</div>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Input/Output Ratio */}
            <div className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm rounded-xl border border-cyan-500/20 p-6">
              <h2 className="text-lg font-semibold mb-4">Output/Input Ratio</h2>
              <div className="flex items-center space-x-4">
                <input
                  type="range"
                  min="0.5"
                  max="5"
                  step="0.5"
                  value={inputOutputRatio}
                  onChange={e => setInputOutputRatio(parseFloat(e.target.value))}
                  className="flex-1 h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
                />
                <div className="text-lg font-semibold text-cyan-400 w-16 text-center">
                  {inputOutputRatio.toFixed(1)}x
                </div>
              </div>
              <div className="mt-2 text-sm text-gray-400">
                Output tokens will be {inputOutputRatio.toFixed(1)}x the input tokens
              </div>
            </div>

            {/* Calculate Button */}
            <button
              onClick={calculateCosts}
              disabled={!text.trim() || selectedModels.length === 0 || loading}
              className="w-full py-4 bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 disabled:from-gray-700 disabled:to-gray-800 disabled:cursor-not-allowed rounded-xl font-semibold transition-all shadow-lg disabled:shadow-none flex items-center justify-center space-x-2"
            >
              {loading ? (
                <>
                  <RefreshCw className="w-5 h-5 animate-spin" />
                  <span>Calculating...</span>
                </>
              ) : (
                <>
                  <Calculator className="w-5 h-5" />
                  <span>Calculate Costs</span>
                </>
              )}
            </button>

            {/* Results */}
            {results.length > 0 && (
              <div className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm rounded-xl border border-cyan-500/20 p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-semibold flex items-center">
                    <DollarSign className="w-6 h-6 text-green-400 mr-2" />
                    Cost Comparison
                  </h2>
                  <div className="flex space-x-2">
                    <button
                      onClick={copyResults}
                      className="p-2 bg-gray-700/50 hover:bg-gray-700 rounded-lg transition-colors"
                    >
                      <Copy className="w-5 h-5" />
                    </button>
                    <button
                      onClick={exportResults}
                      className="p-2 bg-cyan-500/20 hover:bg-cyan-500/30 rounded-lg transition-colors border border-cyan-500/30"
                    >
                      <Download className="w-5 h-5 text-cyan-400" />
                    </button>
                  </div>
                </div>

                <div className="space-y-4">
                  {results.map(result => {
                    const model = MODEL_PRICING.find(m => m.id === result.modelId)!;
                    return (
                      <div
                        key={result.id}
                        className={`p-5 rounded-xl bg-gradient-to-r from-${model.color}-500/10 to-${model.color}-600/10 border border-${model.color}-500/30`}
                      >
                        <div className="flex items-center justify-between mb-3">
                          <div>
                            <div className="font-semibold text-lg">{result.modelName}</div>
                            <div className="text-sm text-gray-400">{model.provider}</div>
                          </div>
                          <div className="text-right">
                            <div className="text-2xl font-bold text-green-400">
                              ${result.totalCost.toFixed(6)}
                            </div>
                            <div className="text-xs text-gray-400">
                              {result.tokenCount.toLocaleString()} tokens
                            </div>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <div className="text-gray-400">Input Tokens</div>
                            <div className="font-semibold">
                              {result.inputTokens.toLocaleString()} · ${result.inputCost.toFixed(6)}
                            </div>
                          </div>
                          <div>
                            <div className="text-gray-400">Output Tokens</div>
                            <div className="font-semibold">
                              {result.outputTokens.toLocaleString()} · $
                              {result.outputCost.toFixed(6)}
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Cost per 1000 requests */}
                <div className="mt-6 p-4 bg-blue-500/10 border border-blue-500/30 rounded-lg">
                  <h3 className="font-semibold mb-3 flex items-center">
                    <TrendingUp className="w-4 h-4 mr-2 text-blue-400" />
                    Cost at Scale (1,000 Requests)
                  </h3>
                  <div className="space-y-2">
                    {results.map(result => (
                      <div key={result.id} className="flex justify-between text-sm">
                        <span className="text-gray-400">{result.modelName}:</span>
                        <span className="font-semibold">
                          ${(result.totalCost * 1000).toFixed(2)}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Budget Tracker */}
            <div className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm rounded-xl border border-cyan-500/20 p-6">
              <h2 className="text-lg font-semibold mb-4 flex items-center">
                <PieChart className="w-5 h-5 text-purple-400 mr-2" />
                Monthly Budget
              </h2>

              <div className="mb-4">
                <label className="text-sm text-gray-400 mb-2 block">Budget Amount</label>
                <div className="flex items-center">
                  <DollarSign className="w-5 h-5 text-gray-400 mr-2" />
                  <input
                    type="number"
                    value={monthlyBudget}
                    onChange={e => setMonthlyBudget(parseFloat(e.target.value) || 0)}
                    className="flex-1 px-3 py-2 bg-black/40 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-cyan-500"
                  />
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-gray-400">Current Spend</span>
                    <span className="font-semibold text-green-400">
                      ${budget.currentSpend.toFixed(2)}
                    </span>
                  </div>
                  <div className="h-2 bg-gray-700 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all ${
                        budgetPercentage > 100
                          ? 'bg-red-500'
                          : budgetPercentage > 80
                            ? 'bg-yellow-500'
                            : 'bg-green-500'
                      }`}
                      style={{ width: `${Math.min(budgetPercentage, 100)}%` }}
                    />
                  </div>
                  <div className="text-xs text-gray-500 mt-1">
                    {budgetPercentage.toFixed(1)}% of budget
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-gray-400">Projected Spend</span>
                    <span className="font-semibold text-yellow-400">
                      ${budget.projectedSpend.toFixed(2)}
                    </span>
                  </div>
                  <div className="h-2 bg-gray-700 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all ${
                        projectedPercentage > 100
                          ? 'bg-red-500'
                          : projectedPercentage > 80
                            ? 'bg-yellow-500'
                            : 'bg-blue-500'
                      }`}
                      style={{ width: `${Math.min(projectedPercentage, 100)}%` }}
                    />
                  </div>
                  <div className="text-xs text-gray-500 mt-1">
                    {projectedPercentage.toFixed(1)}% projected
                  </div>
                </div>

                <div className="pt-3 border-t border-gray-700">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-400">Days Remaining</span>
                    <span className="font-semibold">{budget.daysRemaining}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm mt-2">
                    <span className="text-gray-400">Remaining Budget</span>
                    <span
                      className={`font-semibold ${
                        budget.monthlyBudget - budget.currentSpend < 0
                          ? 'text-red-400'
                          : 'text-green-400'
                      }`}
                    >
                      ${(budget.monthlyBudget - budget.currentSpend).toFixed(2)}
                    </span>
                  </div>
                </div>

                {budgetPercentage > 80 && (
                  <div className="p-3 bg-yellow-500/10 border border-yellow-500/30 rounded-lg">
                    <div className="flex items-start space-x-2">
                      <AlertCircle className="w-4 h-4 text-yellow-400 mt-0.5" />
                      <div className="text-xs text-yellow-200">
                        {budgetPercentage > 100 ? 'Budget exceeded!' : 'Approaching budget limit'}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* History */}
            {history.length > 0 && (
              <div className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm rounded-xl border border-cyan-500/20 p-6">
                <h2 className="text-lg font-semibold mb-4 flex items-center">
                  <History className="w-5 h-5 text-cyan-400 mr-2" />
                  Recent Calculations
                </h2>
                <div className="space-y-3">
                  {history.slice(0, 5).map(item => (
                    <div
                      key={item.id}
                      className="p-3 bg-gray-800/50 rounded-lg border border-gray-700 hover:border-cyan-500/50 transition-colors cursor-pointer"
                      onClick={() => setText(item.text)}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div className="text-sm font-medium">{item.modelName}</div>
                        <div className="text-sm font-semibold text-green-400">
                          ${item.totalCost.toFixed(6)}
                        </div>
                      </div>
                      <div className="text-xs text-gray-400 truncate">
                        {item.text.substring(0, 50)}...
                      </div>
                      <div className="text-xs text-gray-500 mt-1">
                        {item.tokenCount.toLocaleString()} tokens
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Info Panel */}
            {showInfo && (
              <div className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm rounded-xl border border-cyan-500/20 p-6">
                <h2 className="text-lg font-semibold mb-4 flex items-center">
                  <Info className="w-5 h-5 text-cyan-400 mr-2" />
                  About Cost Calculator
                </h2>
                <div className="space-y-3 text-sm text-gray-300">
                  <p>Calculate token counts and costs across different AI models and providers.</p>
                  <div>
                    <div className="font-semibold text-white mb-1">Features:</div>
                    <ul className="list-disc list-inside space-y-1 text-gray-400">
                      <li>Token counting for 6 tokenizers</li>
                      <li>Cost comparison across 12+ models</li>
                      <li>Budget tracking & projections</li>
                      <li>Adjustable input/output ratios</li>
                      <li>Scale calculations (1K requests)</li>
                    </ul>
                  </div>
                  <div>
                    <div className="font-semibold text-white mb-1">Use Cases:</div>
                    <ul className="list-disc list-inside space-y-1 text-gray-400">
                      <li>API cost estimation</li>
                      <li>Budget planning</li>
                      <li>Model selection optimization</li>
                      <li>Token usage analysis</li>
                    </ul>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AILabCostCalculatorPage;
