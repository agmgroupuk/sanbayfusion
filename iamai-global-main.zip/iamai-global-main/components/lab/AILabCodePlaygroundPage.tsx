import React, { useState, useEffect } from 'react';
import { Page } from '../../App';
import {
  ArrowLeft,
  Code2,
  Play,
  RefreshCw,
  Copy,
  Download,
  Settings,
  Terminal,
  FileCode,
  Lightbulb,
  CheckCircle2,
  AlertCircle,
  XCircle,
  Loader2,
  Zap,
  BookOpen,
  Bug,
  Sparkles,
  MessageSquare,
  Hash,
  Clock,
  TrendingUp,
  Lock,
  Crown,
} from 'lucide-react';
import { aiLabService } from '../../services/aiLabService';
import { authService } from '../../services/authService';

interface AILabCodePlaygroundPageProps {
  onNavigate: (page: Page) => void;
}

interface Language {
  id: string;
  name: string;
  icon: string;
  color: string;
  extension: string;
}

interface CodeTask {
  id: string;
  name: string;
  description: string;
  category: 'generate' | 'debug' | 'explain' | 'optimize';
  icon: React.ReactNode;
}

interface ExecutionResult {
  success: boolean;
  output: string;
  error?: string;
  executionTime: number;
  memoryUsed?: string;
}

interface SubscriptionStatus {
  hasActiveSubscription: boolean;
  subscriptionType: string | null;
  isLoading: boolean;
}

interface CodeResult {
  id: string;
  task: string;
  language: string;
  prompt: string;
  code: string;
  explanation?: string;
  execution?: ExecutionResult;
  timestamp: number;
  metrics: {
    lines: number;
    chars: number;
    generationTime: number;
  };
}

const AILabCodePlaygroundPage: React.FC<AILabCodePlaygroundPageProps> = ({ onNavigate }) => {
  // State
  const [subscriptionStatus, setSubscriptionStatus] = useState<SubscriptionStatus>({
    hasActiveSubscription: false,
    subscriptionType: null,
    isLoading: false,
  });
  const [showSubscriptionModal, setShowSubscriptionModal] = useState(true);
  // Languages
  const languages: Language[] = [
    {
      id: 'python',
      name: 'Python',
      icon: '🐍',
      color: 'from-blue-500 to-cyan-600',
      extension: 'py',
    },
    {
      id: 'javascript',
      name: 'JavaScript',
      icon: '📜',
      color: 'from-yellow-500 to-orange-600',
      extension: 'js',
    },
    {
      id: 'typescript',
      name: 'TypeScript',
      icon: '💙',
      color: 'from-blue-600 to-indigo-600',
      extension: 'ts',
    },
    {
      id: 'java',
      name: 'Java',
      icon: '☕',
      color: 'from-red-500 to-orange-600',
      extension: 'java',
    },
    { id: 'cpp', name: 'C++', icon: '⚡', color: 'from-purple-500 to-pink-600', extension: 'cpp' },
    { id: 'go', name: 'Go', icon: '🐹', color: 'from-cyan-500 to-blue-600', extension: 'go' },
    { id: 'rust', name: 'Rust', icon: '🦀', color: 'from-orange-600 to-red-600', extension: 'rs' },
    { id: 'sql', name: 'SQL', icon: '🗄️', color: 'from-green-500 to-teal-600', extension: 'sql' },
  ];

  // Code Tasks
  const tasks: CodeTask[] = [
    {
      id: 'generate',
      name: 'Generate Code',
      description: 'Create new code from description',
      category: 'generate',
      icon: <Sparkles className="w-5 h-5" />,
    },
    {
      id: 'debug',
      name: 'Debug Code',
      description: 'Find and fix bugs in existing code',
      category: 'debug',
      icon: <Bug className="w-5 h-5" />,
    },
    {
      id: 'explain',
      name: 'Explain Code',
      description: 'Get detailed code explanation',
      category: 'explain',
      icon: <BookOpen className="w-5 h-5" />,
    },
    {
      id: 'optimize',
      name: 'Optimize Code',
      description: 'Improve performance and efficiency',
      category: 'optimize',
      icon: <Zap className="w-5 h-5" />,
    },
  ];

  // State
  const [selectedLanguage, setSelectedLanguage] = useState<Language>(languages[0]);
  const [selectedTask, setSelectedTask] = useState<CodeTask>(tasks[0]);
  const [prompt, setPrompt] = useState('');
  const [inputCode, setInputCode] = useState('');
  const [generatedCode, setGeneratedCode] = useState('');
  const [explanation, setExplanation] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [showExecution, setShowExecution] = useState(false);
  const [executionResult, setExecutionResult] = useState<ExecutionResult | null>(null);
  const [history, setHistory] = useState<CodeResult[]>([]);

  // Sample Prompts
  const samplePrompts: Record<string, string[]> = {
    generate: [
      'Create a function to calculate fibonacci numbers',
      'Build a simple REST API endpoint',
      'Write a binary search algorithm',
      'Create a class for managing user data',
    ],
    debug: [
      'Fix the null pointer exception in this code',
      'Resolve the infinite loop issue',
      'Fix the memory leak in this function',
      'Correct the logic error in sorting',
    ],
    explain: [
      'Explain how this recursive function works',
      'What does this regex pattern do?',
      'How does this algorithm achieve O(log n)?',
      'Explain the design pattern used here',
    ],
    optimize: [
      'Optimize this nested loop',
      'Improve database query performance',
      'Reduce memory usage in this function',
      'Make this code more efficient',
    ],
  };

  // Check subscription status
  useEffect(() => {
    const checkSubscription = async () => {
      try {
        if (!authService.isAuthenticated()) {
          setShowSubscriptionModal(true);
          return;
        }
        // For testing: force no subscription
        setSubscriptionStatus({
          hasActiveSubscription: false,
          subscriptionType: null,
          isLoading: false,
        });
      } catch (error) {
        console.error('Error checking subscription:', error);
      }
    };
    checkSubscription();
  }, []);

  // Load history
  useEffect(() => {
    try {
      const saved = localStorage.getItem('ailab_global_history');
      if (saved) {
        const allHistory = JSON.parse(saved);
        const codeHistory = allHistory.filter((item: any) => item.type === 'code');
        setHistory(codeHistory.slice(-10));
      }
    } catch (e) {
      console.error('Failed to load history:', e);
    }
  }, []);

  // Process Code
  const processCode = async () => {
    if (selectedTask.id !== 'generate' && !inputCode.trim()) return;
    if (selectedTask.id === 'generate' && !prompt.trim()) return;

    setIsProcessing(true);
    setGeneratedCode('');
    setExplanation('');

    const startTime = Date.now();

    try {
      // Build prompt based on task
      let aiPrompt = '';
      let systemPrompt = '';

      switch (selectedTask.id) {
        case 'generate':
          aiPrompt = `Write ${selectedLanguage.name} code for: ${prompt}`;
          systemPrompt = `You are an expert ${selectedLanguage.name} programmer. Generate clean, efficient, and well-commented code. Include example usage.`;
          break;
        case 'debug':
          aiPrompt = `Find and fix bugs in this ${selectedLanguage.name} code:\n\n${inputCode}`;
          systemPrompt = `You are an expert ${selectedLanguage.name} debugger. Identify bugs and provide corrected code with explanations of what was wrong.`;
          break;
        case 'explain':
          aiPrompt = `Explain this ${selectedLanguage.name} code in detail:\n\n${inputCode}`;
          systemPrompt = `You are an expert ${selectedLanguage.name} teacher. Provide clear, detailed explanations of code functionality, logic, and best practices.`;
          break;
        case 'optimize':
          aiPrompt = `Optimize this ${selectedLanguage.name} code for performance:\n\n${inputCode}`;
          systemPrompt = `You are an expert ${selectedLanguage.name} performance engineer. Optimize code for speed and efficiency while maintaining readability.`;
          break;
      }

      // Call AI service
      const result = await aiLabService.generateCompletion({
        provider: 'openai',
        model: 'gpt-4',
        prompt: aiPrompt,
        systemPrompt: systemPrompt,
        temperature: 0.7,
        maxTokens: 1000,
      });

      if (!result.success) {
        throw new Error(result.error || 'Failed to generate code');
      }

      const responseText = result.response || '';

      // Extract code blocks from response
      const codeMatch = responseText.match(/```[\w]*\n([\s\S]*?)```/);
      const extractedCode = codeMatch ? codeMatch[1].trim() : responseText;

      // For explain task, use full response as explanation
      if (selectedTask.id === 'explain') {
        setExplanation(responseText);
        setGeneratedCode(inputCode); // Keep original code
      } else {
        setGeneratedCode(extractedCode);
        // Extract explanation (text outside code blocks)
        const explanation = responseText.replace(/```[\w]*\n[\s\S]*?```/g, '').trim();
        setExplanation(explanation || 'Code generated successfully.');
      }

      const generationTime = Date.now() - startTime;

      // Save to history
      const codeResult: CodeResult = {
        id: `code-${Date.now()}`,
        task: selectedTask.name,
        language: selectedLanguage.name,
        prompt: prompt || 'Debug/Explain/Optimize code',
        code: extractedCode,
        explanation:
          selectedTask.id === 'explain'
            ? responseText
            : responseText.replace(/```[\w]*\n[\s\S]*?```/g, '').trim() ||
              'Code generated successfully.',
        timestamp: Date.now(),
        metrics: {
          lines: extractedCode.split('\n').length,
          chars: extractedCode.length,
          generationTime,
        },
      };

      saveToHistory(codeResult);
      setHistory(prev => [codeResult, ...prev].slice(0, 10));
    } catch (error) {
      console.error('Error processing code:', error);
      setGeneratedCode(`// Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
      setExplanation('An error occurred while processing your request.');
    }

    setIsProcessing(false);
  };

  // Mock Code Generators (Keeping as legacy - no longer used)
  const generateNewCode = (lang: string, prompt: string): { code: string; explanation: string } => {
    const templates: Record<string, string> = {
      python: `def fibonacci(n):
    """Calculate fibonacci number at position n"""
    if n <= 1:
        return n
    return fibonacci(n-1) + fibonacci(n-2)

# Example usage
print(fibonacci(10))  # Output: 55`,

      javascript: `function fibonacci(n) {
  // Calculate fibonacci number at position n
  if (n <= 1) return n;
  return fibonacci(n - 1) + fibonacci(n - 2);
}

// Example usage
console.log(fibonacci(10)); // Output: 55`,

      typescript: `function fibonacci(n: number): number {
  // Calculate fibonacci number at position n
  if (n <= 1) return n;
  return fibonacci(n - 1) + fibonacci(n - 2);
}

// Example usage
console.log(fibonacci(10)); // Output: 55`,

      java: `public class Fibonacci {
    public static int fibonacci(int n) {
        // Calculate fibonacci number at position n
        if (n <= 1) return n;
        return fibonacci(n - 1) + fibonacci(n - 2);
    }
    
    public static void main(String[] args) {
        System.out.println(fibonacci(10)); // Output: 55
    }
}`,

      cpp: `#include <iostream>
using namespace std;

int fibonacci(int n) {
    // Calculate fibonacci number at position n
    if (n <= 1) return n;
    return fibonacci(n - 1) + fibonacci(n - 2);
}

int main() {
    cout << fibonacci(10) << endl; // Output: 55
    return 0;
}`,

      go: `package main
import "fmt"

func fibonacci(n int) int {
    // Calculate fibonacci number at position n
    if n <= 1 {
        return n
    }
    return fibonacci(n-1) + fibonacci(n-2)
}

func main() {
    fmt.Println(fibonacci(10)) // Output: 55
}`,

      rust: `fn fibonacci(n: u32) -> u32 {
    // Calculate fibonacci number at position n
    match n {
        0 | 1 => n,
        _ => fibonacci(n - 1) + fibonacci(n - 2),
    }
}

fn main() {
    println!("{}", fibonacci(10)); // Output: 55
}`,

      sql: `-- Create fibonacci sequence using recursive CTE
WITH RECURSIVE fib(n, a, b) AS (
  SELECT 0, 0, 1
  UNION ALL
  SELECT n+1, b, a+b FROM fib WHERE n < 10
)
SELECT n, a as fibonacci FROM fib;`,
    };

    const code = templates[lang] || templates.python;
    const explanation = `Generated ${lang} code based on your prompt: "${prompt}"

Key Features:
• Recursive implementation for clarity
• Base case handling (n <= 1)
• Example usage included
• Clean, readable structure

Time Complexity: O(2^n) - can be optimized with memoization
Space Complexity: O(n) - due to recursion stack`;

    return { code, explanation };
  };

  const debugCode = (lang: string, input: string): { code: string; explanation: string } => {
    const code = input
      .replace(/\/\/ BUG/g, '// FIXED')
      .replace(/null/g, 'undefined')
      .replace(/=/g, '===');

    const explanation = `Debug Analysis:

Issues Found:
🔴 Potential null pointer reference
🔴 Assignment (=) instead of comparison (===)
🔴 Missing error handling

Fixes Applied:
✅ Added null checks
✅ Corrected comparison operators
✅ Improved error handling
✅ Added input validation

The code should now run without errors. Consider adding unit tests to prevent regression.`;

    return { code, explanation };
  };

  const explainCode = (lang: string, input: string): { code: string; explanation: string } => {
    const explanation = `Code Explanation:

📚 Overview:
This code implements a ${lang} function/method with the following characteristics:

🔍 Line-by-Line Breakdown:
• Lines 1-3: Function definition and parameters
• Lines 4-6: Input validation and base case handling
• Lines 7-10: Core logic implementation
• Lines 11-13: Return statement and cleanup

⚙️ How It Works:
1. Accepts input parameters
2. Validates inputs for edge cases
3. Processes data using the core algorithm
4. Returns the computed result

💡 Key Concepts:
• Uses recursion for elegant solution
• Handles edge cases properly
• Time-efficient implementation
• Clear variable naming

🎯 Best Practices:
✓ Follows ${lang} conventions
✓ Includes error handling
✓ Well-documented code
✓ Optimized for readability`;

    return { code: input, explanation };
  };

  const optimizeCode = (lang: string, input: string): { code: string; explanation: string } => {
    const code = `// Optimized version with memoization
${input}

// Performance improvements applied:
// - Added caching for repeated calculations
// - Reduced time complexity from O(2^n) to O(n)
// - Minimized memory allocations`;

    const explanation = `Optimization Report:

⚡ Performance Improvements:
• Time Complexity: O(2^n) → O(n) ✅
• Space Complexity: O(n) → O(n) ➡️
• Execution Speed: ~1000x faster 🚀

🔧 Changes Made:
1. Implemented memoization/caching
2. Reduced redundant calculations
3. Optimized memory usage
4. Improved algorithmic efficiency

📊 Benchmarks:
Before: 2.5s for n=40
After:  0.002s for n=40
Speedup: 1250x improvement

💡 Additional Recommendations:
• Consider iterative approach for even better performance
• Add input size limits for safety
• Use built-in optimizations when available`;

    return { code, explanation };
  };

  // Execute Code (Mock)
  const executeCode = async () => {
    setShowExecution(true);
    setExecutionResult(null);

    await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 1000));

    const success = Math.random() > 0.2; // 80% success rate

    if (success) {
      setExecutionResult({
        success: true,
        output: '55\nExecution completed successfully!',
        executionTime: Math.round(50 + Math.random() * 150),
        memoryUsed: `${(Math.random() * 10 + 5).toFixed(2)} MB`,
      });
    } else {
      setExecutionResult({
        success: false,
        output: '',
        error:
          'RuntimeError: Maximum recursion depth exceeded\nLine 5: return fibonacci(n-1) + fibonacci(n-2)',
        executionTime: Math.round(20 + Math.random() * 50),
      });
    }
  };

  // Save to History
  const saveToHistory = (result: CodeResult) => {
    try {
      const saved = localStorage.getItem('ailab_global_history') || '[]';
      const history = JSON.parse(saved);
      history.push({ type: 'code', ...result });
      localStorage.setItem('ailab_global_history', JSON.stringify(history));
    } catch (e) {
      console.error('Failed to save:', e);
    }
  };

  // Copy to Clipboard
  const copyCode = () => {
    navigator.clipboard.writeText(generatedCode);
  };

  // Download Code
  const downloadCode = () => {
    const blob = new Blob([generatedCode], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `code.${selectedLanguage.extension}`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-black text-white pb-20">
      {/* Subscription Modal */}
      {showSubscriptionModal && (
        <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-gray-900 border border-gray-800 rounded-2xl p-8 max-w-md w-full text-center">
            <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-green-500 to-teal-600 rounded-full flex items-center justify-center">
              <Code2 className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-white mb-3">Code Playground Access Required</h2>
            <p className="text-gray-400 mb-6">
              The Code Playground is a premium feature. Subscribe to unlock access to AI-powered
              code generation and debugging tools.
            </p>
            <div className="space-y-3">
              <button
                onClick={() => (window.location.href = '/pricing')}
                className="w-full bg-gradient-to-r from-green-600 to-teal-600 text-white px-6 py-3 rounded-lg font-semibold hover:from-green-500 hover:to-teal-500 transition-all"
              >
                Upgrade Now
              </button>
              <button
                onClick={() => onNavigate('ai-lab' as Page)}
                className="w-full bg-gray-800 hover:bg-gray-700 text-white px-6 py-3 rounded-lg font-semibold transition-all"
              >
                Back to AI Lab
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Full Page Barrier for Non-Subscribers */}
      {!subscriptionStatus.hasActiveSubscription && (
        <div className="fixed inset-0 z-40 bg-black/90 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-gray-900 border border-green-500/30 rounded-2xl p-8 max-w-lg w-full text-center">
            <div className="w-20 h-20 mx-auto mb-6 bg-gradient-to-r from-green-500 to-teal-600 rounded-full flex items-center justify-center">
              <Lock className="w-10 h-10 text-white" />
            </div>
            <h2 className="text-3xl font-bold text-white mb-4">Premium Feature Locked</h2>
            <p className="text-gray-400 mb-6 text-lg">
              Code Playground requires an active subscription. Generate, debug, and optimize code
              with AI-powered development tools.
            </p>
            <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-4 mb-6">
              <p className="text-green-400 font-semibold">💻 Code Features:</p>
              <ul className="text-sm text-gray-300 mt-2 space-y-1 text-left">
                <li>• AI code generation & completion</li>
                <li>• Intelligent debugging assistance</li>
                <li>• Code optimization suggestions</li>
                <li>• Multi-language support</li>
              </ul>
            </div>
            <button
              onClick={() => setShowSubscriptionModal(true)}
              className="w-full bg-gradient-to-r from-green-600 to-teal-600 text-white px-6 py-4 rounded-xl font-bold text-lg hover:from-green-500 hover:to-teal-500 transition-all shadow-lg"
            >
              Unlock Code Playground
            </button>
          </div>
        </div>
      )}
      {/* Header */}
      <div className="sticky top-0 z-40 bg-black/95 backdrop-blur-xl border-b border-gray-800">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={() => onNavigate('ai-lab' as Page)}
                className="p-2 hover:bg-gray-800 rounded-lg transition-colors"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
              <div>
                <h1 className="text-2xl font-bold text-white flex items-center gap-2">
                  <Code2 className="w-6 h-6 text-green-400" />
                  Code Playground
                </h1>
                <p className="text-sm text-gray-400">
                  Generate, debug, explain, and optimize code with AI
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-6 py-8">
        <div className="grid lg:grid-cols-4 gap-6">
          {/* Left Sidebar - Controls */}
          <div className="lg:col-span-1 space-y-6">
            {/* Task Selection */}
            <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-6 sticky top-24">
              <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                <Settings className="w-5 h-5 text-cyan-400" />
                Task
              </h3>

              <div className="space-y-2">
                {tasks.map(task => (
                  <button
                    key={task.id}
                    onClick={() => setSelectedTask(task)}
                    className={`w-full p-3 rounded-lg border-2 transition-all text-left ${
                      selectedTask.id === task.id
                        ? 'bg-cyan-500 border-cyan-500 text-white'
                        : 'bg-gray-800/50 border-gray-700 hover:border-gray-600 text-gray-300'
                    }`}
                  >
                    <div className="flex items-center gap-2 mb-1">
                      {task.icon}
                      <span className="font-semibold text-sm">{task.name}</span>
                    </div>
                    <p className="text-xs opacity-80">{task.description}</p>
                  </button>
                ))}
              </div>
            </div>

            {/* Language Selection */}
            <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-6">
              <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                <FileCode className="w-5 h-5 text-green-400" />
                Language
              </h3>

              <div className="grid grid-cols-2 gap-2">
                {languages.map(lang => (
                  <button
                    key={lang.id}
                    onClick={() => setSelectedLanguage(lang)}
                    className={`p-3 rounded-lg border-2 transition-all ${
                      selectedLanguage.id === lang.id
                        ? `bg-gradient-to-r ${lang.color} border-transparent`
                        : 'bg-gray-800/50 border-gray-700 hover:border-gray-600'
                    }`}
                  >
                    <div className="text-2xl mb-1">{lang.icon}</div>
                    <div className="text-xs font-semibold">{lang.name}</div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3 space-y-6">
            {/* Prompt/Input Section */}
            <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-6">
              {selectedTask.id === 'generate' ? (
                <>
                  <h3 className="text-lg font-semibold text-white mb-4">
                    Describe What You Want to Build
                  </h3>
                  <textarea
                    value={prompt}
                    onChange={e => setPrompt(e.target.value)}
                    placeholder="E.g., Create a function to calculate factorial recursively..."
                    className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-cyan-500 resize-none min-h-[120px] mb-4"
                  />

                  {/* Sample Prompts */}
                  <div>
                    <p className="text-xs text-gray-400 mb-2">Quick Examples:</p>
                    <div className="flex flex-wrap gap-2">
                      {samplePrompts.generate.map((sample, i) => (
                        <button
                          key={i}
                          onClick={() => setPrompt(sample)}
                          className="px-3 py-1.5 bg-gray-800 hover:bg-gray-700 border border-gray-700 rounded-lg text-xs text-gray-300 transition-colors"
                        >
                          {sample.slice(0, 30)}...
                        </button>
                      ))}
                    </div>
                  </div>
                </>
              ) : (
                <>
                  <h3 className="text-lg font-semibold text-white mb-4">Paste Your Code</h3>
                  <textarea
                    value={inputCode}
                    onChange={e => setInputCode(e.target.value)}
                    placeholder={`Paste your ${selectedLanguage.name} code here...`}
                    className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-cyan-500 resize-none min-h-[200px] font-mono text-sm"
                  />
                </>
              )}
            </div>

            {/* Process Button */}
            <button
              onClick={processCode}
              disabled={
                isProcessing ||
                (selectedTask.id === 'generate' ? !prompt.trim() : !inputCode.trim())
              }
              className="w-full py-4 bg-gradient-to-r from-green-600 to-cyan-600 hover:from-green-500 hover:to-cyan-500 disabled:from-gray-700 disabled:to-gray-700 text-white font-bold text-lg rounded-xl shadow-lg transition-all disabled:cursor-not-allowed flex items-center justify-center gap-3"
            >
              {isProcessing ? (
                <>
                  <Loader2 className="w-6 h-6 animate-spin" />
                  Processing...
                </>
              ) : (
                <>
                  <Play className="w-6 h-6" />
                  {selectedTask.name}
                </>
              )}
            </button>

            {/* Output Section */}
            {(generatedCode || isProcessing) && (
              <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                    <Terminal className="w-5 h-5 text-green-400" />
                    Generated Code
                  </h3>
                  {generatedCode && (
                    <div className="flex items-center gap-2">
                      <button
                        onClick={copyCode}
                        className="p-2 bg-gray-800 hover:bg-gray-700 rounded-lg transition-colors"
                        title="Copy"
                      >
                        <Copy className="w-4 h-4" />
                      </button>
                      <button
                        onClick={downloadCode}
                        className="p-2 bg-gray-800 hover:bg-gray-700 rounded-lg transition-colors"
                        title="Download"
                      >
                        <Download className="w-4 h-4" />
                      </button>
                      <button
                        onClick={executeCode}
                        className="px-3 py-2 bg-green-600 hover:bg-green-500 rounded-lg transition-colors flex items-center gap-2"
                      >
                        <Play className="w-4 h-4" />
                        <span className="text-sm">Run</span>
                      </button>
                    </div>
                  )}
                </div>

                {isProcessing ? (
                  <div className="flex items-center justify-center py-12">
                    <Loader2 className="w-8 h-8 text-green-400 animate-spin" />
                  </div>
                ) : (
                  <>
                    <div className="bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 overflow-x-auto">
                      <pre className="text-sm text-gray-100 font-mono whitespace-pre-wrap">
                        {generatedCode}
                      </pre>
                    </div>

                    {/* Metrics */}
                    <div className="grid grid-cols-3 gap-4 mt-4">
                      <div className="text-center p-3 bg-gray-800/50 rounded-lg">
                        <p className="text-xs text-gray-400 mb-1">Lines</p>
                        <p className="text-lg font-bold text-white">
                          {generatedCode.split('\n').length}
                        </p>
                      </div>
                      <div className="text-center p-3 bg-gray-800/50 rounded-lg">
                        <p className="text-xs text-gray-400 mb-1">Characters</p>
                        <p className="text-lg font-bold text-white">{generatedCode.length}</p>
                      </div>
                      <div className="text-center p-3 bg-gray-800/50 rounded-lg">
                        <p className="text-xs text-gray-400 mb-1">Language</p>
                        <p className="text-lg font-bold text-green-400">{selectedLanguage.name}</p>
                      </div>
                    </div>
                  </>
                )}
              </div>
            )}

            {/* Explanation Section */}
            {explanation && (
              <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-6">
                <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                  <Lightbulb className="w-5 h-5 text-yellow-400" />
                  Explanation
                </h3>
                <div className="prose prose-invert max-w-none">
                  <pre className="text-sm text-gray-300 whitespace-pre-wrap font-sans">
                    {explanation}
                  </pre>
                </div>
              </div>
            )}

            {/* Execution Results */}
            {showExecution && (
              <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-6">
                <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                  <Terminal className="w-5 h-5 text-cyan-400" />
                  Execution Results
                </h3>

                {!executionResult ? (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="w-8 h-8 text-cyan-400 animate-spin" />
                  </div>
                ) : executionResult.success ? (
                  <>
                    <div className="flex items-center gap-2 mb-3">
                      <CheckCircle2 className="w-5 h-5 text-green-400" />
                      <span className="text-green-400 font-semibold">Success</span>
                    </div>
                    <div className="bg-gray-800 border border-green-500/30 rounded-lg p-4">
                      <pre className="text-sm text-gray-100 font-mono">
                        {executionResult.output}
                      </pre>
                    </div>
                    <div className="grid grid-cols-2 gap-4 mt-4">
                      <div className="p-3 bg-gray-800/50 rounded-lg">
                        <p className="text-xs text-gray-400 mb-1">
                          <Clock className="w-3 h-3 inline" /> Execution Time
                        </p>
                        <p className="text-lg font-bold text-green-400">
                          {executionResult.executionTime}ms
                        </p>
                      </div>
                      <div className="p-3 bg-gray-800/50 rounded-lg">
                        <p className="text-xs text-gray-400 mb-1">
                          <Hash className="w-3 h-3 inline" /> Memory Used
                        </p>
                        <p className="text-lg font-bold text-cyan-400">
                          {executionResult.memoryUsed}
                        </p>
                      </div>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="flex items-center gap-2 mb-3">
                      <XCircle className="w-5 h-5 text-red-400" />
                      <span className="text-red-400 font-semibold">Error</span>
                    </div>
                    <div className="bg-red-900/20 border border-red-500/30 rounded-lg p-4">
                      <pre className="text-sm text-red-300 font-mono">{executionResult.error}</pre>
                    </div>
                  </>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AILabCodePlaygroundPage;
