import React, { useState, useEffect } from 'react';
import { Page } from '../../App';
import {
  Beaker,
  Cpu,
  Zap,
  Database,
  Users,
  Rocket,
  Lock,
  GitBranch,
  BarChart3,
  Microscope,
  TestTube,
  Code,
  Brain,
  Eye,
  Network,
  Sparkles,
  Image as ImageIcon,
  MessageSquare,
  FileText,
  Languages,
  TrendingUp,
  ArrowRight,
  Play,
  Shield,
  Swords,
  Wand2,
  Terminal,
  LineChart,
  DollarSign,
  History,
  FlaskConical,
  Settings,
  Share2,
  BookOpen,
  Activity,
  Clock,
  Target,
  Crown,
} from 'lucide-react';
import { fetchLabMetrics, type LabMetricsResponse } from '../../services/analyticsService';
import { authService } from '../../services/authService';

interface AILabHubPageProps {
  onNavigate: (page: Page) => void;
}

interface LabFeature {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  route: Page;
  status: 'live' | 'beta' | 'coming-soon';
  category: 'core' | 'advanced' | 'research' | 'tools';
  metrics?: {
    tests?: number;
    users?: number;
    uptime?: string;
  };
}

interface QuickStat {
  label: string;
  value: string;
  change: string;
  icon: React.ReactNode;
  color: string;
}

interface SubscriptionStatus {
  hasActiveSubscription: boolean;
  subscriptionType: string | null;
  isLoading: boolean;
}

interface AILabDashboard {
  subscription?: {
    hasActiveSubscription?: boolean;
    subscriptionType?: string;
    expiresAt?: string;
  };
  permissions?: {
    maxExperimentsPerDay?: number;
  };
  usage?: {
    totalExperiments?: number;
    todayExperiments?: number;
    totalTokensUsed?: number;
    totalCostIncurred?: number;
  };
}

const DEFAULT_LAB_DAILY_LIMIT = 10;

const createDefaultLabDashboard = (): AILabDashboard => ({
  subscription: {
    hasActiveSubscription: false,
    subscriptionType: 'free',
  },
  permissions: {
    maxExperimentsPerDay: DEFAULT_LAB_DAILY_LIMIT,
  },
  usage: {
    totalExperiments: 0,
    todayExperiments: 0,
    totalTokensUsed: 0,
    totalCostIncurred: 0,
  },
});

const getStatColor = (color: string) => {
  switch (color) {
    case 'cyan':
      return 'from-cyan-500/10 to-blue-500/10 border-cyan-500/30';
    case 'purple':
      return 'from-purple-500/10 to-pink-500/10 border-purple-500/30';
    case 'green':
      return 'from-green-500/10 to-emerald-500/10 border-green-500/30';
    case 'blue':
      return 'from-blue-500/10 to-cyan-500/10 border-blue-500/30';
    default:
      return 'from-gray-500/10 to-gray-500/10 border-gray-500/30';
  }
};

const AILabHubPage: React.FC<AILabHubPageProps> = ({ onNavigate }) => {
  const [activeCategory, setActiveCategory] = useState<
    'all' | 'core' | 'advanced' | 'research' | 'tools'
  >('all');
  const [labMetrics, setLabMetrics] = useState<LabMetricsResponse>({});
  const [stats, setStats] = useState({
    totalExperiments: 0,
    totalTests: 0,
    activeUsers: 0,
    uptime: '99.9%',
  });
  const [subscriptionStatus, setSubscriptionStatus] = useState<SubscriptionStatus>({
    hasActiveSubscription: false,
    subscriptionType: null,
    isLoading: false,
  });
  const [labDashboard, setLabDashboard] = useState<AILabDashboard | null>(null);
  const [statusLoading, setStatusLoading] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [showSubscriptionModal, setShowSubscriptionModal] = useState(false);

  const effectiveDashboard = labDashboard || createDefaultLabDashboard();

  const hasLabAccess = Boolean(
    effectiveDashboard.subscription?.hasActiveSubscription &&
    subscriptionStatus.hasActiveSubscription
  );

  const experimentsLimit =
    effectiveDashboard.permissions?.maxExperimentsPerDay || DEFAULT_LAB_DAILY_LIMIT;
  const experimentsToday = effectiveDashboard.usage?.todayExperiments || 0;
  const experimentsTotal = effectiveDashboard.usage?.totalExperiments || 0;
  const experimentsPercent =
    experimentsLimit > 0 ? Math.min((experimentsToday / experimentsLimit) * 100, 100) : 0;

  const subscriptionLabel = hasLabAccess
    ? effectiveDashboard.subscription?.subscriptionType || 'Active'
    : isAuthenticated
      ? 'No Active Plan'
      : 'Visitor';

  const expiresLabel = effectiveDashboard.subscription?.expiresAt
    ? new Date(effectiveDashboard.subscription.expiresAt).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
      })
    : null;

  const subscriptionHelperText = hasLabAccess
    ? expiresLabel
      ? `Expires: ${expiresLabel}`
      : 'Subscription active'
    : isAuthenticated
      ? 'Upgrade to unlock AI Lab'
      : 'Log in to unlock AI Lab';

  const statusText = hasLabAccess ? 'Active' : isAuthenticated ? 'Not Active' : 'Visitor';
  const statusDescription = hasLabAccess
    ? 'AI Lab ready for experiments'
    : isAuthenticated
      ? 'Upgrade your plan to start testing'
      : 'Create an account to start experimenting';
  const statusColor = hasLabAccess
    ? 'text-green-400'
    : isAuthenticated
      ? 'text-yellow-400'
      : 'text-gray-400';

  // Check global IAMAI subscription status (any active plan unlocks AI Lab)
  useEffect(() => {
    const checkSubscription = async () => {
      try {
        if (!authService.isAuthenticated()) {
          setSubscriptionStatus({
            hasActiveSubscription: false,
            subscriptionType: null,
            isLoading: false,
          });
          return;
        }

        const response = await authService.authenticatedFetch('/api/subscription/current');
        if (response.ok) {
          const data = await response.json();
          const hasActiveSubscription = Boolean(data?.subscription && data.status === 'ACTIVE');
          const normalizedPlan = hasActiveSubscription
            ? (data.subscription.plan || 'MONTHLY').toLowerCase()
            : null;

          setSubscriptionStatus({
            hasActiveSubscription,
            subscriptionType: normalizedPlan,
            isLoading: false,
          });
        } else {
          setSubscriptionStatus({
            hasActiveSubscription: false,
            subscriptionType: null,
            isLoading: false,
          });
        }
      } catch (error) {
        console.error('Error checking subscription:', error);
        setSubscriptionStatus({
          hasActiveSubscription: false,
          subscriptionType: null,
          isLoading: false,
        });
      }
    };
    checkSubscription();
  }, []);

  // Load AI Lab dashboard for status cards
  useEffect(() => {
    const loadDashboard = async () => {
      try {
        const authenticated = authService.isAuthenticated();
        setIsAuthenticated(authenticated);

        if (!authenticated) {
          setLabDashboard(createDefaultLabDashboard());
          setStatusLoading(false);
          return;
        }

        const response = await authService.authenticatedFetch('/api/ai-lab/dashboard');
        if (response.ok) {
          const data = await response.json();
          if (data?.success && data.dashboard) {
            const { dashboard } = data;
            setLabDashboard({
              subscription: dashboard.subscription,
              permissions: dashboard.permissions,
              usage: dashboard.usage,
            });
          } else {
            setLabDashboard(createDefaultLabDashboard());
          }
        } else if (response.status === 403) {
          // Logged-in but no active IAMAI subscription
          setLabDashboard(createDefaultLabDashboard());
        } else {
          setLabDashboard(createDefaultLabDashboard());
        }
      } catch (error) {
        console.error('Failed to load AI Lab dashboard:', error);
        setLabDashboard(createDefaultLabDashboard());
      } finally {
        setStatusLoading(false);
      }
    };

    loadDashboard();
  }, []);

  // Load real-time lab metrics
  useEffect(() => {
    const loadMetrics = async () => {
      const metrics = await fetchLabMetrics();
      setLabMetrics(metrics);

      // Update summary stats
      const metricValues = Object.values(metrics);
      const totalTests = metricValues.reduce((sum, m) => sum + (m.tests || 0), 0);
      const totalUsers = metricValues.reduce((sum, m) => sum + (m.users || 0), 0);
      const totalViews = metricValues.reduce((sum, m) => sum + (m.views || 0), 0);
      setStats(prev => ({
        ...prev,
        totalTests,
        activeUsers: totalUsers,
        // Total experiments = total experiment sessions (views across all labs)
        totalExperiments: totalViews,
      }));
    };

    loadMetrics();

    // Poll for updates every 30 seconds
    const interval = setInterval(loadMetrics, 30000);
    return () => clearInterval(interval);
  }, []);

  // Legacy: Load stats from localStorage (fallback)
  useEffect(() => {
    const savedHistory = localStorage.getItem('ailab_global_history');
    if (savedHistory) {
      try {
        const history = JSON.parse(savedHistory);
        setStats(prev => ({
          ...prev,
          totalTests: Math.max(prev.totalTests, history.length),
          totalExperiments: Math.max(
            prev.totalExperiments,
            new Set(history.map((h: any) => h.experimentType)).size
          ),
        }));
      } catch (e) {
        console.error('Failed to load stats:', e);
      }
    }
  }, []);

  const features: LabFeature[] = [
    // Core Features
    {
      id: 'playground',
      title: 'Multi-Model Playground',
      description: 'Compare GPT, Claude, Gemini, and Mistral side-by-side in real-time',
      icon: <Cpu className="w-6 h-6" />,
      route: 'ai-lab-playground' as Page,
      status: 'live',
      category: 'core',
      metrics: labMetrics['playground'] || { tests: 0, users: 0 },
    },
    {
      id: 'prompt-engineering',
      title: 'Prompt Engineering Lab',
      description: 'Master prompt crafting with temperature controls and best practices',
      icon: <Wand2 className="w-6 h-6" />,
      route: 'ai-lab-prompt' as Page,
      status: 'live',
      category: 'core',
      metrics: labMetrics['prompt-engineering'] || { tests: 0, users: 0 },
    },
    {
      id: 'battle-arena',
      title: 'AI Battle Arena',
      description: 'Watch AI models debate and compete on topics in real-time',
      icon: <Swords className="w-6 h-6" />,
      route: 'ai-lab-battle' as Page,
      status: 'live',
      category: 'core',
      metrics: labMetrics['battle-arena'] || { tests: 0, users: 0 },
    },
    {
      id: 'text-transformers',
      title: 'Text Transformers',
      description: 'Style transfer, tone adjustment, and text rewriting experiments',
      icon: <Sparkles className="w-6 h-6" />,
      route: 'ai-lab-transformers' as Page,
      status: 'live',
      category: 'core',
      metrics: labMetrics['text-transformers'] || { tests: 0, users: 0 },
    },

    // Advanced Features
    {
      id: 'code-playground',
      title: 'Code Playground',
      description: 'Live code generation, debugging, and multi-language support',
      icon: <Terminal className="w-6 h-6" />,
      route: 'ai-lab-code' as Page,
      status: 'live',
      category: 'advanced',
      metrics: labMetrics['code-playground'] || { tests: 0, users: 0 },
    },
    {
      id: 'sentiment-analyzer',
      title: 'Sentiment Analyzer',
      description: 'Real-time emotion detection and tone analysis with visual charts',
      icon: <Activity className="w-6 h-6" />,
      route: 'ai-lab-sentiment' as Page,
      status: 'live',
      category: 'advanced',
      metrics: labMetrics['sentiment-analyzer'] || { tests: 0, users: 0 },
    },
    {
      id: 'cost-calculator',
      title: 'Token & Cost Calculator',
      description: 'Track usage, estimate costs, and optimize budget across providers',
      icon: <DollarSign className="w-6 h-6" />,
      route: 'ai-lab-cost' as Page,
      status: 'live',
      category: 'advanced',
      metrics: { tests: 298, users: 41 },
    },
    {
      id: 'benchmarking',
      title: 'Latency Benchmarking',
      description: 'Performance testing, response time analysis, and optimization',
      icon: <LineChart className="w-6 h-6" />,
      route: 'ai-lab-benchmark' as Page,
      status: 'beta',
      category: 'advanced',
    },

    // Research Features
    {
      id: 'research',
      title: 'Shannon Research Lab',
      description: 'Entropy measurement, bias detection, and hallucination analysis',
      icon: <Microscope className="w-6 h-6" />,
      route: 'ai-lab-research' as Page,
      status: 'beta',
      category: 'research',
    },
    {
      id: 'history',
      title: 'Experiment History',
      description: 'Full audit trail with export, visualization, and comparison tools',
      icon: <History className="w-6 h-6" />,
      route: 'ai-lab-history' as Page,
      status: 'live',
      category: 'research',
      metrics: { tests: stats.totalTests },
    },

    // Tools
    {
      id: 'api-settings',
      title: 'API Key Management',
      description: 'Secure storage for multiple providers and custom endpoints',
      icon: <Settings className="w-6 h-6" />,
      route: 'ai-lab-settings' as Page,
      status: 'live',
      category: 'tools',
    },
    {
      id: 'templates',
      title: 'Template Library',
      description: 'Community prompts, shareable experiments, and team workspaces',
      icon: <Share2 className="w-6 h-6" />,
      route: 'ai-lab-templates' as Page,
      status: 'beta',
      category: 'tools',
    },
  ];

  const quickStats: QuickStat[] = [
    {
      label: 'Total Experiments',
      value: stats.totalExperiments.toString(),
      change: '+12%',
      icon: <FlaskConical className="w-5 h-5" />,
      color: 'cyan',
    },
    {
      label: 'Tests Run',
      value: stats.totalTests.toLocaleString(),
      change: '+23%',
      icon: <TestTube className="w-5 h-5" />,
      color: 'purple',
    },
    {
      label: 'Active Users',
      value: stats.activeUsers.toString(),
      change: '+8%',
      icon: <Users className="w-5 h-5" />,
      color: 'green',
    },
    {
      label: 'System Uptime',
      value: stats.uptime,
      change: 'Stable',
      icon: <Target className="w-5 h-5" />,
      color: 'blue',
    },
  ];

  const categories = [
    { id: 'all', label: 'All Features', count: features.length },
    { id: 'core', label: 'Core', count: features.filter(f => f.category === 'core').length },
    {
      id: 'advanced',
      label: 'Advanced',
      count: features.filter(f => f.category === 'advanced').length,
    },
    {
      id: 'research',
      label: 'Research',
      count: features.filter(f => f.category === 'research').length,
    },
    { id: 'tools', label: 'Tools', count: features.filter(f => f.category === 'tools').length },
  ];

  const filteredFeatures =
    activeCategory === 'all' ? features : features.filter(f => f.category === activeCategory);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'live':
        return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'beta':
        return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      case 'coming-soon':
        return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
      default:
        return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
    }
  };

  const handleFeatureClick = (feature: LabFeature) => {
    if (feature.status === 'coming-soon') return;

    if (!subscriptionStatus.hasActiveSubscription) {
      setShowSubscriptionModal(true);
      return;
    }

    onNavigate(feature.route);
  };

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Subscription Modal */}
      {showSubscriptionModal && (
        <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-gray-900 border border-gray-800 rounded-2xl p-8 max-w-md w-full text-center">
            <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-cyan-500 to-blue-600 rounded-full flex items-center justify-center">
              <Beaker className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-white mb-3">AI Lab Hub Access Required</h2>
            <p className="text-gray-400 mb-6">
              The AI Lab Hub is a premium feature. Subscribe to unlock access to the complete suite
              of AI research and development tools.
            </p>
            <div className="space-y-3">
              <button
                onClick={() => setShowSubscriptionModal(false)}
                className="w-full bg-gray-800 hover:bg-gray-700 text-white px-6 py-3 rounded-lg font-semibold transition-all"
              >
                Cancel
              </button>
              <button
                onClick={() => (window.location.href = '/pricing')}
                className="w-full bg-gradient-to-r from-cyan-600 to-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:from-cyan-500 hover:to-blue-500 transition-all"
              >
                Upgrade Now
              </button>
            </div>
          </div>
        </div>
      )}
      {/* AI Lab Status Section */}
      {!statusLoading && (
        <section className="py-6 bg-gray-950/60 border-b border-gray-800">
          <div className="container mx-auto px-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              {/* Subscription */}
              <div className="bg-gray-900/60 rounded-xl p-4 border border-gray-800">
                <div className="flex items-center gap-3 mb-2">
                  <Crown className="w-5 h-5 text-yellow-400" />
                  <span className="text-sm font-semibold">Subscription Status</span>
                </div>
                <p className="text-2xl font-bold text-cyan-400">{subscriptionLabel}</p>
                <p className="text-sm text-gray-400 mt-1">{subscriptionHelperText}</p>
              </div>

              {/* Usage Today */}
              <div className="bg-gray-900/60 rounded-xl p-4 border border-gray-800">
                <div className="flex items-center gap-3 mb-2">
                  <FlaskConical
                    className={`w-5 h-5 ${hasLabAccess ? 'text-green-400' : 'text-gray-500'}`}
                  />
                  <span className="text-sm font-semibold">Experiments Today</span>
                </div>
                <p
                  className={`text-2xl font-bold ${
                    hasLabAccess ? 'text-green-400' : 'text-gray-400'
                  }`}
                >
                  {experimentsToday}/{experimentsLimit}
                </p>
                <div className="w-full bg-gray-800 rounded-full h-2 mt-2">
                  <div
                    className={`${hasLabAccess ? 'bg-green-400' : 'bg-gray-600'} h-2 rounded-full`}
                    style={{ width: `${experimentsPercent}%` }}
                  ></div>
                </div>
                <p className="text-sm text-gray-400 mt-2">
                  {hasLabAccess
                    ? 'Experiments run today'
                    : isAuthenticated
                      ? 'Upgrade for higher daily limits'
                      : 'Sign in to start experimenting'}
                </p>
              </div>

              {/* Total Experiments */}
              <div className="bg-gray-900/60 rounded-xl p-4 border border-gray-800">
                <div className="flex items-center gap-3 mb-2">
                  <Beaker className="w-5 h-5 text-cyan-400" />
                  <span className="text-sm font-semibold">Total Experiments</span>
                </div>
                <p className="text-2xl font-bold text-blue-400">{experimentsTotal}</p>
                <p className="text-sm text-gray-400">Lifetime experiments across your AI Lab</p>
              </div>

              {/* Status */}
              <div className="bg-gray-900/60 rounded-xl p-4 border border-gray-800">
                <div className="flex items-center gap-3 mb-2">
                  <Target className={`w-5 h-5 ${statusColor}`} />
                  <span className="text-sm font-semibold">Status</span>
                </div>
                <p className={`text-2xl font-bold ${statusColor}`}>{statusText}</p>
                <p className="text-sm text-gray-400">{statusDescription}</p>
              </div>
            </div>
          </div>
        </section>
      )}
      {/* Hero Section */}
      <section className="relative overflow-hidden py-16 md:py-24 border-b border-gray-800">
        <div className="absolute inset-0 bg-grid-gray-900 [mask-image:linear-gradient(to_bottom,white_40%,transparent)]"></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-gradient-to-r from-cyan-500/10 via-purple-500/10 to-blue-500/10 rounded-full blur-3xl"></div>

        <div className="container mx-auto px-6 relative z-10">
          <div className="text-center max-w-4xl mx-auto">
            <div className="inline-flex items-center gap-2 bg-cyan-500/10 border border-cyan-500/30 rounded-full px-4 py-2 mb-6">
              <Beaker className="w-4 h-4 text-cyan-400" />
              <span className="text-sm font-semibold text-cyan-400">AI Testing Laboratory</span>
            </div>

            <h1 className="text-5xl md:text-7xl font-extrabold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-white via-cyan-400 to-purple-400">
              The Mythic Lab
            </h1>

            <div className="flex justify-center mb-4">
              <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold border border-emerald-400/50 bg-emerald-500/10 text-emerald-300">
                <Crown className="w-3 h-3" />
                Included with any active subscription
              </span>
            </div>

            <p className="text-xl text-gray-400 mb-8 leading-relaxed">
              Where AI models compete, experiments unfold, and every test becomes a breakthrough.
              <br />
              <span className="text-cyan-400">Real AI. Real Results. Real-Time.</span>
            </p>

            <div className="flex flex-wrap items-center justify-center gap-4">
              <button
                onClick={() => {
                  if (subscriptionStatus.hasActiveSubscription) {
                    onNavigate('ai-lab-playground' as Page);
                  } else {
                    setShowSubscriptionModal(true);
                  }
                }}
                className="px-8 py-4 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-semibold rounded-xl shadow-lg shadow-cyan-500/20 transition-all flex items-center gap-2 group"
              >
                <Play className="w-5 h-5 group-hover:scale-110 transition-transform" />
                Start Experimenting
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                onClick={() => onNavigate('documentation' as Page)}
                className="px-8 py-4 bg-gray-900/80 hover:bg-gray-800 border border-gray-700 hover:border-cyan-500/50 text-white font-semibold rounded-xl transition-all flex items-center gap-2"
              >
                <BookOpen className="w-5 h-5" />
                View Documentation
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Quick Stats */}
      <section className="py-12 bg-gray-900/20 border-b border-gray-800">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {quickStats.map((stat, index) => (
              <div
                key={index}
                className={`bg-gradient-to-br ${getStatColor(stat.color)} border rounded-xl p-6 hover:scale-105 transition-transform`}
              >
                <div className="flex items-center justify-between mb-3">
                  <span className="text-sm text-gray-400">{stat.label}</span>
                  <div className="text-cyan-400">{stat.icon}</div>
                </div>
                <div className="flex items-end justify-between">
                  <p className="text-3xl font-bold text-white">{stat.value}</p>
                  <span className="text-xs text-green-400 font-semibold">{stat.change}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16">
        <div className="container mx-auto px-6">
          {/* Category Filters */}
          <div className="mb-8">
            <h2 className="text-3xl font-bold text-white mb-6">Laboratory Features</h2>
            <div className="flex flex-wrap gap-3">
              {categories.map(cat => (
                <button
                  key={cat.id}
                  onClick={() => setActiveCategory(cat.id as any)}
                  className={`px-6 py-3 rounded-xl font-semibold transition-all ${
                    activeCategory === cat.id
                      ? 'bg-cyan-500 text-black shadow-lg shadow-cyan-500/30'
                      : 'bg-gray-900/50 text-gray-400 hover:bg-gray-800 border border-gray-800 hover:text-cyan-400'
                  }`}
                >
                  {cat.label}
                  <span
                    className={`ml-2 px-2 py-0.5 rounded-full text-xs ${
                      activeCategory === cat.id ? 'bg-black/20' : 'bg-gray-800'
                    }`}
                  >
                    {cat.count}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Feature Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredFeatures.map(feature => (
              <div
                key={feature.id}
                onClick={() => handleFeatureClick(feature)}
                className={`relative group bg-gray-900/50 border border-gray-800 rounded-2xl p-6 hover:border-cyan-500/50 transition-all ${
                  feature.status === 'live' || feature.status === 'beta'
                    ? 'cursor-pointer'
                    : 'opacity-60 cursor-not-allowed'
                }`}
              >
                {/* Status Badge */}
                <div className="absolute top-4 right-4">
                  <span
                    className={`text-xs font-semibold px-3 py-1.5 rounded-full border ${getStatusColor(feature.status)}`}
                  >
                    {feature.status === 'live'
                      ? '🟢 Live'
                      : feature.status === 'beta'
                        ? '🟡 Beta'
                        : '⏳ Coming Soon'}
                  </span>
                </div>

                {/* Lock Badge for Non-Subscribers */}
                {!subscriptionStatus.hasActiveSubscription &&
                  (feature.status === 'live' || feature.status === 'beta') && (
                    <div className="absolute top-4 left-4 z-20">
                      <div className="inline-flex items-center gap-1 px-3 py-1.5 bg-gray-800/90 border border-gray-600 rounded-full">
                        <Lock className="w-3 h-3 text-gray-400" />
                        <span className="text-xs font-semibold text-gray-400">Premium</span>
                      </div>
                    </div>
                  )}

                {/* Icon */}
                <div
                  className={`w-14 h-14 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-all ${
                    !subscriptionStatus.hasActiveSubscription &&
                    (feature.status === 'live' || feature.status === 'beta')
                      ? 'bg-gray-800 text-gray-500'
                      : 'bg-cyan-500/20 border border-cyan-500/30 text-cyan-400 group-hover:bg-cyan-500/30'
                  }`}
                >
                  {feature.icon}
                </div>

                {/* Content */}
                <h3
                  className={`text-xl font-bold mb-2 group-hover:text-cyan-400 transition-colors ${
                    !subscriptionStatus.hasActiveSubscription &&
                    (feature.status === 'live' || feature.status === 'beta')
                      ? 'text-gray-500'
                      : 'text-white'
                  }`}
                >
                  {feature.title}
                </h3>
                <p
                  className={`text-sm mb-4 leading-relaxed ${
                    !subscriptionStatus.hasActiveSubscription &&
                    (feature.status === 'live' || feature.status === 'beta')
                      ? 'text-gray-500'
                      : 'text-gray-400'
                  }`}
                >
                  {feature.description}
                </p>

                {/* Metrics */}
                {feature.metrics && (
                  <div className="flex items-center gap-4 pt-4 border-t border-gray-800">
                    {feature.metrics.tests !== undefined && (
                      <div className="flex items-center gap-1.5 text-xs text-gray-500">
                        <TestTube className="w-3.5 h-3.5" />
                        <span>{feature.metrics.tests} tests</span>
                      </div>
                    )}
                    {feature.metrics.users !== undefined && (
                      <div className="flex items-center gap-1.5 text-xs text-gray-500">
                        <Users className="w-3.5 h-3.5" />
                        <span>{feature.metrics.users} users</span>
                      </div>
                    )}
                  </div>
                )}

                {/* Hover Arrow */}
                {(feature.status === 'live' || feature.status === 'beta') &&
                  subscriptionStatus.hasActiveSubscription && (
                    <div className="absolute bottom-6 right-6 opacity-0 group-hover:opacity-100 transition-opacity">
                      <ArrowRight className="w-5 h-5 text-cyan-400" />
                    </div>
                  )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 border-t border-gray-800">
        <div className="container mx-auto px-6">
          <div className="bg-gradient-to-r from-cyan-500/10 via-purple-500/10 to-blue-500/10 border border-cyan-500/30 rounded-3xl p-12 text-center">
            <h2 className="text-4xl font-bold text-white mb-4">Ready to Push the Boundaries?</h2>
            <p className="text-xl text-gray-400 mb-8 max-w-2xl mx-auto">
              Join researchers, developers, and AI enthusiasts experimenting with cutting-edge
              models in real-time.
            </p>
            <div className="flex flex-wrap items-center justify-center gap-4">
              <button
                onClick={() => {
                  if (subscriptionStatus.hasActiveSubscription) {
                    onNavigate('ai-lab-playground' as Page);
                  } else {
                    setShowSubscriptionModal(true);
                  }
                }}
                className="px-8 py-4 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold rounded-xl shadow-lg shadow-cyan-500/20 transition-all"
              >
                Launch Playground
              </button>
              <button
                onClick={() => {
                  if (subscriptionStatus.hasActiveSubscription) {
                    onNavigate('ai-lab-settings' as Page);
                  } else {
                    setShowSubscriptionModal(true);
                  }
                }}
                className="px-8 py-4 bg-gray-900 hover:bg-gray-800 border border-gray-700 hover:border-cyan-500/50 text-white font-bold rounded-xl transition-all"
              >
                Configure API Keys
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default AILabHubPage;
