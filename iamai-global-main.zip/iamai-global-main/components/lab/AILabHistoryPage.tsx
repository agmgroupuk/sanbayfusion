import React, { useState, useEffect } from 'react';
import {
  History,
  Filter,
  Download,
  Trash2,
  Search,
  Calendar,
  TrendingUp,
  BarChart3,
  Eye,
  Copy,
  RefreshCw,
  Info,
  Lock,
  Crown,
} from 'lucide-react';
import { authService } from '../../services/authService';

interface ExperimentRecord {
  id: string;
  type:
    | 'playground'
    | 'prompt'
    | 'battle'
    | 'transformers'
    | 'code'
    | 'sentiment'
    | 'cost'
    | 'latency';
  timestamp: number;
  data: any;
}

interface FilterOptions {
  type: string[];
  dateRange: 'all' | 'today' | 'week' | 'month';
  searchTerm: string;
}

interface SubscriptionStatus {
  hasAccess: boolean;
  type: string;
  expiresAt?: Date;
  usageToday: number;
  usageLimit: number;
  hasActiveSubscription: boolean;
}

const TYPE_ICONS: { [key: string]: { icon: string; label: string; color: string } } = {
  playground: { icon: '🎮', label: 'Playground', color: 'blue' },
  prompt: { icon: '📝', label: 'Prompt Lab', color: 'purple' },
  battle: { icon: '⚔️', label: 'Battle Arena', color: 'red' },
  transformers: { icon: '🎨', label: 'Transformers', color: 'pink' },
  code: { icon: '💻', label: 'Code Gen', color: 'green' },
  sentiment: { icon: '😊', label: 'Sentiment', color: 'yellow' },
  cost: { icon: '💰', label: 'Cost Calc', color: 'emerald' },
  latency: { icon: '⚡', label: 'Latency', color: 'orange' },
};

const AILabHistoryPage: React.FC<{ onNavigate: (page: string) => void }> = ({ onNavigate }) => {
  // Subscription State
  const [subscriptionStatus, setSubscriptionStatus] = useState<SubscriptionStatus>({
    hasAccess: false,
    type: 'free',
    usageToday: 0,
    usageLimit: 0,
    hasActiveSubscription: false,
  });

  // Check subscription status
  useEffect(() => {
    const checkSubscription = async () => {
      try {
        const hasActiveSubscription = false; // Set to false for testing subscription barrier
        setSubscriptionStatus({
          hasAccess: hasActiveSubscription,
          type: hasActiveSubscription ? 'premium' : 'free',
          usageToday: 0,
          usageLimit: hasActiveSubscription ? 1000 : 5,
          hasActiveSubscription,
        });
      } catch (error) {
        console.error('Error checking subscription:', error);
      }
    };
    checkSubscription();
  }, []);

  const [experiments, setExperiments] = useState<ExperimentRecord[]>([]);
  const [filteredExperiments, setFilteredExperiments] = useState<ExperimentRecord[]>([]);
  const [filters, setFilters] = useState<FilterOptions>({
    type: [],
    dateRange: 'all',
    searchTerm: '',
  });
  const [selectedExperiment, setSelectedExperiment] = useState<ExperimentRecord | null>(null);
  const [showInfo, setShowInfo] = useState(false);
  const [stats, setStats] = useState({
    total: 0,
    byType: {} as { [key: string]: number },
    mostUsed: '',
    avgPerDay: 0,
  });

  // Load experiments from localStorage
  useEffect(() => {
    loadExperiments();
  }, []);

  // Apply filters
  useEffect(() => {
    applyFilters();
  }, [experiments, filters]);

  // Calculate stats
  useEffect(() => {
    calculateStats();
  }, [experiments]);

  const loadExperiments = () => {
    try {
      const saved = localStorage.getItem('ailab_global_history');
      if (saved) {
        const parsed = JSON.parse(saved);
        setExperiments(parsed);
      }
    } catch (e) {
      console.error('Failed to load experiments:', e);
    }
  };

  const applyFilters = () => {
    let filtered = [...experiments];

    // Type filter
    if (filters.type.length > 0) {
      filtered = filtered.filter(exp => filters.type.includes(exp.type));
    }

    // Date range filter
    const now = Date.now();
    const dayMs = 24 * 60 * 60 * 1000;
    switch (filters.dateRange) {
      case 'today':
        filtered = filtered.filter(exp => now - exp.timestamp < dayMs);
        break;
      case 'week':
        filtered = filtered.filter(exp => now - exp.timestamp < 7 * dayMs);
        break;
      case 'month':
        filtered = filtered.filter(exp => now - exp.timestamp < 30 * dayMs);
        break;
    }

    // Search term filter
    if (filters.searchTerm.trim()) {
      const term = filters.searchTerm.toLowerCase();
      filtered = filtered.filter(exp => {
        const dataStr = JSON.stringify(exp.data).toLowerCase();
        return dataStr.includes(term) || exp.type.includes(term);
      });
    }

    setFilteredExperiments(filtered);
  };

  const calculateStats = () => {
    const byType: { [key: string]: number } = {};
    experiments.forEach(exp => {
      byType[exp.type] = (byType[exp.type] || 0) + 1;
    });

    const mostUsed = Object.entries(byType).sort((a, b) => b[1] - a[1])[0]?.[0] || '';

    const oldestTimestamp = Math.min(...experiments.map(exp => exp.timestamp));
    const daysSinceFirst = oldestTimestamp
      ? (Date.now() - oldestTimestamp) / (24 * 60 * 60 * 1000)
      : 1;
    const avgPerDay = experiments.length / Math.max(daysSinceFirst, 1);

    setStats({
      total: experiments.length,
      byType,
      mostUsed,
      avgPerDay,
    });
  };

  const toggleTypeFilter = (type: string) => {
    setFilters(prev => ({
      ...prev,
      type: prev.type.includes(type) ? prev.type.filter(t => t !== type) : [...prev.type, type],
    }));
  };

  const clearAllData = () => {
    if (confirm('Are you sure you want to delete ALL experiment history? This cannot be undone.')) {
      localStorage.setItem('ailab_global_history', JSON.stringify([]));
      setExperiments([]);
      setSelectedExperiment(null);
    }
  };

  const deleteExperiment = (id: string) => {
    const updated = experiments.filter(exp => exp.id !== id);
    setExperiments(updated);
    localStorage.setItem('ailab_global_history', JSON.stringify(updated));
    if (selectedExperiment?.id === id) {
      setSelectedExperiment(null);
    }
  };

  const exportAll = () => {
    const data = {
      exported: new Date().toISOString(),
      totalExperiments: experiments.length,
      experiments: experiments.map(exp => ({
        ...exp,
        timestamp: new Date(exp.timestamp).toISOString(),
      })),
    };

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ailab-history-export-${Date.now()}.json`;
    a.click();
  };

  const exportFiltered = () => {
    const data = {
      exported: new Date().toISOString(),
      filters: filters,
      totalExperiments: filteredExperiments.length,
      experiments: filteredExperiments.map(exp => ({
        ...exp,
        timestamp: new Date(exp.timestamp).toISOString(),
      })),
    };

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ailab-filtered-export-${Date.now()}.json`;
    a.click();
  };

  const formatTimestamp = (timestamp: number): string => {
    const date = new Date(timestamp);
    const now = Date.now();
    const diff = now - timestamp;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 1) return 'Just now';
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    if (days < 7) return `${days}d ago`;
    return date.toLocaleDateString();
  };

  const renderExperimentSummary = (exp: ExperimentRecord): string => {
    switch (exp.type) {
      case 'playground':
        return `Compared ${exp.data.providers?.length || 0} providers`;
      case 'prompt':
        return exp.data.category || 'Custom prompt';
      case 'battle':
        return `Battle: ${exp.data.topic || 'Unknown'}`;
      case 'transformers':
        return `Style: ${exp.data.style || 'Unknown'}`;
      case 'code':
        return `${exp.data.language || 'Unknown'} - ${exp.data.task || 'Generation'}`;
      case 'sentiment':
        return `Sentiment: ${exp.data.overall || 'Unknown'}`;
      case 'cost':
        return `$${exp.data.totalCost?.toFixed(4) || '0'} - ${exp.data.modelName || 'Unknown'}`;
      case 'latency':
        return `${exp.data.totalTime?.toFixed(0) || 0}ms - ${exp.data.providerName || 'Unknown'}`;
      default:
        return 'Experiment';
    }
  };

  const renderDetailedView = (exp: ExperimentRecord) => {
    const config = TYPE_ICONS[exp.type];

    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="text-3xl">{config.icon}</div>
            <div>
              <h3 className="text-xl font-semibold">{config.label}</h3>
              <p className="text-sm text-gray-400">{formatTimestamp(exp.timestamp)}</p>
            </div>
          </div>
          <div className="flex space-x-2">
            <button
              onClick={() => {
                navigator.clipboard.writeText(JSON.stringify(exp.data, null, 2));
              }}
              className="p-2 bg-gray-700/50 hover:bg-gray-700 rounded-lg transition-colors"
            >
              <Copy className="w-4 h-4" />
            </button>
            <button
              onClick={() => deleteExperiment(exp.id)}
              className="p-2 bg-red-500/20 hover:bg-red-500/30 rounded-lg transition-colors border border-red-500/30"
            >
              <Trash2 className="w-4 h-4 text-red-400" />
            </button>
          </div>
        </div>

        <div className="bg-black/40 rounded-lg p-4 max-h-96 overflow-y-auto">
          <pre className="text-xs text-gray-300 whitespace-pre-wrap break-words">
            {JSON.stringify(exp.data, null, 2)}
          </pre>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 text-white relative">
      {/* Subscription Access Barrier */}
      {!subscriptionStatus.hasActiveSubscription && (
        <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-gray-900 border border-gray-800 rounded-2xl p-8 max-w-md w-full text-center">
            <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-gray-500 to-slate-600 rounded-full flex items-center justify-center">
              <Crown className="w-8 h-8 text-black" />
            </div>
            <h2 className="text-2xl font-bold text-white mb-3">History Lab Access Required</h2>
            <p className="text-gray-400 mb-6">
              Advanced Usage Analytics & History Tracking is a premium feature. Subscribe to unlock
              comprehensive experiment history, detailed analytics, and advanced filtering
              capabilities.
            </p>
            <div className="flex flex-col gap-3 mb-6">
              <div className="flex items-center gap-2 text-sm text-gray-300">
                <Lock className="w-4 h-4 text-gray-400" />
                <span>Complete experiment history</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-300">
                <History className="w-4 h-4 text-slate-400" />
                <span>Advanced analytics & insights</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-300">
                <BarChart3 className="w-4 h-4 text-gray-400" />
                <span>Export & filtering tools</span>
              </div>
            </div>
            <div className="flex flex-col sm:flex-row gap-3">
              <button
                onClick={() => onNavigate('subscription')}
                className="flex-1 bg-gradient-to-r from-gray-600 to-slate-600 text-white px-6 py-3 rounded-lg font-semibold hover:from-gray-500 hover:to-slate-500 transition-all flex items-center justify-center gap-2"
              >
                <Crown className="w-4 h-4" />
                Subscribe Now
              </button>
              <button
                onClick={() => onNavigate('ai-lab')}
                className="flex-1 bg-gray-800 hover:bg-gray-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors"
              >
                Back to Lab
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="border-b border-cyan-500/20 bg-black/40 backdrop-blur-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => onNavigate('ai-lab')}
                className="text-cyan-400 hover:text-cyan-300 transition-colors"
              >
                ← Back to Hub
              </button>
              <div className="flex items-center space-x-2">
                <History className="w-6 h-6 text-cyan-400" />
                <h1 className="text-2xl font-bold bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent">
                  Experiment History
                </h1>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <button
                onClick={loadExperiments}
                className="p-2 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/20 transition-colors border border-cyan-500/30"
              >
                <RefreshCw className="w-5 h-5 text-cyan-400" />
              </button>
              <button
                onClick={() => setShowInfo(!showInfo)}
                className="p-2 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/20 transition-colors border border-cyan-500/30"
              >
                <Info className="w-5 h-5 text-cyan-400" />
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Filters & Stats Sidebar */}
          <div className="space-y-6">
            {/* Stats */}
            <div className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm rounded-xl border border-cyan-500/20 p-6">
              <h2 className="text-lg font-semibold mb-4 flex items-center">
                <BarChart3 className="w-5 h-5 text-cyan-400 mr-2" />
                Statistics
              </h2>
              <div className="space-y-4">
                <div>
                  <div className="text-3xl font-bold text-cyan-400">{stats.total}</div>
                  <div className="text-sm text-gray-400">Total Experiments</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-purple-400">
                    {stats.avgPerDay.toFixed(1)}
                  </div>
                  <div className="text-sm text-gray-400">Avg per Day</div>
                </div>
                {stats.mostUsed && (
                  <div>
                    <div className="text-lg font-bold text-blue-400">
                      {TYPE_ICONS[stats.mostUsed]?.label}
                    </div>
                    <div className="text-sm text-gray-400">Most Used Tool</div>
                  </div>
                )}
              </div>
            </div>

            {/* Type Filter */}
            <div className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm rounded-xl border border-cyan-500/20 p-6">
              <h2 className="text-lg font-semibold mb-4 flex items-center">
                <Filter className="w-5 h-5 text-cyan-400 mr-2" />
                Filter by Type
              </h2>
              <div className="space-y-2">
                {Object.entries(TYPE_ICONS).map(([type, config]) => {
                  const count = stats.byType[type] || 0;
                  const isSelected = filters.type.includes(type);

                  return (
                    <button
                      key={type}
                      onClick={() => toggleTypeFilter(type)}
                      disabled={count === 0}
                      className={`w-full p-3 rounded-lg border transition-all text-left ${
                        isSelected
                          ? `bg-${config.color}-500/20 border-${config.color}-400`
                          : 'bg-gray-800/50 border-gray-700 hover:border-gray-600'
                      } disabled:opacity-30 disabled:cursor-not-allowed`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <span>{config.icon}</span>
                          <span className="text-sm">{config.label}</span>
                        </div>
                        <span className="text-xs text-gray-400">{count}</span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Date Range Filter */}
            <div className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm rounded-xl border border-cyan-500/20 p-6">
              <h2 className="text-lg font-semibold mb-4 flex items-center">
                <Calendar className="w-5 h-5 text-cyan-400 mr-2" />
                Date Range
              </h2>
              <div className="space-y-2">
                {['all', 'today', 'week', 'month'].map(range => (
                  <button
                    key={range}
                    onClick={() => setFilters(prev => ({ ...prev, dateRange: range as any }))}
                    className={`w-full p-3 rounded-lg border transition-all text-left ${
                      filters.dateRange === range
                        ? 'bg-cyan-500/20 border-cyan-400'
                        : 'bg-gray-800/50 border-gray-700 hover:border-gray-600'
                    }`}
                  >
                    <span className="text-sm capitalize">
                      {range === 'all'
                        ? 'All Time'
                        : range === 'week'
                          ? 'Past Week'
                          : range === 'month'
                            ? 'Past Month'
                            : 'Today'}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Actions */}
            <div className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm rounded-xl border border-cyan-500/20 p-6">
              <h2 className="text-lg font-semibold mb-4">Actions</h2>
              <div className="space-y-2">
                <button
                  onClick={exportAll}
                  disabled={experiments.length === 0}
                  className="w-full p-3 bg-cyan-500/20 hover:bg-cyan-500/30 rounded-lg transition-colors border border-cyan-500/30 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
                >
                  <Download className="w-4 h-4" />
                  <span className="text-sm">Export All</span>
                </button>
                <button
                  onClick={exportFiltered}
                  disabled={filteredExperiments.length === 0}
                  className="w-full p-3 bg-blue-500/20 hover:bg-blue-500/30 rounded-lg transition-colors border border-blue-500/30 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
                >
                  <Download className="w-4 h-4" />
                  <span className="text-sm">Export Filtered</span>
                </button>
                <button
                  onClick={clearAllData}
                  disabled={experiments.length === 0}
                  className="w-full p-3 bg-red-500/20 hover:bg-red-500/30 rounded-lg transition-colors border border-red-500/30 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
                >
                  <Trash2 className="w-4 h-4" />
                  <span className="text-sm">Clear All</span>
                </button>
              </div>
            </div>

            {/* Info Panel */}
            {showInfo && (
              <div className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm rounded-xl border border-cyan-500/20 p-6">
                <h2 className="text-lg font-semibold mb-4 flex items-center">
                  <Info className="w-5 h-5 text-cyan-400 mr-2" />
                  About History
                </h2>
                <div className="space-y-3 text-sm text-gray-300">
                  <p>
                    Track all your AI Lab experiments in one place. Filter, search, export, and
                    analyze your usage.
                  </p>
                  <div>
                    <div className="font-semibold text-white mb-1">Features:</div>
                    <ul className="list-disc list-inside space-y-1 text-gray-400">
                      <li>Unified history across all tools</li>
                      <li>Advanced filtering & search</li>
                      <li>Export to JSON</li>
                      <li>Usage statistics</li>
                      <li>Detailed experiment views</li>
                    </ul>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3 space-y-6">
            {/* Search Bar */}
            <div className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm rounded-xl border border-cyan-500/20 p-4">
              <div className="flex items-center space-x-3">
                <Search className="w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  value={filters.searchTerm}
                  onChange={e => setFilters(prev => ({ ...prev, searchTerm: e.target.value }))}
                  placeholder="Search experiments..."
                  className="flex-1 bg-transparent border-none text-white placeholder-gray-500 focus:outline-none"
                />
                {filters.searchTerm && (
                  <button
                    onClick={() => setFilters(prev => ({ ...prev, searchTerm: '' }))}
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    Clear
                  </button>
                )}
              </div>
            </div>

            {/* Results Count */}
            <div className="text-sm text-gray-400">
              Showing {filteredExperiments.length} of {experiments.length} experiments
            </div>

            {/* Experiments List */}
            {filteredExperiments.length === 0 ? (
              <div className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm rounded-xl border border-cyan-500/20 p-12 text-center">
                <History className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">No Experiments Found</h3>
                <p className="text-gray-400">
                  {experiments.length === 0
                    ? 'Start using AI Lab tools to build your experiment history.'
                    : 'Try adjusting your filters or search term.'}
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {filteredExperiments.map(exp => {
                  const config = TYPE_ICONS[exp.type];
                  const isSelected = selectedExperiment?.id === exp.id;

                  return (
                    <div
                      key={exp.id}
                      className={`bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm rounded-xl border transition-all ${
                        isSelected ? 'border-cyan-400' : 'border-gray-700 hover:border-cyan-500/50'
                      } overflow-hidden`}
                    >
                      <div
                        className="p-5 cursor-pointer"
                        onClick={() => setSelectedExperiment(isSelected ? null : exp)}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3 flex-1">
                            <div className="text-2xl">{config.icon}</div>
                            <div className="flex-1">
                              <div className="font-medium">{config.label}</div>
                              <div className="text-sm text-gray-400">
                                {renderExperimentSummary(exp)}
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center space-x-4">
                            <div className="text-right">
                              <div className="text-sm text-gray-400">
                                {formatTimestamp(exp.timestamp)}
                              </div>
                            </div>
                            <Eye className="w-5 h-5 text-cyan-400" />
                          </div>
                        </div>
                      </div>

                      {isSelected && (
                        <div className="border-t border-gray-700 p-5">
                          {renderDetailedView(exp)}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AILabHistoryPage;
