// AI Lab Pages - Centralized exports
export { default as AILabHubPage } from './AILabHubPage';
export { default as AILabPlaygroundPage } from './AILabPlaygroundPage';
export { default as AILabPromptPage } from './AILabPromptPage';
export { default as AILabBattlePage } from './AILabBattlePage';
export { default as AILabTransformersPage } from './AILabTransformersPage';
export { default as AILabCodePlaygroundPage } from './AILabCodePlaygroundPage';
export { default as AILabSentimentAnalyzerPage } from './AILabSentimentAnalyzerPage';
export { default as AILabCostCalculatorPage } from './AILabCostCalculatorPage';
export { default as AILabLatencyPage } from './AILabLatencyPage';
export { default as AILabHistoryPage } from './AILabHistoryPage';
export { default as AILabResearchPage } from './AILabResearchPage';
export { default as AILabSettingsPage } from './AILabSettingsPage';
export { default as AILabTemplatesPage } from './AILabTemplatesPage';

// Export types
export type { Page } from '../../App';
