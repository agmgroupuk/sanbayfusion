import React, { useState, useRef, useEffect } from 'react';
import { Page } from '../../App';
import {
  ArrowLeft,
  Play,
  Cpu,
  Zap,
  DollarSign,
  Clock,
  Hash,
  Copy,
  Download,
  Trash2,
  RefreshCw,
  Settings,
  ChevronDown,
  MessageSquare,
  Check,
  AlertCircle,
  Sparkles,
  Lock,
  Crown,
} from 'lucide-react';
import { aiLabService } from '../../services/aiLabService';
import { trackLabView, trackLabTest } from '../../services/analyticsService';
import { authService } from '../../services/authService';

interface AILabPlaygroundPageProps {
  onNavigate: (page: Page) => void;
}

interface ModelConfig {
  id: string;
  name: string;
  provider: 'openai' | 'anthropic' | 'google' | 'mistral';
  color: string;
  icon: string;
  pricing: {
    input: number; // per 1M tokens
    output: number; // per 1M tokens
  };
}

interface TestResult {
  modelId: string;
  response: string;
  tokens: {
    input: number;
    output: number;
    total: number;
  };
  cost: number;
  latency: number;
  timestamp: number;
  status: 'pending' | 'streaming' | 'complete' | 'error';
  error?: string;
}

interface SubscriptionStatus {
  hasActiveSubscription: boolean;
  subscriptionType: string | null;
  isLoading: boolean;
}

const AILabPlaygroundPage: React.FC<AILabPlaygroundPageProps> = ({ onNavigate }) => {
  // Models Configuration
  const models: ModelConfig[] = [
    {
      id: 'gpt-4-turbo',
      name: 'GPT-4 Turbo',
      provider: 'openai',
      color: 'from-green-500 to-emerald-500',
      icon: '🤖',
      pricing: { input: 10, output: 30 },
    },
    {
      id: 'claude-3-haiku-20240307',
      name: 'Claude 3 Haiku',
      provider: 'anthropic',
      color: 'from-purple-500 to-pink-500',
      icon: '🧠',
      pricing: { input: 0.25, output: 1.25 },
    },
    {
      id: 'gemini-pro-latest',
      name: 'Gemini Pro',
      provider: 'google',
      color: 'from-blue-500 to-cyan-500',
      icon: '💎',
      pricing: { input: 0.5, output: 1.5 },
    },
    {
      id: 'mistral-large-latest',
      name: 'Mistral Large',
      provider: 'mistral',
      color: 'from-orange-500 to-red-500',
      icon: '🌪️',
      pricing: { input: 2, output: 6 },
    },
  ];

  // State
  const [selectedModels, setSelectedModels] = useState<string[]>([models[0].id, models[1].id]);
  const [prompt, setPrompt] = useState('');
  const [systemMessage, setSystemMessage] = useState('You are a helpful AI assistant.');
  const [results, setResults] = useState<Record<string, TestResult>>({});
  const [isRunning, setIsRunning] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [comparisonMode, setComparisonMode] = useState<'side-by-side' | 'stacked'>('side-by-side');
  const [subscriptionStatus, setSubscriptionStatus] = useState<SubscriptionStatus>({
    hasActiveSubscription: false,
    subscriptionType: null,
    isLoading: false,
  });
  const [showSubscriptionModal, setShowSubscriptionModal] = useState(true);

  // Model Parameters
  const [temperature, setTemperature] = useState(0.7);
  const [maxTokens, setMaxTokens] = useState(500);
  const [topP, setTopP] = useState(1);

  const promptRef = useRef<HTMLTextAreaElement>(null);

  // Track page view on mount
  useEffect(() => {
    trackLabView('playground');
  }, []);

  // Check subscription status
  useEffect(() => {
    const checkSubscription = async () => {
      try {
        if (!authService.isAuthenticated()) {
          setShowSubscriptionModal(true);
          return;
        }
        // For testing: force no subscription
        setSubscriptionStatus({
          hasActiveSubscription: false,
          subscriptionType: null,
          isLoading: false,
        });
      } catch (error) {
        console.error('Error checking subscription:', error);
      }
    };
    checkSubscription();
  }, []);

  // Auto-resize textarea
  useEffect(() => {
    if (promptRef.current) {
      promptRef.current.style.height = 'auto';
      promptRef.current.style.height = promptRef.current.scrollHeight + 'px';
    }
  }, [prompt]);

  // Toggle model selection
  const toggleModel = (modelId: string) => {
    if (selectedModels.includes(modelId)) {
      if (selectedModels.length > 1) {
        setSelectedModels(selectedModels.filter(id => id !== modelId));
      }
    } else {
      if (selectedModels.length < 4) {
        setSelectedModels([...selectedModels, modelId]);
      }
    }
  };

  // Estimate tokens (rough approximation)
  const estimateTokens = (text: string): number => {
    return Math.ceil(text.length / 4);
  };

  // Calculate cost
  const calculateCost = (model: ModelConfig, inputTokens: number, outputTokens: number): number => {
    return (
      (inputTokens / 1_000_000) * model.pricing.input +
      (outputTokens / 1_000_000) * model.pricing.output
    );
  };

  // Generate AI response using backend proxy
  const generateResponse = async (modelId: string): Promise<TestResult> => {
    const model = models.find(m => m.id === modelId)!;
    const startTime = Date.now();

    try {
      const result = await aiLabService.generateCompletion({
        provider: model.provider,
        model: modelId,
        prompt: prompt,
        systemPrompt: systemMessage,
        temperature: temperature,
        maxTokens: maxTokens,
      });

      if (!result.success) {
        throw new Error(result.error || 'AI request failed');
      }

      const inputTokens = result.tokensUsed?.prompt || estimateTokens(systemMessage + prompt);
      const outputTokens = result.tokensUsed?.completion || estimateTokens(result.response || '');

      return {
        modelId,
        response: result.response || '',
        tokens: {
          input: inputTokens,
          output: outputTokens,
          total: inputTokens + outputTokens,
        },
        cost: calculateCost(model, inputTokens, outputTokens),
        latency: Date.now() - startTime,
        timestamp: Date.now(),
        status: 'complete',
      };
    } catch (error) {
      return {
        modelId,
        response: '',
        tokens: { input: 0, output: 0, total: 0 },
        cost: 0,
        latency: Date.now() - startTime,
        timestamp: Date.now(),
        status: 'error',
        error: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  };

  // Run comparison
  const runComparison = async () => {
    if (!prompt.trim()) return;

    // Track test run analytics
    trackLabTest('playground');

    setIsRunning(true);

    // Initialize results with pending status
    const initialResults: Record<string, TestResult> = {};
    selectedModels.forEach(modelId => {
      initialResults[modelId] = {
        modelId,
        response: '',
        tokens: { input: 0, output: 0, total: 0 },
        cost: 0,
        latency: 0,
        timestamp: Date.now(),
        status: 'pending',
      };
    });
    setResults(initialResults);

    // Run all models in parallel
    const promises = selectedModels.map(async modelId => {
      try {
        setResults(prev => ({
          ...prev,
          [modelId]: { ...prev[modelId], status: 'streaming' },
        }));

        const result = await generateResponse(modelId);

        setResults(prev => ({
          ...prev,
          [modelId]: result,
        }));

        return result;
      } catch (error) {
        setResults(prev => ({
          ...prev,
          [modelId]: {
            ...prev[modelId],
            status: 'error',
            error: error instanceof Error ? error.message : 'Unknown error',
          },
        }));
      }
    });

    await Promise.all(promises);
    setIsRunning(false);

    // Save to history
    saveToHistory();
  };

  // Save to history
  const saveToHistory = () => {
    try {
      const history = JSON.parse(localStorage.getItem('ailab_global_history') || '[]');
      history.push({
        type: 'playground',
        prompt,
        systemMessage,
        models: selectedModels,
        results,
        parameters: { temperature, maxTokens, topP },
        timestamp: Date.now(),
      });
      localStorage.setItem('ailab_global_history', JSON.stringify(history));
    } catch (e) {
      console.error('Failed to save to history:', e);
    }
  };

  // Copy result
  const copyResult = (text: string) => {
    navigator.clipboard.writeText(text);
    // Show toast notification (would need toast system)
  };

  // Download all results
  const downloadResults = () => {
    const data = {
      prompt,
      systemMessage,
      parameters: { temperature, maxTokens, topP },
      results: Object.entries(results).map(([modelId, result]) => ({
        model: models.find(m => m.id === modelId)?.name,
        ...result,
      })),
      timestamp: new Date().toISOString(),
    };

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `playground-results-${Date.now()}.json`;
    a.click();
  };

  // Get winner (fastest + cheapest)
  const getWinner = () => {
    const completed = Object.values(results).filter(r => r.status === 'complete');
    if (completed.length === 0) return null;

    // Best latency
    const fastest = completed.reduce((min, r) => (r.latency < min.latency ? r : min));
    // Best cost
    const cheapest = completed.reduce((min, r) => (r.cost < min.cost ? r : min));

    return { fastest, cheapest };
  };

  const winner = getWinner();

  return (
    <div className="min-h-screen bg-black text-white pb-20">
      {/* Subscription Modal */}
      {showSubscriptionModal && (
        <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-gray-900 border border-gray-800 rounded-2xl p-8 max-w-md w-full text-center">
            <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
              <Play className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-white mb-3">AI Playground Access Required</h2>
            <p className="text-gray-400 mb-6">
              The AI Playground is a premium feature. Subscribe to unlock access to multi-model
              testing and comparison capabilities.
            </p>
            <div className="space-y-3">
              <button
                onClick={() => (window.location.href = '/pricing')}
                className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white px-6 py-3 rounded-lg font-semibold hover:from-blue-500 hover:to-purple-500 transition-all"
              >
                Upgrade Now
              </button>
              <button
                onClick={() => onNavigate('ai-lab' as Page)}
                className="w-full bg-gray-800 hover:bg-gray-700 text-white px-6 py-3 rounded-lg font-semibold transition-all"
              >
                Back to AI Lab
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Full Page Barrier for Non-Subscribers */}
      {!subscriptionStatus.hasActiveSubscription && (
        <div className="fixed inset-0 z-40 bg-black/90 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-gray-900 border border-blue-500/30 rounded-2xl p-8 max-w-lg w-full text-center">
            <div className="w-20 h-20 mx-auto mb-6 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
              <Lock className="w-10 h-10 text-white" />
            </div>
            <h2 className="text-3xl font-bold text-white mb-4">Premium Feature Locked</h2>
            <p className="text-gray-400 mb-6 text-lg">
              AI Playground requires an active subscription. Test and compare multiple AI models
              side-by-side with advanced analytics.
            </p>
            <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-4 mb-6">
              <p className="text-blue-400 font-semibold">🚀 Playground Features:</p>
              <ul className="text-sm text-gray-300 mt-2 space-y-1 text-left">
                <li>• Multi-model testing & comparison</li>
                <li>• Advanced parameter controls</li>
                <li>• Performance analytics & metrics</li>
                <li>• Export test results & data</li>
              </ul>
            </div>
            <button
              onClick={() => setShowSubscriptionModal(true)}
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white px-6 py-4 rounded-xl font-bold text-lg hover:from-blue-500 hover:to-purple-500 transition-all shadow-lg"
            >
              Unlock AI Playground
            </button>
          </div>
        </div>
      )}
      {/* Header */}
      <div className="sticky top-0 z-40 bg-black/95 backdrop-blur-xl border-b border-gray-800">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={() => onNavigate('ai-lab' as Page)}
                className="p-2 hover:bg-gray-800 rounded-lg transition-colors"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
              <div>
                <h1 className="text-2xl font-bold text-white">Multi-Model Playground</h1>
                <p className="text-sm text-gray-400">Compare AI models side-by-side</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={() => setShowSettings(!showSettings)}
                className="p-2 hover:bg-gray-800 rounded-lg transition-colors"
              >
                <Settings className="w-5 h-5" />
              </button>
              <button
                onClick={() =>
                  setComparisonMode(comparisonMode === 'side-by-side' ? 'stacked' : 'side-by-side')
                }
                className="px-4 py-2 bg-gray-800 hover:bg-gray-700 rounded-lg text-sm font-medium transition-colors"
              >
                {comparisonMode === 'side-by-side' ? 'Side by Side' : 'Stacked'}
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-6 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Left Panel - Input & Controls */}
          <div className="lg:col-span-1 space-y-6">
            {/* Model Selection */}
            <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-6">
              <h3 className="text-lg font-semibold text-white mb-4">
                Select Models ({selectedModels.length}/4)
              </h3>
              <div className="space-y-3">
                {models.map(model => (
                  <button
                    key={model.id}
                    onClick={() => toggleModel(model.id)}
                    disabled={isRunning}
                    className={`w-full p-4 rounded-xl border-2 transition-all text-left ${
                      selectedModels.includes(model.id)
                        ? `bg-gradient-to-r ${model.color} border-transparent shadow-lg`
                        : 'bg-gray-800/50 border-gray-700 hover:border-gray-600'
                    } ${isRunning ? 'opacity-50 cursor-not-allowed' : ''}`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <span className="text-2xl">{model.icon}</span>
                        <div>
                          <p className="font-semibold">{model.name}</p>
                          <p className="text-xs opacity-70">{model.provider}</p>
                        </div>
                      </div>
                      {selectedModels.includes(model.id) && <Check className="w-5 h-5" />}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Parameters */}
            {showSettings && (
              <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-6">
                <h3 className="text-lg font-semibold text-white mb-4">Parameters</h3>

                <div className="space-y-4">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <label className="text-sm text-gray-400">Temperature</label>
                      <span className="text-sm text-cyan-400 font-mono">{temperature}</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="2"
                      step="0.1"
                      value={temperature}
                      onChange={e => setTemperature(parseFloat(e.target.value))}
                      disabled={isRunning}
                      className="w-full"
                    />
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <label className="text-sm text-gray-400">Max Tokens</label>
                      <span className="text-sm text-cyan-400 font-mono">{maxTokens}</span>
                    </div>
                    <input
                      type="range"
                      min="50"
                      max="4000"
                      step="50"
                      value={maxTokens}
                      onChange={e => setMaxTokens(parseInt(e.target.value))}
                      disabled={isRunning}
                      className="w-full"
                    />
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <label className="text-sm text-gray-400">Top P</label>
                      <span className="text-sm text-cyan-400 font-mono">{topP}</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="1"
                      step="0.05"
                      value={topP}
                      onChange={e => setTopP(parseFloat(e.target.value))}
                      disabled={isRunning}
                      className="w-full"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* System Message */}
            <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-6">
              <h3 className="text-lg font-semibold text-white mb-4">System Message</h3>
              <textarea
                value={systemMessage}
                onChange={e => setSystemMessage(e.target.value)}
                disabled={isRunning}
                placeholder="Define the AI's behavior and context..."
                className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-cyan-500 resize-none"
                rows={3}
              />
            </div>
          </div>

          {/* Right Panel - Prompt & Results */}
          <div className="lg:col-span-2 space-y-6">
            {/* Prompt Input */}
            <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-white">Your Prompt</h3>
                <span className="text-sm text-gray-400">~{estimateTokens(prompt)} tokens</span>
              </div>
              <textarea
                ref={promptRef}
                value={prompt}
                onChange={e => setPrompt(e.target.value)}
                disabled={isRunning}
                placeholder="Enter your prompt here... Be specific and clear for best results."
                className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-cyan-500 resize-none min-h-[120px]"
              />

              <div className="flex items-center justify-between mt-4">
                <button
                  onClick={() => {
                    setPrompt('');
                    setResults({});
                  }}
                  disabled={isRunning || !prompt}
                  className="px-4 py-2 text-sm text-gray-400 hover:text-white hover:bg-gray-800 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <Trash2 className="w-4 h-4 inline mr-2" />
                  Clear
                </button>

                <button
                  onClick={runComparison}
                  disabled={isRunning || !prompt.trim()}
                  className="px-8 py-3 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 disabled:from-gray-700 disabled:to-gray-700 text-white font-semibold rounded-xl shadow-lg transition-all disabled:cursor-not-allowed flex items-center gap-2"
                >
                  {isRunning ? (
                    <>
                      <RefreshCw className="w-5 h-5 animate-spin" />
                      Running...
                    </>
                  ) : (
                    <>
                      <Play className="w-5 h-5" />
                      Run Comparison
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Winner Banner */}
            {winner && (
              <div className="bg-gradient-to-r from-yellow-500/20 to-orange-500/20 border border-yellow-500/30 rounded-xl p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Sparkles className="w-5 h-5 text-yellow-400" />
                    <div>
                      <p className="text-sm font-semibold text-yellow-400">Performance Winners</p>
                      <p className="text-xs text-gray-400">
                        Fastest: {models.find(m => m.id === winner.fastest.modelId)?.name} (
                        {winner.fastest.latency}ms) • Cheapest:{' '}
                        {models.find(m => m.id === winner.cheapest.modelId)?.name} ($
                        {winner.cheapest.cost.toFixed(6)})
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={downloadResults}
                    className="p-2 hover:bg-gray-800 rounded-lg transition-colors"
                  >
                    <Download className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

            {/* Results Grid */}
            <div
              className={`grid gap-6 ${
                comparisonMode === 'side-by-side'
                  ? selectedModels.length === 1
                    ? 'grid-cols-1'
                    : 'grid-cols-2'
                  : 'grid-cols-1'
              }`}
            >
              {selectedModels.map(modelId => {
                const model = models.find(m => m.id === modelId)!;
                const result = results[modelId];

                return (
                  <div
                    key={modelId}
                    className="bg-gray-900/50 border border-gray-800 rounded-xl p-6"
                  >
                    {/* Model Header */}
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-10 h-10 rounded-lg bg-gradient-to-r ${model.color} flex items-center justify-center text-xl`}
                        >
                          {model.icon}
                        </div>
                        <div>
                          <p className="font-semibold text-white">{model.name}</p>
                          <p className="text-xs text-gray-400">{model.provider}</p>
                        </div>
                      </div>

                      {result?.status === 'complete' && (
                        <button
                          onClick={() => copyResult(result.response)}
                          className="p-2 hover:bg-gray-800 rounded-lg transition-colors"
                        >
                          <Copy className="w-4 h-4" />
                        </button>
                      )}
                    </div>

                    {/* Status / Response */}
                    {!result && (
                      <div className="text-center py-12 text-gray-500">
                        <MessageSquare className="w-12 h-12 mx-auto mb-3 opacity-30" />
                        <p className="text-sm">Waiting to run...</p>
                      </div>
                    )}

                    {result?.status === 'pending' && (
                      <div className="text-center py-12 text-gray-400">
                        <Clock className="w-12 h-12 mx-auto mb-3 animate-pulse" />
                        <p className="text-sm">Queued...</p>
                      </div>
                    )}

                    {result?.status === 'streaming' && (
                      <div className="text-center py-12 text-cyan-400">
                        <RefreshCw className="w-12 h-12 mx-auto mb-3 animate-spin" />
                        <p className="text-sm">Generating response...</p>
                      </div>
                    )}

                    {result?.status === 'error' && (
                      <div className="text-center py-12 text-red-400">
                        <AlertCircle className="w-12 h-12 mx-auto mb-3" />
                        <p className="text-sm font-semibold">Error</p>
                        <p className="text-xs text-gray-400 mt-2">{result.error}</p>
                      </div>
                    )}

                    {result?.status === 'complete' && (
                      <>
                        <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-4 mb-4 max-h-[400px] overflow-y-auto">
                          <p className="text-sm text-gray-300 whitespace-pre-wrap leading-relaxed">
                            {result.response}
                          </p>
                        </div>

                        {/* Metrics */}
                        <div className="grid grid-cols-4 gap-3">
                          <div className="text-center p-3 bg-gray-800/50 rounded-lg">
                            <Hash className="w-4 h-4 mx-auto mb-1 text-gray-400" />
                            <p className="text-xs text-gray-400">Tokens</p>
                            <p className="text-sm font-semibold text-white">
                              {result.tokens.total}
                            </p>
                          </div>
                          <div className="text-center p-3 bg-gray-800/50 rounded-lg">
                            <Clock className="w-4 h-4 mx-auto mb-1 text-gray-400" />
                            <p className="text-xs text-gray-400">Latency</p>
                            <p className="text-sm font-semibold text-white">{result.latency}ms</p>
                          </div>
                          <div className="text-center p-3 bg-gray-800/50 rounded-lg">
                            <DollarSign className="w-4 h-4 mx-auto mb-1 text-gray-400" />
                            <p className="text-xs text-gray-400">Cost</p>
                            <p className="text-sm font-semibold text-white">
                              ${result.cost.toFixed(6)}
                            </p>
                          </div>
                          <div className="text-center p-3 bg-gray-800/50 rounded-lg">
                            <Zap className="w-4 h-4 mx-auto mb-1 text-gray-400" />
                            <p className="text-xs text-gray-400">Speed</p>
                            <p className="text-sm font-semibold text-white">
                              {Math.round(result.tokens.output / (result.latency / 1000))} t/s
                            </p>
                          </div>
                        </div>
                      </>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AILabPlaygroundPage;
