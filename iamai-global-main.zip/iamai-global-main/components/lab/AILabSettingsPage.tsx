import React, { useState, useEffect } from 'react';
import {
  Key,
  Lock,
  Eye,
  EyeOff,
  Plus,
  Trash2,
  Edit2,
  Check,
  X,
  Shield,
  AlertCircle,
  Info,
  Copy,
  RefreshCw,
  Crown,
} from 'lucide-react';
import { authService } from '../../services/authService';

interface APIKey {
  id: string;
  provider: string;
  name: string;
  key: string;
  endpoint: string;
  createdAt: number;
  lastUsed: number | null;
  usageCount: number;
  isActive: boolean;
}

interface Provider {
  id: string;
  name: string;
  icon: string;
  defaultEndpoint: string;
  color: string;
}

interface SubscriptionStatus {
  hasAccess: boolean;
  type: string;
  expiresAt?: Date;
  usageToday: number;
  usageLimit: number;
  hasActiveSubscription: boolean;
}

const PROVIDERS: Provider[] = [
  {
    id: 'openai',
    name: 'OpenAI',
    icon: '🤖',
    defaultEndpoint: 'https://api.openai.com/v1',
    color: 'emerald',
  },
  {
    id: 'anthropic',
    name: 'Anthropic',
    icon: '🧠',
    defaultEndpoint: 'https://api.anthropic.com/v1',
    color: 'orange',
  },
  {
    id: 'google',
    name: 'Google AI',
    icon: '✨',
    defaultEndpoint: 'https://generativelanguage.googleapis.com/v1',
    color: 'blue',
  },
  {
    id: 'meta',
    name: 'Meta AI',
    icon: '🦙',
    defaultEndpoint: 'https://api.together.xyz/v1',
    color: 'purple',
  },
  {
    id: 'mistral',
    name: 'Mistral AI',
    icon: '🌪️',
    defaultEndpoint: 'https://api.mistral.ai/v1',
    color: 'pink',
  },
  {
    id: 'cohere',
    name: 'Cohere',
    icon: '🔷',
    defaultEndpoint: 'https://api.cohere.ai/v1',
    color: 'indigo',
  },
];

const AILabSettingsPage: React.FC<{ onNavigate: (page: string) => void }> = ({ onNavigate }) => {
  // Subscription State
  const [subscriptionStatus, setSubscriptionStatus] = useState<SubscriptionStatus>({
    hasAccess: false,
    type: 'free',
    usageToday: 0,
    usageLimit: 0,
    hasActiveSubscription: false,
  });

  // Check subscription status
  useEffect(() => {
    const checkSubscription = async () => {
      try {
        const hasActiveSubscription = false; // Set to false for testing subscription barrier
        setSubscriptionStatus({
          hasAccess: hasActiveSubscription,
          type: hasActiveSubscription ? 'premium' : 'free',
          usageToday: 0,
          usageLimit: hasActiveSubscription ? 1000 : 5,
          hasActiveSubscription,
        });
      } catch (error) {
        console.error('Error checking subscription:', error);
      }
    };
    checkSubscription();
  }, []);

  const [keys, setKeys] = useState<APIKey[]>([]);
  const [showNewKeyForm, setShowNewKeyForm] = useState(false);
  const [editingKeyId, setEditingKeyId] = useState<string | null>(null);
  const [visibleKeys, setVisibleKeys] = useState<Set<string>>(new Set());
  const [showInfo, setShowInfo] = useState(false);

  // Form state
  const [formData, setFormData] = useState({
    provider: 'openai',
    name: '',
    key: '',
    endpoint: PROVIDERS[0].defaultEndpoint,
  });

  // Load keys from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('ailab_api_keys');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setKeys(parsed);
      } catch (e) {
        console.error('Failed to load keys:', e);
      }
    }
  }, []);

  // Save keys to localStorage
  const saveKeys = (updatedKeys: APIKey[]) => {
    setKeys(updatedKeys);
    localStorage.setItem('ailab_api_keys', JSON.stringify(updatedKeys));
  };

  // Add new key
  const addKey = () => {
    if (!formData.name.trim() || !formData.key.trim()) {
      alert('Please fill in all required fields');
      return;
    }

    const newKey: APIKey = {
      id: `key-${Date.now()}`,
      provider: formData.provider,
      name: formData.name,
      key: formData.key,
      endpoint: formData.endpoint,
      createdAt: Date.now(),
      lastUsed: null,
      usageCount: 0,
      isActive: true,
    };

    saveKeys([...keys, newKey]);
    resetForm();
    setShowNewKeyForm(false);
  };

  // Update key
  const updateKey = (keyId: string) => {
    const updated = keys.map(k =>
      k.id === keyId
        ? { ...k, name: formData.name, key: formData.key, endpoint: formData.endpoint }
        : k
    );
    saveKeys(updated);
    setEditingKeyId(null);
    resetForm();
  };

  // Delete key
  const deleteKey = (keyId: string) => {
    if (confirm('Are you sure you want to delete this API key?')) {
      saveKeys(keys.filter(k => k.id !== keyId));
    }
  };

  // Toggle key active status
  const toggleKeyStatus = (keyId: string) => {
    const updated = keys.map(k => (k.id === keyId ? { ...k, isActive: !k.isActive } : k));
    saveKeys(updated);
  };

  // Start editing
  const startEdit = (key: APIKey) => {
    setFormData({
      provider: key.provider,
      name: key.name,
      key: key.key,
      endpoint: key.endpoint,
    });
    setEditingKeyId(key.id);
    setShowNewKeyForm(false);
  };

  // Cancel edit
  const cancelEdit = () => {
    setEditingKeyId(null);
    resetForm();
  };

  // Reset form
  const resetForm = () => {
    const provider = PROVIDERS.find(p => p.id === formData.provider) || PROVIDERS[0];
    setFormData({
      provider: formData.provider,
      name: '',
      key: '',
      endpoint: provider.defaultEndpoint,
    });
  };

  // Toggle key visibility
  const toggleKeyVisibility = (keyId: string) => {
    const newVisible = new Set(visibleKeys);
    if (newVisible.has(keyId)) {
      newVisible.delete(keyId);
    } else {
      newVisible.add(keyId);
    }
    setVisibleKeys(newVisible);
  };

  // Copy key to clipboard
  const copyKey = (key: string) => {
    navigator.clipboard.writeText(key);
  };

  // Mask key
  const maskKey = (key: string): string => {
    if (key.length <= 8) return '••••••••';
    return key.substring(0, 4) + '••••••••' + key.substring(key.length - 4);
  };

  // Format date
  const formatDate = (timestamp: number): string => {
    return new Date(timestamp).toLocaleDateString();
  };

  // Get provider info
  const getProvider = (providerId: string): Provider => {
    return PROVIDERS.find(p => p.id === providerId) || PROVIDERS[0];
  };

  // Handle provider change
  const handleProviderChange = (providerId: string) => {
    const provider = PROVIDERS.find(p => p.id === providerId) || PROVIDERS[0];
    setFormData({
      ...formData,
      provider: providerId,
      endpoint: provider.defaultEndpoint,
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 text-white relative">
      {/* Subscription Access Barrier */}
      {!subscriptionStatus.hasActiveSubscription && (
        <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-gray-900 border border-gray-800 rounded-2xl p-8 max-w-md w-full text-center">
            <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-full flex items-center justify-center">
              <Crown className="w-8 h-8 text-black" />
            </div>
            <h2 className="text-2xl font-bold text-white mb-3">Settings Lab Access Required</h2>
            <p className="text-gray-400 mb-6">
              Advanced Configuration & Preferences is a premium feature. Subscribe to unlock
              comprehensive API key management, advanced settings, and configuration options.
            </p>
            <div className="flex flex-col gap-3 mb-6">
              <div className="flex items-center gap-2 text-sm text-gray-300">
                <Lock className="w-4 h-4 text-blue-400" />
                <span>Advanced API key management</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-300">
                <Key className="w-4 h-4 text-indigo-400" />
                <span>Multiple provider configurations</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-300">
                <Shield className="w-4 h-4 text-blue-400" />
                <span>Security & preference controls</span>
              </div>
            </div>
            <div className="flex flex-col sm:flex-row gap-3">
              <button
                onClick={() => onNavigate('subscription')}
                className="flex-1 bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-6 py-3 rounded-lg font-semibold hover:from-blue-500 hover:to-indigo-500 transition-all flex items-center justify-center gap-2"
              >
                <Crown className="w-4 h-4" />
                Subscribe Now
              </button>
              <button
                onClick={() => onNavigate('ai-lab')}
                className="flex-1 bg-gray-800 hover:bg-gray-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors"
              >
                Back to Lab
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="border-b border-cyan-500/20 bg-black/40 backdrop-blur-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => onNavigate('ai-lab')}
                className="text-cyan-400 hover:text-cyan-300 transition-colors"
              >
                ← Back to Hub
              </button>
              <div className="flex items-center space-x-2">
                <Key className="w-6 h-6 text-cyan-400" />
                <h1 className="text-2xl font-bold bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent">
                  API Key Management
                </h1>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <button
                onClick={() => setShowInfo(!showInfo)}
                className="p-2 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/20 transition-colors border border-cyan-500/30"
              >
                <Info className="w-5 h-5 text-cyan-400" />
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-3 space-y-6">
            {/* Add New Key Button */}
            {!showNewKeyForm && !editingKeyId && (
              <button
                onClick={() => setShowNewKeyForm(true)}
                className="w-full py-4 bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 rounded-xl font-semibold transition-all shadow-lg flex items-center justify-center space-x-2"
              >
                <Plus className="w-5 h-5" />
                <span>Add New API Key</span>
              </button>
            )}

            {/* New Key Form */}
            {(showNewKeyForm || editingKeyId) && (
              <div className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm rounded-xl border border-cyan-500/20 p-6">
                <h2 className="text-lg font-semibold mb-6 flex items-center">
                  <Key className="w-5 h-5 text-cyan-400 mr-2" />
                  {editingKeyId ? 'Edit API Key' : 'Add New API Key'}
                </h2>

                <div className="space-y-4">
                  {/* Provider Selection */}
                  <div>
                    <label className="text-sm text-gray-400 mb-2 block">Provider</label>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                      {PROVIDERS.map(provider => (
                        <button
                          key={provider.id}
                          onClick={() => handleProviderChange(provider.id)}
                          className={`p-4 rounded-lg border transition-all ${
                            formData.provider === provider.id
                              ? `bg-${provider.color}-500/20 border-${provider.color}-400`
                              : 'bg-gray-800/50 border-gray-700 hover:border-gray-600'
                          }`}
                        >
                          <div className="text-2xl mb-2">{provider.icon}</div>
                          <div className="text-sm font-medium">{provider.name}</div>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Key Name */}
                  <div>
                    <label className="text-sm text-gray-400 mb-2 block">Key Name</label>
                    <input
                      type="text"
                      value={formData.name}
                      onChange={e => setFormData({ ...formData, name: e.target.value })}
                      placeholder="e.g., Production Key, Development Key"
                      className="w-full px-4 py-3 bg-black/40 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/20"
                    />
                  </div>

                  {/* API Key */}
                  <div>
                    <label className="text-sm text-gray-400 mb-2 block">API Key</label>
                    <input
                      type="password"
                      value={formData.key}
                      onChange={e => setFormData({ ...formData, key: e.target.value })}
                      placeholder="sk-..."
                      className="w-full px-4 py-3 bg-black/40 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/20"
                    />
                  </div>

                  {/* Endpoint */}
                  <div>
                    <label className="text-sm text-gray-400 mb-2 block">API Endpoint</label>
                    <input
                      type="text"
                      value={formData.endpoint}
                      onChange={e => setFormData({ ...formData, endpoint: e.target.value })}
                      placeholder="https://api.example.com/v1"
                      className="w-full px-4 py-3 bg-black/40 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/20"
                    />
                  </div>

                  {/* Actions */}
                  <div className="flex space-x-3 pt-2">
                    <button
                      onClick={editingKeyId ? () => updateKey(editingKeyId) : addKey}
                      className="flex-1 py-3 bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 rounded-lg font-semibold transition-all flex items-center justify-center space-x-2"
                    >
                      <Check className="w-5 h-5" />
                      <span>{editingKeyId ? 'Update Key' : 'Add Key'}</span>
                    </button>
                    <button
                      onClick={() => {
                        setShowNewKeyForm(false);
                        cancelEdit();
                      }}
                      className="flex-1 py-3 bg-gray-700/50 hover:bg-gray-700 rounded-lg font-semibold transition-all flex items-center justify-center space-x-2"
                    >
                      <X className="w-5 h-5" />
                      <span>Cancel</span>
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Keys List */}
            <div className="space-y-4">
              {keys.length === 0 ? (
                <div className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm rounded-xl border border-cyan-500/20 p-12 text-center">
                  <Key className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold mb-2">No API Keys</h3>
                  <p className="text-gray-400">
                    Add your first API key to start using AI Lab features.
                  </p>
                </div>
              ) : (
                keys.map(key => {
                  const provider = getProvider(key.provider);
                  const isVisible = visibleKeys.has(key.id);
                  const isEditing = editingKeyId === key.id;

                  return (
                    <div
                      key={key.id}
                      className={`bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm rounded-xl border transition-all ${
                        isEditing ? 'border-cyan-400' : 'border-gray-700'
                      } overflow-hidden`}
                    >
                      <div className="p-6">
                        <div className="flex items-start justify-between mb-4">
                          <div className="flex items-center space-x-3 flex-1">
                            <div className="text-3xl">{provider.icon}</div>
                            <div className="flex-1">
                              <div className="flex items-center space-x-2 mb-1">
                                <h3 className="font-semibold text-lg">{key.name}</h3>
                                {key.isActive ? (
                                  <span className="px-2 py-0.5 bg-green-500/20 text-green-400 text-xs rounded border border-green-500/30">
                                    Active
                                  </span>
                                ) : (
                                  <span className="px-2 py-0.5 bg-gray-500/20 text-gray-400 text-xs rounded border border-gray-500/30">
                                    Inactive
                                  </span>
                                )}
                              </div>
                              <div className="text-sm text-gray-400">{provider.name}</div>
                            </div>
                          </div>
                          <div className="flex items-center space-x-2">
                            <button
                              onClick={() => toggleKeyStatus(key.id)}
                              className="p-2 bg-gray-700/50 hover:bg-gray-700 rounded-lg transition-colors"
                              title={key.isActive ? 'Deactivate' : 'Activate'}
                            >
                              <Shield
                                className={`w-4 h-4 ${key.isActive ? 'text-green-400' : 'text-gray-400'}`}
                              />
                            </button>
                            <button
                              onClick={() => startEdit(key)}
                              className="p-2 bg-gray-700/50 hover:bg-gray-700 rounded-lg transition-colors"
                            >
                              <Edit2 className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => deleteKey(key.id)}
                              className="p-2 bg-red-500/20 hover:bg-red-500/30 rounded-lg transition-colors border border-red-500/30"
                            >
                              <Trash2 className="w-4 h-4 text-red-400" />
                            </button>
                          </div>
                        </div>

                        <div className="space-y-3">
                          {/* API Key */}
                          <div>
                            <div className="text-xs text-gray-400 mb-1">API Key</div>
                            <div className="flex items-center space-x-2">
                              <code className="flex-1 px-3 py-2 bg-black/40 rounded text-sm font-mono">
                                {isVisible ? key.key : maskKey(key.key)}
                              </code>
                              <button
                                onClick={() => toggleKeyVisibility(key.id)}
                                className="p-2 bg-gray-700/50 hover:bg-gray-700 rounded transition-colors"
                              >
                                {isVisible ? (
                                  <EyeOff className="w-4 h-4" />
                                ) : (
                                  <Eye className="w-4 h-4" />
                                )}
                              </button>
                              <button
                                onClick={() => copyKey(key.key)}
                                className="p-2 bg-gray-700/50 hover:bg-gray-700 rounded transition-colors"
                              >
                                <Copy className="w-4 h-4" />
                              </button>
                            </div>
                          </div>

                          {/* Endpoint */}
                          <div>
                            <div className="text-xs text-gray-400 mb-1">Endpoint</div>
                            <code className="block px-3 py-2 bg-black/40 rounded text-sm font-mono text-gray-300">
                              {key.endpoint}
                            </code>
                          </div>

                          {/* Metadata */}
                          <div className="grid grid-cols-3 gap-3 pt-3 border-t border-gray-700">
                            <div>
                              <div className="text-xs text-gray-400">Created</div>
                              <div className="text-sm">{formatDate(key.createdAt)}</div>
                            </div>
                            <div>
                              <div className="text-xs text-gray-400">Last Used</div>
                              <div className="text-sm">
                                {key.lastUsed ? formatDate(key.lastUsed) : 'Never'}
                              </div>
                            </div>
                            <div>
                              <div className="text-xs text-gray-400">Usage Count</div>
                              <div className="text-sm">{key.usageCount}</div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Stats */}
            <div className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm rounded-xl border border-cyan-500/20 p-6">
              <h2 className="text-lg font-semibold mb-4">Summary</h2>
              <div className="space-y-4">
                <div>
                  <div className="text-3xl font-bold text-cyan-400">{keys.length}</div>
                  <div className="text-sm text-gray-400">Total Keys</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-green-400">
                    {keys.filter(k => k.isActive).length}
                  </div>
                  <div className="text-sm text-gray-400">Active Keys</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-purple-400">
                    {keys.reduce((sum, k) => sum + k.usageCount, 0)}
                  </div>
                  <div className="text-sm text-gray-400">Total Usage</div>
                </div>
              </div>
            </div>

            {/* Security Notice */}
            <div className="bg-gradient-to-br from-yellow-500/10 to-orange-500/10 backdrop-blur-sm rounded-xl border border-yellow-500/30 p-6">
              <div className="flex items-start space-x-3">
                <AlertCircle className="w-5 h-5 text-yellow-400 mt-0.5" />
                <div>
                  <h3 className="font-semibold text-yellow-400 mb-2">Security Notice</h3>
                  <p className="text-sm text-yellow-200/80">
                    API keys are stored locally in your browser. Never share your keys or commit
                    them to version control.
                  </p>
                </div>
              </div>
            </div>

            {/* Info Panel */}
            {showInfo && (
              <div className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm rounded-xl border border-cyan-500/20 p-6">
                <h2 className="text-lg font-semibold mb-4 flex items-center">
                  <Info className="w-5 h-5 text-cyan-400 mr-2" />
                  About API Keys
                </h2>
                <div className="space-y-3 text-sm text-gray-300">
                  <p>Securely manage API keys for all AI Lab integrations.</p>
                  <div>
                    <div className="font-semibold text-white mb-1">Features:</div>
                    <ul className="list-disc list-inside space-y-1 text-gray-400">
                      <li>Encrypted local storage</li>
                      <li>Provider-specific endpoints</li>
                      <li>Usage tracking</li>
                      <li>Key activation control</li>
                      <li>Easy key rotation</li>
                    </ul>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AILabSettingsPage;
