import React, { useState, useEffect } from 'react';
import {
  Brain,
  Zap,
  Activity,
  BarChart3,
  PieChart,
  TrendingUp,
  AlertTriangle,
  Download,
  Info,
  RefreshCw,
  Lock,
  Crown,
} from 'lucide-react';
import { authService } from '../../services/authService';

interface EntropyResult {
  text: string;
  entropy: number;
  avgBitsPerChar: number;
  redundancy: number;
  estimatedCompression: number;
}

interface BiasResult {
  text: string;
  biasScore: number;
  detectedBiases: {
    type: string;
    confidence: number;
    examples: string[];
  }[];
  sentiment: 'positive' | 'negative' | 'neutral';
}

interface CompressionResult {
  original: string;
  originalSize: number;
  compressedSize: number;
  ratio: number;
  algorithm: string;
  savings: number;
}

interface SubscriptionStatus {
  hasAccess: boolean;
  type: string;
  expiresAt?: Date;
  usageToday: number;
  usageLimit: number;
  hasActiveSubscription: boolean;
}

const AILabResearchPage: React.FC<{ onNavigate: (page: string) => void }> = ({ onNavigate }) => {
  // Subscription State
  const [subscriptionStatus, setSubscriptionStatus] = useState<SubscriptionStatus>({
    hasAccess: false,
    type: 'free',
    usageToday: 0,
    usageLimit: 0,
    hasActiveSubscription: false,
  });

  // Check subscription status
  useEffect(() => {
    const checkSubscription = async () => {
      try {
        const hasActiveSubscription = false; // Set to false for testing subscription barrier
        setSubscriptionStatus({
          hasAccess: hasActiveSubscription,
          type: hasActiveSubscription ? 'premium' : 'free',
          usageToday: 0,
          usageLimit: hasActiveSubscription ? 1000 : 5,
          hasActiveSubscription,
        });
      } catch (error) {
        console.error('Error checking subscription:', error);
      }
    };
    checkSubscription();
  }, []);

  const [activeTab, setActiveTab] = useState<'entropy' | 'bias' | 'compression'>('entropy');
  const [showInfo, setShowInfo] = useState(false);

  // Entropy Calculator State
  const [entropyText, setEntropyText] = useState('');
  const [entropyResult, setEntropyResult] = useState<EntropyResult | null>(null);

  // Bias Detector State
  const [biasText, setBiasText] = useState('');
  const [biasResult, setBiasResult] = useState<BiasResult | null>(null);

  // Compression Simulator State
  const [compressionText, setCompressionText] = useState('');
  const [compressionAlgorithm, setCompressionAlgorithm] = useState<
    'huffman' | 'lz77' | 'shannon-fano'
  >('huffman');
  const [compressionResult, setCompressionResult] = useState<CompressionResult | null>(null);

  // Calculate Shannon Entropy
  const calculateEntropy = () => {
    if (!entropyText.trim()) return;

    const text = entropyText;
    const freq: { [key: string]: number } = {};

    // Count character frequencies
    for (const char of text) {
      freq[char] = (freq[char] || 0) + 1;
    }

    // Calculate entropy
    let entropy = 0;
    const len = text.length;

    for (const char in freq) {
      const p = freq[char] / len;
      entropy -= p * Math.log2(p);
    }

    const maxEntropy = Math.log2(Object.keys(freq).length);
    const redundancy = maxEntropy > 0 ? (1 - entropy / maxEntropy) * 100 : 0;
    const avgBitsPerChar = entropy;
    const estimatedCompression = redundancy;

    setEntropyResult({
      text: text.substring(0, 100),
      entropy,
      avgBitsPerChar,
      redundancy,
      estimatedCompression,
    });
  };

  // Detect Bias
  const detectBias = () => {
    if (!biasText.trim()) return;

    const text = biasText.toLowerCase();
    const biases: { type: string; confidence: number; examples: string[] }[] = [];

    // Gender bias detection
    const genderWords = {
      male: ['he', 'him', 'his', 'man', 'men', 'male', 'boy', 'guys'],
      female: ['she', 'her', 'hers', 'woman', 'women', 'female', 'girl', 'gals'],
    };

    let maleCount = 0;
    let femaleCount = 0;
    const genderExamples: string[] = [];

    for (const word of genderWords.male) {
      const matches = text.match(new RegExp(`\\b${word}\\b`, 'gi'));
      if (matches) {
        maleCount += matches.length;
        if (genderExamples.length < 3) genderExamples.push(matches[0]);
      }
    }

    for (const word of genderWords.female) {
      const matches = text.match(new RegExp(`\\b${word}\\b`, 'gi'));
      if (matches) {
        femaleCount += matches.length;
        if (genderExamples.length < 3) genderExamples.push(matches[0]);
      }
    }

    const totalGender = maleCount + femaleCount;
    if (totalGender > 0) {
      const maleRatio = maleCount / totalGender;
      const femaleRatio = femaleCount / totalGender;
      const imbalance = Math.abs(maleRatio - femaleRatio);

      if (imbalance > 0.3) {
        biases.push({
          type: 'Gender Bias',
          confidence: imbalance * 100,
          examples: genderExamples,
        });
      }
    }

    // Sentiment bias
    const positiveWords = [
      'good',
      'great',
      'excellent',
      'amazing',
      'wonderful',
      'fantastic',
      'love',
      'best',
    ];
    const negativeWords = [
      'bad',
      'terrible',
      'awful',
      'horrible',
      'worst',
      'hate',
      'poor',
      'disappointing',
    ];

    let positiveCount = 0;
    let negativeCount = 0;
    const sentimentExamples: string[] = [];

    for (const word of positiveWords) {
      const matches = text.match(new RegExp(`\\b${word}\\b`, 'gi'));
      if (matches) {
        positiveCount += matches.length;
        if (sentimentExamples.length < 3) sentimentExamples.push(matches[0]);
      }
    }

    for (const word of negativeWords) {
      const matches = text.match(new RegExp(`\\b${word}\\b`, 'gi'));
      if (matches) {
        negativeCount += matches.length;
        if (sentimentExamples.length < 3) sentimentExamples.push(matches[0]);
      }
    }

    const totalSentiment = positiveCount + negativeCount;
    let sentiment: 'positive' | 'negative' | 'neutral' = 'neutral';

    if (totalSentiment > 0) {
      const positiveRatio = positiveCount / totalSentiment;
      const negativeRatio = negativeCount / totalSentiment;
      const sentimentImbalance = Math.abs(positiveRatio - negativeRatio);

      if (sentimentImbalance > 0.3) {
        biases.push({
          type: 'Sentiment Bias',
          confidence: sentimentImbalance * 100,
          examples: sentimentExamples,
        });
      }

      sentiment = positiveCount > negativeCount ? 'positive' : 'negative';
    }

    // Authority bias detection
    const authorityWords = [
      'must',
      'should',
      'always',
      'never',
      'certainly',
      'definitely',
      'obviously',
      'clearly',
    ];
    let authorityCount = 0;
    const authorityExamples: string[] = [];

    for (const word of authorityWords) {
      const matches = text.match(new RegExp(`\\b${word}\\b`, 'gi'));
      if (matches) {
        authorityCount += matches.length;
        if (authorityExamples.length < 3) authorityExamples.push(matches[0]);
      }
    }

    const words = text.split(/\s+/).length;
    const authorityDensity = authorityCount / words;

    if (authorityDensity > 0.02) {
      biases.push({
        type: 'Authority Bias',
        confidence: Math.min(authorityDensity * 100 * 50, 100),
        examples: authorityExamples,
      });
    }

    const biasScore =
      biases.length > 0 ? biases.reduce((sum, b) => sum + b.confidence, 0) / biases.length : 0;

    setBiasResult({
      text: biasText.substring(0, 100),
      biasScore,
      detectedBiases: biases,
      sentiment,
    });
  };

  // Simulate Compression
  const simulateCompression = () => {
    if (!compressionText.trim()) return;

    const text = compressionText;
    const originalSize = new Blob([text]).size;

    let compressedSize: number;
    let algorithmName: string;

    // Simulate different compression algorithms
    switch (compressionAlgorithm) {
      case 'huffman':
        // Huffman typically achieves 30-60% compression for text
        compressedSize = originalSize * (0.4 + Math.random() * 0.2);
        algorithmName = 'Huffman Coding';
        break;
      case 'lz77':
        // LZ77 achieves 40-70% compression
        compressedSize = originalSize * (0.3 + Math.random() * 0.4);
        algorithmName = 'LZ77 (Lempel-Ziv)';
        break;
      case 'shannon-fano':
        // Shannon-Fano similar to Huffman
        compressedSize = originalSize * (0.45 + Math.random() * 0.15);
        algorithmName = 'Shannon-Fano Coding';
        break;
      default:
        compressedSize = originalSize * 0.5;
        algorithmName = 'Unknown';
    }

    const ratio = (originalSize / compressedSize).toFixed(2);
    const savings = ((1 - compressedSize / originalSize) * 100).toFixed(1);

    setCompressionResult({
      original: text.substring(0, 100),
      originalSize,
      compressedSize: Math.round(compressedSize),
      ratio: parseFloat(ratio),
      algorithm: algorithmName,
      savings: parseFloat(savings),
    });
  };

  // Export result
  const exportResult = () => {
    let data: any;
    let filename: string;

    switch (activeTab) {
      case 'entropy':
        data = entropyResult;
        filename = `entropy-analysis-${Date.now()}.json`;
        break;
      case 'bias':
        data = biasResult;
        filename = `bias-detection-${Date.now()}.json`;
        break;
      case 'compression':
        data = compressionResult;
        filename = `compression-analysis-${Date.now()}.json`;
        break;
    }

    if (!data) return;

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
  };

  // Sample texts
  const sampleTexts = {
    entropy:
      'The quick brown fox jumps over the lazy dog. Information theory studies the quantification, storage, and communication of information.',
    bias: 'All men should pursue engineering careers because they are naturally better at math. Women are more suited for nursing and teaching roles.',
    compression:
      'aaaaabbbbbbccccccddddddeeeeee This text has lots of repetition repetition repetition!',
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 text-white relative">
      {/* Subscription Access Barrier */}
      {!subscriptionStatus.hasActiveSubscription && (
        <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-gray-900 border border-gray-800 rounded-2xl p-8 max-w-md w-full text-center">
            <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-purple-500 to-violet-600 rounded-full flex items-center justify-center">
              <Crown className="w-8 h-8 text-black" />
            </div>
            <h2 className="text-2xl font-bold text-white mb-3">Research Lab Access Required</h2>
            <p className="text-gray-400 mb-6">
              AI Research Tools & Experimentation is a premium feature. Subscribe to unlock advanced
              research capabilities including entropy analysis, bias detection, and experimental
              tools.
            </p>
            <div className="flex flex-col gap-3 mb-6">
              <div className="flex items-center gap-2 text-sm text-gray-300">
                <Lock className="w-4 h-4 text-purple-400" />
                <span>Advanced entropy analysis tools</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-300">
                <Brain className="w-4 h-4 text-violet-400" />
                <span>AI bias detection algorithms</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-300">
                <Zap className="w-4 h-4 text-purple-400" />
                <span>Experimental research suite</span>
              </div>
            </div>
            <div className="flex flex-col sm:flex-row gap-3">
              <button
                onClick={() => onNavigate('subscription')}
                className="flex-1 bg-gradient-to-r from-purple-600 to-violet-600 text-white px-6 py-3 rounded-lg font-semibold hover:from-purple-500 hover:to-violet-500 transition-all flex items-center justify-center gap-2"
              >
                <Crown className="w-4 h-4" />
                Subscribe Now
              </button>
              <button
                onClick={() => onNavigate('ai-lab')}
                className="flex-1 bg-gray-800 hover:bg-gray-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors"
              >
                Back to Lab
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="border-b border-purple-500/20 bg-black/40 backdrop-blur-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => onNavigate('ai-lab')}
                className="text-purple-400 hover:text-purple-300 transition-colors"
              >
                ← Back to Hub
              </button>
              <div className="flex items-center space-x-2">
                <Brain className="w-6 h-6 text-purple-400" />
                <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                  Shannon Research Lab
                </h1>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <button
                onClick={() => setShowInfo(!showInfo)}
                className="p-2 rounded-lg bg-purple-500/10 hover:bg-purple-500/20 transition-colors border border-purple-500/30"
              >
                <Info className="w-5 h-5 text-purple-400" />
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-3 space-y-6">
            {/* Tabs */}
            <div className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm rounded-xl border border-purple-500/20 p-2">
              <div className="grid grid-cols-3 gap-2">
                <button
                  onClick={() => setActiveTab('entropy')}
                  className={`py-3 px-4 rounded-lg font-medium transition-all ${
                    activeTab === 'entropy'
                      ? 'bg-purple-500/20 border border-purple-400 shadow-lg'
                      : 'bg-gray-800/50 border border-gray-700 hover:border-purple-500/50'
                  }`}
                >
                  <div className="flex items-center justify-center space-x-2">
                    <Activity className="w-5 h-5" />
                    <span>Entropy</span>
                  </div>
                </button>
                <button
                  onClick={() => setActiveTab('bias')}
                  className={`py-3 px-4 rounded-lg font-medium transition-all ${
                    activeTab === 'bias'
                      ? 'bg-pink-500/20 border border-pink-400 shadow-lg'
                      : 'bg-gray-800/50 border border-gray-700 hover:border-pink-500/50'
                  }`}
                >
                  <div className="flex items-center justify-center space-x-2">
                    <AlertTriangle className="w-5 h-5" />
                    <span>Bias Detection</span>
                  </div>
                </button>
                <button
                  onClick={() => setActiveTab('compression')}
                  className={`py-3 px-4 rounded-lg font-medium transition-all ${
                    activeTab === 'compression'
                      ? 'bg-blue-500/20 border border-blue-400 shadow-lg'
                      : 'bg-gray-800/50 border border-gray-700 hover:border-blue-500/50'
                  }`}
                >
                  <div className="flex items-center justify-center space-x-2">
                    <BarChart3 className="w-5 h-5" />
                    <span>Compression</span>
                  </div>
                </button>
              </div>
            </div>

            {/* Entropy Calculator */}
            {activeTab === 'entropy' && (
              <>
                <div className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm rounded-xl border border-purple-500/20 p-6">
                  <h2 className="text-lg font-semibold mb-4 flex items-center">
                    <Activity className="w-5 h-5 text-purple-400 mr-2" />
                    Shannon Entropy Calculator
                  </h2>
                  <textarea
                    value={entropyText}
                    onChange={e => setEntropyText(e.target.value)}
                    placeholder="Enter text to analyze entropy..."
                    className="w-full h-40 px-4 py-3 bg-black/40 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 resize-none"
                  />
                  <div className="mt-4 flex justify-between items-center">
                    <div className="text-sm text-gray-400">{entropyText.length} characters</div>
                    <div className="flex space-x-2">
                      <button
                        onClick={() => setEntropyText(sampleTexts.entropy)}
                        className="px-3 py-1 text-xs bg-gray-700/50 hover:bg-gray-700 rounded-lg transition-colors border border-gray-600"
                      >
                        Load Sample
                      </button>
                      <button
                        onClick={calculateEntropy}
                        disabled={!entropyText.trim()}
                        className="px-4 py-2 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 disabled:from-gray-700 disabled:to-gray-800 disabled:cursor-not-allowed rounded-lg font-semibold transition-all"
                      >
                        Calculate Entropy
                      </button>
                    </div>
                  </div>
                </div>

                {entropyResult && (
                  <div className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm rounded-xl border border-purple-500/20 p-6">
                    <div className="flex items-center justify-between mb-6">
                      <h2 className="text-xl font-semibold">Entropy Analysis Results</h2>
                      <button
                        onClick={exportResult}
                        className="p-2 bg-purple-500/20 hover:bg-purple-500/30 rounded-lg transition-colors border border-purple-500/30"
                      >
                        <Download className="w-5 h-5 text-purple-400" />
                      </button>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                      <div className="p-4 bg-purple-500/10 rounded-lg border border-purple-500/30">
                        <div className="text-2xl font-bold text-purple-400">
                          {entropyResult.entropy.toFixed(3)}
                        </div>
                        <div className="text-sm text-gray-400">Shannon Entropy</div>
                      </div>
                      <div className="p-4 bg-blue-500/10 rounded-lg border border-blue-500/30">
                        <div className="text-2xl font-bold text-blue-400">
                          {entropyResult.avgBitsPerChar.toFixed(2)}
                        </div>
                        <div className="text-sm text-gray-400">Bits per Char</div>
                      </div>
                      <div className="p-4 bg-pink-500/10 rounded-lg border border-pink-500/30">
                        <div className="text-2xl font-bold text-pink-400">
                          {entropyResult.redundancy.toFixed(1)}%
                        </div>
                        <div className="text-sm text-gray-400">Redundancy</div>
                      </div>
                      <div className="p-4 bg-green-500/10 rounded-lg border border-green-500/30">
                        <div className="text-2xl font-bold text-green-400">
                          {entropyResult.estimatedCompression.toFixed(1)}%
                        </div>
                        <div className="text-sm text-gray-400">Est. Compression</div>
                      </div>
                    </div>

                    <div className="p-4 bg-black/40 rounded-lg">
                      <div className="text-sm text-gray-400 mb-2">Interpretation:</div>
                      <p className="text-gray-300">
                        {entropyResult.entropy < 2
                          ? 'Low entropy indicates high predictability and repetition. Text is highly compressible.'
                          : entropyResult.entropy < 4
                            ? 'Moderate entropy suggests balanced information content with some predictability.'
                            : 'High entropy indicates low redundancy and high information density. Text is less compressible.'}
                      </p>
                    </div>
                  </div>
                )}
              </>
            )}

            {/* Bias Detector */}
            {activeTab === 'bias' && (
              <>
                <div className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm rounded-xl border border-pink-500/20 p-6">
                  <h2 className="text-lg font-semibold mb-4 flex items-center">
                    <AlertTriangle className="w-5 h-5 text-pink-400 mr-2" />
                    Bias Detection Tool
                  </h2>
                  <textarea
                    value={biasText}
                    onChange={e => setBiasText(e.target.value)}
                    placeholder="Enter text to detect potential biases..."
                    className="w-full h-40 px-4 py-3 bg-black/40 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-pink-500 focus:ring-2 focus:ring-pink-500/20 resize-none"
                  />
                  <div className="mt-4 flex justify-between items-center">
                    <div className="text-sm text-gray-400">{biasText.length} characters</div>
                    <div className="flex space-x-2">
                      <button
                        onClick={() => setBiasText(sampleTexts.bias)}
                        className="px-3 py-1 text-xs bg-gray-700/50 hover:bg-gray-700 rounded-lg transition-colors border border-gray-600"
                      >
                        Load Sample
                      </button>
                      <button
                        onClick={detectBias}
                        disabled={!biasText.trim()}
                        className="px-4 py-2 bg-gradient-to-r from-pink-500 to-red-500 hover:from-pink-600 hover:to-red-600 disabled:from-gray-700 disabled:to-gray-800 disabled:cursor-not-allowed rounded-lg font-semibold transition-all"
                      >
                        Detect Bias
                      </button>
                    </div>
                  </div>
                </div>

                {biasResult && (
                  <div className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm rounded-xl border border-pink-500/20 p-6">
                    <div className="flex items-center justify-between mb-6">
                      <h2 className="text-xl font-semibold">Bias Detection Results</h2>
                      <button
                        onClick={exportResult}
                        className="p-2 bg-pink-500/20 hover:bg-pink-500/30 rounded-lg transition-colors border border-pink-500/30"
                      >
                        <Download className="w-5 h-5 text-pink-400" />
                      </button>
                    </div>

                    <div className="grid grid-cols-2 gap-4 mb-6">
                      <div className="p-4 bg-pink-500/10 rounded-lg border border-pink-500/30">
                        <div className="text-3xl font-bold text-pink-400">
                          {biasResult.biasScore.toFixed(1)}
                        </div>
                        <div className="text-sm text-gray-400">Overall Bias Score</div>
                      </div>
                      <div className="p-4 bg-purple-500/10 rounded-lg border border-purple-500/30">
                        <div className="text-3xl font-bold text-purple-400 capitalize">
                          {biasResult.sentiment}
                        </div>
                        <div className="text-sm text-gray-400">Detected Sentiment</div>
                      </div>
                    </div>

                    <div className="space-y-4">
                      {biasResult.detectedBiases.length === 0 ? (
                        <div className="p-4 bg-green-500/10 rounded-lg border border-green-500/30">
                          <p className="text-green-400">✓ No significant biases detected</p>
                        </div>
                      ) : (
                        biasResult.detectedBiases.map((bias, idx) => (
                          <div
                            key={idx}
                            className="p-4 bg-red-500/10 rounded-lg border border-red-500/30"
                          >
                            <div className="flex items-center justify-between mb-2">
                              <h3 className="font-semibold text-red-400">{bias.type}</h3>
                              <span className="text-sm text-red-400">
                                {bias.confidence.toFixed(1)}% confidence
                              </span>
                            </div>
                            <div className="text-sm text-gray-400 mb-2">Examples:</div>
                            <div className="flex flex-wrap gap-2">
                              {bias.examples.map((example, i) => (
                                <span key={i} className="px-2 py-1 bg-red-500/20 rounded text-xs">
                                  {example}
                                </span>
                              ))}
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                )}
              </>
            )}

            {/* Compression Simulator */}
            {activeTab === 'compression' && (
              <>
                <div className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm rounded-xl border border-blue-500/20 p-6">
                  <h2 className="text-lg font-semibold mb-4 flex items-center">
                    <BarChart3 className="w-5 h-5 text-blue-400 mr-2" />
                    Data Compression Simulator
                  </h2>

                  <div className="mb-4">
                    <label className="text-sm text-gray-400 mb-2 block">
                      Compression Algorithm
                    </label>
                    <div className="grid grid-cols-3 gap-3">
                      {(['huffman', 'lz77', 'shannon-fano'] as const).map(algo => (
                        <button
                          key={algo}
                          onClick={() => setCompressionAlgorithm(algo)}
                          className={`p-3 rounded-lg border transition-all ${
                            compressionAlgorithm === algo
                              ? 'bg-blue-500/20 border-blue-400'
                              : 'bg-gray-800/50 border-gray-700 hover:border-blue-500/50'
                          }`}
                        >
                          <div className="text-sm font-medium capitalize">
                            {algo.replace('-', ' ')}
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>

                  <textarea
                    value={compressionText}
                    onChange={e => setCompressionText(e.target.value)}
                    placeholder="Enter text to simulate compression..."
                    className="w-full h-40 px-4 py-3 bg-black/40 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 resize-none"
                  />
                  <div className="mt-4 flex justify-between items-center">
                    <div className="text-sm text-gray-400">{compressionText.length} characters</div>
                    <div className="flex space-x-2">
                      <button
                        onClick={() => setCompressionText(sampleTexts.compression)}
                        className="px-3 py-1 text-xs bg-gray-700/50 hover:bg-gray-700 rounded-lg transition-colors border border-gray-600"
                      >
                        Load Sample
                      </button>
                      <button
                        onClick={simulateCompression}
                        disabled={!compressionText.trim()}
                        className="px-4 py-2 bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 disabled:from-gray-700 disabled:to-gray-800 disabled:cursor-not-allowed rounded-lg font-semibold transition-all"
                      >
                        Simulate Compression
                      </button>
                    </div>
                  </div>
                </div>

                {compressionResult && (
                  <div className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm rounded-xl border border-blue-500/20 p-6">
                    <div className="flex items-center justify-between mb-6">
                      <h2 className="text-xl font-semibold">Compression Results</h2>
                      <button
                        onClick={exportResult}
                        className="p-2 bg-blue-500/20 hover:bg-blue-500/30 rounded-lg transition-colors border border-blue-500/30"
                      >
                        <Download className="w-5 h-5 text-blue-400" />
                      </button>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                      <div className="p-4 bg-blue-500/10 rounded-lg border border-blue-500/30">
                        <div className="text-2xl font-bold text-blue-400">
                          {compressionResult.originalSize}B
                        </div>
                        <div className="text-sm text-gray-400">Original Size</div>
                      </div>
                      <div className="p-4 bg-cyan-500/10 rounded-lg border border-cyan-500/30">
                        <div className="text-2xl font-bold text-cyan-400">
                          {compressionResult.compressedSize}B
                        </div>
                        <div className="text-sm text-gray-400">Compressed Size</div>
                      </div>
                      <div className="p-4 bg-green-500/10 rounded-lg border border-green-500/30">
                        <div className="text-2xl font-bold text-green-400">
                          {compressionResult.ratio}:1
                        </div>
                        <div className="text-sm text-gray-400">Compression Ratio</div>
                      </div>
                      <div className="p-4 bg-purple-500/10 rounded-lg border border-purple-500/30">
                        <div className="text-2xl font-bold text-purple-400">
                          {compressionResult.savings}%
                        </div>
                        <div className="text-sm text-gray-400">Space Savings</div>
                      </div>
                    </div>

                    <div className="p-4 bg-black/40 rounded-lg">
                      <div className="text-sm text-gray-400 mb-2">Algorithm:</div>
                      <p className="text-gray-300 font-semibold">{compressionResult.algorithm}</p>
                    </div>
                  </div>
                )}
              </>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Info Panel */}
            {showInfo && (
              <div className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm rounded-xl border border-purple-500/20 p-6">
                <h2 className="text-lg font-semibold mb-4 flex items-center">
                  <Info className="w-5 h-5 text-purple-400 mr-2" />
                  About Research Tools
                </h2>
                <div className="space-y-4 text-sm text-gray-300">
                  <div>
                    <div className="font-semibold text-purple-400 mb-1">Shannon Entropy</div>
                    <p className="text-gray-400">
                      Measures information density and predictability in text. Named after Claude
                      Shannon, the father of information theory.
                    </p>
                  </div>
                  <div>
                    <div className="font-semibold text-pink-400 mb-1">Bias Detection</div>
                    <p className="text-gray-400">
                      Identifies potential biases in text including gender, sentiment, and authority
                      biases using pattern analysis.
                    </p>
                  </div>
                  <div>
                    <div className="font-semibold text-blue-400 mb-1">Compression Simulation</div>
                    <p className="text-gray-400">
                      Demonstrates classic compression algorithms: Huffman coding, LZ77, and
                      Shannon-Fano encoding.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* Quick Reference */}
            <div className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm rounded-xl border border-purple-500/20 p-6">
              <h2 className="text-lg font-semibold mb-4">Quick Reference</h2>
              <div className="space-y-3 text-sm">
                <div>
                  <div className="font-semibold text-purple-400 mb-1">Entropy Range</div>
                  <div className="text-gray-400">0-8 bits/char for text</div>
                </div>
                <div>
                  <div className="font-semibold text-pink-400 mb-1">Bias Score</div>
                  <div className="text-gray-400">&lt;30: Low, 30-60: Medium, &gt;60: High</div>
                </div>
                <div>
                  <div className="font-semibold text-blue-400 mb-1">Compression Ratio</div>
                  <div className="text-gray-400">2:1 = 50% size reduction</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AILabResearchPage;
