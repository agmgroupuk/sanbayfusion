import React, { useState, useEffect } from 'react';
import { Page } from '../../App';
import {
  ArrowLeft,
  Sparkles,
  Wand2,
  RefreshCw,
  Copy,
  Download,
  History,
  Maximize2,
  Minimize2,
  ArrowRight,
  Zap,
  MessageSquare,
  FileText,
  TrendingUp,
  Target,
  Settings,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Sliders,
  ChevronDown,
  ChevronUp,
  BarChart3,
  Hash,
  Clock,
  Lock,
  Crown,
} from 'lucide-react';
import { aiLabService } from '../../services/aiLabService';
import { authService } from '../../services/authService';

interface AILabTransformersPageProps {
  onNavigate: (page: Page) => void;
}

interface SubscriptionStatus {
  hasAccess: boolean;
  type: string;
  expiresAt?: Date;
  usageToday: number;
  usageLimit: number;
  hasActiveSubscription: boolean;
}

interface TransformMode {
  id: string;
  name: string;
  description: string;
  icon: React.ReactNode;
  category: 'style' | 'length' | 'tone' | 'clarity';
  color: string;
}

interface TransformResult {
  id: string;
  mode: string;
  input: string;
  output: string;
  intensity: number;
  timestamp: number;
  metrics: {
    inputLength: number;
    outputLength: number;
    changePercent: number;
    processingTime: number;
  };
}

const AILabTransformersPage: React.FC<AILabTransformersPageProps> = ({ onNavigate }) => {
  // Subscription State
  const [subscriptionStatus, setSubscriptionStatus] = useState<SubscriptionStatus>({
    hasAccess: false,
    type: 'free',
    usageToday: 0,
    usageLimit: 0,
    hasActiveSubscription: false,
  });

  // Check subscription status
  useEffect(() => {
    const checkSubscription = async () => {
      try {
        const hasActiveSubscription = false; // Set to false for testing subscription barrier
        setSubscriptionStatus({
          hasAccess: hasActiveSubscription,
          type: hasActiveSubscription ? 'premium' : 'free',
          usageToday: 0,
          usageLimit: hasActiveSubscription ? 1000 : 5,
          hasActiveSubscription,
        });
      } catch (error) {
        console.error('Error checking subscription:', error);
      }
    };
    checkSubscription();
  }, []);

  // Transform Modes
  const modes: TransformMode[] = [
    {
      id: 'formal',
      name: 'Make Formal',
      description: 'Transform text to professional, formal language',
      icon: <FileText className="w-5 h-5" />,
      category: 'style',
      color: 'from-blue-500 to-indigo-600',
    },
    {
      id: 'casual',
      name: 'Make Casual',
      description: 'Convert to friendly, conversational tone',
      icon: <MessageSquare className="w-5 h-5" />,
      category: 'style',
      color: 'from-green-500 to-emerald-600',
    },
    {
      id: 'expand',
      name: 'Expand Text',
      description: 'Add more details and elaborate on ideas',
      icon: <Maximize2 className="w-5 h-5" />,
      category: 'length',
      color: 'from-purple-500 to-pink-600',
    },
    {
      id: 'summarize',
      name: 'Summarize',
      description: 'Condense to key points and main ideas',
      icon: <Minimize2 className="w-5 h-5" />,
      category: 'length',
      color: 'from-orange-500 to-red-600',
    },
    {
      id: 'professional',
      name: 'Professionalize',
      description: 'Business-appropriate language and structure',
      icon: <Target className="w-5 h-5" />,
      category: 'tone',
      color: 'from-cyan-500 to-blue-600',
    },
    {
      id: 'simplify',
      name: 'Simplify',
      description: 'Use simpler words and shorter sentences',
      icon: <Zap className="w-5 h-5" />,
      category: 'clarity',
      color: 'from-yellow-500 to-orange-600',
    },
    {
      id: 'clarify',
      name: 'Clarify',
      description: 'Make meaning clearer and more precise',
      icon: <CheckCircle2 className="w-5 h-5" />,
      category: 'clarity',
      color: 'from-teal-500 to-cyan-600',
    },
    {
      id: 'rewrite',
      name: 'Creative Rewrite',
      description: 'Rephrase completely while keeping meaning',
      icon: <Sparkles className="w-5 h-5" />,
      category: 'style',
      color: 'from-pink-500 to-rose-600',
    },
  ];

  // State
  const [selectedMode, setSelectedMode] = useState<TransformMode>(modes[0]);
  const [inputText, setInputText] = useState('');
  const [outputText, setOutputText] = useState('');
  const [intensity, setIntensity] = useState(50);
  const [isProcessing, setIsProcessing] = useState(false);
  const [history, setHistory] = useState<TransformResult[]>([]);
  const [showHistory, setShowHistory] = useState(false);
  const [categoryFilter, setCategoryFilter] = useState<
    'all' | 'style' | 'length' | 'tone' | 'clarity'
  >('all');
  const [compareMode, setCompareMode] = useState(false);

  // Sample Texts
  const sampleTexts = [
    "Hey! I think we should totally meet up tomorrow to discuss the project. Let me know if you're free!",
    'The implementation of artificial intelligence systems requires careful consideration of ethical implications and potential societal impacts.',
    "Our company's Q4 results exceeded expectations with revenue growth of 23% year-over-year, driven primarily by expansion in emerging markets.",
    "I was wondering if maybe you could help me with this problem I'm having with my computer. It keeps freezing and stuff.",
  ];

  // Load history from localStorage
  useEffect(() => {
    try {
      const saved = localStorage.getItem('ailab_global_history');
      if (saved) {
        const allHistory = JSON.parse(saved);
        const transformHistory = allHistory.filter((item: any) => item.type === 'transform');
        setHistory(transformHistory.slice(-20)); // Keep last 20
      }
    } catch (e) {
      console.error('Failed to load history:', e);
    }
  }, []);

  // Transform Text
  const transformText = async () => {
    if (!inputText.trim()) return;

    setIsProcessing(true);
    setOutputText('');

    const startTime = Date.now();

    try {
      // Generate transformed output using AI
      const transformed = await generateTransformation(inputText, selectedMode.id, intensity);
      setOutputText(transformed);

      const processingTime = Date.now() - startTime;

      // Create result
      const result: TransformResult = {
        id: `transform-${Date.now()}`,
        mode: selectedMode.name,
        input: inputText,
        output: transformed,
        intensity,
        timestamp: Date.now(),
        metrics: {
          inputLength: inputText.length,
          outputLength: transformed.length,
          changePercent: Math.abs(
            ((transformed.length - inputText.length) / inputText.length) * 100
          ),
          processingTime,
        },
      };

      // Save to history
      saveToHistory(result);
      setHistory(prev => [result, ...prev].slice(0, 20));
    } catch (error) {
      console.error('Error in transformation:', error);
      setOutputText('Error: Failed to transform text. Please try again.');
    }

    setIsProcessing(false);
    setCompareMode(true);
  };

  // Generate Transformation using AI
  const generateTransformation = async (
    text: string,
    mode: string,
    intensity: number
  ): Promise<string> => {
    try {
      // Build prompt based on transformation mode
      let prompt = '';
      let systemPrompt = '';

      switch (mode) {
        case 'formal':
          prompt = `Transform this text to ${intensity > 70 ? 'very formal, academic' : 'professional, formal'} language: "${text}"`;
          systemPrompt =
            'You are an expert in formal writing. Transform text to professional, formal language while preserving meaning.';
          break;
        case 'casual':
          prompt = `Rewrite this in a ${intensity > 70 ? 'very casual, friendly' : 'casual, conversational'} tone: "${text}"`;
          systemPrompt =
            'You are an expert in casual writing. Make text friendly and conversational while keeping the message clear.';
          break;
        case 'expand':
          prompt = `Expand and elaborate on this text (increase length by ${intensity}%): "${text}"`;
          systemPrompt =
            'You are an expert writer. Expand text with relevant details, examples, and explanations.';
          break;
        case 'summarize':
          prompt = `Summarize this text (reduce by ${intensity}%): "${text}"`;
          systemPrompt =
            'You are an expert at summarization. Create concise summaries that capture key points.';
          break;
        case 'professional':
          prompt = `Rewrite this in a professional business tone: "${text}"`;
          systemPrompt =
            'You are an expert business writer. Transform text to sound professional and business-appropriate.';
          break;
        case 'simplify':
          prompt = `Simplify this text to ${intensity > 70 ? 'very simple' : 'simpler'} language: "${text}"`;
          systemPrompt =
            'You are an expert at simplification. Make text easy to understand while preserving meaning.';
          break;
        case 'clarify':
          prompt = `Clarify and make this text clearer: "${text}"`;
          systemPrompt =
            'You are an expert at clear communication. Improve clarity and remove ambiguity.';
          break;
        case 'rewrite':
          prompt = `Creatively rewrite this text: "${text}"`;
          systemPrompt =
            'You are a creative writer. Rewrite text in a fresh, engaging way while keeping the core message.';
          break;
        default:
          return text;
      }

      const result = await aiLabService.generateCompletion({
        provider: 'openai',
        model: 'gpt-4',
        prompt: prompt,
        systemPrompt: systemPrompt,
        temperature: 0.7,
        maxTokens: 500,
      });

      if (!result.success || !result.response) {
        throw new Error(result.error || 'Transformation failed');
      }

      return result.response;
    } catch (error) {
      console.error('Error in transformation:', error);
      return `Error: ${error instanceof Error ? error.message : 'Transformation failed'}`;
    }
  };

  // Transformation Functions (Legacy - kept as fallback, but no longer used)
  const makeFormal = (text: string, intensity: number): string => {
    if (intensity > 0.7) {
      return text
        .replace(/Hey!?/gi, 'Greetings.')
        .replace(/totally/gi, 'certainly')
        .replace(/Let me know/gi, 'Please inform me')
        .replace(/you're/gi, 'you are')
        .replace(/I think/gi, 'I believe')
        .replace(/!/g, '.');
    } else if (intensity > 0.4) {
      return text
        .replace(/Hey!?/gi, 'Hello.')
        .replace(/totally/gi, 'definitely')
        .replace(/!/g, '.');
    }
    return text.replace(/Hey/gi, 'Hello');
  };

  const makeCasual = (text: string, intensity: number): string => {
    if (intensity > 0.7) {
      return text
        .replace(/Greetings/gi, 'Hey')
        .replace(/requires/gi, 'needs')
        .replace(/consideration/gi, 'thinking about')
        .replace(/implementation/gi, 'setting up')
        .replace(/\./g, '!')
        .toLowerCase()
        .replace(/^./, str => str.toUpperCase());
    } else if (intensity > 0.4) {
      return text.replace(/requires/gi, 'needs').replace(/consideration/gi, 'thought');
    }
    return text;
  };

  const expandText = (text: string, intensity: number): string => {
    const expansions = [
      ' This is particularly important because it allows for better understanding and clearer communication.',
      ' Furthermore, we should consider the various implications and potential outcomes of this approach.',
      ' It is worth noting that this perspective takes into account multiple factors and considerations.',
      ' Additionally, this method provides several advantages and benefits that are worth exploring in detail.',
    ];

    const numExpansions = Math.floor(intensity * 2);
    let expanded = text;

    for (let i = 0; i < numExpansions && i < expansions.length; i++) {
      expanded += expansions[i];
    }

    return expanded;
  };

  const summarizeText = (text: string, intensity: number): string => {
    const sentences = text.split(/[.!?]+/).filter(s => s.trim());
    const keepCount = Math.max(1, Math.floor(sentences.length * (1 - intensity * 0.7)));
    return sentences.slice(0, keepCount).join('. ') + '.';
  };

  const makeProfessional = (text: string, intensity: number): string => {
    return text
      .replace(/I think/gi, 'In my professional assessment,')
      .replace(/maybe/gi, 'perhaps')
      .replace(/stuff/gi, 'matters')
      .replace(/help me with/gi, 'assist me in addressing')
      .replace(/problem/gi, 'issue')
      .replace(/!/g, '.');
  };

  const simplifyText = (text: string, intensity: number): string => {
    return text
      .replace(/implementation/gi, 'setup')
      .replace(/consideration/gi, 'thought')
      .replace(/implications/gi, 'effects')
      .replace(/societal/gi, 'social')
      .replace(/exceeded expectations/gi, 'did better than expected')
      .replace(/primarily/gi, 'mainly');
  };

  const clarifyText = (text: string, intensity: number): string => {
    return text
      .replace(/it/gi, 'the system')
      .replace(/this/gi, 'this specific matter')
      .replace(/that/gi, 'the aforementioned point')
      .replace(/they/gi, 'the individuals');
  };

  const creativeRewrite = (text: string, intensity: number): string => {
    const alternatives = [
      text.split(' ').reverse().join(' '),
      "Here's another way to express that: " + text,
      text.replace(/\b(\w+)\s+(\w+)\b/g, '$2 $1'),
      'Consider this perspective: ' + text.toLowerCase(),
    ];

    const index = Math.floor(intensity * (alternatives.length - 1));
    return alternatives[index];
  };

  // Save to History
  const saveToHistory = (result: TransformResult) => {
    try {
      const saved = localStorage.getItem('ailab_global_history') || '[]';
      const history = JSON.parse(saved);
      history.push({
        type: 'transform',
        ...result,
      });
      localStorage.setItem('ailab_global_history', JSON.stringify(history));
    } catch (e) {
      console.error('Failed to save:', e);
    }
  };

  // Copy to Clipboard
  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  // Download Result
  const downloadResult = () => {
    const content = `Input:\n${inputText}\n\nMode: ${selectedMode.name}\nIntensity: ${intensity}%\n\nOutput:\n${outputText}`;
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `transform-${Date.now()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Filter modes by category
  const filteredModes =
    categoryFilter === 'all' ? modes : modes.filter(m => m.category === categoryFilter);

  return (
    <div className="min-h-screen bg-black text-white pb-20 relative">
      {/* Subscription Access Barrier */}
      {!subscriptionStatus.hasActiveSubscription && (
        <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-gray-900 border border-gray-800 rounded-2xl p-8 max-w-md w-full text-center">
            <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-orange-500 to-red-600 rounded-full flex items-center justify-center">
              <Crown className="w-8 h-8 text-black" />
            </div>
            <h2 className="text-2xl font-bold text-white mb-3">Transformers Lab Access Required</h2>
            <p className="text-gray-400 mb-6">
              The Advanced Transformer Model Analysis is a premium feature. Subscribe to unlock
              powerful text transformation capabilities and AI model testing.
            </p>
            <div className="flex flex-col gap-3 mb-6">
              <div className="flex items-center gap-2 text-sm text-gray-300">
                <Lock className="w-4 h-4 text-orange-400" />
                <span>Advanced transformer model analysis</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-300">
                <Sparkles className="w-4 h-4 text-red-400" />
                <span>Style transfer & tone adjustment</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-300">
                <Wand2 className="w-4 h-4 text-orange-400" />
                <span>Unlimited text transformations</span>
              </div>
            </div>
            <div className="flex flex-col sm:flex-row gap-3">
              <button
                onClick={() => onNavigate('subscription' as Page)}
                className="flex-1 bg-gradient-to-r from-orange-600 to-red-600 text-white px-6 py-3 rounded-lg font-semibold hover:from-orange-500 hover:to-red-500 transition-all flex items-center justify-center gap-2"
              >
                <Crown className="w-4 h-4" />
                Subscribe Now
              </button>
              <button
                onClick={() => onNavigate('ai-lab' as Page)}
                className="flex-1 bg-gray-800 hover:bg-gray-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors"
              >
                Back to Lab
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="sticky top-0 z-40 bg-black/95 backdrop-blur-xl border-b border-gray-800">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={() => onNavigate('ai-lab' as Page)}
                className="p-2 hover:bg-gray-800 rounded-lg transition-colors"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
              <div>
                <h1 className="text-2xl font-bold text-white flex items-center gap-2">
                  <Sparkles className="w-6 h-6 text-purple-400" />
                  Text Transformers
                </h1>
                <p className="text-sm text-gray-400">
                  Style transfer, tone adjustment, and text transformation
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={() => setShowHistory(!showHistory)}
                className="px-4 py-2 bg-gray-800 hover:bg-gray-700 border border-gray-700 rounded-lg transition-colors flex items-center gap-2"
              >
                <History className="w-4 h-4" />
                <span className="hidden sm:inline">History</span>
                {history.length > 0 && (
                  <span className="px-2 py-0.5 bg-cyan-500/20 text-cyan-400 text-xs rounded-full">
                    {history.length}
                  </span>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-6 py-8">
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Left Column - Transform Modes */}
          <div className="lg:col-span-1">
            <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-6 sticky top-24">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-white">Transform Modes</h3>
                <Wand2 className="w-5 h-5 text-purple-400" />
              </div>

              {/* Category Filters */}
              <div className="flex flex-wrap gap-2 mb-4">
                {['all', 'style', 'length', 'tone', 'clarity'].map(cat => (
                  <button
                    key={cat}
                    onClick={() => setCategoryFilter(cat as any)}
                    className={`px-3 py-1 rounded-lg text-xs font-medium transition-colors ${
                      categoryFilter === cat
                        ? 'bg-cyan-500 text-white'
                        : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
                    }`}
                  >
                    {cat.charAt(0).toUpperCase() + cat.slice(1)}
                  </button>
                ))}
              </div>

              {/* Mode List */}
              <div className="space-y-2">
                {filteredModes.map(mode => (
                  <button
                    key={mode.id}
                    onClick={() => setSelectedMode(mode)}
                    className={`w-full p-3 rounded-lg border-2 transition-all text-left ${
                      selectedMode.id === mode.id
                        ? `bg-gradient-to-r ${mode.color} border-transparent`
                        : 'bg-gray-800/50 border-gray-700 hover:border-gray-600'
                    }`}
                  >
                    <div className="flex items-center gap-2 mb-1">
                      {mode.icon}
                      <span className="font-semibold text-white text-sm">{mode.name}</span>
                    </div>
                    <p className="text-xs text-gray-300">{mode.description}</p>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Middle Column - Input/Output */}
          <div className="lg:col-span-2 space-y-6">
            {/* Input Section */}
            <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-white">Input Text</h3>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-gray-400">{inputText.length} characters</span>
                </div>
              </div>

              <textarea
                value={inputText}
                onChange={e => setInputText(e.target.value)}
                placeholder="Enter text to transform..."
                className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-cyan-500 resize-none min-h-[200px]"
              />

              {/* Sample Texts */}
              <div className="mt-4">
                <p className="text-xs text-gray-400 mb-2">Quick Samples:</p>
                <div className="flex flex-wrap gap-2">
                  {sampleTexts.map((sample, i) => (
                    <button
                      key={i}
                      onClick={() => setInputText(sample)}
                      className="px-3 py-1.5 bg-gray-800 hover:bg-gray-700 border border-gray-700 rounded-lg text-xs text-gray-300 transition-colors"
                    >
                      Sample {i + 1}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Intensity Control */}
            <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                  <Sliders className="w-5 h-5 text-cyan-400" />
                  Transformation Intensity
                </h3>
                <span className="text-2xl font-bold text-cyan-400">{intensity}%</span>
              </div>

              <input
                type="range"
                min="0"
                max="100"
                value={intensity}
                onChange={e => setIntensity(parseInt(e.target.value))}
                className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer slider-thumb"
              />

              <div className="flex justify-between text-xs text-gray-400 mt-2">
                <span>Subtle (0%)</span>
                <span>Moderate (50%)</span>
                <span>Extreme (100%)</span>
              </div>

              <div className="mt-4 p-3 bg-gray-800/50 rounded-lg">
                <p className="text-sm text-gray-300">
                  {intensity < 33 &&
                    '🟢 Subtle transformation - Minor changes while preserving original style'}
                  {intensity >= 33 &&
                    intensity < 66 &&
                    '🟡 Moderate transformation - Balanced changes to achieve desired effect'}
                  {intensity >= 66 &&
                    '🔴 Extreme transformation - Maximum changes for dramatic effect'}
                </p>
              </div>
            </div>

            {/* Transform Button */}
            <button
              onClick={transformText}
              disabled={!inputText.trim() || isProcessing}
              className="w-full py-4 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 disabled:from-gray-700 disabled:to-gray-700 text-white font-bold text-lg rounded-xl shadow-lg transition-all disabled:cursor-not-allowed flex items-center justify-center gap-3"
            >
              {isProcessing ? (
                <>
                  <RefreshCw className="w-6 h-6 animate-spin" />
                  Transforming...
                </>
              ) : (
                <>
                  <Wand2 className="w-6 h-6" />
                  Transform with {selectedMode.name}
                </>
              )}
            </button>

            {/* Output Section */}
            {(outputText || isProcessing) && (
              <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-white">Transformed Output</h3>
                  {outputText && (
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => copyToClipboard(outputText)}
                        className="p-2 bg-gray-800 hover:bg-gray-700 rounded-lg transition-colors"
                        title="Copy"
                      >
                        <Copy className="w-4 h-4" />
                      </button>
                      <button
                        onClick={downloadResult}
                        className="p-2 bg-gray-800 hover:bg-gray-700 rounded-lg transition-colors"
                        title="Download"
                      >
                        <Download className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                </div>

                {isProcessing ? (
                  <div className="flex items-center justify-center py-12">
                    <RefreshCw className="w-8 h-8 text-purple-400 animate-spin" />
                  </div>
                ) : (
                  <>
                    <div className="bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 min-h-[200px]">
                      <p className="text-white leading-relaxed">{outputText}</p>
                    </div>

                    {/* Metrics */}
                    <div className="grid grid-cols-3 gap-4 mt-4">
                      <div className="text-center p-3 bg-gray-800/50 rounded-lg">
                        <p className="text-xs text-gray-400 mb-1">Length Change</p>
                        <p className="text-lg font-bold text-cyan-400">
                          {outputText.length > inputText.length ? '+' : ''}
                          {(
                            ((outputText.length - inputText.length) / inputText.length) *
                            100
                          ).toFixed(0)}
                          %
                        </p>
                      </div>
                      <div className="text-center p-3 bg-gray-800/50 rounded-lg">
                        <p className="text-xs text-gray-400 mb-1">Characters</p>
                        <p className="text-lg font-bold text-white">{outputText.length}</p>
                      </div>
                      <div className="text-center p-3 bg-gray-800/50 rounded-lg">
                        <p className="text-xs text-gray-400 mb-1">Mode</p>
                        <p className="text-sm font-bold text-purple-400">{selectedMode.name}</p>
                      </div>
                    </div>

                    {/* Compare Mode Toggle */}
                    <button
                      onClick={() => setCompareMode(!compareMode)}
                      className="w-full mt-4 px-4 py-2 bg-gray-800 hover:bg-gray-700 border border-gray-700 rounded-lg transition-colors flex items-center justify-center gap-2"
                    >
                      {compareMode ? (
                        <ChevronUp className="w-4 h-4" />
                      ) : (
                        <ChevronDown className="w-4 h-4" />
                      )}
                      {compareMode ? 'Hide' : 'Show'} Side-by-Side Comparison
                    </button>

                    {/* Side-by-Side Comparison */}
                    {compareMode && (
                      <div className="grid md:grid-cols-2 gap-4 mt-4">
                        <div>
                          <h4 className="text-sm font-semibold text-gray-400 mb-2">Before</h4>
                          <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-3">
                            <p className="text-sm text-gray-300">{inputText}</p>
                          </div>
                        </div>
                        <div>
                          <h4 className="text-sm font-semibold text-cyan-400 mb-2">After</h4>
                          <div className="bg-gray-800/50 border border-cyan-500/30 rounded-lg p-3">
                            <p className="text-sm text-white">{outputText}</p>
                          </div>
                        </div>
                      </div>
                    )}
                  </>
                )}
              </div>
            )}
          </div>
        </div>

        {/* History Panel */}
        {showHistory && history.length > 0 && (
          <div className="mt-6 bg-gray-900/50 border border-gray-800 rounded-xl p-6">
            <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
              <History className="w-5 h-5 text-cyan-400" />
              Recent Transformations
            </h3>

            <div className="space-y-3">
              {history.map(item => (
                <div
                  key={item.id}
                  className="p-4 bg-gray-800/50 border border-gray-700 rounded-lg hover:border-gray-600 transition-colors"
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-1 bg-purple-500/20 text-purple-400 text-xs rounded">
                        {item.mode}
                      </span>
                      <span className="text-xs text-gray-500">
                        {new Date(item.timestamp).toLocaleString()}
                      </span>
                    </div>
                    <button
                      onClick={() => {
                        setInputText(item.input);
                        setOutputText(item.output);
                        setCompareMode(true);
                      }}
                      className="text-xs text-cyan-400 hover:text-cyan-300"
                    >
                      Reload
                    </button>
                  </div>

                  <div className="grid md:grid-cols-2 gap-3 text-xs">
                    <div>
                      <p className="text-gray-400 mb-1">Input:</p>
                      <p className="text-gray-300 line-clamp-2">{item.input}</p>
                    </div>
                    <div>
                      <p className="text-gray-400 mb-1">Output:</p>
                      <p className="text-white line-clamp-2">{item.output}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-4 mt-3 text-xs text-gray-500">
                    <span>
                      <Hash className="w-3 h-3 inline" /> {item.metrics.outputLength} chars
                    </span>
                    <span>
                      <TrendingUp className="w-3 h-3 inline" />{' '}
                      {item.metrics.changePercent.toFixed(0)}% change
                    </span>
                    <span>
                      <Clock className="w-3 h-3 inline" /> {item.metrics.processingTime}ms
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AILabTransformersPage;
