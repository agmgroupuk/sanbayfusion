import React, { useState, useEffect } from 'react';
import {
  Zap,
  Clock,
  TrendingUp,
  Activity,
  BarChart3,
  Target,
  PlayCircle,
  StopCircle,
  Download,
  Info,
  RefreshCw,
  AlertTriangle,
  Lock,
  Crown,
} from 'lucide-react';
import { authService } from '../../services/authService';

interface Provider {
  id: string;
  name: string;
  endpoint: string;
  color: string;
  icon: string;
}

interface SubscriptionStatus {
  hasAccess: boolean;
  type: string;
  expiresAt?: Date;
  usageToday: number;
  usageLimit: number;
  hasActiveSubscription: boolean;
}

interface LatencyResult {
  id: string;
  providerId: string;
  providerName: string;
  ttfb: number; // Time to first byte
  totalTime: number;
  tokens: number;
  tokensPerSecond: number;
  status: 'success' | 'error' | 'timeout';
  timestamp: number;
  prompt: string;
}

interface BenchmarkRun {
  id: string;
  timestamp: number;
  prompt: string;
  iterations: number;
  results: LatencyResult[];
  stats: {
    fastest: string;
    slowest: string;
    avgLatency: number;
  };
}

interface ProviderStats {
  providerId: string;
  avgTTFB: number;
  avgTotal: number;
  avgTokensPerSec: number;
  successRate: number;
  p50: number;
  p95: number;
  p99: number;
}

interface SubscriptionStatus {
  hasAccess: boolean;
  type: string;
  expiresAt?: Date;
  usageToday: number;
  usageLimit: number;
  hasActiveSubscription: boolean;
}

const PROVIDERS: Provider[] = [
  { id: 'openai', name: 'OpenAI GPT-4', endpoint: 'api.openai.com', color: 'emerald', icon: '🤖' },
  {
    id: 'anthropic',
    name: 'Anthropic Claude',
    endpoint: 'api.anthropic.com',
    color: 'orange',
    icon: '🧠',
  },
  {
    id: 'google',
    name: 'Google Gemini',
    endpoint: 'generativelanguage.googleapis.com',
    color: 'blue',
    icon: '✨',
  },
  { id: 'meta', name: 'Meta Llama', endpoint: 'api.together.xyz', color: 'purple', icon: '🦙' },
  { id: 'mistral', name: 'Mistral AI', endpoint: 'api.mistral.ai', color: 'pink', icon: '🌪️' },
  { id: 'cohere', name: 'Cohere', endpoint: 'api.cohere.ai', color: 'indigo', icon: '🔷' },
];

const AILabLatencyPage: React.FC<{ onNavigate: (page: string) => void }> = ({ onNavigate }) => {
  // Subscription State
  const [subscriptionStatus, setSubscriptionStatus] = useState<SubscriptionStatus>({
    hasAccess: false,
    type: 'free',
    usageToday: 0,
    usageLimit: 0,
    hasActiveSubscription: false,
  });

  // Check subscription status
  useEffect(() => {
    const checkSubscription = async () => {
      try {
        const hasActiveSubscription = false; // Set to false for testing subscription barrier
        setSubscriptionStatus({
          hasAccess: hasActiveSubscription,
          type: hasActiveSubscription ? 'premium' : 'free',
          usageToday: 0,
          usageLimit: hasActiveSubscription ? 1000 : 5,
          hasActiveSubscription,
        });
      } catch (error) {
        console.error('Error checking subscription:', error);
      }
    };
    checkSubscription();
  }, []);

  const [prompt, setPrompt] = useState('Write a short poem about artificial intelligence');
  const [selectedProviders, setSelectedProviders] = useState<string[]>([
    'openai',
    'anthropic',
    'google',
  ]);
  const [iterations, setIterations] = useState<number>(3);
  const [isRunning, setIsRunning] = useState(false);
  const [currentResults, setCurrentResults] = useState<LatencyResult[]>([]);
  const [history, setHistory] = useState<BenchmarkRun[]>([]);
  const [showInfo, setShowInfo] = useState(false);
  const [progress, setProgress] = useState(0);
  const [providerStats, setProviderStats] = useState<ProviderStats[]>([]);

  // Load history from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('ailab_global_history');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        const latencyHistory = parsed.filter((h: any) => h.type === 'latency').slice(0, 10);
        setHistory(latencyHistory);
        calculateProviderStats(latencyHistory);
      } catch (e) {
        console.error('Failed to load history:', e);
      }
    }
  }, []);

  // Calculate provider statistics
  const calculateProviderStats = (runs: BenchmarkRun[]) => {
    const allResults = runs.flatMap(r => r.results);
    const statsByProvider: { [key: string]: LatencyResult[] } = {};

    allResults.forEach(result => {
      if (!statsByProvider[result.providerId]) {
        statsByProvider[result.providerId] = [];
      }
      statsByProvider[result.providerId].push(result);
    });

    const stats: ProviderStats[] = Object.entries(statsByProvider).map(([providerId, results]) => {
      const successful = results.filter(r => r.status === 'success');
      const ttfbs = successful.map(r => r.ttfb).sort((a, b) => a - b);
      const totals = successful.map(r => r.totalTime).sort((a, b) => a - b);

      return {
        providerId,
        avgTTFB: successful.reduce((sum, r) => sum + r.ttfb, 0) / successful.length || 0,
        avgTotal: successful.reduce((sum, r) => sum + r.totalTime, 0) / successful.length || 0,
        avgTokensPerSec:
          successful.reduce((sum, r) => sum + r.tokensPerSecond, 0) / successful.length || 0,
        successRate: (successful.length / results.length) * 100,
        p50: totals[Math.floor(totals.length * 0.5)] || 0,
        p95: totals[Math.floor(totals.length * 0.95)] || 0,
        p99: totals[Math.floor(totals.length * 0.99)] || 0,
      };
    });

    setProviderStats(stats);
  };

  // Mock latency test function
  const runLatencyTest = async (providerId: string, iteration: number): Promise<LatencyResult> => {
    const provider = PROVIDERS.find(p => p.id === providerId)!;

    // Simulate API call with random latency
    await new Promise(resolve => setTimeout(resolve, 500 + Math.random() * 1500));

    // Mock data generation
    const baseLatency =
      {
        openai: 400,
        anthropic: 350,
        google: 500,
        meta: 600,
        mistral: 450,
        cohere: 550,
      }[providerId] || 500;

    const variance = baseLatency * 0.3;
    const ttfb = baseLatency + (Math.random() - 0.5) * variance;
    const totalTime = ttfb * (2 + Math.random());
    const tokens = 150 + Math.floor(Math.random() * 100);
    const tokensPerSecond = tokens / (totalTime / 1000);

    // 95% success rate
    const status = Math.random() > 0.05 ? 'success' : Math.random() > 0.5 ? 'error' : 'timeout';

    return {
      id: `${Date.now()}-${providerId}-${iteration}`,
      providerId,
      providerName: provider.name,
      ttfb: status === 'success' ? ttfb : 0,
      totalTime: status === 'success' ? totalTime : 0,
      tokens: status === 'success' ? tokens : 0,
      tokensPerSecond: status === 'success' ? tokensPerSecond : 0,
      status,
      timestamp: Date.now(),
      prompt: prompt.substring(0, 50),
    };
  };

  // Run benchmark
  const runBenchmark = async () => {
    if (selectedProviders.length === 0 || !prompt.trim()) return;

    setIsRunning(true);
    setProgress(0);
    setCurrentResults([]);

    const allResults: LatencyResult[] = [];
    const totalTests = selectedProviders.length * iterations;
    let completed = 0;

    for (let i = 0; i < iterations; i++) {
      for (const providerId of selectedProviders) {
        const result = await runLatencyTest(providerId, i);
        allResults.push(result);
        completed++;
        setProgress((completed / totalTests) * 100);
        setCurrentResults([...allResults]);
      }
    }

    // Calculate stats
    const successful = allResults.filter(r => r.status === 'success');
    const fastest = successful.reduce(
      (min, r) => (r.totalTime < min.totalTime ? r : min),
      successful[0]
    );
    const slowest = successful.reduce(
      (max, r) => (r.totalTime > max.totalTime ? r : max),
      successful[0]
    );
    const avgLatency = successful.reduce((sum, r) => sum + r.totalTime, 0) / successful.length;

    const benchmarkRun: BenchmarkRun = {
      id: `run-${Date.now()}`,
      timestamp: Date.now(),
      prompt: prompt.substring(0, 50),
      iterations,
      results: allResults,
      stats: {
        fastest: fastest?.providerName || 'N/A',
        slowest: slowest?.providerName || 'N/A',
        avgLatency,
      },
    };

    const updatedHistory = [benchmarkRun, ...history].slice(0, 10);
    setHistory(updatedHistory);
    calculateProviderStats(updatedHistory);

    // Save to localStorage
    const allHistory = JSON.parse(localStorage.getItem('ailab_global_history') || '[]');
    const filtered = allHistory.filter((h: any) => h.type !== 'latency');
    localStorage.setItem(
      'ailab_global_history',
      JSON.stringify([...updatedHistory.map(r => ({ ...r, type: 'latency' })), ...filtered])
    );

    setIsRunning(false);
  };

  // Toggle provider selection
  const toggleProvider = (providerId: string) => {
    if (selectedProviders.includes(providerId)) {
      if (selectedProviders.length > 1) {
        setSelectedProviders(selectedProviders.filter(id => id !== providerId));
      }
    } else {
      setSelectedProviders([...selectedProviders, providerId]);
    }
  };

  // Get results by provider
  const getResultsByProvider = (providerId: string): LatencyResult[] => {
    return currentResults.filter(r => r.providerId === providerId && r.status === 'success');
  };

  // Calculate average for provider
  const getProviderAverage = (providerId: string): number => {
    const results = getResultsByProvider(providerId);
    if (results.length === 0) return 0;
    return results.reduce((sum, r) => sum + r.totalTime, 0) / results.length;
  };

  // Export results
  const exportResults = () => {
    const data = {
      timestamp: new Date().toISOString(),
      prompt,
      iterations,
      providers: selectedProviders.map(id => PROVIDERS.find(p => p.id === id)?.name),
      results: currentResults.map(r => ({
        provider: r.providerName,
        ttfb: `${r.ttfb.toFixed(0)}ms`,
        totalTime: `${r.totalTime.toFixed(0)}ms`,
        tokens: r.tokens,
        tokensPerSecond: r.tokensPerSecond.toFixed(1),
        status: r.status,
      })),
      stats: {
        fastest: history[0]?.stats.fastest,
        slowest: history[0]?.stats.slowest,
        avgLatency: `${history[0]?.stats.avgLatency.toFixed(0)}ms`,
      },
    };

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `latency-benchmark-${Date.now()}.json`;
    a.click();
  };

  // Sample prompts
  const samplePrompts = [
    'Write a short poem about artificial intelligence',
    'Explain quantum computing in simple terms',
    'Create a recipe for chocolate chip cookies',
    'Summarize the history of the internet in 3 paragraphs',
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 text-white relative">
      {/* Subscription Access Barrier */}
      {!subscriptionStatus.hasActiveSubscription && (
        <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-gray-900 border border-gray-800 rounded-2xl p-8 max-w-md w-full text-center">
            <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-yellow-500 to-amber-600 rounded-full flex items-center justify-center">
              <Crown className="w-8 h-8 text-black" />
            </div>
            <h2 className="text-2xl font-bold text-white mb-3">Latency Lab Access Required</h2>
            <p className="text-gray-400 mb-6">
              Performance Benchmarking & Latency Testing is a premium feature. Subscribe to unlock
              comprehensive AI model performance analysis and benchmarking tools.
            </p>
            <div className="flex flex-col gap-3 mb-6">
              <div className="flex items-center gap-2 text-sm text-gray-300">
                <Lock className="w-4 h-4 text-yellow-400" />
                <span>Advanced performance benchmarking</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-300">
                <Zap className="w-4 h-4 text-amber-400" />
                <span>Real-time latency monitoring</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-300">
                <BarChart3 className="w-4 h-4 text-yellow-400" />
                <span>Detailed statistical analysis</span>
              </div>
            </div>
            <div className="flex flex-col sm:flex-row gap-3">
              <button
                onClick={() => onNavigate('subscription')}
                className="flex-1 bg-gradient-to-r from-yellow-600 to-amber-600 text-white px-6 py-3 rounded-lg font-semibold hover:from-yellow-500 hover:to-amber-500 transition-all flex items-center justify-center gap-2"
              >
                <Crown className="w-4 h-4" />
                Subscribe Now
              </button>
              <button
                onClick={() => onNavigate('ai-lab')}
                className="flex-1 bg-gray-800 hover:bg-gray-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors"
              >
                Back to Lab
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="border-b border-cyan-500/20 bg-black/40 backdrop-blur-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => onNavigate('ai-lab')}
                className="text-cyan-400 hover:text-cyan-300 transition-colors"
              >
                ← Back to Hub
              </button>
              <div className="flex items-center space-x-2">
                <Zap className="w-6 h-6 text-yellow-400" />
                <h1 className="text-2xl font-bold bg-gradient-to-r from-yellow-400 to-orange-400 bg-clip-text text-transparent">
                  Latency Benchmarking
                </h1>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <button
                onClick={() => setShowInfo(!showInfo)}
                className="p-2 rounded-lg bg-yellow-500/10 hover:bg-yellow-500/20 transition-colors border border-yellow-500/30"
              >
                <Info className="w-5 h-5 text-yellow-400" />
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-3 space-y-6">
            {/* Provider Selection */}
            <div className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm rounded-xl border border-yellow-500/20 p-6">
              <h2 className="text-lg font-semibold mb-4 flex items-center">
                <Target className="w-5 h-5 text-yellow-400 mr-2" />
                Select Providers to Test
              </h2>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {PROVIDERS.map(provider => (
                  <button
                    key={provider.id}
                    onClick={() => toggleProvider(provider.id)}
                    disabled={isRunning}
                    className={`p-4 rounded-lg border transition-all ${
                      selectedProviders.includes(provider.id)
                        ? `bg-${provider.color}-500/20 border-${provider.color}-400 shadow-lg`
                        : 'bg-gray-800/50 border-gray-700 hover:border-yellow-500/50'
                    } disabled:opacity-50 disabled:cursor-not-allowed`}
                  >
                    <div className="text-2xl mb-2">{provider.icon}</div>
                    <div className="font-medium text-sm">{provider.name}</div>
                    <div className="text-xs text-gray-400 mt-1">{provider.endpoint}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Test Configuration */}
            <div className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm rounded-xl border border-yellow-500/20 p-6">
              <h2 className="text-lg font-semibold mb-4">Test Configuration</h2>

              <div className="space-y-4">
                <div>
                  <label className="text-sm text-gray-400 mb-2 block">Test Prompt</label>
                  <textarea
                    value={prompt}
                    onChange={e => setPrompt(e.target.value)}
                    disabled={isRunning}
                    placeholder="Enter the prompt to test with..."
                    className="w-full h-24 px-4 py-3 bg-black/40 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-yellow-500 focus:ring-2 focus:ring-yellow-500/20 resize-none disabled:opacity-50"
                  />
                  <div className="mt-2 flex justify-between items-center">
                    <div className="text-sm text-gray-400">{prompt.length} characters</div>
                    <div className="flex space-x-2">
                      {samplePrompts.map((sample, idx) => (
                        <button
                          key={idx}
                          onClick={() => setPrompt(sample)}
                          disabled={isRunning}
                          className="px-3 py-1 text-xs bg-gray-700/50 hover:bg-gray-700 rounded-lg transition-colors border border-gray-600 disabled:opacity-50"
                        >
                          Sample {idx + 1}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <div>
                  <label className="text-sm text-gray-400 mb-2 block">
                    Iterations per Provider: {iterations}
                  </label>
                  <input
                    type="range"
                    min="1"
                    max="10"
                    value={iterations}
                    onChange={e => setIterations(parseInt(e.target.value))}
                    disabled={isRunning}
                    className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer disabled:opacity-50"
                  />
                  <div className="flex justify-between text-xs text-gray-500 mt-1">
                    <span>1</span>
                    <span>5</span>
                    <span>10</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Run Button */}
            <button
              onClick={isRunning ? undefined : runBenchmark}
              disabled={!prompt.trim() || selectedProviders.length === 0}
              className="w-full py-4 bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 disabled:from-gray-700 disabled:to-gray-800 disabled:cursor-not-allowed rounded-xl font-semibold transition-all shadow-lg disabled:shadow-none flex items-center justify-center space-x-2"
            >
              {isRunning ? (
                <>
                  <RefreshCw className="w-5 h-5 animate-spin" />
                  <span>Testing... {progress.toFixed(0)}%</span>
                </>
              ) : (
                <>
                  <PlayCircle className="w-5 h-5" />
                  <span>Run Benchmark</span>
                </>
              )}
            </button>

            {/* Progress Bar */}
            {isRunning && (
              <div className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm rounded-xl border border-yellow-500/20 p-4">
                <div className="h-3 bg-gray-700 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-yellow-500 to-orange-500 transition-all duration-300"
                    style={{ width: `${progress}%` }}
                  />
                </div>
              </div>
            )}

            {/* Current Results */}
            {currentResults.length > 0 && (
              <div className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm rounded-xl border border-yellow-500/20 p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-semibold flex items-center">
                    <Activity className="w-6 h-6 text-yellow-400 mr-2" />
                    Benchmark Results
                  </h2>
                  {!isRunning && (
                    <button
                      onClick={exportResults}
                      className="p-2 bg-yellow-500/20 hover:bg-yellow-500/30 rounded-lg transition-colors border border-yellow-500/30"
                    >
                      <Download className="w-5 h-5 text-yellow-400" />
                    </button>
                  )}
                </div>

                {/* Provider Comparison Chart */}
                <div className="space-y-4 mb-6">
                  {selectedProviders.map(providerId => {
                    const provider = PROVIDERS.find(p => p.id === providerId)!;
                    const results = getResultsByProvider(providerId);
                    const avg = getProviderAverage(providerId);
                    const maxAvg = Math.max(...selectedProviders.map(id => getProviderAverage(id)));
                    const percentage = maxAvg > 0 ? (avg / maxAvg) * 100 : 0;

                    return (
                      <div key={providerId} className="space-y-2">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <span>{provider.icon}</span>
                            <span className="font-medium">{provider.name}</span>
                          </div>
                          <div className="text-right">
                            <div className="font-semibold text-yellow-400">
                              {avg > 0 ? `${avg.toFixed(0)}ms` : 'N/A'}
                            </div>
                            <div className="text-xs text-gray-400">
                              {results.length}/{iterations} successful
                            </div>
                          </div>
                        </div>
                        <div className="h-3 bg-gray-700 rounded-full overflow-hidden">
                          <div
                            className={`h-full bg-gradient-to-r from-${provider.color}-500 to-${provider.color}-600 transition-all duration-500`}
                            style={{ width: `${percentage}%` }}
                          />
                        </div>
                        {results.length > 0 && (
                          <div className="grid grid-cols-3 gap-2 text-xs text-gray-400">
                            <div>
                              TTFB:{' '}
                              {(
                                results.reduce((sum, r) => sum + r.ttfb, 0) / results.length
                              ).toFixed(0)}
                              ms
                            </div>
                            <div>
                              Tokens:{' '}
                              {(
                                results.reduce((sum, r) => sum + r.tokens, 0) / results.length
                              ).toFixed(0)}
                            </div>
                            <div>
                              Speed:{' '}
                              {(
                                results.reduce((sum, r) => sum + r.tokensPerSecond, 0) /
                                results.length
                              ).toFixed(1)}{' '}
                              t/s
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>

                {/* Detailed Results Table */}
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="border-b border-gray-700">
                      <tr>
                        <th className="text-left py-2 px-3">Provider</th>
                        <th className="text-right py-2 px-3">TTFB</th>
                        <th className="text-right py-2 px-3">Total</th>
                        <th className="text-right py-2 px-3">Tokens</th>
                        <th className="text-right py-2 px-3">Speed</th>
                        <th className="text-center py-2 px-3">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {currentResults.map(result => (
                        <tr
                          key={result.id}
                          className="border-b border-gray-800 hover:bg-gray-800/30"
                        >
                          <td className="py-2 px-3">{result.providerName}</td>
                          <td className="text-right py-2 px-3">
                            {result.status === 'success' ? `${result.ttfb.toFixed(0)}ms` : '-'}
                          </td>
                          <td className="text-right py-2 px-3 font-semibold">
                            {result.status === 'success' ? `${result.totalTime.toFixed(0)}ms` : '-'}
                          </td>
                          <td className="text-right py-2 px-3">
                            {result.status === 'success' ? result.tokens : '-'}
                          </td>
                          <td className="text-right py-2 px-3">
                            {result.status === 'success'
                              ? `${result.tokensPerSecond.toFixed(1)} t/s`
                              : '-'}
                          </td>
                          <td className="text-center py-2 px-3">
                            {result.status === 'success' ? (
                              <span className="text-green-400">✓</span>
                            ) : result.status === 'timeout' ? (
                              <span className="text-yellow-400">⏱</span>
                            ) : (
                              <span className="text-red-400">✗</span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Provider Stats */}
            {providerStats.length > 0 && (
              <div className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm rounded-xl border border-yellow-500/20 p-6">
                <h2 className="text-lg font-semibold mb-4 flex items-center">
                  <BarChart3 className="w-5 h-5 text-yellow-400 mr-2" />
                  Historical Stats
                </h2>
                <div className="space-y-4">
                  {providerStats.map(stat => {
                    const provider = PROVIDERS.find(p => p.id === stat.providerId);
                    if (!provider) return null;

                    return (
                      <div
                        key={stat.providerId}
                        className="p-4 bg-gray-800/50 rounded-lg border border-gray-700"
                      >
                        <div className="flex items-center space-x-2 mb-3">
                          <span>{provider.icon}</span>
                          <span className="font-medium text-sm">{provider.name}</span>
                        </div>
                        <div className="space-y-2 text-xs">
                          <div className="flex justify-between">
                            <span className="text-gray-400">Avg Latency:</span>
                            <span className="font-semibold">{stat.avgTotal.toFixed(0)}ms</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-400">Avg TTFB:</span>
                            <span className="font-semibold">{stat.avgTTFB.toFixed(0)}ms</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-400">Avg Speed:</span>
                            <span className="font-semibold">
                              {stat.avgTokensPerSec.toFixed(1)} t/s
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-400">P95:</span>
                            <span className="font-semibold">{stat.p95.toFixed(0)}ms</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-400">Success Rate:</span>
                            <span className="font-semibold text-green-400">
                              {stat.successRate.toFixed(1)}%
                            </span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Info Panel */}
            {showInfo && (
              <div className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm rounded-xl border border-yellow-500/20 p-6">
                <h2 className="text-lg font-semibold mb-4 flex items-center">
                  <Info className="w-5 h-5 text-yellow-400 mr-2" />
                  About Latency Testing
                </h2>
                <div className="space-y-3 text-sm text-gray-300">
                  <p>Measure and compare response times across different AI providers.</p>
                  <div>
                    <div className="font-semibold text-white mb-1">Metrics:</div>
                    <ul className="list-disc list-inside space-y-1 text-gray-400">
                      <li>
                        <strong>TTFB:</strong> Time to first byte
                      </li>
                      <li>
                        <strong>Total Time:</strong> Complete response time
                      </li>
                      <li>
                        <strong>Tokens/sec:</strong> Generation speed
                      </li>
                      <li>
                        <strong>P95/P99:</strong> 95th/99th percentile latency
                      </li>
                    </ul>
                  </div>
                  <div>
                    <div className="font-semibold text-white mb-1">Use Cases:</div>
                    <ul className="list-disc list-inside space-y-1 text-gray-400">
                      <li>Provider performance comparison</li>
                      <li>SLA compliance monitoring</li>
                      <li>Optimization & debugging</li>
                      <li>Capacity planning</li>
                    </ul>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AILabLatencyPage;
