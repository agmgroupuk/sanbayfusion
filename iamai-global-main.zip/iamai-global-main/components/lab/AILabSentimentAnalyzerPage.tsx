import React, { useState, useEffect } from 'react';
import { Page } from '../../App';
import {
  ArrowLeft,
  Activity,
  Heart,
  Smile,
  Frown,
  Meh,
  AlertTriangle,
  TrendingUp,
  TrendingDown,
  BarChart3,
  PieChart,
  Download,
  Copy,
  RefreshCw,
  MessageSquare,
  Hash,
  Clock,
  Target,
  Zap,
  Sparkles,
  Lock,
  Crown,
} from 'lucide-react';
import { aiLabService } from '../../services/aiLabService';
import { authService } from '../../services/authService';

interface AILabSentimentAnalyzerPageProps {
  onNavigate: (page: Page) => void;
}

interface SubscriptionStatus {
  hasAccess: boolean;
  type: string;
  expiresAt?: Date;
  usageToday: number;
  usageLimit: number;
  hasActiveSubscription: boolean;
}

interface EmotionScore {
  emotion: string;
  score: number;
  icon: React.ReactNode;
  color: string;
}

interface SentimentResult {
  id: string;
  text: string;
  overall: 'positive' | 'negative' | 'neutral' | 'mixed';
  confidence: number;
  emotions: EmotionScore[];
  tone: string[];
  keywords: string[];
  timestamp: number;
  metrics: {
    positivity: number;
    negativity: number;
    neutrality: number;
    subjectivity: number;
    intensity: number;
  };
}

const AILabSentimentAnalyzerPage: React.FC<AILabSentimentAnalyzerPageProps> = ({ onNavigate }) => {
  // Subscription State
  const [subscriptionStatus, setSubscriptionStatus] = useState<SubscriptionStatus>({
    hasAccess: false,
    type: 'free',
    usageToday: 0,
    usageLimit: 0,
    hasActiveSubscription: false,
  });

  // Check subscription status
  useEffect(() => {
    const checkSubscription = async () => {
      try {
        const hasActiveSubscription = false; // Set to false for testing subscription barrier
        setSubscriptionStatus({
          hasAccess: hasActiveSubscription,
          type: hasActiveSubscription ? 'premium' : 'free',
          usageToday: 0,
          usageLimit: hasActiveSubscription ? 1000 : 5,
          hasActiveSubscription,
        });
      } catch (error) {
        console.error('Error checking subscription:', error);
      }
    };
    checkSubscription();
  }, []);

  // State
  const [inputText, setInputText] = useState('');
  const [batchTexts, setBatchTexts] = useState<string[]>(['']);
  const [mode, setMode] = useState<'single' | 'batch'>('single');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<SentimentResult | null>(null);
  const [batchResults, setBatchResults] = useState<SentimentResult[]>([]);
  const [history, setHistory] = useState<SentimentResult[]>([]);

  // Sample Texts
  const sampleTexts = [
    'I absolutely love this product! It exceeded all my expectations and the customer service was outstanding.',
    "This is the worst experience I've ever had. Completely disappointed and frustrated with the service.",
    'The weather today is partly cloudy with temperatures around 72 degrees.',
    "I'm feeling cautiously optimistic about the future, though there are still some concerns.",
  ];

  // Load history
  useEffect(() => {
    try {
      const saved = localStorage.getItem('ailab_global_history');
      if (saved) {
        const allHistory = JSON.parse(saved);
        const sentimentHistory = allHistory.filter((item: any) => item.type === 'sentiment');
        setHistory(sentimentHistory.slice(-10));
      }
    } catch (e) {
      console.error('Failed to load history:', e);
    }
  }, []);

  // Analyze Sentiment
  const analyzeSentiment = async () => {
    if (mode === 'single' && !inputText.trim()) return;
    if (mode === 'batch' && batchTexts.every(t => !t.trim())) return;

    setIsAnalyzing(true);
    setResult(null);
    setBatchResults([]);

    try {
      if (mode === 'single') {
        const sentimentResult = await generateSentimentAnalysis(inputText);
        setResult(sentimentResult);
        saveToHistory(sentimentResult);
        setHistory(prev => [sentimentResult, ...prev].slice(0, 10));
      } else {
        const validTexts = batchTexts.filter(t => t.trim());
        const results = await Promise.all(validTexts.map(text => generateSentimentAnalysis(text)));
        setBatchResults(results);
        results.forEach(saveToHistory);
        setHistory(prev => [...results, ...prev].slice(0, 10));
      }
    } catch (error) {
      console.error('Error in sentiment analysis:', error);
    }

    setIsAnalyzing(false);
  };

  // Generate Sentiment Analysis using AI
  const generateSentimentAnalysis = async (text: string): Promise<SentimentResult> => {
    try {
      const result = await aiLabService.generateCompletion({
        provider: 'openai',
        model: 'gpt-4',
        prompt: `Analyze the sentiment of this text: "${text}"`,
        systemPrompt: `You are a sentiment analysis expert. Analyze the text and respond with a JSON object containing:
{
  "overall": "positive" | "negative" | "neutral" | "mixed",
  "confidence": 0.0-1.0,
  "emotions": {
    "joy": 0.0-1.0,
    "sadness": 0.0-1.0,
    "anger": 0.0-1.0,
    "fear": 0.0-1.0,
    "surprise": 0.0-1.0,
    "trust": 0.0-1.0
  },
  "tone": ["professional", "casual", "formal", etc],
  "keywords": ["word1", "word2"],
  "metrics": {
    "positivity": 0.0-1.0,
    "negativity": 0.0-1.0,
    "neutrality": 0.0-1.0,
    "subjectivity": 0.0-1.0,
    "intensity": 0.0-1.0
  }
}`,
        temperature: 0.3,
        maxTokens: 500,
      });

      if (!result.success || !result.response) {
        throw new Error(result.error || 'Failed to analyze sentiment');
      }

      // Parse AI response
      let analysisData;
      try {
        // Extract JSON from response
        const jsonMatch = result.response.match(/\{[\s\S]*\}/);
        analysisData = jsonMatch ? JSON.parse(jsonMatch[0]) : null;
      } catch (e) {
        // Fallback to simple analysis if JSON parsing fails
        analysisData = null;
      }

      // Build result with AI data or fallback
      const emotions: EmotionScore[] = [
        {
          emotion: 'Joy',
          score: analysisData?.emotions?.joy || 0.5,
          icon: <Smile className="w-4 h-4" />,
          color: 'text-yellow-400',
        },
        {
          emotion: 'Sadness',
          score: analysisData?.emotions?.sadness || 0.2,
          icon: <Frown className="w-4 h-4" />,
          color: 'text-blue-400',
        },
        {
          emotion: 'Anger',
          score: analysisData?.emotions?.anger || 0.1,
          icon: <AlertTriangle className="w-4 h-4" />,
          color: 'text-red-400',
        },
        {
          emotion: 'Fear',
          score: analysisData?.emotions?.fear || 0.1,
          icon: <AlertTriangle className="w-4 h-4" />,
          color: 'text-purple-400',
        },
        {
          emotion: 'Surprise',
          score: analysisData?.emotions?.surprise || 0.1,
          icon: <Sparkles className="w-4 h-4" />,
          color: 'text-pink-400',
        },
        {
          emotion: 'Trust',
          score: analysisData?.emotions?.trust || 0.6,
          icon: <Heart className="w-4 h-4" />,
          color: 'text-green-400',
        },
      ];

      return {
        id: `sentiment-${Date.now()}-${Math.random()}`,
        text,
        overall: analysisData?.overall || 'neutral',
        confidence: analysisData?.confidence || 0.7,
        emotions,
        tone: analysisData?.tone || ['neutral'],
        keywords: analysisData?.keywords || text.split(' ').slice(0, 5),
        timestamp: Date.now(),
        metrics: analysisData?.metrics || {
          positivity: 0.5,
          negativity: 0.2,
          neutrality: 0.3,
          subjectivity: 0.5,
          intensity: 0.5,
        },
      };
    } catch (error) {
      console.error('Error analyzing sentiment:', error);
      // Return basic fallback result on error
      return {
        id: `sentiment-${Date.now()}-${Math.random()}`,
        text,
        overall: 'neutral',
        confidence: 0.5,
        emotions: [
          {
            emotion: 'Joy',
            score: 0.5,
            icon: <Smile className="w-4 h-4" />,
            color: 'text-yellow-400',
          },
          {
            emotion: 'Sadness',
            score: 0.2,
            icon: <Frown className="w-4 h-4" />,
            color: 'text-blue-400',
          },
          {
            emotion: 'Anger',
            score: 0.1,
            icon: <AlertTriangle className="w-4 h-4" />,
            color: 'text-red-400',
          },
          {
            emotion: 'Fear',
            score: 0.1,
            icon: <AlertTriangle className="w-4 h-4" />,
            color: 'text-purple-400',
          },
          {
            emotion: 'Surprise',
            score: 0.1,
            icon: <Sparkles className="w-4 h-4" />,
            color: 'text-pink-400',
          },
          {
            emotion: 'Trust',
            score: 0.5,
            icon: <Heart className="w-4 h-4" />,
            color: 'text-green-400',
          },
        ],
        tone: ['error'],
        keywords: text.split(' ').slice(0, 5),
        timestamp: Date.now(),
        metrics: {
          positivity: 0.5,
          negativity: 0.2,
          neutrality: 0.3,
          subjectivity: 0.5,
          intensity: 0.5,
        },
      };
    }
  };

  // Save to History
  const saveToHistory = (result: SentimentResult) => {
    try {
      const saved = localStorage.getItem('ailab_global_history') || '[]';
      const history = JSON.parse(saved);
      history.push({ type: 'sentiment', ...result });
      localStorage.setItem('ailab_global_history', JSON.stringify(history));
    } catch (e) {
      console.error('Failed to save:', e);
    }
  };

  // Add Batch Text Field
  const addBatchField = () => {
    setBatchTexts([...batchTexts, '']);
  };

  // Update Batch Text
  const updateBatchText = (index: number, value: string) => {
    const updated = [...batchTexts];
    updated[index] = value;
    setBatchTexts(updated);
  };

  // Remove Batch Field
  const removeBatchField = (index: number) => {
    if (batchTexts.length > 1) {
      setBatchTexts(batchTexts.filter((_, i) => i !== index));
    }
  };

  // Get Overall Color
  const getOverallColor = (overall: string) => {
    switch (overall) {
      case 'positive':
        return 'text-green-400';
      case 'negative':
        return 'text-red-400';
      case 'neutral':
        return 'text-gray-400';
      case 'mixed':
        return 'text-yellow-400';
      default:
        return 'text-gray-400';
    }
  };

  // Get Overall Icon
  const getOverallIcon = (overall: string) => {
    switch (overall) {
      case 'positive':
        return <Smile className="w-8 h-8" />;
      case 'negative':
        return <Frown className="w-8 h-8" />;
      case 'neutral':
        return <Meh className="w-8 h-8" />;
      case 'mixed':
        return <Activity className="w-8 h-8" />;
      default:
        return <Activity className="w-8 h-8" />;
    }
  };

  // Copy Result
  const copyResult = () => {
    if (!result) return;
    const text = `Sentiment: ${result.overall} (${(result.confidence * 100).toFixed(0)}%)\nEmotions: ${result.emotions.map(e => `${e.emotion}: ${(e.score * 100).toFixed(0)}%`).join(', ')}`;
    navigator.clipboard.writeText(text);
  };

  // Download Results
  const downloadResults = () => {
    const data = mode === 'single' && result ? [result] : batchResults;
    const json = JSON.stringify(data, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `sentiment-analysis-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-black text-white pb-20 relative">
      {/* Subscription Access Barrier */}
      {!subscriptionStatus.hasActiveSubscription && (
        <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-gray-900 border border-gray-800 rounded-2xl p-8 max-w-md w-full text-center">
            <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-green-500 to-emerald-600 rounded-full flex items-center justify-center">
              <Crown className="w-8 h-8 text-black" />
            </div>
            <h2 className="text-2xl font-bold text-white mb-3">Sentiment Lab Access Required</h2>
            <p className="text-gray-400 mb-6">
              AI Sentiment Analysis & Emotion Detection is a premium feature. Subscribe to unlock
              advanced sentiment analysis and real-time emotion detection capabilities.
            </p>
            <div className="flex flex-col gap-3 mb-6">
              <div className="flex items-center gap-2 text-sm text-gray-300">
                <Lock className="w-4 h-4 text-green-400" />
                <span>Advanced emotion detection algorithms</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-300">
                <Activity className="w-4 h-4 text-emerald-400" />
                <span>Real-time sentiment scoring</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-300">
                <Heart className="w-4 h-4 text-green-400" />
                <span>Batch processing & analytics</span>
              </div>
            </div>
            <div className="flex flex-col sm:flex-row gap-3">
              <button
                onClick={() => onNavigate('subscription' as Page)}
                className="flex-1 bg-gradient-to-r from-green-600 to-emerald-600 text-white px-6 py-3 rounded-lg font-semibold hover:from-green-500 hover:to-emerald-500 transition-all flex items-center justify-center gap-2"
              >
                <Crown className="w-4 h-4" />
                Subscribe Now
              </button>
              <button
                onClick={() => onNavigate('ai-lab' as Page)}
                className="flex-1 bg-gray-800 hover:bg-gray-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors"
              >
                Back to Lab
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="sticky top-0 z-40 bg-black/95 backdrop-blur-xl border-b border-gray-800">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={() => onNavigate('ai-lab' as Page)}
                className="p-2 hover:bg-gray-800 rounded-lg transition-colors"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
              <div>
                <h1 className="text-2xl font-bold text-white flex items-center gap-2">
                  <Activity className="w-6 h-6 text-pink-400" />
                  Sentiment Analyzer
                </h1>
                <p className="text-sm text-gray-400">
                  Real-time emotion detection and tone analysis
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-6 py-8">
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Left Column - Input */}
          <div className="lg:col-span-2 space-y-6">
            {/* Mode Toggle */}
            <div className="flex gap-3">
              <button
                onClick={() => setMode('single')}
                className={`flex-1 px-4 py-3 rounded-lg border-2 transition-all ${
                  mode === 'single'
                    ? 'bg-cyan-500 border-cyan-500 text-white'
                    : 'bg-gray-900/50 border-gray-800 text-gray-400 hover:border-gray-700'
                }`}
              >
                <MessageSquare className="w-5 h-5 mx-auto mb-1" />
                <span className="text-sm font-semibold">Single Analysis</span>
              </button>
              <button
                onClick={() => setMode('batch')}
                className={`flex-1 px-4 py-3 rounded-lg border-2 transition-all ${
                  mode === 'batch'
                    ? 'bg-cyan-500 border-cyan-500 text-white'
                    : 'bg-gray-900/50 border-gray-800 text-gray-400 hover:border-gray-700'
                }`}
              >
                <BarChart3 className="w-5 h-5 mx-auto mb-1" />
                <span className="text-sm font-semibold">Batch Processing</span>
              </button>
            </div>

            {/* Input Section */}
            <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-6">
              <h3 className="text-lg font-semibold text-white mb-4">
                {mode === 'single' ? 'Enter Text to Analyze' : 'Batch Text Analysis'}
              </h3>

              {mode === 'single' ? (
                <>
                  <textarea
                    value={inputText}
                    onChange={e => setInputText(e.target.value)}
                    placeholder="Enter text for sentiment analysis..."
                    className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-cyan-500 resize-none min-h-[150px] mb-4"
                  />

                  {/* Sample Texts */}
                  <div>
                    <p className="text-xs text-gray-400 mb-2">Quick Samples:</p>
                    <div className="grid grid-cols-2 gap-2">
                      {sampleTexts.map((sample, i) => (
                        <button
                          key={i}
                          onClick={() => setInputText(sample)}
                          className="px-3 py-2 bg-gray-800 hover:bg-gray-700 border border-gray-700 rounded-lg text-xs text-left text-gray-300 transition-colors line-clamp-2"
                        >
                          {sample}
                        </button>
                      ))}
                    </div>
                  </div>
                </>
              ) : (
                <>
                  <div className="space-y-3 mb-4">
                    {batchTexts.map((text, index) => (
                      <div key={index} className="flex gap-2">
                        <input
                          type="text"
                          value={text}
                          onChange={e => updateBatchText(index, e.target.value)}
                          placeholder={`Text ${index + 1}...`}
                          className="flex-1 bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                        />
                        {batchTexts.length > 1 && (
                          <button
                            onClick={() => removeBatchField(index)}
                            className="px-3 py-2 bg-red-500/20 hover:bg-red-500/30 border border-red-500/50 text-red-400 rounded-lg transition-colors"
                          >
                            Remove
                          </button>
                        )}
                      </div>
                    ))}
                  </div>

                  <button
                    onClick={addBatchField}
                    className="w-full px-4 py-2 bg-gray-800 hover:bg-gray-700 border border-gray-700 rounded-lg text-cyan-400 transition-colors"
                  >
                    + Add Text Field
                  </button>
                </>
              )}
            </div>

            {/* Analyze Button */}
            <button
              onClick={analyzeSentiment}
              disabled={
                isAnalyzing ||
                (mode === 'single' ? !inputText.trim() : batchTexts.every(t => !t.trim()))
              }
              className="w-full py-4 bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500 disabled:from-gray-700 disabled:to-gray-700 text-white font-bold text-lg rounded-xl shadow-lg transition-all disabled:cursor-not-allowed flex items-center justify-center gap-3"
            >
              {isAnalyzing ? (
                <>
                  <RefreshCw className="w-6 h-6 animate-spin" />
                  Analyzing...
                </>
              ) : (
                <>
                  <Activity className="w-6 h-6" />
                  Analyze Sentiment
                </>
              )}
            </button>

            {/* Single Result */}
            {result && mode === 'single' && (
              <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-6">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-lg font-semibold text-white">Analysis Results</h3>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={copyResult}
                      className="p-2 bg-gray-800 hover:bg-gray-700 rounded-lg transition-colors"
                      title="Copy"
                    >
                      <Copy className="w-4 h-4" />
                    </button>
                    <button
                      onClick={downloadResults}
                      className="p-2 bg-gray-800 hover:bg-gray-700 rounded-lg transition-colors"
                      title="Download"
                    >
                      <Download className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Overall Sentiment */}
                <div className="flex items-center justify-center gap-4 mb-6 p-6 bg-gray-800/50 rounded-lg">
                  <div className={getOverallColor(result.overall)}>
                    {getOverallIcon(result.overall)}
                  </div>
                  <div>
                    <p className="text-3xl font-bold text-white capitalize">{result.overall}</p>
                    <p className="text-sm text-gray-400">
                      Confidence: {(result.confidence * 100).toFixed(0)}%
                    </p>
                  </div>
                </div>

                {/* Emotion Radar Chart (simplified visualization) */}
                <div className="mb-6">
                  <h4 className="text-sm font-semibold text-gray-400 mb-3">Emotion Distribution</h4>
                  <div className="space-y-3">
                    {result.emotions.map(emotion => (
                      <div key={emotion.emotion}>
                        <div className="flex items-center justify-between mb-1">
                          <div className="flex items-center gap-2">
                            <span className={emotion.color}>{emotion.icon}</span>
                            <span className="text-sm text-white">{emotion.emotion}</span>
                          </div>
                          <span className="text-sm text-gray-400">
                            {(emotion.score * 100).toFixed(0)}%
                          </span>
                        </div>
                        <div className="w-full bg-gray-800 rounded-full h-2">
                          <div
                            className={`h-2 rounded-full bg-gradient-to-r ${
                              emotion.emotion === 'Joy'
                                ? 'from-yellow-500 to-orange-500'
                                : emotion.emotion === 'Sadness'
                                  ? 'from-blue-500 to-cyan-500'
                                  : emotion.emotion === 'Anger'
                                    ? 'from-red-500 to-orange-500'
                                    : emotion.emotion === 'Fear'
                                      ? 'from-purple-500 to-pink-500'
                                      : emotion.emotion === 'Surprise'
                                        ? 'from-pink-500 to-rose-500'
                                        : 'from-green-500 to-teal-500'
                            }`}
                            style={{ width: `${emotion.score * 100}%` }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Metrics */}
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-6">
                  <div className="p-3 bg-gray-800/50 rounded-lg">
                    <p className="text-xs text-gray-400 mb-1">Positivity</p>
                    <p className="text-lg font-bold text-green-400">
                      {(result.metrics.positivity * 100).toFixed(0)}%
                    </p>
                  </div>
                  <div className="p-3 bg-gray-800/50 rounded-lg">
                    <p className="text-xs text-gray-400 mb-1">Negativity</p>
                    <p className="text-lg font-bold text-red-400">
                      {(result.metrics.negativity * 100).toFixed(0)}%
                    </p>
                  </div>
                  <div className="p-3 bg-gray-800/50 rounded-lg">
                    <p className="text-xs text-gray-400 mb-1">Neutrality</p>
                    <p className="text-lg font-bold text-gray-400">
                      {(result.metrics.neutrality * 100).toFixed(0)}%
                    </p>
                  </div>
                  <div className="p-3 bg-gray-800/50 rounded-lg">
                    <p className="text-xs text-gray-400 mb-1">Subjectivity</p>
                    <p className="text-lg font-bold text-cyan-400">
                      {(result.metrics.subjectivity * 100).toFixed(0)}%
                    </p>
                  </div>
                  <div className="p-3 bg-gray-800/50 rounded-lg">
                    <p className="text-xs text-gray-400 mb-1">Intensity</p>
                    <p className="text-lg font-bold text-purple-400">
                      {(result.metrics.intensity * 100).toFixed(0)}%
                    </p>
                  </div>
                  <div className="p-3 bg-gray-800/50 rounded-lg">
                    <p className="text-xs text-gray-400 mb-1">Characters</p>
                    <p className="text-lg font-bold text-white">{result.text.length}</p>
                  </div>
                </div>

                {/* Tone & Keywords */}
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm font-semibold text-gray-400 mb-2">Detected Tones</p>
                    <div className="flex flex-wrap gap-2">
                      {result.tone.map((t, i) => (
                        <span
                          key={i}
                          className="px-3 py-1 bg-purple-500/20 text-purple-400 text-xs rounded-full"
                        >
                          {t}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-gray-400 mb-2">Key Terms</p>
                    <div className="flex flex-wrap gap-2">
                      {result.keywords.map((k, i) => (
                        <span
                          key={i}
                          className="px-3 py-1 bg-cyan-500/20 text-cyan-400 text-xs rounded-full"
                        >
                          {k}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Batch Results */}
            {batchResults.length > 0 && mode === 'batch' && (
              <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-white">
                    Batch Results ({batchResults.length})
                  </h3>
                  <button
                    onClick={downloadResults}
                    className="px-3 py-2 bg-cyan-600 hover:bg-cyan-500 rounded-lg transition-colors flex items-center gap-2"
                  >
                    <Download className="w-4 h-4" />
                    Export
                  </button>
                </div>

                <div className="space-y-3">
                  {batchResults.map((res, index) => (
                    <div
                      key={res.id}
                      className="p-4 bg-gray-800/50 border border-gray-700 rounded-lg"
                    >
                      <div className="flex items-start justify-between mb-2">
                        <p className="text-sm text-gray-300 flex-1 line-clamp-2">{res.text}</p>
                        <div
                          className={`ml-3 flex items-center gap-2 ${getOverallColor(res.overall)}`}
                        >
                          {getOverallIcon(res.overall)}
                          <span className="font-bold capitalize">{res.overall}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-4 text-xs text-gray-500">
                        <span>Confidence: {(res.confidence * 100).toFixed(0)}%</span>
                        <span>•</span>
                        <span>Positivity: {(res.metrics.positivity * 100).toFixed(0)}%</span>
                        <span>•</span>
                        <span>Negativity: {(res.metrics.negativity * 100).toFixed(0)}%</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Right Column - Info & History */}
          <div className="lg:col-span-1 space-y-6">
            {/* Info Panel */}
            <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-6 sticky top-24">
              <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                <Target className="w-5 h-5 text-cyan-400" />
                About Sentiment Analysis
              </h3>

              <div className="space-y-4 text-sm text-gray-300">
                <div>
                  <p className="font-semibold text-white mb-1">What it does:</p>
                  <p className="text-xs">
                    Analyzes text to identify emotional tone, sentiment polarity, and underlying
                    emotions.
                  </p>
                </div>

                <div>
                  <p className="font-semibold text-white mb-1">Sentiment Categories:</p>
                  <div className="space-y-1 text-xs">
                    <p>
                      <Smile className="w-3 h-3 inline text-green-400" />{' '}
                      <span className="text-green-400">Positive</span> - Favorable, happy tone
                    </p>
                    <p>
                      <Frown className="w-3 h-3 inline text-red-400" />{' '}
                      <span className="text-red-400">Negative</span> - Unfavorable, critical tone
                    </p>
                    <p>
                      <Meh className="w-3 h-3 inline text-gray-400" />{' '}
                      <span className="text-gray-400">Neutral</span> - Objective, factual tone
                    </p>
                    <p>
                      <Activity className="w-3 h-3 inline text-yellow-400" />{' '}
                      <span className="text-yellow-400">Mixed</span> - Complex, ambiguous tone
                    </p>
                  </div>
                </div>

                <div>
                  <p className="font-semibold text-white mb-1">Use Cases:</p>
                  <ul className="space-y-1 text-xs list-disc list-inside">
                    <li>Customer feedback analysis</li>
                    <li>Social media monitoring</li>
                    <li>Product review insights</li>
                    <li>Brand sentiment tracking</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Recent History */}
            {history.length > 0 && (
              <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-6">
                <h3 className="text-lg font-semibold text-white mb-4">Recent Analyses</h3>
                <div className="space-y-3">
                  {history.slice(0, 5).map(item => (
                    <div
                      key={item.id}
                      className="p-3 bg-gray-800/50 border border-gray-700 rounded-lg text-xs"
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className={`font-bold capitalize ${getOverallColor(item.overall)}`}>
                          {item.overall}
                        </span>
                        <span className="text-gray-500">{(item.confidence * 100).toFixed(0)}%</span>
                      </div>
                      <p className="text-gray-400 line-clamp-2">{item.text}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AILabSentimentAnalyzerPage;
