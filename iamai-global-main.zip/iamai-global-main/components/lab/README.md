# AI Lab Components

This folder contains all AI Lab feature pages organized in a clean, scalable structure.

## Structure

```
components/lab/
├── index.ts                    # Central exports for all lab pages
├── AILabHubPage.tsx           # Main landing page with feature grid
├── AILabPlaygroundPage.tsx    # Multi-model comparison tool
├── AILabPromptPage.tsx        # Prompt engineering lab
└── [future pages...]          # Battle Arena, Transformers, etc.
```

## Usage

All lab pages are exported through `index.ts` for clean imports in `App.tsx`:

```tsx
import { AILabHubPage, AILabPlaygroundPage, AILabPromptPage } from './components/lab';
```

## Routes

| Page | Route | Status |
|------|-------|--------|
| AI Lab Hub | `/ai-lab` | ✅ Live |
| Multi-Model Playground | `/ai-lab-playground` | ✅ Live |
| Prompt Engineering Lab | `/ai-lab-prompt` | ✅ Live |
| AI Battle Arena | `/ai-lab-battle` | 🔄 Planned |
| Text Transformers | `/ai-lab-transformers` | 🔄 Planned |
| Code Playground | `/ai-lab-code` | 🔄 Planned |
| Sentiment Analyzer | `/ai-lab-sentiment` | 🔄 Planned |
| Token & Cost Calculator | `/ai-lab-cost` | 🔄 Planned |
| Latency Benchmarking | `/ai-lab-benchmark` | 🔄 Planned |
| Experiment History | `/ai-lab-history` | 🔄 Planned |
| Shannon Research | `/ai-lab-research` | 🔄 Planned |
| API Settings | `/ai-lab-settings` | 🔄 Planned |
| Template Library | `/ai-lab-templates` | 🔄 Planned |

## Component Guidelines

Each lab page should:
1. Accept `onNavigate: (page: Page) => void` prop
2. Include back button to AI Lab hub
3. Save experiments to localStorage history
4. Follow cyan/black theme
5. Be mobile-responsive
6. Include loading states for async operations

## Adding New Pages

1. Create new page component in this folder
2. Export it in `index.ts`
3. Add route to `Page` type in `App.tsx`
4. Add to `validPages` array
5. Add routing case in `renderPage()` (both public and authenticated)
6. Update this README

## Features

### ✅ Completed
- **AI Lab Hub**: Feature grid, stats, category filters
- **Multi-Model Playground**: Side-by-side AI comparison with GPT-4, Claude, Gemini, Mistral
- **Prompt Engineering Lab**: Template library, parameter tuning, best practices

### 🔄 In Progress
- AI Battle Arena
- Text Transformers
- Code Playground
- Sentiment Analyzer
- Token Calculator
- Latency Benchmarking
- History & Analytics
- Shannon Research Tools
- API Key Management
- Template Sharing

## Development Notes

- All pages use mock AI responses (real API integration pending)
- History saved to `localStorage` under `ailab_global_history`
- Cost calculations based on approximate token pricing
- Token estimation: ~4 characters per token
