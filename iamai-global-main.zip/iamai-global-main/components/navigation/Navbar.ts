import { Agent } from '../../constants';

export interface NavbarState {
  user: any;
  isMenuOpen: boolean;
  activeSection: string;
  agents: Agent[];
  notifications: Notification[];
  theme: any;
}

export interface NavbarNotification {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
  timestamp: Date;
  read: boolean;
}

export class NavbarService {
  private listeners: Set<(state: NavbarState) => void> = new Set();
  private state: NavbarState;

  constructor(user: any, agents: Agent[], theme: any) {
    this.state = {
      user,
      isMenuOpen: false,
      activeSection: 'dashboard',
      agents,
      notifications: [],
      theme,
    };

    this.loadNotifications();
  }

  private loadNotifications(): void {
    try {
      const stored = localStorage.getItem('navbar_notifications');
      if (stored) {
        const notifications = JSON.parse(stored).map((n: any) => ({
          ...n,
          timestamp: new Date(n.timestamp),
        }));
        this.updateState({ ...this.state, notifications });
      }
    } catch (error) {
      console.error('Failed to load notifications:', error);
    }
  }

  private saveNotifications(): void {
    try {
      localStorage.setItem('navbar_notifications', JSON.stringify(this.state.notifications));
    } catch (error) {
      console.error('Failed to save notifications:', error);
    }
  }

  toggleMenu(): void {
    this.updateState({
      ...this.state,
      isMenuOpen: !this.state.isMenuOpen,
    });
  }

  closeMenu(): void {
    this.updateState({
      ...this.state,
      isMenuOpen: false,
    });
  }

  setActiveSection(section: string): void {
    this.updateState({
      ...this.state,
      activeSection: section,
      isMenuOpen: false,
    });
  }

  addNotification(notification: Omit<NavbarNotification, 'id' | 'timestamp' | 'read'>): void {
    const newNotification: NavbarNotification = {
      ...notification,
      id: Date.now().toString(),
      timestamp: new Date(),
      read: false,
    };

    const notifications = [newNotification, ...this.state.notifications].slice(0, 50); // Keep max 50
    this.updateState({ ...this.state, notifications });
    this.saveNotifications();
  }

  markNotificationRead(id: string): void {
    const notifications = this.state.notifications.map(n =>
      n.id === id ? { ...n, read: true } : n
    );
    this.updateState({ ...this.state, notifications });
    this.saveNotifications();
  }

  clearNotification(id: string): void {
    const notifications = this.state.notifications.filter(n => n.id !== id);
    this.updateState({ ...this.state, notifications });
    this.saveNotifications();
  }

  clearAllNotifications(): void {
    this.updateState({ ...this.state, notifications: [] });
    this.saveNotifications();
  }

  getUnreadCount(): number {
    return this.state.notifications.filter(n => !n.read).length;
  }

  getRecentNotifications(limit: number = 5): NavbarNotification[] {
    return this.state.notifications
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, limit);
  }

  updateUser(user: any): void {
    this.updateState({ ...this.state, user });
  }

  updateTheme(theme: any): void {
    this.updateState({ ...this.state, theme });
  }

  getNavItems(): Array<{ name: string; path: string; icon: string; active: boolean }> {
    const baseItems = [
      { name: 'Dashboard', path: '/dashboard', icon: 'dashboard' },
      { name: 'AI Agents', path: '/agents', icon: 'psychology' },
      { name: 'AI Lab', path: '/ai-lab', icon: 'science' },
      { name: 'Analytics', path: '/analytics', icon: 'analytics' },
      { name: 'Settings', path: '/settings', icon: 'settings' },
    ];

    return baseItems.map(item => ({
      ...item,
      active: this.isActive(item.path),
    }));
  }

  getAgentNavItems(): Array<{ agent: Agent; active: boolean }> {
    return this.state.agents.map(agent => ({
      agent,
      active: this.state.activeSection === agent.name.toLowerCase(),
    }));
  }

  private isActive(path: string): boolean {
    // Simple path matching - could be enhanced
    const section = path.replace('/', '').toLowerCase();
    return this.state.activeSection === section;
  }

  getUserInitials(): string {
    if (!this.state.user?.name) return 'U';

    const parts = this.state.user.name.split(' ');
    if (parts.length >= 2) {
      return (parts[0][0] + parts[1][0]).toUpperCase();
    }
    return this.state.user.name[0].toUpperCase();
  }

  getUserDisplayName(): string {
    return this.state.user?.name || this.state.user?.email || 'User';
  }

  getState(): NavbarState {
    return { ...this.state };
  }

  subscribe(listener: (state: NavbarState) => void): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private updateState(newState: NavbarState): void {
    this.state = newState;
    this.listeners.forEach(listener => listener(this.state));
  }

  destroy(): void {
    this.listeners.clear();
  }
}
