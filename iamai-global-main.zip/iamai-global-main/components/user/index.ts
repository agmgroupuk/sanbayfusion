/**
 * 👤 User Components - Centralized Exports
 * Unified access to all user-related components including dashboard, account, and settings
 */

// Dashboard Components
export { default as Dashboard } from './dashboard/Dashboard';
export { default as Sidebar } from './dashboard/Sidebar';
export { default as AgentPage } from './dashboard/AgentPage';
export { default as DashboardFilePreview } from './dashboard/DashboardFilePreview';
export { default as AgentProfilePage } from './dashboard/AgentProfilePage';
export { default as AgentManagementPage } from './dashboard/AgentManagementPage';
export { default as AgentFormPage } from './dashboard/AgentFormPage';
export { default as SettingsModal } from './dashboard/SettingsModal';
export { default as OnboardingTutorial } from './dashboard/OnboardingTutorial';
export { default as GlobalSearch } from './dashboard/GlobalSearch';
export { default as ChatArea } from './dashboard/ChatArea';
export { default as ThemeSwitcher } from './dashboard/ThemeSwitcher';
export { default as AchievementSystem } from './dashboard/AchievementSystem';
export { default as LiveActivityFeed } from './dashboard/LiveActivityFeed';
export { default as NotificationCenter } from './dashboard/NotificationCenter';

// Account Components
export { default as ProfileSection } from './account/ProfileSection';
export { default as BillingHistorySection } from './account/BillingHistorySection';
export { default as SubscriptionsSection } from './account/SubscriptionsSection';
export { default as UsageAnalyticsSection } from './account/UsageAnalyticsSection';
export { default as AccountSecurity } from './account/AccountSecurity';
export { default as AccountSettings } from './account/AccountSettings';
export { default as OverviewSection } from './account/OverviewSection';

// Services
export { dashboardStorage } from '../../services/user/dashboardStorage';
export { settingsService } from '../../services/user/settingsService';

// Type exports for dashboard views
export type { DashboardView } from './dashboard/types';
