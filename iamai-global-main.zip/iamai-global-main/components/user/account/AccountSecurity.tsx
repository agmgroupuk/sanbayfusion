import React, { useState, useEffect } from 'react';
import { authService } from '../../../services/authService';

interface TwoFactorSetup {
  qrCode: string;
  secret: string;
  backupCodes: string[];
}

interface Session {
  sessionId: string;
  browser: string;
  os: string;
  device: string;
  location: { country: string; city: string };
  lastActive: string;
  isCurrent: boolean;
}

interface SecurityOverview {
  twoFactorEnabled: boolean;
  backupCodesCount: number;
  lastPasswordChange: string;
  activeSessions: number;
  emailChangeRequest?: {
    newEmail: string;
    expiresAt: string;
  };
  notifications: {
    email: boolean;
    sms: boolean;
  };
  lastLoginAt?: string;
  lastLoginIP?: string;
}

const AccountSecurity: React.FC = () => {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [securityOverview, setSecurityOverview] = useState<SecurityOverview | null>(null);
  const [sessions, setSessions] = useState<Session[]>([]);

  const [show2FASetup, setShow2FASetup] = useState(false);
  const [twoFactorSetup, setTwoFactorSetup] = useState<TwoFactorSetup | null>(null);
  const [verificationCode, setVerificationCode] = useState('');
  const [backupCodesDownloaded, setBackupCodesDownloaded] = useState(false);

  const [showPasswordChange, setShowPasswordChange] = useState(false);
  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  });

  const [showEmailChange, setShowEmailChange] = useState(false);
  const [emailData, setEmailData] = useState({
    newEmail: '',
    currentPassword: '',
  });

  const [notificationSettings, setNotificationSettings] = useState({
    email: true,
    sms: false,
  });

  const fetchSecurityOverview = async () => {
    try {
      setLoading(true);
      const response = await authService.authenticatedFetch('/api/users/security/overview');
      if (response.ok) {
        const data = await response.json();
        setSecurityOverview(data);
        setNotificationSettings(data.notifications);
      }
    } catch (error) {
      console.error('Error fetching security overview:', error);
      setError('Failed to load security information');
    } finally {
      setLoading(false);
    }
  };

  const fetchSessions = async () => {
    try {
      const response = await authService.authenticatedFetch('/api/users/security/sessions');
      if (response.ok) {
        const data = await response.json();
        setSessions(data);
      }
    } catch (error) {
      console.error('Error fetching sessions:', error);
    }
  };

  const initialize2FASetup = async () => {
    try {
      setSaving(true);
      setError('');
      const response = await authService.authenticatedFetch('/api/users/security/2fa/setup', {
        method: 'POST',
      });

      if (response.ok) {
        const data = await response.json();
        setTwoFactorSetup(data);
        setShow2FASetup(true);
      } else {
        const errorData = await response.json();
        setError(errorData.message);
      }
    } catch (error) {
      setError('Failed to initialize 2FA setup');
    } finally {
      setSaving(false);
    }
  };

  const verify2FA = async () => {
    try {
      setSaving(true);
      setError('');

      const response = await authService.authenticatedFetch('/api/users/security/2fa/verify', {
        method: 'POST',
        body: JSON.stringify({
          code: verificationCode,
          backupCodes: twoFactorSetup?.backupCodes,
        }),
      });

      if (response.ok) {
        setSuccess('2FA enabled successfully!');
        setShow2FASetup(false);
        setVerificationCode('');
        setTwoFactorSetup(null);
        await fetchSecurityOverview();
      } else {
        const errorData = await response.json();
        setError(errorData.message);
      }
    } catch (error) {
      setError('Failed to verify 2FA code');
    } finally {
      setSaving(false);
    }
  };

  const disable2FA = async () => {
    const currentPassword = prompt('Enter your current password to disable 2FA:');
    if (!currentPassword) return;

    try {
      setSaving(true);
      setError('');

      const response = await authService.authenticatedFetch('/api/users/security/2fa/disable', {
        method: 'POST',
        body: JSON.stringify({ currentPassword }),
      });

      if (response.ok) {
        setSuccess('2FA disabled successfully');
        await fetchSecurityOverview();
      } else {
        const errorData = await response.json();
        setError(errorData.message);
      }
    } catch (error) {
      setError('Failed to disable 2FA');
    } finally {
      setSaving(false);
    }
  };

  const changePassword = async () => {
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      setError('New passwords do not match');
      return;
    }

    try {
      setSaving(true);
      setError('');

      const response = await authService.authenticatedFetch('/api/users/security/password/change', {
        method: 'POST',
        body: JSON.stringify({
          currentPassword: passwordData.currentPassword,
          newPassword: passwordData.newPassword,
        }),
      });

      if (response.ok) {
        setSuccess('Password changed successfully');
        setShowPasswordChange(false);
        setPasswordData({ currentPassword: '', newPassword: '', confirmPassword: '' });
        await fetchSecurityOverview();
      } else {
        const errorData = await response.json();
        setError(errorData.message);
      }
    } catch (error) {
      setError('Failed to change password');
    } finally {
      setSaving(false);
    }
  };

  const requestEmailChange = async () => {
    try {
      setSaving(true);
      setError('');

      const response = await authService.authenticatedFetch(
        '/api/users/security/email/request-change',
        {
          method: 'POST',
          body: JSON.stringify(emailData),
        }
      );

      if (response.ok) {
        setSuccess('Email change verification sent to your new email address');
        setShowEmailChange(false);
        setEmailData({ newEmail: '', currentPassword: '' });
        await fetchSecurityOverview();
      } else {
        const errorData = await response.json();
        setError(errorData.message);
      }
    } catch (error) {
      setError('Failed to request email change');
    } finally {
      setSaving(false);
    }
  };

  const terminateSessions = async (sessionIds?: string[], terminateAll = false) => {
    try {
      setSaving(true);
      setError('');

      const response = await authService.authenticatedFetch(
        '/api/users/security/sessions/terminate',
        {
          method: 'POST',
          body: JSON.stringify({ sessionIds, terminateAll }),
        }
      );

      if (response.ok) {
        setSuccess(terminateAll ? 'All other sessions terminated' : 'Selected sessions terminated');
        await Promise.all([fetchSessions(), fetchSecurityOverview()]);
      } else {
        const errorData = await response.json();
        setError(errorData.message);
      }
    } catch (error) {
      setError('Failed to terminate sessions');
    } finally {
      setSaving(false);
    }
  };

  const updateNotifications = async (settings: { email?: boolean; sms?: boolean }) => {
    try {
      setSaving(true);
      setError('');

      const response = await authService.authenticatedFetch('/api/users/security/notifications', {
        method: 'PUT',
        body: JSON.stringify(settings),
      });

      if (response.ok) {
        const data = await response.json();
        setNotificationSettings(data.notifications);
        setSuccess('Notification settings updated');
      } else {
        const errorData = await response.json();
        setError(errorData.message);
      }
    } catch (error) {
      setError('Failed to update notification settings');
    } finally {
      setSaving(false);
    }
  };

  const downloadBackupCodes = () => {
    if (!twoFactorSetup?.backupCodes) return;

    const content = `IAMAI Global - 2FA Backup Codes\n\nGenerated: ${new Date().toLocaleString()}\n\n${twoFactorSetup.backupCodes.join('\n')}\n\nStore these codes securely. Each code can only be used once.`;
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'iamai-backup-codes.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    setBackupCodesDownloaded(true);
  };

  useEffect(() => {
    fetchSecurityOverview();
    fetchSessions();
  }, []);

  useEffect(() => {
    if (error || success) {
      const timer = setTimeout(() => {
        setError('');
        setSuccess('');
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [error, success]);

  if (loading) {
    return (
      <div className="min-h-screen bg-[var(--color-background)] flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[var(--color-primary)] mx-auto mb-4"></div>
          <p className="text-[var(--color-text-secondary)]">Loading security settings...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[var(--color-background)] p-6">
      <div className="max-w-6xl mx-auto space-y-8">
        {error && (
          <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-4 text-red-500">
            <i className="fas fa-exclamation-triangle mr-2"></i>
            {error}
          </div>
        )}

        {success && (
          <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-4 text-green-500">
            <i className="fas fa-check-circle mr-2"></i>
            {success}
          </div>
        )}

        {securityOverview && (
          <div className="bg-[var(--color-surface)] rounded-lg border border-[var(--color-border)] p-6">
            <h2 className="text-xl font-bold text-[var(--color-text)] mb-4 flex items-center">
              <i className="fas fa-shield-alt text-[var(--color-primary)] mr-3"></i>
              Security Overview
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="text-2xl font-bold text-[var(--color-primary)]">
                  {securityOverview.activeSessions}
                </div>
                <div className="text-sm text-[var(--color-text-secondary)]">Active Sessions</div>
              </div>
              <div className="text-center">
                <div
                  className={`text-2xl font-bold ${securityOverview.twoFactorEnabled ? 'text-green-500' : 'text-red-500'}`}
                >
                  {securityOverview.twoFactorEnabled ? 'Enabled' : 'Disabled'}
                </div>
                <div className="text-sm text-[var(--color-text-secondary)]">Two-Factor Auth</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-[var(--color-primary)]">
                  {securityOverview.backupCodesCount}
                </div>
                <div className="text-sm text-[var(--color-text-secondary)]">Backup Codes</div>
              </div>
              <div className="text-center">
                <div className="text-sm text-[var(--color-text-secondary)]">Last Login</div>
                <div className="text-sm font-medium text-[var(--color-text)]">
                  {securityOverview.lastLoginAt
                    ? new Date(securityOverview.lastLoginAt).toLocaleDateString()
                    : 'Never'}
                </div>
              </div>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="bg-[var(--color-surface)] rounded-lg border border-[var(--color-border)] p-6">
            <h3 className="text-lg font-bold text-[var(--color-text)] mb-4 flex items-center">
              <i className="fas fa-user-lock text-[var(--color-primary)] mr-3"></i>
              Account Credentials
            </h3>

            <div className="space-y-4 mb-6">
              <div className="flex items-center justify-between p-4 bg-[var(--color-background)] rounded-lg border border-[var(--color-border)]">
                <div>
                  <h4 className="font-medium text-[var(--color-text)]">Email Address</h4>
                  <p className="text-sm text-[var(--color-text-secondary)]">
                    Update your account email address
                  </p>
                  {securityOverview?.emailChangeRequest && (
                    <p className="text-xs text-yellow-500 mt-1">
                      Pending verification for: {securityOverview.emailChangeRequest.newEmail}
                    </p>
                  )}
                </div>
                <button
                  onClick={() => setShowEmailChange(true)}
                  className="px-4 py-2 bg-[var(--color-primary)] text-white rounded-lg hover:bg-[var(--color-primary)]/80 disabled:opacity-50"
                  disabled={saving}
                >
                  Change Email
                </button>
              </div>

              <div className="flex items-center justify-between p-4 bg-[var(--color-background)] rounded-lg border border-[var(--color-border)]">
                <div>
                  <h4 className="font-medium text-[var(--color-text)]">Password</h4>
                  <p className="text-sm text-[var(--color-text-secondary)]">
                    Last changed:{' '}
                    {securityOverview?.lastPasswordChange
                      ? new Date(securityOverview.lastPasswordChange).toLocaleDateString()
                      : 'Never'}
                  </p>
                </div>
                <button
                  onClick={() => setShowPasswordChange(true)}
                  className="px-4 py-2 bg-[var(--color-primary)] text-white rounded-lg hover:bg-[var(--color-primary)]/80 disabled:opacity-50"
                  disabled={saving}
                >
                  Change Password
                </button>
              </div>
            </div>
          </div>

          <div className="bg-[var(--color-surface)] rounded-lg border border-[var(--color-border)] p-6">
            <h3 className="text-lg font-bold text-[var(--color-text)] mb-4 flex items-center">
              <i className="fas fa-mobile-alt text-[var(--color-primary)] mr-3"></i>
              Two-Factor Authentication
            </h3>

            <div className="space-y-4">
              <div className="p-4 bg-[var(--color-background)] rounded-lg border border-[var(--color-border)]">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h4 className="font-medium text-[var(--color-text)]">Authenticator App</h4>
                    <p className="text-sm text-[var(--color-text-secondary)]">
                      {securityOverview?.twoFactorEnabled
                        ? 'Enabled'
                        : 'Add an extra layer of security'}
                    </p>
                  </div>
                  <div
                    className={`px-3 py-1 rounded text-sm font-medium ${securityOverview?.twoFactorEnabled ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}`}
                  >
                    {securityOverview?.twoFactorEnabled ? 'Enabled' : 'Disabled'}
                  </div>
                </div>

                {securityOverview?.twoFactorEnabled ? (
                  <div className="space-y-3">
                    <div className="text-sm text-[var(--color-text-secondary)]">
                      Backup codes remaining: {securityOverview.backupCodesCount}
                    </div>
                    <button
                      onClick={disable2FA}
                      className="w-full px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 disabled:opacity-50"
                      disabled={saving}
                    >
                      {saving ? 'Processing...' : 'Disable 2FA'}
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={initialize2FASetup}
                    className="w-full px-4 py-2 bg-[var(--color-primary)] text-white rounded-lg hover:bg-[var(--color-primary)]/80 disabled:opacity-50"
                    disabled={saving}
                  >
                    {saving ? 'Setting up...' : 'Enable 2FA'}
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="bg-[var(--color-surface)] rounded-lg border border-[var(--color-border)] p-6">
          <h3 className="text-lg font-bold text-[var(--color-text)] mb-4 flex items-center">
            <i className="fas fa-bell text-[var(--color-primary)] mr-3"></i>
            Security Notifications
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex items-center justify-between p-4 bg-[var(--color-background)] rounded-lg border border-[var(--color-border)]">
              <div>
                <h4 className="font-medium text-[var(--color-text)]">Email Notifications</h4>
                <p className="text-sm text-[var(--color-text-secondary)]">
                  Get notified of security events via email
                </p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={notificationSettings.email}
                  onChange={e => updateNotifications({ email: e.target.checked })}
                  disabled={saving}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-[var(--color-primary)]/25 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[var(--color-primary)]"></div>
              </label>
            </div>

            <div className="flex items-center justify-between p-4 bg-[var(--color-background)] rounded-lg border border-[var(--color-border)]">
              <div>
                <h4 className="font-medium text-[var(--color-text)]">SMS Notifications</h4>
                <p className="text-sm text-[var(--color-text-secondary)]">
                  Get notified of security events via SMS
                </p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={notificationSettings.sms}
                  onChange={e => updateNotifications({ sms: e.target.checked })}
                  disabled={saving}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-[var(--color-primary)]/25 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[var(--color-primary)]"></div>
              </label>
            </div>
          </div>
        </div>

        <div className="bg-[var(--color-surface)] rounded-lg border border-[var(--color-border)] p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-bold text-[var(--color-text)] flex items-center">
              <i className="fas fa-laptop text-[var(--color-primary)] mr-3"></i>
              Active Sessions
            </h3>
            <button
              onClick={fetchSessions}
              className="text-[var(--color-primary)] hover:text-[var(--color-primary)]/80 text-sm"
              disabled={saving}
            >
              <i className="fas fa-refresh mr-1"></i>
              Refresh
            </button>
          </div>

          {sessions.length > 0 ? (
            <div className="space-y-3">
              {sessions.map(session => (
                <div
                  key={session.sessionId}
                  className="p-4 bg-[var(--color-background)] rounded-lg border border-[var(--color-border)]"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center mb-2">
                        <span className="font-medium text-[var(--color-text)]">
                          {session.browser}
                        </span>
                        {session.isCurrent && (
                          <span className="ml-2 px-2 py-1 bg-[var(--color-primary)] text-white text-xs rounded">
                            Current
                          </span>
                        )}
                      </div>
                      <div className="text-sm text-[var(--color-text-secondary)] space-y-1">
                        <div>
                          {session.device} • {session.os}
                        </div>
                        <div>
                          {session.location.city}, {session.location.country}
                        </div>
                        <div>Last active: {new Date(session.lastActive).toLocaleString()}</div>
                      </div>
                    </div>
                    {!session.isCurrent && (
                      <button
                        onClick={() => terminateSessions([session.sessionId])}
                        className="ml-4 px-3 py-1 bg-red-500 text-white text-sm rounded hover:bg-red-600 disabled:opacity-50"
                        disabled={saving}
                      >
                        End Session
                      </button>
                    )}
                  </div>
                </div>
              ))}
              {sessions.length > 1 && (
                <button
                  onClick={() => terminateSessions([], true)}
                  className="w-full mt-4 px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600 disabled:opacity-50"
                  disabled={saving}
                >
                  {saving ? 'Processing...' : 'End All Other Sessions'}
                </button>
              )}
            </div>
          ) : (
            <p className="text-[var(--color-text-secondary)] text-center py-8">
              No active sessions found
            </p>
          )}
        </div>

        {show2FASetup && twoFactorSetup && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-[var(--color-surface)] rounded-lg border border-[var(--color-border)] p-6 max-w-md w-full max-h-[90vh] overflow-y-auto">
              <h3 className="text-lg font-bold text-[var(--color-text)] mb-4">
                Set Up Two-Factor Authentication
              </h3>

              <div className="space-y-4">
                <div>
                  <p className="text-sm text-[var(--color-text-secondary)] mb-4">
                    1. Scan this QR code with your authenticator app (Google Authenticator, Authy,
                    etc.)
                  </p>
                  <div className="flex justify-center mb-4">
                    <img src={twoFactorSetup.qrCode} alt="2FA QR Code" className="w-48 h-48" />
                  </div>
                  <p className="text-xs text-[var(--color-text-secondary)] text-center break-all">
                    Manual entry: {twoFactorSetup.secret}
                  </p>
                </div>

                <div>
                  <p className="text-sm text-[var(--color-text-secondary)] mb-2">
                    2. Save these backup codes in a secure location:
                  </p>
                  <div className="bg-[var(--color-background)] rounded-lg p-4 border border-[var(--color-border)]">
                    <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                      {twoFactorSetup.backupCodes.map((code, index) => (
                        <div key={index} className="text-center py-1">
                          {code}
                        </div>
                      ))}
                    </div>
                    <button
                      onClick={downloadBackupCodes}
                      className="w-full mt-3 px-3 py-1 bg-[var(--color-primary)] text-white text-sm rounded hover:bg-[var(--color-primary)]/80"
                    >
                      <i className="fas fa-download mr-1"></i>
                      Download Backup Codes
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-[var(--color-text)] mb-2">
                    3. Enter the 6-digit code from your authenticator app:
                  </label>
                  <input
                    type="text"
                    value={verificationCode}
                    onChange={e =>
                      setVerificationCode(e.target.value.replace(/\D/g, '').slice(0, 6))
                    }
                    className="w-full px-4 py-2 bg-[var(--color-background)] border border-[var(--color-border)] rounded-lg text-[var(--color-text)] text-center text-lg font-mono"
                    placeholder="123456"
                    maxLength={6}
                  />
                </div>

                <div className="flex space-x-3">
                  <button
                    onClick={() => {
                      setShow2FASetup(false);
                      setTwoFactorSetup(null);
                      setVerificationCode('');
                    }}
                    className="flex-1 px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={verify2FA}
                    className="flex-1 px-4 py-2 bg-[var(--color-primary)] text-white rounded-lg hover:bg-[var(--color-primary)]/80 disabled:opacity-50"
                    disabled={verificationCode.length !== 6 || saving || !backupCodesDownloaded}
                  >
                    {saving ? 'Verifying...' : 'Enable 2FA'}
                  </button>
                </div>

                {!backupCodesDownloaded && (
                  <p className="text-xs text-yellow-600 text-center">
                    Please download your backup codes before continuing
                  </p>
                )}
              </div>
            </div>
          </div>
        )}

        {showPasswordChange && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-[var(--color-surface)] rounded-lg border border-[var(--color-border)] p-6 max-w-md w-full">
              <h3 className="text-lg font-bold text-[var(--color-text)] mb-4">Change Password</h3>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-[var(--color-text)] mb-2">
                    Current Password
                  </label>
                  <input
                    type="password"
                    value={passwordData.currentPassword}
                    onChange={e =>
                      setPasswordData({ ...passwordData, currentPassword: e.target.value })
                    }
                    className="w-full px-4 py-2 bg-[var(--color-background)] border border-[var(--color-border)] rounded-lg text-[var(--color-text)]"
                    placeholder="Enter current password"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-[var(--color-text)] mb-2">
                    New Password
                  </label>
                  <input
                    type="password"
                    value={passwordData.newPassword}
                    onChange={e =>
                      setPasswordData({ ...passwordData, newPassword: e.target.value })
                    }
                    className="w-full px-4 py-2 bg-[var(--color-background)] border border-[var(--color-border)] rounded-lg text-[var(--color-text)]"
                    placeholder="Enter new password"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-[var(--color-text)] mb-2">
                    Confirm New Password
                  </label>
                  <input
                    type="password"
                    value={passwordData.confirmPassword}
                    onChange={e =>
                      setPasswordData({ ...passwordData, confirmPassword: e.target.value })
                    }
                    className="w-full px-4 py-2 bg-[var(--color-background)] border border-[var(--color-border)] rounded-lg text-[var(--color-text)]"
                    placeholder="Confirm new password"
                  />
                </div>

                <div className="flex space-x-3">
                  <button
                    onClick={() => {
                      setShowPasswordChange(false);
                      setPasswordData({
                        currentPassword: '',
                        newPassword: '',
                        confirmPassword: '',
                      });
                    }}
                    className="flex-1 px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={changePassword}
                    className="flex-1 px-4 py-2 bg-[var(--color-primary)] text-white rounded-lg hover:bg-[var(--color-primary)]/80 disabled:opacity-50"
                    disabled={
                      !passwordData.currentPassword ||
                      !passwordData.newPassword ||
                      !passwordData.confirmPassword ||
                      saving
                    }
                  >
                    {saving ? 'Changing...' : 'Change Password'}
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {showEmailChange && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-[var(--color-surface)] rounded-lg border border-[var(--color-border)] p-6 max-w-md w-full">
              <h3 className="text-lg font-bold text-[var(--color-text)] mb-4">
                Change Email Address
              </h3>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-[var(--color-text)] mb-2">
                    New Email Address
                  </label>
                  <input
                    type="email"
                    value={emailData.newEmail}
                    onChange={e => setEmailData({ ...emailData, newEmail: e.target.value })}
                    className="w-full px-4 py-2 bg-[var(--color-background)] border border-[var(--color-border)] rounded-lg text-[var(--color-text)]"
                    placeholder="Enter new email address"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-[var(--color-text)] mb-2">
                    Current Password
                  </label>
                  <input
                    type="password"
                    value={emailData.currentPassword}
                    onChange={e => setEmailData({ ...emailData, currentPassword: e.target.value })}
                    className="w-full px-4 py-2 bg-[var(--color-background)] border border-[var(--color-border)] rounded-lg text-[var(--color-text)]"
                    placeholder="Enter current password"
                  />
                </div>

                <div className="flex space-x-3">
                  <button
                    onClick={() => {
                      setShowEmailChange(false);
                      setEmailData({ newEmail: '', currentPassword: '' });
                    }}
                    className="flex-1 px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={requestEmailChange}
                    className="flex-1 px-4 py-2 bg-[var(--color-primary)] text-white rounded-lg hover:bg-[var(--color-primary)]/80 disabled:opacity-50"
                    disabled={!emailData.newEmail || !emailData.currentPassword || saving}
                  >
                    {saving ? 'Processing...' : 'Send Verification'}
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AccountSecurity;
