import React, { useState, useEffect } from 'react';
import { useTheme } from '../../../contexts/ThemeContext';
import { authService } from '../../../services/authService';
import {
  MessageSquare,
  Bot,
  Clock,
  TrendingUp,
  Activity,
  Calendar,
  BarChart3,
  Zap,
  Trophy,
  Palette,
  LayoutDashboard,
} from 'lucide-react';
import AchievementSystem from '../dashboard/AchievementSystem';
import ThemeSwitcher from '../dashboard/ThemeSwitcher';

// Dynamic API base for development vs production
const API_BASE =
  window.location.hostname === 'localhost' ? 'http://localhost:3001' : 'https://iamai.global';

interface DashboardStats {
  totalMessages: number;
  activeAgents: number;
  avgResponseTime: number;
  successRate: number;
}

interface DailyUsage {
  date: string;
  messages: number;
  sessions: number;
}

interface AgentUsage {
  agentId: string;
  name: string;
  messages: number;
  sessions?: number;
  lastUsed?: string;
  plan?: string;
  status?: string;
  percentage?: number;
}

interface StatsResponse {
  success: boolean;
  stats: DashboardStats;
  dailyUsage: DailyUsage[];
  agentUsage: AgentUsage[];
}

const OverviewSection: React.FC = () => {
  const { themeColors } = useTheme();

  const [stats, setStats] = useState<DashboardStats>({
    totalMessages: 0,
    activeAgents: 0,
    avgResponseTime: 0,
    successRate: 0,
  });
  const [dailyUsage, setDailyUsage] = useState<DailyUsage[]>([]);
  const [agentUsage, setAgentUsage] = useState<AgentUsage[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeView, setActiveView] = useState<'dashboard' | 'achievements'>('dashboard');
  const [showThemePopup, setShowThemePopup] = useState(false);

  const fetchDashboardStats = async () => {
    try {
      setIsLoading(true);
      setError(null);

      const response = await fetch(`${API_BASE}/api/dashboard/stats`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
      });

      if (!response.ok) {
        throw new Error(`Failed to fetch stats: ${response.status}`);
      }

      const data: StatsResponse = await response.json();

      if (data.success) {
        setStats(data.stats);
        setDailyUsage(data.dailyUsage);
        setAgentUsage(data.agentUsage);
      } else {
        throw new Error('Failed to load dashboard statistics');
      }
    } catch (err) {
      console.error('Error fetching dashboard stats:', err);
      setError(err instanceof Error ? err.message : 'Failed to load dashboard data');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardStats();

    // Auto-refresh every 30 seconds
    const interval = setInterval(fetchDashboardStats, 30000);
    return () => clearInterval(interval);
  }, []);

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  const getMaxMessages = () => {
    if (dailyUsage.length === 0) return 100;
    return Math.max(...dailyUsage.map(d => d.messages), 100);
  };

  if (isLoading) {
    return (
      <div
        className="min-h-screen p-8"
        style={{
          background: 'var(--color-background)',
          color: 'var(--color-text)',
        }}
      >
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-center py-20">
            <div
              className="animate-spin rounded-full h-12 w-12 border-4 border-t-transparent"
              style={{
                borderColor: `var(--color-primary) transparent var(--color-primary) var(--color-primary)`,
              }}
            ></div>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div
        className="min-h-screen p-8"
        style={{
          background: 'var(--color-background)',
          color: 'var(--color-text)',
        }}
      >
        <div className="max-w-7xl mx-auto">
          <div
            className="rounded-xl p-6 text-center"
            style={{
              background: 'var(--color-surface)',
              borderColor: 'var(--color-border)',
            }}
          >
            <p className="text-red-400 mb-4">{error}</p>
            <button
              onClick={fetchDashboardStats}
              className="px-6 py-2 rounded-lg transition-all duration-200 hover:opacity-80"
              style={{
                background: 'var(--color-primary)',
                color: '#ffffff',
              }}
            >
              Retry
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div
      className="min-h-screen p-8"
      style={{
        background: 'var(--color-background)',
        color: 'var(--color-text)',
      }}
    >
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header with Action Buttons */}
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2" style={{ color: 'var(--color-text)' }}>
              {activeView === 'dashboard' && 'Dashboard Overview'}
              {activeView === 'achievements' && 'Achievements & Rewards'}
            </h1>
            <p style={{ color: 'var(--color-text-secondary)' }}>
              {activeView === 'dashboard' &&
                'Monitor your AI assistant usage and performance metrics'}
              {activeView === 'achievements' && 'Track your progress and unlock rewards'}
            </p>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center space-x-3 relative">
            <button
              onClick={() => setActiveView('dashboard')}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-all duration-200 ${
                activeView === 'dashboard'
                  ? 'bg-[var(--color-primary)] text-white shadow-lg'
                  : 'bg-[var(--color-surface)] text-[var(--color-text-secondary)] hover:bg-[var(--color-surface)]/80 border border-[var(--color-border)]'
              }`}
            >
              <LayoutDashboard size={18} />
              <span className="font-medium">Dashboard</span>
            </button>

            <div className="relative">
              <button
                onClick={() => setShowThemePopup(!showThemePopup)}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-all duration-200 ${
                  showThemePopup
                    ? 'bg-[var(--color-primary)] text-white shadow-lg'
                    : 'bg-[var(--color-surface)] text-[var(--color-text-secondary)] hover:bg-[var(--color-surface)]/80 border border-[var(--color-border)]'
                }`}
              >
                <Palette size={18} />
                <span className="font-medium">Theme</span>
              </button>

              {/* Theme Popup Dropdown */}
              {showThemePopup && (
                <>
                  <div className="fixed inset-0 z-40" onClick={() => setShowThemePopup(false)} />
                  <div className="absolute right-0 top-full mt-2 z-50">
                    <ThemeSwitcher isDropdown={true} />
                  </div>
                </>
              )}
            </div>

            <button
              onClick={() => setActiveView('achievements')}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-all duration-200 ${
                activeView === 'achievements'
                  ? 'bg-[var(--color-primary)] text-white shadow-lg'
                  : 'bg-[var(--color-surface)] text-[var(--color-text-secondary)] hover:bg-[var(--color-surface)]/80 border border-[var(--color-border)]'
              }`}
            >
              <Trophy size={18} />
              <span className="font-medium">Achievements</span>
            </button>
          </div>
        </div>

        {/* Conditional Content Rendering */}
        {activeView === 'achievements' && <AchievementSystem />}

        {activeView === 'dashboard' && (
          <>
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {/* Total Messages */}
              <div
                className="rounded-xl p-6 transition-all duration-200 hover:scale-105"
                style={{
                  background: 'var(--color-surface)',
                  borderColor: 'var(--color-border)',
                }}
              >
                <div className="flex items-center justify-between mb-4">
                  <div
                    className="p-3 rounded-lg"
                    style={{
                      background: 'color-mix(in srgb, var(--color-primary) 20%, transparent)',
                    }}
                  >
                    <MessageSquare size={24} style={{ color: 'var(--color-primary)' }} />
                  </div>
                  <TrendingUp size={20} className="text-green-400" />
                </div>
                <div>
                  <p className="text-sm mb-1" style={{ color: 'var(--color-text-secondary)' }}>
                    Total Messages
                  </p>
                  <p className="text-3xl font-bold" style={{ color: 'var(--color-text)' }}>
                    {stats?.totalMessages?.toLocaleString() || '0'}
                  </p>
                </div>
              </div>

              {/* Active Agents */}
              <div
                className="rounded-xl p-6 transition-all duration-200 hover:scale-105"
                style={{
                  background: 'var(--color-surface)',
                  borderColor: 'var(--color-border)',
                }}
              >
                <div className="flex items-center justify-between mb-4">
                  <div
                    className="p-3 rounded-lg"
                    style={{
                      background: 'color-mix(in srgb, var(--color-secondary) 20%, transparent)',
                    }}
                  >
                    <Bot size={24} style={{ color: 'var(--color-secondary)' }} />
                  </div>
                  <Activity size={20} className="text-blue-400" />
                </div>
                <div>
                  <p className="text-sm mb-1" style={{ color: 'var(--color-text-secondary)' }}>
                    Active Agents
                  </p>
                  <p className="text-3xl font-bold" style={{ color: 'var(--color-text)' }}>
                    {stats?.activeAgents || 0}
                  </p>
                </div>
              </div>

              {/* Avg Response Time */}
              <div
                className="rounded-xl p-6 transition-all duration-200 hover:scale-105"
                style={{
                  background: 'var(--color-surface)',
                  borderColor: 'var(--color-border)',
                }}
              >
                <div className="flex items-center justify-between mb-4">
                  <div
                    className="p-3 rounded-lg"
                    style={{
                      background: 'color-mix(in srgb, var(--color-accent) 20%, transparent)',
                    }}
                  >
                    <Clock size={24} style={{ color: 'var(--color-accent)' }} />
                  </div>
                  <Zap size={20} className="text-yellow-400" />
                </div>
                <div>
                  <p className="text-sm mb-1" style={{ color: 'var(--color-text-secondary)' }}>
                    Avg Response Time
                  </p>
                  <p className="text-3xl font-bold" style={{ color: 'var(--color-text)' }}>
                    {stats?.avgResponseTime?.toFixed(1) || '0.0'}s
                  </p>
                </div>
              </div>

              {/* Success Rate */}
              <div
                className="rounded-xl p-6 transition-all duration-200 hover:scale-105"
                style={{
                  background: 'var(--color-surface)',
                  borderColor: 'var(--color-border)',
                }}
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="p-3 rounded-lg" style={{ background: '#10b98120' }}>
                    <TrendingUp size={24} className="text-green-400" />
                  </div>
                  <BarChart3 size={20} className="text-purple-400" />
                </div>
                <div>
                  <p className="text-sm mb-1" style={{ color: 'var(--color-text-secondary)' }}>
                    Success Rate
                  </p>
                  <p className="text-3xl font-bold" style={{ color: 'var(--color-text)' }}>
                    {stats?.successRate?.toFixed(1) || '0.0'}%
                  </p>
                </div>
              </div>
            </div>

            {/* Charts Section */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Daily Usage Chart */}
              <div
                className="rounded-xl p-6"
                style={{
                  background: 'var(--color-surface)',
                  borderColor: 'var(--color-border)',
                }}
              >
                <div className="flex items-center gap-3 mb-6">
                  <Calendar size={24} style={{ color: 'var(--color-primary)' }} />
                  <h2 className="text-xl font-semibold" style={{ color: 'var(--color-text)' }}>
                    Daily Activity (Last 7 Days)
                  </h2>
                </div>

                <div className="space-y-4">
                  {dailyUsage.map((day, index) => {
                    const maxMessages = getMaxMessages();
                    const percentage = (day.messages / maxMessages) * 100;

                    return (
                      <div key={index}>
                        <div className="flex items-center justify-between mb-2">
                          <span
                            className="text-sm"
                            style={{ color: 'var(--color-text-secondary)' }}
                          >
                            {formatDate(day.date)}
                          </span>
                          <span
                            className="text-sm font-semibold"
                            style={{ color: 'var(--color-text)' }}
                          >
                            {day.messages} messages
                          </span>
                        </div>
                        <div
                          className="h-3 rounded-full overflow-hidden"
                          style={{
                            background: 'color-mix(in srgb, var(--color-primary) 20%, transparent)',
                          }}
                        >
                          <div
                            className="h-full rounded-full transition-all duration-500"
                            style={{
                              width: `${percentage}%`,
                              background: 'var(--color-primary)',
                            }}
                          ></div>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {dailyUsage.length === 0 && (
                  <div
                    className="text-center py-8"
                    style={{ color: 'var(--color-text-secondary)' }}
                  >
                    No activity data available
                  </div>
                )}
              </div>

              {/* Agent Usage */}
              <div
                className="rounded-xl p-6"
                style={{
                  background: 'var(--color-surface)',
                  borderColor: 'var(--color-border)',
                }}
              >
                <div className="flex items-center gap-3 mb-6">
                  <Bot size={24} style={{ color: 'var(--color-secondary)' }} />
                  <h2 className="text-xl font-semibold" style={{ color: 'var(--color-text)' }}>
                    Top Agents
                  </h2>
                </div>

                <div className="space-y-4">
                  {agentUsage.map((agent, index) => {
                    const maxMessages = agentUsage[0]?.messages || 1;
                    const percentage = maxMessages > 0 ? (agent.messages / maxMessages) * 100 : 0;
                    const hasMessages = agent.messages > 0;

                    return (
                      <div key={agent.agentId || index}>
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <div
                              className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold"
                              style={{ 
                                background: agent.status === 'ACTIVE' ? 'var(--color-primary)' : 'var(--color-border)', 
                                color: '#ffffff' 
                              }}
                            >
                              {index + 1}
                            </div>
                            <div className="flex flex-col">
                              <span className="font-medium" style={{ color: 'var(--color-text)' }}>
                                {agent.name}
                              </span>
                              <span className="text-xs" style={{ color: 'var(--color-text-secondary)' }}>
                                {agent.plan ? `${agent.plan} Plan` : 'Free Trial'} • {agent.lastUsed || 'Not used yet'}
                              </span>
                            </div>
                          </div>
                          <div className="text-right">
                            <span
                              className="text-sm font-medium"
                              style={{ color: 'var(--color-text)' }}
                            >
                              {agent.messages} msgs
                            </span>
                            {agent.status === 'ACTIVE' && (
                              <div 
                                className="text-xs px-2 py-0.5 rounded-full mt-1"
                                style={{ 
                                  background: 'color-mix(in srgb, var(--color-success) 20%, transparent)',
                                  color: 'var(--color-success)'
                                }}
                              >
                                Active
                              </div>
                            )}
                          </div>
                        </div>
                        <div
                          className="h-3 rounded-full overflow-hidden"
                          style={{
                            background:
                              'color-mix(in srgb, var(--color-secondary) 20%, transparent)',
                          }}
                        >
                          <div
                            className="h-full rounded-full transition-all duration-500"
                            style={{
                              width: hasMessages ? `${Math.max(percentage, 5)}%` : '5%',
                              background: agent.status === 'ACTIVE' ? 'var(--color-secondary)' : 'var(--color-border)',
                              opacity: hasMessages ? 1 : 0.5
                            }}
                          ></div>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {agentUsage.length === 0 && (
                  <div
                    className="text-center py-8"
                    style={{ color: 'var(--color-text-secondary)' }}
                  >
                    No agent usage data available
                  </div>
                )}
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default OverviewSection;
