import React, { useState, useEffect } from 'react';
import { useTheme } from '../../../contexts/ThemeContext';

const AccountSettings: React.FC = () => {
  const { theme: currentTheme, setTheme } = useTheme();
  const [settings, setSettings] = useState({
    theme: currentTheme || 'dark',
    language: 'en',
    timezone: 'UTC-5',
    emailNotifications: true,
    pushNotifications: false,
    marketingEmails: false,
    dataSharing: false,
    autoSave: true,
    compactMode: false,
  });

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState('');

  useEffect(() => {
    fetchUserSettings();
  }, []);

  const fetchUserSettings = async () => {
    try {
      setLoading(true);

      // First try to load from localStorage as backup
      const savedSettings = localStorage.getItem('iamai_user_settings');
      if (savedSettings) {
        const parsed = JSON.parse(savedSettings);
        setSettings(prev => ({ ...prev, ...parsed }));
      }

      const response = await fetch('/api/users/preferences', {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
      });

      if (response.ok) {
        const data = await response.json();
        const preferences = data.data || {};

        const newSettings = {
          theme: preferences.theme || currentTheme || 'dark',
          language: preferences.language || 'en',
          timezone: preferences.timezone || 'UTC-5',
          emailNotifications: preferences.emailNotifications ?? true,
          pushNotifications: preferences.pushNotifications ?? false,
          marketingEmails: preferences.marketingEmails ?? false,
          dataSharing: preferences.dataSharing ?? false,
          autoSave: preferences.autoSave ?? true,
          compactMode: preferences.compactMode ?? false,
        };

        setSettings(newSettings);

        // Save to localStorage as backup
        localStorage.setItem('iamai_user_settings', JSON.stringify(newSettings));
      }
    } catch (error) {
      console.error('Error fetching user settings:', error);
      // If API fails, try to use localStorage data
      const savedSettings = localStorage.getItem('iamai_user_settings');
      if (savedSettings) {
        setSettings(JSON.parse(savedSettings));
      }
    } finally {
      setLoading(false);
    }
  };

  const handleSettingChange = (key: string, value: any) => {
    setSettings(prev => ({ ...prev, [key]: value }));

    // Apply theme immediately
    if (key === 'theme') {
      setTheme(value);
    }
  };

  const handleSaveSettings = async () => {
    setSaving(true);
    setMessage('');

    try {
      // Save preferences
      const preferencesResponse = await fetch('/api/users/preferences', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({
          theme: settings.theme,
          language: settings.language,
          timezone: settings.timezone,
          emailNotifications: settings.emailNotifications,
          pushNotifications: settings.pushNotifications,
          marketingEmails: settings.marketingEmails,
          dataSharing: settings.dataSharing,
          autoSave: settings.autoSave,
          compactMode: settings.compactMode,
        }),
      });

      // Always save to localStorage as backup
      localStorage.setItem('iamai_user_settings', JSON.stringify(settings));

      if (preferencesResponse.ok) {
        setMessage('Settings saved successfully!');
        // Apply theme
        setTheme(settings.theme);
      } else {
        console.warn('Settings failed to save to server');
        setMessage('Settings saved locally. May not sync to server.');

        // Still apply theme even if server save failed
        setTheme(settings.theme);
      }
    } catch (error) {
      console.error('Error saving settings:', error);
      // Even on error, save to localStorage
      localStorage.setItem('iamai_user_settings', JSON.stringify(settings));
      setMessage('Settings saved locally. Server sync failed.');

      // Still apply theme
      setTheme(settings.theme);
    } finally {
      setSaving(false);
      setTimeout(() => setMessage(''), 3000);
    }
  };

  const settingSections = [
    {
      title: 'Localization',
      icon: 'fa-globe',
      settings: [
        {
          key: 'language',
          label: 'Language',
          type: 'select',
          options: [
            { value: 'en', label: 'English' },
            { value: 'es', label: 'Español' },
            { value: 'fr', label: 'Français' },
            { value: 'de', label: 'Deutsch' },
            { value: 'ja', label: '日本語' },
          ],
        },
        {
          key: 'timezone',
          label: 'Timezone',
          type: 'select',
          options: [
            { value: 'UTC-8', label: 'Pacific Time (UTC-8)' },
            { value: 'UTC-5', label: 'Eastern Time (UTC-5)' },
            { value: 'UTC+0', label: 'GMT (UTC+0)' },
            { value: 'UTC+1', label: 'Central European Time (UTC+1)' },
            { value: 'UTC+9', label: 'Japan Standard Time (UTC+9)' },
          ],
        },
      ],
    },
    {
      title: 'Notifications',
      icon: 'fa-bell',
      settings: [
        {
          key: 'emailNotifications',
          label: 'Email Notifications',
          type: 'toggle',
          description: 'Receive important updates via email',
        },
        {
          key: 'pushNotifications',
          label: 'Push Notifications',
          type: 'toggle',
          description: 'Receive push notifications in your browser',
        },
        {
          key: 'marketingEmails',
          label: 'Marketing Emails',
          type: 'toggle',
          description: 'Receive emails about new features and promotions',
        },
      ],
    },
    {
      title: 'Privacy & Data',
      icon: 'fa-lock',
      settings: [
        {
          key: 'dataSharing',
          label: 'Data Sharing',
          type: 'toggle',
          description: 'Allow anonymous usage data to help improve our services',
        },
        {
          key: 'autoSave',
          label: 'Auto-save Conversations',
          type: 'toggle',
          description: 'Automatically save your chat conversations',
        },
      ],
    },
  ];

  return (
    <div className="p-8">
      {/* Settings Sections */}
      <div className="space-y-8">
        {settingSections.map((section, sectionIndex) => (
          <div
            key={sectionIndex}
            className="bg-[var(--color-surface)]/50 border border-[var(--color-border)] rounded-lg p-6"
          >
            <div className="flex items-center space-x-3 mb-6">
              <i className={`fa-solid ${section.icon} text-[var(--color-primary)] text-xl`}></i>
              <h3 className="text-xl font-semibold text-[var(--color-text)]">{section.title}</h3>
            </div>

            <div className="space-y-6">
              {section.settings.map((setting, settingIndex) => (
                <div key={settingIndex} className="flex items-center justify-between py-3">
                  <div className="flex-1">
                    <label className="text-[var(--color-text)] font-medium block">
                      {setting.label}
                    </label>
                    {setting.description && (
                      <p className="text-[var(--color-text-secondary)] text-sm mt-1">
                        {setting.description}
                      </p>
                    )}
                  </div>
                  <div className="ml-4">
                    {setting.type === 'toggle' ? (
                      <button
                        onClick={() =>
                          handleSettingChange(
                            setting.key,
                            !settings[setting.key as keyof typeof settings]
                          )
                        }
                        className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)] focus:ring-offset-2 ${
                          settings[setting.key as keyof typeof settings]
                            ? 'bg-[var(--color-primary)]'
                            : 'bg-[var(--color-surface)]'
                        }`}
                      >
                        <span
                          className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                            settings[setting.key as keyof typeof settings]
                              ? 'translate-x-6'
                              : 'translate-x-1'
                          }`}
                        />
                      </button>
                    ) : setting.type === 'select' ? (
                      <select
                        value={settings[setting.key as keyof typeof settings] as string}
                        onChange={e => handleSettingChange(setting.key, e.target.value)}
                        className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-lg px-3 py-2 text-[var(--color-text)] focus:border-[var(--color-primary)] focus:outline-none min-w-48"
                      >
                        {setting.options?.map(option => (
                          <option key={option.value} value={option.value}>
                            {option.label}
                          </option>
                        ))}
                      </select>
                    ) : null}
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Save Button */}
      <div className="mt-8 flex items-center justify-between">
        <div>
          {message && (
            <p
              className={`text-sm ${message.includes('success') ? 'text-green-400' : 'text-red-400'}`}
            >
              {message}
            </p>
          )}
        </div>
        <button
          onClick={handleSaveSettings}
          disabled={loading || saving}
          className="px-8 py-3 bg-[var(--color-primary)] hover:bg-[var(--color-primary)]/80 disabled:bg-[var(--color-surface)] text-[var(--color-text)] disabled:text-[var(--color-text-secondary)] font-semibold rounded-lg transition-colors flex items-center space-x-2"
        >
          {loading || saving ? (
            <>
              <i className="fa-solid fa-spinner fa-spin"></i>
              <span>Saving...</span>
            </>
          ) : (
            <>
              <i className="fa-solid fa-save"></i>
              <span>Save Settings</span>
            </>
          )}
        </button>
      </div>

      {/* Data Export */}
      <div className="mt-8 bg-[var(--color-surface)]/50 border border-[var(--color-border)] rounded-lg p-6">
        <h3 className="text-xl font-semibold text-[var(--color-text)] mb-4">Data Management</h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="text-[var(--color-text)] font-medium">Export Your Data</h4>
              <p className="text-[var(--color-text-secondary)] text-sm">
                Download a copy of all your data
              </p>
            </div>
            <button className="px-4 py-2 bg-[var(--color-surface)] hover:bg-[var(--color-surface)]/80 text-[var(--color-text)] font-semibold rounded-lg transition-colors border border-[var(--color-border)]">
              Export Data
            </button>
          </div>
          <div className="flex items-center justify-between">
            <div>
              <h4 className="text-[var(--color-text)] font-medium">Delete Account</h4>
              <p className="text-[var(--color-text-secondary)] text-sm">
                Permanently delete your account and all data
              </p>
            </div>
            <button className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white font-semibold rounded-lg transition-colors">
              Delete Account
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AccountSettings;
