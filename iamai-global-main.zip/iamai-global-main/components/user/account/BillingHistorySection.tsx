import React, { useState, useEffect } from 'react';

interface BillingItem {
  id: string;
  date: string;
  description: string;
  amount: string;
  status?: 'paid' | 'pending' | 'failed';
}

interface BillingHistorySectionProps {
  billingHistory?: BillingItem[];
  showHeading?: boolean;
}

const BillingHistorySection: React.FC<BillingHistorySectionProps> = ({
  billingHistory: initialBillingHistory = [],
  showHeading = true,
}) => {
  const [billingHistory, setBillingHistory] = useState<BillingItem[]>(initialBillingHistory);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchBillingHistory = async () => {
      try {
        setLoading(true);

        const response = await fetch('/api/purchases/history', {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
          },
          credentials: 'include',
        });

        if (response.ok) {
          const result = await response.json();
          const purchases =
            result?.purchases || result?.data?.purchases || [];

          if (Array.isArray(purchases)) {
            const invoices = purchases.map((purchase: any) => {
              const amountNumber = purchase.amount ?? purchase.pricing?.amount ?? 0;
              const paymentStatus = (purchase.paymentStatus || '').toUpperCase();
              let status: 'paid' | 'pending' | 'failed' = 'paid';
              if (paymentStatus === 'PENDING') status = 'pending';
              else if (paymentStatus && paymentStatus !== 'SUCCESS') status = 'failed';

              return {
                id: purchase.id || purchase._id,
                date: new Date(purchase.purchaseDate || purchase.createdAt).toLocaleDateString(
                  'en-US',
                  {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric',
                  }
                ),
                description: `${purchase.planName || purchase.plan || 'Access'} - ${
                  purchase.agentName || purchase.agentId || 'Agent'
                }`,
                amount: `$${Number(amountNumber).toFixed(2)}`,
                status,
              } as BillingItem;
            });
            setBillingHistory(invoices);
          } else {
            setBillingHistory([]);
          }
        } else {
          console.warn('Failed to fetch billing history');
          setBillingHistory([]);
        }
      } catch (err) {
        console.error('Error fetching billing history:', err);
        setError('Failed to load billing history');
        setBillingHistory([]);
      } finally {
        setLoading(false);
      }
    };

    fetchBillingHistory();
  }, []);

  if (loading) {
    return (
      <div className="p-8 flex items-center justify-center min-h-[400px]">
        <div className="flex flex-col items-center space-y-4">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[var(--color-primary)]"></div>
          <p className="text-[var(--color-text-secondary)]">Loading billing history...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-8">
        <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4">
          <p className="text-red-400">{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8">
      {showHeading && (
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
          <div>
            <h2 className="text-2xl font-bold text-[var(--color-text)]">Billing History</h2>
            <p className="text-[var(--color-text-secondary)] mt-1">
              Manage your payment method and view invoices.
            </p>
          </div>
          <button
            title="Update your credit card and billing information"
            className="mt-4 sm:mt-0 px-4 py-2 bg-[var(--color-surface)] text-[var(--color-text)] font-semibold rounded-lg hover:bg-[var(--color-surface)]/80 transition-colors duration-300 text-sm border border-[var(--color-border)]"
          >
            Manage Payment Method
          </button>
        </div>
      )}

      {billingHistory.length === 0 ? (
        <div className="text-center py-12">
          <svg
            className="mx-auto h-12 w-12 text-[var(--color-text-secondary)]"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
            />
          </svg>
          <h3 className="mt-2 text-sm font-semibold text-[var(--color-text)]">No invoices</h3>
          <p className="mt-1 text-sm text-[var(--color-text-secondary)]">
            You don't have any billing history yet.
          </p>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-700">
            <thead>
              <tr>
                <th
                  scope="col"
                  className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-[var(--color-text)] sm:pl-0"
                >
                  Invoice
                </th>
                <th
                  scope="col"
                  className="px-3 py-3.5 text-left text-sm font-semibold text-[var(--color-text)]"
                >
                  Date
                </th>
                <th
                  scope="col"
                  className="px-3 py-3.5 text-left text-sm font-semibold text-[var(--color-text)]"
                >
                  Description
                </th>
                <th
                  scope="col"
                  className="px-3 py-3.5 text-left text-sm font-semibold text-[var(--color-text)]"
                >
                  Status
                </th>
                <th
                  scope="col"
                  className="px-3 py-3.5 text-left text-sm font-semibold text-[var(--color-text)]"
                >
                  Amount
                </th>
                <th scope="col" className="relative py-3.5 pl-3 pr-4 sm:pr-0">
                  <span className="sr-only">Download</span>
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[var(--color-border)]">
              {billingHistory.map(invoice => (
                <tr key={invoice.id}>
                  <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-[var(--color-text)] sm:pl-0">
                    {invoice.id}
                  </td>
                  <td className="whitespace-nowrap px-3 py-4 text-sm text-[var(--color-text-secondary)]">
                    {invoice.date}
                  </td>
                  <td className="whitespace-nowrap px-3 py-4 text-sm text-[var(--color-text-secondary)]">
                    {invoice.description}
                  </td>
                  <td className="whitespace-nowrap px-3 py-4 text-sm">
                    <span
                      className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                        invoice.status === 'paid'
                          ? 'bg-[var(--color-primary)]/10 text-[var(--color-primary)] border border-[var(--color-primary)]/20'
                          : invoice.status === 'pending'
                            ? 'bg-yellow-500/10 text-yellow-400 border border-yellow-500/20'
                            : 'bg-red-500/10 text-red-400 border border-red-500/20'
                      }`}
                    >
                      {invoice.status || 'paid'}
                    </span>
                  </td>
                  <td className="whitespace-nowrap px-3 py-4 text-sm text-[var(--color-text-secondary)]">
                    {invoice.amount}
                  </td>
                  <td className="relative whitespace-nowrap py-4 pl-3 pr-4 text-right text-sm font-medium sm:pr-0">
                    <button
                      title={`Download invoice ${invoice.id}`}
                      className="text-[var(--color-primary)] hover:text-[var(--color-primary)]/80"
                    >
                      Download<span className="sr-only">, {invoice.id}</span>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default BillingHistorySection;
