import React, { useState, useEffect } from 'react';
import AvatarUpload from '../dashboard/AvatarUpload';

interface UserProfile {
  name: string;
  email: string;
  avatar: string;
  joined: string;
  phone?: string;
  address?: string;
  city?: string;
  country?: string;
}

interface User {
  _id?: string;
  name?: string;
  email?: string;
  avatar?: string;
  profileImage?: string;
  createdAt?: string;
  phone?: string;
  address?: string;
  city?: string;
  country?: string;
  bio?: string;
}

interface ProfileSectionProps {
  user: User;
  onProfileUpdate?: (updatedUser: User) => void;
}

const formatJoinedDate = (date?: string) => {
  if (!date) return 'Loading...';
  try {
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  } catch (error) {
    return 'Loading...';
  }
};

const buildProfileState = (user: User): UserProfile => ({
  name: user.name || '',
  email: user.email || '',
  avatar: user.avatar || user.profileImage || '/default-avatar.svg',
  joined: formatJoinedDate(user.createdAt),
  phone: user.phone || '',
  address: user.address || '',
  city: user.city || '',
  country: user.country || '',
});

const ProfileInfoRow: React.FC<{ label: string; value: string; icon?: string }> = ({
  label,
  value,
  icon,
}) => (
  <div className="flex items-start space-x-4 p-4 bg-[var(--color-surface)]/30 rounded-lg border border-[var(--color-border)]/50 hover:border-[var(--color-primary)]/30 transition-colors">
    {icon && <i className={`${icon} text-[var(--color-primary)] text-lg mt-1`}></i>}
    <div className="flex-1">
      <dt className="text-xs font-semibold text-[var(--color-text-secondary)] uppercase tracking-wide">
        {label}
      </dt>
      <dd className="mt-1 text-base font-medium text-[var(--color-text)]">{value}</dd>
    </div>
  </div>
);

const ProfileSection: React.FC<ProfileSectionProps> = ({ user, onProfileUpdate }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [loading, setLoading] = useState(false);
  const [profileData, setProfileData] = useState<UserProfile>(buildProfileState(user));
  const [saveStatus, setSaveStatus] = useState<{
    type: 'success' | 'error';
    message: string;
  } | null>(null);
  const [showAvatarUploader, setShowAvatarUploader] = useState(false);

  useEffect(() => {
    setProfileData(buildProfileState(user));
  }, [user]);

  const handleSave = async () => {
    setLoading(true);
    setSaveStatus(null);
    try {
      const response = await fetch('/api/users/profile', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({
          name: profileData.name,
          phone: profileData.phone,
          address: profileData.address,
          city: profileData.city,
          country: profileData.country,
        }),
      });

      if (response.ok) {
        const result = await response.json();
        const updatedUser = result.user ||
          result.data || {
            ...user,
            ...profileData,
          };
        setProfileData(buildProfileState(updatedUser));
        setIsEditing(false);
        setSaveStatus({ type: 'success', message: 'Profile updated successfully' });
        onProfileUpdate?.(updatedUser);
      } else {
        const errorPayload = await response
          .json()
          .catch(() => ({ message: 'Failed to update profile' }));
        setSaveStatus({
          type: 'error',
          message: errorPayload.message || 'Failed to update profile',
        });
      }
    } catch (error) {
      console.error('Error updating profile:', error);
      setSaveStatus({ type: 'error', message: 'Unexpected error updating profile' });
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = () => {
    setProfileData(buildProfileState(user));
    setSaveStatus(null);
    setIsEditing(false);
  };

  if (isEditing) {
    return (
      <div className="p-8">
        {/* Header */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-[var(--color-text)]">Edit Profile</h2>
          <p className="text-[var(--color-text-secondary)] mt-2">Update your profile information</p>
        </div>

        {/* Edit Form */}
        <div className="bg-gradient-to-r from-[var(--color-surface)]/50 to-[var(--color-surface)]/30 border border-[var(--color-border)] rounded-2xl p-8 mb-8">
          <div className="space-y-6">
            {/* Avatar Upload */}
            <div className="flex flex-col items-center space-y-4">
              <div className="relative">
                <img
                  src={profileData.avatar}
                  alt="User Avatar"
                  className="w-32 h-32 rounded-full border-4 border-[var(--color-primary)]/20 shadow-lg shadow-[var(--color-primary)]/10"
                />
              </div>
              <button
                type="button"
                onClick={() => setShowAvatarUploader(true)}
                className="px-4 py-2 bg-[var(--color-primary)]/20 border border-[var(--color-primary)]/40 rounded-full text-sm font-semibold text-[var(--color-primary)] hover:bg-[var(--color-primary)]/30 transition-colors"
              >
                Change Avatar
              </button>
            </div>

            {/* Form Fields */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-[var(--color-text)] mb-2">
                  Full Name *
                </label>
                <input
                  type="text"
                  value={profileData.name}
                  onChange={e => setProfileData({ ...profileData, name: e.target.value })}
                  className="w-full px-4 py-3 bg-[var(--color-surface)] border border-[var(--color-border)] rounded-lg text-[var(--color-text)] focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)] focus:border-transparent"
                  placeholder="Enter your full name"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-[var(--color-text)] mb-2">
                  Email Address
                </label>
                <input
                  type="email"
                  value={profileData.email}
                  disabled
                  className="w-full px-4 py-3 bg-[var(--color-surface)]/50 border border-[var(--color-border)] rounded-lg text-[var(--color-text-secondary)] cursor-not-allowed"
                  placeholder="Email cannot be changed here"
                />
                <p className="text-xs text-[var(--color-text-secondary)] mt-1">
                  Change email in Security settings
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-[var(--color-text)] mb-2">
                  Phone Number
                </label>
                <input
                  type="tel"
                  value={profileData.phone}
                  onChange={e => setProfileData({ ...profileData, phone: e.target.value })}
                  className="w-full px-4 py-3 bg-[var(--color-surface)] border border-[var(--color-border)] rounded-lg text-[var(--color-text)] focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)] focus:border-transparent"
                  placeholder="+1 (555) 123-4567"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-[var(--color-text)] mb-2">
                  Country
                </label>
                <input
                  type="text"
                  value={profileData.country}
                  onChange={e => setProfileData({ ...profileData, country: e.target.value })}
                  className="w-full px-4 py-3 bg-[var(--color-surface)] border border-[var(--color-border)] rounded-lg text-[var(--color-text)] focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)] focus:border-transparent"
                  placeholder="United States"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-[var(--color-text)] mb-2">
                  City
                </label>
                <input
                  type="text"
                  value={profileData.city}
                  onChange={e => setProfileData({ ...profileData, city: e.target.value })}
                  className="w-full px-4 py-3 bg-[var(--color-surface)] border border-[var(--color-border)] rounded-lg text-[var(--color-text)] focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)] focus:border-transparent"
                  placeholder="New York"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-[var(--color-text)] mb-2">
                  Address
                </label>
                <input
                  type="text"
                  value={profileData.address}
                  onChange={e => setProfileData({ ...profileData, address: e.target.value })}
                  className="w-full px-4 py-3 bg-[var(--color-surface)] border border-[var(--color-border)] rounded-lg text-[var(--color-text)] focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)] focus:border-transparent"
                  placeholder="123 Main Street"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex space-x-4">
          <button
            onClick={handleSave}
            disabled={loading || !profileData.name.trim()}
            className="px-6 py-3 bg-[var(--color-primary)] hover:bg-[var(--color-primary)]/80 disabled:opacity-50 disabled:cursor-not-allowed text-[var(--color-text)] font-semibold rounded-lg transition-all duration-300 flex items-center justify-center space-x-2 hover:shadow-lg hover:shadow-[var(--color-primary)]/20"
          >
            <i className="fa-solid fa-check"></i>
            <span>{loading ? 'Saving...' : 'Save Changes'}</span>
          </button>
          <button
            onClick={handleCancel}
            disabled={loading}
            className="px-6 py-3 bg-transparent border-2 border-[var(--color-border)] text-[var(--color-text)] font-semibold rounded-lg hover:bg-[var(--color-surface)]/50 hover:border-[var(--color-primary)]/50 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300 flex items-center justify-center space-x-2"
          >
            <i className="fa-solid fa-times"></i>
            <span>Cancel</span>
          </button>
        </div>

        {saveStatus && (
          <div
            className={`mt-6 p-4 rounded-lg border ${
              saveStatus.type === 'success'
                ? 'bg-green-500/10 border-green-500/30 text-green-300'
                : 'bg-red-500/10 border-red-500/30 text-red-300'
            }`}
          >
            {saveStatus.message}
          </div>
        )}

        {showAvatarUploader && (
          <AvatarUpload
            currentAvatar={profileData.avatar}
            onUpload={avatarUrl => {
              setProfileData(prev => ({ ...prev, avatar: avatarUrl }));
              setShowAvatarUploader(false);
              onProfileUpdate?.({ ...user, avatar: avatarUrl, profileImage: avatarUrl });
              setSaveStatus({ type: 'success', message: 'Avatar updated successfully' });
            }}
            onClose={() => setShowAvatarUploader(false)}
          />
        )}
      </div>
    );
  }

  return (
    <div className="p-8">
      {/* Header */}
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-[var(--color-text)]">Profile Information</h2>
        <p className="text-[var(--color-text-secondary)] mt-2">
          Manage and view your account details
        </p>
      </div>

      {/* Profile Card */}
      <div className="bg-gradient-to-r from-[var(--color-surface)]/50 to-[var(--color-surface)]/30 border border-[var(--color-border)] rounded-2xl p-8 mb-8">
        <div className="flex flex-col md:flex-row items-start md:items-center space-y-6 md:space-y-0 md:space-x-8">
          <div className="relative">
            <img
              src={profileData.avatar}
              alt="User Avatar"
              className="w-32 h-32 rounded-full border-4 border-[var(--color-primary)]/20 shadow-lg shadow-[var(--color-primary)]/10"
            />
            <div className="absolute bottom-0 right-0 w-5 h-5 bg-green-500 rounded-full border-2 border-[var(--color-background)]"></div>
          </div>
          <div className="flex-1">
            <h3 className="text-3xl font-bold text-[var(--color-text)]">{profileData.name}</h3>
            <p className="text-[var(--color-primary)] text-lg mt-1">{profileData.email}</p>
            <div className="flex flex-wrap gap-2 mt-4">
              <span className="px-3 py-1 bg-[var(--color-primary)]/10 border border-[var(--color-primary)]/30 rounded-full text-xs font-semibold text-[var(--color-primary)]">
                ✓ Active
              </span>
              <span className="px-3 py-1 bg-[var(--color-primary)]/10 border border-[var(--color-primary)]/30 rounded-full text-xs font-semibold text-[var(--color-primary)]">
                ✓ Verified
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Account Details Grid */}
      <div className="mb-8">
        <h3 className="text-lg font-bold text-[var(--color-text)] mb-4">Account Details</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <ProfileInfoRow label="Full Name" value={profileData.name} icon="fa-solid fa-user" />
          <ProfileInfoRow
            label="Email Address"
            value={profileData.email}
            icon="fa-solid fa-envelope"
          />
          <ProfileInfoRow
            label="Phone Number"
            value={profileData.phone || 'Not provided'}
            icon="fa-solid fa-phone"
          />
          <ProfileInfoRow
            label="Country"
            value={profileData.country || 'Not provided'}
            icon="fa-solid fa-globe"
          />
          <ProfileInfoRow
            label="City"
            value={profileData.city || 'Not provided'}
            icon="fa-solid fa-location-dot"
          />
          <ProfileInfoRow
            label="Address"
            value={profileData.address || 'Not provided'}
            icon="fa-solid fa-map-marker"
          />
          <ProfileInfoRow
            label="Member Since"
            value={profileData.joined}
            icon="fa-solid fa-calendar"
          />
          <ProfileInfoRow
            label="Account Status"
            value="Active & Verified"
            icon="fa-solid fa-badge-check"
          />
        </div>
      </div>

      {/* Action Buttons */}
      <div className="border-t border-[var(--color-border)] pt-8">
        <h3 className="text-lg font-bold text-[var(--color-text)] mb-4">Account Actions</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <button
            onClick={() => setIsEditing(true)}
            title="Update your profile information"
            className="px-6 py-3 bg-[var(--color-primary)] hover:bg-[var(--color-primary)]/80 text-[var(--color-text)] font-semibold rounded-lg transition-all duration-300 flex items-center justify-center space-x-2 hover:shadow-lg hover:shadow-[var(--color-primary)]/20"
          >
            <i className="fa-solid fa-pen-to-square"></i>
            <span>Edit Profile</span>
          </button>
          <button
            title="Permanently delete your account"
            className="px-6 py-3 border-2 border-red-500/50 text-red-400 font-semibold rounded-lg hover:bg-red-500/10 hover:border-red-500 transition-all duration-300 flex items-center justify-center space-x-2"
          >
            <i className="fa-solid fa-trash-can"></i>
            <span>Delete Account</span>
          </button>
        </div>
      </div>

      {/* Info Box */}
      <div className="mt-8 p-4 bg-[var(--color-primary)]/5 border border-[var(--color-primary)]/20 rounded-lg">
        <div className="flex space-x-3">
          <i className="fa-solid fa-info-circle text-[var(--color-primary)] text-lg flex-shrink-0"></i>
          <p className="text-sm text-[var(--color-text-secondary)]">
            Your email address is protected and cannot be changed here. To update your email or
            password, visit the{' '}
            <span className="text-[var(--color-primary)] font-semibold">Security</span> section. For
            assistance, contact our support team at{' '}
            <span className="text-[var(--color-primary)] font-semibold">support@iamai.global</span>
          </p>
        </div>
      </div>
    </div>
  );
};

export default ProfileSection;
