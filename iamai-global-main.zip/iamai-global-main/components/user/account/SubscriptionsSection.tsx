import React, { useMemo } from 'react';
import { Agent } from '../../../constants';
import { ALL_AGENTS } from '../../../agents';
import { useApp } from '../../../contexts/AppContext';
import { notificationService } from '../../../services/notificationService';

interface SubscriptionsSectionProps {
  subscriptions?: Record<string, string>;
  agents?: Agent[];
  showOnlyPurchased?: boolean;
}

interface AgentPurchase {
  id: string;
  agentId: string;
  agentName: string;
  plan: string;
  planName: string;
  expiresAt: string;
  daysRemaining: number;
  status: string;
}

interface AgentCardProps {
  agent: Agent;
  purchase: AgentPurchase | null;
  onBuyAccess: (agent: Agent) => void;
  onStartChat: (agent: Agent) => void;
  onCancelAccess: (agent: Agent, purchase: AgentPurchase) => void;
}

const formatExpiryDate = (dateString: string): string => {
  const date = new Date(dateString);
  return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
};

const AgentPurchaseCard: React.FC<AgentCardProps> = ({
  agent,
  purchase,
  onBuyAccess,
  onStartChat,
  onCancelAccess,
}) => {
  const hasAccess = purchase && purchase.status === 'active';
  const isExpiringSoon = purchase && purchase.daysRemaining <= 3;

  const handleCardClick = () => {
    if (hasAccess) {
      onStartChat(agent);
    } else {
      onBuyAccess(agent);
    }
  };

  return (
    <div
      className={`relative border rounded-2xl p-5 transition hover:border-[var(--color-primary)] cursor-pointer ${
        !hasAccess ? 'bg-[var(--color-surface)]/40' : 'bg-[var(--color-surface)]'
      }`}
      style={{ borderColor: 'var(--color-border)' }}
      onClick={handleCardClick}
    >
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-center gap-3 flex-1">
          <div className="w-14 h-14 rounded-2xl bg-[var(--color-background)]/70 flex items-center justify-center text-[var(--color-primary)] text-2xl">
            {agent.icon && agent.icon.startsWith('data:image') ? (
              <img
                src={agent.icon}
                alt={`${agent.name} icon`}
                className="w-full h-full rounded-2xl object-cover"
              />
            ) : (
              <i className={agent.icon || 'fa-solid fa-robot'}></i>
            )}
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-3 flex-wrap">
              <span
                className={`px-3 py-1 text-xs uppercase tracking-wide rounded-full ${
                  !hasAccess
                    ? 'bg-cyan-500/10 text-cyan-300'
                    : isExpiringSoon
                      ? 'bg-amber-500/10 text-amber-300'
                      : 'bg-emerald-500/10 text-emerald-300'
                }`}
              >
                {!hasAccess ? 'UNLOCK' : isExpiringSoon ? 'EXPIRING SOON' : 'ACTIVE'}
              </span>
              <h3 className="text-lg font-semibold" style={{ color: 'var(--color-text)' }}>
                {agent.name}
              </h3>
            </div>
            <p className="text-sm mt-1 text-[var(--color-text-secondary)]">
              {!hasAccess
                ? `Buy access to unlock ${agent.name}`
                : purchase
                  ? `${purchase.planName} • ${purchase.daysRemaining} days remaining`
                  : 'Active purchase'}
            </p>
            {hasAccess && purchase && (
              <p className="text-xs mt-1 text-[var(--color-text-secondary)]">
                Expires: {formatExpiryDate(purchase.expiresAt)}
              </p>
            )}
          </div>
        </div>
      </div>

      <div className="mt-6 flex gap-3">
        <button
          type="button"
          onClick={e => {
            e.stopPropagation();
            if (hasAccess) {
              onStartChat(agent);
            } else {
              onBuyAccess(agent);
            }
          }}
          className={`flex-1 px-4 py-2.5 rounded-lg font-semibold text-sm transition ${
            hasAccess
              ? 'bg-emerald-500/15 text-emerald-200 hover:bg-emerald-500/25'
              : 'bg-[var(--color-primary)]/20 text-[var(--color-primary)] hover:bg-[var(--color-primary)]/30'
          }`}
        >
          {hasAccess ? 'Start Chat' : 'Buy Access'}
        </button>

        <button
          type="button"
          onClick={e => {
            e.stopPropagation();
            if (hasAccess && purchase) {
              onCancelAccess(agent, purchase);
            } else {
              onBuyAccess(agent);
            }
          }}
          className="px-4 py-2.5 rounded-lg bg-[var(--color-surface)]/70 text-[var(--color-text-secondary)] hover:text-[var(--color-text)] text-sm font-semibold transition"
        >
          {hasAccess ? 'Cancel Access' : 'View Plans'}
        </button>
      </div>
    </div>
  );
};

const SubscriptionsSection: React.FC<SubscriptionsSectionProps> = ({
  agents: propAgents,
  showOnlyPurchased,
}) => {
  const { state, setState, selectAgent, navigate, refreshAppData, selectAgentForSubscription } =
    useApp();

  // Get purchases from state (loaded from /api/purchases/active)
  const purchases = (state as any).agentSubscriptions || [];
  const purchasesByAgentId = useMemo(() => {
    const map: Record<string, AgentPurchase> = {};
    purchases.forEach((p: any) => {
      if (p.agentId && p.status === 'active') {
        map[p.agentId] = p;
      }
    });
    return map;
  }, [purchases]);

  const agentsToDisplay = useMemo(() => {
    const baseAgents = propAgents && propAgents.length > 0 ? propAgents : ALL_AGENTS;

    if (!showOnlyPurchased) {
      return baseAgents;
    }

    const purchasedIds = new Set(
      purchases.filter((p: any) => p.agentId && p.status === 'active').map((p: any) => p.agentId)
    );

    return baseAgents.filter(agent => purchasedIds.has(agent.id));
  }, [propAgents, showOnlyPurchased, purchases]);

  const handleBuyAccess = (agent: Agent) => {
    selectAgentForSubscription(agent);
  };

  const handleStartChat = (agent: Agent) => {
    selectAgent(agent);
  };

  const handleCancelAccess = async (agent: Agent, _purchase: AgentPurchase) => {
    const confirmed = window.confirm(
      `Are you sure you want to cancel access to ${agent.name}? You can purchase again later with any plan.`
    );

    if (!confirmed) return;

    try {
      const response = await fetch(`/api/agents/${encodeURIComponent(agent.id)}/cancel`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({ reason: 'User requested cancellation from dashboard' }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}) as any);
        const message =
          (errorData && (errorData.error || errorData.message)) || 'Cancellation failed';
        notificationService.error('Unable to cancel access', message);
        return;
      }

      notificationService.success('Access cancelled', `${agent.name} can now be purchased again.`);

      // Refresh subscriptions from backend so UI reflects the change
      try {
        await refreshAppData();
      } catch (refreshError) {
        console.error('Failed to refresh app data after cancellation:', refreshError);
        // Fallback: optimistically remove from local state
        setState(prev => ({
          ...prev,
          agentSubscriptions: prev.agentSubscriptions.filter(p => p.agentId !== agent.id),
          agentSubscriptionsById: Object.fromEntries(
            Object.entries(prev.agentSubscriptionsById).filter(([key]) => key !== agent.id)
          ),
        }));
      }
    } catch (error: any) {
      console.error('Cancel access error:', error);
      notificationService.error('Cancellation failed', error?.message || 'Please try again later');
    }
  };

  return (
    <div className="p-8 space-y-8">
      <div>
        <h2 className="text-2xl font-bold mb-2" style={{ color: 'var(--color-text)' }}>
          Your Agent Access
        </h2>
        <p className="text-[var(--color-text-secondary)] max-w-3xl">
          Buy one-time access to any AI agent. No recurring subscriptions - just pay once and get
          access for the duration you choose (daily, weekly, or monthly).
        </p>
      </div>

      {agentsToDisplay.length === 0 ? (
        <div className="mt-6 text-sm text-[var(--color-text-secondary)]">
          {showOnlyPurchased
            ? 'You do not have any active agent access yet. Visit Agent Management to unlock an agent.'
            : 'No agents available.'}
        </div>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
          {agentsToDisplay.map(agent => {
            const purchase = purchasesByAgentId[agent.id] || null;

            return (
              <AgentPurchaseCard
                key={agent.id}
                agent={agent}
                purchase={purchase}
                onBuyAccess={handleBuyAccess}
                onStartChat={handleStartChat}
                onCancelAccess={handleCancelAccess}
              />
            );
          })}
        </div>
      )}
    </div>
  );
};

export default SubscriptionsSection;
