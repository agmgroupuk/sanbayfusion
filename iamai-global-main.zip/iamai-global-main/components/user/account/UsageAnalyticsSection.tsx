import React, { useEffect, useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface UsageData {
  name: string;
  messages: number;
}

interface DashboardStats {
  totalMessages: number;
  favoriteAgent: string;
  activeSince: string;
  documentsAnalyzed: number;
  agentUsage: UsageData[];
}

interface AnalyticsAgentBreakdownItem {
  agentId: string;
  agentName: string;
  totalMessages: number;
  totalSessions: number;
  totalTime: number;
  averageRating: number;
  lastUsed?: string;
}

interface AnalyticsTimeSeriesItem {
  date: string | Date;
  messages: number;
  sessions: number;
  timeSpent: number;
  agentsUsed: number;
}

interface AnalyticsPeaks {
  bestDay: { date: string | Date; messages: number } | null;
  peakHour: any;
  mostActiveAgent: AnalyticsAgentBreakdownItem | null;
}

interface AnalyticsData {
  totals: {
    messages: number;
    sessions: number;
    timeSpent: number;
  };
  agentBreakdown: AnalyticsAgentBreakdownItem[];
  timeSeries: AnalyticsTimeSeriesItem[];
  peaks: AnalyticsPeaks;
}

const StatCard: React.FC<{ label: string; value: string; icon: string }> = ({
  label,
  value,
  icon,
}) => (
  <div className="bg-[var(--color-surface)]/50 border border-[var(--color-border)] rounded-lg p-4">
    <div className="flex items-center text-[var(--color-text-secondary)] text-sm mb-2">
      <i className={`fa-solid ${icon} mr-2`}></i>
      {label}
    </div>
    <p className="text-3xl font-bold text-[var(--color-text)]">{value}</p>
  </div>
);

const UsageAnalyticsSection: React.FC = () => {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardAnalytics();
  }, []);

  const fetchDashboardAnalytics = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/dashboard/analytics?period=month', {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
      });

      if (!response.ok) {
        throw new Error(`Failed to fetch analytics: ${response.status}`);
      }

      const json = await response.json();
      const data: AnalyticsData | undefined = json?.data;

      if (!data) {
        throw new Error('Analytics response missing data field');
      }

      const favoriteAgentName = data.peaks?.mostActiveAgent?.agentName || 'None';

      const firstActiveDate =
        data.timeSeries && data.timeSeries.length > 0
          ? data.timeSeries[0].date
          : undefined;

      const transformedStats: DashboardStats = {
        totalMessages: data.totals?.messages || 0,
        favoriteAgent: favoriteAgentName,
        activeSince: firstActiveDate ? formatDate(firstActiveDate as string) : 'Recently',
        // Documents analyzed are not explicitly tracked in analytics yet;
        // keep this as 0 for now so the card is stable.
        documentsAnalyzed: 0,
        agentUsage: (data.agentBreakdown || []).map(agent => ({
          name: agent.agentName || 'Unknown Agent',
          messages: agent.totalMessages || 0,
        })),
      };

      setStats(transformedStats);
    } catch (error) {
      console.error('Error fetching dashboard analytics:', error);
      // Set default empty stats on error
      setStats({
        totalMessages: 0,
        favoriteAgent: 'None',
        activeSince: 'Recently',
        documentsAnalyzed: 0,
        agentUsage: [],
      });
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateInput: string | Date | undefined): string => {
    if (!dateInput) return 'Recently';
    const date = new Date(dateInput);
    return date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
  };

  const renderChart = () => {
    if (loading) {
      return (
        <div className="w-full h-full flex items-center justify-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[var(--color-primary)]"></div>
        </div>
      );
    }

    const usageData = stats?.agentUsage || [];

    if (usageData.length === 0) {
      return (
        <div className="w-full h-full flex items-center justify-center bg-[var(--color-surface)]/30 rounded-lg">
          <div className="text-center text-[var(--color-text-secondary)]">
            <i className="fa-solid fa-chart-bar text-4xl mb-4"></i>
            <p className="text-lg font-semibold mb-2">No Usage Data</p>
            <p className="text-sm">Start using agents to see your analytics</p>
          </div>
        </div>
      );
    }

    try {
      return (
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={usageData} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#4B5563" />
            <XAxis
              dataKey="name"
              stroke="#9CA3AF"
              fontSize={12}
              tickLine={false}
              axisLine={false}
            />
            <YAxis stroke="#9CA3AF" fontSize={12} tickLine={false} axisLine={false} />
            <Tooltip
              contentStyle={{
                background: '#1F2937',
                border: '1px solid #374151',
                borderRadius: '0.5rem',
              }}
              labelStyle={{ color: '#F9FAFB' }}
            />
            <Bar dataKey="messages" fill="#06b6d4" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      );
    } catch (error) {
      console.error('Error rendering chart:', error);
      return (
        <div className="w-full h-full flex items-center justify-center bg-[var(--color-surface)]/30 rounded-lg">
          <div className="text-center text-[var(--color-text-secondary)]">
            <i className="fa-solid fa-exclamation-triangle text-4xl mb-4"></i>
            <p className="text-lg font-semibold mb-2">Chart Unavailable</p>
            <p className="text-sm">Unable to load chart visualization</p>
          </div>
        </div>
      );
    }
  };

  return (
    <div className="p-8">
      <h2 className="text-2xl font-bold text-[var(--color-text)] mb-6">Usage Analytics</h2>

      {loading ? (
        <div className="flex justify-center items-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[var(--color-primary)]"></div>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <StatCard
              label="Total Messages Sent"
              value={stats?.totalMessages?.toLocaleString() || '0'}
              icon="fa-paper-plane"
            />
            <StatCard
              label="Favorite Agent"
              value={stats?.favoriteAgent || 'None'}
              icon="fa-heart"
            />
            <StatCard
              label="Active Since"
              value={stats?.activeSince || 'Recently'}
              icon="fa-calendar-alt"
            />
            <StatCard
              label="Documents Analyzed"
              value={stats?.documentsAnalyzed.toLocaleString() || '0'}
              icon="fa-file-pdf"
            />
          </div>

          <div className="bg-[var(--color-surface)]/50 border border-[var(--color-border)] rounded-lg p-6 h-96">
            <h3 className="text-lg font-semibold text-[var(--color-text)] mb-4">
              Messages by Agent
            </h3>
            {renderChart()}
          </div>
        </>
      )}
    </div>
  );
};

export default UsageAnalyticsSection;
