import React, { useState, useEffect, useRef } from 'react';
import { Agent } from '../../../constants';
import { GoogleGenAI } from '@google/genai';

const AVAILABLE_ICONS = [
  'fa-solid fa-robot',
  'fa-solid fa-user-tie',
  'fa-solid fa-heart',
  'fa-solid fa-brain',
  'fa-solid fa-file-pdf',
  'fa-solid fa-comments',
  'fa-solid fa-arrow-trend-up',
  'fa-solid fa-video',
  'fa-solid fa-cogs',
  'fa-solid fa-headset',
  'fa-solid fa-briefcase',
  'fa-solid fa-lightbulb',
  'fa-solid fa-rocket',
  'fa-solid fa-shield-halved',
  'fa-solid fa-wrench',
  'fa-solid fa-code',
];

interface AgentFormPageProps {
  agentToEdit: Agent | null;
  onSave: (agent: Agent) => void;
  onCancel: () => void;
}

const PersonalitySlider: React.FC<{
  name: 'formality' | 'humor' | 'enthusiasm';
  label: string;
  value: number;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  minLabel: string;
  maxLabel: string;
}> = ({ name, label, value, onChange, minLabel, maxLabel }) => (
  <div>
    <div className="flex justify-between items-center mb-1">
      <label className="text-sm font-medium text-gray-300">{label}</label>
      <span className="text-sm font-bold text-cyan-400">{value}</span>
    </div>
    <input
      type="range"
      name={name}
      min="0"
      max="100"
      value={value}
      onChange={onChange}
      className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-cyan-500"
    />
    <div className="flex justify-between text-xs text-gray-500 mt-1">
      <span>{minLabel}</span>
      <span>{maxLabel}</span>
    </div>
  </div>
);

const AgentFormPage: React.FC<AgentFormPageProps> = ({ agentToEdit, onSave, onCancel }) => {
  const [formData, setFormData] = useState({
    name: '',
    role: '',
    description: '',
    icon: AVAILABLE_ICONS[0],
    canAttachFiles: false,
    canAccessWeb: false,
    canUseVoice: false,
    personalityMatrix: {
      formality: 50,
      humor: 50,
      enthusiasm: 50,
    },
  });
  const [customIconPreview, setCustomIconPreview] = useState<string | null>(null);
  const [isGeneratingIcon, setIsGeneratingIcon] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (agentToEdit) {
      setFormData({
        name: agentToEdit.name,
        role: agentToEdit.role,
        description: agentToEdit.description,
        icon: agentToEdit.icon,
        canAttachFiles: agentToEdit.capabilities.canAttachFiles,
        canAccessWeb: agentToEdit.capabilities.canAccessWeb || false,
        canUseVoice: agentToEdit.capabilities.canUseVoice || false,
        // Ensure personalityMatrix exists and has defaults
        personalityMatrix: agentToEdit.personalityMatrix
          ? {
              formality: agentToEdit.personalityMatrix.formality,
              humor: agentToEdit.personalityMatrix.humor,
              enthusiasm: agentToEdit.personalityMatrix.enthusiasm,
            }
          : { formality: 50, humor: 50, enthusiasm: 50 },
      });
      if (agentToEdit.icon && agentToEdit.icon.startsWith('data:image')) {
        setCustomIconPreview(agentToEdit.icon);
      } else {
        setCustomIconPreview(null);
      }
    } else {
      setFormData({
        name: '',
        role: '',
        description: '',
        icon: AVAILABLE_ICONS[0],
        canAttachFiles: false,
        canAccessWeb: false,
        canUseVoice: false,
        personalityMatrix: { formality: 50, humor: 50, enthusiasm: 50 },
      });
      setCustomIconPreview(null);
    }
  }, [agentToEdit]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    if (type === 'checkbox') {
      const { checked } = e.target as HTMLInputElement;
      setFormData(prev => ({ ...prev, [name]: checked }));
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handlePersonalityChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      personalityMatrix: {
        ...prev.personalityMatrix,
        [name]: Number(value),
      },
    }));
  };

  const handleIconSelect = (icon: string) => {
    setFormData(prev => ({ ...prev, icon }));
    setCustomIconPreview(null);
  };

  const handleCustomIconUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        setFormData(prev => ({ ...prev, icon: base64String }));
        setCustomIconPreview(base64String);
      };
      reader.readAsDataURL(file);
    }
    e.target.value = ''; // Reset file input
  };

  const handleGenerateIcon = async () => {
    if (!process.env.API_KEY) {
      alert('API_KEY environment variable not set. Cannot generate image.');
      return;
    }
    if (!formData.name || !formData.role) {
      alert('Please fill in the Agent Name and Role before generating an icon.');
      return;
    }
    setIsGeneratingIcon(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const prompt = `Create a unique, visually appealing, abstract, minimalist, circular logo avatar for an AI agent.
            Agent Name: "${formData.name}"
            Agent Role: "${formData.role}"
            Description: "${formData.description}"
            The logo should be modern, clean, and suitable for a tech product. Avoid text and realistic images. Focus on abstract shapes, simple lines, and elegant color gradients.`;

      const response = await ai.models.generateImages({
        model: 'imagen-4.0-generate-001',
        prompt: prompt,
        config: {
          numberOfImages: 1,
          outputMimeType: 'image/png',
          aspectRatio: '1:1',
        },
      });

      const base64ImageBytes = response.generatedImages[0].image.imageBytes;
      const imageUrl = `data:image/png;base64,${base64ImageBytes}`;
      setFormData(prev => ({ ...prev, icon: imageUrl }));
      setCustomIconPreview(imageUrl);
    } catch (error) {
      console.error('Error generating icon:', error);
      alert('Failed to generate icon. Please check the console for details.');
    } finally {
      setIsGeneratingIcon(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Build the capabilities from form data, starting with existing if available
    const capabilities = {
      ...(agentToEdit?.capabilities || {}),
      canAttachFiles: formData.canAttachFiles,
      canAccessWeb: formData.canAccessWeb,
      canUseVoice: formData.canUseVoice,
    };

    // Build the personality matrix from form data, starting with existing if available
    const personalityMatrix = {
      ...(agentToEdit?.personalityMatrix || {}),
      formality: formData.personalityMatrix.formality,
      humor: formData.personalityMatrix.humor,
      enthusiasm: formData.personalityMatrix.enthusiasm,
    };

    // If editing, start with the existing agent object and overwrite
    // If creating, build a new object from scratch
    const finalAgent: Agent = agentToEdit
      ? {
          ...agentToEdit,
          name: formData.name,
          role: formData.role,
          description: formData.description,
          icon: formData.icon,
          capabilities: capabilities,
          personalityMatrix: personalityMatrix,
        }
      : {
          id: '', // Will be assigned in Dashboard component
          name: formData.name,
          role: formData.role,
          description: formData.description,
          icon: formData.icon,
          capabilities: capabilities,
          personalityMatrix: personalityMatrix,
          voicePreferences: {
            // Provide default for new agent
            defaultGender: 'female',
            allowGenderToggle: true,
          },
          // All other optional fields will be undefined
        };

    onSave(finalAgent);
  };

  const pageTitle = agentToEdit ? 'Edit Agent' : 'Create New Agent';
  const pageDescription = agentToEdit
    ? `Editing the details for ${agentToEdit.name}.`
    : 'Define a new specialized agent for your platform.';

  return (
    <div className="flex-1 flex flex-col bg-black overflow-y-auto p-6">
      <header className="mb-6">
        <h1 className="text-2xl font-bold text-white">{pageTitle}</h1>
        <p className="text-sm text-gray-400">{pageDescription}</p>
      </header>

      <form
        onSubmit={handleSubmit}
        className="bg-gray-900/50 border border-gray-800 rounded-xl p-8 space-y-8 max-w-3xl mx-auto w-full"
      >
        {/* Basic Info */}
        <div className="space-y-6">
          <div>
            <label htmlFor="name" className="block text-sm font-medium text-gray-300 mb-1">
              Agent Name
            </label>
            <input
              type="text"
              name="name"
              id="name"
              value={formData.name}
              onChange={handleChange}
              placeholder="e.g., CodeHelper"
              required
              className="w-full bg-gray-800 border border-gray-700 rounded-lg p-2.5 text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
            />
          </div>
          <div>
            <label htmlFor="role" className="block text-sm font-medium text-gray-300 mb-1">
              Role
            </label>
            <input
              type="text"
              name="role"
              id="role"
              value={formData.role}
              onChange={handleChange}
              placeholder="e.g., Code Generation Expert"
              required
              className="w-full bg-gray-800 border border-gray-700 rounded-lg p-2.5 text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
            />
          </div>
          <div>
            <label htmlFor="description" className="block text-sm font-medium text-gray-300 mb-1">
              Description / Persona
            </label>
            <textarea
              name="description"
              id="description"
              value={formData.description}
              onChange={handleChange}
              required
              rows={4}
              placeholder="Describe the agent's personality and purpose."
              className="w-full bg-gray-800 border border-gray-700 rounded-lg p-2.5 text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
            ></textarea>
          </div>
        </div>

        {/* Icon Section */}
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Icon</label>
          <div className="flex items-center gap-4 mb-3">
            <div className="w-20 h-20 flex-shrink-0 bg-gray-800 border border-gray-700 rounded-lg flex items-center justify-center">
              {customIconPreview ? (
                <img
                  src={customIconPreview}
                  alt="Custom Icon Preview"
                  className="w-full h-full object-cover rounded-lg"
                />
              ) : (
                <i className={`${formData.icon} text-4xl text-cyan-400`}></i>
              )}
            </div>
            <div className="flex-grow">
              <p className="text-sm text-gray-400 mb-2">
                Select a predefined icon below or upload your own image.
              </p>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="px-4 py-2 text-sm bg-gray-700 text-white font-semibold rounded-lg hover:bg-gray-600 transition-colors"
                >
                  <i className="fa-solid fa-upload mr-2"></i>Upload Image
                </button>
                <button
                  type="button"
                  onClick={handleGenerateIcon}
                  disabled={isGeneratingIcon}
                  className="px-4 py-2 text-sm bg-cyan-600 text-white font-semibold rounded-lg hover:bg-cyan-500 transition-colors disabled:bg-gray-600 disabled:cursor-wait"
                >
                  {isGeneratingIcon ? (
                    <>
                      <i className="fa-solid fa-spinner fa-spin mr-2"></i>Generating...
                    </>
                  ) : (
                    <>
                      <i className="fa-solid fa-wand-magic-sparkles mr-2"></i>Generate with AI
                    </>
                  )}
                </button>
              </div>
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleCustomIconUpload}
                accept="image/png, image/jpeg, image/gif, image/webp"
                className="hidden"
              />
            </div>
          </div>
          <div className="grid grid-cols-8 gap-2 p-3 bg-gray-800 border border-gray-700 rounded-lg">
            {AVAILABLE_ICONS.map(icon => (
              <button
                type="button"
                key={icon}
                onClick={() => handleIconSelect(icon)}
                title={icon}
                className={`flex items-center justify-center w-full aspect-square rounded-lg transition-all duration-200 ${formData.icon === icon && !customIconPreview ? 'bg-cyan-500 text-black scale-110 ring-2 ring-cyan-300' : 'bg-gray-700 text-gray-300 hover:bg-gray-600'}`}
              >
                <i className={`${icon} text-2xl`}></i>
              </button>
            ))}
          </div>
        </div>

        {/* Personality Traits */}
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Personality Traits</label>
          <div className="space-y-4 p-4 bg-gray-800 border border-gray-700 rounded-lg">
            <PersonalitySlider
              name="formality"
              label="Formality"
              value={formData.personalityMatrix.formality}
              onChange={handlePersonalityChange}
              minLabel="Casual"
              maxLabel="Formal"
            />
            <PersonalitySlider
              name="humor"
              label="Humor"
              value={formData.personalityMatrix.humor}
              onChange={handlePersonalityChange}
              minLabel="Serious"
              maxLabel="Witty"
            />
            <PersonalitySlider
              name="enthusiasm"
              label="Enthusiasm"
              value={formData.personalityMatrix.enthusiasm}
              onChange={handlePersonalityChange}
              minLabel="Reserved"
              maxLabel="Eager"
            />
          </div>
        </div>

        {/* Capabilities */}
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Capabilities</label>
          <div className="space-y-4">
            <div className="relative flex items-start bg-gray-800 border border-gray-700 rounded-lg p-3">
              <div className="flex h-6 items-center">
                <input
                  id="canAttachFiles"
                  name="canAttachFiles"
                  type="checkbox"
                  checked={formData.canAttachFiles}
                  onChange={handleChange}
                  className="h-4 w-4 rounded border-gray-600 bg-gray-700 text-cyan-600 focus:ring-cyan-600"
                />
              </div>
              <div className="ml-3 text-sm leading-6">
                <label
                  htmlFor="canAttachFiles"
                  className="font-medium text-gray-300 cursor-pointer"
                >
                  Can Attach Files
                </label>
                <p className="text-gray-500">
                  Allows agent to receive and process file attachments (e.g., PDFs).
                </p>
              </div>
            </div>
            <div className="relative flex items-start bg-gray-800 border border-gray-700 rounded-lg p-3">
              <div className="flex h-6 items-center">
                <input
                  id="canAccessWeb"
                  name="canAccessWeb"
                  type="checkbox"
                  checked={formData.canAccessWeb}
                  onChange={handleChange}
                  className="h-4 w-4 rounded border-gray-600 bg-gray-700 text-cyan-600 focus:ring-cyan-600"
                />
              </div>
              <div className="ml-3 text-sm leading-6">
                <label htmlFor="canAccessWeb" className="font-medium text-gray-300 cursor-pointer">
                  Can Access Web
                </label>
                <p className="text-gray-500">
                  Enables the agent to search the web for real-time information.
                </p>
              </div>
            </div>
            <div className="relative flex items-start bg-gray-800 border border-gray-700 rounded-lg p-3">
              <div className="flex h-6 items-center">
                <input
                  id="canUseVoice"
                  name="canUseVoice"
                  type="checkbox"
                  checked={formData.canUseVoice}
                  onChange={handleChange}
                  className="h-4 w-4 rounded border-gray-600 bg-gray-700 text-cyan-600 focus:ring-cyan-600"
                />
              </div>
              <div className="ml-3 text-sm leading-6">
                <label htmlFor="canUseVoice" className="font-medium text-gray-300 cursor-pointer">
                  Can Use Voice
                </label>
                <p className="text-gray-500">
                  Enables text-to-speech and speech-to-text capabilities.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex justify-end space-x-4 pt-6 border-t border-gray-800">
          <button
            type="button"
            onClick={onCancel}
            className="px-5 py-2.5 bg-gray-700 text-white font-semibold rounded-lg hover:bg-gray-600 transition-colors"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="px-5 py-2.5 bg-cyan-500 text-black font-semibold rounded-lg hover:bg-cyan-400 transition-colors"
          >
            Save Agent
          </button>
        </div>
      </form>
    </div>
  );
};

export default AgentFormPage;
