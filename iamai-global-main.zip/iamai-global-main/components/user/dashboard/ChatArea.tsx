import React, { useRef, useEffect, useState } from 'react';
import { Message, AIModel, Agent } from '../../../constants';
import ModelSelector from './ModelSelector';
import FeedbackControls from './FeedbackControls';
import AgentSettingsModal from './AgentSettingsModal';

interface AttachedFile {
  name: string;
  data: string;
  mimeType: string;
}

interface AgentSettings {
  maxTokens: number;
  temperature: number;
  tone: 'professional' | 'casual' | 'friendly' | 'technical' | 'creative';
  personality: 'balanced' | 'concise' | 'detailed' | 'humorous' | 'formal';
  systemPrompt: string;
}

interface ChatAreaProps {
  agent: Agent | null;
  messages: Message[];
  onSendMessage: (content: string) => void;
  isLoading: boolean;
  attachedFile: AttachedFile | null;
  onFileAttach: (file: File) => void;
  onFileRemove: () => void;
  onPreviewFile: () => void;
  selectedModel: AIModel;
  onSelectModel: (modelId: string) => void;
  input: string;
  setInput: (value: string) => void;
  onFeedback: (messageId: number, rating: 'good' | 'bad', comment?: string) => void;
  onClearChat: () => void;
  agentVoiceGender: 'male' | 'female';
  onVoiceGenderChange: (gender: 'male' | 'female') => void;
  agentSettings?: AgentSettings;
  onSaveAgentSettings?: (settings: AgentSettings) => void;
}

const Sources: React.FC<{ sources: { uri: string; title: string }[] }> = ({ sources }) => (
  <div className="mt-3 pt-3 border-t border-gray-700/50">
    <h4 className="text-xs font-semibold text-gray-400 mb-2 flex items-center">
      <i className="fa-solid fa-earth-americas mr-2"></i>
      Sources
    </h4>
    <div className="flex flex-wrap gap-2">
      {sources.map((source, index) => (
        <a
          key={index}
          href={source.uri}
          target="_blank"
          rel="noopener noreferrer"
          title={source.title}
          className="flex items-center gap-1.5 text-xs bg-gray-700/50 hover:bg-gray-700 text-cyan-400 px-2 py-1 rounded-full transition-colors"
        >
          <span>{index + 1}</span>
          <span className="truncate max-w-[200px]">
            {source.title || new URL(source.uri).hostname}
          </span>
          <i className="fa-solid fa-arrow-up-right-from-square text-gray-500 text-[10px]"></i>
        </a>
      ))}
    </div>
  </div>
);

const ChatArea: React.FC<ChatAreaProps> = ({
  agent,
  messages,
  onSendMessage,
  isLoading,
  attachedFile,
  onFileAttach,
  onFileRemove,
  onPreviewFile,
  selectedModel,
  onSelectModel,
  input,
  setInput,
  onFeedback,
  onClearChat,
  agentVoiceGender,
  onVoiceGenderChange,
  agentSettings,
  onSaveAgentSettings,
}) => {
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isListening, setIsListening] = useState(false);
  const recognitionRef = useRef<any | null>(null);
  const [speakingMessageId, setSpeakingMessageId] = useState<number | null>(null);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [showAgentSettings, setShowAgentSettings] = useState(false);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(scrollToBottom, [messages]);

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      const scrollHeight = textareaRef.current.scrollHeight;
      textareaRef.current.style.height = `${scrollHeight}px`;
    }
  }, [input]);

  // Load system voices for TTS
  useEffect(() => {
    const loadVoices = () => {
      const availableVoices = window.speechSynthesis.getVoices();
      if (availableVoices.length > 0) {
        setVoices(availableVoices);
      }
    };
    loadVoices();
    window.speechSynthesis.onvoiceschanged = loadVoices;
    return () => {
      window.speechSynthesis.onvoiceschanged = null;
      window.speechSynthesis.cancel();
    };
  }, []);

  useEffect(() => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.lang = 'en-US';
      recognition.interimResults = false;

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInput(input ? `${input} ${transcript}` : transcript);
        setIsListening(false);
      };

      recognition.onerror = (event: any) => {
        console.error('Speech recognition error:', event.error);
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
    } else {
      console.warn('Speech recognition not supported in this browser.');
    }

    return () => {
      recognitionRef.current?.abort();
    };
  }, [setInput, input]);

  const handleToggleListening = () => {
    const recognition = recognitionRef.current;
    if (!recognition) return;

    if (isListening) {
      recognition.stop();
      setIsListening(false);
    } else {
      recognition.start();
      setIsListening(true);
    }
  };

  const handleStopSpeaking = () => {
    window.speechSynthesis.cancel();
    setSpeakingMessageId(null);
  };

  const handleSpeak = (text: string, messageId: number) => {
    if (speakingMessageId === messageId) {
      handleStopSpeaking();
      return;
    }
    if (window.speechSynthesis.speaking) {
      window.speechSynthesis.cancel();
    }
    if (!voices.length) {
      alert('Text-to-speech is not available or still loading.');
      return;
    }

    const utterance = new SpeechSynthesisUtterance(text);
    const targetGender = agent!.voicePreferences.allowGenderToggle
      ? agentVoiceGender
      : agent!.voicePreferences.defaultGender;
    const filteredVoices = voices.filter(voice => voice.lang.startsWith('en'));

    const selectedVoice =
      filteredVoices.find(
        v => v.name.toLowerCase().includes('google') && v.name.toLowerCase().includes(targetGender)
      ) ||
      filteredVoices.find(v => v.name.toLowerCase().includes(targetGender)) ||
      filteredVoices.find(
        v => !v.name.toLowerCase().includes(targetGender === 'male' ? 'female' : 'male')
      ) ||
      filteredVoices[0];

    utterance.voice = selectedVoice;
    utterance.onstart = () => setSpeakingMessageId(messageId);
    utterance.onend = () => setSpeakingMessageId(null);
    utterance.onerror = () => setSpeakingMessageId(null);

    window.speechSynthesis.speak(utterance);
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if ((input.trim() || attachedFile) && agent && !isLoading) {
      onSendMessage(input.trim());
      setInput('');
    }
  };

  const handleFileIconClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileSelected = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onFileAttach(file);
    }
    e.target.value = '';
  };

  if (!agent) {
    return (
      <div className="flex-1 flex items-center justify-center text-gray-500">
        Select an agent to start chatting.
      </div>
    );
  }

  const isFileAttachDisabled = !agent.capabilities.canAttachFiles;
  const speechRecognitionSupported = !!recognitionRef.current;

  return (
    <div className="flex-1 flex flex-col bg-black rounded-l-2xl">
      <header className="flex items-center justify-between p-4 border-b border-gray-800 flex-shrink-0">
        <div className="flex items-center">
          <div className="w-10 h-10 flex items-center justify-center rounded-lg bg-gray-800 mr-4 text-cyan-400">
            {agent.icon && agent.icon.startsWith('data:image') ? (
              <img
                src={agent.icon}
                alt={`${agent.name} icon`}
                className="w-full h-full object-cover rounded-lg"
              />
            ) : (
              <i className={`${agent.icon} text-2xl`}></i>
            )}
          </div>
          <div>
            <h2 className="text-lg font-bold text-white">{agent.name}</h2>
            <p className="text-sm text-cyan-400">{agent.role}</p>
          </div>
        </div>
        <div className="flex items-center space-x-4">
          {agent.voicePreferences.allowGenderToggle && (
            <div className="flex items-center space-x-1 bg-gray-800/50 border border-gray-700 rounded-md p-1">
              <button
                onClick={() => onVoiceGenderChange('female')}
                className={`px-2 py-0.5 rounded ${agentVoiceGender === 'female' ? 'bg-cyan-500/20 text-cyan-300' : 'text-gray-400 hover:bg-gray-700'}`}
                title="Set female voice"
              >
                <i className="fa-solid fa-venus"></i>
              </button>
              <button
                onClick={() => onVoiceGenderChange('male')}
                className={`px-2 py-0.5 rounded ${agentVoiceGender === 'male' ? 'bg-cyan-500/20 text-cyan-300' : 'text-gray-400 hover:bg-gray-700'}`}
                title="Set male voice"
              >
                <i className="fa-solid fa-mars"></i>
              </button>
            </div>
          )}
          <ModelSelector selectedModel={selectedModel} onSelectModel={onSelectModel} />
          <button
            onClick={() => setShowAgentSettings(true)}
            className="text-gray-500 hover:text-cyan-400 transition-colors"
            title="Agent settings"
          >
            <i className="fa-solid fa-gear text-lg"></i>
          </button>
          {messages.length > 1 && (
            <button
              onClick={onClearChat}
              className="text-gray-500 hover:text-red-400 transition-colors"
              title="Clear chat history"
            >
              <i className="fa-solid fa-eraser text-lg"></i>
            </button>
          )}
        </div>
      </header>

      {!agent ? (
        <div className="flex-1 flex items-center justify-center text-gray-500">
          Select an agent to start chatting.
        </div>
      ) : (
        <>
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            {messages.map(message => (
              <div
                key={message.id}
                className={`flex items-start gap-4 ${message.role === 'user' ? 'justify-end' : ''} w-full`}
              >
                {message.role === 'agent' && message.agent && (
                  <div className="w-8 h-8 flex-shrink-0 flex items-center justify-center rounded-full bg-gray-800 text-cyan-400">
                    <i className={`${message.agent.icon} w-5 h-5`}></i>
                  </div>
                )}
                <div className={`max-w-lg ${message.role === 'user' ? 'ml-auto' : ''}`}>
                  <div
                    className={`p-4 rounded-2xl ${message.role === 'user' ? 'bg-cyan-600 text-white rounded-br-none' : 'bg-gray-800 text-gray-300 rounded-bl-none'}`}
                  >
                    <p className="text-sm whitespace-pre-wrap">
                      {message.content}
                      {isLoading && message.id === messages[messages.length - 1].id ? (
                        <span className="animate-pulse">▍</span>
                      ) : (
                        ''
                      )}
                    </p>
                    {message.sources && message.sources.length > 0 && (
                      <Sources sources={message.sources} />
                    )}
                  </div>
                  {message.role === 'agent' && !isLoading && message.content && (
                    <div className="flex items-center">
                      <FeedbackControls
                        messageId={message.id}
                        feedback={message.feedback}
                        onFeedback={onFeedback}
                      />
                      <button
                        onClick={() => handleSpeak(message.content, message.id)}
                        className={`ml-3 text-gray-500 hover:text-cyan-400 transition-colors ${speakingMessageId === message.id ? 'text-cyan-400' : ''}`}
                        title={speakingMessageId === message.id ? 'Stop speaking' : 'Read aloud'}
                      >
                        <i
                          className={`fa-solid fa-volume-high ${speakingMessageId === message.id ? 'animate-pulse-strong' : ''}`}
                        ></i>
                      </button>
                    </div>
                  )}
                </div>
                {message.role === 'user' && (
                  <img
                    src="https://picsum.photos/100/100?random=42"
                    alt="User Avatar"
                    className="w-8 h-8 rounded-full"
                  />
                )}
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          <div className="p-6 bg-black border-t border-gray-800 flex-shrink-0">
            {attachedFile && (
              <div className="mb-2">
                <div
                  className="group relative inline-flex items-center bg-gray-700 text-white text-sm font-medium px-3 py-1.5 rounded-lg cursor-pointer"
                  onClick={onPreviewFile}
                  title={`Preview ${attachedFile.name}`}
                >
                  <i className="fa-solid fa-file-pdf mr-2 text-red-400"></i>
                  <span className="truncate max-w-xs">{attachedFile.name}</span>
                  <button
                    onClick={e => {
                      e.stopPropagation();
                      onFileRemove();
                    }}
                    className="ml-2 text-gray-400 hover:text-white"
                    aria-label="Remove file"
                    title="Remove attached file"
                  >
                    <i className="fa-solid fa-times"></i>
                  </button>
                </div>
              </div>
            )}
            <form onSubmit={handleSendMessage} className="relative">
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileSelected}
                className="hidden"
                accept="application/pdf"
                disabled={isFileAttachDisabled}
              />
              <textarea
                ref={textareaRef}
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={e => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSendMessage(e);
                  }
                }}
                placeholder={`Message ${agent.name}...`}
                className="w-full bg-gray-900 border border-gray-700 rounded-lg p-4 pr-36 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-cyan-500 resize-none disabled:bg-gray-800 overflow-y-hidden"
                rows={1}
                disabled={isLoading}
              />
              <div className="absolute right-4 top-1/2 -translate-y-1/2 flex items-center space-x-4">
                <div className="relative group">
                  <button
                    type="button"
                    onClick={handleFileIconClick}
                    className="text-gray-400 hover:text-cyan-400 disabled:text-gray-600 disabled:cursor-not-allowed transition-colors"
                    disabled={isFileAttachDisabled}
                    aria-label="Attach file"
                    title={
                      isFileAttachDisabled
                        ? 'File attachment is only available for PDFMind'
                        : 'Attach a PDF file'
                    }
                  >
                    <i className="fa-solid fa-paperclip text-xl"></i>
                  </button>
                  {isFileAttachDisabled && (
                    <div className="absolute bottom-full mb-2 w-max max-w-xs bg-gray-800 text-white text-xs rounded py-1 px-2 pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity whitespace-normal right-1/2 translate-x-1/2">
                      File attachment is only available for PDFMind.
                    </div>
                  )}
                </div>
                <button
                  type="button"
                  onClick={handleToggleListening}
                  disabled={!speechRecognitionSupported || isLoading}
                  className={`transition-colors disabled:text-gray-600 disabled:cursor-not-allowed ${isListening ? 'text-red-500 animate-pulse' : 'text-gray-400 hover:text-cyan-400'}`}
                  title={
                    speechRecognitionSupported
                      ? isListening
                        ? 'Stop listening'
                        : 'Use voice input'
                      : 'Voice input not supported by your browser'
                  }
                >
                  <i className="fa-solid fa-microphone text-xl"></i>
                </button>
                <button
                  type="submit"
                  className="text-gray-400 hover:text-cyan-400 disabled:text-gray-600 transition-colors"
                  disabled={(!input.trim() && !attachedFile) || isLoading}
                  title="Send message"
                >
                  <i className="fa-solid fa-paper-plane text-xl"></i>
                </button>
              </div>
            </form>
          </div>
        </>
      )}

      {/* Agent Settings Modal */}
      {agentSettings && onSaveAgentSettings && (
        <AgentSettingsModal
          isOpen={showAgentSettings}
          onClose={() => setShowAgentSettings(false)}
          agent={agent}
          settings={agentSettings}
          onSaveSettings={onSaveAgentSettings}
        />
      )}

      <style>{`
                @keyframes pulse-strong {
                    50% { opacity: .5; }
                }
                .animate-pulse-strong { animation: pulse-strong 1s cubic-bezier(0.4, 0, 0.6, 1) infinite; }
            `}</style>
    </div>
  );
};

export default ChatArea;
