import React from 'react';

const AddAgentPage: React.FC = () => {
  return (
    <div className="flex-1 flex flex-col items-center justify-center text-center bg-black p-6">
      <div className="w-24 h-24 flex items-center justify-center rounded-2xl bg-gray-900 border border-gray-800 mb-6">
          <i className="fa-solid fa-plus text-5xl text-gray-700"></i>
      </div>
      <h1 className="text-3xl font-bold text-white">Agent Creation Studio</h1>
      <p className="max-w-md mx-auto mt-2 text-gray-400">
        This is where you'll be able to create, customize, and deploy your own specialized AI agents.
      </p>
      <div className="mt-6 p-4 bg-cyan-900/50 border border-cyan-500/30 rounded-lg text-cyan-300 text-sm">
        <p><i className="fa-solid fa-hammer mr-2"></i> This feature is currently under construction. Stay tuned!</p>
      </div>
    </div>
  );
};

export default AddAgentPage;
