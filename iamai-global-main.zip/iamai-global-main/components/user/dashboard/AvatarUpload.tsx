import React, { useState, useRef, useCallback } from 'react';
import { Upload, X, Check, Crop, RotateCw, ZoomIn, ZoomOut, AlertCircle } from 'lucide-react';
import dashboardStorage from '../../../services/user/dashboardStorage';

interface AvatarUploadProps {
  currentAvatar?: string;
  onUpload: (avatar: string) => void;
  onClose: () => void;
}

const AvatarUpload: React.FC<AvatarUploadProps> = ({ currentAvatar, onUpload, onClose }) => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [zoom, setZoom] = useState(1);
  const [rotation, setRotation] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB
  const ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!ALLOWED_TYPES.includes(file.type)) {
      setError('Please upload a valid image file (JPEG, PNG, WEBP, or GIF)');
      return;
    }

    // Validate file size
    if (file.size > MAX_FILE_SIZE) {
      setError('File size must be less than 5MB');
      return;
    }

    setError(null);
    setSelectedFile(file);

    // Create preview
    const reader = new FileReader();
    reader.onloadend = () => {
      setPreviewUrl(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();

    const file = e.dataTransfer.files[0];
    if (file && ALLOWED_TYPES.includes(file.type)) {
      const fakeEvent = {
        target: { files: [file] },
      } as unknown as React.ChangeEvent<HTMLInputElement>;
      handleFileSelect(fakeEvent);
    }
  };

  const processImage = useCallback(async (): Promise<string> => {
    return new Promise((resolve, reject) => {
      if (!previewUrl || !canvasRef.current) {
        reject('No image to process');
        return;
      }

      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        reject('Failed to get canvas context');
        return;
      }

      const img = new Image();
      img.onload = () => {
        const size = 200; // Output size
        canvas.width = size;
        canvas.height = size;

        // Clear canvas
        ctx.clearRect(0, 0, size, size);

        // Apply transformations
        ctx.save();
        ctx.translate(size / 2, size / 2);
        ctx.rotate((rotation * Math.PI) / 180);
        ctx.scale(zoom, zoom);
        ctx.drawImage(img, -size / 2, -size / 2, size, size);
        ctx.restore();

        // Convert to base64
        const dataUrl = canvas.toDataURL('image/jpeg', 0.9);
        resolve(dataUrl);
      };
      img.onerror = () => reject('Failed to load image');
      img.src = previewUrl;
    });
  }, [previewUrl, zoom, rotation]);

  const processImageAsBlob = useCallback(async (): Promise<Blob> => {
    return new Promise((resolve, reject) => {
      if (!previewUrl || !canvasRef.current) {
        reject('No image to process');
        return;
      }

      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        reject('Failed to get canvas context');
        return;
      }

      const img = new Image();
      img.onload = () => {
        const size = 200; // Output size
        canvas.width = size;
        canvas.height = size;

        // Clear canvas
        ctx.clearRect(0, 0, size, size);

        // Apply transformations
        ctx.save();
        ctx.translate(size / 2, size / 2);
        ctx.rotate((rotation * Math.PI) / 180);
        ctx.scale(zoom, zoom);
        ctx.drawImage(img, -size / 2, -size / 2, size, size);
        ctx.restore();

        // Convert to blob
        canvas.toBlob(
          blob => {
            if (blob) {
              resolve(blob);
            } else {
              reject('Failed to create blob');
            }
          },
          'image/png',
          0.9
        );
      };
      img.onerror = () => reject('Failed to load image');
      img.src = previewUrl;
    });
  }, [previewUrl, zoom, rotation]);

  const handleUpload = async () => {
    if (!selectedFile) return;

    setIsUploading(true);
    setError(null);

    try {
      // Process and crop image
      const processedImageBlob = await processImageAsBlob();

      // Create FormData for upload
      const formData = new FormData();
      formData.append('avatar', processedImageBlob, 'avatar.png');

      const API_BASE =
        window.location.hostname === 'localhost' ? 'http://localhost:3001' : 'https://iamai.global';

      console.log('🔄 Uploading avatar to:', `${API_BASE}/api/users/avatar`);

      const response = await fetch(`${API_BASE}/api/users/avatar`, {
        method: 'POST',
        credentials: 'include',
        body: formData,
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || errorData.error || 'Upload failed');
      }

      const data = await response.json();
      console.log('✅ Avatar uploaded successfully:', data);

      // Update cached auth + profile data with new avatar URL
      try {
        const authRaw = localStorage.getItem('iamai_auth');
        if (authRaw) {
          const authData = JSON.parse(authRaw);
          if (authData.user) {
            authData.user.profileImage = data.avatarUrl;
            authData.user.avatar = data.avatarUrl;
          }
          localStorage.setItem('iamai_auth', JSON.stringify(authData));
        }
      } catch (storageError) {
        console.warn('⚠️ Failed to update local auth cache with avatar:', storageError);
      }

      dashboardStorage.updateAuthData({
        user: {
          ...(dashboardStorage.getAuthData()?.user || {}),
          profileImage: data.avatarUrl,
          avatar: data.avatarUrl,
        },
      });

      try {
        const profileRaw = localStorage.getItem('iamai_user_profile');
        if (profileRaw) {
          const parsedProfile = JSON.parse(profileRaw);
          parsedProfile.profileImage = data.avatarUrl;
          parsedProfile.avatar = data.avatarUrl;
          localStorage.setItem('iamai_user_profile', JSON.stringify(parsedProfile));
        }
      } catch (profileError) {
        console.warn('⚠️ Failed to update cached profile with avatar:', profileError);
      }

      localStorage.setItem('iamai_user_avatar', data.avatarUrl);

      // Call callback with server URL
      onUpload(data.avatarUrl);

      // Success feedback
      setTimeout(() => {
        setIsUploading(false);
        onClose();
      }, 500);
    } catch (err) {
      console.error('Avatar upload error:', err);
      setError(err instanceof Error ? err.message : 'Failed to upload avatar');
      setIsUploading(false);
    }
  };

  const handleReset = () => {
    setSelectedFile(null);
    setPreviewUrl(null);
    setZoom(1);
    setRotation(0);
    setError(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <>
      {/* Backdrop */}
      <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-[100]" onClick={onClose} />

      {/* Modal */}
      <div className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-full max-w-lg z-[101] px-4">
        <div className="bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 border-2 border-cyan-500/30 rounded-2xl shadow-2xl shadow-cyan-500/20 overflow-hidden">
          {/* Header */}
          <div className="relative p-6 border-b border-gray-700">
            <button
              onClick={onClose}
              className="absolute top-4 right-4 text-gray-400 hover:text-white transition-colors"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-2xl font-bold text-white flex items-center">
              <Upload className="w-6 h-6 text-cyan-400 mr-3" />
              Upload Profile Picture
            </h3>
            <p className="text-sm text-gray-400 mt-2">
              Choose an image (JPEG, PNG, WEBP, GIF • Max 5MB)
            </p>
          </div>

          {/* Content */}
          <div className="p-6">
            {!previewUrl ? (
              <>
                {/* Upload Area */}
                <div
                  onDragOver={handleDragOver}
                  onDrop={handleDrop}
                  className="relative border-2 border-dashed border-gray-700 hover:border-cyan-500/50 rounded-xl p-12 text-center transition-all cursor-pointer group"
                  onClick={() => fileInputRef.current?.click()}
                >
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept={ALLOWED_TYPES.join(',')}
                    onChange={handleFileSelect}
                    className="hidden"
                  />

                  <div className="flex flex-col items-center space-y-4">
                    <div className="p-4 bg-gray-800 rounded-full group-hover:bg-cyan-600/20 transition-colors">
                      <Upload className="w-8 h-8 text-gray-400 group-hover:text-cyan-400 transition-colors" />
                    </div>
                    <div>
                      <p className="text-lg font-semibold text-white mb-1">
                        Click to upload or drag & drop
                      </p>
                      <p className="text-sm text-gray-400">JPEG, PNG, WEBP, or GIF (max 5MB)</p>
                    </div>
                  </div>
                </div>

                {/* Current Avatar Preview */}
                {currentAvatar && (
                  <div className="mt-6 p-4 bg-gray-800/50 rounded-xl">
                    <p className="text-sm text-gray-400 mb-3">Current Avatar:</p>
                    <div className="flex items-center space-x-4">
                      <img
                        src={currentAvatar}
                        alt="Current avatar"
                        className="w-16 h-16 rounded-full border-2 border-gray-700"
                      />
                      <p className="text-sm text-gray-500">Upload a new image to replace it</p>
                    </div>
                  </div>
                )}
              </>
            ) : (
              <>
                {/* Image Preview & Editor */}
                <div className="space-y-4">
                  <div
                    className="relative bg-gray-800 rounded-xl p-4 flex items-center justify-center"
                    style={{ minHeight: '300px' }}
                  >
                    <canvas ref={canvasRef} className="hidden" />
                    <img
                      src={previewUrl}
                      alt="Preview"
                      className="max-w-full max-h-64 rounded-lg"
                      style={{
                        transform: `scale(${zoom}) rotate(${rotation}deg)`,
                        transition: 'transform 0.2s ease',
                      }}
                    />
                  </div>

                  {/* Image Controls */}
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium text-gray-400 mb-2 flex items-center">
                        <ZoomIn className="w-4 h-4 mr-2" />
                        Zoom: {(zoom * 100).toFixed(0)}%
                      </label>
                      <input
                        type="range"
                        min="0.5"
                        max="2"
                        step="0.1"
                        value={zoom}
                        onChange={e => setZoom(parseFloat(e.target.value))}
                        className="w-full"
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium text-gray-400 mb-2 flex items-center">
                        <RotateCw className="w-4 h-4 mr-2" />
                        Rotation: {rotation}°
                      </label>
                      <input
                        type="range"
                        min="0"
                        max="360"
                        step="15"
                        value={rotation}
                        onChange={e => setRotation(parseInt(e.target.value))}
                        className="w-full"
                      />
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex space-x-3">
                    <button
                      onClick={handleReset}
                      className="flex-1 px-4 py-2 bg-gray-700 hover:bg-gray-600 text-white rounded-lg transition-colors font-medium"
                    >
                      Choose Different
                    </button>
                    <button
                      onClick={handleUpload}
                      disabled={isUploading}
                      className="flex-1 px-4 py-2 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700 text-white rounded-lg transition-all font-medium shadow-lg shadow-cyan-500/20 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
                    >
                      {isUploading ? (
                        <>
                          <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                          Uploading...
                        </>
                      ) : (
                        <>
                          <Check className="w-4 h-4 mr-2" />
                          Upload
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </>
            )}

            {/* Error Message */}
            {error && (
              <div className="mt-4 p-3 bg-red-500/10 border border-red-500/30 rounded-lg flex items-start space-x-3">
                <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
                <p className="text-sm text-red-400">{error}</p>
              </div>
            )}
          </div>

          {/* Footer Info */}
          <div className="px-6 pb-6">
            <div className="p-3 bg-gray-800/50 rounded-lg">
              <p className="text-xs text-gray-500 text-center">
                💡 Tip: For best results, use a square image with your face centered
              </p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default AvatarUpload;
