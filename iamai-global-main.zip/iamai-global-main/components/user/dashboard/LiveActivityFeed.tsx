/**
 * Live Activity Feed Component
 * Displays real-time user activities with animations and filtering
 */

import React, { useState } from 'react';
import { Activity, MessageSquare, Upload, CreditCard, Download, User, Clock, Filter } from 'lucide-react';

interface ActivityItem {
  id: string;
  userId: string;
  userName: string;
  agentId: string;
  agentName: string;
  action: 'chat' | 'subscribe' | 'upload' | 'export';
  timestamp: string;
  metadata?: any;
}

interface LiveActivityFeedProps {
  activities: ActivityItem[];
  maxItems?: number;
  showFilters?: boolean;
}

const LiveActivityFeed: React.FC<LiveActivityFeedProps> = ({ 
  activities, 
  maxItems = 20,
  showFilters = true 
}) => {
  const [filterAction, setFilterAction] = useState<string>('all');

  // Filter activities
  const filteredActivities = filterAction === 'all'
    ? activities
    : activities.filter(a => a.action === filterAction);

  // Get action icon and color
  const getActionDisplay = (action: string) => {
    switch (action) {
      case 'chat':
        return { 
          icon: <MessageSquare className="w-4 h-4" />, 
          color: 'text-cyan-400 bg-cyan-500/10',
          label: 'Chat'
        };
      case 'subscribe':
        return { 
          icon: <CreditCard className="w-4 h-4" />, 
          color: 'text-green-400 bg-green-500/10',
          label: 'Subscribed'
        };
      case 'upload':
        return { 
          icon: <Upload className="w-4 h-4" />, 
          color: 'text-blue-400 bg-blue-500/10',
          label: 'Uploaded'
        };
      case 'export':
        return { 
          icon: <Download className="w-4 h-4" />, 
          color: 'text-purple-400 bg-purple-500/10',
          label: 'Exported'
        };
      default:
        return { 
          icon: <Activity className="w-4 h-4" />, 
          color: 'text-gray-400 bg-gray-500/10',
          label: 'Activity'
        };
    }
  };

  // Format timestamp
  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours < 24) return `${diffHours}h ago`;
    
    const diffDays = Math.floor(diffHours / 24);
    return `${diffDays}d ago`;
  };

  return (
    <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6 hover:border-cyan-500/30 transition-all">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="relative">
            <Activity className="w-6 h-6 text-cyan-400" />
            <span className="absolute -top-1 -right-1 w-2 h-2 bg-green-400 rounded-full animate-pulse"></span>
          </div>
          <div>
            <h3 className="text-xl font-bold text-white">Live Activity Feed</h3>
            <p className="text-xs text-gray-400">Real-time platform activity</p>
          </div>
        </div>

        {showFilters && (
          <div className="flex items-center space-x-2">
            <Filter className="w-4 h-4 text-gray-400" />
            <select 
              value={filterAction}
              onChange={(e) => setFilterAction(e.target.value)}
              className="bg-gray-800 border border-gray-700 rounded-lg px-3 py-1 text-sm text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
            >
              <option value="all">All Activities</option>
              <option value="chat">Chats</option>
              <option value="subscribe">Subscriptions</option>
              <option value="upload">Uploads</option>
              <option value="export">Exports</option>
            </select>
          </div>
        )}
      </div>

      <div className="space-y-3 max-h-[500px] overflow-y-auto custom-scrollbar">
        {filteredActivities.length === 0 ? (
          <div className="text-center py-12 text-gray-500">
            <Activity className="w-12 h-12 mx-auto mb-3 opacity-30" />
            <p>No activities yet</p>
          </div>
        ) : (
          filteredActivities.slice(0, maxItems).map((activity) => {
            const display = getActionDisplay(activity.action);
            
            return (
              <div
                key={activity.id}
                className="flex items-start space-x-3 p-3 bg-gray-800/30 rounded-lg hover:bg-gray-800/50 transition-all animate-slideIn"
              >
                <div className={`p-2 rounded-lg ${display.color}`}>
                  {display.icon}
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <p className="text-sm text-white">
                        <span className="font-semibold">{activity.userName}</span>
                        {' '}
                        <span className="text-gray-400">
                          {activity.action === 'chat' && `chatted with ${activity.agentName}`}
                          {activity.action === 'subscribe' && `subscribed to ${activity.agentName}`}
                          {activity.action === 'upload' && `uploaded file to ${activity.agentName}`}
                          {activity.action === 'export' && `exported data`}
                        </span>
                      </p>
                      
                      {activity.metadata && (
                        <p className="text-xs text-gray-500 mt-1">
                          {activity.metadata.fileName && `📎 ${activity.metadata.fileName}`}
                          {activity.metadata.plan && `💳 ${activity.metadata.plan} plan`}
                          {activity.metadata.exportType && `📥 ${activity.metadata.exportType}`}
                          {activity.metadata.messageCount && `📊 Message #${activity.metadata.messageCount}`}
                        </p>
                      )}
                    </div>
                    
                    <div className="flex items-center space-x-1 text-xs text-gray-500 ml-2">
                      <Clock className="w-3 h-3" />
                      <span>{formatTimestamp(activity.timestamp)}</span>
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {filteredActivities.length > maxItems && (
        <div className="mt-4 text-center">
          <button className="text-sm text-cyan-400 hover:text-cyan-300 transition-colors">
            View all {filteredActivities.length} activities →
          </button>
        </div>
      )}

      <style>{`
        @keyframes slideIn {
          from {
            opacity: 0;
            transform: translateX(-10px);
          }
          to {
            opacity: 1;
            transform: translateX(0);
          }
        }
        
        .animate-slideIn {
          animation: slideIn 0.3s ease-out;
        }
        
        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
        }
        
        .custom-scrollbar::-webkit-scrollbar-track {
          background: rgba(31, 41, 55, 0.5);
          border-radius: 3px;
        }
        
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(96, 165, 250, 0.3);
          border-radius: 3px;
        }
        
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: rgba(96, 165, 250, 0.5);
        }
      `}</style>
    </div>
  );
};

export default LiveActivityFeed;
