/**
 * 📊 Dashboard Components
 * All dashboard-related components for the user interface
 */

export { default as Dashboard } from './Dashboard';
export { default as Sidebar } from './Sidebar';
export { default as AgentPage } from './AgentPage';
export { default as FilePreviewModal } from './FilePreviewModal';
export { default as AgentProfilePage } from './AgentProfilePage';
export { default as AgentManagementPage } from './AgentManagementPage';
export { default as AgentFormPage } from './AgentFormPage';
export { default as SettingsModal } from './SettingsModal';
export { default as OnboardingTutorial } from './OnboardingTutorial';
export { default as GlobalSearch } from './GlobalSearch';
export { default as ChatArea } from './ChatArea';
export { default as ThemeSwitcher } from './ThemeSwitcher';
export { default as AchievementSystem } from './AchievementSystem';
export { default as LiveActivityFeed } from './LiveActivityFeed';
export { default as NotificationCenter } from './NotificationCenter';
export { default as ModelSelector } from './ModelSelector';
export { default as FeedbackControls } from './FeedbackControls';
export { default as AvatarUpload } from './AvatarUpload';
export { default as AgentSettingsModal } from './AgentSettingsModal';
export { default as AddAgentPage } from './AddAgentPage';

// Widget exports
export * from './widgets';
