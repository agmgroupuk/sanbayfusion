import React from 'react';
import { Agent } from '../../../constants';
import { UniversalAgentChat } from '../../universal-chat';
import { convertAgentToChatConfig } from '../../../agents/agentChatConfig';

interface AgentPageProps {
  agent: Agent;
}

const AgentPage: React.FC<AgentPageProps> = ({ agent }) => {
  // ✨ Using UniversalAgentChat for professional chat experience
  // This ensures Dashboard shows the same advanced chat interface as agent pages

  const chatConfig = convertAgentToChatConfig(agent);
  return <UniversalAgentChat agent={chatConfig} />;
};

export default AgentPage;
