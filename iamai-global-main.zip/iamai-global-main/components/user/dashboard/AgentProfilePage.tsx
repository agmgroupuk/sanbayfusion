import React from 'react';
import { Agent, AIModel } from '../../../constants';
import { AGENT_UI_DATA } from '../../../agents/agentData';
import ModelSelector from './ModelSelector';

// Import all possible widgets
import StatsWidget from './widgets/StatsWidget';
import MemoryWidget from './widgets/MemoryWidget';
import EmotionalStateWidget from './widgets/EmotionalStateWidget';
import RelationshipProgressWidget from './widgets/RelationshipProgressWidget';
import DocumentAnalyticsWidget from './widgets/DocumentAnalyticsWidget';
import RecentFilesWidget from './widgets/RecentFilesWidget';
import ResumeScoreWidget from './widgets/ResumeScoreWidget';
import CareerChecklistWidget from './widgets/CareerChecklistWidget';
import ConversationHealthWidget from './widgets/ConversationHealthWidget';
import ConversationTopicsWidget from './widgets/ConversationTopicsWidget';
import EngagementRateWidget from './widgets/EngagementRateWidget';
import ViralTrendsWidget from './widgets/ViralTrendsWidget';
import GenerationStatsWidget from './widgets/GenerationStatsWidget';
import ContentIdeasWidget from './widgets/ContentIdeasWidget';
import SentimentAnalysisWidget from './widgets/SentimentAnalysisWidget';
import EmotionalTrendWidget from './widgets/EmotionalTrendWidget';

interface AgentProfilePageProps {
  agent: Agent;
  onStartChat: () => void;
  onNextAgent: () => void;
  onPrevAgent: () => void;
  selectedModel: AIModel;
  onSelectModel: (modelId: string) => void;
}

const THEME_CLASSES: Record<
  string,
  { text: string; bg: string; border: string; button: string; buttonHover: string }
> = {
  pink: {
    text: 'text-pink-400',
    bg: 'bg-pink-900/10',
    border: 'border-pink-500/30',
    button: 'bg-pink-500',
    buttonHover: 'hover:bg-pink-400',
  },
  cyan: {
    text: 'text-cyan-400',
    bg: 'bg-cyan-900/10',
    border: 'border-cyan-500/30',
    button: 'bg-cyan-500',
    buttonHover: 'hover:bg-cyan-400',
  },
  red: {
    text: 'text-red-400',
    bg: 'bg-red-900/10',
    border: 'border-red-500/30',
    button: 'bg-red-500',
    buttonHover: 'hover:bg-red-400',
  },
  blue: {
    text: 'text-blue-400',
    bg: 'bg-blue-900/10',
    border: 'border-blue-500/30',
    button: 'bg-blue-500',
    buttonHover: 'hover:bg-blue-400',
  },
  yellow: {
    text: 'text-yellow-400',
    bg: 'bg-yellow-900/10',
    border: 'border-yellow-500/30',
    button: 'bg-yellow-500',
    buttonHover: 'hover:bg-yellow-400',
  },
  purple: {
    text: 'text-purple-400',
    bg: 'bg-purple-900/10',
    border: 'border-purple-500/30',
    button: 'bg-purple-500',
    buttonHover: 'hover:bg-purple-400',
  },
  grey: {
    text: 'text-gray-400',
    bg: 'bg-gray-900/10',
    border: 'border-gray-500/30',
    button: 'bg-gray-500',
    buttonHover: 'hover:bg-gray-400',
  },
  orange: {
    text: 'text-orange-400',
    bg: 'bg-orange-900/10',
    border: 'border-orange-500/30',
    button: 'bg-orange-500',
    buttonHover: 'hover:bg-orange-400',
  },
  green: {
    text: 'text-green-400',
    bg: 'bg-green-900/10',
    border: 'border-green-500/30',
    button: 'bg-green-500',
    buttonHover: 'hover:bg-green-400',
  },
};

const CodeSnippet: React.FC<{ language: string; code: string }> = ({ language, code }) => (
  <div className="bg-gray-800 rounded-lg overflow-hidden my-2">
    <div className="bg-gray-900/80 px-4 py-2 text-xs text-gray-400 font-semibold flex justify-between items-center">
      <span>{language}</span>
      <button
        onClick={() => navigator.clipboard.writeText(code)}
        title="Copy code"
        className="text-gray-500 hover:text-white transition-colors"
      >
        <i className="fa-solid fa-copy"></i>
      </button>
    </div>
    <pre className="p-4 text-sm text-white overflow-x-auto">
      <code>{code}</code>
    </pre>
  </div>
);

const InfoGrid: React.FC<{
  title: string;
  data: Record<string, boolean | string | number> | undefined;
  iconMap?: Record<string, string>;
}> = ({ title, data, iconMap }) => {
  if (!data || Object.keys(data).length === 0) return null;

  const formatKey = (key: string) =>
    key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());

  return (
    <div className="border-t border-gray-800 pt-6 mt-6">
      <h3 className="text-lg font-semibold text-white mb-4">{title}</h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {Object.entries(data).map(([key, value]) => (
          <div key={key} className="flex items-center bg-gray-800/50 p-3 rounded-lg">
            {typeof value === 'boolean' ? (
              <i
                className={`fa-solid ${value ? 'fa-check-circle text-green-400' : 'fa-times-circle text-red-400'} mr-3 w-5 text-center`}
              ></i>
            ) : (
              <i
                className={`fa-solid ${iconMap?.[key] || 'fa-star'} ${THEME_CLASSES.cyan.text} mr-3 w-5 text-center`}
              ></i>
            )}
            <div>
              <p className="text-sm font-medium text-white">{formatKey(key)}</p>
              {typeof value !== 'boolean' && (
                <p className="text-xs text-gray-400">{String(value)}</p>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

const AgentProfilePage: React.FC<AgentProfilePageProps> = ({
  agent,
  onStartChat,
  onNextAgent,
  onPrevAgent,
  selectedModel,
  onSelectModel,
}) => {
  const agentData = AGENT_UI_DATA[agent.name] || AGENT_UI_DATA['default'];
  const theme = THEME_CLASSES[agentData.themeColor] || THEME_CLASSES.cyan;

  const renderWidgets = () => {
    if (agent.name === 'AI Girlfriend' && agentData.relationshipStats) {
      return (
        <>
          <EmotionalStateWidget
            title={agentData.stats.title}
            stats={agentData.stats.items}
            themeColor={agentData.themeColor}
          />
          <RelationshipProgressWidget
            title={agentData.relationshipStats.title}
            items={agentData.relationshipStats.items}
            themeColor={agentData.themeColor}
          />
        </>
      );
    }
    if (agent.name === 'PDFMind' && agentData.recentFiles) {
      return (
        <>
          <DocumentAnalyticsWidget
            title={agentData.stats.title}
            stats={agentData.stats.items}
            themeColor={agentData.themeColor}
          />
          <RecentFilesWidget
            title={agentData.recentFiles.title}
            items={agentData.recentFiles.items}
            themeColor={agentData.themeColor}
          />
        </>
      );
    }
    if (agent.name === 'CVSmash' && agentData.resumeScore && agentData.careerChecklist) {
      return (
        <>
          <ResumeScoreWidget
            title={agentData.resumeScore.title}
            score={agentData.resumeScore.score}
            themeColor={agentData.themeColor}
          />
          <CareerChecklistWidget
            title={agentData.careerChecklist.title}
            items={agentData.careerChecklist.items}
            themeColor={agentData.themeColor}
          />
        </>
      );
    }
    if (agent.name === 'EmoAI' && agentData.sentimentAnalysis && agentData.emotionalTrend) {
      return (
        <>
          <SentimentAnalysisWidget
            title={agentData.sentimentAnalysis.title}
            analysis={agentData.sentimentAnalysis.analysis}
            themeColor={agentData.themeColor}
          />
          <EmotionalTrendWidget
            title={agentData.emotionalTrend.title}
            trend={agentData.emotionalTrend.trend}
            themeColor={agentData.themeColor}
          />
        </>
      );
    }
    if (
      agent.name === 'ChatRevive' &&
      agentData.conversationHealth &&
      agentData.conversationTopics
    ) {
      return (
        <>
          <ConversationHealthWidget
            title={agentData.conversationHealth.title}
            health={agentData.conversationHealth.health}
            themeColor={agentData.themeColor}
          />
          <ConversationTopicsWidget
            title={agentData.conversationTopics.title}
            items={agentData.conversationTopics.items}
            themeColor={agentData.themeColor}
          />
        </>
      );
    }
    if (agent.name === 'TokBoost' && agentData.engagementRate && agentData.viralTrends) {
      return (
        <>
          <EngagementRateWidget
            title={agentData.engagementRate.title}
            rate={agentData.engagementRate.rate}
            themeColor={agentData.themeColor}
          />
          <ViralTrendsWidget
            title={agentData.viralTrends.title}
            items={agentData.viralTrends.items}
            themeColor={agentData.themeColor}
          />
        </>
      );
    }
    if (agent.name === 'YouGen' && agentData.contentIdeas) {
      return (
        <>
          <GenerationStatsWidget
            title={agentData.stats.title}
            stats={agentData.stats.items}
            themeColor={agentData.themeColor}
          />
          <ContentIdeasWidget
            title={agentData.contentIdeas.title}
            items={agentData.contentIdeas.items}
            themeColor={agentData.themeColor}
          />
        </>
      );
    }
    return (
      <>
        <StatsWidget
          title={agentData.stats.title}
          stats={agentData.stats.items}
          themeColor={agentData.themeColor}
        />
        <MemoryWidget
          title="Memory Bank"
          items={agentData.memoryItems}
          themeColor={agentData.themeColor}
        />
      </>
    );
  };

  return (
    <div className="flex-1 flex flex-col bg-black overflow-y-auto">
      <header className="flex items-center justify-between p-4 border-b border-gray-800 flex-shrink-0">
        <h1 className="text-xl font-bold text-white">Agent Dossier</h1>
        <div className="flex items-center space-x-2">
          <button
            onClick={onPrevAgent}
            title="View previous agent"
            className="px-3 py-1.5 text-sm bg-gray-800/50 border border-gray-700 rounded-md text-gray-300 hover:bg-gray-700/50 transition-colors"
          >
            <i className="fa-solid fa-chevron-left mr-2"></i> Prev
          </button>
          <button
            onClick={onNextAgent}
            title="View next agent"
            className="px-3 py-1.5 text-sm bg-gray-800/50 border border-gray-700 rounded-md text-gray-300 hover:bg-gray-700/50 transition-colors"
          >
            Next <i className="fa-solid fa-chevron-right ml-2"></i>
          </button>
        </div>
      </header>
      <div
        className={`flex-1 grid grid-cols-1 lg:grid-cols-5 xl:grid-cols-3 gap-6 p-6 ${theme.bg}`}
      >
        <div className="lg:col-span-3 xl:col-span-2 bg-gray-900/50 border border-gray-800 rounded-2xl p-8 flex flex-col overflow-y-auto">
          <div className="flex items-center space-x-6 mb-6">
            <div
              className={`w-24 h-24 flex items-center justify-center rounded-2xl ${theme.bg} border ${theme.border}`}
            >
              {agent.icon && agent.icon.startsWith('data:image') ? (
                <img
                  src={agent.icon}
                  alt={`${agent.name} icon`}
                  className="w-full h-full object-cover rounded-2xl"
                />
              ) : (
                <i className={`${agent.icon} w-14 h-14 ${theme.text}`}></i>
              )}
            </div>
            <div>
              <h2 className="text-4xl font-bold text-white">{agent.name}</h2>
              <p className={`text-lg font-medium ${theme.text}`}>{agent.role}</p>
            </div>
          </div>

          <div className="border-t border-gray-800 pt-6">
            <h3 className="text-lg font-semibold text-white mb-2">About {agent.name}</h3>
            <p className="text-gray-400 leading-relaxed">{agent.description}</p>
          </div>

          {agent.skills && agent.skills.enabled.length > 0 && (
            <div className="border-t border-gray-800 pt-6 mt-6">
              <h3 className="text-lg font-semibold text-white mb-4">Core Skills</h3>
              <div className="flex flex-wrap gap-2">
                {agent.skills.enabled.map(skill => (
                  <span
                    key={skill}
                    className={`px-3 py-1 text-xs font-semibold rounded-full ${theme.bg} ${theme.text} border ${theme.border}`}
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          )}

          <InfoGrid title="Cognitive Features" data={agent.cognition} />
          <InfoGrid title="Web Intelligence" data={agent.webOps} />
          <InfoGrid title="Developer Tools" data={agent.developerTools} />
          <InfoGrid title="Multimodal Capabilities" data={agent.multimodal} />

          <div className="mt-auto pt-8">
            <button
              onClick={onStartChat}
              title={`Start a conversation with ${agent.name}`}
              className={`w-full py-3 rounded-lg text-lg font-bold text-black transition-colors ${theme.button} ${theme.buttonHover}`}
            >
              Start Chatting with {agent.name}
            </button>
          </div>
        </div>

        <div className="lg:col-span-2 xl:col-span-1 flex flex-col space-y-4 overflow-y-auto">
          {renderWidgets()}
        </div>
      </div>
    </div>
  );
};

export default AgentProfilePage;
