import React, { useState, useEffect, useRef } from 'react';
import Sidebar from './Sidebar';
import AgentPage from './AgentPage';
import FilePreviewModal from './DashboardFilePreview';
import { Message, AIModel, ALL_MODELS, Agent } from '../../../constants';
import { GoogleGenAI, Part } from '@google/genai';
import AgentProfilePage from './AgentProfilePage';
import AgentManagementPage from './AgentManagementPage';
import AgentFormPage from './AgentFormPage';
import ProfileSection from '../account/ProfileSection';
import BillingHistorySection from '../account/BillingHistorySection';
import SubscriptionsSection from '../account/SubscriptionsSection';
import UsageAnalyticsSection from '../account/UsageAnalyticsSection';
import AccountSecurity from '../account/AccountSecurity';
import AccountSettings from '../account/AccountSettings';
import OverviewSection from '../account/OverviewSection';
import { useApp } from '../../../contexts/AppContext';
import GlobalSearch from './GlobalSearch';
import UserActivityLog from './UserActivityLog';
import OnboardingTutorial from './OnboardingTutorial';
import { dashboardStorage } from '../../../services/user/dashboardStorage';

interface DashboardProps {
  agents: Agent[];
  setAgents: React.Dispatch<React.SetStateAction<Agent[]>>;
  selectedAgent: Agent;
  onSelectAgent: (agent: Agent) => void;
  onLogout: () => void;
  onOpenSettings: () => void;
  geminiApiKey: string;
  subscriptions: Record<string, string>;
  onSubscribe: (agent: Agent) => void;
}

interface AttachedFile {
  name: string;
  data: string; // base64 encoded
  mimeType: string;
}

export type DashboardView =
  | 'agent'
  | 'account-profile'
  | 'account-billing'
  | 'account-subscriptions'
  | 'account-analytics'
  | 'account-security'
  | 'account-settings'
  | 'agentProfile'
  | 'agentManagement'
  | 'agentForm'
  | 'activityLog'
  | 'dashboard'
  | 'achievements';

const Dashboard: React.FC<DashboardProps> = ({
  agents,
  setAgents,
  selectedAgent,
  onSelectAgent,
  onLogout,
  onOpenSettings,
  geminiApiKey,
  subscriptions,
  onSubscribe,
}) => {
  const { navigate, selectAgentForSubscription, refreshAppData } = useApp();
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [attachedFile, setAttachedFile] = useState<AttachedFile | null>(null);
  const [isFilePreviewOpen, setIsFilePreviewOpen] = useState(false);
  const [selectedModelId, setSelectedModelId] = useState<string>('gemini-2.5-flash');
  const [view, setView] = useState<DashboardView>('dashboard');
  const [agentToEdit, setAgentToEdit] = useState<Agent | null>(null);
  const [agentVoiceGender, setAgentVoiceGender] = useState<Record<string, 'male' | 'female'>>({});
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [showGlobalSearch, setShowGlobalSearch] = useState(false);
  const [subscriptionSuccess, setSubscriptionSuccess] = useState<string | null>(null);

  // User profile state
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [isLoadingUser, setIsLoadingUser] = useState(true);

  // Custom agents state
  const [customAgents, setCustomAgents] = useState<Agent[]>([]);
  const [isLoadingAgents, setIsLoadingAgents] = useState(false);

  const handleProfileUpdate = (updatedUser: any) => {
    if (!updatedUser) return;
    setCurrentUser(prev => {
      const merged = {
        ...(prev || {}),
        ...updatedUser,
      };
      try {
        localStorage.setItem('iamai_user_profile', JSON.stringify(merged));
      } catch (error) {
        console.error('Failed to persist profile locally:', error);
      }
      return merged;
    });
  };

  // Set initial view from URL on mount
  useEffect(() => {
    const getViewFromUrl = (): DashboardView => {
      const path = window.location.pathname;
      const pathMap: Record<string, DashboardView> = {
        '/dashboard': 'dashboard',
        '/dashboard/profile': 'account-profile',
        '/dashboard/billing': 'account-billing',
        '/dashboard/subscriptions': 'account-subscriptions',
        '/dashboard/security': 'account-security',
        '/dashboard/settings': 'account-settings',
        '/dashboard/analytics': 'account-analytics',
        '/dashboard/management': 'agentManagement',
        '/dashboard/activity-log': 'activityLog',
        '/dashboard/achievements': 'achievements',
      };
      return pathMap[path] || 'dashboard';
    };
    setView(getViewFromUrl());
  }, []);

  // Load user profile on component mount
  useEffect(() => {
    const loadUserProfile = async () => {
      try {
        setIsLoadingUser(true);
        const userProfile = await dashboardStorage.loadUserProfile();
        if (userProfile && userProfile.email) {
          setCurrentUser(userProfile);
        } else {
          // If no profile data, try to fetch from API directly
          try {
            const response = await fetch('/api/users/profile', {
              method: 'GET',
              headers: {
                'Content-Type': 'application/json',
              },
              credentials: 'include',
            });
            if (response.ok) {
              const data = await response.json();
              const userData = data.data || data;
              setCurrentUser(userData);
            } else {
              // Only set default if API also fails
              setCurrentUser({
                name: 'User',
                email: 'user@example.com',
                profileImage: '/default-avatar.svg',
                createdAt: new Date().toISOString(),
              });
            }
          } catch (apiError) {
            console.error('API fetch failed:', apiError);
            setCurrentUser({
              name: 'User',
              email: 'user@example.com',
              profileImage: '/default-avatar.svg',
              createdAt: new Date().toISOString(),
            });
          }
        }
      } catch (error) {
        console.error('Error loading user profile:', error);
        // Set default user data on error
        setCurrentUser({
          name: 'User',
          email: 'user@example.com',
          profileImage: '/default-avatar.svg',
          createdAt: new Date().toISOString(),
        });
      } finally {
        setIsLoadingUser(false);
      }
    };

    loadUserProfile();
  }, []);

  // Load custom agents on component mount
  useEffect(() => {
    const loadCustomAgents = async () => {
      try {
        setIsLoadingAgents(true);
        const response = await fetch('/api/users/agents', {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
          },
          credentials: 'include',
        });

        if (response.ok) {
          const data = await response.json();
          if (data.success) {
            setCustomAgents(data.data || []);
          }
        }
      } catch (error) {
        console.error('Error loading custom agents:', error);
      } finally {
        setIsLoadingAgents(false);
      }
    };

    loadCustomAgents();
  }, []);

  // Check for subscription success in URL params
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const subscriptionStatus = urlParams.get('subscription');
    const agentId = urlParams.get('agent');

    if (subscriptionStatus === 'success' && agentId) {
      setSubscriptionSuccess(agentId);
      // Clean URL
      window.history.replaceState({}, '', '/dashboard');
      // Refresh app data to update subscriptions
      refreshAppData();
      // Show success message for 5 seconds
      setTimeout(() => setSubscriptionSuccess(null), 5000);
    }
  }, []);

  // Refs for auto-saving to get the latest state inside setInterval
  const messagesRef = useRef(messages);
  messagesRef.current = messages;
  const selectedAgentRef = useRef(selectedAgent);
  selectedAgentRef.current = selectedAgent;
  const subscriptionsRef = useRef(subscriptions);
  subscriptionsRef.current = subscriptions;
  const viewRef = useRef(view);
  viewRef.current = view;

  const selectedModel =
    ALL_MODELS.find(m => m.id === selectedModelId) ||
    ALL_MODELS.find(m => m.id === 'gemini-2.5-flash')!;

  // Check if user should see onboarding
  useEffect(() => {
    const hasSeenOnboarding =
      localStorage.getItem('iamai_onboarding_completed') ||
      localStorage.getItem('iamai_onboarding_skipped');
    if (!hasSeenOnboarding) {
      setTimeout(() => setShowOnboarding(true), 1000);
    }
  }, []);

  // Global keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Cmd/Ctrl + K to open global search
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setShowGlobalSearch(true);
      }
      // Cmd/Ctrl + H to show help/onboarding
      if ((e.metaKey || e.ctrlKey) && e.key === 'h') {
        e.preventDefault();
        setShowOnboarding(true);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleFileAttach = (file: File) => {
    if (file.type !== 'application/pdf') {
      alert('Only PDF files are supported for now.');
      return;
    }
    const reader = new FileReader();
    reader.onload = e => {
      const base64Data = (e.target?.result as string).split(',')[1];
      setAttachedFile({
        name: file.name,
        data: base64Data,
        mimeType: file.type,
      });
    };
    reader.readAsDataURL(file);
  };

  const handleFileRemove = () => {
    setAttachedFile(null);
  };

  const getSystemInstruction = (agent: Agent) => {
    const personalityTraits = JSON.stringify(
      agent.personalityMatrix,
      (key, value) => {
        if (
          [
            'formality',
            'humor',
            'enthusiasm',
            'leadership',
            'diplomacy',
            'storytelling',
            'resilience',
            'empathy',
            'precision',
            'creativity',
          ].includes(key)
        ) {
          return `${value}/100`;
        }
        return value;
      },
      2
    );

    return `You are ${agent.name}, a ${agent.role}. Your primary function is: ${agent.description}. You must adhere strictly to the following personality matrix:\n${personalityTraits}\nStay in character and respond to the user's request.`;
  };

  const streamGeminiResponse = async (
    content: string,
    currentAttachedFile: AttachedFile | null,
    placeholderId: string
  ) => {
    if (!geminiApiKey) {
      throw new Error('Please set your Google Gemini API key in the settings to start chatting.');
    }

    const ai = new GoogleGenAI({ apiKey: geminiApiKey });
    const parts: Part[] = [];
    if (currentAttachedFile && selectedAgent.capabilities.canAttachFiles) {
      parts.push({
        inlineData: {
          mimeType: currentAttachedFile.mimeType,
          data: currentAttachedFile.data,
        },
      });
    }
    parts.push({ text: content });

    const modelConfig: any = {
      systemInstruction: getSystemInstruction(selectedAgent),
    };

    if (selectedAgent.capabilities.canAccessWeb) {
      modelConfig.tools = [{ googleSearch: {} }];
    }

    const stream = await ai.models.generateContentStream({
      model: selectedModel.id,
      contents: { parts },
      config: modelConfig,
    });

    const sourceMap = new Map<string, string>(); // Use a map to deduplicate sources by URI

    for await (const chunk of stream) {
      const chunkText = chunk.text;
      setMessages(prevMessages => {
        return prevMessages.map(msg =>
          msg.id === placeholderId ? { ...msg, content: msg.content + chunkText } : msg
        );
      });

      // Collect grounding metadata
      const groundingMetadata = chunk.candidates?.[0]?.groundingMetadata;
      if (groundingMetadata?.groundingChunks) {
        for (const chunkInfo of groundingMetadata.groundingChunks) {
          if (chunkInfo.web && chunkInfo.web.uri) {
            sourceMap.set(chunkInfo.web.uri, chunkInfo.web.title || '');
          }
        }
      }
    }

    // After stream ends, update the message with collected sources
    if (sourceMap.size > 0) {
      setMessages(prevMessages => {
        return prevMessages.map(msg => {
          if (msg.id === placeholderId) {
            return {
              ...msg,
              sources: Array.from(sourceMap.entries()).map(([uri, title]) => ({ uri, title })),
            };
          }
          return msg;
        });
      });
    }
  };

  const streamOllamaResponse = async (
    content: string,
    currentAttachedFile: AttachedFile | null,
    placeholderId: string
  ) => {
    let fullPrompt = content;
    if (currentAttachedFile) {
      fullPrompt += `\n\n[User has attached a file named ${currentAttachedFile.name}. You cannot see the file contents, but acknowledge its presence.]`;
    }

    const response = await fetch('http://localhost:11434/api/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: selectedModel.id,
        prompt: fullPrompt,
        stream: true,
        system: getSystemInstruction(selectedAgent),
      }),
    });

    if (!response.ok || !response.body) {
      throw new Error('Failed to connect to Ollama server.');
    }

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let accumulatedResponse = '';

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      const chunk = decoder.decode(value, { stream: true });
      const lines = chunk.split('\n').filter(line => line.trim() !== '');

      for (const line of lines) {
        try {
          const parsed = JSON.parse(line);
          if (parsed.response) {
            accumulatedResponse += parsed.response;
            setMessages(prev =>
              prev.map(msg =>
                msg.id === placeholderId ? { ...msg, content: accumulatedResponse } : msg
              )
            );
          }
        } catch (e) {
          console.error('Failed to parse Ollama stream chunk:', line, e);
        }
      }
    }
  };

  const handleSendMessage = async (content: string) => {
    const userMessageContent = attachedFile
      ? `${content}\n\n[File Attached: ${attachedFile.name}]`
      : content;
    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: userMessageContent,
      timestamp: new Date(),
    };
    const agentMessagePlaceholder: Message = {
      id: (Date.now() + 1).toString(),
      role: 'agent',
      content: '',
      timestamp: new Date(),
      agent: selectedAgent,
    };

    setMessages(prevMessages => [...prevMessages, userMessage, agentMessagePlaceholder]);
    setIsLoading(true);
    const currentAttachedFile = attachedFile;
    setAttachedFile(null);

    try {
      switch (selectedModel.provider) {
        case 'Google':
          await streamGeminiResponse(content, currentAttachedFile, agentMessagePlaceholder.id);
          break;
        case 'Ollama':
          await streamOllamaResponse(content, currentAttachedFile, agentMessagePlaceholder.id);
          break;
        case 'OpenAI':
        case 'Anthropic':
          const notImplementedMsg = `Integration for ${selectedModel.provider} (${selectedModel.name}) is not yet available.`;
          setMessages(prev =>
            prev.map(msg =>
              msg.id === agentMessagePlaceholder.id ? { ...msg, content: notImplementedMsg } : msg
            )
          );
          break;
        default:
          throw new Error('Selected model provider is not supported.');
      }
    } catch (error: any) {
      console.error(`Error calling ${selectedModel.provider} API:`, error);
      let errorMessageContent = "I'm sorry, I encountered an error. Please try again.";
      if (selectedModel.provider === 'Ollama') {
        errorMessageContent =
          "I'm sorry, I couldn't connect to the local Ollama server. Please ensure it's running and accessible at http://localhost:11434.";
      } else if (error.message.includes('API key')) {
        errorMessageContent = error.message;
      }

      setMessages(prevMessages =>
        prevMessages.map(msg =>
          msg.id === agentMessagePlaceholder.id ? { ...msg, content: errorMessageContent } : msg
        )
      );
    } finally {
      setIsLoading(false);
    }
  };

  const handleFeedback = (messageId: string, rating: 'good' | 'bad', comment?: string) => {
    setMessages(prevMessages =>
      prevMessages.map(msg => {
        if (msg.id === messageId) {
          return {
            ...msg,
            feedback: {
              rating,
              comment,
            },
          };
        }
        return msg;
      })
    );
  };

  const handleClearChat = () => {
    if (!selectedAgent) return;
    if (
      window.confirm(
        `Are you sure you want to clear the chat history for ${selectedAgent.name}? This action cannot be undone.`
      )
    ) {
      setMessages([
        {
          id: Date.now().toString(),
          role: 'agent',
          content: `Hello! I'm ${selectedAgent.name}. ${selectedAgent.description} How can I help you today?`,
          timestamp: new Date(),
          agent: selectedAgent,
        },
      ]);
      localStorage.removeItem(`chatHistory_${selectedAgent.name}`);
    }
  };

  useEffect(() => {
    if (view !== 'agent' || !selectedAgent) return;

    const isSubscribed = !!subscriptions[selectedAgent.name];
    if (!isSubscribed) {
      setMessages([]);
      return;
    }

    const storageKey = `chatHistory_${selectedAgent.name}`;
    const savedMessagesRaw = localStorage.getItem(storageKey);

    const initializeMessages = () =>
      setMessages([
        {
          id: Date.now().toString(),
          role: 'agent',
          content: `Hello! I'm ${selectedAgent.name}. ${selectedAgent.description} How can I help you today?`,
          timestamp: new Date(),
          agent: selectedAgent,
        },
      ]);

    if (savedMessagesRaw) {
      try {
        const savedMessages: Message[] = JSON.parse(savedMessagesRaw);
        if (Array.isArray(savedMessages) && savedMessages.length > 0) {
          const hydratedMessages = savedMessages.map(msg => {
            if (msg.role === 'agent' && msg.agent?.id) {
              const fullAgent = agents.find(a => a.id === msg.agent!.id);
              return { ...msg, agent: fullAgent };
            }
            return msg;
          });
          setMessages(hydratedMessages);
        } else {
          initializeMessages();
        }
      } catch (error) {
        console.error('Failed to parse chat history', error);
        initializeMessages();
      }
    } else {
      initializeMessages();
    }

    setAttachedFile(null);
  }, [selectedAgent, subscriptions, view, agents]);

  // Auto-save chat history every 60 seconds and on unmount
  useEffect(() => {
    const autoSave = () => {
      const currentView = viewRef.current;
      const currentAgent = selectedAgentRef.current;
      const currentMessages = messagesRef.current;
      const currentSubscriptions = subscriptionsRef.current;

      if (currentView !== 'agent' || !currentAgent) return;

      const isSubscribed = !!currentSubscriptions[currentAgent.name];
      if (currentMessages.length > 1 && isSubscribed) {
        const storageKey = `chatHistory_${currentAgent.name}`;
        const messagesToSave = currentMessages.filter(msg => !msg.content.includes('API key'));
        if (messagesToSave.length > 0) {
          localStorage.setItem(storageKey, JSON.stringify(messagesToSave));
        }
      }
    };

    const intervalId = setInterval(autoSave, 60000);

    return () => {
      clearInterval(intervalId);
      autoSave(); // Perform final save on cleanup
    };
  }, []);

  useEffect(() => {
    if (!selectedAgent) return;
    const storageKey = `modelSelection_${selectedAgent.name}`;
    const savedModelId = localStorage.getItem(storageKey);
    if (savedModelId && ALL_MODELS.find(m => m.id === savedModelId)) {
      setSelectedModelId(savedModelId);
    } else {
      setSelectedModelId('gemini-2.5-flash');
    }
  }, [selectedAgent]);

  useEffect(() => {
    if (selectedModelId && selectedAgent) {
      const storageKey = `modelSelection_${selectedAgent.name}`;
      localStorage.setItem(storageKey, selectedModelId);
    }
  }, [selectedModelId, selectedAgent]);

  // Load/Save voice gender preferences
  useEffect(() => {
    const savedGenders = localStorage.getItem('iamai_voice_genders');
    if (savedGenders) {
      try {
        setAgentVoiceGender(JSON.parse(savedGenders));
      } catch (e) {
        console.error('Failed to parse voice genders from localStorage', e);
      }
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('iamai_voice_genders', JSON.stringify(agentVoiceGender));
  }, [agentVoiceGender]);

  // ✨ SOLUTION A: Map agent ID to route name for navigation
  const getAgentRoute = (agentId: string): string => {
    const agentRoutes: Record<string, string> = {
      'ai-girlfriend': 'ai-girlfriend',
      'emo-ai': 'emo-ai',
      'pdf-mind': 'pdf-mind',
      'chat-revive': 'chat-revive',
      'tok-boost': 'tok-boost',
      'you-gen': 'you-gen',
      'agent-x': 'agent-x',
      'auto-chat': 'auto-chat',
      'cv-smash': 'cv-smash',
    };
    return agentRoutes[agentId] || 'home';
  };

  // Allow direct access to agent pages (subscription check happens in agent page)
  const handleNavigateToChat = (agent: Agent) => {
    // For dashboard agent navigation, stay within dashboard and show agent interface
    onSelectAgent(agent);
    setView('agent'); // Show the agent chat view within dashboard

    // Alternative: If you want to navigate to dedicated agent pages, use this:
    // const agentRoute = getAgentRoute(agent.id);
    // navigate(agentRoute as any);
  };

  const handleNavigateToProfile = (agent: Agent) => {
    onSelectAgent(agent);
    setView('agentProfile');
  };

  const handleCycleAgent = (direction: 'next' | 'prev') => {
    const currentIndex = agents.findIndex(a => a.id === selectedAgent.id);
    let nextIndex;
    if (direction === 'next') {
      nextIndex = (currentIndex + 1) % agents.length;
    } else {
      nextIndex = (currentIndex - 1 + agents.length) % agents.length;
    }
    onSelectAgent(agents[nextIndex]);
  };

  const handleEditAgent = (agent: Agent) => {
    setAgentToEdit(agent);
    setView('agentForm');
  };

  const handleCreateAgent = () => {
    setAgentToEdit(null);
    setView('agentForm');
  };

  const handleDeleteAgent = async (agentId: string) => {
    if (!agentId.startsWith('custom_')) {
      alert('Default agent templates cannot be deleted. Please delete only your custom agents.');
      return;
    }
    if (
      window.confirm('Are you sure you want to delete this agent? This action cannot be undone.')
    ) {
      try {
        const response = await fetch(`/api/users/agents/${agentId}`, {
          method: 'DELETE',
          headers: {
            'Content-Type': 'application/json',
          },
          credentials: 'include',
        });

        if (response.ok) {
          setCustomAgents(prev => prev.filter(a => a.id !== agentId));
        } else {
          alert('Failed to delete agent');
        }
      } catch (error) {
        console.error('Error deleting agent:', error);
        alert('Failed to delete agent');
      }
    }
  };

  const handleSaveAgent = async (agentToSave: Agent) => {
    try {
      const payload = {
        name: agentToSave.name,
        role: agentToSave.role,
        description: agentToSave.description,
        icon: agentToSave.icon,
        capabilities: agentToSave.capabilities,
        personalityMatrix: agentToSave.personalityMatrix,
        voicePreferences: agentToSave.voicePreferences,
        tags: agentToSave.tags,
        config: agentToSave,
      };

      if (agentToSave.id && agentToSave.id.startsWith('custom_')) {
        // Update existing custom agent
        const response = await fetch(`/api/users/agents/${agentToSave.id}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
          },
          credentials: 'include',
          body: JSON.stringify(payload),
        });

        if (response.ok) {
          const data = await response.json();
          setCustomAgents(prev => prev.map(a => (a.id === agentToSave.id ? data.data : a)));
        } else {
          alert('Failed to update agent');
          return;
        }
      } else {
        // Create new custom agent
        const response = await fetch('/api/users/agents', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          credentials: 'include',
          body: JSON.stringify(payload),
        });

        if (response.ok) {
          const data = await response.json();
          setCustomAgents(prev => [...prev, data.data]);
        } else {
          alert('Failed to create agent');
          return;
        }
      }
      setView('agentManagement');
    } catch (error) {
      console.error('Error saving agent:', error);
      alert('Failed to save agent');
    }
  };

  // Helper function to map URL path to dashboard view
  const getViewFromUrl = (): DashboardView => {
    const path = window.location.pathname;
    const pathMap: Record<string, DashboardView> = {
      '/dashboard/profile': 'account-profile',
      '/dashboard/billing': 'account-billing',
      '/dashboard/subscriptions': 'account-subscriptions',
      '/dashboard/security': 'account-security',
      '/dashboard/settings': 'account-settings',
      '/dashboard/analytics': 'account-analytics',
      '/dashboard/management': 'agentManagement',
      '/dashboard/activity-log': 'activityLog',
    };
    return pathMap[path] || 'dashboard';
  };

  // Update URL when view changes
  const handleViewChange = (newView: DashboardView) => {
    setView(newView);

    const viewToPathMap: Record<DashboardView, string> = {
      dashboard: '/dashboard',
      'account-profile': '/dashboard/profile',
      'account-billing': '/dashboard/billing',
      'account-subscriptions': '/dashboard/subscriptions',
      'account-security': '/dashboard/security',
      'account-settings': '/dashboard/settings',
      'account-analytics': '/dashboard/analytics',
      agentManagement: '/dashboard/management',
      activityLog: '/dashboard/activity-log',
      agent: '/dashboard',
      agentProfile: '/dashboard',
      agentForm: '/dashboard',
      achievements: '/dashboard/achievements',
    };

    const newPath = viewToPathMap[newView] || '/dashboard';
    if (window.location.pathname !== newPath) {
      window.history.pushState({}, '', newPath);
    }
  };

  const renderMainView = () => {
    switch (view) {
      case 'agent':
        return <AgentPage agent={selectedAgent} />;
      case 'agentProfile':
        return (
          <AgentProfilePage
            agent={selectedAgent}
            onStartChat={() => handleNavigateToChat(selectedAgent)}
            onNextAgent={() => handleCycleAgent('next')}
            onPrevAgent={() => handleCycleAgent('prev')}
            selectedModel={selectedModel}
            onSelectModel={setSelectedModelId}
          />
        );
      case 'agentManagement':
        return (
          <div className="h-full" style={{ background: 'var(--color-background)' }}>
            <div className="max-w-7xl mx-auto">
              <SubscriptionsSection agents={agents} />
            </div>
          </div>
        );
      case 'agentForm':
        return (
          <AgentFormPage
            agentToEdit={agentToEdit}
            onSave={handleSaveAgent}
            onCancel={() => setView('agentManagement')}
          />
        );
      case 'activityLog':
        return <UserActivityLog />;
      case 'account-profile': {
        const profileUser = currentUser || {
          name: 'Loading...',
          email: 'Loading...',
          profileImage: '/default-avatar.svg',
          avatar: '/default-avatar.svg',
          createdAt: '',
          phone: '',
          address: '',
          city: '',
          country: '',
        };
        return (
          <div className="h-full" style={{ background: 'var(--color-background)' }}>
            <div className="max-w-7xl mx-auto">
              <ProfileSection user={profileUser} onProfileUpdate={handleProfileUpdate} />
            </div>
          </div>
        );
      }
      case 'account-billing':
        return (
          <div className="h-full" style={{ background: 'var(--color-background)' }}>
            <div className="max-w-7xl mx-auto">
              {/* Account Header */}
              <div
                className="border-b p-6"
                style={{
                  background: `linear-gradient(to right, var(--color-surface), var(--color-background))`,
                  borderColor: 'var(--color-border)',
                }}
              >
                <h1 className="text-3xl font-bold" style={{ color: 'var(--color-text)' }}>
                  Billing History
                </h1>
                <p className="mt-2" style={{ color: 'var(--color-text-secondary)' }}>
                  View your payment history and billing information
                </p>
              </div>
              <BillingHistorySection showHeading={false} />
            </div>
          </div>
        );
      case 'account-subscriptions':
        return (
          <div className="h-full" style={{ background: 'var(--color-background)' }}>
            <div className="max-w-7xl mx-auto">
              {/* Account Header */}
              <div
                className="border-b p-6"
                style={{
                  background: `linear-gradient(to right, var(--color-surface), var(--color-background))`,
                  borderColor: 'var(--color-border)',
                }}
              >
                <h1 className="text-3xl font-bold" style={{ color: 'var(--color-text)' }}>
                  Subscriptions
                </h1>
                <p className="mt-2" style={{ color: 'var(--color-text-secondary)' }}>
                  Manage your active subscriptions and plans
                </p>
              </div>
              <SubscriptionsSection subscriptions={subscriptions} agents={agents} showOnlyPurchased />
            </div>
          </div>
        );
      case 'account-security':
        return (
          <div className="h-full" style={{ background: 'var(--color-background)' }}>
            <div className="max-w-7xl mx-auto">
              {/* Account Header */}
              <div
                className="border-b p-6"
                style={{
                  background: `linear-gradient(to right, var(--color-surface), var(--color-background))`,
                  borderColor: 'var(--color-border)',
                }}
              >
                <h1 className="text-3xl font-bold" style={{ color: 'var(--color-text)' }}>
                  Security
                </h1>
                <p className="mt-2" style={{ color: 'var(--color-text-secondary)' }}>
                  Manage your account security and privacy settings
                </p>
              </div>
              <AccountSecurity />
            </div>
          </div>
        );
      case 'account-settings':
        return (
          <div className="h-full" style={{ background: 'var(--color-background)' }}>
            <div className="max-w-7xl mx-auto">
              {/* Account Header */}
              <div
                className="border-b p-6"
                style={{
                  background: `linear-gradient(to right, var(--color-surface), var(--color-background))`,
                  borderColor: 'var(--color-border)',
                }}
              >
                <h1 className="text-3xl font-bold" style={{ color: 'var(--color-text)' }}>
                  Settings
                </h1>
                <p className="mt-2" style={{ color: 'var(--color-text-secondary)' }}>
                  Customize your account preferences and behavior
                </p>
              </div>
              <AccountSettings />
            </div>
          </div>
        );
      case 'account-analytics':
        return (
          <div className="h-full" style={{ background: 'var(--color-background)' }}>
            <div className="max-w-7xl mx-auto">
              {/* Account Header */}
              <div
                className="border-b p-6"
                style={{
                  background: `linear-gradient(to right, var(--color-surface), var(--color-background))`,
                  borderColor: 'var(--color-border)',
                }}
              >
                <h1 className="text-3xl font-bold" style={{ color: 'var(--color-text)' }}>
                  Analytics
                </h1>
                <p className="mt-2" style={{ color: 'var(--color-text-secondary)' }}>
                  View your usage statistics and insights
                </p>
              </div>
              <UsageAnalyticsSection />
            </div>
          </div>
        );
      case 'dashboard':
        return <OverviewSection />;
      default:
        return <AgentPage agent={selectedAgent} />;
    }
  };

  return (
    <>
      {/* Onboarding Tutorial */}
      {showOnboarding && (
        <OnboardingTutorial
          onComplete={() => setShowOnboarding(false)}
          onSkip={() => setShowOnboarding(false)}
        />
      )}

      {/* Subscription Success Notification */}
      {subscriptionSuccess && (
        <div className="fixed top-4 right-4 bg-green-600 text-white px-6 py-3 rounded-lg shadow-lg z-50 flex items-center space-x-3">
          <i className="fa-solid fa-check-circle"></i>
          <span>
            Successfully subscribed to {agents.find(a => a.id === subscriptionSuccess)?.name}! 🎉
          </span>
          <button
            onClick={() => setSubscriptionSuccess(null)}
            className="ml-2 text-white hover:text-gray-200"
          >
            <i className="fa-solid fa-times"></i>
          </button>
        </div>
      )}

      {/* Global Search */}
      <GlobalSearch
        agents={agents}
        onNavigate={handleViewChange}
        onSelectAgent={onSelectAgent}
        isOpen={showGlobalSearch}
        onClose={() => setShowGlobalSearch(false)}
      />

      <div className="flex flex-1 bg-black">
        <Sidebar
          agents={agents}
          selectedAgent={selectedAgent}
          onNavigateToChat={handleNavigateToChat}
          onNavigateToProfile={handleNavigateToProfile}
          onLogout={onLogout}
          subscriptions={subscriptions}
          onNavigate={handleViewChange}
          currentView={view}
          onNavigateToHome={() => navigate('home')}
        />
        <main className="flex-1 flex flex-col">{renderMainView()}</main>
      </div>
      {attachedFile && (
        <FilePreviewModal
          isOpen={isFilePreviewOpen}
          onClose={() => setIsFilePreviewOpen(false)}
          fileName={attachedFile.name}
          fileData={attachedFile.data}
          mimeType={attachedFile.mimeType}
        />
      )}
    </>
  );
};

export default Dashboard;
