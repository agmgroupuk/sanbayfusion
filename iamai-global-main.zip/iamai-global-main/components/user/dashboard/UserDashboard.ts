import { Agent } from '../../../constants';

export interface DashboardWidget {
  id: string;
  type: 'stats' | 'chart' | 'activity' | 'agents' | 'quickActions';
  title: string;
  size: 'small' | 'medium' | 'large';
  position: { x: number; y: number };
  data?: any;
  isVisible: boolean;
  refreshInterval?: number;
}

export interface QuickAction {
  id: string;
  title: string;
  description: string;
  icon: string;
  action: () => void;
  category: 'chat' | 'agent' | 'settings' | 'analytics';
}

export interface RecentActivity {
  id: string;
  type: 'chat' | 'agent_used' | 'file_uploaded' | 'setting_changed';
  description: string;
  timestamp: Date;
  agentName?: string;
  metadata?: Record<string, any>;
}

export interface UserDashboardState {
  widgets: DashboardWidget[];
  recentActivity: RecentActivity[];
  quickActions: QuickAction[];
  favoriteAgents: Agent[];
  isCustomizing: boolean;
  selectedWidget: string | null;
  dashboardLayout: 'grid' | 'list';
  refreshRate: number;
  lastRefresh: Date | null;
}

export class UserDashboardService {
  private listeners: Set<(state: UserDashboardState) => void> = new Set();
  private state: UserDashboardState;
  private refreshTimers: Map<string, NodeJS.Timeout> = new Map();

  constructor(agents: Agent[]) {
    this.state = {
      widgets: this.getDefaultWidgets(),
      recentActivity: [],
      quickActions: this.generateQuickActions(),
      favoriteAgents: [],
      isCustomizing: false,
      selectedWidget: null,
      dashboardLayout: 'grid',
      refreshRate: 30000,
      lastRefresh: null,
    };

    this.loadDashboardState();
    this.loadRecentActivity();
    this.loadFavoriteAgents(agents);
    this.startAutoRefresh();
  }

  private getDefaultWidgets(): DashboardWidget[] {
    return [
      {
        id: 'welcome',
        type: 'stats',
        title: 'Welcome Back',
        size: 'large',
        position: { x: 0, y: 0 },
        isVisible: true,
      },
      {
        id: 'quick-stats',
        type: 'stats',
        title: 'Your Stats',
        size: 'medium',
        position: { x: 2, y: 0 },
        isVisible: true,
        refreshInterval: 60000,
      },
      {
        id: 'favorite-agents',
        type: 'agents',
        title: 'Favorite Agents',
        size: 'medium',
        position: { x: 0, y: 1 },
        isVisible: true,
      },
      {
        id: 'recent-activity',
        type: 'activity',
        title: 'Recent Activity',
        size: 'medium',
        position: { x: 2, y: 1 },
        isVisible: true,
      },
      {
        id: 'usage-chart',
        type: 'chart',
        title: 'Usage Trends',
        size: 'large',
        position: { x: 0, y: 2 },
        isVisible: true,
        refreshInterval: 300000,
      },
      {
        id: 'quick-actions',
        type: 'quickActions',
        title: 'Quick Actions',
        size: 'small',
        position: { x: 3, y: 0 },
        isVisible: true,
      },
    ];
  }

  private generateQuickActions(): QuickAction[] {
    return [
      {
        id: 'new-chat',
        title: 'Start New Chat',
        description: 'Begin a conversation with any agent',
        icon: '💬',
        category: 'chat',
        action: () => this.handleQuickAction('new-chat'),
      },
      {
        id: 'browse-agents',
        title: 'Browse Agents',
        description: 'Explore all available AI agents',
        icon: '🤖',
        category: 'agent',
        action: () => this.handleQuickAction('browse-agents'),
      },
      {
        id: 'ai-lab',
        title: 'AI Lab',
        description: 'Experiment with different AI models',
        icon: '🧪',
        category: 'chat',
        action: () => this.handleQuickAction('ai-lab'),
      },
      {
        id: 'upload-file',
        title: 'Upload File',
        description: 'Analyze documents with AI',
        icon: '📁',
        category: 'chat',
        action: () => this.handleQuickAction('upload-file'),
      },
      {
        id: 'view-analytics',
        title: 'View Analytics',
        description: 'Check your usage statistics',
        icon: '📊',
        category: 'analytics',
        action: () => this.handleQuickAction('view-analytics'),
      },
      {
        id: 'settings',
        title: 'Settings',
        description: 'Customize your experience',
        icon: '⚙️',
        category: 'settings',
        action: () => this.handleQuickAction('settings'),
      },
    ];
  }

  private loadDashboardState(): void {
    try {
      const stored = localStorage.getItem('user_dashboard_state');
      if (stored) {
        const data = JSON.parse(stored);
        this.updateState({
          ...this.state,
          widgets: data.widgets || this.state.widgets,
          dashboardLayout: data.dashboardLayout || this.state.dashboardLayout,
          refreshRate: data.refreshRate || this.state.refreshRate,
        });
      }
    } catch (error) {
      console.error('Failed to load dashboard state:', error);
    }
  }

  private saveDashboardState(): void {
    try {
      const data = {
        widgets: this.state.widgets,
        dashboardLayout: this.state.dashboardLayout,
        refreshRate: this.state.refreshRate,
      };
      localStorage.setItem('user_dashboard_state', JSON.stringify(data));
    } catch (error) {
      console.error('Failed to save dashboard state:', error);
    }
  }

  private loadRecentActivity(): void {
    try {
      const stored = localStorage.getItem('user_recent_activity');
      if (stored) {
        const activities = JSON.parse(stored).map((activity: any) => ({
          ...activity,
          timestamp: new Date(activity.timestamp),
        }));
        this.updateState({ ...this.state, recentActivity: activities });
      }
    } catch (error) {
      console.error('Failed to load recent activity:', error);
    }
  }

  private saveRecentActivity(): void {
    try {
      localStorage.setItem('user_recent_activity', JSON.stringify(this.state.recentActivity));
    } catch (error) {
      console.error('Failed to save recent activity:', error);
    }
  }

  private loadFavoriteAgents(allAgents: Agent[]): void {
    try {
      const stored = localStorage.getItem('favorite_agents');
      if (stored) {
        const favoriteIds = JSON.parse(stored);
        const favorites = allAgents.filter(agent => favoriteIds.includes(agent.name));
        this.updateState({ ...this.state, favoriteAgents: favorites });
      }
    } catch (error) {
      console.error('Failed to load favorite agents:', error);
    }
  }

  addRecentActivity(activity: Omit<RecentActivity, 'id' | 'timestamp'>): void {
    const newActivity: RecentActivity = {
      ...activity,
      id: `activity_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      timestamp: new Date(),
    };

    const activities = [newActivity, ...this.state.recentActivity].slice(0, 50); // Keep last 50
    this.updateState({ ...this.state, recentActivity: activities });
    this.saveRecentActivity();
  }

  toggleFavoriteAgent(agent: Agent): void {
    const isFavorite = this.state.favoriteAgents.some(fav => fav.name === agent.name);

    let favorites: Agent[];
    if (isFavorite) {
      favorites = this.state.favoriteAgents.filter(fav => fav.name !== agent.name);
      this.addRecentActivity({
        type: 'setting_changed',
        description: `Removed ${agent.name} from favorites`,
        agentName: agent.name,
      });
    } else {
      favorites = [...this.state.favoriteAgents, agent].slice(0, 10); // Max 10 favorites
      this.addRecentActivity({
        type: 'setting_changed',
        description: `Added ${agent.name} to favorites`,
        agentName: agent.name,
      });
    }

    this.updateState({ ...this.state, favoriteAgents: favorites });

    try {
      const favoriteIds = favorites.map(fav => fav.name);
      localStorage.setItem('favorite_agents', JSON.stringify(favoriteIds));
    } catch (error) {
      console.error('Failed to save favorite agents:', error);
    }
  }

  updateWidgetVisibility(widgetId: string, isVisible: boolean): void {
    const widgets = this.state.widgets.map(widget =>
      widget.id === widgetId ? { ...widget, isVisible } : widget
    );

    this.updateState({ ...this.state, widgets });
    this.saveDashboardState();
  }

  updateWidgetPosition(widgetId: string, position: { x: number; y: number }): void {
    const widgets = this.state.widgets.map(widget =>
      widget.id === widgetId ? { ...widget, position } : widget
    );

    this.updateState({ ...this.state, widgets });
    this.saveDashboardState();
  }

  updateWidgetSize(widgetId: string, size: 'small' | 'medium' | 'large'): void {
    const widgets = this.state.widgets.map(widget =>
      widget.id === widgetId ? { ...widget, size } : widget
    );

    this.updateState({ ...this.state, widgets });
    this.saveDashboardState();
  }

  addCustomWidget(widget: Omit<DashboardWidget, 'id'>): void {
    const newWidget: DashboardWidget = {
      ...widget,
      id: `custom_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    };

    const widgets = [...this.state.widgets, newWidget];
    this.updateState({ ...this.state, widgets });
    this.saveDashboardState();
  }

  removeWidget(widgetId: string): void {
    const widgets = this.state.widgets.filter(widget => widget.id !== widgetId);
    this.updateState({ ...this.state, widgets });
    this.saveDashboardState();
  }

  toggleCustomizeMode(): void {
    this.updateState({
      ...this.state,
      isCustomizing: !this.state.isCustomizing,
      selectedWidget: null,
    });
  }

  selectWidget(widgetId: string | null): void {
    this.updateState({ ...this.state, selectedWidget: widgetId });
  }

  setDashboardLayout(layout: 'grid' | 'list'): void {
    this.updateState({ ...this.state, dashboardLayout: layout });
    this.saveDashboardState();
  }

  setRefreshRate(rate: number): void {
    this.updateState({ ...this.state, refreshRate: rate });
    this.saveDashboardState();
    this.restartAutoRefresh();
  }

  private handleQuickAction(actionId: string): void {
    this.addRecentActivity({
      type: 'setting_changed',
      description: `Used quick action: ${actionId}`,
      metadata: { actionId },
    });

    // Emit event for parent components to handle
    const event = new CustomEvent('dashboardQuickAction', {
      detail: { actionId },
    });
    window.dispatchEvent(event);
  }

  refreshWidget(widgetId: string): void {
    const widget = this.state.widgets.find(w => w.id === widgetId);
    if (!widget) return;

    // Update widget data based on type
    const updatedWidget = { ...widget, data: this.getWidgetData(widget.type) };
    const widgets = this.state.widgets.map(w => (w.id === widgetId ? updatedWidget : w));

    this.updateState({
      ...this.state,
      widgets,
      lastRefresh: new Date(),
    });
  }

  private getWidgetData(type: DashboardWidget['type']): any {
    switch (type) {
      case 'stats':
        return this.getUserStats();
      case 'chart':
        return this.getUsageChartData();
      default:
        return null;
    }
  }

  private getUserStats(): any {
    // Calculate user statistics
    let totalChats = 0;
    let totalAgentsUsed = 0;

    try {
      // Aggregate from agent stats
      this.state.favoriteAgents.forEach(agent => {
        const stats = localStorage.getItem(`agent_stats_${agent.name}`);
        if (stats) {
          const agentStats = JSON.parse(stats);
          totalChats += agentStats.totalChats || 0;
          if (agentStats.totalChats > 0) totalAgentsUsed++;
        }
      });
    } catch (error) {
      console.error('Failed to calculate user stats:', error);
    }

    return {
      totalChats,
      totalAgentsUsed,
      favoriteAgents: this.state.favoriteAgents.length,
      recentActivity: this.state.recentActivity.length,
    };
  }

  private getUsageChartData(): any {
    // Generate chart data from recent activity
    const last7Days = [];
    const now = new Date();

    for (let i = 6; i >= 0; i--) {
      const date = new Date(now.getTime() - i * 24 * 60 * 60 * 1000);
      const dayActivity = this.state.recentActivity.filter(activity => {
        const activityDate = new Date(activity.timestamp);
        return activityDate.toDateString() === date.toDateString();
      });

      last7Days.push({
        date: date.toISOString().split('T')[0],
        chats: dayActivity.filter(a => a.type === 'chat').length,
        agentUses: dayActivity.filter(a => a.type === 'agent_used').length,
        total: dayActivity.length,
      });
    }

    return { chartData: last7Days };
  }

  private startAutoRefresh(): void {
    this.state.widgets
      .filter(widget => widget.refreshInterval)
      .forEach(widget => {
        const timer = setInterval(() => {
          this.refreshWidget(widget.id);
        }, widget.refreshInterval!);

        this.refreshTimers.set(widget.id, timer);
      });
  }

  private restartAutoRefresh(): void {
    this.stopAutoRefresh();
    this.startAutoRefresh();
  }

  private stopAutoRefresh(): void {
    this.refreshTimers.forEach(timer => clearInterval(timer));
    this.refreshTimers.clear();
  }

  refreshAllWidgets(): void {
    this.state.widgets.forEach(widget => {
      this.refreshWidget(widget.id);
    });
  }

  resetDashboard(): void {
    this.updateState({
      ...this.state,
      widgets: this.getDefaultWidgets(),
      dashboardLayout: 'grid',
      refreshRate: 30000,
      isCustomizing: false,
      selectedWidget: null,
    });

    this.saveDashboardState();
    this.restartAutoRefresh();
  }

  exportDashboardConfig(): string {
    return JSON.stringify(
      {
        widgets: this.state.widgets,
        layout: this.state.dashboardLayout,
        refreshRate: this.state.refreshRate,
        exportedAt: new Date().toISOString(),
      },
      null,
      2
    );
  }

  importDashboardConfig(configJson: string): boolean {
    try {
      const config = JSON.parse(configJson);
      this.updateState({
        ...this.state,
        widgets: config.widgets || this.state.widgets,
        dashboardLayout: config.layout || this.state.dashboardLayout,
        refreshRate: config.refreshRate || this.state.refreshRate,
      });

      this.saveDashboardState();
      this.restartAutoRefresh();
      return true;
    } catch (error) {
      console.error('Failed to import dashboard config:', error);
      return false;
    }
  }

  getState(): UserDashboardState {
    return { ...this.state };
  }

  subscribe(listener: (state: UserDashboardState) => void): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private updateState(newState: UserDashboardState): void {
    this.state = newState;
    this.listeners.forEach(listener => listener(this.state));
  }

  destroy(): void {
    this.stopAutoRefresh();
    this.listeners.clear();
  }
}
