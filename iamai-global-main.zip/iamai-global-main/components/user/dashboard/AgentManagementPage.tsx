import React, { useState, useMemo } from 'react';
import { Agent } from '../../../constants';
import { useTheme } from '../../../contexts/ThemeContext';

interface AgentManagementPageProps {
  agents: Agent[];
  onEdit: (agent: Agent) => void;
  onDelete: (agentId: string) => void;
  onCreate: () => void;
}

const AgentManagementPage: React.FC<AgentManagementPageProps> = ({
  agents,
  onEdit,
  onDelete,
  onCreate,
}) => {
  const { theme, themeColors } = useTheme();

  // Dynamic theme utility functions
  const getThemeClass = (opacity = 10) => {
    return `bg-gradient-to-br from-[var(--color-primary)]/${opacity} to-[var(--color-secondary)]/${opacity}`;
  };

  const getBorderClass = (opacity = 20) => {
    return `border border-[var(--color-primary)]/${opacity}`;
  };

  const getHoverBorderClass = (opacity = 40) => {
    return `hover:border-[var(--color-primary)]/${opacity}`;
  };

  const getTextColorClass = (isPrimary = true) => {
    return isPrimary ? 'text-[var(--color-primary)]' : 'text-[var(--color-text)]';
  };

  const [searchQuery, setSearchQuery] = useState('');

  const filteredAgents = useMemo(() => {
    if (!searchQuery.trim()) {
      return agents;
    }
    return agents.filter(
      agent =>
        agent.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        agent.role.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [agents, searchQuery]);

  return (
    <div className="flex-1 flex flex-col bg-[var(--color-background)] overflow-y-auto p-6">
      <header className="flex flex-col md:flex-row items-start md:items-center justify-between mb-6 gap-4">
        <div>
          <h1 className={`text-2xl font-bold ${getTextColorClass(false)}`}>Agent Management</h1>
          <p className="text-sm text-[var(--color-text-secondary)]">
            Create, edit, and manage your AI agents.
          </p>
        </div>
        <div className="flex items-center gap-4 w-full md:w-auto">
          <div className="relative flex-grow">
            <i className="fa-solid fa-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2 text-[var(--color-text-secondary)]"></i>
            <input
              type="text"
              placeholder="Search agents..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className={`w-full bg-[var(--color-surface)] ${getBorderClass()} rounded-lg pl-9 pr-3 py-2 text-sm text-[var(--color-text)] placeholder-[var(--color-text-secondary)] focus:outline-none focus:ring-1 focus:ring-[var(--color-primary)]`}
            />
          </div>
          <button
            onClick={onCreate}
            title="Create a new custom agent"
            className={`flex-shrink-0 px-4 py-2 bg-[var(--color-primary)] hover:bg-[var(--color-primary)]/80 ${getTextColorClass(false)} font-semibold rounded-lg transition-colors duration-300`}
          >
            <i className="fa-solid fa-plus mr-2"></i> Create New
          </button>
        </div>
      </header>

      <div className={`bg-[var(--color-surface)]/50 ${getBorderClass()} rounded-xl`}>
        <div className="overflow-x-auto">
          <table className={`min-w-full divide-y divide-[var(--color-border)]`}>
            <thead className={`bg-[var(--color-surface)]/80`}>
              <tr>
                <th
                  scope="col"
                  className={`py-3.5 pl-6 pr-3 text-left text-sm font-semibold ${getTextColorClass(false)}`}
                >
                  Agent
                </th>
                <th
                  scope="col"
                  className={`px-3 py-3.5 text-left text-sm font-semibold ${getTextColorClass(false)}`}
                >
                  Role
                </th>
                <th
                  scope="col"
                  className={`px-3 py-3.5 text-left text-sm font-semibold ${getTextColorClass(false)}`}
                >
                  Description
                </th>
                <th scope="col" className="relative py-3.5 pl-3 pr-6">
                  <span className="sr-only">Actions</span>
                </th>
              </tr>
            </thead>
            <tbody className={`divide-y divide-[var(--color-border)]`}>
              {filteredAgents.length > 0 ? (
                filteredAgents.map(agent => (
                  <tr key={agent.id}>
                    <td className="whitespace-nowrap py-4 pl-6 pr-3 text-sm">
                      <div className="flex items-center">
                        <div
                          className={`h-10 w-10 flex-shrink-0 flex items-center justify-center bg-[var(--color-surface)] rounded-lg`}
                        >
                          {agent.icon && agent.icon.startsWith('data:image') ? (
                            <img
                              src={agent.icon}
                              alt={`${agent.name} icon`}
                              className="w-full h-full object-cover rounded-lg"
                            />
                          ) : (
                            <i className={`${agent.icon} text-xl ${getTextColorClass()}`}></i>
                          )}
                        </div>
                        <div className="ml-4">
                          <div className={`font-medium ${getTextColorClass(false)}`}>
                            {agent.name}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="whitespace-nowrap px-3 py-4 text-sm text-[var(--color-text-secondary)]">
                      {agent.role}
                    </td>
                    <td
                      className="px-3 py-4 text-sm text-[var(--color-text-secondary)] max-w-sm truncate"
                      title={agent.description}
                    >
                      {agent.description}
                    </td>
                    <td className="relative whitespace-nowrap py-4 pl-3 pr-6 text-right text-sm font-medium">
                      <button
                        onClick={() => onEdit(agent)}
                        title={`Edit ${agent.name}`}
                        className={`${getTextColorClass()} hover:opacity-80`}
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => onDelete(agent.id)}
                        title={`Delete ${agent.name}`}
                        className="ml-4 text-red-400 hover:text-red-300"
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={4} className="text-center py-8 text-[var(--color-text-secondary)]">
                    No agents found for your search.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AgentManagementPage;
