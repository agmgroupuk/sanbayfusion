import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Search,
  X,
  Clock,
  TrendingUp,
  Hash,
  FileText,
  MessageSquare,
  Users,
  Settings as SettingsIcon,
  Zap,
  Command,
  Filter,
  ArrowRight,
  BarChart3,
} from 'lucide-react';
import { Agent } from '../../../constants';

interface SearchResult {
  id: string;
  type: 'agent' | 'message' | 'tool' | 'documentation' | 'setting';
  title: string;
  description: string;
  icon: React.ReactNode;
  category: string;
  lastAccessed?: string;
  onClick: () => void;
}

interface GlobalSearchProps {
  agents: Agent[];
  onNavigate: (view: any) => void;
  onSelectAgent?: (agent: Agent) => void;
  isOpen: boolean;
  onClose: () => void;
}

const GlobalSearch: React.FC<GlobalSearchProps> = ({
  agents,
  onNavigate,
  onSelectAgent,
  isOpen,
  onClose,
}) => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [recentSearches, setRecentSearches] = useState<string[]>([]);
  const [selectedFilter, setSelectedFilter] = useState<
    'all' | 'agent' | 'message' | 'tool' | 'documentation'
  >('all');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const searchInputRef = useRef<HTMLInputElement>(null);
  const resultsRef = useRef<HTMLDivElement>(null);

  // Load recent searches from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('iamai_recent_searches');
    if (saved) {
      setRecentSearches(JSON.parse(saved));
    }
  }, []);

  // Focus input when opened
  useEffect(() => {
    if (isOpen && searchInputRef.current) {
      searchInputRef.current.focus();
    }
  }, [isOpen]);

  // Save search to recent
  const saveToRecent = (searchQuery: string) => {
    if (!searchQuery.trim()) return;

    const updated = [searchQuery, ...recentSearches.filter(s => s !== searchQuery)].slice(0, 5);
    setRecentSearches(updated);
    localStorage.setItem('iamai_recent_searches', JSON.stringify(updated));
  };

  // Generate search results
  const performSearch = useCallback(
    (searchQuery: string) => {
      if (!searchQuery.trim()) {
        setResults([]);
        return;
      }

      const lowerQuery = searchQuery.toLowerCase();
      const searchResults: SearchResult[] = [];

      // Search Agents
      if (selectedFilter === 'all' || selectedFilter === 'agent') {
        agents.forEach(agent => {
          if (
            agent.name.toLowerCase().includes(lowerQuery) ||
            agent.role.toLowerCase().includes(lowerQuery) ||
            agent.description.toLowerCase().includes(lowerQuery)
          ) {
            searchResults.push({
              id: `agent-${agent.id}`,
              type: 'agent',
              title: agent.name,
              description: agent.role,
              icon: <Users className="w-5 h-5 text-purple-400" />,
              category: 'AI Agent',
              onClick: () => {
                if (onSelectAgent) onSelectAgent(agent);
                saveToRecent(searchQuery);
                onClose();
              },
            });
          }
        });
      }

      // Search Tools (example tools)
      if (selectedFilter === 'all' || selectedFilter === 'tool') {
        const tools = [
          {
            name: 'Agent Management',
            description: 'Create and manage custom agents',
            view: 'agentManagement',
          },
          {
            name: 'Activity Log',
            description: 'View conversation history and analytics',
            view: 'activityLog',
          },
          {
            name: 'API Tester',
            description: 'Test API endpoints and integrations',
            view: 'apiTester',
          },
          {
            name: 'IP Toolbox',
            description: 'Network diagnostics and IP lookup',
            view: 'ipToolbox',
          },
        ];

        tools.forEach(tool => {
          if (
            tool.name.toLowerCase().includes(lowerQuery) ||
            tool.description.toLowerCase().includes(lowerQuery)
          ) {
            searchResults.push({
              id: `tool-${tool.name}`,
              type: 'tool',
              title: tool.name,
              description: tool.description,
              icon: <Zap className="w-5 h-5 text-yellow-400" />,
              category: 'Tool',
              onClick: () => {
                onNavigate(tool.view);
                saveToRecent(searchQuery);
                onClose();
              },
            });
          }
        });
      }

      // Search Documentation
      if (selectedFilter === 'all' || selectedFilter === 'documentation') {
        const docs = [
          {
            title: 'Getting Started',
            content: 'Learn how to use IAM.AI platform',
            path: '/docs/getting-started',
          },
          {
            title: 'API Documentation',
            content: 'Integrate IAM.AI with your applications',
            path: '/docs/api',
          },
          {
            title: 'Agent Capabilities',
            content: 'Understand what each agent can do',
            path: '/docs/capabilities',
          },
          {
            title: 'Billing & Subscriptions',
            content: 'Manage your subscription and payments',
            path: '/docs/billing',
          },
          { title: 'FAQ', content: 'Frequently asked questions', path: '/docs/faq' },
        ];

        docs.forEach(doc => {
          if (
            doc.title.toLowerCase().includes(lowerQuery) ||
            doc.content.toLowerCase().includes(lowerQuery)
          ) {
            searchResults.push({
              id: `doc-${doc.path}`,
              type: 'documentation',
              title: doc.title,
              description: doc.content,
              icon: <FileText className="w-5 h-5 text-blue-400" />,
              category: 'Documentation',
              onClick: () => {
                window.open(doc.path, '_blank');
                saveToRecent(searchQuery);
                onClose();
              },
            });
          }
        });
      }

      // Search Settings
      if (selectedFilter === 'all' || lowerQuery.includes('setting')) {
        const settings = [
          { name: 'Account Settings', description: 'Manage your profile and preferences' },
          { name: 'Notification Settings', description: 'Configure alerts and notifications' },
          { name: 'Theme Settings', description: 'Customize appearance and colors' },
          { name: 'API Keys', description: 'Manage your API access keys' },
        ];

        settings.forEach(setting => {
          if (
            setting.name.toLowerCase().includes(lowerQuery) ||
            setting.description.toLowerCase().includes(lowerQuery)
          ) {
            searchResults.push({
              id: `setting-${setting.name}`,
              type: 'setting',
              title: setting.name,
              description: setting.description,
              icon: <SettingsIcon className="w-5 h-5 text-gray-400" />,
              category: 'Setting',
              onClick: () => {
                onNavigate('dashboard');
                saveToRecent(searchQuery);
                onClose();
              },
            });
          }
        });
      }

      setResults(searchResults);
      setSelectedIndex(0);
    },
    [agents, selectedFilter, onSelectAgent, onNavigate, onClose]
  );

  // Debounced search
  useEffect(() => {
    const timer = setTimeout(() => {
      performSearch(query);
    }, 200);

    return () => clearTimeout(timer);
  }, [query, performSearch]);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isOpen) return;

      switch (e.key) {
        case 'Escape':
          onClose();
          break;
        case 'ArrowDown':
          e.preventDefault();
          setSelectedIndex(prev => (prev < results.length - 1 ? prev + 1 : prev));
          break;
        case 'ArrowUp':
          e.preventDefault();
          setSelectedIndex(prev => (prev > 0 ? prev - 1 : 0));
          break;
        case 'Enter':
          e.preventDefault();
          if (results[selectedIndex]) {
            results[selectedIndex].onClick();
          }
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, results, selectedIndex, onClose]);

  // Auto-scroll selected result into view
  useEffect(() => {
    if (resultsRef.current) {
      const selectedElement = resultsRef.current.children[selectedIndex] as HTMLElement;
      if (selectedElement) {
        selectedElement.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
      }
    }
  }, [selectedIndex]);

  if (!isOpen) return null;

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[999] animate-fadeIn"
        onClick={onClose}
      />

      {/* Search Modal */}
      <div className="fixed top-20 left-1/2 transform -translate-x-1/2 w-full max-w-2xl z-[1000] px-4 animate-slideInDown">
        <div className="bg-gray-900 border border-cyan-500/30 rounded-2xl shadow-2xl shadow-cyan-500/20 overflow-hidden">
          {/* Search Input */}
          <div className="flex items-center p-4 border-b border-gray-800">
            <Search className="w-5 h-5 text-gray-400 mr-3" />
            <input
              ref={searchInputRef}
              type="text"
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="Search agents, tools, docs... (Cmd+K)"
              className="flex-1 bg-transparent text-white placeholder-gray-500 focus:outline-none text-lg"
            />
            {query && (
              <button
                onClick={() => setQuery('')}
                className="p-1 text-gray-400 hover:text-white transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            )}
            <button
              onClick={onClose}
              className="ml-2 px-3 py-1 bg-gray-800 hover:bg-gray-700 rounded-lg text-gray-400 hover:text-white transition-colors text-sm"
            >
              ESC
            </button>
          </div>

          {/* Filters */}
          <div className="flex items-center space-x-2 p-3 border-b border-gray-800 bg-gray-900/50 overflow-x-auto">
            <Filter className="w-4 h-4 text-gray-400 flex-shrink-0" />
            {(['all', 'agent', 'tool', 'documentation'] as const).map(filter => (
              <button
                key={filter}
                onClick={() => setSelectedFilter(filter)}
                className={`px-3 py-1 rounded-lg text-sm font-medium transition-colors whitespace-nowrap ${
                  selectedFilter === filter
                    ? 'bg-cyan-600 text-white'
                    : 'bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-white'
                }`}
              >
                {filter.charAt(0).toUpperCase() + filter.slice(1)}
              </button>
            ))}
          </div>

          {/* Results */}
          <div className="max-h-[60vh] overflow-y-auto">
            {query && results.length > 0 ? (
              <div ref={resultsRef} className="py-2">
                {results.map((result, index) => (
                  <button
                    key={result.id}
                    onClick={result.onClick}
                    className={`w-full flex items-center space-x-4 px-4 py-3 hover:bg-gray-800/50 transition-colors text-left ${
                      index === selectedIndex ? 'bg-gray-800/70' : ''
                    }`}
                  >
                    <div className="flex-shrink-0 p-2 bg-gray-800 rounded-lg">{result.icon}</div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center space-x-2">
                        <span className="text-white font-medium">{result.title}</span>
                        <span className="text-xs text-gray-500 px-2 py-0.5 bg-gray-800 rounded">
                          {result.category}
                        </span>
                      </div>
                      <p className="text-sm text-gray-400 truncate mt-1">{result.description}</p>
                    </div>
                    <ArrowRight className="w-4 h-4 text-gray-600 flex-shrink-0" />
                  </button>
                ))}
              </div>
            ) : query ? (
              <div className="p-8 text-center text-gray-500">
                <Search className="w-12 h-12 mx-auto mb-3 opacity-30" />
                <p>No results found for "{query}"</p>
                <p className="text-sm mt-2">Try different keywords or filters</p>
              </div>
            ) : (
              <>
                {/* Recent Searches */}
                {recentSearches.length > 0 && (
                  <div className="p-4">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="text-sm font-semibold text-gray-400 flex items-center">
                        <Clock className="w-4 h-4 mr-2" />
                        Recent Searches
                      </h3>
                      <button
                        onClick={() => {
                          setRecentSearches([]);
                          localStorage.removeItem('iamai_recent_searches');
                        }}
                        className="text-xs text-gray-500 hover:text-gray-400"
                      >
                        Clear
                      </button>
                    </div>
                    <div className="space-y-1">
                      {recentSearches.map((search, index) => (
                        <button
                          key={index}
                          onClick={() => setQuery(search)}
                          className="w-full flex items-center space-x-3 px-3 py-2 rounded-lg hover:bg-gray-800 transition-colors text-left"
                        >
                          <Hash className="w-4 h-4 text-gray-500" />
                          <span className="text-gray-300 text-sm">{search}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Quick Actions */}
                <div className="p-4 border-t border-gray-800">
                  <h3 className="text-sm font-semibold text-gray-400 mb-3 flex items-center">
                    <TrendingUp className="w-4 h-4 mr-2" />
                    Quick Actions
                  </h3>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      {
                        label: 'View Dashboard',
                        icon: <BarChart3 className="w-4 h-4" />,
                        action: () => onNavigate('dashboard'),
                      },
                      {
                        label: 'Manage Agents',
                        icon: <Users className="w-4 h-4" />,
                        action: () => onNavigate('agentManagement'),
                      },
                      {
                        label: 'Activity Log',
                        icon: <MessageSquare className="w-4 h-4" />,
                        action: () => onNavigate('activityLog'),
                      },
                      {
                        label: 'Settings',
                        icon: <SettingsIcon className="w-4 h-4" />,
                        action: () => onNavigate('account-settings'),
                      },
                    ].map((action, index) => (
                      <button
                        key={index}
                        onClick={() => {
                          action.action();
                          onClose();
                        }}
                        className="flex items-center space-x-2 px-3 py-2 bg-gray-800 hover:bg-gray-700 rounded-lg transition-colors text-left"
                      >
                        {action.icon}
                        <span className="text-sm text-gray-300">{action.label}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </>
            )}
          </div>

          {/* Footer */}
          <div className="flex items-center justify-between px-4 py-3 bg-gray-900/50 border-t border-gray-800 text-xs text-gray-500">
            <div className="flex items-center space-x-4">
              <span className="flex items-center">
                <kbd className="px-2 py-1 bg-gray-800 rounded mr-1">↑↓</kbd> Navigate
              </span>
              <span className="flex items-center">
                <kbd className="px-2 py-1 bg-gray-800 rounded mr-1">↵</kbd> Select
              </span>
              <span className="flex items-center">
                <kbd className="px-2 py-1 bg-gray-800 rounded mr-1">ESC</kbd> Close
              </span>
            </div>
            <div className="flex items-center space-x-1">
              <Command className="w-3 h-3" />
              <span>+K</span>
            </div>
          </div>
        </div>
      </div>

      <style>{`
                @keyframes slideInDown {
                    from { transform: translate(-50%, -10px); opacity: 0; }
                    to { transform: translate(-50%, 0); opacity: 1; }
                }
                .animate-slideInDown { animation: slideInDown 0.3s ease-out; }
            `}</style>
    </>
  );
};

export default GlobalSearch;
