import React, { useEffect } from 'react';

interface FilePreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  fileName: string;
  fileData: string; // base64 encoded data
  mimeType: string;
}

const DashboardFilePreview: React.FC<FilePreviewModalProps> = ({
  isOpen,
  onClose,
  fileName,
  fileData,
  mimeType,
}) => {
  useEffect(() => {
    const handleEsc = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleEsc);
    return () => {
      window.removeEventListener('keydown', handleEsc);
    };
  }, [onClose]);

  if (!isOpen) {
    return null;
  }

  const dataUri = `data:${mimeType};base64,${fileData}`;

  return (
    <div
      className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 transition-opacity duration-300 animate-fadeIn"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
    >
      <div
        className="bg-gray-900/50 border border-gray-800 rounded-2xl w-full max-w-4xl h-[90vh] m-4 text-white flex flex-col transform transition-all duration-300 animate-slideInUp"
        onClick={e => e.stopPropagation()}
      >
        <header className="flex justify-between items-center p-4 border-b border-gray-800 flex-shrink-0">
          <h2 className="text-lg font-bold truncate" title={fileName}>
            {fileName}
          </h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-white transition-colors"
            aria-label="Close file preview"
            title="Close"
          >
            <i className="fa-solid fa-times text-2xl"></i>
          </button>
        </header>
        <div className="flex-grow p-4">
          {mimeType === 'application/pdf' ? (
            <iframe src={dataUri} title={fileName} className="w-full h-full border-0 rounded-lg" />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-gray-400">
              <p>Preview is not available for this file type ({mimeType}).</p>
            </div>
          )}
        </div>
      </div>
      <style>{`
                @keyframes fadeIn {
                    from { opacity: 0; }
                    to { opacity: 1; }
                }
                @keyframes slideInUp {
                    from { transform: translateY(20px); opacity: 0; }
                    to { transform: translateY(0); opacity: 1; }
                }
                .animate-fadeIn { animation: fadeIn 0.3s ease-out forwards; }
                .animate-slideInUp { animation: slideInUp 0.3s ease-out forwards; }
            `}</style>
    </div>
  );
};

export default DashboardFilePreview;
