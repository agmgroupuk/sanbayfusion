import React, { useState } from 'react';
import { Message } from '../../../constants';

interface FeedbackControlsProps {
  messageId: number;
  feedback: Message['feedback'];
  onFeedback: (messageId: number, rating: 'good' | 'bad', comment?: string) => void;
}

const FeedbackControls: React.FC<FeedbackControlsProps> = ({ messageId, feedback, onFeedback }) => {
  const [isCommenting, setIsCommenting] = useState(false);
  const [comment, setComment] = useState('');
  const [showThankYou, setShowThankYou] = useState(false);

  const handleRatingClick = (rating: 'good' | 'bad') => {
    if (feedback?.rating) return; // Already rated, do nothing.

    onFeedback(messageId, rating);
    if (rating === 'bad') {
      setIsCommenting(true);
    } else {
      setShowThankYou(true);
      setTimeout(() => setShowThankYou(false), 2500);
    }
  };

  const handleCommentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onFeedback(messageId, 'bad', comment);
    setIsCommenting(false);
    setShowThankYou(true);
    setTimeout(() => setShowThankYou(false), 2500);
  };

  if (showThankYou) {
    return <div className="mt-2 text-xs text-gray-500">Thanks for your feedback!</div>;
  }

  if (isCommenting) {
    return (
      <form
        onSubmit={handleCommentSubmit}
        className="mt-2 flex w-full max-w-sm items-center space-x-2"
      >
        <input
          type="text"
          value={comment}
          onChange={e => setComment(e.target.value)}
          placeholder="Tell us more..."
          className="flex-grow bg-gray-700 border border-gray-600 text-xs rounded-md px-2 py-1 text-white placeholder-gray-400 focus:outline-none focus:ring-1 focus:ring-cyan-500"
          autoFocus
        />
        <button
          type="submit"
          className="text-xs text-cyan-400 hover:text-cyan-300 font-semibold px-2"
        >
          Submit
        </button>
      </form>
    );
  }

  return (
    <div className="mt-2 flex items-center space-x-3">
      <button
        onClick={() => handleRatingClick('good')}
        disabled={!!feedback?.rating}
        className="text-gray-500 disabled:cursor-not-allowed"
        aria-label="Good response"
        title="Good response"
      >
        {feedback?.rating === 'good' ? (
          <i className="fa-solid fa-thumbs-up text-green-500"></i>
        ) : (
          <i className="fa-regular fa-thumbs-up hover:text-green-500"></i>
        )}
      </button>
      <button
        onClick={() => handleRatingClick('bad')}
        disabled={!!feedback?.rating}
        className="text-gray-500 disabled:cursor-not-allowed"
        aria-label="Bad response"
        title="Bad response"
      >
        {feedback?.rating === 'bad' ? (
          <i className="fa-solid fa-thumbs-down text-red-500"></i>
        ) : (
          <i className="fa-regular fa-thumbs-down hover:text-red-500"></i>
        )}
      </button>
    </div>
  );
};

export default FeedbackControls;
