import React, { useState, useEffect } from 'react';

interface SettingsModalProps {
    isOpen: boolean;
    onClose: () => void;
    apiKeys: {
        gemini: string;
        openai: string;
        anthropic: string;
    };
    onApiKeysChange: {
        gemini: (key: string) => void;
        openai: (key: string) => void;
        anthropic: (key: string) => void;
    };
}

const ApiKeyInput: React.FC<{
    id: string;
    label: string;
    value: string;
    onChange: (value: string) => void;
}> = ({ id, label, value, onChange }) => {
    const [isVisible, setIsVisible] = useState(false);

    return (
        <div>
            <label htmlFor={id} className="block text-sm font-medium text-gray-400 mb-2">
                {label}
            </label>
            <div className="relative">
                <input
                    id={id}
                    type={isVisible ? 'text' : 'password'}
                    value={value}
                    onChange={(e) => onChange(e.target.value)}
                    placeholder={`Enter your ${label}`}
                    className="w-full bg-gray-900 border border-gray-700 rounded-lg p-3 pr-10 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                />
                <button
                    type="button"
                    onClick={() => setIsVisible(!isVisible)}
                    className="absolute inset-y-0 right-0 px-3 flex items-center text-gray-500 hover:text-cyan-400"
                    aria-label={isVisible ? 'Hide API key' : 'Show API key'}
                    title={isVisible ? 'Hide API key' : 'Show API key'}
                >
                    <i className={`fa-solid ${isVisible ? 'fa-eye-slash' : 'fa-eye'}`}></i>
                </button>
            </div>
        </div>
    );
};


const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose, apiKeys, onApiKeysChange }) => {
    useEffect(() => {
        const handleEsc = (event: KeyboardEvent) => {
            if (event.key === 'Escape') {
                onClose();
            }
        };
        window.addEventListener('keydown', handleEsc);
        return () => {
            window.removeEventListener('keydown', handleEsc);
        };
    }, [onClose]);

    if (!isOpen) {
        return null;
    }

    return (
        <div 
            className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 transition-opacity duration-300 animate-fadeIn"
            onClick={onClose}
            role="dialog"
            aria-modal="true"
        >
            <div 
                className="bg-gray-900/50 border border-gray-800 rounded-2xl p-8 w-full max-w-lg m-4 text-white transform transition-all duration-300 animate-slideInUp"
                onClick={(e) => e.stopPropagation()}
            >
                <div className="flex justify-between items-center mb-6">
                    <h2 className="text-2xl font-bold">Settings</h2>
                    <button onClick={onClose} className="text-gray-500 hover:text-white transition-colors" aria-label="Close settings" title="Close">
                        <i className="fa-solid fa-times text-2xl"></i>
                    </button>
                </div>

                <div className="space-y-6">
                    <p className="text-gray-400">
                        Manage your API keys for external providers. These keys are stored securely and used as fallbacks or for high-accuracy tasks.
                    </p>
                    
                    <ApiKeyInput
                        id="gemini-key"
                        label="Google Gemini API Key"
                        value={apiKeys.gemini}
                        onChange={onApiKeysChange.gemini}
                    />
                    
                    <ApiKeyInput
                        id="openai-key"
                        label="OpenAI API Key"
                        value={apiKeys.openai}
                        onChange={onApiKeysChange.openai}
                    />

                    <ApiKeyInput
                        id="anthropic-key"
                        label="Anthropic API Key"
                        value={apiKeys.anthropic}
                        onChange={onApiKeysChange.anthropic}
                    />
                </div>

                 <div className="mt-8 pt-6 border-t border-gray-800 flex justify-end">
                    <button
                        onClick={onClose}
                        title="Save and close"
                        className="px-6 py-2 bg-cyan-500 text-black font-semibold rounded-lg hover:bg-cyan-400 transition-colors duration-300"
                    >
                        Done
                    </button>
                </div>
            </div>
             <style>{`
                @keyframes fadeIn {
                    from { opacity: 0; }
                    to { opacity: 1; }
                }
                @keyframes slideInUp {
                    from { transform: translateY(20px); opacity: 0; }
                    to { transform: translateY(0); opacity: 1; }
                }
                .animate-fadeIn { animation: fadeIn 0.3s ease-out forwards; }
                .animate-slideInUp { animation: slideInUp 0.3s ease-out forwards; }
            `}</style>
        </div>
    );
};

export default SettingsModal;