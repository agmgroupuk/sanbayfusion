import React, { useState, useEffect } from 'react';
import {
  Trophy,
  Star,
  Award,
  Target,
  Crown,
  Zap,
  TrendingUp,
  Lock,
  Check,
  Sparkles,
} from 'lucide-react';

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  points: number;
  category: 'agent' | 'usage' | 'social' | 'milestone' | 'special';
  tier: 'bronze' | 'silver' | 'gold' | 'platinum' | 'diamond';
  unlocked: boolean;
  unlockedDate?: string;
  progress: number; // 0-100
  requirement: number;
  current: number;
}

export interface UserLevel {
  level: number;
  name: string;
  minPoints: number;
  maxPoints: number;
  currentPoints: number;
  progress: number; // 0-100
  color: string;
  icon: string;
}

interface AchievementSystemProps {
  userId?: string;
}

const AchievementSystem: React.FC<AchievementSystemProps> = ({ userId }) => {
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [userLevel, setUserLevel] = useState<UserLevel | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<'all' | Achievement['category']>('all');
  const [showNotification, setShowNotification] = useState<Achievement | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Fetch achievements from API
  useEffect(() => {
    const fetchAchievements = async () => {
      try {
        setLoading(true);
        setError(null);

        const apiBaseUrl =
          window.location.hostname === 'localhost'
            ? 'http://localhost:3001'
            : 'https://iamai.global';
        const response = await fetch(`${apiBaseUrl}/api/achievements/user`, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
          },
          credentials: 'include',
        });

        if (!response.ok) {
          throw new Error(`Failed to fetch achievements: ${response.status}`);
        }

        const data = await response.json();

        if (data.success) {
          // Transform API achievements to component format
          const transformedAchievements: Achievement[] = data.achievements.map(
            (achievement: any) => ({
              id: achievement.id,
              title: achievement.title,
              description: achievement.description,
              icon: getAchievementIcon(achievement.icon),
              points: achievement.points,
              category: achievement.category,
              tier: achievement.tier,
              unlocked: achievement.unlocked,
              unlockedDate: achievement.unlockedDate,
              progress: achievement.progress,
              requirement: achievement.requirement,
              current: achievement.current,
            })
          );

          setAchievements(transformedAchievements);
          setUserLevel(data.userLevel);
        } else {
          throw new Error(data.message || 'Failed to load achievements');
        }
      } catch (err) {
        console.error('Error fetching achievements:', err);
        setError(err instanceof Error ? err.message : 'Failed to load achievements');

        // Fallback to default achievements if API fails
        setAchievements(getDefaultAchievements());
        setUserLevel(getDefaultUserLevel());
      } finally {
        setLoading(false);
      }
    };

    fetchAchievements();
  }, [userId]);

  // Helper function to get achievement icons
  const getAchievementIcon = (iconName: string) => {
    const iconMap: Record<string, React.ReactNode> = {
      sparkles: <Sparkles className="w-6 h-6" />,
      target: <Target className="w-6 h-6" />,
      crown: <Crown className="w-6 h-6" />,
      zap: <Zap className="w-6 h-6" />,
      'trending-up': <TrendingUp className="w-6 h-6" />,
      calendar: <Calendar className="w-6 h-6" />,
      award: <Award className="w-6 h-6" />,
      trophy: <Trophy className="w-6 h-6" />,
      star: <Star className="w-6 h-6" />,
    };
    return iconMap[iconName] || <Trophy className="w-6 h-6" />;
  };

  // Default achievements for fallback
  const getDefaultAchievements = (): Achievement[] => [
    {
      id: 'first-chat',
      title: 'First Steps',
      description: 'Start your first conversation with an AI agent',
      icon: <Sparkles className="w-6 h-6" />,
      points: 50,
      category: 'agent',
      tier: 'bronze',
      unlocked: true,
      unlockedDate: new Date().toISOString(),
      progress: 100,
      requirement: 1,
      current: 1,
    },
    {
      id: 'chatterbox',
      title: 'Chatterbox',
      description: 'Send 100 messages',
      icon: <Zap className="w-6 h-6" />,
      points: 150,
      category: 'usage',
      tier: 'silver',
      unlocked: false,
      progress: 0,
      requirement: 100,
      current: 0,
    },
  ];

  // Default user level for fallback
  const getDefaultUserLevel = (): UserLevel => ({
    level: 1,
    name: 'Novice',
    minPoints: 0,
    maxPoints: 500,
    currentPoints: 50,
    progress: 10,
    color: '#f59e0b',
    icon: '🌱',
  });

  const getTierColor = (tier: Achievement['tier']) => {
    switch (tier) {
      case 'bronze':
        return 'from-orange-600 to-amber-700';
      case 'silver':
        return 'from-gray-400 to-gray-500';
      case 'gold':
        return 'from-yellow-400 to-yellow-600';
      case 'platinum':
        return 'from-cyan-400 to-blue-500';
      case 'diamond':
        return 'from-purple-500 to-pink-600';
    }
  };

  const getTierTextColor = (tier: Achievement['tier']) => {
    switch (tier) {
      case 'bronze':
        return 'text-amber-400';
      case 'silver':
        return 'text-gray-400';
      case 'gold':
        return 'text-yellow-400';
      case 'platinum':
        return 'text-cyan-400';
      case 'diamond':
        return 'text-purple-400';
    }
  };

  const filteredAchievements =
    selectedCategory === 'all'
      ? achievements
      : achievements.filter(a => a.category === selectedCategory);

  return (
    <div className="space-y-6">
      {/* User Level Card */}
      {userLevel && (
        <div className="bg-gradient-to-r from-[var(--color-surface)] via-[var(--color-surface)] to-[var(--color-surface)] border border-[var(--color-primary)]/30 rounded-2xl p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-4">
              <div className="text-5xl">{userLevel.icon}</div>
              <div>
                <h3 className="text-2xl font-bold text-[var(--color-text)]">
                  Level {userLevel.level}
                </h3>
                <p className="text-lg text-[var(--color-primary)]">{userLevel.name}</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-3xl font-bold text-[var(--color-text)]">
                {userLevel.currentPoints}
              </p>
              <p className="text-sm text-[var(--color-text-secondary)]">Total Points</p>
            </div>
          </div>
          <div className="space-y-2">
            <div className="flex justify-between text-sm text-[var(--color-text-secondary)]">
              <span>{userLevel.minPoints} pts</span>
              <span>{userLevel.maxPoints} pts</span>
            </div>
            <div className="w-full h-3 bg-[var(--color-surface-dark)] rounded-full overflow-hidden">
              <div
                className="h-full rounded-full transition-all duration-500 bg-[var(--color-primary)]"
                style={{
                  width: `${userLevel.progress}%`,
                }}
              />
            </div>
            <p className="text-center text-sm text-[var(--color-text-secondary)]">
              {userLevel.maxPoints - userLevel.currentPoints} points to next level
            </p>
          </div>
        </div>
      )}

      {/* Category Filter */}
      <div className="flex space-x-2 overflow-x-auto pb-2">
        {(['all', 'agent', 'usage', 'social', 'milestone', 'special'] as const).map(category => (
          <button
            key={category}
            onClick={() => setSelectedCategory(category)}
            className={`px-4 py-2 rounded-lg font-medium text-sm whitespace-nowrap transition-all ${
              selectedCategory === category
                ? 'bg-[var(--color-primary)] text-[var(--color-text)] shadow-lg shadow-[var(--color-primary)]/20'
                : 'bg-[var(--color-surface)] text-[var(--color-text-secondary)] hover:bg-[var(--color-surface-hover)] hover:text-[var(--color-text)]'
            }`}
          >
            {category.charAt(0).toUpperCase() + category.slice(1)}
          </button>
        ))}
      </div>

      {/* Achievements Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredAchievements.map(achievement => (
          <div
            key={achievement.id}
            className={`relative p-6 rounded-xl border-2 transition-all ${
              achievement.unlocked
                ? 'bg-gradient-to-br from-[var(--color-surface)] to-[var(--color-surface-light)] border-[var(--color-primary)]/30 hover:border-[var(--color-primary)]/50'
                : 'bg-[var(--color-surface)]/50 border-[var(--color-border)] opacity-75'
            }`}
          >
            {/* Lock Overlay */}
            {!achievement.unlocked && (
              <div className="absolute top-4 right-4">
                <div className="p-2 bg-[var(--color-surface-dark)] rounded-lg">
                  <Lock className="w-4 h-4 text-[var(--color-text-secondary)]" />
                </div>
              </div>
            )}

            {/* Achievement Content */}
            <div className="flex items-start space-x-4">
              <div
                className={`p-3 rounded-xl bg-gradient-to-br ${getTierColor(achievement.tier)} ${achievement.unlocked ? 'text-white' : 'opacity-50 text-gray-300'}`}
              >
                {achievement.icon}
              </div>
              <div className="flex-1">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <h4 className="text-lg font-bold text-[var(--color-text)] flex items-center space-x-2">
                      <span>{achievement.title}</span>
                      {achievement.unlocked && <Check className="w-4 h-4 text-green-400" />}
                    </h4>
                    <p className={`text-xs font-semibold ${getTierTextColor(achievement.tier)}`}>
                      {achievement.tier.toUpperCase()} • {achievement.points} pts
                    </p>
                  </div>
                </div>
                <p className="text-sm text-[var(--color-text-secondary)] mb-3">
                  {achievement.description}
                </p>

                {/* Progress Bar */}
                {!achievement.unlocked && (
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs text-[var(--color-text-secondary)]">
                      <span>
                        Progress: {achievement.current}/{achievement.requirement}
                      </span>
                      <span>{achievement.progress}%</span>
                    </div>
                    <div className="w-full h-2 bg-[var(--color-surface-dark)] rounded-full overflow-hidden">
                      <div
                        className={`h-full bg-gradient-to-r ${getTierColor(achievement.tier)} transition-all duration-500`}
                        style={{ width: `${achievement.progress}%` }}
                      />
                    </div>
                  </div>
                )}

                {/* Unlocked Date */}
                {achievement.unlocked && achievement.unlockedDate && (
                  <p className="text-xs text-[var(--color-text-secondary)] mt-2">
                    Unlocked {new Date(achievement.unlockedDate).toLocaleDateString()}
                  </p>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Stats Summary */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-[var(--color-surface)]/50 border border-[var(--color-border)] rounded-xl p-4 text-center">
          <div className="text-3xl font-bold text-[var(--color-text)]">
            {achievements.filter(a => a.unlocked).length}
          </div>
          <p className="text-sm text-[var(--color-text-secondary)] mt-1">Achievements Unlocked</p>
        </div>
        <div className="bg-[var(--color-surface)]/50 border border-[var(--color-border)] rounded-xl p-4 text-center">
          <div className="text-3xl font-bold text-[var(--color-text)]">{achievements.length}</div>
          <p className="text-sm text-[var(--color-text-secondary)] mt-1">Total Achievements</p>
        </div>
        <div className="bg-[var(--color-surface)]/50 border border-[var(--color-border)] rounded-xl p-4 text-center">
          <div className="text-3xl font-bold text-[var(--color-text)]">
            {Math.round((achievements.filter(a => a.unlocked).length / achievements.length) * 100)}%
          </div>
          <p className="text-sm text-[var(--color-text-secondary)] mt-1">Completion Rate</p>
        </div>
        <div className="bg-[var(--color-surface)]/50 border border-[var(--color-border)] rounded-xl p-4 text-center">
          <div className="text-3xl font-bold text-[var(--color-text)]">
            {achievements.filter(a => a.unlocked).reduce((sum, a) => sum + a.points, 0)}
          </div>
          <p className="text-sm text-[var(--color-text-secondary)] mt-1">Points Earned</p>
        </div>
      </div>

      {/* Achievement Notification */}
      {showNotification && (
        <div className="fixed bottom-6 right-6 z-[100] animate-slideInRight">
          <div className="bg-gradient-to-r from-green-600 to-emerald-600 border border-green-500 rounded-xl p-4 shadow-2xl shadow-green-500/30 max-w-sm">
            <div className="flex items-start space-x-3">
              <div className="p-2 bg-white/20 rounded-lg">
                <Trophy className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1">
                <h4 className="text-white font-bold mb-1">Achievement Unlocked!</h4>
                <p className="text-green-100 text-sm">{showNotification.title}</p>
                <p className="text-green-200 text-xs mt-1">+{showNotification.points} points</p>
              </div>
              <button
                onClick={() => setShowNotification(null)}
                className="text-white/80 hover:text-white"
              >
                ×
              </button>
            </div>
          </div>
        </div>
      )}

      <style>{`
                @keyframes slideInRight {
                    from { transform: translateX(100%); opacity: 0; }
                    to { transform: translateX(0); opacity: 1; }
                }
                .animate-slideInRight { animation: slideInRight 0.4s ease-out; }
            `}</style>
    </div>
  );
};

export default AchievementSystem;
