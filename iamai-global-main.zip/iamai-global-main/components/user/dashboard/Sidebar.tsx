import React from 'react';
import { Agent } from '../../../constants';
import { DashboardView } from './Dashboard';
import { useTheme } from '../../../contexts/ThemeContext';

interface SidebarProps {
  agents: Agent[];
  selectedAgent: Agent;
  onNavigateToChat: (agent: Agent) => void;
  onNavigateToProfile: (agent: Agent) => void;
  onLogout: () => void;
  subscriptions: Record<string, string>;
  onNavigate: (view: DashboardView) => void;
  currentView: DashboardView;
  onNavigateToHome?: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({
  agents,
  selectedAgent,
  onNavigateToChat,
  onNavigateToProfile,
  onLogout,
  subscriptions,
  onNavigate,
  currentView,
  onNavigateToHome,
}) => {
  // Theme context for dynamic theming
  const { theme, themeColors } = useTheme();

  // Dynamic theme utility functions
  const getActiveClass = () => {
    return `bg-[var(--color-primary)]/10 text-[var(--color-primary)]`;
  };

  const getHoverClass = () => {
    return `text-[var(--color-text-secondary)] hover:text-[var(--color-text)] hover:bg-[var(--color-surface)]/50`;
  };

  return (
    <aside
      className={`w-64 hidden md:flex bg-[var(--color-background)] border-r border-[var(--color-border)] flex flex-col p-4`}
    >
      <div className={`text-2xl font-bold text-[var(--color-text)] mb-6`}>
        IA <span className="text-[var(--color-primary)]">M</span> AI
      </div>
      <nav className="flex-grow overflow-y-auto">
        <h3
          className={`text-xs font-semibold text-[var(--color-text-secondary)] uppercase tracking-wider mb-3 px-2`}
        >
          Navigation
        </h3>
        <ul className="space-y-2">
          <li>
            <button
              onClick={() => onNavigate('dashboard')}
              className={`w-full flex items-center space-x-3 px-3 py-3 rounded-lg text-left transition-colors ${
                currentView === 'dashboard' ? getActiveClass() : getHoverClass()
              }`}
            >
              <i className="fa-solid fa-home w-5 h-5"></i>
              <span className="font-medium">Dashboard</span>
            </button>
          </li>
          <li>
            <button
              onClick={() => (window.location.href = '/agents')}
              className={`w-full flex items-center space-x-3 px-3 py-3 rounded-lg text-left transition-colors ${getHoverClass()}`}
            >
              <i className="fa-solid fa-robot w-5 h-5"></i>
              <span className="font-medium">Browse Agents</span>
            </button>
          </li>
          <li>
            <button
              onClick={() => {
                window.location.href = '/';
              }}
              className={`w-full flex items-center space-x-3 px-3 py-3 rounded-lg text-left transition-colors ${getHoverClass()}`}
            >
              <i className="fa-solid fa-globe w-5 h-5"></i>
              <span className="font-medium">Visit Site</span>
            </button>
          </li>
        </ul>

        {/* Account Section */}
        <h3
          className={`text-xs font-semibold text-[var(--color-text-secondary)] uppercase tracking-wider mb-3 px-2 mt-6`}
        >
          Account
        </h3>
        <ul className="space-y-1">
          <li>
            <button
              onClick={() => onNavigate('account-profile')}
              className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left transition-colors text-sm ${
                currentView === 'account-profile' ? getActiveClass() : getHoverClass()
              }`}
            >
              <i className="fa-solid fa-user w-4 h-4"></i>
              <span>Profile</span>
            </button>
          </li>
          <li>
            <button
              onClick={() => onNavigate('account-billing')}
              className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left transition-colors text-sm ${
                currentView === 'account-billing' ? getActiveClass() : getHoverClass()
              }`}
            >
              <i className="fa-solid fa-credit-card w-4 h-4"></i>
              <span>Billing</span>
            </button>
          </li>
          <li>
            <button
              onClick={() => onNavigate('account-subscriptions')}
              className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left transition-colors text-sm ${
                currentView === 'account-subscriptions' ? getActiveClass() : getHoverClass()
              }`}
            >
              <i className="fa-solid fa-star w-4 h-4"></i>
              <span>Subscriptions</span>
            </button>
          </li>
          <li>
            <button
              onClick={() => onNavigate('account-security')}
              className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left transition-colors text-sm ${
                currentView === 'account-security' ? getActiveClass() : getHoverClass()
              }`}
            >
              <i className="fa-solid fa-shield w-4 h-4"></i>
              <span>Security</span>
            </button>
          </li>
          <li>
            <button
              onClick={() => onNavigate('account-settings')}
              className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left transition-colors text-sm ${
                currentView === 'account-settings' ? getActiveClass() : getHoverClass()
              }`}
            >
              <i className="fa-solid fa-cog w-4 h-4"></i>
              <span>Settings</span>
            </button>
          </li>
          <li>
            <button
              onClick={() => onNavigate('account-analytics')}
              className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left transition-colors text-sm ${
                currentView === 'account-analytics' ? getActiveClass() : getHoverClass()
              }`}
            >
              <i className="fa-solid fa-chart-line w-4 h-4"></i>
              <span>Analytics</span>
            </button>
          </li>
        </ul>

        {/* Management Section */}
        <h3
          className={`text-xs font-semibold text-[var(--color-text-secondary)] uppercase tracking-wider mb-3 px-2 mt-6`}
        >
          Management
        </h3>
        <ul className="space-y-2">
          <li>
            <button
              onClick={() => onNavigate('agentManagement')}
              className={`w-full flex items-center space-x-3 px-3 py-3 rounded-lg text-left transition-colors ${
                currentView === 'agentManagement' ? getActiveClass() : getHoverClass()
              }`}
            >
              <i className="fa-solid fa-cogs w-5 h-5"></i>
              <span className="font-medium">Agent Management</span>
            </button>
          </li>
          <li>
            <button
              onClick={() => onNavigate('activityLog')}
              className={`w-full flex items-center space-x-3 px-3 py-3 rounded-lg text-left transition-colors ${
                currentView === 'activityLog' ? getActiveClass() : getHoverClass()
              }`}
            >
              <i className="fa-solid fa-history w-5 h-5"></i>
              <span className="font-medium">Activity Log</span>
            </button>
          </li>
        </ul>
      </nav>
    </aside>
  );
};

export default Sidebar;
