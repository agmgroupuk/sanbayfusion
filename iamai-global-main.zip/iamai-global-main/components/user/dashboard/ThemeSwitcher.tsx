import React, { useState } from 'react';
import {
  Palette,
  Check,
  Monitor,
  Sun,
  Moon,
  Waves,
  Trees,
  Sunset as SunsetIcon,
  Zap,
} from 'lucide-react';
import { useTheme } from '../../../contexts/ThemeContext';
type Theme = 'dark' | 'light' | 'midnight' | 'ocean' | 'forest' | 'sunset' | 'cyberpunk';

interface ThemeSwitcherProps {
  isDropdown?: boolean;
}

const ThemeSwitcher: React.FC<ThemeSwitcherProps> = ({ isDropdown = false }) => {
  const { theme: currentTheme, setTheme, availableThemes } = useTheme();
  const [isOpen, setIsOpen] = useState(false);

  const themeIcons: Record<Theme, React.ReactNode> = {
    dark: <Moon className="w-5 h-5" />,
    light: <Sun className="w-5 h-5" />,
    midnight: <Monitor className="w-5 h-5" />,
    ocean: <Waves className="w-5 h-5" />,
    forest: <Trees className="w-5 h-5" />,
    sunset: <SunsetIcon className="w-5 h-5" />,
    cyberpunk: <Zap className="w-5 h-5" />,
  };

  // If used as dropdown, render only the dropdown content
  if (isDropdown) {
    return (
      <div className="w-80 bg-[var(--color-background)] border border-[var(--color-border)] rounded-xl shadow-2xl shadow-[var(--color-primary)]/10 overflow-hidden animate-slideIn">
        <div className="p-4 border-b border-[var(--color-border)]">
          <h3 className="text-lg font-bold text-[var(--color-text)] flex items-center">
            <Palette className="w-5 h-5 text-[var(--color-primary)] mr-2" />
            Choose Your Theme
          </h3>
          <p className="text-sm text-[var(--color-text-secondary)] mt-1">
            Customize your dashboard appearance
          </p>
        </div>

        <div className="p-4 max-h-96 overflow-y-auto">
          <div className="grid grid-cols-2 gap-3">
            {availableThemes.map(themeOption => {
              const isActive = currentTheme === themeOption.name;
              return (
                <button
                  key={themeOption.name}
                  onClick={() => {
                    setTheme(themeOption.name);
                  }}
                  className={`relative p-4 rounded-lg border-2 transition-all group ${
                    isActive
                      ? 'border-[var(--color-primary)] bg-[var(--color-primary)]/10'
                      : 'border-[var(--color-border)] hover:border-[var(--color-primary)]/50 bg-[var(--color-surface)]/50'
                  }`}
                >
                  {/* Theme Preview */}
                  <div
                    className="w-full h-16 rounded-lg mb-3 relative overflow-hidden"
                    style={{
                      background: `linear-gradient(135deg, ${themeOption.primary} 0%, ${themeOption.secondary} 50%, ${themeOption.accent} 100%)`,
                    }}
                  >
                    <div
                      className="absolute inset-0 opacity-20"
                      style={{ backgroundColor: themeOption.background }}
                    />
                    <div
                      className="absolute bottom-0 left-0 right-0 h-1/3"
                      style={{ backgroundColor: themeOption.surface, opacity: 0.8 }}
                    />
                  </div>

                  {/* Theme Info */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div style={{ color: themeOption.primary }}>
                        {themeIcons[themeOption.name]}
                      </div>
                      <span
                        className={`text-sm font-semibold ${isActive ? 'text-[var(--color-text)]' : 'text-[var(--color-text-secondary)] group-hover:text-[var(--color-text)]'}`}
                      >
                        {themeOption.displayName}
                      </span>
                    </div>
                    {isActive && (
                      <div className="w-5 h-5 rounded-full bg-[var(--color-primary)] flex items-center justify-center">
                        <Check className="w-3 h-3 text-[var(--color-background)]" />
                      </div>
                    )}
                  </div>

                  {/* Color Palette Preview */}
                  <div className="mt-3 flex space-x-1">
                    {[themeOption.primary, themeOption.secondary, themeOption.accent].map(
                      (color, idx) => (
                        <div
                          key={idx}
                          className="h-2 rounded-full flex-1"
                          style={{ backgroundColor: color }}
                        />
                      )
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        <div className="p-4 border-t border-[var(--color-border)] bg-[var(--color-background)]/50">
          <p className="text-xs text-[var(--color-text-secondary)] text-center">
            Theme preference is saved automatically
          </p>
        </div>

        <style>{`
                    @keyframes slideIn {
                        from { opacity: 0; transform: translateY(-10px); }
                        to { opacity: 1; transform: translateY(0); }
                    }
                    .animate-slideIn { animation: slideIn 0.2s ease-out; }
                `}</style>
      </div>
    );
  }

  // Regular button with dropdown
  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center space-x-2 px-4 py-2 bg-[var(--color-surface)] hover:bg-[var(--color-surface)]/80 border border-[var(--color-border)] rounded-lg transition-colors"
        aria-label="Change theme"
      >
        <Palette className="w-5 h-5 text-[var(--color-primary)]" />
        <span className="text-[var(--color-text)] text-sm font-medium">Theme</span>
      </button>

      {isOpen && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setIsOpen(false)} />
          <div className="absolute right-0 top-full mt-2 w-80 bg-[var(--color-background)] border border-[var(--color-border)] rounded-xl shadow-2xl shadow-[var(--color-primary)]/10 z-50 overflow-hidden animate-slideIn">
            <div className="p-4 border-b border-[var(--color-border)]">
              <h3 className="text-lg font-bold text-[var(--color-text)] flex items-center">
                <Palette className="w-5 h-5 text-[var(--color-primary)] mr-2" />
                Choose Your Theme
              </h3>
              <p className="text-sm text-[var(--color-text-secondary)] mt-1">
                Customize your dashboard appearance
              </p>
            </div>

            <div className="p-4 max-h-96 overflow-y-auto">
              <div className="grid grid-cols-2 gap-3">
                {availableThemes.map(themeOption => {
                  const isActive = currentTheme === themeOption.name;
                  return (
                    <button
                      key={themeOption.name}
                      onClick={() => {
                        setTheme(themeOption.name);
                        setTimeout(() => setIsOpen(false), 300);
                      }}
                      className={`relative p-4 rounded-lg border-2 transition-all group ${
                        isActive
                          ? 'border-[var(--color-primary)] bg-[var(--color-primary)]/10'
                          : 'border-[var(--color-border)] hover:border-[var(--color-primary)]/50 bg-[var(--color-surface)]/50'
                      }`}
                    >
                      {/* Theme Preview */}
                      <div
                        className="w-full h-16 rounded-lg mb-3 relative overflow-hidden"
                        style={{
                          background: `linear-gradient(135deg, ${themeOption.primary} 0%, ${themeOption.secondary} 50%, ${themeOption.accent} 100%)`,
                        }}
                      >
                        <div
                          className="absolute inset-0 opacity-20"
                          style={{ backgroundColor: themeOption.background }}
                        />
                        <div
                          className="absolute bottom-0 left-0 right-0 h-1/3"
                          style={{ backgroundColor: themeOption.surface, opacity: 0.8 }}
                        />
                      </div>

                      {/* Theme Info */}
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <div style={{ color: themeOption.primary }}>
                            {themeIcons[themeOption.name]}
                          </div>
                          <span
                            className={`text-sm font-semibold ${isActive ? 'text-[var(--color-text)]' : 'text-[var(--color-text-secondary)] group-hover:text-[var(--color-text)]'}`}
                          >
                            {themeOption.displayName}
                          </span>
                        </div>
                        {isActive && (
                          <div className="w-5 h-5 rounded-full bg-[var(--color-primary)] flex items-center justify-center">
                            <Check className="w-3 h-3 text-[var(--color-background)]" />
                          </div>
                        )}
                      </div>

                      {/* Color Palette Preview */}
                      <div className="mt-3 flex space-x-1">
                        {[themeOption.primary, themeOption.secondary, themeOption.accent].map(
                          (color, idx) => (
                            <div
                              key={idx}
                              className="h-2 rounded-full flex-1"
                              style={{ backgroundColor: color }}
                            />
                          )
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="p-4 border-t border-[var(--color-border)] bg-[var(--color-background)]/50">
              <p className="text-xs text-[var(--color-text-secondary)] text-center">
                Theme preference is saved automatically
              </p>
            </div>
          </div>
        </>
      )}

      <style>{`
                @keyframes slideIn {
                    from { opacity: 0; transform: translateY(-10px); }
                    to { opacity: 1; transform: translateY(0); }
                }
                .animate-slideIn { animation: slideIn 0.2s ease-out; }
            `}</style>
    </div>
  );
};

export default ThemeSwitcher;
