import React, { useState, useEffect } from 'react';
import { X, ChevronLeft, ChevronRight, Check, Sparkles, MessageSquare, Users, Settings, Zap, Target } from 'lucide-react';

interface OnboardingStep {
    id: string;
    title: string;
    description: string;
    icon: React.ReactNode;
    targetElement?: string;
    position?: 'top' | 'bottom' | 'left' | 'right' | 'center';
    action?: {
        label: string;
        onClick: () => void;
    };
}

interface OnboardingTutorialProps {
    onComplete: () => void;
    onSkip: () => void;
}

const OnboardingTutorial: React.FC<OnboardingTutorialProps> = ({ onComplete, onSkip }) => {
    const [currentStep, setCurrentStep] = useState(0);
    const [isVisible, setIsVisible] = useState(true);
    const [completedSteps, setCompletedSteps] = useState<Set<string>>(new Set());

    const steps: OnboardingStep[] = [
        {
            id: 'welcome',
            title: '🎉 Welcome to IAM.AI!',
            description: 'Your intelligent multi-agent platform. Let\'s take a quick tour to help you get started with all the amazing features.',
            icon: <Sparkles className="w-8 h-8 text-cyan-400" />,
            position: 'center'
        },
        {
            id: 'dashboard',
            title: '📊 Dashboard Overview',
            description: 'This is your command center. Here you can view your usage stats, active subscriptions, recent activity, and performance metrics in real-time.',
            icon: <Target className="w-8 h-8 text-blue-400" />,
            targetElement: '[data-tour="dashboard-overview"]',
            position: 'bottom'
        },
        {
            id: 'agents',
            title: '🤖 Your AI Agents',
            description: 'Browse and select from 17 specialized AI agents. Each has unique capabilities - from AI Girlfriend to PDFMind to ChatRevive. Click any agent to start chatting!',
            icon: <Users className="w-8 h-8 text-purple-400" />,
            targetElement: '[data-tour="agent-list"]',
            position: 'right'
        },
        {
            id: 'messaging',
            title: '💬 Start Conversations',
            description: 'Chat with any agent instantly. Attach files, use voice input, switch between AI models, and enjoy real-time streaming responses.',
            icon: <MessageSquare className="w-8 h-8 text-green-400" />,
            targetElement: '[data-tour="chat-area"]',
            position: 'left'
        },
        {
            id: 'subscriptions',
            title: '🚀 Subscription Plans',
            description: 'Choose from Daily ($1), Weekly ($5), or Monthly ($19) plans. Upgrade anytime to unlock unlimited access to all agents and features.',
            icon: <Zap className="w-8 h-8 text-yellow-400" />,
            targetElement: '[data-tour="subscriptions"]',
            position: 'top'
        },
        {
            id: 'settings',
            title: '⚙️ Customize Your Experience',
            description: 'Access settings to configure notifications, change themes, manage payment methods, and personalize your dashboard.',
            icon: <Settings className="w-8 h-8 text-gray-400" />,
            targetElement: '[data-tour="settings"]',
            position: 'bottom'
        },
        {
            id: 'complete',
            title: '✨ You\'re All Set!',
            description: 'You\'ve completed the tour! Start exploring your AI agents, or revisit this tutorial anytime from the help menu.',
            icon: <Check className="w-8 h-8 text-green-400" />,
            position: 'center'
        }
    ];

    const currentStepData = steps[currentStep];
    const progress = ((currentStep + 1) / steps.length) * 100;

    useEffect(() => {
        // Track analytics
        if (currentStepData) {
            console.log(`Onboarding: Step ${currentStep + 1} - ${currentStepData.id}`);
            
            // Scroll highlighted element into view with offset for top modal
            if (currentStepData.targetElement) {
                setTimeout(() => {
                    const element = document.querySelector(currentStepData.targetElement!);
                    if (element) {
                        element.scrollIntoView({ 
                            behavior: 'smooth', 
                            block: 'center'
                        });
                    }
                }, 100);
            }
        }
    }, [currentStep, currentStepData]);

    const handleNext = () => {
        setCompletedSteps(prev => new Set(prev).add(currentStepData.id));
        
        if (currentStep < steps.length - 1) {
            setCurrentStep(currentStep + 1);
        } else {
            handleComplete();
        }
    };

    const handlePrev = () => {
        if (currentStep > 0) {
            setCurrentStep(currentStep - 1);
        }
    };

    const handleComplete = () => {
        setIsVisible(false);
        localStorage.setItem('iamai_onboarding_completed', 'true');
        localStorage.setItem('iamai_onboarding_completed_date', new Date().toISOString());
        setTimeout(() => onComplete(), 300);
    };

    const handleSkip = () => {
        setIsVisible(false);
        localStorage.setItem('iamai_onboarding_skipped', 'true');
        setTimeout(() => onSkip(), 300);
    };

    const getPositionClasses = () => {
        // Always keep the tutorial modal at the top of the screen
        // Only the first "welcome" step is centered, all others stay at top
        if (currentStepData.position === 'center') {
            return 'fixed inset-0 flex items-center justify-center z-[100]';
        }
        // For all other steps, keep modal at top so content below is accessible
        return 'fixed top-4 left-1/2 transform -translate-x-1/2 z-[100]';
    };

    if (!isVisible) return null;

    return (
        <>
            {/* Backdrop Overlay - dims background but allows clicks on highlighted elements */}
            <div className={`fixed inset-0 z-[99] animate-fadeIn pointer-events-none ${
                currentStepData.position === 'center' 
                    ? 'bg-black/70 backdrop-blur-sm' 
                    : 'bg-black/30'
            }`} />

            {/* Tutorial Card */}
            <div className={getPositionClasses()}>
                <div className={`bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 border-2 border-cyan-500/30 rounded-2xl shadow-2xl shadow-cyan-500/20 max-w-lg w-full mx-4 animate-slideInUp pointer-events-auto relative ${isVisible ? 'opacity-100' : 'opacity-0'} transition-opacity duration-300`} style={{ zIndex: 9999 }}>
                    {/* Header */}
                    <div className="relative p-6 border-b border-gray-700">
                        <button
                            type="button"
                            onClick={(e) => {
                                e.stopPropagation();
                                e.preventDefault();
                                handleSkip();
                            }}
                            className="absolute top-4 right-4 text-gray-400 hover:text-white transition-colors z-10 cursor-pointer"
                            aria-label="Skip tutorial"
                        >
                            <X className="w-5 h-5" />
                        </button>
                        
                        <div className="flex items-center space-x-4">
                            <div className="p-3 bg-gradient-to-br from-cyan-500/20 to-blue-500/20 rounded-xl border border-cyan-500/30">
                                {currentStepData.icon}
                            </div>
                            <div className="flex-1">
                                <h3 className="text-xl font-bold text-white">{currentStepData.title}</h3>
                                <p className="text-sm text-gray-400 mt-1">Step {currentStep + 1} of {steps.length}</p>
                            </div>
                        </div>
                    </div>

                    {/* Progress Bar */}
                    <div className="px-6 pt-4">
                        <div className="w-full h-2 bg-gray-700 rounded-full overflow-hidden">
                            <div
                                className="h-full bg-gradient-to-r from-cyan-500 to-blue-500 transition-all duration-500 ease-out"
                                style={{ width: `${progress}%` }}
                            />
                        </div>
                    </div>

                    {/* Content */}
                    <div className="p-6">
                        <p className="text-gray-300 text-base leading-relaxed">
                            {currentStepData.description}
                        </p>

                        {currentStepData.action && (
                            <button
                                onClick={currentStepData.action.onClick}
                                className="mt-4 w-full px-4 py-2 bg-cyan-600 hover:bg-cyan-700 text-white font-semibold rounded-lg transition-colors"
                            >
                                {currentStepData.action.label}
                            </button>
                        )}
                    </div>

                    {/* Footer Navigation */}
                    <div className="flex items-center justify-between p-6 border-t border-gray-700">
                        <button
                            type="button"
                            onClick={(e) => {
                                e.stopPropagation();
                                e.preventDefault();
                                handlePrev();
                            }}
                            disabled={currentStep === 0}
                            className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-semibold transition-colors z-10 ${
                                currentStep === 0
                                    ? 'text-gray-600 cursor-not-allowed'
                                    : 'text-gray-300 hover:text-white hover:bg-gray-700 cursor-pointer'
                            }`}
                        >
                            <ChevronLeft className="w-4 h-4" />
                            <span>Previous</span>
                        </button>

                        <div className="flex space-x-2">
                            {steps.map((step, index) => (
                                <div
                                    key={step.id}
                                    className={`w-2 h-2 rounded-full transition-all duration-300 ${
                                        index === currentStep
                                            ? 'bg-cyan-500 w-8'
                                            : completedSteps.has(step.id)
                                            ? 'bg-cyan-500/50'
                                            : 'bg-gray-600'
                                    }`}
                                />
                            ))}
                        </div>

                        <button
                            type="button"
                            onClick={(e) => {
                                e.stopPropagation();
                                e.preventDefault();
                                handleNext();
                            }}
                            className="flex items-center space-x-2 px-6 py-2 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700 text-white font-semibold rounded-lg transition-all shadow-lg shadow-cyan-500/20 cursor-pointer z-10"
                        >
                            <span>{currentStep === steps.length - 1 ? 'Finish' : 'Next'}</span>
                            {currentStep === steps.length - 1 ? (
                                <Check className="w-4 h-4" />
                            ) : (
                                <ChevronRight className="w-4 h-4" />
                            )}
                        </button>
                    </div>

                    {/* Skip Link */}
                    <div className="px-6 pb-6 text-center">
                        <button
                            type="button"
                            onClick={(e) => {
                                e.stopPropagation();
                                e.preventDefault();
                                handleSkip();
                            }}
                            className="text-sm text-gray-400 hover:text-gray-300 transition-colors cursor-pointer z-10"
                        >
                            Skip tutorial
                        </button>
                    </div>
                </div>
            </div>

            {/* Spotlight Effect for Targeted Elements */}
            {currentStepData.targetElement && (
                <style>{`
                    ${currentStepData.targetElement} {
                        position: relative;
                        z-index: 101;
                        pointer-events: auto;
                        box-shadow: 0 0 0 4px rgba(6, 182, 212, 0.3), 0 0 60px 20px rgba(6, 182, 212, 0.2);
                        border-radius: 12px;
                        animation: pulse 2s infinite;
                    }
                    @keyframes pulse {
                        0%, 100% { box-shadow: 0 0 0 4px rgba(6, 182, 212, 0.3), 0 0 60px 20px rgba(6, 182, 212, 0.2); }
                        50% { box-shadow: 0 0 0 8px rgba(6, 182, 212, 0.4), 0 0 80px 30px rgba(6, 182, 212, 0.3); }
                    }
                    @keyframes fadeIn {
                        from { opacity: 0; }
                        to { opacity: 1; }
                    }
                    @keyframes slideInUp {
                        from { transform: translateY(20px); opacity: 0; }
                        to { transform: translateY(0); opacity: 1; }
                    }
                    .animate-fadeIn { animation: fadeIn 0.3s ease-out; }
                    .animate-slideInUp { animation: slideInUp 0.4s ease-out; }
                `}</style>
            )}
        </>
    );
};

export default OnboardingTutorial;
