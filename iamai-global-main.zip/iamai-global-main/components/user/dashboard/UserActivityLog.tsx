import React, { useState, useMemo, useEffect } from 'react';
import { useTheme } from '../../../contexts/ThemeContext';

interface UserActivity {
  id: string;
  // "action" is used by older responses; "type"/"details" by newer ones
  action?: string;
  type?: string;
  description?: string;
  details?: string;
  timestamp: string;
  ipAddress?: string;
  userAgent?: string;
  location?: {
    country: string;
    city: string;
  };
  metadata?: any;
}

const actionColors: Record<string, string> = {
  LOGIN_SUCCESS: 'bg-green-500/20 text-green-300',
  LOGIN_FAILED: 'bg-red-500/20 text-red-300',
  LOGOUT: 'bg-blue-500/20 text-blue-300',
  PROFILE_UPDATE: 'bg-purple-500/20 text-purple-300',
  PASSWORD_CHANGE: 'bg-yellow-500/20 text-yellow-300',
  SECURITY_PASSWORD_CHANGED: 'bg-yellow-500/20 text-yellow-300',
  AI_CHAT_MESSAGE: 'bg-cyan-500/20 text-cyan-300',
  SUBSCRIPTION_UPGRADE: 'bg-emerald-500/20 text-emerald-300',
  SUBSCRIPTION_VIEW: 'bg-emerald-500/20 text-emerald-300',
  SIGNUP_SUCCESS: 'bg-indigo-500/20 text-indigo-300',
  SIGNUP_FAILED: 'bg-red-500/20 text-red-300',
  EMAIL_CHANGE: 'bg-orange-500/20 text-orange-300',
  SETTINGS_UPDATE: 'bg-pink-500/20 text-pink-300',
  SECURITY_NOTIFICATIONS_UPDATED: 'bg-pink-500/20 text-pink-300',
  SECURITY_SESSIONS_TERMINATED: 'bg-red-500/20 text-red-300',
  AGENT_SELECTED: 'bg-teal-500/20 text-teal-300',
  default: 'bg-gray-500/20 text-gray-300',
};

// Actions to filter out (noise that users don't care about)
const HIDDEN_ACTIONS = ['API_CALL', 'WS_CONNECT', 'WS_DISCONNECT', 'PAGE_VIEW'];

// Friendly display names for actions
const actionDisplayNames: Record<string, string> = {
  LOGIN_SUCCESS: 'Login Success',
  LOGIN_FAILED: 'Login Failed',
  LOGOUT: 'Logged Out',
  PROFILE_UPDATE: 'Profile Updated',
  SECURITY_PASSWORD_CHANGED: 'Password Changed',
  AI_CHAT_MESSAGE: 'AI Chat',
  SUBSCRIPTION_VIEW: 'Viewed Subscription',
  SUBSCRIPTION_UPGRADE: 'Subscription Upgraded',
  AGENT_PURCHASED: 'Agent Plan Purchased',
  SIGNUP_SUCCESS: 'Account Created',
  SIGNUP_FAILED: 'Signup Failed',
  SECURITY_NOTIFICATIONS_UPDATED: 'Notifications Updated',
  SECURITY_SESSIONS_TERMINATED: 'Sessions Terminated',
  AGENT_SELECTED: 'Agent Selected',
  EMAIL_CHANGE: 'Email Changed',
  SETTINGS_UPDATE: 'Settings Updated',
};

const UserActivityLog: React.FC = () => {
  const { theme, themeColors } = useTheme();

  const getBorderClass = (opacity = 20) => {
    return `border border-[var(--color-primary)]/${opacity}`;
  };

  const getTextColorClass = (isPrimary = true) => {
    return isPrimary ? 'text-[var(--color-primary)]' : 'text-[var(--color-text)]';
  };

  const [activities, setActivities] = useState<UserActivity[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [dateRange, setDateRange] = useState<'all' | '24h' | '7d' | '30d'>('all');
  const [activityType, setActivityType] = useState<'all' | string>('all');
  const [pagination, setPagination] = useState({
    page: 1,
    limit: 50,
    total: 0,
    pages: 0,
    hasNext: false,
    hasPrev: false,
  });

  const computeStartDate = () => {
    if (dateRange === 'all') return null;
    const now = new Date();
    switch (dateRange) {
      case '24h':
        now.setDate(now.getDate() - 1);
        break;
      case '7d':
        now.setDate(now.getDate() - 7);
        break;
      case '30d':
        now.setDate(now.getDate() - 30);
        break;
      default:
        return null;
    }
    return now.toISOString();
  };

  const fetchActivityLogs = async () => {
    setLoading(true);
    setError(null);

    try {
      const params = new URLSearchParams({
        page: pagination.page.toString(),
        limit: pagination.limit.toString(),
      });

      const startDateParam = computeStartDate();
      if (startDateParam) {
        params.append('startDate', startDateParam);
      }

      if (activityType !== 'all') {
        params.append('action', activityType);
      }

      const apiBaseUrl =
        window.location.hostname === 'localhost' ? 'http://localhost:3001' : 'https://iamai.global';
      // Backend exposes user activity at /api/users/activity
      const response = await fetch(`${apiBaseUrl}/api/users/activity?${params}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
      });

      if (!response.ok) {
        if (response.status === 401) {
          setError('Please log in to view activity logs');
          return;
        }
        throw new Error(`Failed to fetch activity logs: ${response.status}`);
      }

      const result = await response.json();

      if (result.success) {
        const items: UserActivity[] =
          // Prefer "data" (used by current /api/users/activity implementation),
          // but fall back to "activities" or "activity" for compatibility.
          result.data || result.activities || result.activity || [];

        setActivities(items);

        if (result.pagination) {
          setPagination(prev => ({ ...prev, ...result.pagination }));
        }
      } else {
        setError(result.message || 'Failed to load activity logs');
      }
    } catch (err) {
      console.error('Error fetching activity logs:', err);
      if (err instanceof Error && err.message.includes('401')) {
        setError('Please log in to view activity logs');
      } else {
        setError('Unable to load activity logs.');
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchActivityLogs();
  }, [pagination.page, dateRange, activityType]);

  useEffect(() => {
    setPagination(prev => (prev.page === 1 ? prev : { ...prev, page: 1 }));
  }, [dateRange, activityType]);

  const filteredActivities = useMemo(() => {
    // Filter out noise activities that users don't care about
    return activities.filter(activity => {
      const actionType = activity.action || activity.type || '';
      return !HIDDEN_ACTIONS.includes(actionType);
    });
  }, [activities]);

  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

    if (diffDays === 0) {
      return date.toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
      });
    } else if (diffDays === 1) {
      return 'Yesterday';
    } else if (diffDays < 7) {
      return `${diffDays} days ago`;
    } else {
      return date.toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: date.getFullYear() !== now.getFullYear() ? 'numeric' : undefined,
      });
    }
  };

  const getActionColor = (action: string) => {
    return actionColors[action] || actionColors.default;
  };

  const getLocationString = (location?: { country: string; city: string }) => {
    if (!location) return 'Unknown';
    return `${location.city}, ${location.country}`;
  };

  if (loading) {
    return (
      <div className="p-8 flex items-center justify-center min-h-[400px]">
        <div className="flex flex-col items-center space-y-4">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[var(--color-primary)]"></div>
          <p className="text-[var(--color-text-secondary)]">Loading activity logs...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-8">
        <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-6">
          <div className="flex items-center space-x-3">
            <i className="fa-solid fa-exclamation-triangle text-red-400 text-xl"></i>
            <div>
              <h3 className="text-red-400 font-semibold">Error Loading Activity Logs</h3>
              <p className="text-red-300 text-sm mt-1">{error}</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8">
      {/* Header */}
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-[var(--color-text)]">Activity Log</h2>
        <p className="text-[var(--color-text-secondary)] mt-2">
          Track all your account activities and security events
        </p>
      </div>

      {/* Filters */}
      <div className="mb-6 flex flex-wrap gap-4">
        <div className="flex items-center space-x-2">
          <label className="text-sm font-medium text-[var(--color-text-secondary)]">
            Time Range:
          </label>
          <select
            value={dateRange}
            onChange={e => setDateRange(e.target.value as typeof dateRange)}
            className="px-3 py-2 bg-[var(--color-surface)] border border-[var(--color-border)] rounded-lg text-[var(--color-text)] focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)]"
          >
            <option value="all">All Time</option>
            <option value="24h">Last 24 Hours</option>
            <option value="7d">Last 7 Days</option>
            <option value="30d">Last 30 Days</option>
          </select>
        </div>

        <div className="flex items-center space-x-2">
          <label className="text-sm font-medium text-[var(--color-text-secondary)]">
            Activity Type:
          </label>
          <select
            value={activityType}
            onChange={e => setActivityType(e.target.value)}
            className="px-3 py-2 bg-[var(--color-surface)] border border-[var(--color-border)] rounded-lg text-[var(--color-text)] focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)]"
          >
            <option value="all">All Activities</option>
            <option value="LOGIN_SUCCESS">Login Success</option>
            <option value="LOGOUT">Logout</option>
            <option value="LOGIN_FAILED">Login Failed</option>
            <option value="AI_CHAT_MESSAGE">AI Chat</option>
            <option value="AGENT_SELECTED">Agent Selected</option>
            <option value="AGENT_PURCHASED">Agent Purchased</option>
            <option value="PROFILE_UPDATE">Profile Update</option>
            <option value="SECURITY_PASSWORD_CHANGED">Password Changed</option>
            <option value="SECURITY_NOTIFICATIONS_UPDATED">Notifications Updated</option>
            <option value="SECURITY_SESSIONS_TERMINATED">Sessions Terminated</option>
            <option value="SUBSCRIPTION_VIEW">Subscription View</option>
            <option value="SIGNUP_FAILED">Signup Failed</option>
          </select>
        </div>

        <button
          onClick={fetchActivityLogs}
          className="px-4 py-2 bg-[var(--color-primary)] hover:bg-[var(--color-primary)]/80 text-[var(--color-text)] font-semibold rounded-lg transition-all duration-300 flex items-center space-x-2"
        >
          <i className="fa-solid fa-refresh"></i>
          <span>Refresh</span>
        </button>
      </div>

      {/* Activity List */}
      <div className="space-y-4">
        {filteredActivities.length === 0 ? (
          <div className="text-center py-12">
            <i className="fa-solid fa-inbox text-6xl text-[var(--color-text-secondary)]/50 mb-4"></i>
            <h3 className="text-xl font-semibold text-[var(--color-text-secondary)] mb-2">
              No Activities Found
            </h3>
            <p className="text-[var(--color-text-secondary)]">
              {activityType !== 'all' || dateRange !== 'all'
                ? 'Try adjusting your filters to see more activities.'
                : 'Your activity log will appear here as you use the platform.'}
            </p>
          </div>
        ) : (
          filteredActivities.map(activity => {
            const actionLabel = (activity.action || activity.type || 'UNKNOWN').toString();
            const displayName = actionDisplayNames[actionLabel] || actionLabel.replace(/_/g, ' ');
            const description = activity.description || activity.details || displayName;

            return (
              <div
              key={activity.id}
              className="bg-[var(--color-surface)]/50 border border-[var(--color-border)] rounded-lg p-6 hover:border-[var(--color-primary)]/30 transition-colors"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start space-x-4">
                  <div
                    className={`px-3 py-1 rounded-full text-xs font-semibold ${getActionColor(actionLabel)}`}
                  >
                    {displayName}
                  </div>
                  <div className="flex-1">
                    <p className="text-[var(--color-text)] font-medium">{description}</p>
                    <div className="flex flex-wrap items-center gap-4 mt-2 text-sm text-[var(--color-text-secondary)]">
                      <span className="flex items-center space-x-1">
                        <i className="fa-solid fa-clock"></i>
                        <span>{formatTimestamp(activity.timestamp)}</span>
                      </span>
                      {activity.ipAddress && (
                        <span className="flex items-center space-x-1">
                          <i className="fa-solid fa-globe"></i>
                          <span>{activity.ipAddress}</span>
                        </span>
                      )}
                      {activity.location && (
                        <span className="flex items-center space-x-1">
                          <i className="fa-solid fa-map-marker"></i>
                          <span>{getLocationString(activity.location)}</span>
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
        })
        )}
      </div>

      {/* Pagination */}
      {pagination.pages > 1 && (
        <div className="flex items-center justify-between mt-8">
          <div className="text-sm text-[var(--color-text-secondary)]">
            Showing {(pagination.page - 1) * pagination.limit + 1} to{' '}
            {Math.min(pagination.page * pagination.limit, pagination.total)} of {pagination.total}{' '}
            activities
          </div>
          <div className="flex space-x-2">
            <button
              onClick={() => setPagination(prev => ({ ...prev, page: prev.page - 1 }))}
              disabled={!pagination.hasPrev}
              className="px-4 py-2 bg-[var(--color-surface)] border border-[var(--color-border)] rounded-lg text-[var(--color-text)] disabled:opacity-50 disabled:cursor-not-allowed hover:border-[var(--color-primary)] transition-colors"
            >
              <i className="fa-solid fa-chevron-left mr-2"></i>
              Previous
            </button>
            <button
              onClick={() => setPagination(prev => ({ ...prev, page: prev.page + 1 }))}
              disabled={!pagination.hasNext}
              className="px-4 py-2 bg-[var(--color-surface)] border border-[var(--color-border)] rounded-lg text-[var(--color-text)] disabled:opacity-50 disabled:cursor-not-allowed hover:border-[var(--color-primary)] transition-colors"
            >
              Next
              <i className="fa-solid fa-chevron-right ml-2"></i>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default UserActivityLog;
