import React, { useState, useRef, useEffect } from 'react';
import { AIModel, AI_MODELS } from '../../../constants';

interface ModelSelectorProps {
  selectedModel: AIModel;
  onSelectModel: (modelId: string) => void;
}

const ModelSelector: React.FC<ModelSelectorProps> = ({ selectedModel, onSelectModel }) => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSelect = (modelId: string) => {
    onSelectModel(modelId);
    setIsOpen(false);
  };

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        title="Select an AI model for the chat"
        className="flex items-center space-x-2 px-3 py-1.5 bg-gray-800/50 border border-gray-700 rounded-md text-sm text-gray-300 hover:bg-gray-700/50 transition-colors"
      >
        <i className="fa-solid fa-cogs text-cyan-400"></i>
        <span>{selectedModel.name}</span>
        <i
          className={`fa-solid fa-chevron-down text-xs transition-transform ${isOpen ? 'rotate-180' : ''}`}
        ></i>
      </button>
      {isOpen && (
        <div className="absolute top-full right-0 mt-2 w-64 bg-gray-900 border border-gray-800 rounded-lg shadow-lg z-20">
          <ul className="py-2 max-h-80 overflow-y-auto">
            {Object.entries(AI_MODELS).map(([provider, models]) => (
              <li key={provider}>
                <h4 className="px-4 py-2 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                  {provider}
                </h4>
                {models.map(model => (
                  <button
                    key={model.id}
                    onClick={() => handleSelect(model.id)}
                    className={`w-full text-left px-4 py-2 text-sm flex items-center justify-between ${
                      selectedModel.id === model.id
                        ? 'text-cyan-300'
                        : 'text-gray-300 hover:bg-gray-800'
                    }`}
                  >
                    <span>{model.name}</span>
                    {selectedModel.id === model.id && (
                      <i className="fa-solid fa-check text-cyan-400"></i>
                    )}
                  </button>
                ))}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default ModelSelector;
