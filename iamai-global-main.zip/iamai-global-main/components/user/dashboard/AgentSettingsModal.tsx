import React, { useState, useEffect } from 'react';
import { X, Settings, Sliders, MessageSquare, Brain, Sparkles } from 'lucide-react';
import { Agent } from '../../../constants';

interface AgentSettings {
  maxTokens: number;
  temperature: number;
  tone: 'professional' | 'casual' | 'friendly' | 'technical' | 'creative';
  personality: 'balanced' | 'concise' | 'detailed' | 'humorous' | 'formal';
  systemPrompt: string;
}

interface AgentSettingsModalProps {
  onClose: () => void;
  agent: Agent;
  currentSettings: AgentSettings;
  onSave: (settings: AgentSettings) => void;
}

const AgentSettingsModal: React.FC<AgentSettingsModalProps> = ({
  onClose,
  agent,
  currentSettings,
  onSave,
}) => {
  const [localSettings, setLocalSettings] = useState<AgentSettings>(currentSettings);

  useEffect(() => {
    setLocalSettings(currentSettings);
  }, [currentSettings]);

  const handleSave = () => {
    onSave(localSettings);
    onClose();
  };

  const handleReset = () => {
    setLocalSettings({
      maxTokens: 2048,
      temperature: 0.7,
      tone: 'professional',
      personality: 'balanced',
      systemPrompt: '',
    });
  };

  const toneOptions: Array<{ value: AgentSettings['tone']; label: string; description: string }> = [
    { value: 'professional', label: 'Professional', description: 'Formal and business-oriented' },
    { value: 'casual', label: 'Casual', description: 'Relaxed and conversational' },
    { value: 'friendly', label: 'Friendly', description: 'Warm and approachable' },
    { value: 'technical', label: 'Technical', description: 'Precise and detailed' },
    { value: 'creative', label: 'Creative', description: 'Imaginative and expressive' },
  ];

  const personalityOptions: Array<{
    value: AgentSettings['personality'];
    label: string;
    description: string;
  }> = [
    { value: 'balanced', label: 'Balanced', description: 'Moderate response length' },
    { value: 'concise', label: 'Concise', description: 'Brief and to the point' },
    { value: 'detailed', label: 'Detailed', description: 'Comprehensive explanations' },
    { value: 'humorous', label: 'Humorous', description: 'Witty and entertaining' },
    { value: 'formal', label: 'Formal', description: 'Structured and academic' },
  ];

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-gray-900 border border-gray-800 rounded-xl max-w-2xl w-full max-h-[90vh] overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="bg-gradient-to-r from-cyan-500/10 to-purple-500/10 border-b border-gray-800 p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 flex items-center justify-center rounded-lg bg-gray-800">
                {agent.icon && agent.icon.startsWith('data:image') ? (
                  <img
                    src={agent.icon}
                    alt={agent.name}
                    className="w-full h-full object-cover rounded-lg"
                  />
                ) : (
                  <i className={`${agent.icon} text-2xl text-cyan-400`}></i>
                )}
              </div>
              <div>
                <h2 className="text-xl font-bold text-white flex items-center gap-2">
                  <Settings className="w-5 h-5 text-cyan-400" />
                  Agent Settings
                </h2>
                <p className="text-sm text-gray-400">
                  {agent.name} - {agent.role}
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-white transition-colors"
              title="Close settings"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6 overflow-y-auto max-h-[calc(90vh-200px)]">
          {/* Max Tokens */}
          <div className="space-y-3">
            <label className="flex items-center gap-2 text-sm font-semibold text-white">
              <Sliders className="w-4 h-4 text-cyan-400" />
              Max Tokens: {localSettings.maxTokens}
            </label>
            <input
              type="range"
              min="256"
              max="4096"
              step="256"
              value={localSettings.maxTokens}
              onChange={e =>
                setLocalSettings({ ...localSettings, maxTokens: parseInt(e.target.value) })
              }
              className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-cyan-500"
            />
            <div className="flex justify-between text-xs text-gray-500">
              <span>256 (Short)</span>
              <span>2048 (Medium)</span>
              <span>4096 (Long)</span>
            </div>
            <p className="text-xs text-gray-400">
              Controls the maximum length of the agent's responses. Higher values allow longer
              responses but use more resources.
            </p>
          </div>

          {/* Temperature */}
          <div className="space-y-3">
            <label className="flex items-center gap-2 text-sm font-semibold text-white">
              <Sparkles className="w-4 h-4 text-purple-400" />
              Temperature: {localSettings.temperature.toFixed(1)}
            </label>
            <input
              type="range"
              min="0"
              max="2"
              step="0.1"
              value={localSettings.temperature}
              onChange={e =>
                setLocalSettings({ ...localSettings, temperature: parseFloat(e.target.value) })
              }
              className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-purple-500"
            />
            <div className="flex justify-between text-xs text-gray-500">
              <span>0.0 (Precise)</span>
              <span>1.0 (Balanced)</span>
              <span>2.0 (Creative)</span>
            </div>
            <p className="text-xs text-gray-400">
              Controls randomness. Lower values make responses more focused and deterministic,
              higher values make them more creative.
            </p>
          </div>

          {/* Tone */}
          <div className="space-y-3">
            <label className="flex items-center gap-2 text-sm font-semibold text-white">
              <MessageSquare className="w-4 h-4 text-cyan-400" />
              Tone
            </label>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {toneOptions.map(option => (
                <button
                  key={option.value}
                  onClick={() => setLocalSettings({ ...localSettings, tone: option.value })}
                  className={`p-3 rounded-lg border text-left transition-all ${
                    localSettings.tone === option.value
                      ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300'
                      : 'bg-gray-800 border-gray-700 text-gray-400 hover:border-gray-600'
                  }`}
                >
                  <div className="font-medium text-sm">{option.label}</div>
                  <div className="text-xs opacity-70 mt-1">{option.description}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Personality */}
          <div className="space-y-3">
            <label className="flex items-center gap-2 text-sm font-semibold text-white">
              <Brain className="w-4 h-4 text-purple-400" />
              Personality
            </label>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {personalityOptions.map(option => (
                <button
                  key={option.value}
                  onClick={() => setLocalSettings({ ...localSettings, personality: option.value })}
                  className={`p-3 rounded-lg border text-left transition-all ${
                    localSettings.personality === option.value
                      ? 'bg-purple-500/20 border-purple-500 text-purple-300'
                      : 'bg-gray-800 border-gray-700 text-gray-400 hover:border-gray-600'
                  }`}
                >
                  <div className="font-medium text-sm">{option.label}</div>
                  <div className="text-xs opacity-70 mt-1">{option.description}</div>
                </button>
              ))}
            </div>
          </div>

          {/* System Prompt */}
          <div className="space-y-3">
            <label className="flex items-center gap-2 text-sm font-semibold text-white">
              <MessageSquare className="w-4 h-4 text-cyan-400" />
              Custom Instructions
            </label>
            <textarea
              value={localSettings.systemPrompt}
              onChange={e => setLocalSettings({ ...localSettings, systemPrompt: e.target.value })}
              placeholder={`Add custom instructions for ${agent.name}...\n\nExample:\n- Always provide code examples when explaining concepts\n- Use simple language and avoid jargon\n- Include relevant links and resources`}
              className="w-full h-32 bg-gray-800 border border-gray-700 rounded-lg p-3 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-cyan-500 resize-none"
            />
            <p className="text-xs text-gray-400">
              Provide specific guidance or instructions for how the agent should respond to you.
              This helps personalize the interaction.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="border-t border-gray-800 p-6 bg-gray-900/50">
          <div className="flex items-center justify-between">
            <button
              onClick={handleReset}
              className="px-4 py-2 text-sm text-gray-400 hover:text-white transition-colors"
            >
              Reset to Defaults
            </button>
            <div className="flex items-center space-x-3">
              <button
                onClick={onClose}
                className="px-4 py-2 text-sm bg-gray-800 text-white rounded-lg hover:bg-gray-700 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleSave}
                className="px-6 py-2 text-sm bg-gradient-to-r from-cyan-500 to-purple-500 text-white rounded-lg hover:from-cyan-600 hover:to-purple-600 transition-all shadow-lg"
              >
                Save Settings
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AgentSettingsModal;
