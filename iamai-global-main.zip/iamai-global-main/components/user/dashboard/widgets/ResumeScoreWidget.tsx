import React from 'react';
import { AgentResumeScore } from '../../../constants';

interface ResumeScoreWidgetProps {
    title: string;
    score: AgentResumeScore;
    themeColor: string;
}

const THEME_CLASSES: Record<string, { border: string, text: string, bg: string }> = {
    blue: { border: 'border-blue-500/50', text: 'text-blue-400', bg: 'bg-blue-500/10' },
};

const SubScoreBar: React.FC<{ label: string; value: number; color: string }> = ({ label, value, color }) => (
    <div>
        <div className="flex justify-between items-baseline mb-1">
            <span className="text-xs font-medium text-gray-400">{label}</span>
            <span className="text-xs font-bold text-white">{value}%</span>
        </div>
        <div className="w-full bg-gray-700/50 rounded-full h-1.5">
            <div 
                className={`h-1.5 rounded-full ${color}`} 
                style={{ width: `${value}%`, transition: 'width 0.5s ease-in-out' }}
            ></div>
        </div>
    </div>
);

const ResumeScoreWidget: React.FC<ResumeScoreWidgetProps> = ({ title, score, themeColor }) => {
    const theme = THEME_CLASSES[themeColor] || THEME_CLASSES.blue;
    const circumference = 2 * Math.PI * 52; // 2 * pi * r
    const offset = circumference - (score.total / 100) * circumference;

    return (
        <div className={`bg-gray-900/50 border ${theme.border} rounded-xl p-5`}>
            <div className="flex items-center gap-3 mb-4">
                 <div className={`flex-shrink-0 flex items-center justify-center w-8 h-8 rounded-lg ${theme.bg} ${theme.text}`}>
                    <i className="fa-solid fa-tachometer-alt"></i>
                 </div>
                 <h3 className={`text-sm font-semibold ${theme.text} uppercase tracking-wider`}>{title}</h3>
            </div>

            <div className="relative w-40 h-40 mx-auto my-4 flex items-center justify-center">
                <svg className="absolute w-full h-full transform -rotate-90" viewBox="0 0 120 120">
                    <circle
                        className="text-gray-700"
                        stroke="currentColor"
                        strokeWidth="8"
                        fill="transparent"
                        r="52"
                        cx="60"
                        cy="60"
                    />
                    <circle
                        className={theme.text}
                        stroke="currentColor"
                        strokeWidth="8"
                        strokeDasharray={circumference}
                        strokeDashoffset={offset}
                        strokeLinecap="round"
                        fill="transparent"
                        r="52"
                        cx="60"
                        cy="60"
                        style={{ transition: 'stroke-dashoffset 0.5s ease-in-out' }}
                    />
                </svg>
                <div className="text-center">
                    <span className="text-4xl font-bold text-white">{score.total}</span>
                    <p className="text-xs text-gray-400">out of 100</p>
                </div>
            </div>

            <div className="space-y-3">
                <SubScoreBar label="Formatting" value={score.formatting} color="bg-cyan-400" />
                <SubScoreBar label="Keywords" value={score.keywords} color="bg-green-400" />
                <SubScoreBar label="Impact" value={score.impact} color="bg-purple-400" />
            </div>
        </div>
    );
};

export default ResumeScoreWidget;
