import React from 'react';
import { AgentStat } from '../../../constants';

interface StatsWidgetProps {
    title: string;
    stats: AgentStat[];
    themeColor: string;
}

const THEME_CLASSES: Record<string, { border: string, text: string }> = {
    pink: { border: 'border-pink-500/50', text: 'text-pink-400' },
    cyan: { border: 'border-cyan-500/50', text: 'text-cyan-400' },
    red: { border: 'border-red-500/50', text: 'text-red-400' },
    blue: { border: 'border-blue-500/50', text: 'text-blue-400' },
    yellow: { border: 'border-yellow-500/50', text: 'text-yellow-400' },
    grey: { border: 'border-gray-500/50', text: 'text-gray-400' },
    purple: { border: 'border-purple-500/50', text: 'text-purple-400' },
    green: { border: 'border-green-500/50', text: 'text-green-400' },
    orange: { border: 'border-orange-500/50', text: 'text-orange-400' },
};

const StatsWidget: React.FC<StatsWidgetProps> = ({ title, stats, themeColor }) => {
    const theme = THEME_CLASSES[themeColor] || THEME_CLASSES.cyan;

    return (
        <div className={`bg-gray-900/50 border ${theme.border} rounded-xl p-4`}>
            <h3 className={`text-sm font-semibold ${theme.text} mb-4`}>{title}</h3>
            <div className="grid grid-cols-2 gap-4">
                {stats.map((stat, index) => (
                    <div key={index}>
                        <div className="flex items-center text-xs text-gray-400">
                            <i className={`${stat.icon} mr-2 w-4 text-center`}></i>
                            {stat.label}
                        </div>
                        <p className="text-xl font-bold text-white mt-1">{stat.value}</p>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default StatsWidget;