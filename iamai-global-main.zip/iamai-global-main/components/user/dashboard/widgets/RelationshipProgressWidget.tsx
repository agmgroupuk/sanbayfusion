import React from 'react';
import { AgentRelationshipStat } from '../../../constants';

interface RelationshipProgressWidgetProps {
    title: string;
    items: AgentRelationshipStat[];
    themeColor: string;
}

const THEME_CLASSES: Record<string, { border: string, text: string, bg: string, gradient: string }> = {
    pink: { border: 'border-pink-500/50', text: 'text-pink-400', bg: 'bg-pink-500/10', gradient: 'bg-gradient-to-r from-pink-500 to-rose-500' },
    // Add other themes if needed
};

const RelationshipProgressWidget: React.FC<RelationshipProgressWidgetProps> = ({ title, items, themeColor }) => {
    const theme = THEME_CLASSES[themeColor] || THEME_CLASSES.pink;

    return (
        <div className={`bg-gray-900/50 border ${theme.border} rounded-xl p-5`}>
            <div className="flex items-center gap-3 mb-4">
                 <div className={`flex-shrink-0 flex items-center justify-center w-8 h-8 rounded-lg ${theme.bg} ${theme.text}`}>
                    <i className="fa-solid fa-bars-progress"></i>
                 </div>
                 <h3 className={`text-sm font-semibold ${theme.text} uppercase tracking-wider`}>{title}</h3>
            </div>
            
            <div className="space-y-4">
                {items.map((item, index) => (
                    <div key={index}>
                        <div className="flex justify-between items-baseline mb-1">
                            <span className="text-sm font-medium text-gray-300">{item.label}</span>
                            <span className={`text-sm font-bold ${theme.text}`}>{item.value}%</span>
                        </div>
                        <div className="w-full bg-gray-700/50 rounded-full h-2">
                            <div 
                                className={`h-2 rounded-full ${theme.gradient}`} 
                                style={{ width: `${item.value}%`, transition: 'width 0.5s ease-in-out' }}
                            ></div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default RelationshipProgressWidget;