import React from 'react';
import { AgentConversationHealth } from '../../../constants';

interface ConversationHealthWidgetProps {
    title: string;
    health: AgentConversationHealth;
    themeColor: string;
}

const THEME_CLASSES = {
    green: { border: 'border-green-500/50', text: 'text-green-400', bg: 'bg-green-500/10' },
};

const heartbeatData = [
    { name: '10m ago', value: 70 },
    { name: '8m ago', value: 75 },
    { name: '6m ago', value: 72 },
    { name: '4m ago', value: 80 },
    { name: '2m ago', value: 78 },
    { name: 'now', value: 85 },
];

const ConversationHealthWidget: React.FC<ConversationHealthWidgetProps> = ({ title, health, themeColor }) => {
    // @ts-ignore
    const Recharts = window.Recharts;
    const theme = THEME_CLASSES.green;

    if (!Recharts) {
        return (
            <div className={`bg-gray-900/50 border ${theme.border} rounded-xl p-5 h-full flex items-center justify-center`}>
                <div className="text-center text-gray-400">
                    <i className="fa-solid fa-spinner fa-spin text-2xl mb-4"></i>
                    <p>Loading chart...</p>
                </div>
            </div>
        );
    }

    const { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip } = Recharts;

    return (
        <div className={`bg-gray-900/50 border ${theme.border} rounded-xl p-5`}>
            <div className="flex items-center gap-3 mb-4">
                 <div className={`flex-shrink-0 flex items-center justify-center w-8 h-8 rounded-lg ${theme.bg} ${theme.text}`}>
                    <i className="fa-solid fa-heart-pulse"></i>
                 </div>
                 <h3 className={`text-sm font-semibold ${theme.text} uppercase tracking-wider`}>{title}</h3>
            </div>

            <div className="h-28 -ml-4 mb-4">
                <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={heartbeatData}>
                        <Tooltip contentStyle={{ background: '#1f2937', border: 'none', borderRadius: '0.5rem' }} itemStyle={{ color: '#86efac' }} />
                        <XAxis dataKey="name" stroke="#6b7280" fontSize={10} axisLine={false} tickLine={false} />
                        <YAxis stroke="#6b7280" fontSize={10} axisLine={false} tickLine={false} domain={[60, 90]} />
                        <Line type="monotone" dataKey="value" stroke="#4ade80" strokeWidth={2} dot={false} />
                    </LineChart>
                </ResponsiveContainer>
            </div>
            
            <div className="grid grid-cols-3 gap-2 text-center">
                <div>
                    <p className="text-xs text-gray-400">Response Rate</p>
                    <p className="text-lg font-bold text-white">{health.responseRate}%</p>
                </div>
                <div>
                    <p className="text-xs text-gray-400">Engagement</p>
                    <p className="text-lg font-bold text-white">{health.engagement}%</p>
                </div>
                <div>
                    <p className="text-xs text-gray-400">Sentiment</p>
                    <p className="text-lg font-bold text-white">+{health.sentiment}</p>
                </div>
            </div>
        </div>
    );
};

export default ConversationHealthWidget;