import React from 'react';
import { AgentStat } from '../../../constants';

interface GenerationStatsWidgetProps {
    title: string;
    stats: AgentStat[];
    themeColor: string;
}

const THEME_CLASSES: Record<string, { border: string, text: string, bg: string }> = {
    purple: { border: 'border-purple-500/50', text: 'text-purple-400', bg: 'bg-purple-500/10' },
};

const GenerationStatsWidget: React.FC<GenerationStatsWidgetProps> = ({ title, stats, themeColor }) => {
    const theme = THEME_CLASSES[themeColor] || THEME_CLASSES.purple;

    return (
        <div className={`bg-gray-900/50 border ${theme.border} rounded-xl p-5`}>
            <div className="flex items-center gap-3 mb-4">
                 <div className={`flex-shrink-0 flex items-center justify-center w-8 h-8 rounded-lg ${theme.bg} ${theme.text}`}>
                    <i className="fa-solid fa-wand-magic-sparkles"></i>
                 </div>
                 <h3 className={`text-sm font-semibold ${theme.text} uppercase tracking-wider`}>{title}</h3>
            </div>
            <div className="space-y-4">
                {stats.map((stat, index) => (
                    <div key={index} className="flex items-center justify-between">
                        <div className="flex items-center text-sm text-gray-400">
                             <span className={`w-6 text-center mr-2 ${theme.text}`}>
                                <i className={stat.icon}></i>
                             </span>
                            {stat.label}
                        </div>
                        <p className="text-lg font-bold text-white">{stat.value}</p>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default GenerationStatsWidget;