import React from 'react';
import { AgentContentIdea } from '../../../constants';

interface ContentIdeasWidgetProps {
    title: string;
    items: AgentContentIdea[];
    themeColor: string;
}

const THEME_CLASSES: Record<string, { border: string, text: string, bg: string, tagBg: string }> = {
    purple: { border: 'border-purple-500/50', text: 'text-purple-400', bg: 'bg-purple-500/10', tagBg: 'bg-purple-500/20 text-purple-300' },
};

const ContentIdeasWidget: React.FC<ContentIdeasWidgetProps> = ({ title, items, themeColor }) => {
    const theme = THEME_CLASSES[themeColor] || THEME_CLASSES.purple;

    return (
        <div className={`bg-gray-900/50 border ${theme.border} rounded-xl p-5`}>
            <div className="flex items-center gap-3 mb-4">
                 <div className={`flex-shrink-0 flex items-center justify-center w-8 h-8 rounded-lg ${theme.bg} ${theme.text}`}>
                    <i className="fa-solid fa-lightbulb"></i>
                 </div>
                 <h3 className={`text-sm font-semibold ${theme.text} uppercase tracking-wider`}>{title}</h3>
            </div>
            <div className="space-y-3">
                {items.map((item, index) => (
                    <div key={index} className={`p-3 rounded-lg ${theme.bg}`}>
                        <div className="flex items-center justify-between">
                            <div className="flex items-center">
                                <span className={`mr-3 ${theme.text}`}>
                                  <i className={item.icon}></i>
                                </span>
                                <p className="text-sm font-semibold text-white">{item.title}</p>
                            </div>
                            <span className={`px-2 py-0.5 text-xs font-medium rounded-full ${theme.tagBg}`}>{item.type}</span>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default ContentIdeasWidget;