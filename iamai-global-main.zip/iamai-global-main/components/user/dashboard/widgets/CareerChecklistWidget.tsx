import React, { useState, useEffect } from 'react';
import { AgentChecklistItem } from '../../../constants';

interface CareerChecklistWidgetProps {
    title: string;
    items: AgentChecklistItem[];
    themeColor: string;
}

const THEME_CLASSES: Record<string, { border: string, text: string, bg: string, accent: string }> = {
    blue: { border: 'border-blue-500/50', text: 'text-blue-400', bg: 'bg-blue-500/10', accent: 'accent-blue-400' },
};

const CareerChecklistWidget: React.FC<CareerChecklistWidgetProps> = ({ title, items, themeColor }) => {
    const theme = THEME_CLASSES[themeColor] || THEME_CLASSES.blue;
    const [checkedItems, setCheckedItems] = useState<Record<string, boolean>>({});

    useEffect(() => {
        const initialCheckedState = items.reduce((acc, item) => {
            acc[item.task] = item.completed;
            return acc;
        }, {} as Record<string, boolean>);
        setCheckedItems(initialCheckedState);
    }, [items]);

    const handleCheckboxChange = (task: string) => {
        setCheckedItems(prev => ({ ...prev, [task]: !prev[task] }));
    };

    return (
        <div className={`bg-gray-900/50 border ${theme.border} rounded-xl p-5`}>
            <div className="flex items-center gap-3 mb-4">
                 <div className={`flex-shrink-0 flex items-center justify-center w-8 h-8 rounded-lg ${theme.bg} ${theme.text}`}>
                    <i className="fa-solid fa-clipboard-check"></i>
                 </div>
                 <h3 className={`text-sm font-semibold ${theme.text} uppercase tracking-wider`}>{title}</h3>
            </div>
            
            <div className="space-y-3">
                {items.map((item, index) => (
                    <div key={index} className="flex items-center">
                        <input
                            type="checkbox"
                            id={`task-${index}`}
                            checked={checkedItems[item.task] || false}
                            onChange={() => handleCheckboxChange(item.task)}
                            title="Toggle completion status"
                            className={`w-5 h-5 rounded bg-gray-700 border-gray-600 text-blue-500 focus:ring-blue-600 ${theme.accent}`}
                        />
                        <label
                            htmlFor={`task-${index}`}
                            className={`ml-3 text-sm font-medium ${
                                checkedItems[item.task] ? 'text-gray-500 line-through' : 'text-gray-300'
                            }`}
                        >
                            {item.task}
                        </label>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default CareerChecklistWidget;