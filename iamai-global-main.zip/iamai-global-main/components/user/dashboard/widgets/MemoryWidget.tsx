import React from 'react';
import { AgentMemoryItem } from '../../../constants';

interface MemoryWidgetProps {
    title: string;
    items: AgentMemoryItem[];
    themeColor: string;
}

const THEME_CLASSES: Record<string, { border: string, text: string, bg: string }> = {
    pink: { border: 'border-pink-500/50', text: 'text-pink-400', bg: 'bg-pink-500/10' },
    cyan: { border: 'border-cyan-500/50', text: 'text-cyan-400', bg: 'bg-cyan-500/10' },
    red: { border: 'border-red-500/50', text: 'text-red-400', bg: 'bg-red-500/10' },
    blue: { border: 'border-blue-500/50', text: 'text-blue-400', bg: 'bg-blue-500/10' },
    yellow: { border: 'border-yellow-500/50', text: 'text-yellow-400', bg: 'bg-yellow-500/10' },
    purple: { border: 'border-purple-500/50', text: 'text-purple-400', bg: 'bg-purple-500/10' },
    grey: { border: 'border-gray-500/50', text: 'text-gray-400', bg: 'bg-gray-500/10' },
    green: { border: 'border-green-500/50', text: 'text-green-400', bg: 'bg-green-500/10' },
    orange: { border: 'border-orange-500/50', text: 'text-orange-400', bg: 'bg-orange-500/10' },
};

const MemoryWidget: React.FC<MemoryWidgetProps> = ({ title, items, themeColor }) => {
    const theme = THEME_CLASSES[themeColor] || THEME_CLASSES.cyan;

    return (
        <div className={`bg-gray-900/50 border ${theme.border} rounded-xl p-5`}>
            <div className="flex items-center gap-3 mb-4">
                 <div className={`flex-shrink-0 flex items-center justify-center w-8 h-8 rounded-lg ${theme.bg} ${theme.text}`}>
                    <i className="fa-solid fa-brain"></i>
                 </div>
                 <h3 className={`text-sm font-semibold ${theme.text} uppercase tracking-wider`}>{title}</h3>
            </div>
            <div className="space-y-4">
                {items.map((item, index) => (
                    <div key={index} className="flex items-start text-sm">
                        <div className={`w-8 h-8 flex-shrink-0 flex items-center justify-center rounded-lg mr-3 ${theme.bg} ${theme.text}`}>
                            <i className={item.icon}></i>
                        </div>
                        <div>
                            <p className="text-gray-400 font-medium">{item.label}</p>
                            <p className="text-white font-semibold">{item.value}</p>

                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default MemoryWidget;