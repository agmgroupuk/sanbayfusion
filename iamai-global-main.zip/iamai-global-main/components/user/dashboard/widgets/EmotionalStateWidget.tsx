import React from 'react';
import { AgentStat } from '../../../constants';

interface EmotionalStateWidgetProps {
    title: string;
    stats: AgentStat[];
    themeColor: string;
}

const THEME_CLASSES: Record<string, { border: string, text: string, bg: string, pulse: string }> = {
    pink: { border: 'border-pink-500/50', text: 'text-pink-400', bg: 'bg-pink-500/10', pulse: 'shadow-[0_0_12px] shadow-pink-500/50' },
    // Add other themes if needed
};

const EmotionalStateWidget: React.FC<EmotionalStateWidgetProps> = ({ title, stats, themeColor }) => {
    const theme = THEME_CLASSES[themeColor] || THEME_CLASSES.pink;

    return (
        <div className={`bg-gray-900/50 border ${theme.border} rounded-xl p-5`}>
             <div className="flex items-center gap-3 mb-4">
                 <div className={`flex-shrink-0 flex items-center justify-center w-8 h-8 rounded-lg ${theme.bg} ${theme.text}`}>
                    <i className="fa-solid fa-heart-pulse"></i>
                 </div>
                 <h3 className={`text-sm font-semibold ${theme.text} uppercase tracking-wider`}>{title}</h3>
            </div>
            
            {/* Emotional Radar Visualization */}
            <div className="relative w-40 h-40 mx-auto my-4">
                <div className="absolute inset-0 border-2 border-gray-700 rounded-full"></div>
                <div className="absolute inset-2 border border-gray-800 rounded-full"></div>
                <div className="absolute inset-5 border-2 border-gray-700 rounded-full"></div>
                <div className={`absolute top-[20%] left-[60%] w-3 h-3 bg-pink-400 border-2 border-white rounded-full ${theme.pulse} animate-pulse`}></div>
                <div className={`absolute top-[40%] left-[80%] w-3 h-3 bg-pink-400 border-2 border-white rounded-full ${theme.pulse} animate-pulse delay-100`}></div>
                <div className={`absolute top-[70%] left-[45%] w-3 h-3 bg-pink-400 border-2 border-white rounded-full ${theme.pulse} animate-pulse delay-200`}></div>
            </div>

            {/* Mood Metrics */}
            <div className="grid grid-cols-2 gap-4">
                {stats.map((stat, index) => (
                    <div key={index} className={`p-3 rounded-lg ${theme.bg}`}>
                        <div className="flex items-center text-xs text-gray-400 mb-1">
                             <span className={`mr-2 ${theme.text}`}>
                               <i className={stat.icon}></i>
                             </span>
                            {stat.label}
                        </div>
                        <p className="text-xl font-bold text-white">{stat.value}</p>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default EmotionalStateWidget;