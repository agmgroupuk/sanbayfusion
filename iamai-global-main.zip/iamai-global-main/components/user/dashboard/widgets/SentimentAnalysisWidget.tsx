import React from 'react';
import { AgentSentimentAnalysis } from '../../../constants';

interface SentimentAnalysisWidgetProps {
    title: string;
    analysis: AgentSentimentAnalysis;
    themeColor: string;
}

const THEME_CLASSES = {
    yellow: { border: 'border-yellow-500/50', text: 'text-yellow-400', bg: 'bg-yellow-500/10', fill: 'stroke-yellow-400' },
};

const getSentimentLabel = (score: number) => {
    if (score > 0.5) return 'Very Positive';
    if (score > 0.1) return 'Positive';
    if (score < -0.5) return 'Very Negative';
    if (score < -0.1) return 'Negative';
    return 'Neutral';
}

const SentimentAnalysisWidget: React.FC<SentimentAnalysisWidgetProps> = ({ title, analysis, themeColor }) => {
    const theme = THEME_CLASSES.yellow;
    const scorePercentage = (analysis.score + 1) / 2; // convert -1..1 to 0..1
    const circumference = 2 * Math.PI * 50; // 2 * pi * r of the path
    const strokeDashoffset = circumference * (1 - scorePercentage);

    return (
        <div className={`bg-gray-900/50 border ${theme.border} rounded-xl p-5`}>
            <div className="flex items-center gap-3 mb-4">
                 <div className={`flex-shrink-0 flex items-center justify-center w-8 h-8 rounded-lg ${theme.bg} ${theme.text}`}>
                    <i className="fa-solid fa-gauge-high"></i>
                 </div>
                 <h3 className={`text-sm font-semibold ${theme.text} uppercase tracking-wider`}>{title}</h3>
            </div>

            <div className="relative w-48 h-24 mx-auto my-4 flex items-end justify-center overflow-hidden">
                <svg className="absolute w-full h-full" viewBox="0 0 120 65">
                    <path
                        d="M 10 60 A 50 50 0 0 1 110 60"
                        className="text-gray-700"
                        stroke="currentColor"
                        strokeWidth="10"
                        fill="transparent"
                        strokeLinecap="round"
                    />
                    <path
                        d="M 10 60 A 50 50 0 0 1 110 60"
                        className={theme.text}
                        stroke="currentColor"
                        strokeWidth="10"
                        fill="transparent"
                        strokeDasharray={`${circumference / 2} ${circumference}`}
                        strokeDashoffset={strokeDashoffset}
                        strokeLinecap="round"
                        style={{ transition: 'stroke-dashoffset 0.5s ease-in-out' }}
                    />
                </svg>
                 <div className="text-center absolute bottom-0">
                    <span className="text-3xl font-bold text-white">{(analysis.score).toFixed(2)}</span>
                    <p className={`text-sm font-semibold ${theme.text}`}>{getSentimentLabel(analysis.score)}</p>
                </div>
            </div>

            <div className="space-y-3 mt-4">
                <h4 className="text-xs font-semibold text-gray-400 uppercase">Detected Emotions</h4>
                {analysis.emotions.map((emotion) => (
                    <div key={emotion.name}>
                        <div className="flex justify-between items-baseline mb-1">
                            <span className="text-sm font-medium text-gray-300">{emotion.name}</span>
                            <span className="text-sm font-bold text-white">{emotion.value}%</span>
                        </div>
                        <div className="w-full bg-gray-700/50 rounded-full h-1.5">
                            <div 
                                className={`h-1.5 rounded-full bg-yellow-400`} 
                                style={{ width: `${emotion.value}%`, transition: 'width 0.5s ease-in-out' }}
                            ></div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default SentimentAnalysisWidget;
