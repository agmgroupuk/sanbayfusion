import React from 'react';
import { AgentAction } from '../../../constants';

interface QuickActionsWidgetProps {
    title: string;
    actions: AgentAction[];
    onAction: (prompt: string) => void;
    themeColor: string;
}

const THEME_CLASSES: Record<string, { border: string, text: string, bg: string, hoverBg: string }> = {
    pink: { border: 'border-pink-500/50', text: 'text-pink-400', bg: 'bg-pink-500/10', hoverBg: 'hover:bg-pink-500/20' },
    cyan: { border: 'border-cyan-500/50', text: 'text-cyan-400', bg: 'bg-cyan-500/10', hoverBg: 'hover:bg-cyan-500/20' },
    red: { border: 'border-red-500/50', text: 'text-red-400', bg: 'bg-red-500/10', hoverBg: 'hover:bg-red-500/20' },
    blue: { border: 'border-blue-500/50', text: 'text-blue-400', bg: 'bg-blue-500/10', hoverBg: 'hover:bg-blue-500/20' },
    yellow: { border: 'border-yellow-500/50', text: 'text-yellow-400', bg: 'bg-yellow-500/10', hoverBg: 'hover:bg-yellow-500/20' },
    purple: { border: 'border-purple-500/50', text: 'text-purple-400', bg: 'bg-purple-500/10', hoverBg: 'hover:bg-purple-500/20' },
    grey: { border: 'border-gray-500/50', text: 'text-gray-400', bg: 'bg-gray-500/10', hoverBg: 'hover:bg-gray-500/20' },
    green: { border: 'border-green-500/50', text: 'text-green-400', bg: 'bg-green-500/10', hoverBg: 'hover:bg-green-500/20' },
    orange: { border: 'border-orange-500/50', text: 'text-orange-400', bg: 'bg-orange-500/10', hoverBg: 'hover:bg-orange-500/20' },
};

const QuickActionsWidget: React.FC<QuickActionsWidgetProps> = ({ title, actions, onAction, themeColor }) => {
    const theme = THEME_CLASSES[themeColor] || THEME_CLASSES.cyan;

    return (
        <div className={`bg-gray-900/50 border ${theme.border} rounded-xl p-4`}>
            <h3 className={`text-sm font-semibold ${theme.text} mb-3`}>{title}</h3>
            <div className="grid grid-cols-2 gap-2">
                {actions.map((action, index) => (
                    <button
                        key={index}
                        onClick={() => onAction(action.prompt)}
                        title={`Use prompt: "${action.prompt}"`}
                        className={`p-3 rounded-lg text-left ${theme.bg} ${theme.hoverBg} transition-colors duration-200`}
                    >
                        <div className={`text-lg ${theme.text}`}>
                          <i className={action.icon}></i>
                        </div>
                        <p className="mt-1 text-xs font-semibold text-gray-300">{action.label}</p>
                    </button>
                ))}
            </div>
        </div>
    );
};

export default QuickActionsWidget;