import React from 'react';
import { AgentRecentFile } from '../../../constants';

interface RecentFilesWidgetProps {
    title: string;
    items: AgentRecentFile[];
    themeColor: string;
}

const THEME_CLASSES: Record<string, { border: string, text: string, bg: string, hoverBg: string }> = {
    red: { border: 'border-red-500/50', text: 'text-red-400', bg: 'bg-red-500/10', hoverBg: 'hover:bg-red-500/20' },
    // Add other themes if needed
};

const RecentFilesWidget: React.FC<RecentFilesWidgetProps> = ({ title, items, themeColor }) => {
    const theme = THEME_CLASSES[themeColor] || THEME_CLASSES.red;

    return (
        <div className={`bg-gray-900/50 border ${theme.border} rounded-xl p-5`}>
            <div className="flex items-center gap-3 mb-4">
                 <div className={`flex-shrink-0 flex items-center justify-center w-8 h-8 rounded-lg ${theme.bg} ${theme.text}`}>
                    <i className="fa-solid fa-clock-rotate-left"></i>
                 </div>
                 <h3 className={`text-sm font-semibold ${theme.text} uppercase tracking-wider`}>{title}</h3>
            </div>
            <div className="space-y-2">
                {items.map((item, index) => (
                    <button key={index} title={`Preview file: ${item.name}`} className={`w-full text-left p-3 rounded-lg ${theme.bg} ${theme.hoverBg} transition-colors duration-200`}>
                        <div className="flex items-center">
                            <span className="mr-3">
                               <i className={item.icon}></i>
                            </span>
                            <div>
                                <p className="text-sm font-semibold text-white truncate">{item.name}</p>
                                <p className="text-xs text-gray-400">{item.date}</p>
                            </div>
                        </div>
                    </button>
                ))}
            </div>
        </div>
    );
};

export default RecentFilesWidget;