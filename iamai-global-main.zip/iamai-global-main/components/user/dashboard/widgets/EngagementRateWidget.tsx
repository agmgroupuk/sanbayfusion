import React from 'react';
import { AgentEngagementRate } from '../../../constants';

interface EngagementRateWidgetProps {
    title: string;
    rate: AgentEngagementRate;
    themeColor: string;
}

const THEME_CLASSES = {
    cyan: { border: 'border-cyan-500/50', text: 'text-cyan-400', bg: 'bg-cyan-500/10' },
};

const EngagementRateWidget: React.FC<EngagementRateWidgetProps> = ({ title, rate, themeColor }) => {
    const theme = THEME_CLASSES.cyan;
    const circumference = 2 * Math.PI * 52; // 2 * pi * r
    const offset = circumference - (rate.rate / 10) * circumference; // Assuming rate is out of 10 for better visualization

    return (
        <div className={`bg-gray-900/50 border ${theme.border} rounded-xl p-5`}>
            <div className="flex items-center gap-3 mb-4">
                 <div className={`flex-shrink-0 flex items-center justify-center w-8 h-8 rounded-lg ${theme.bg} ${theme.text}`}>
                    <i className="fa-solid fa-fire"></i>
                 </div>
                 <h3 className={`text-sm font-semibold ${theme.text} uppercase tracking-wider`}>{title}</h3>
            </div>
            
            <div className="relative w-40 h-40 mx-auto my-4 flex items-center justify-center">
                <svg className="absolute w-full h-full transform -rotate-90" viewBox="0 0 120 120">
                    <circle className="text-gray-700" stroke="currentColor" strokeWidth="8" fill="transparent" r="52" cx="60" cy="60" />
                    <circle
                        className={theme.text}
                        stroke="currentColor"
                        strokeWidth="8"
                        strokeDasharray={circumference}
                        strokeDashoffset={offset}
                        strokeLinecap="round"
                        fill="transparent"
                        r="52"
                        cx="60"
                        cy="60"
                        style={{ transition: 'stroke-dashoffset 0.5s ease-in-out' }}
                    />
                </svg>
                <div className="text-center">
                    <span className="text-4xl font-bold text-white">{rate.rate}%</span>
                </div>
            </div>

            <div className="grid grid-cols-3 gap-2 text-center">
                <div>
                    <p className="text-xs text-gray-400">Likes</p>
                    <p className="text-lg font-bold text-white">{(rate.likes / 1000).toFixed(1)}k</p>
                </div>
                <div>
                    <p className="text-xs text-gray-400">Comments</p>
                    <p className="text-lg font-bold text-white">{rate.comments}</p>
                </div>
                 <div>
                    <p className="text-xs text-gray-400">Shares</p>
                    <p className="text-lg font-bold text-white">{(rate.shares / 1000).toFixed(1)}k</p>
                </div>
            </div>
        </div>
    );
};

export default EngagementRateWidget;
