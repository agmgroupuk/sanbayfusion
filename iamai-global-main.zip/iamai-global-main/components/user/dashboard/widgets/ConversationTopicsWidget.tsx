import React from 'react';
import { AgentConversationTopic } from '../../../constants';

interface ConversationTopicsWidgetProps {
    title: string;
    items: AgentConversationTopic[];
    themeColor: string;
}

const THEME_CLASSES = {
    green: { 
        border: 'border-green-500/50', 
        text: 'text-green-400', 
        bg: 'bg-green-500/10',
        activeTag: 'bg-green-500/20 text-green-300',
        fadingTag: 'bg-yellow-500/20 text-yellow-300',
    },
};

const ConversationTopicsWidget: React.FC<ConversationTopicsWidgetProps> = ({ title, items, themeColor }) => {
    const theme = THEME_CLASSES.green;

    return (
        <div className={`bg-gray-900/50 border ${theme.border} rounded-xl p-5`}>
            <div className="flex items-center gap-3 mb-4">
                 <div className={`flex-shrink-0 flex items-center justify-center w-8 h-8 rounded-lg ${theme.bg} ${theme.text}`}>
                    <i className="fa-solid fa-list-alt"></i>
                 </div>
                 <h3 className={`text-sm font-semibold ${theme.text} uppercase tracking-wider`}>{title}</h3>
            </div>
            <div className="flex flex-wrap gap-2">
                {items.map((item, index) => (
                    <div key={index} className={`px-3 py-1 text-sm font-medium rounded-full flex items-center ${item.status === 'active' ? theme.activeTag : theme.fadingTag}`}>
                        <span className={`w-2 h-2 rounded-full mr-2 ${item.status === 'active' ? 'bg-green-400' : 'bg-yellow-400'}`}></span>
                        {item.topic}
                    </div>
                ))}
            </div>
        </div>
    );
};

export default ConversationTopicsWidget;
