import React from 'react';
import { AgentViralTrend } from '../../../constants';

interface ViralTrendsWidgetProps {
    title: string;
    items: AgentViralTrend[];
    themeColor: string;
}

const THEME_CLASSES = {
    cyan: { border: 'border-cyan-500/50', text: 'text-cyan-400', bg: 'bg-cyan-500/10' },
};

const getHeatColor = (heat: number): string => {
    if (heat > 90) return 'text-red-500';
    if (heat > 80) return 'text-orange-500';
    if (heat > 70) return 'text-yellow-500';
    return 'text-green-500';
}

const ViralTrendsWidget: React.FC<ViralTrendsWidgetProps> = ({ title, items, themeColor }) => {
    const theme = THEME_CLASSES.cyan;

    return (
        <div className={`bg-gray-900/50 border ${theme.border} rounded-xl p-5`}>
            <div className="flex items-center gap-3 mb-4">
                 <div className={`flex-shrink-0 flex items-center justify-center w-8 h-8 rounded-lg ${theme.bg} ${theme.text}`}>
                    <i className="fa-solid fa-arrow-trend-up"></i>
                 </div>
                 <h3 className={`text-sm font-semibold ${theme.text} uppercase tracking-wider`}>{title}</h3>
            </div>
            <div className="space-y-3">
                {items.map((item, index) => (
                    <div key={index} className="flex items-center justify-between p-2 rounded-lg bg-gray-800/50">
                        <p className="text-sm font-medium text-white">{item.topic}</p>
                        <div className="flex items-center space-x-1">
                            <i className={`fa-solid fa-fire ${getHeatColor(item.heat)}`}></i>
                            <span className="text-xs font-bold text-gray-300">{item.heat}</span>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default ViralTrendsWidget;
