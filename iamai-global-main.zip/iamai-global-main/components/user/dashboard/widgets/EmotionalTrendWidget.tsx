import React from 'react';
import { AgentEmotionalTrend } from '../../../constants';

interface EmotionalTrendWidgetProps {
    title: string;
    trend: AgentEmotionalTrend;
    themeColor: string;
}

const THEME_CLASSES = {
    yellow: { border: 'border-yellow-500/50', text: 'text-yellow-400', bg: 'bg-yellow-500/10' },
};

const EmotionalTrendWidget: React.FC<EmotionalTrendWidgetProps> = ({ title, trend, themeColor }) => {
    // @ts-ignore
    const Recharts = window.Recharts;
    const theme = THEME_CLASSES.yellow;

    if (!Recharts) {
        return (
            <div className={`bg-gray-900/50 border ${theme.border} rounded-xl p-5 h-full flex items-center justify-center`}>
                <div className="text-center text-gray-400">
                    <i className="fa-solid fa-spinner fa-spin text-2xl mb-4"></i>
                    <p>Loading chart...</p>
                </div>
            </div>
        );
    }
    
    const { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid } = Recharts;

    return (
        <div className={`bg-gray-900/50 border ${theme.border} rounded-xl p-5`}>
            <div className="flex items-center gap-3 mb-4">
                 <div className={`flex-shrink-0 flex items-center justify-center w-8 h-8 rounded-lg ${theme.bg} ${theme.text}`}>
                    <i className="fa-solid fa-chart-line"></i>
                 </div>
                 <h3 className={`text-sm font-semibold ${theme.text} uppercase tracking-wider`}>{title}</h3>
            </div>

            <div className="h-40 -ml-4">
                <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={trend.data} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
                        <defs>
                            <linearGradient id="colorSentiment" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="5%" stopColor="#facc15" stopOpacity={0.8}/>
                                <stop offset="95%" stopColor="#facc15" stopOpacity={0}/>
                            </linearGradient>
                        </defs>
                        <Tooltip 
                            contentStyle={{ background: '#1f2937', border: '1px solid #4b5563', borderRadius: '0.5rem' }} 
                            itemStyle={{ color: '#facc15' }} 
                            labelFormatter={(label) => `Message ${label}`}
                        />
                        <CartesianGrid stroke="#374151" strokeDasharray="3 3" />
                        <XAxis dataKey="message" stroke="#9ca3af" fontSize={10} axisLine={false} tickLine={false} />
                        <YAxis stroke="#9ca3af" fontSize={10} axisLine={false} tickLine={false} domain={[-1, 1]} />
                        <Area type="monotone" dataKey="sentiment" stroke="#facc15" fill="url(#colorSentiment)" strokeWidth={2} />
                    </AreaChart>
                </ResponsiveContainer>
            </div>
        </div>
    );
};

export default EmotionalTrendWidget;