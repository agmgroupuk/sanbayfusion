import { Agent } from '../../constants';

export interface DashboardMetrics {
  totalChats: number;
  activeAgents: number;
  totalUsers: number;
  averageResponseTime: number;
  userSatisfaction: number;
  dailyActiveUsers: number;
  monthlyGrowth: number;
  systemUptime: number;
}

export interface UsageData {
  date: string;
  chats: number;
  users: number;
  responseTime: number;
}

export interface AgentPerformance {
  agent: Agent;
  totalChats: number;
  averageRating: number;
  responseTime: number;
  growthRate: number;
}

export interface DashboardStatsState {
  metrics: DashboardMetrics;
  usageData: UsageData[];
  agentPerformance: AgentPerformance[];
  isLoading: boolean;
  error: string | null;
  lastUpdated: Date;
  refreshInterval: number;
}

export class DashboardStatsService {
  private listeners: Set<(state: DashboardStatsState) => void> = new Set();
  private state: DashboardStatsState;
  private refreshTimer?: NodeJS.Timeout;

  constructor(agents: Agent[], refreshInterval: number = 30000) {
    this.state = {
      metrics: this.getDefaultMetrics(),
      usageData: [],
      agentPerformance: agents.map(agent => this.getDefaultAgentPerformance(agent)),
      isLoading: false,
      error: null,
      lastUpdated: new Date(),
      refreshInterval,
    };

    this.loadCachedData();
    this.startAutoRefresh();
  }

  private getDefaultMetrics(): DashboardMetrics {
    return {
      totalChats: 0,
      activeAgents: 0,
      totalUsers: 0,
      averageResponseTime: 0,
      userSatisfaction: 0,
      dailyActiveUsers: 0,
      monthlyGrowth: 0,
      systemUptime: 99.9,
    };
  }

  private getDefaultAgentPerformance(agent: Agent): AgentPerformance {
    return {
      agent,
      totalChats: 0,
      averageRating: 0,
      responseTime: 0,
      growthRate: 0,
    };
  }

  private loadCachedData(): void {
    try {
      const cached = localStorage.getItem('dashboard_stats_cache');
      if (cached) {
        const data = JSON.parse(cached);
        const cachedState = {
          ...data,
          lastUpdated: new Date(data.lastUpdated),
          isLoading: false,
        };

        // Check if cache is still fresh (less than 5 minutes old)
        const cacheAge = Date.now() - cachedState.lastUpdated.getTime();
        if (cacheAge < 5 * 60 * 1000) {
          this.updateState({ ...this.state, ...cachedState });
          return;
        }
      }
    } catch (error) {
      console.error('Failed to load cached dashboard data:', error);
    }

    // If no fresh cache, refresh data
    this.refreshData();
  }

  private saveCachedData(): void {
    try {
      localStorage.setItem(
        'dashboard_stats_cache',
        JSON.stringify({
          metrics: this.state.metrics,
          usageData: this.state.usageData,
          agentPerformance: this.state.agentPerformance,
          lastUpdated: this.state.lastUpdated,
        })
      );
    } catch (error) {
      console.error('Failed to cache dashboard data:', error);
    }
  }

  async refreshData(): Promise<void> {
    this.updateState({ ...this.state, isLoading: true, error: null });

    try {
      // Simulate API calls - replace with actual API endpoints
      const [metrics, usageData, agentPerformance] = await Promise.all([
        this.fetchMetrics(),
        this.fetchUsageData(),
        this.fetchAgentPerformance(),
      ]);

      this.updateState({
        ...this.state,
        metrics,
        usageData,
        agentPerformance,
        isLoading: false,
        lastUpdated: new Date(),
      });

      this.saveCachedData();
    } catch (error) {
      console.error('Failed to refresh dashboard data:', error);
      this.updateState({
        ...this.state,
        isLoading: false,
        error: 'Failed to load dashboard data',
      });
    }
  }

  private async fetchMetrics(): Promise<DashboardMetrics> {
    // Simulate API call - replace with actual endpoint
    return new Promise(resolve => {
      setTimeout(() => {
        // Generate mock data based on localStorage stats
        const metrics = this.calculateMetricsFromLocalStorage();
        resolve(metrics);
      }, 1000);
    });
  }

  private async fetchUsageData(): Promise<UsageData[]> {
    // Generate mock usage data for the last 30 days
    const data: UsageData[] = [];
    const now = new Date();

    for (let i = 29; i >= 0; i--) {
      const date = new Date(now.getTime() - i * 24 * 60 * 60 * 1000);
      data.push({
        date: date.toISOString().split('T')[0],
        chats: Math.floor(Math.random() * 100) + 20,
        users: Math.floor(Math.random() * 50) + 10,
        responseTime: Math.floor(Math.random() * 2000) + 500,
      });
    }

    return data;
  }

  private async fetchAgentPerformance(): Promise<AgentPerformance[]> {
    return this.state.agentPerformance.map(perf => {
      // Load actual stats from localStorage
      const stats = this.loadAgentStatsFromStorage(perf.agent.name);
      return {
        ...perf,
        totalChats: stats.totalChats,
        averageRating: stats.averageRating,
        responseTime: stats.responseTime,
        growthRate: Math.floor(Math.random() * 40) - 10, // Mock growth rate
      };
    });
  }

  private calculateMetricsFromLocalStorage(): DashboardMetrics {
    // Aggregate data from all stored agent stats
    let totalChats = 0;
    let totalRatings = 0;
    let totalResponseTime = 0;
    let ratedAgents = 0;

    this.state.agentPerformance.forEach(perf => {
      const stats = this.loadAgentStatsFromStorage(perf.agent.name);
      totalChats += stats.totalChats;
      if (stats.averageRating > 0) {
        totalRatings += stats.averageRating;
        ratedAgents++;
      }
      totalResponseTime += stats.responseTime;
    });

    return {
      totalChats,
      activeAgents: this.state.agentPerformance.length,
      totalUsers: Math.floor(totalChats * 0.3), // Estimate
      averageResponseTime: totalResponseTime / this.state.agentPerformance.length,
      userSatisfaction: ratedAgents > 0 ? (totalRatings / ratedAgents) * 20 : 0, // Convert to percentage
      dailyActiveUsers: Math.floor(Math.random() * 200) + 50,
      monthlyGrowth: Math.floor(Math.random() * 30) + 5,
      systemUptime: 99.9,
    };
  }

  private loadAgentStatsFromStorage(agentName: string): any {
    try {
      const stored = localStorage.getItem(`agent_stats_${agentName}`);
      return stored
        ? JSON.parse(stored)
        : {
            totalChats: 0,
            averageRating: 0,
            responseTime: 0,
          };
    } catch {
      return {
        totalChats: 0,
        averageRating: 0,
        responseTime: 0,
      };
    }
  }

  private startAutoRefresh(): void {
    this.refreshTimer = setInterval(() => {
      this.refreshData();
    }, this.state.refreshInterval);
  }

  stopAutoRefresh(): void {
    if (this.refreshTimer) {
      clearInterval(this.refreshTimer);
      this.refreshTimer = undefined;
    }
  }

  setRefreshInterval(interval: number): void {
    this.stopAutoRefresh();
    this.updateState({ ...this.state, refreshInterval: interval });
    this.startAutoRefresh();
  }

  getTopPerformingAgents(limit: number = 5): AgentPerformance[] {
    return [...this.state.agentPerformance]
      .sort((a, b) => {
        // Sort by total chats and rating
        const scoreA = a.totalChats * 0.6 + a.averageRating * 20 * 0.4;
        const scoreB = b.totalChats * 0.6 + b.averageRating * 20 * 0.4;
        return scoreB - scoreA;
      })
      .slice(0, limit);
  }

  getUsageTrend(days: number = 7): { direction: 'up' | 'down' | 'stable'; percentage: number } {
    if (this.state.usageData.length < days) {
      return { direction: 'stable', percentage: 0 };
    }

    const recent = this.state.usageData.slice(-days);
    const older = this.state.usageData.slice(-days * 2, -days);

    const recentAvg = recent.reduce((sum, d) => sum + d.chats, 0) / recent.length;
    const olderAvg =
      older.length > 0 ? older.reduce((sum, d) => sum + d.chats, 0) / older.length : recentAvg;

    const change = ((recentAvg - olderAvg) / olderAvg) * 100;

    if (Math.abs(change) < 5) return { direction: 'stable', percentage: Math.abs(change) };
    return {
      direction: change > 0 ? 'up' : 'down',
      percentage: Math.abs(change),
    };
  }

  getFormattedMetrics(): Record<keyof DashboardMetrics, string> {
    const m = this.state.metrics;
    return {
      totalChats: this.formatNumber(m.totalChats),
      activeAgents: m.activeAgents.toString(),
      totalUsers: this.formatNumber(m.totalUsers),
      averageResponseTime: `${(m.averageResponseTime / 1000).toFixed(1)}s`,
      userSatisfaction: `${m.userSatisfaction.toFixed(1)}%`,
      dailyActiveUsers: this.formatNumber(m.dailyActiveUsers),
      monthlyGrowth: `${m.monthlyGrowth > 0 ? '+' : ''}${m.monthlyGrowth}%`,
      systemUptime: `${m.systemUptime.toFixed(1)}%`,
    };
  }

  private formatNumber(num: number): string {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toString();
  }

  getState(): DashboardStatsState {
    return { ...this.state };
  }

  subscribe(listener: (state: DashboardStatsState) => void): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private updateState(newState: DashboardStatsState): void {
    this.state = newState;
    this.listeners.forEach(listener => listener(this.state));
  }

  destroy(): void {
    this.stopAutoRefresh();
    this.listeners.clear();
  }
}
