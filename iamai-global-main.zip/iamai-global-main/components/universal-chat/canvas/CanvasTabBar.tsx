'use client';

import { PlusIcon } from '@heroicons/react/24/outline';
import { FileTab } from './types';
import CanvasTab from './CanvasTab';
import CanvasButton from './CanvasButton';

interface CanvasTabBarProps {
  tabs: FileTab[];
  activeTabId: string;
  isNeural?: boolean;
  onTabSelect: (tabId: string) => void;
  onTabClose: (tabId: string) => void;
  onNewTab: () => void;
}

export default function CanvasTabBar({
  tabs,
  activeTabId,
  isNeural = true,
  onTabSelect,
  onTabClose,
  onNewTab,
}: CanvasTabBarProps) {
  const bgColor = isNeural ? 'bg-gray-800' : 'bg-gray-50';
  const borderColor = isNeural ? 'border-gray-700/50' : 'border-gray-200';

  return (
    <div className={`flex items-center ${bgColor} border-b ${borderColor} overflow-x-auto`}>
      {/* Tabs */}
      <div className="flex items-center flex-1 min-w-0">
        {tabs.map(tab => (
          <CanvasTab
            key={tab.id}
            tab={tab}
            isActive={tab.id === activeTabId}
            isNeural={isNeural}
            onSelect={onTabSelect}
            onClose={onTabClose}
            canClose={tabs.length > 1}
          />
        ))}
      </div>

      {/* Add Tab Button */}
      <div className="flex-shrink-0 px-2">
        <CanvasButton
          variant="icon"
          size="sm"
          isNeural={isNeural}
          onClick={onNewTab}
          title="New file"
        >
          <PlusIcon className="w-4 h-4" />
        </CanvasButton>
      </div>
    </div>
  );
}
