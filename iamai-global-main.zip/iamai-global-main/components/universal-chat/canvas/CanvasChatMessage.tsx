import { ChatMessage, CanvasTheme } from './types';

interface CanvasChatMessageProps {
  message: ChatMessage;
  theme: CanvasTheme;
}

export default function CanvasChatMessage({ message, theme }: CanvasChatMessageProps) {
  const { isNeural } = theme;
  const alignment = message.role === 'user' ? 'justify-end' : 'justify-start';

  const bubbleClasses =
    message.role === 'user'
      ? isNeural
        ? 'bg-gradient-to-r from-cyan-600 to-purple-600 text-white'
        : 'bg-indigo-600 text-white'
      : isNeural
        ? 'bg-gray-800 text-gray-100'
        : 'bg-gray-200 text-gray-900';

  return (
    <div className={`flex ${alignment}`}>
      <div className={`max-w-[90%] rounded-2xl px-4 py-2.5 ${bubbleClasses}`}>
        <p className="text-sm whitespace-pre-wrap">{message.content}</p>
      </div>
    </div>
  );
}
