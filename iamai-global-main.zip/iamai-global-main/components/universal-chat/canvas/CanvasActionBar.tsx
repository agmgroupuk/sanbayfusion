import { SparklesIcon, PhotoIcon, WrenchIcon, GlobeAltIcon } from '@heroicons/react/24/outline';
import CanvasButton from './CanvasButton';
import { CanvasTheme } from './types';

interface CanvasActionBarProps {
  onAction: (action: 'landing' | 'dashboard' | 'fix' | 'image') => void;
  theme: CanvasTheme;
}

const actions = [
  { key: 'landing' as const, label: 'AI Landing Page', icon: <GlobeAltIcon className="w-4 h-4" /> },
  { key: 'dashboard' as const, label: 'AI Dashboard', icon: <SparklesIcon className="w-4 h-4" /> },
  { key: 'fix' as const, label: 'Fix Bugs', icon: <WrenchIcon className="w-4 h-4" /> },
  { key: 'image' as const, label: 'Generate Image', icon: <PhotoIcon className="w-4 h-4" /> },
];

export default function CanvasActionBar({ onAction, theme }: CanvasActionBarProps) {
  const { isNeural } = theme;

  return (
    <div
      className={`px-4 py-3 border-b ${theme.borderColor} ${
        isNeural ? 'bg-gradient-to-r from-gray-900 via-gray-900 to-gray-800' : 'bg-white'
      } flex items-center justify-between gap-3`}
    >
      <div className={`text-sm font-medium ${theme.textPrimary}`}>AI Accelerators</div>
      <div className="flex items-center gap-2 flex-wrap">
        {actions.map(action => (
          <CanvasButton
            key={action.key}
            variant="secondary"
            size="sm"
            isNeural={isNeural}
            onClick={() => onAction(action.key)}
          >
            <div className="flex items-center gap-1.5">
              {action.icon}
              <span>{action.label}</span>
            </div>
          </CanvasButton>
        ))}
      </div>
    </div>
  );
}
