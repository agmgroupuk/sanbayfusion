import {
  XMarkIcon,
  DocumentDuplicateIcon,
  ArrowTopRightOnSquareIcon,
  TrashIcon,
} from '@heroicons/react/24/outline';
import CanvasButton from './CanvasButton';
import { CanvasTheme } from './types';

interface CanvasHeaderProps {
  theme: CanvasTheme;
  onClose: () => void;
  onCopy: () => void;
  onShare: () => void;
  onDelete: () => void;
}

export default function CanvasHeader({
  theme,
  onClose,
  onCopy,
  onShare,
  onDelete,
}: CanvasHeaderProps) {
  const { isNeural, bgSecondary, borderColor, textPrimary } = theme;

  return (
    <div
      className={`flex items-center justify-between px-4 py-2 border-b ${borderColor} ${bgSecondary}`}
    >
      {/* Left side - Title */}
      <div className={`text-sm font-medium ${textPrimary}`}>Canvas</div>

      {/* Right side - Action icons */}
      <div className="flex items-center space-x-1">
        <CanvasButton
          variant="icon"
          size="sm"
          isNeural={isNeural}
          onClick={onCopy}
          title="Copy code"
        >
          <DocumentDuplicateIcon className="w-4 h-4" />
        </CanvasButton>

        <CanvasButton
          variant="icon"
          size="sm"
          isNeural={isNeural}
          onClick={onShare}
          title="Open in external browser"
        >
          <ArrowTopRightOnSquareIcon className="w-4 h-4" />
        </CanvasButton>

        <CanvasButton
          variant="icon"
          size="sm"
          isNeural={isNeural}
          onClick={onDelete}
          title="Delete"
          className={`${isNeural ? 'hover:text-red-400 hover:bg-red-500/20' : 'hover:text-red-500 hover:bg-red-100'}`}
        >
          <TrashIcon className="w-4 h-4" />
        </CanvasButton>

        <div className={`w-px h-5 mx-1 ${isNeural ? 'bg-gray-700' : 'bg-gray-300'}`} />

        <CanvasButton
          variant="icon"
          size="sm"
          isNeural={isNeural}
          onClick={onClose}
          title="Close Canvas"
          className={`${isNeural ? 'text-red-400 hover:bg-red-500/20' : 'text-red-500 hover:bg-red-100'}`}
        >
          <XMarkIcon className="w-5 h-5" />
        </CanvasButton>
      </div>
    </div>
  );
}
