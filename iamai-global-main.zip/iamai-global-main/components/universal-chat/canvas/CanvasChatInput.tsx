import { KeyboardEvent, RefObject } from 'react';
import { PaperAirplaneIcon } from '@heroicons/react/24/outline';
import CanvasButton from './CanvasButton';
import { CanvasTheme } from './types';

interface CanvasChatInputProps {
  value: string;
  onChange: (value: string) => void;
  onSend: () => void;
  isGenerating?: boolean;
  theme: CanvasTheme;
  textAreaRef?: RefObject<HTMLTextAreaElement>;
}

export default function CanvasChatInput({
  value,
  onChange,
  onSend,
  isGenerating = false,
  theme,
  textAreaRef,
}: CanvasChatInputProps) {
  const { isNeural, textPrimary } = theme;

  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      onSend();
    }
  };

  return (
    <div
      className={`flex items-end space-x-2 rounded-xl ${isNeural ? 'bg-gray-800' : 'bg-gray-100'} p-2`}
    >
      <textarea
        ref={textAreaRef}
        value={value}
        onChange={e => onChange(e.target.value)}
        onKeyDown={handleKeyDown}
        placeholder="Ask AI to help with code..."
        className={`flex-1 resize-none bg-transparent outline-none text-sm ${textPrimary} placeholder-gray-500`}
        rows={2}
      />
      <CanvasButton
        variant="icon"
        size="sm"
        isNeural={isNeural}
        onClick={onSend}
        disabled={!value.trim() || isGenerating}
        title="Send to AI"
      >
        <PaperAirplaneIcon className="w-4 h-4" />
      </CanvasButton>
    </div>
  );
}
