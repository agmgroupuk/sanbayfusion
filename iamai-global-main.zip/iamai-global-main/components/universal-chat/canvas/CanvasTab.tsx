'use client';

import { XMarkIcon } from '@heroicons/react/24/outline';
import { FileTab, LANGUAGE_ICONS } from './types';

interface CanvasTabProps {
  tab: FileTab;
  isActive: boolean;
  isNeural?: boolean;
  onSelect: (tabId: string) => void;
  onClose: (tabId: string) => void;
  canClose?: boolean;
}

export default function CanvasTab({
  tab,
  isActive,
  isNeural = true,
  onSelect,
  onClose,
  canClose = true,
}: CanvasTabProps) {
  const icon = LANGUAGE_ICONS[tab.language] || LANGUAGE_ICONS.default;

  const baseClasses =
    'group flex items-center space-x-2 px-3 py-2 text-sm transition-all duration-200 cursor-pointer';

  const activeClasses = isActive
    ? isNeural
      ? 'bg-gray-950 text-cyan-400 border-t-2 border-cyan-400'
      : 'bg-gray-900 text-indigo-400 border-t-2 border-indigo-400'
    : isNeural
      ? 'bg-gray-800 text-gray-400 hover:text-gray-200 hover:bg-gray-700/50'
      : 'bg-gray-100 text-gray-600 hover:text-gray-900 hover:bg-gray-200';

  return (
    <div className={`${baseClasses} ${activeClasses}`} onClick={() => onSelect(tab.id)}>
      <span className="text-base">{icon}</span>
      <span className="max-w-[120px] truncate">{tab.name}</span>
      {tab.isModified && (
        <span className={`w-2 h-2 rounded-full ${isNeural ? 'bg-cyan-400' : 'bg-indigo-400'}`} />
      )}
      {canClose && (
        <button
          onClick={e => {
            e.stopPropagation();
            onClose(tab.id);
          }}
          className={`ml-1 p-0.5 rounded opacity-0 group-hover:opacity-100 transition-opacity ${
            isNeural ? 'hover:bg-gray-600' : 'hover:bg-gray-300'
          }`}
        >
          <XMarkIcon className="w-3.5 h-3.5" />
        </button>
      )}
    </div>
  );
}
