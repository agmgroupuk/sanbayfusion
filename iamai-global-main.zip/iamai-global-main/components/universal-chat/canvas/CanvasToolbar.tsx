import { XMarkIcon } from '@heroicons/react/24/outline';
import CanvasButton from './CanvasButton';
import CanvasTabBar from './CanvasTabBar';
import { CanvasTheme, FileTab } from './types';

interface CanvasToolbarProps {
  tabs: FileTab[];
  activeTabId: string;
  theme: CanvasTheme;
  onTabSelect: (tabId: string) => void;
  onTabClose: (tabId: string) => void;
  onNewTab: () => void;
  onClose: () => void;
}

export default function CanvasToolbar({
  tabs,
  activeTabId,
  theme,
  onTabSelect,
  onTabClose,
  onNewTab,
  onClose,
}: CanvasToolbarProps) {
  const { isNeural, bgSecondary, borderColor } = theme;

  return (
    <div
      className={`flex items-center justify-between px-4 py-2 border-b ${borderColor} ${bgSecondary}`}
    >
      <div className="flex-1 min-w-0">
        <CanvasTabBar
          tabs={tabs}
          activeTabId={activeTabId}
          isNeural={isNeural}
          onTabSelect={onTabSelect}
          onTabClose={onTabClose}
          onNewTab={onNewTab}
        />
      </div>

      <div className="flex items-center space-x-2 ml-4">
        <CanvasButton
          variant="icon"
          size="sm"
          isNeural={isNeural}
          onClick={onClose}
          title="Close Canvas"
          className={`${isNeural ? 'text-red-400 hover:bg-red-500/20' : 'text-red-500 hover:bg-red-100'}`}
        >
          <XMarkIcon className="w-5 h-5" />
        </CanvasButton>
      </div>
    </div>
  );
}
