import Editor, { OnMount } from '@monaco-editor/react';
import { CanvasTheme, FileTab, getMonacoLanguage } from './types';

interface CanvasEditorProps {
  activeTab?: FileTab;
  theme: CanvasTheme;
  monacoTheme: string;
  onChange: (value: string | undefined) => void;
  onMount: OnMount;
}

export default function CanvasEditor({
  activeTab,
  theme,
  monacoTheme,
  onChange,
  onMount,
}: CanvasEditorProps) {
  const { textSecondary } = theme;

  return (
    <Editor
      height="100%"
      language={getMonacoLanguage(activeTab?.language || 'javascript')}
      value={activeTab?.content || ''}
      onChange={onChange}
      onMount={onMount}
      theme={monacoTheme}
      options={{
        minimap: { enabled: true },
        fontSize: 14,
        lineNumbers: 'on',
        roundedSelection: true,
        scrollBeyondLastLine: false,
        automaticLayout: true,
        tabSize: 2,
        wordWrap: 'on',
        bracketPairColorization: { enabled: true },
        cursorBlinking: 'smooth',
        cursorSmoothCaretAnimation: 'on',
        smoothScrolling: true,
        padding: { top: 16, bottom: 16 },
        renderLineHighlight: 'all',
        fontFamily: "'Fira Code', 'JetBrains Mono', 'SF Mono', Consolas, monospace",
        fontLigatures: true,
      }}
      loading={
        <div className="flex items-center justify-center h-full">
          <div className="flex flex-col items-center space-y-3">
            <div className="w-8 h-8 border-2 border-cyan-500 border-t-transparent rounded-full animate-spin" />
            <span className={`text-sm ${textSecondary}`}>Loading Monaco Editor...</span>
          </div>
        </div>
      }
    />
  );
}
