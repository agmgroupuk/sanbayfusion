import { EyeIcon } from '@heroicons/react/24/outline';
import { RefObject } from 'react';
import { CanvasTheme } from './types';

interface CanvasPreviewProps {
  iframeRef: RefObject<HTMLIFrameElement>;
  theme: CanvasTheme;
}

export default function CanvasPreview({ iframeRef, theme }: CanvasPreviewProps) {
  const { isNeural, bgPrimary, borderColor, textPrimary } = theme;

  return (
    <>
      <div className={`px-3 py-2 border-b ${borderColor} flex items-center space-x-2`}>
        <EyeIcon className={`w-4 h-4 ${isNeural ? 'text-purple-400' : 'text-indigo-500'}`} />
        <span className={`text-sm font-medium ${textPrimary}`}>Live Preview</span>
      </div>
      <iframe
        ref={iframeRef}
        className="flex-1 w-full bg-white"
        title="Preview"
        sandbox="allow-scripts"
      />
    </>
  );
}
