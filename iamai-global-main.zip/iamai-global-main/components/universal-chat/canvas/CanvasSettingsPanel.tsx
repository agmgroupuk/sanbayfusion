import { Cog6ToothIcon, XMarkIcon } from '@heroicons/react/24/outline';
import { useState, useEffect } from 'react';
import CanvasButton from './CanvasButton';
import { CanvasTheme } from './types';

interface CanvasSettings {
  provider: string;
  model: string;
  temperature: number;
  maxTokens: number;
  systemPrompt: string;
}

interface CanvasSettingsPanelProps {
  isOpen: boolean;
  onClose: () => void;
  theme: CanvasTheme;
  settings: CanvasSettings;
  onSettingsChange: (settings: CanvasSettings) => void;
}

const PROVIDERS = [
  { id: 'mistral', name: 'Mistral AI' },
  { id: 'openai', name: 'OpenAI' },
  { id: 'anthropic', name: 'Anthropic' },
  { id: 'groq', name: 'Groq' },
  { id: 'google', name: 'Google AI' },
];

const MODELS: Record<string, { id: string; name: string }[]> = {
  mistral: [
    { id: 'mistral-large-latest', name: 'Mistral Large' },
    { id: 'mistral-medium-latest', name: 'Mistral Medium' },
    { id: 'mistral-small-latest', name: 'Mistral Small' },
    { id: 'codestral-latest', name: 'Codestral' },
  ],
  openai: [
    { id: 'gpt-4o', name: 'GPT-4o' },
    { id: 'gpt-4o-mini', name: 'GPT-4o Mini' },
    { id: 'gpt-4-turbo', name: 'GPT-4 Turbo' },
    { id: 'gpt-3.5-turbo', name: 'GPT-3.5 Turbo' },
  ],
  anthropic: [
    { id: 'claude-3-5-sonnet-20241022', name: 'Claude 3.5 Sonnet' },
    { id: 'claude-3-opus-20240229', name: 'Claude 3 Opus' },
    { id: 'claude-3-haiku-20240307', name: 'Claude 3 Haiku' },
  ],
  groq: [
    { id: 'llama-3.3-70b-versatile', name: 'Llama 3.3 70B' },
    { id: 'llama-3.1-8b-instant', name: 'Llama 3.1 8B' },
    { id: 'mixtral-8x7b-32768', name: 'Mixtral 8x7B' },
  ],
  google: [
    { id: 'gemini-1.5-pro', name: 'Gemini 1.5 Pro' },
    { id: 'gemini-1.5-flash', name: 'Gemini 1.5 Flash' },
  ],
};

export default function CanvasSettingsPanel({
  isOpen,
  onClose,
  theme,
  settings,
  onSettingsChange,
}: CanvasSettingsPanelProps) {
  const { isNeural, bgPrimary, borderColor, textPrimary, textSecondary } = theme;
  const [localSettings, setLocalSettings] = useState<CanvasSettings>(settings);

  useEffect(() => {
    setLocalSettings(settings);
  }, [settings]);

  const handleProviderChange = (provider: string) => {
    const models = MODELS[provider] || [];
    const newModel = models[0]?.id || '';
    setLocalSettings(prev => ({ ...prev, provider, model: newModel }));
  };

  const handleSave = () => {
    onSettingsChange(localSettings);
    onClose();
  };

  const availableModels = MODELS[localSettings.provider] || [];

  const inputClass = `w-full px-3 py-2 rounded-lg text-sm ${
    isNeural
      ? 'bg-gray-800 border-gray-700 text-gray-100 focus:border-cyan-500'
      : 'bg-white border-gray-300 text-gray-900 focus:border-indigo-500'
  } border focus:outline-none focus:ring-1 ${
    isNeural ? 'focus:ring-cyan-500/50' : 'focus:ring-indigo-500/50'
  }`;

  const labelClass = `block text-xs font-medium mb-1.5 ${textSecondary}`;

  if (!isOpen) return null;

  return (
    <div
      className={`absolute left-14 top-0 bottom-0 w-80 ${bgPrimary} border-r ${borderColor} z-10 flex flex-col shadow-xl`}
    >
      {/* Header */}
      <div className={`flex items-center justify-between px-3 py-2 border-b ${borderColor}`}>
        <div className="flex items-center space-x-2">
          <Cog6ToothIcon className={`w-4 h-4 ${isNeural ? 'text-cyan-400' : 'text-indigo-500'}`} />
          <span className={`text-sm font-medium ${textPrimary}`}>Settings</span>
        </div>
        <CanvasButton variant="icon" size="sm" isNeural={isNeural} onClick={onClose} title="Close">
          <XMarkIcon className="w-4 h-4" />
        </CanvasButton>
      </div>

      {/* Settings form */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {/* Provider */}
        <div>
          <label className={labelClass}>AI Provider</label>
          <select
            value={localSettings.provider}
            onChange={e => handleProviderChange(e.target.value)}
            className={inputClass}
          >
            {PROVIDERS.map(p => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </select>
        </div>

        {/* Model */}
        <div>
          <label className={labelClass}>Model</label>
          <select
            value={localSettings.model}
            onChange={e => setLocalSettings(prev => ({ ...prev, model: e.target.value }))}
            className={inputClass}
          >
            {availableModels.map(m => (
              <option key={m.id} value={m.id}>
                {m.name}
              </option>
            ))}
          </select>
        </div>

        {/* Temperature */}
        <div>
          <label className={labelClass}>Temperature: {localSettings.temperature.toFixed(1)}</label>
          <input
            type="range"
            min="0"
            max="1"
            step="0.1"
            value={localSettings.temperature}
            onChange={e =>
              setLocalSettings(prev => ({ ...prev, temperature: parseFloat(e.target.value) }))
            }
            className={`w-full h-2 rounded-lg appearance-none cursor-pointer ${
              isNeural ? 'bg-gray-700' : 'bg-gray-200'
            }`}
          />
          <div className={`flex justify-between text-xs mt-1 ${textSecondary}`}>
            <span>Precise</span>
            <span>Creative</span>
          </div>
        </div>

        {/* Max Tokens */}
        <div>
          <label className={labelClass}>Max Tokens</label>
          <input
            type="number"
            value={localSettings.maxTokens}
            onChange={e =>
              setLocalSettings(prev => ({ ...prev, maxTokens: parseInt(e.target.value) || 4000 }))
            }
            min={100}
            max={16000}
            className={inputClass}
          />
        </div>

        {/* System Prompt */}
        <div>
          <label className={labelClass}>Custom System Prompt</label>
          <textarea
            value={localSettings.systemPrompt}
            onChange={e => setLocalSettings(prev => ({ ...prev, systemPrompt: e.target.value }))}
            rows={4}
            placeholder="Enter a custom system prompt to guide the AI..."
            className={`${inputClass} resize-none`}
          />
        </div>
      </div>

      {/* Footer */}
      <div className={`px-4 py-3 border-t ${borderColor} flex justify-end space-x-2`}>
        <CanvasButton variant="secondary" size="sm" isNeural={isNeural} onClick={onClose}>
          Cancel
        </CanvasButton>
        <CanvasButton variant="primary" size="sm" isNeural={isNeural} onClick={handleSave}>
          Save Changes
        </CanvasButton>
      </div>
    </div>
  );
}
