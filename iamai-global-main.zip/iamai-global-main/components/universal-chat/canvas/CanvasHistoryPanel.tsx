import { ClockIcon, TrashIcon, ChatBubbleLeftIcon } from '@heroicons/react/24/outline';
import CanvasButton from './CanvasButton';
import { CanvasTheme, ChatMessage } from './types';

interface HistoryItem {
  id: string;
  title: string;
  timestamp: Date;
  messageCount: number;
}

interface CanvasHistoryPanelProps {
  isOpen: boolean;
  onClose: () => void;
  theme: CanvasTheme;
  currentMessages: ChatMessage[];
  onLoadHistory?: (historyId: string) => void;
  onDeleteHistory?: (historyId: string) => void;
}

export default function CanvasHistoryPanel({
  isOpen,
  onClose,
  theme,
  currentMessages,
  onLoadHistory,
  onDeleteHistory,
}: CanvasHistoryPanelProps) {
  const { isNeural, bgPrimary, borderColor, textPrimary, textSecondary } = theme;

  // Mock history items - in real implementation, load from storage/API
  const historyItems: HistoryItem[] = [
    {
      id: 'current',
      title: 'Current Session',
      timestamp: new Date(),
      messageCount: currentMessages.length,
    },
    // Add more mock items or load from storage
  ];

  const formatDate = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 1) return 'Just now';
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    return `${days}d ago`;
  };

  if (!isOpen) return null;

  return (
    <div
      className={`absolute left-14 top-0 bottom-0 w-72 ${bgPrimary} border-r ${borderColor} z-10 flex flex-col shadow-xl`}
    >
      {/* Header */}
      <div className={`flex items-center justify-between px-3 py-2 border-b ${borderColor}`}>
        <div className="flex items-center space-x-2">
          <ClockIcon className={`w-4 h-4 ${isNeural ? 'text-cyan-400' : 'text-indigo-500'}`} />
          <span className={`text-sm font-medium ${textPrimary}`}>History</span>
        </div>
      </div>

      {/* History list */}
      <div className="flex-1 overflow-y-auto">
        {historyItems.length === 0 ? (
          <div className={`p-4 text-center ${textSecondary}`}>
            <ClockIcon className="w-8 h-8 mx-auto mb-2 opacity-50" />
            <p className="text-sm">No history yet</p>
            <p className="text-xs mt-1">Your chat sessions will appear here</p>
          </div>
        ) : (
          <div className="p-2 space-y-1">
            {historyItems.map(item => (
              <div
                key={item.id}
                className={`p-3 rounded-lg cursor-pointer transition-colors ${
                  item.id === 'current'
                    ? isNeural
                      ? 'bg-cyan-500/20 border border-cyan-500/30'
                      : 'bg-indigo-100 border border-indigo-200'
                    : isNeural
                      ? 'hover:bg-gray-800'
                      : 'hover:bg-gray-100'
                }`}
                onClick={() => onLoadHistory?.(item.id)}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1 min-w-0">
                    <div className={`text-sm font-medium truncate ${textPrimary}`}>
                      {item.title}
                    </div>
                    <div className={`flex items-center space-x-2 mt-1 text-xs ${textSecondary}`}>
                      <span>{formatDate(item.timestamp)}</span>
                      <span>•</span>
                      <span className="flex items-center">
                        <ChatBubbleLeftIcon className="w-3 h-3 mr-1" />
                        {item.messageCount}
                      </span>
                    </div>
                  </div>
                  {item.id !== 'current' && (
                    <CanvasButton
                      variant="icon"
                      size="sm"
                      isNeural={isNeural}
                      onClick={e => {
                        e.stopPropagation();
                        onDeleteHistory?.(item.id);
                      }}
                      title="Delete"
                      className={`opacity-0 group-hover:opacity-100 ${
                        isNeural ? 'hover:text-red-400' : 'hover:text-red-500'
                      }`}
                    >
                      <TrashIcon className="w-3 h-3" />
                    </CanvasButton>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Footer */}
      <div className={`px-3 py-2 border-t ${borderColor}`}>
        <span className={`text-xs ${textSecondary}`}>{historyItems.length} session(s)</span>
      </div>
    </div>
  );
}
