'use client';

import { ButtonHTMLAttributes, forwardRef } from 'react';

interface CanvasButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'ghost' | 'icon';
  size?: 'sm' | 'md' | 'lg';
  isNeural?: boolean;
  isActive?: boolean;
  children: React.ReactNode;
}

const CanvasButton = forwardRef<HTMLButtonElement, CanvasButtonProps>(
  (
    {
      variant = 'ghost',
      size = 'md',
      isNeural = true,
      isActive = false,
      children,
      className = '',
      disabled,
      ...props
    },
    ref
  ) => {
    // Size classes
    const sizeClasses = {
      sm: 'px-2 py-1 text-xs',
      md: 'px-3 py-1.5 text-sm',
      lg: 'px-4 py-2 text-base',
    };

    // Base classes
    const baseClasses =
      'inline-flex items-center justify-center rounded-lg font-medium transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-1';

    // Variant classes
    const getVariantClasses = () => {
      switch (variant) {
        case 'primary':
          return isNeural
            ? 'bg-cyan-600 hover:bg-cyan-500 text-white focus:ring-cyan-400'
            : 'bg-indigo-600 hover:bg-indigo-500 text-white focus:ring-indigo-400';
        case 'secondary':
          return isNeural
            ? 'bg-gray-700 hover:bg-gray-600 text-gray-100 focus:ring-gray-500'
            : 'bg-gray-200 hover:bg-gray-300 text-gray-900 focus:ring-gray-400';
        case 'ghost':
          return isNeural
            ? `hover:bg-gray-700/50 ${isActive ? 'bg-gray-700/70 text-cyan-400' : 'text-gray-400 hover:text-gray-200'}`
            : `hover:bg-gray-100 ${isActive ? 'bg-gray-200 text-indigo-600' : 'text-gray-600 hover:text-gray-900'}`;
        case 'icon':
          return isNeural
            ? `p-2 hover:bg-gray-700/50 ${isActive ? 'bg-gray-700/70 text-cyan-400' : 'text-gray-400 hover:text-gray-200'}`
            : `p-2 hover:bg-gray-100 ${isActive ? 'bg-gray-200 text-indigo-600' : 'text-gray-600 hover:text-gray-900'}`;
        default:
          return '';
      }
    };

    // Disabled classes
    const disabledClasses = disabled
      ? 'opacity-50 cursor-not-allowed pointer-events-none'
      : 'cursor-pointer';

    return (
      <button
        ref={ref}
        className={`${baseClasses} ${variant !== 'icon' ? sizeClasses[size] : ''} ${getVariantClasses()} ${disabledClasses} ${className}`}
        disabled={disabled}
        {...props}
      >
        {children}
      </button>
    );
  }
);

CanvasButton.displayName = 'CanvasButton';

export default CanvasButton;
