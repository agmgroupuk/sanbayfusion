// Canvas component types - shared across all canvas components

export interface FileTab {
  id: string;
  name: string;
  language: string;
  content: string;
  isModified: boolean;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

export interface CanvasTheme {
  isNeural: boolean;
  bgPrimary: string;
  bgSecondary: string;
  bgEditor: string;
  borderColor: string;
  textPrimary: string;
  textSecondary: string;
  accentColor: string;
}

export type ViewMode = 'code' | 'preview' | 'split';

// Language configuration
export const LANGUAGE_ICONS: Record<string, string> = {
  javascript: '📜',
  typescript: '💠',
  python: '🐍',
  html: '🌐',
  css: '🎨',
  json: '📋',
  markdown: '📝',
  jsx: '⚛️',
  tsx: '⚛️',
  default: '📄',
};

export const MONACO_LANGUAGE_MAP: Record<string, string> = {
  javascript: 'javascript',
  typescript: 'typescript',
  python: 'python',
  html: 'html',
  css: 'css',
  json: 'json',
  markdown: 'markdown',
  jsx: 'javascript',
  tsx: 'typescript',
  java: 'java',
  cpp: 'cpp',
  c: 'c',
  csharp: 'csharp',
  go: 'go',
  rust: 'rust',
  sql: 'sql',
  yaml: 'yaml',
  xml: 'xml',
  php: 'php',
  ruby: 'ruby',
  swift: 'swift',
  kotlin: 'kotlin',
};

// Helper function to get Monaco language
export const getMonacoLanguage = (lang: string): string => {
  return MONACO_LANGUAGE_MAP[lang] || 'plaintext';
};

// Helper function to create theme from mode
export const createCanvasTheme = (mode: 'default' | 'neural'): CanvasTheme => {
  const isNeural = mode === 'neural';
  return {
    isNeural,
    bgPrimary: isNeural ? 'bg-gray-900' : 'bg-white',
    bgSecondary: isNeural ? 'bg-gray-800' : 'bg-gray-50',
    bgEditor: isNeural ? 'bg-gray-950' : 'bg-gray-900',
    borderColor: isNeural ? 'border-gray-700/50' : 'border-gray-200',
    textPrimary: isNeural ? 'text-gray-100' : 'text-gray-900',
    textSecondary: isNeural ? 'text-gray-400' : 'text-gray-500',
    accentColor: isNeural ? 'cyan' : 'indigo',
  };
};
