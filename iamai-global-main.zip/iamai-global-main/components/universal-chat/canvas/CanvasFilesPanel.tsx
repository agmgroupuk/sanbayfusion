import {
  FolderIcon,
  DocumentIcon,
  ChevronRightIcon,
  ChevronDownIcon,
  PlusIcon,
} from '@heroicons/react/24/outline';
import { useState } from 'react';
import CanvasButton from './CanvasButton';
import { CanvasTheme, FileTab } from './types';

interface CanvasFilesPanelProps {
  isOpen: boolean;
  onClose: () => void;
  tabs: FileTab[];
  activeTabId: string;
  onTabSelect: (tabId: string) => void;
  onNewTab: () => void;
  theme: CanvasTheme;
}

// Mock folder structure - will be populated by agent during build
interface FileNode {
  id: string;
  name: string;
  type: 'file' | 'folder';
  children?: FileNode[];
  language?: string;
}

export default function CanvasFilesPanel({
  isOpen,
  onClose,
  tabs,
  activeTabId,
  onTabSelect,
  onNewTab,
  theme,
}: CanvasFilesPanelProps) {
  const { isNeural, bgPrimary, borderColor, textPrimary, textSecondary } = theme;
  const [expandedFolders, setExpandedFolders] = useState<Set<string>>(new Set(['root']));

  // Convert tabs to file structure
  const fileStructure: FileNode = {
    id: 'root',
    name: 'Project',
    type: 'folder',
    children: tabs.map(tab => ({
      id: tab.id,
      name: tab.name,
      type: 'file' as const,
      language: tab.language,
    })),
  };

  const toggleFolder = (folderId: string) => {
    setExpandedFolders(prev => {
      const next = new Set(prev);
      if (next.has(folderId)) {
        next.delete(folderId);
      } else {
        next.add(folderId);
      }
      return next;
    });
  };

  const renderNode = (node: FileNode, depth = 0) => {
    const isExpanded = expandedFolders.has(node.id);
    const isActive = node.type === 'file' && node.id === activeTabId;
    const paddingLeft = depth * 12 + 8;

    return (
      <div key={node.id}>
        <div
          className={`flex items-center py-1.5 px-2 cursor-pointer rounded-md transition-colors ${
            isActive
              ? isNeural
                ? 'bg-cyan-500/20 text-cyan-400'
                : 'bg-indigo-100 text-indigo-600'
              : isNeural
                ? 'hover:bg-gray-800 text-gray-300'
                : 'hover:bg-gray-100 text-gray-700'
          }`}
          style={{ paddingLeft }}
          onClick={() => {
            if (node.type === 'folder') {
              toggleFolder(node.id);
            } else {
              onTabSelect(node.id);
            }
          }}
        >
          {node.type === 'folder' ? (
            <>
              {isExpanded ? (
                <ChevronDownIcon className="w-3 h-3 mr-1" />
              ) : (
                <ChevronRightIcon className="w-3 h-3 mr-1" />
              )}
              <FolderIcon
                className={`w-4 h-4 mr-2 ${isNeural ? 'text-amber-400' : 'text-amber-600'}`}
              />
            </>
          ) : (
            <>
              <span className="w-3 mr-1" />
              <DocumentIcon
                className={`w-4 h-4 mr-2 ${isNeural ? 'text-gray-400' : 'text-gray-500'}`}
              />
            </>
          )}
          <span className="text-sm truncate">{node.name}</span>
        </div>
        {node.type === 'folder' && isExpanded && node.children && (
          <div>{node.children.map(child => renderNode(child, depth + 1))}</div>
        )}
      </div>
    );
  };

  if (!isOpen) return null;

  return (
    <div
      className={`absolute left-14 top-0 bottom-0 w-64 ${bgPrimary} border-r ${borderColor} z-10 flex flex-col shadow-xl`}
    >
      {/* Header */}
      <div className={`flex items-center justify-between px-3 py-2 border-b ${borderColor}`}>
        <span className={`text-sm font-medium ${textPrimary}`}>Files</span>
        <CanvasButton
          variant="icon"
          size="sm"
          isNeural={isNeural}
          onClick={onNewTab}
          title="New file"
        >
          <PlusIcon className="w-4 h-4" />
        </CanvasButton>
      </div>

      {/* File tree */}
      <div className="flex-1 overflow-y-auto p-2">{renderNode(fileStructure)}</div>

      {/* Footer */}
      <div className={`px-3 py-2 border-t ${borderColor}`}>
        <span className={`text-xs ${textSecondary}`}>{tabs.length} file(s)</span>
      </div>
    </div>
  );
}
