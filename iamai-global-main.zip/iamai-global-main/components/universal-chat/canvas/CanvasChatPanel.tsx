import {
  ArrowDownTrayIcon,
  ArrowsPointingOutIcon,
  ChevronLeftIcon,
  ChevronRightIcon,
  ClockIcon,
  CodeBracketIcon,
  Cog6ToothIcon,
  DocumentDuplicateIcon,
  EyeIcon,
  FolderIcon,
  SparklesIcon,
} from '@heroicons/react/24/outline';
import { RefObject } from 'react';
import CanvasButton from './CanvasButton';
import CanvasChatMessage from './CanvasChatMessage';
import CanvasChatInput from './CanvasChatInput';
import { CanvasTheme, ChatMessage, FileTab, ViewMode } from './types';

interface CanvasChatPanelProps {
  messages: ChatMessage[];
  chatInput: string;
  isGenerating: boolean;
  isChatCollapsed: boolean;
  onToggleCollapse: () => void;
  onChatInputChange: (value: string) => void;
  onSend: () => void;
  activeView: ViewMode;
  onViewChange: (view: ViewMode) => void;
  onCopy: () => void;
  onDownload: () => void;
  theme: CanvasTheme;
  textAreaRef?: RefObject<HTMLTextAreaElement>;
  activeTab?: FileTab;
  // New panel controls
  onToggleFilesPanel?: () => void;
  onToggleHistoryPanel?: () => void;
  onToggleSettingsPanel?: () => void;
  isFilesPanelOpen?: boolean;
  isHistoryPanelOpen?: boolean;
  isSettingsPanelOpen?: boolean;
}

export default function CanvasChatPanel({
  messages,
  chatInput,
  isGenerating,
  isChatCollapsed,
  onToggleCollapse,
  onChatInputChange,
  onSend,
  activeView,
  onViewChange,
  onCopy,
  onDownload,
  theme,
  textAreaRef,
  activeTab,
  onToggleFilesPanel,
  onToggleHistoryPanel,
  onToggleSettingsPanel,
  isFilesPanelOpen,
  isHistoryPanelOpen,
  isSettingsPanelOpen,
}: CanvasChatPanelProps) {
  const { isNeural, bgPrimary, borderColor, textPrimary, textSecondary } = theme;

  // Sidebar icons for collapsed state
  const sidebarActions = [
    { key: 'code' as ViewMode, icon: <CodeBracketIcon className="w-5 h-5" />, title: 'Code View' },
    {
      key: 'split' as ViewMode,
      icon: <ArrowsPointingOutIcon className="w-5 h-5" />,
      title: 'Split View',
    },
    { key: 'preview' as ViewMode, icon: <EyeIcon className="w-5 h-5" />, title: 'Preview' },
    {
      key: 'copy' as const,
      icon: <DocumentDuplicateIcon className="w-5 h-5" />,
      title: 'Copy Code',
    },
  ];

  return (
    <div
      className={`flex flex-col border-r ${borderColor} transition-all duration-300 ${
        isChatCollapsed ? 'w-14' : 'w-80'
      } ${bgPrimary}`}
    >
      <div className={`flex items-center justify-between px-3 py-2 border-b ${borderColor}`}>
        {!isChatCollapsed && (
          <div className="flex items-center space-x-2">
            <SparklesIcon className={`w-5 h-5 ${isNeural ? 'text-cyan-400' : 'text-indigo-500'}`} />
            <span className={`font-medium ${textPrimary}`}>AI Assistant</span>
          </div>
        )}
        <CanvasButton
          variant="icon"
          size="sm"
          isNeural={isNeural}
          onClick={onToggleCollapse}
          title={isChatCollapsed ? 'Open chat' : 'Collapse chat'}
        >
          {isChatCollapsed ? (
            <ChevronRightIcon className="w-4 h-4" />
          ) : (
            <ChevronLeftIcon className="w-4 h-4" />
          )}
        </CanvasButton>
      </div>

      {!isChatCollapsed && (
        <div className={`px-3 py-2 border-b ${borderColor} flex items-center gap-2 flex-wrap`}>
          <span className={`text-xs ${textSecondary}`}>Editor actions</span>
          <div
            className={`flex items-center rounded-lg ${isNeural ? 'bg-gray-800' : 'bg-gray-200'} p-0.5`}
          >
            <CanvasButton
              variant="ghost"
              size="sm"
              isNeural={isNeural}
              isActive={activeView === 'code'}
              onClick={() => onViewChange('code')}
              title="Code View"
            >
              <CodeBracketIcon className="w-4 h-4" />
            </CanvasButton>
            <CanvasButton
              variant="ghost"
              size="sm"
              isNeural={isNeural}
              isActive={activeView === 'split'}
              onClick={() => onViewChange('split')}
              title="Split View"
            >
              <ArrowsPointingOutIcon className="w-4 h-4" />
            </CanvasButton>
            <CanvasButton
              variant="ghost"
              size="sm"
              isNeural={isNeural}
              isActive={activeView === 'preview'}
              onClick={() => onViewChange('preview')}
              title="Preview"
            >
              <EyeIcon className="w-4 h-4" />
            </CanvasButton>
          </div>

          <CanvasButton variant="icon" size="sm" isNeural={isNeural} onClick={onCopy} title="Copy">
            <DocumentDuplicateIcon className="w-4 h-4" />
          </CanvasButton>
          <CanvasButton
            variant="icon"
            size="sm"
            isNeural={isNeural}
            onClick={onDownload}
            title="Download"
          >
            <ArrowDownTrayIcon className="w-4 h-4" />
          </CanvasButton>
        </div>
      )}

      {!isChatCollapsed ? (
        <>
          <div className="flex-1 overflow-y-auto p-3 space-y-3">
            {messages.map(msg => (
              <CanvasChatMessage key={msg.id} message={msg} theme={theme} />
            ))}
            {isGenerating && (
              <div className="flex justify-start">
                <div
                  className={`rounded-2xl px-4 py-2.5 ${isNeural ? 'bg-gray-800' : 'bg-gray-200'}`}
                >
                  <div className="flex space-x-1">
                    <div
                      className={`w-2 h-2 rounded-full ${isNeural ? 'bg-cyan-400' : 'bg-indigo-400'} animate-bounce`}
                      style={{ animationDelay: '0ms' }}
                    />
                    <div
                      className={`w-2 h-2 rounded-full ${isNeural ? 'bg-cyan-400' : 'bg-indigo-400'} animate-bounce`}
                      style={{ animationDelay: '150ms' }}
                    />
                    <div
                      className={`w-2 h-2 rounded-full ${isNeural ? 'bg-cyan-400' : 'bg-indigo-400'} animate-bounce`}
                      style={{ animationDelay: '300ms' }}
                    />
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className={`p-3 border-t ${borderColor}`}>
            <CanvasChatInput
              value={chatInput}
              onChange={onChatInputChange}
              onSend={onSend}
              isGenerating={isGenerating}
              theme={theme}
              textAreaRef={textAreaRef}
            />
          </div>
        </>
      ) : (
        <div className="flex-1 flex flex-col items-center py-4 space-y-2">
          {/* Toggle collapse button */}
          <CanvasButton
            variant="icon"
            size="sm"
            isNeural={isNeural}
            onClick={onToggleCollapse}
            title="Open chat"
            className="mb-2"
          >
            <SparklesIcon className={`w-5 h-5 ${isNeural ? 'text-cyan-400' : 'text-indigo-500'}`} />
          </CanvasButton>

          {/* Files panel toggle */}
          <CanvasButton
            variant="icon"
            size="sm"
            isNeural={isNeural}
            onClick={onToggleFilesPanel}
            title="Files"
            isActive={isFilesPanelOpen}
            className={
              isFilesPanelOpen
                ? isNeural
                  ? 'bg-cyan-500/20 text-cyan-400'
                  : 'bg-indigo-100 text-indigo-600'
                : ''
            }
          >
            <FolderIcon
              className={`w-5 h-5 ${isFilesPanelOpen ? '' : isNeural ? 'text-amber-400' : 'text-amber-600'}`}
            />
          </CanvasButton>

          {/* Divider */}
          <div className={`w-6 h-px ${isNeural ? 'bg-gray-700' : 'bg-gray-300'} my-1`} />

          {/* View mode icons */}
          {sidebarActions.map(action => (
            <CanvasButton
              key={action.key}
              variant="icon"
              size="sm"
              isNeural={isNeural}
              isActive={action.key !== 'copy' && activeView === action.key}
              onClick={() => {
                if (action.key === 'copy') {
                  onCopy();
                } else {
                  onViewChange(action.key as ViewMode);
                }
              }}
              title={action.title}
              className={
                action.key !== 'copy' && activeView === action.key
                  ? isNeural
                    ? 'bg-cyan-500/20 text-cyan-400'
                    : 'bg-indigo-100 text-indigo-600'
                  : ''
              }
            >
              {action.icon}
            </CanvasButton>
          ))}

          {/* Download */}
          <CanvasButton
            variant="icon"
            size="sm"
            isNeural={isNeural}
            onClick={onDownload}
            title="Download"
          >
            <ArrowDownTrayIcon className="w-5 h-5" />
          </CanvasButton>

          {/* Divider */}
          <div className={`w-6 h-px ${isNeural ? 'bg-gray-700' : 'bg-gray-300'} my-1`} />

          {/* History */}
          <CanvasButton
            variant="icon"
            size="sm"
            isNeural={isNeural}
            onClick={onToggleHistoryPanel}
            title="History"
            isActive={isHistoryPanelOpen}
            className={
              isHistoryPanelOpen
                ? isNeural
                  ? 'bg-cyan-500/20 text-cyan-400'
                  : 'bg-indigo-100 text-indigo-600'
                : ''
            }
          >
            <ClockIcon className="w-5 h-5" />
          </CanvasButton>

          {/* Settings - at bottom */}
          <div className="flex-1" />
          <CanvasButton
            variant="icon"
            size="sm"
            isNeural={isNeural}
            onClick={onToggleSettingsPanel}
            title="Settings"
            isActive={isSettingsPanelOpen}
            className={
              isSettingsPanelOpen
                ? isNeural
                  ? 'bg-cyan-500/20 text-cyan-400'
                  : 'bg-indigo-100 text-indigo-600'
                : ''
            }
          >
            <Cog6ToothIcon className="w-5 h-5" />
          </CanvasButton>
        </div>
      )}
    </div>
  );
}
