# AI Canvas Workspace Architecture

## 1. Product Goals

- Give users a browser-based workspace where they describe changes in natural language and the AI edits code/assets on their behalf.
- Keep users inside one tab: explore files, inspect diffs, preview the running app, download bundles.
- Support multiple iterative requests per session without exposing raw filesystem access.

## 2. Frontend Requirements

### 2.1 Tech Stack

- Vite + React 18 + TypeScript, Tailwind for layout, Radix/Headless UI for accessible primitives.
- Monaco editor (via @monaco-editor/react) for file tabs; integrate language services (TS, JSON, CSS, MD).
- Zustand or Redux Toolkit for workspace state (tabs, selected file, pending AI ops, job status).
- WebSocket/SSE client for streaming AI responses and file diffs.

### 2.2 Core UI Regions

1. **Command Console**
   - Chat-style thread with user prompts, AI status updates, diff previews.
   - Quick action buttons ("Generate landing page", "Fix syntax", "Add API route").
   - Action confirmation controls (Accept/Reject changes, Apply partially, Revert).
2. **File Tree**
   - Lazy-loaded tree view (virtualized) with context menu actions (open, rename, duplicate, delete, restore).
   - Search-as-you-type filtering across filenames and content (delegate to backend index).
3. **Code & Asset Tabs**
   - Monaco tabs for text-based assets; embed specialized viewers for images, JSON, Markdown, env files.
   - Dirty state badges, keyboard shortcuts, diff view toggle.
4. **Live Preview Panel**
   - Iframe pointing to sandboxed runtime (per workspace container URL).
   - Options: desktop/mobile breakpoints, auto-refresh on build success, manual refresh, open in new tab.
5. **Status & History**
   - Job queue list (build, test, deploy) with logs.
   - Timeline of AI actions with ability to roll back to any snapshot.

### 2.3 Supporting Features

- Offline/slow network handling, optimistic UI for prompt submission.
- Session recovery (reopen last tabs, scroll positions, conversation state from backend snapshot).
- Accessibility: keyboard navigation, ARIA roles, color contrast compliance.
- Telemetry hooks (performance, error boundaries, feature usage) via analytics service.

## 3. Backend Requirements

### 3.1 Services Overview

1. **Gateway/API Layer (REST + WebSocket/SSE)**
   - Auth middleware (JWT cookie + PAT + OAuth) and workspace scoping.
   - Routes: `/workspaces`, `/files`, `/actions`, `/jobs`, `/preview`, `/snapshots`, `/billing`.
2. **AI Orchestrator Service**
   - Accepts user prompt + workspace context.
   - Plans operations (create/edit/delete files, run commands) using planner/executor loop.
   - Streams tokens + structured diffs back to client.
   - Supports tools: repo analyzer, test runner, doc search, image generator, template library.
3. **File Service**
   - Abstraction over storage (git-based or object storage) with versioning and locking.
   - Exposes diff endpoints, binary upload/download, tree queries, search index updates.
4. **Execution Sandbox**
   - Manages ephemeral containers/VMs per workspace.
   - APIs to run npm/yarn/pnpm commands, tests, or preview servers.
   - Streams stdout/stderr logs.
5. **Job & Notification Service**
   - Queue (Redis, RabbitMQ, SQS) for long-running builds, image renders, deployments.
   - Webhook/email/push notifications when jobs finish or fail.
6. **Billing/Usage Service**
   - Tracks prompt counts, compute minutes, storage; integrates with Stripe or Paddle.

### 3.2 Key Backend Flows

- **Prompt Flow**: Client POST `/actions/prompt` → orchestrator streams plan via SSE/WebSocket → orchestrator applies file ops through File Service → sandbox rebuild triggers preview refresh.
- **File CRUD**: Signed requests to file service; includes binary support and size/quota checks.
- **Preview Flow**: Sandbox exposes HTTP port; reverse proxy (Traefik/Nginx) maps to `/preview/:workspaceId` with auth guard.
- **Snapshot Flow**: POST `/snapshots` to tag current tree; diff snapshots for history/rollback.

### 3.3 Security & Isolation

- Each workspace executes in isolated container namespace; seccomp/SELinux profiles.
- Secrets injected via vault at runtime; never exposed to LLM context by default.
- AI tool calls audited/logged; rate limits per user.
- Input validation and content filtering before executing shell commands.

## 4. Data & Storage

| Concern            | Solution                                                                  |
| ------------------ | ------------------------------------------------------------------------- |
| Workspace metadata | Postgres (workspaces, members, roles, billing state).                     |
| Files & versions   | Git-backed storage or object storage (S3/GCS) + metadata DB.              |
| Snapshots/history  | Append-only table referencing blob hashes; enables rollback.              |
| Conversations      | Postgres table storing prompts, responses, tool calls, token usage.       |
| Job queue          | Redis Streams / RabbitMQ with idempotent job handlers.                    |
| Logs & metrics     | Loki/ELK for logs, Prometheus/Grafana for metrics, OpenTelemetry tracing. |

## 5. DevOps & Tooling

- CI/CD: lint/test/build containers, deploy orchestrator + API + sandbox operator.
- Infrastructure-as-Code (Terraform/Pulumi) to provision k8s cluster, databases, storage, secrets.
- Observability: tracing for AI actions, sandbox metrics, file-service latency.
- Feature flag system (LaunchDarkly or custom) to roll out new tools gradually.

## 6. Implementation Milestones

1. **MVP**
   - Core UI shell with file tree + tabs + console + preview.
   - Backend with auth, workspace CRUD, file storage, orchestrator stub, simple sandbox (VM per workspace) using single-model LLM.
2. **Production Hardening**
   - Streaming responses, diff review, optimistic locking, granular permissions, rate limiting.
   - Persistent preview environments, template gallery, asset upload pipeline.
3. **Enterprise Features**
   - Team collaboration (multi-user editing, presence indicators), audit exports, SOC2 controls.
   - Custom models, on-prem connectors, SSO/SCIM.

## 7. Open Questions

- Will workspaces be seeded from templates or blank repos?
- What languages/frameworks must the sandbox support initially?
- Do users need GitHub/GitLab sync, or is this walled-garden storage?
- How will deployments be handled (export zip, push to repo, deploy to hosting provider)?

Use this document as the single source of truth while we scope tasks for backend, frontend, and infrastructure teams.
