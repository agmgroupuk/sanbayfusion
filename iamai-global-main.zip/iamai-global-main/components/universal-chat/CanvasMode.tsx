'use client';

import { useState, useRef, useEffect } from 'react';
import type { OnMount } from '@monaco-editor/react';
import type { editor } from 'monaco-editor';
import CanvasChatPanel from './canvas/CanvasChatPanel';
import CanvasEditor from './canvas/CanvasEditor';
import CanvasPreview from './canvas/CanvasPreview';
import CanvasHeader from './canvas/CanvasHeader';
import CanvasFilesPanel from './canvas/CanvasFilesPanel';
import CanvasHistoryPanel from './canvas/CanvasHistoryPanel';
import CanvasSettingsPanel from './canvas/CanvasSettingsPanel';
import { ChatMessage, FileTab, ViewMode, createCanvasTheme } from './canvas/types';
import realtimeChatService from './realtimeChatService';

interface CanvasSettings {
  provider: string;
  model: string;
  temperature: number;
  maxTokens: number;
  systemPrompt: string;
}

interface CanvasModeProps {
  isOpen: boolean;
  onClose: () => void;
  theme?: 'default' | 'neural';
  initialCode?: string;
  initialLanguage?: string;
  initialFilename?: string;
}

export default function CanvasMode({
  isOpen,
  onClose,
  theme = 'neural',
  initialCode = '// Start coding or ask AI to help\n\nfunction hello() {\n  console.log("Hello from AI Canvas!");\n}\n\nhello();',
  initialLanguage = 'javascript',
  initialFilename = 'main.js',
}: CanvasModeProps) {
  const themeConfig = createCanvasTheme(theme);
  const monacoEditorRef = useRef<editor.IStandaloneCodeEditor | null>(null);
  const chatInputRef = useRef<HTMLTextAreaElement>(null);
  const previewRef = useRef<HTMLIFrameElement>(null);

  // State
  const [activeView, setActiveView] = useState<ViewMode>('code');
  const [isChatCollapsed, setIsChatCollapsed] = useState(true);
  const [chatInput, setChatInput] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      role: 'assistant',
      content:
        'Welcome to Canvas! I can help you write, edit, and improve code. What would you like to create?',
      timestamp: new Date(),
    },
  ]);

  // Panel states
  const [isFilesPanelOpen, setIsFilesPanelOpen] = useState(false);
  const [isHistoryPanelOpen, setIsHistoryPanelOpen] = useState(false);
  const [isSettingsPanelOpen, setIsSettingsPanelOpen] = useState(false);

  // Settings state
  const [settings, setSettings] = useState<CanvasSettings>({
    provider: 'mistral',
    model: 'mistral-large-latest',
    temperature: 0.7,
    maxTokens: 4000,
    systemPrompt: '',
  });

  const [tabs, setTabs] = useState<FileTab[]>([
    {
      id: '1',
      name: initialFilename,
      language: initialLanguage,
      content: initialCode,
      isModified: false,
    },
  ]);
  const [activeTabId, setActiveTabId] = useState('1');
  const [lineCount, setLineCount] = useState(0);

  const activeTab = tabs.find(t => t.id === activeTabId);

  // Monaco editor mount handler
  const handleEditorDidMount: OnMount = (editor, _monaco) => {
    monacoEditorRef.current = editor;

    // Configure editor settings
    editor.updateOptions({
      minimap: { enabled: true },
      fontSize: 14,
      lineNumbers: 'on',
      roundedSelection: true,
      scrollBeyondLastLine: false,
      automaticLayout: true,
      tabSize: 2,
      wordWrap: 'on',
      bracketPairColorization: { enabled: true },
      cursorBlinking: 'smooth',
      cursorSmoothCaretAnimation: 'on',
      smoothScrolling: true,
    });
  };

  // Handle Monaco editor content changes
  const handleEditorChange = (value: string | undefined) => {
    if (value !== undefined) {
      setTabs(prev =>
        prev.map(t => (t.id === activeTabId ? { ...t, content: value, isModified: true } : t))
      );
    }
  };

  // Update line numbers when content changes (for status bar)
  useEffect(() => {
    if (activeTab) {
      const lines = activeTab.content.split('\n').length;
      setLineCount(Math.max(lines, 1));
    }
  }, [activeTab?.content]);

  const monacoTheme = themeConfig.isNeural ? 'vs-dark' : 'vs-dark';

  const handleSendMessage = async (input?: string) => {
    const content = (input ?? chatInput).trim();
    if (!content || isGenerating) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setChatInput('');
    setIsGenerating(true);

    // Create assistant message placeholder for streaming
    const assistantMessageId = (Date.now() + 1).toString();
    const assistantMessage: ChatMessage = {
      id: assistantMessageId,
      role: 'assistant',
      content: '',
      timestamp: new Date(),
    };
    setMessages(prev => [...prev, assistantMessage]);

    // Build context with current code
    const codeContext = activeTab
      ? `\n\nCurrent file: ${activeTab.name}\n\`\`\`${activeTab.language}\n${activeTab.content}\n\`\`\``
      : '';

    const systemPrompt = `You are an expert coding assistant in a Canvas code editor. Help users write, debug, and improve code.
When providing code, always include the full code block with the language specified.
If asked to create or modify code, provide the complete updated code.
Be concise and focus on the code solution.${codeContext}`;

    // Convert messages to service format
    const conversationHistory = messages.map(m => ({
      id: m.id,
      role: m.role as 'user' | 'assistant',
      content: m.content,
      timestamp: m.timestamp,
    }));

    try {
      await realtimeChatService.sendMessageStream(
        content,
        conversationHistory,
        {
          id: 'canvas-assistant',
          name: 'Canvas AI',
          systemPrompt,
          model: 'mistral-large-latest',
          temperature: 0.7,
          maxTokens: 4000,
          provider: 'mistral',
        },
        {
          onToken: token => {
            setMessages(prev =>
              prev.map(m =>
                m.id === assistantMessageId ? { ...m, content: m.content + token } : m
              )
            );
          },
          onComplete: fullMessage => {
            setMessages(prev =>
              prev.map(m => (m.id === assistantMessageId ? { ...m, content: fullMessage } : m))
            );
            setIsGenerating(false);

            // Auto-extract and apply code if present
            const codeMatch = fullMessage.match(/```(\w+)?\n([\s\S]*?)```/);
            if (codeMatch && activeTab) {
              const [, lang, code] = codeMatch;
              // Offer to apply the code
              const shouldApply = confirm('AI generated code detected. Apply to editor?');
              if (shouldApply) {
                setTabs(prev =>
                  prev.map(t =>
                    t.id === activeTabId
                      ? {
                          ...t,
                          content: code.trim(),
                          isModified: true,
                          language: lang || t.language,
                        }
                      : t
                  )
                );
              }
            }
          },
          onError: error => {
            console.error('Canvas AI error:', error);
            setMessages(prev =>
              prev.map(m =>
                m.id === assistantMessageId
                  ? { ...m, content: `❌ Error: ${error.message}. Please try again.` }
                  : m
              )
            );
            setIsGenerating(false);
          },
          onCodeBlock: _codeBlock => {
            // Code block detected - could add handling here
          },
        }
      );
    } catch (error) {
      console.error('Canvas chat error:', error);
      setIsGenerating(false);
    }
  };

  const addNewTab = () => {
    const newTab: FileTab = {
      id: Date.now().toString(),
      name: 'untitled.js',
      language: 'javascript',
      content: '// New file\n',
      isModified: false,
    };
    setTabs(prev => [...prev, newTab]);
    setActiveTabId(newTab.id);
  };

  const copyCode = () => {
    if (activeTab) {
      navigator.clipboard.writeText(activeTab.content);
    }
  };

  const downloadCode = () => {
    if (activeTab) {
      const blob = new Blob([activeTab.content], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = activeTab.name;
      a.click();
      URL.revokeObjectURL(url);
    }
  };

  // Toggle panel functions (close others when opening one)
  const toggleFilesPanel = () => {
    setIsFilesPanelOpen(prev => !prev);
    setIsHistoryPanelOpen(false);
    setIsSettingsPanelOpen(false);
  };

  const toggleHistoryPanel = () => {
    setIsHistoryPanelOpen(prev => !prev);
    setIsFilesPanelOpen(false);
    setIsSettingsPanelOpen(false);
  };

  const toggleSettingsPanel = () => {
    setIsSettingsPanelOpen(prev => !prev);
    setIsFilesPanelOpen(false);
    setIsHistoryPanelOpen(false);
  };

  // Share/open in external browser
  const shareCode = () => {
    if (activeTab) {
      // Create a blob URL and open in new tab
      const blob = new Blob([activeTab.content], { type: 'text/html' });
      const url = URL.createObjectURL(blob);
      window.open(url, '_blank');
    }
  };

  // Delete current chat/session
  const deleteSession = () => {
    if (confirm('Are you sure you want to delete this session?')) {
      setMessages([
        {
          id: '1',
          role: 'assistant',
          content:
            'Welcome to Canvas! I can help you write, edit, and improve code. What would you like to create?',
          timestamp: new Date(),
        },
      ]);
      setTabs([
        {
          id: '1',
          name: initialFilename,
          language: initialLanguage,
          content: initialCode,
          isModified: false,
        },
      ]);
      setActiveTabId('1');
    }
  };

  if (!isOpen) return null;

  return (
    <div
      className={`fixed inset-0 z-50 flex ${themeConfig.isNeural ? 'bg-gray-950' : 'bg-gray-100'}`}
    >
      {/* Left sidebar with chat panel */}
      <div className="relative">
        <CanvasChatPanel
          messages={messages}
          chatInput={chatInput}
          isGenerating={isGenerating}
          isChatCollapsed={isChatCollapsed}
          onToggleCollapse={() => setIsChatCollapsed(!isChatCollapsed)}
          onChatInputChange={setChatInput}
          onSend={handleSendMessage}
          activeView={activeView}
          onViewChange={setActiveView}
          onCopy={copyCode}
          onDownload={downloadCode}
          theme={themeConfig}
          textAreaRef={chatInputRef}
          activeTab={activeTab}
          onToggleFilesPanel={toggleFilesPanel}
          onToggleHistoryPanel={toggleHistoryPanel}
          onToggleSettingsPanel={toggleSettingsPanel}
          isFilesPanelOpen={isFilesPanelOpen}
          isHistoryPanelOpen={isHistoryPanelOpen}
          isSettingsPanelOpen={isSettingsPanelOpen}
        />

        {/* Slide-out panels */}
        <CanvasFilesPanel
          isOpen={isFilesPanelOpen}
          onClose={() => setIsFilesPanelOpen(false)}
          tabs={tabs}
          activeTabId={activeTabId}
          onTabSelect={setActiveTabId}
          onNewTab={addNewTab}
          theme={themeConfig}
        />

        <CanvasHistoryPanel
          isOpen={isHistoryPanelOpen}
          onClose={() => setIsHistoryPanelOpen(false)}
          theme={themeConfig}
          currentMessages={messages}
        />

        <CanvasSettingsPanel
          isOpen={isSettingsPanelOpen}
          onClose={() => setIsSettingsPanelOpen(false)}
          theme={themeConfig}
          settings={settings}
          onSettingsChange={setSettings}
        />
      </div>

      {/* Main content area */}
      <div className="flex-1 flex flex-col">
        {/* New header with close, copy, share, delete */}
        <CanvasHeader
          theme={themeConfig}
          onClose={onClose}
          onCopy={copyCode}
          onShare={shareCode}
          onDelete={deleteSession}
        />

        <div className="flex-1 flex overflow-hidden">
          {(activeView === 'code' || activeView === 'split') && (
            <div
              className={`${activeView === 'split' ? 'w-1/2' : 'flex-1'} flex flex-col ${themeConfig.bgEditor}`}
            >
              <CanvasEditor
                activeTab={activeTab}
                theme={themeConfig}
                monacoTheme={monacoTheme}
                onChange={handleEditorChange}
                onMount={handleEditorDidMount}
              />
            </div>
          )}

          {activeView === 'split' && (
            <div
              className={`w-1 cursor-col-resize ${
                themeConfig.isNeural
                  ? 'bg-gray-700 hover:bg-cyan-500/50'
                  : 'bg-gray-300 hover:bg-indigo-400'
              } transition-colors`}
            />
          )}

          {(activeView === 'preview' || activeView === 'split') && (
            <div
              className={`${activeView === 'split' ? 'w-1/2' : 'flex-1'} flex flex-col ${themeConfig.bgPrimary}`}
            >
              <CanvasPreview iframeRef={previewRef} theme={themeConfig} />
            </div>
          )}
        </div>

        <div
          className={`flex items-center justify-between px-4 py-1 border-t ${themeConfig.borderColor} ${themeConfig.bgSecondary}`}
        >
          <div className="flex items-center space-x-4">
            <span className={`text-xs ${themeConfig.textSecondary}`}>
              {activeTab?.language.toUpperCase()}
            </span>
            <span className={`text-xs ${themeConfig.textSecondary}`}>Ln {lineCount}, Col 1</span>
          </div>
          <div className="flex items-center space-x-2">
            <span
              className={`w-2 h-2 rounded-full ${
                themeConfig.isNeural ? 'bg-cyan-400 animate-pulse' : 'bg-green-400'
              }`}
            />
            <span className={`text-xs ${themeConfig.textSecondary}`}>Canvas Ready</span>
          </div>
        </div>
      </div>
    </div>
  );
}
