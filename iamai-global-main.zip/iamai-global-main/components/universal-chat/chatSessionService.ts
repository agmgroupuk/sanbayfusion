/**
 * Chat Session Persistence Service
 * Connects frontend chat to backend MongoDB storage
 */

const API_URL = import.meta.env.VITE_API_URL || 'https://api.iamai.global';

export interface StoredMessage {
  messageId: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  attachments?: Array<{
    type: string;
    url: string;
    filename: string;
  }>;
  metadata?: {
    model?: string;
    provider?: string;
    tokensUsed?: number;
  };
}

export interface StoredSession {
  sessionId: string;
  userId: string;
  agentId: string;
  sessionInfo: {
    agentName: string;
    agentDisplayName: string;
    title: string;
    description?: string;
    isActive: boolean;
  };
  messages: StoredMessage[];
  sessionStats: {
    totalMessages: number;
    userMessages: number;
    assistantMessages: number;
    lastMessageAt?: Date;
  };
  createdAt: Date;
  updatedAt: Date;
}

export interface CreateSessionParams {
  agentId: string;
  agentName: string;
  agentDisplayName?: string;
  title?: string;
  description?: string;
}

class ChatSessionService {
  private authToken: string | null = null;

  /**
   * Use cookies for auth; ensure credentials are included on every request.
   */
  private fetchWithAuth(url: string, options: RequestInit = {}) {
    const mergedHeaders: HeadersInit = {
      ...this.getHeaders(),
      ...(options.headers || {}),
    };

    return fetch(url, {
      ...options,
      headers: mergedHeaders,
      credentials: 'include',
    });
  }

  /**
   * Set authentication token for API calls
   */
  setAuthToken(token: string) {
    this.authToken = token;
  }

  /**
   * Get auth headers
   */
  private getHeaders(): HeadersInit {
    const headers: HeadersInit = {
      'Content-Type': 'application/json',
    };
    if (this.authToken) {
      headers['Authorization'] = `Bearer ${this.authToken}`;
    }
    return headers;
  }

  /**
   * Fetch all sessions for a user
   */
  async getUserSessions(
    userId: string,
    options: {
      agentId?: string;
      limit?: number;
      offset?: number;
    } = {}
  ): Promise<{ sessions: StoredSession[]; total: number }> {
    try {
      const params = new URLSearchParams();
      if (options.agentId) params.append('agentId', options.agentId);
      if (options.limit) params.append('limit', options.limit.toString());
      if (options.offset) params.append('offset', options.offset.toString());

      const response = await this.fetchWithAuth(
        `${API_URL}/api/chat/sessions/user/${userId}?${params}`,
        {
          method: 'GET',
        }
      );

      if (!response.ok) {
        throw new Error('Failed to fetch sessions');
      }

      const data = await response.json();
      return {
        sessions: data.data?.sessions || [],
        total: data.data?.pagination?.total || 0,
      };
    } catch (error) {
      console.error('Error fetching user sessions:', error);
      // Return from localStorage as fallback
      return this.getLocalSessions(userId, options.agentId);
    }
  }

  /**
   * Get a specific session with all messages
   */
  async getSession(sessionId: string): Promise<StoredSession | null> {
    try {
      const response = await this.fetchWithAuth(`${API_URL}/api/chat/sessions/${sessionId}`, {
        method: 'GET',
      });

      if (!response.ok) {
        throw new Error('Session not found');
      }

      const data = await response.json();
      return data.data?.session || null;
    } catch (error) {
      console.error('Error fetching session:', error);
      return this.getLocalSession(sessionId);
    }
  }

  /**
   * Create a new chat session
   */
  async createSession(params: CreateSessionParams): Promise<StoredSession | null> {
    try {
      const response = await this.fetchWithAuth(`${API_URL}/api/chat/sessions/create`, {
        method: 'POST',
        body: JSON.stringify(params),
      });

      if (!response.ok) {
        throw new Error('Failed to create session');
      }

      const data = await response.json();
      const session = data.data;

      // Also save to localStorage as backup
      this.saveLocalSession(session);

      return session;
    } catch (error) {
      console.error('Error creating session:', error);
      // Create local session as fallback
      return this.createLocalSession(params);
    }
  }

  /**
   * Add a message to a session
   */
  async addMessage(
    sessionId: string,
    message: {
      content: string;
      role: 'user' | 'assistant';
      attachments?: Array<{ type: string; url: string; filename: string }>;
      metadata?: { model?: string; provider?: string; tokensUsed?: number };
    }
  ): Promise<StoredMessage | null> {
    try {
      const response = await this.fetchWithAuth(
        `${API_URL}/api/chat/sessions/${sessionId}/messages`,
        {
          method: 'POST',
          body: JSON.stringify(message),
        }
      );

      if (!response.ok) {
        throw new Error('Failed to add message');
      }

      const data = await response.json();
      const storedMessage = data.data?.message;

      // Also update localStorage
      this.addLocalMessage(sessionId, storedMessage);

      return storedMessage;
    } catch (error) {
      console.error('Error adding message:', error);
      // Save to localStorage as fallback
      return this.addLocalMessage(sessionId, {
        messageId: `msg_${Date.now()}`,
        ...message,
        timestamp: new Date(),
      });
    }
  }

  /**
   * React to a message (like/dislike)
   */
  async reactToMessage(
    messageId: string,
    sessionId: string,
    reactionType: 'like' | 'dislike',
    comment?: string
  ): Promise<boolean> {
    try {
      const response = await this.fetchWithAuth(
        `${API_URL}/api/chat/messages/${messageId}/reactions`,
        {
          method: 'POST',
          body: JSON.stringify({ reactionType, sessionId, comment }),
        }
      );

      if (!response.ok) {
        throw new Error('Failed to react to message');
      }

      return true;
    } catch (error) {
      console.error('Error reacting to message:', error);
      return false;
    }
  }

  /**
   * Update session info (rename, etc.)
   */
  async updateSession(
    sessionId: string,
    updates: { title?: string; description?: string; isActive?: boolean }
  ): Promise<boolean> {
    try {
      const response = await this.fetchWithAuth(`${API_URL}/api/chat/sessions/${sessionId}`, {
        method: 'PUT',
        body: JSON.stringify(updates),
      });

      if (!response.ok) {
        throw new Error('Failed to update session');
      }

      // Update localStorage too
      this.updateLocalSession(sessionId, updates);

      return true;
    } catch (error) {
      console.error('Error updating session:', error);
      return this.updateLocalSession(sessionId, updates);
    }
  }

  /**
   * Delete a session
   */
  async deleteSession(sessionId: string): Promise<boolean> {
    try {
      const response = await this.fetchWithAuth(`${API_URL}/api/chat/sessions/${sessionId}`, {
        method: 'DELETE',
      });

      if (!response.ok) {
        throw new Error('Failed to delete session');
      }

      // Remove from localStorage too
      this.deleteLocalSession(sessionId);

      return true;
    } catch (error) {
      console.error('Error deleting session:', error);
      return this.deleteLocalSession(sessionId);
    }
  }

  // ============================================
  // LOCAL STORAGE FALLBACK METHODS
  // ============================================

  private getStorageKey(userId: string): string {
    return `chat_sessions_${userId}`;
  }

  private getLocalSessions(
    userId: string,
    agentId?: string
  ): { sessions: StoredSession[]; total: number } {
    try {
      const stored = localStorage.getItem(this.getStorageKey(userId));
      if (!stored) return { sessions: [], total: 0 };

      let sessions: StoredSession[] = JSON.parse(stored);
      if (agentId) {
        sessions = sessions.filter(s => s.agentId === agentId);
      }

      return { sessions, total: sessions.length };
    } catch {
      return { sessions: [], total: 0 };
    }
  }

  private getLocalSession(sessionId: string): StoredSession | null {
    try {
      // Search through all user storage keys
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key?.startsWith('chat_sessions_')) {
          const sessions: StoredSession[] = JSON.parse(localStorage.getItem(key) || '[]');
          const session = sessions.find(s => s.sessionId === sessionId);
          if (session) return session;
        }
      }
      return null;
    } catch {
      return null;
    }
  }

  private saveLocalSession(session: StoredSession): void {
    try {
      const key = this.getStorageKey(session.userId);
      const stored = localStorage.getItem(key);
      const sessions: StoredSession[] = stored ? JSON.parse(stored) : [];

      const existingIndex = sessions.findIndex(s => s.sessionId === session.sessionId);
      if (existingIndex >= 0) {
        sessions[existingIndex] = session;
      } else {
        sessions.unshift(session);
      }

      localStorage.setItem(key, JSON.stringify(sessions));
    } catch (error) {
      console.error('Error saving to localStorage:', error);
    }
  }

  private createLocalSession(params: CreateSessionParams): StoredSession {
    const session: StoredSession = {
      sessionId: `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      userId: 'local-user',
      agentId: params.agentId,
      sessionInfo: {
        agentName: params.agentName,
        agentDisplayName: params.agentDisplayName || params.agentName,
        title: params.title || `Chat with ${params.agentDisplayName || params.agentName}`,
        description: params.description,
        isActive: true,
      },
      messages: [],
      sessionStats: {
        totalMessages: 0,
        userMessages: 0,
        assistantMessages: 0,
      },
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    this.saveLocalSession(session);
    return session;
  }

  private addLocalMessage(sessionId: string, message: StoredMessage): StoredMessage {
    try {
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key?.startsWith('chat_sessions_')) {
          const sessions: StoredSession[] = JSON.parse(localStorage.getItem(key) || '[]');
          const sessionIndex = sessions.findIndex(s => s.sessionId === sessionId);

          if (sessionIndex >= 0) {
            sessions[sessionIndex].messages.push(message);
            sessions[sessionIndex].sessionStats.totalMessages++;
            sessions[sessionIndex].sessionStats[
              message.role === 'user' ? 'userMessages' : 'assistantMessages'
            ]++;
            sessions[sessionIndex].sessionStats.lastMessageAt = new Date();
            sessions[sessionIndex].updatedAt = new Date();

            localStorage.setItem(key, JSON.stringify(sessions));
            break;
          }
        }
      }
    } catch (error) {
      console.error('Error adding local message:', error);
    }
    return message;
  }

  private updateLocalSession(
    sessionId: string,
    updates: { title?: string; description?: string; isActive?: boolean }
  ): boolean {
    try {
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key?.startsWith('chat_sessions_')) {
          const sessions: StoredSession[] = JSON.parse(localStorage.getItem(key) || '[]');
          const sessionIndex = sessions.findIndex(s => s.sessionId === sessionId);

          if (sessionIndex >= 0) {
            if (updates.title !== undefined) {
              sessions[sessionIndex].sessionInfo.title = updates.title;
            }
            if (updates.description !== undefined) {
              sessions[sessionIndex].sessionInfo.description = updates.description;
            }
            if (updates.isActive !== undefined) {
              sessions[sessionIndex].sessionInfo.isActive = updates.isActive;
            }
            sessions[sessionIndex].updatedAt = new Date();

            localStorage.setItem(key, JSON.stringify(sessions));
            return true;
          }
        }
      }
      return false;
    } catch {
      return false;
    }
  }

  private deleteLocalSession(sessionId: string): boolean {
    try {
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key?.startsWith('chat_sessions_')) {
          const sessions: StoredSession[] = JSON.parse(localStorage.getItem(key) || '[]');
          const filtered = sessions.filter(s => s.sessionId !== sessionId);

          if (filtered.length !== sessions.length) {
            localStorage.setItem(key, JSON.stringify(filtered));
            return true;
          }
        }
      }
      return false;
    } catch {
      return false;
    }
  }
}

// Export singleton instance
const chatSessionService = new ChatSessionService();
export default chatSessionService;
