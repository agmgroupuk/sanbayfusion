'use client';

import { useState, useCallback, useRef, useEffect } from 'react';
import {
  PaperAirplaneIcon,
  MicrophoneIcon,
  PaperClipIcon,
  PhoneIcon,
  XMarkIcon,
  DocumentIcon,
} from '@heroicons/react/24/solid';

// Web Speech API types
interface SpeechRecognitionEvent extends Event {
  results: SpeechRecognitionResultList;
  resultIndex: number;
}

interface SpeechRecognitionResultList {
  length: number;
  item(index: number): SpeechRecognitionResult;
  [index: number]: SpeechRecognitionResult;
}

interface SpeechRecognitionResult {
  isFinal: boolean;
  length: number;
  item(index: number): SpeechRecognitionAlternative;
  [index: number]: SpeechRecognitionAlternative;
}

interface SpeechRecognitionAlternative {
  transcript: string;
  confidence: number;
}

interface SpeechRecognition extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  onresult: ((event: SpeechRecognitionEvent) => void) | null;
  onerror: ((event: Event) => void) | null;
  onend: (() => void) | null;
  start(): void;
  stop(): void;
  abort(): void;
}

declare global {
  interface Window {
    SpeechRecognition: new () => SpeechRecognition;
    webkitSpeechRecognition: new () => SpeechRecognition;
  }
}

// Uploaded file interface
interface UploadedFile {
  id: string;
  name: string;
  url: string;
  type: string;
  size: number;
}
import {
  HandThumbUpIcon,
  HandThumbDownIcon,
  ClipboardDocumentIcon,
  ShareIcon,
  SpeakerWaveIcon,
} from '@heroicons/react/24/outline';
import { useAuth } from '../../contexts/AuthContext';
import { authService } from '../../services/authService';
import EnhancedChatLayout from './EnhancedChatLayout';
import { AgentSettings } from './ChatSettingsPanel';
import QuickActionsPanel from './QuickActionsPanel';
import realtimeChatService, {
  ChatMessage as ServiceChatMessage,
  AgentConfig,
  CodeBlock,
} from './realtimeChatService';
import chatSessionService from './chatSessionService';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  isStreaming?: boolean;
  codeBlocks?: CodeBlock[];
}

interface ChatSession {
  id: string;
  name: string;
  messages: Message[];
  lastMessage?: string;
  messageCount?: number;
  updatedAt?: Date;
}

export interface AgentChatConfig {
  id: string;
  name: string;
  icon: string;
  description?: string;
  systemPrompt: string;
  welcomeMessage: string;
  specialties?: string[];
  color?: string;
}

interface UniversalAgentChatProps {
  agent: AgentChatConfig;
}

export default function UniversalAgentChat({ agent }: UniversalAgentChatProps) {
  const { user, isAuthenticated } = useAuth();
  const userId = user?.id || authService.getUserId() || 'guest';

  // Sessions state
  const [sessions, setSessions] = useState<ChatSession[]>([
    {
      id: 'session-1',
      name: 'Welcome Conversation',
      messages: [
        {
          id: 'msg-1',
          role: 'assistant',
          content: agent.welcomeMessage,
          timestamp: new Date(),
        },
      ],
      lastMessage: `Chat with ${agent.name}`,
      messageCount: 1,
      updatedAt: new Date(),
    },
  ]);

  const [activeSessionId, setActiveSessionId] = useState<string>('session-1');
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isQuickActionsCollapsed, setIsQuickActionsCollapsed] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [messageFeedback, setMessageFeedback] = useState<Record<string, 'up' | 'down' | null>>({});
  const [copiedMessageId, setCopiedMessageId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const recognitionRef = useRef<SpeechRecognition | null>(null);

  // File upload state
  const [uploadedFile, setUploadedFile] = useState<UploadedFile | null>(null);
  const [isUploading, setIsUploading] = useState(false);

  // Settings state
  const [settings, setSettings] = useState<AgentSettings>({
    temperature: 0.7,
    maxTokens: 2000,
    mode: 'balanced',
    systemPrompt: '',
    provider: 'mistral',
    model: 'mistral-large-latest',
  });

  const activeSession = sessions.find(s => s.id === activeSessionId);

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [activeSession?.messages]);

  // 📦 Load sessions from storage on mount
  useEffect(() => {
    const loadSessions = async () => {
      try {
        const targetUserId = userId || 'guest';
        const { sessions: storedSessions } = await chatSessionService.getUserSessions(
          targetUserId,
          {
            agentId: agent.id,
            limit: 50,
          }
        );

        if (storedSessions.length > 0) {
          const convertedSessions: ChatSession[] = storedSessions.map(s => ({
            id: s.sessionId,
            name: s.sessionInfo.title,
            messages: s.messages.map(m => ({
              id: m.messageId,
              role: m.role,
              content: m.content,
              timestamp: new Date(m.timestamp),
            })),
            lastMessage: s.messages[s.messages.length - 1]?.content?.slice(0, 50) || '',
            messageCount: s.messages.length,
            updatedAt: new Date(s.updatedAt),
          }));

          setSessions(convertedSessions);
          setActiveSessionId(convertedSessions[0].id);
          return;
        }

        // No stored sessions: create a fresh one (backend if authenticated, local otherwise)
        const created = await chatSessionService.createSession({
          agentId: agent.id,
          agentName: agent.name,
          agentDisplayName: agent.name,
          title: `Chat with ${agent.name}`,
        });

        const fallbackSession: ChatSession = {
          id: created?.sessionId || `session-${Date.now()}`,
          name: created?.sessionInfo?.title || `Chat with ${agent.name}`,
          messages: [
            {
              id: `msg-${Date.now()}`,
              role: 'assistant',
              content: agent.welcomeMessage,
              timestamp: new Date(),
            },
          ],
          lastMessage: agent.welcomeMessage,
          messageCount: 1,
          updatedAt: new Date(),
        };

        setSessions([fallbackSession]);
        setActiveSessionId(fallbackSession.id);
      } catch (error) {
        console.error('Error loading sessions:', error);
      }
    };

    loadSessions();
  }, [agent.id, userId]);

  // 💾 Save session when messages change
  useEffect(() => {
    const saveCurrentSession = async () => {
      if (!activeSession || activeSession.messages.length <= 1) return;

      const lastMessage = activeSession.messages[activeSession.messages.length - 1];
      if (lastMessage.isStreaming) return; // Don't save while streaming

      try {
        // Save the last message to backend
        const saved = await chatSessionService.addMessage(activeSession.id, {
          content: lastMessage.content,
          role: lastMessage.role,
        });

        // Align local message with server-generated id/timestamp for downstream actions
        if (saved?.messageId && lastMessage.id !== saved.messageId) {
          setSessions(prev =>
            prev.map(s =>
              s.id === activeSession.id
                ? {
                    ...s,
                    messages: s.messages.map((m, idx) =>
                      idx === s.messages.length - 1
                        ? {
                            ...m,
                            id: saved.messageId,
                            timestamp: saved.timestamp ? new Date(saved.timestamp) : m.timestamp,
                          }
                        : m
                    ),
                  }
                : s
            )
          );
        }
      } catch (error) {
        console.error('Error saving message:', error);
      }
    };

    // Debounce save
    const timeout = setTimeout(saveCurrentSession, 1000);
    return () => clearTimeout(timeout);
  }, [activeSession?.messages]);

  // Handlers
  const handleNewSession = useCallback(async () => {
    const newId = `session-${Date.now()}`;
    const welcomeContent = `🚀 **New conversation started!**\n\nI'm ${agent.name}, ready to assist you. What would you like to explore today?\n\n---\n*Connected to AI • Settings available in ⚙️ panel*`;

    const newSession: ChatSession = {
      id: newId,
      name: `Conversation ${sessions.length + 1}`,
      messages: [
        {
          id: `msg-${Date.now()}`,
          role: 'assistant',
          content: welcomeContent,
          timestamp: new Date(),
        },
      ],
      lastMessage: 'New conversation started',
      messageCount: 1,
      updatedAt: new Date(),
    };

    setSessions(prev => [newSession, ...prev]);
    setActiveSessionId(newId);

    // Create session in backend
    try {
      const storedSession = await chatSessionService.createSession({
        agentId: agent.id,
        agentName: agent.name,
        agentDisplayName: agent.name,
        title: newSession.name,
      });

      if (storedSession) {
        // Update local session with backend ID
        setSessions(prev =>
          prev.map(s => (s.id === newId ? { ...s, id: storedSession.sessionId } : s))
        );
        setActiveSessionId(storedSession.sessionId);

        // Add welcome message to backend
        await chatSessionService.addMessage(storedSession.sessionId, {
          content: welcomeContent,
          role: 'assistant',
        });
      }
    } catch (error) {
      console.error('Error creating session in backend:', error);
    }
  }, [sessions.length, agent.id, agent.name]);

  const handleSelectSession = useCallback((id: string) => {
    setActiveSessionId(id);
  }, []);

  const handleDeleteSession = useCallback(
    async (id: string) => {
      setSessions(prev => {
        const filtered = prev.filter(s => s.id !== id);
        if (activeSessionId === id && filtered.length > 0) {
          setActiveSessionId(filtered[0].id);
        }
        return filtered;
      });

      // Delete from backend
      try {
        await chatSessionService.deleteSession(id);
      } catch (error) {
        console.error('Error deleting session from backend:', error);
      }
    },
    [activeSessionId]
  );

  const handleRenameSession = useCallback(async (id: string, newName: string) => {
    setSessions(prev => prev.map(s => (s.id === id ? { ...s, name: newName } : s)));

    // Update in backend
    try {
      await chatSessionService.updateSession(id, { title: newName });
    } catch (error) {
      console.error('Error renaming session in backend:', error);
    }
  }, []);

  const handleExportSession = useCallback(
    (id: string) => {
      const session = sessions.find(s => s.id === id);
      if (!session) return;

      let exportText = `Chat Session: ${session.name}\n`;
      exportText += `Agent: ${agent.name}\n`;
      exportText += `Exported: ${new Date().toLocaleString()}\n\n`;
      exportText += '='.repeat(60) + '\n\n';

      session.messages.forEach(msg => {
        const role = msg.role === 'user' ? 'You' : agent.name;
        exportText += `[${msg.timestamp.toLocaleString()}] ${role}:\n`;
        exportText += `${msg.content}\n\n`;
      });

      const blob = new Blob([exportText], { type: 'text/plain;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${agent.name.replace(
        /[^a-z0-9]/gi,
        '_'
      )}_${session.name.replace(/[^a-z0-9]/gi, '_')}_${Date.now()}.txt`;
      a.click();
      URL.revokeObjectURL(url);
    },
    [sessions, agent.name]
  );

  const handleUpdateSettings = useCallback((newSettings: Partial<AgentSettings>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
  }, []);

  const handleResetSettings = useCallback(() => {
    setSettings({
      temperature: 0.7,
      maxTokens: 2000,
      mode: 'balanced',
      systemPrompt: '',
      provider: 'mistral',
      model: 'mistral-large-latest',
    });
  }, []);

  // Message action handlers
  const handleFeedback = useCallback(
    (messageId: string, type: 'up' | 'down') => {
      setMessageFeedback(prev => ({
        ...prev,
        [messageId]: prev[messageId] === type ? null : type,
      }));

      // Persist reaction when we have a server-generated message id
      if (messageId.startsWith('msg_')) {
        const reactionType = type === 'up' ? 'like' : 'dislike';
        chatSessionService.reactToMessage(messageId, activeSessionId, reactionType).catch(err => {
          console.error('Error persisting reaction:', err);
        });
      }
    },
    [activeSessionId]
  );

  const handleCopyMessage = useCallback((messageId: string, content: string) => {
    navigator.clipboard.writeText(content);
    setCopiedMessageId(messageId);
    setTimeout(() => setCopiedMessageId(null), 2000);
  }, []);

  const handleShareMessage = useCallback(
    (content: string) => {
      if (navigator.share) {
        navigator.share({
          title: `${agent.name} Response`,
          text: content,
        });
      } else {
        navigator.clipboard.writeText(content);
      }
    },
    [agent.name]
  );

  const handleListenMessage = useCallback((content: string) => {
    const cleanText = content
      .replace(/\*\*(.*?)\*\*/g, '$1')
      .replace(/\*(.*?)\*/g, '$1')
      .replace(/```[\s\S]*?```/g, '')
      .replace(/`(.*?)`/g, '$1')
      .replace(/^#+\s/gm, '')
      .replace(/^[•-]\s/gm, '')
      .replace(/>\s/g, '');

    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.rate = 0.9;
    utterance.pitch = 1;
    speechSynthesis.speak(utterance);
  }, []);

  // 🎤 Voice Input Handler
  const handleVoiceInput = useCallback(() => {
    if (!('SpeechRecognition' in window || 'webkitSpeechRecognition' in window)) {
      alert('Voice input is not supported in your browser. Please use Chrome or Edge.');
      return;
    }

    if (isRecording) {
      // Stop recording
      recognitionRef.current?.stop();
      setIsRecording(false);
      return;
    }

    // Start recording
    const SpeechRecognitionAPI = window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognition = new SpeechRecognitionAPI();
    recognitionRef.current = recognition;

    recognition.continuous = false;
    recognition.interimResults = true;
    recognition.lang = 'en-US';

    recognition.onresult = (event: SpeechRecognitionEvent) => {
      let finalTranscript = '';
      let interimTranscript = '';

      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcript = event.results[i][0].transcript;
        if (event.results[i].isFinal) {
          finalTranscript += transcript;
        } else {
          interimTranscript += transcript;
        }
      }

      if (finalTranscript) {
        setInputValue(prev => prev + finalTranscript);
      } else if (interimTranscript) {
        // Show interim results with visual feedback
        setInputValue(prev => {
          const base = prev.replace(/\[listening...\].*$/, '');
          return base + '[listening...] ' + interimTranscript;
        });
      }
    };

    recognition.onerror = event => {
      console.error('Speech recognition error:', event);
      setIsRecording(false);
      setInputValue(prev => prev.replace(/\[listening...\].*$/, ''));
    };

    recognition.onend = () => {
      setIsRecording(false);
      setInputValue(prev => prev.replace(/\[listening...\].*$/, ''));
    };

    recognition.start();
    setIsRecording(true);
  }, [isRecording]);

  // 📎 File Upload Handler
  const handleFileUpload = useCallback(
    async (file: File) => {
      if (!file) return;

      // Validate file size (max 10MB)
      if (file.size > 10 * 1024 * 1024) {
        alert('File size must be less than 10MB');
        return;
      }

      // Validate file type
      const allowedTypes = [
        'image/jpeg',
        'image/png',
        'image/gif',
        'image/webp',
        'application/pdf',
        'text/plain',
        'text/csv',
        'application/json',
        'application/javascript',
        'text/html',
        'text/css',
        'text/markdown',
      ];

      if (!allowedTypes.includes(file.type) && !file.type.startsWith('text/')) {
        alert('File type not supported. Please upload images, PDFs, or text files.');
        return;
      }

      setIsUploading(true);

      try {
        const formData = new FormData();
        formData.append('file', file);
        formData.append('userId', userId);
        formData.append('sessionId', activeSessionId);

        const apiUrl = import.meta.env.VITE_API_URL || 'https://api.iamai.global';
        const response = await fetch(`${apiUrl}/api/chat/upload`, {
          method: 'POST',
          body: formData,
          credentials: 'include',
        });

        if (!response.ok) {
          throw new Error('Upload failed');
        }

        const data = await response.json();
        const upload = data.data || {};

        setUploadedFile({
          id: upload.fileId || Date.now().toString(),
          name: file.name,
          url: upload.fileUrl || URL.createObjectURL(file),
          type: file.type,
          size: file.size,
        });

        // Add context about the file to the input
        const fileContext = file.type.startsWith('image/')
          ? `[Uploaded image: ${file.name}] `
          : `[Uploaded file: ${file.name}] `;

        setInputValue(prev => fileContext + prev);
      } catch (error) {
        console.error('File upload error:', error);
        // Fallback: create local preview for images
        if (file.type.startsWith('image/')) {
          setUploadedFile({
            id: Date.now().toString(),
            name: file.name,
            url: URL.createObjectURL(file),
            type: file.type,
            size: file.size,
          });
          setInputValue(prev => `[Image: ${file.name}] ` + prev);
        } else {
          alert('Failed to upload file. Please try again.');
        }
      } finally {
        setIsUploading(false);
      }
    },
    [activeSessionId]
  );

  // Remove uploaded file
  const handleRemoveFile = useCallback(() => {
    if (uploadedFile?.url.startsWith('blob:')) {
      URL.revokeObjectURL(uploadedFile.url);
    }
    setUploadedFile(null);
    setInputValue(prev =>
      prev
        .replace(/\[(Uploaded )?[Ii]mage:.*?\]\s*/g, '')
        .replace(/\[(Uploaded )?[Ff]ile:.*?\]\s*/g, '')
    );
  }, [uploadedFile]);

  const handleSendMessage = useCallback(async () => {
    if (!inputValue.trim() || !activeSession || isLoading) return;

    const userMessage: Message = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: inputValue,
      timestamp: new Date(),
    };

    setSessions(prev =>
      prev.map(s =>
        s.id === activeSessionId
          ? {
              ...s,
              messages: [...s.messages, userMessage],
              lastMessage: inputValue.slice(0, 50),
              messageCount: s.messages.length + 1,
              updatedAt: new Date(),
            }
          : s
      )
    );

    const userInput = inputValue;
    setInputValue('');
    setIsLoading(true);

    const conversationHistory: ServiceChatMessage[] = activeSession.messages.map(m => ({
      id: m.id,
      role: m.role,
      content: m.content,
      timestamp: m.timestamp,
    }));

    conversationHistory.push({
      id: userMessage.id,
      role: 'user',
      content: userInput,
      timestamp: new Date(),
    });

    const agentConfig: AgentConfig = {
      id: agent.id,
      name: agent.name,
      systemPrompt: settings.systemPrompt || agent.systemPrompt,
      model: settings.model || 'mistral-large-latest',
      temperature: settings.temperature,
      maxTokens: settings.maxTokens,
      provider:
        settings.provider === 'openai' ? 'mistral' : (settings.provider as 'mistral' | 'gemini'),
    };

    const assistantMessageId = `asst-${Date.now()}`;
    const assistantMessage: Message = {
      id: assistantMessageId,
      role: 'assistant',
      content: '',
      timestamp: new Date(),
      isStreaming: true,
    };

    setSessions(prev =>
      prev.map(s =>
        s.id === activeSessionId
          ? {
              ...s,
              messages: [...s.messages, assistantMessage],
              messageCount: s.messages.length + 1,
              updatedAt: new Date(),
            }
          : s
      )
    );

    let detectedCodeBlocks: CodeBlock[] = [];

    await realtimeChatService.sendMessageStream(userInput, conversationHistory, agentConfig, {
      onToken: token => {
        setSessions(prev =>
          prev.map(s =>
            s.id === activeSessionId
              ? {
                  ...s,
                  messages: s.messages.map(m =>
                    m.id === assistantMessageId ? { ...m, content: m.content + token } : m
                  ),
                }
              : s
          )
        );
      },
      onComplete: fullMessage => {
        setSessions(prev =>
          prev.map(s =>
            s.id === activeSessionId
              ? {
                  ...s,
                  messages: s.messages.map(m =>
                    m.id === assistantMessageId
                      ? {
                          ...m,
                          content: fullMessage,
                          isStreaming: false,
                          codeBlocks:
                            detectedCodeBlocks.length > 0 ? detectedCodeBlocks : undefined,
                        }
                      : m
                  ),
                }
              : s
          )
        );
        setIsLoading(false);
      },
      onError: error => {
        console.error('Chat error:', error);
        setSessions(prev =>
          prev.map(s =>
            s.id === activeSessionId
              ? {
                  ...s,
                  messages: s.messages.map(m =>
                    m.id === assistantMessageId
                      ? {
                          ...m,
                          content: `❌ Sorry, I encountered an error: ${error.message}\n\nPlease try again.`,
                          isStreaming: false,
                        }
                      : m
                  ),
                }
              : s
          )
        );
        setIsLoading(false);
      },
      onCodeBlock: codeBlock => {
        detectedCodeBlocks.push(codeBlock);
      },
    });
  }, [inputValue, activeSession, activeSessionId, isLoading, settings, agent]);

  return (
    <EnhancedChatLayout
      agentId={agent.id}
      agentName={agent.name}
      sessions={sessions}
      activeSessionId={activeSessionId}
      onNewSession={handleNewSession}
      onSelectSession={handleSelectSession}
      onDeleteSession={handleDeleteSession}
      onRenameSession={handleRenameSession}
      onExportSession={handleExportSession}
      settings={settings}
      onUpdateSettings={handleUpdateSettings}
      onResetSettings={handleResetSettings}
      externalUrl="https://iamai.global/agents"
    >
      <div className="flex flex-col h-full">
        {/* Messages Area */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar">
          {activeSession?.messages.map(message => (
            <div
              key={message.id}
              className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[80%] rounded-2xl px-4 py-3 shadow-sm ${
                  message.role === 'user'
                    ? 'bg-gradient-to-r from-indigo-500 to-purple-600 text-white'
                    : 'bg-white border border-gray-200 text-gray-900'
                }`}
              >
                <div className="whitespace-pre-wrap text-sm leading-relaxed">
                  {message.content
                    .split('\n')
                    .map((line, i) => {
                      let processedLine = line.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
                      processedLine = processedLine.replace(/\*(.*?)\*/g, '<em>$1</em>');

                      if (line.startsWith('```')) return null;
                      if (line.startsWith('---')) {
                        return <hr key={`line-${i}`} className="my-2 border-gray-300" />;
                      }
                      if (line.startsWith('## ')) {
                        return (
                          <h3 key={`line-${i}`} className="font-bold text-base mt-2">
                            {line.slice(3)}
                          </h3>
                        );
                      }
                      if (line.startsWith('# ')) {
                        return (
                          <h2 key={`line-${i}`} className="font-bold text-lg mt-2">
                            {line.slice(2)}
                          </h2>
                        );
                      }
                      if (line.startsWith('> ')) {
                        return (
                          <blockquote
                            key={`line-${i}`}
                            className="border-l-4 border-indigo-300 pl-3 italic my-2 text-gray-600"
                          >
                            <span
                              dangerouslySetInnerHTML={{
                                __html: processedLine.slice(2),
                              }}
                            />
                          </blockquote>
                        );
                      }
                      if (line.startsWith('• ') || line.startsWith('- ')) {
                        return (
                          <div key={`line-${i}`} className="flex items-start space-x-2">
                            <span className="text-indigo-500">•</span>
                            <span
                              dangerouslySetInnerHTML={{
                                __html: processedLine.slice(2),
                              }}
                            />
                          </div>
                        );
                      }
                      if (/^\d+\.\s/.test(line)) {
                        const num = /^(\d+)\./.exec(line)?.[1];
                        return (
                          <div key={`line-${i}`} className="flex items-start space-x-2">
                            <span className="text-indigo-500 font-medium">{num}.</span>
                            <span
                              dangerouslySetInnerHTML={{
                                __html: processedLine.replace(/^\d+\.\s/, ''),
                              }}
                            />
                          </div>
                        );
                      }
                      return (
                        <span
                          key={`line-${i}`}
                          dangerouslySetInnerHTML={{ __html: processedLine }}
                        />
                      );
                    })
                    .filter(Boolean)}
                </div>
                <div
                  className={`text-xs mt-2 ${
                    message.role === 'user' ? 'text-white/60' : 'text-gray-400'
                  }`}
                >
                  {message.timestamp.toLocaleTimeString([], {
                    hour: '2-digit',
                    minute: '2-digit',
                  })}
                </div>

                {message.role === 'assistant' && (
                  <div className="flex items-center space-x-1 mt-2 pt-2 border-t border-gray-100">
                    <button
                      onClick={() => handleFeedback(message.id, 'up')}
                      className={`p-1.5 rounded-lg transition-all ${
                        messageFeedback[message.id] === 'up'
                          ? 'bg-green-100 text-green-600'
                          : 'hover:bg-gray-100 text-gray-400 hover:text-gray-600'
                      }`}
                      title="Good response"
                    >
                      <HandThumbUpIcon className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleFeedback(message.id, 'down')}
                      className={`p-1.5 rounded-lg transition-all ${
                        messageFeedback[message.id] === 'down'
                          ? 'bg-red-100 text-red-600'
                          : 'hover:bg-gray-100 text-gray-400 hover:text-gray-600'
                      }`}
                      title="Poor response"
                    >
                      <HandThumbDownIcon className="w-4 h-4" />
                    </button>
                    <div className="w-px h-4 bg-gray-200 mx-1" />
                    <button
                      onClick={() => handleCopyMessage(message.id, message.content)}
                      className={`p-1.5 rounded-lg transition-all ${
                        copiedMessageId === message.id
                          ? 'bg-indigo-100 text-indigo-600'
                          : 'hover:bg-gray-100 text-gray-400 hover:text-gray-600'
                      }`}
                      title={copiedMessageId === message.id ? 'Copied!' : 'Copy message'}
                    >
                      <ClipboardDocumentIcon className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleShareMessage(message.content)}
                      className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 hover:text-gray-600 transition-all"
                      title="Share message"
                    >
                      <ShareIcon className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleListenMessage(message.content)}
                      className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 hover:text-gray-600 transition-all"
                      title="Listen to message"
                    >
                      <SpeakerWaveIcon className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))}

          {isLoading && (
            <div className="flex justify-start">
              <div className="bg-white border border-gray-200 rounded-2xl px-4 py-3 shadow-sm">
                <div className="flex items-center space-x-2">
                  <div className="flex space-x-1">
                    <div
                      className="w-2 h-2 bg-indigo-500 rounded-full animate-bounce"
                      style={{ animationDelay: '0ms' }}
                    />
                    <div
                      className="w-2 h-2 bg-purple-500 rounded-full animate-bounce"
                      style={{ animationDelay: '150ms' }}
                    />
                    <div
                      className="w-2 h-2 bg-pink-500 rounded-full animate-bounce"
                      style={{ animationDelay: '300ms' }}
                    />
                  </div>
                  <span className="text-xs text-gray-500">{agent.name} is thinking...</span>
                </div>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Quick Actions Panel */}
        <QuickActionsPanel
          onSelectAction={prompt => setInputValue(prompt)}
          theme="default"
          isCollapsed={isQuickActionsCollapsed}
          onToggleCollapse={() => setIsQuickActionsCollapsed(!isQuickActionsCollapsed)}
        />

        {/* File Preview */}
        {uploadedFile && (
          <div className="flex-shrink-0 px-4 py-2 bg-gray-50 border-t border-gray-200">
            <div className="flex items-center gap-3 p-2 bg-white rounded-lg border border-gray-200 shadow-sm">
              {uploadedFile.type.startsWith('image/') ? (
                <div className="relative w-16 h-16 rounded-lg overflow-hidden bg-gray-100">
                  <img
                    src={uploadedFile.url}
                    alt={uploadedFile.name}
                    className="w-full h-full object-cover"
                  />
                </div>
              ) : (
                <div className="w-16 h-16 rounded-lg bg-gradient-to-br from-indigo-50 to-purple-50 flex items-center justify-center">
                  <DocumentIcon className="w-8 h-8 text-indigo-500" />
                </div>
              )}
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-900 truncate">{uploadedFile.name}</p>
                <p className="text-xs text-gray-500">
                  {(uploadedFile.size / 1024).toFixed(1)} KB •{' '}
                  {uploadedFile.type.split('/')[1]?.toUpperCase()}
                </p>
              </div>
              <button
                onClick={handleRemoveFile}
                className="p-1.5 rounded-lg hover:bg-red-50 text-gray-400 hover:text-red-500 transition-colors"
                title="Remove file"
              >
                <XMarkIcon className="w-5 h-5" />
              </button>
            </div>
          </div>
        )}

        {/* Input Area */}
        <div className="flex-shrink-0 px-4 py-2 border-t border-gray-200 bg-white/80 backdrop-blur-sm">
          <input
            ref={fileInputRef}
            type="file"
            className="hidden"
            accept="image/*,.pdf,.txt,.csv,.json,.js,.html,.css,.md"
            aria-label="File upload"
            onChange={e => {
              const file = e.target.files?.[0];
              if (file) handleFileUpload(file);
              e.target.value = ''; // Reset for re-upload
            }}
          />

          <form
            onSubmit={e => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex items-center space-x-2"
          >
            <button
              type="button"
              onClick={handleVoiceInput}
              className={`p-2.5 rounded-xl transition-all ${
                isRecording
                  ? 'bg-red-500 text-white animate-pulse shadow-lg shadow-red-500/50'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
              title={isRecording ? 'Stop Recording' : 'Voice Input'}
            >
              <MicrophoneIcon className="w-5 h-5" />
            </button>

            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              disabled={isUploading}
              className={`p-2.5 rounded-xl transition-all ${
                isUploading
                  ? 'bg-indigo-100 text-indigo-600 animate-pulse'
                  : uploadedFile
                    ? 'bg-green-100 text-green-600'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
              title={isUploading ? 'Uploading...' : uploadedFile ? 'File attached' : 'Upload File'}
            >
              <PaperClipIcon className="w-5 h-5" />
            </button>

            <button
              type="button"
              onClick={() => alert('Voice-to-Voice coming soon!')}
              className="p-2.5 rounded-xl bg-gray-100 text-gray-600 hover:bg-gray-200 transition-all"
              title="Voice Conversation"
            >
              <PhoneIcon className="w-5 h-5" />
            </button>

            <div className="flex-1 relative">
              <input
                type="text"
                value={inputValue}
                onChange={e => setInputValue(e.target.value)}
                placeholder={`Message ${agent.name}...`}
                className="w-full px-4 py-3 pr-12 rounded-xl border border-gray-300 bg-white text-gray-900 focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all placeholder:text-gray-400"
                disabled={isLoading}
              />
              <button
                type="submit"
                disabled={!inputValue.trim() || isLoading}
                className="absolute right-2 top-1/2 -translate-y-1/2 p-2 rounded-lg bg-gradient-to-r from-indigo-500 to-purple-600 text-white disabled:opacity-50 disabled:cursor-not-allowed transition-all hover:from-indigo-600 hover:to-purple-700"
              >
                {isLoading ? (
                  <svg className="animate-spin w-5 h-5" viewBox="0 0 24 24">
                    <circle
                      className="opacity-25"
                      cx="12"
                      cy="12"
                      r="10"
                      stroke="currentColor"
                      strokeWidth="4"
                      fill="none"
                    />
                    <path
                      className="opacity-75"
                      fill="currentColor"
                      d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                    />
                  </svg>
                ) : (
                  <PaperAirplaneIcon className="w-5 h-5" />
                )}
              </button>
            </div>
          </form>

          <div className="mt-1 text-center">
            <p className="text-[10px] text-gray-400">
              AI digital friend can make mistakes. Check important info.
            </p>
          </div>
        </div>
      </div>
    </EnhancedChatLayout>
  );
}
