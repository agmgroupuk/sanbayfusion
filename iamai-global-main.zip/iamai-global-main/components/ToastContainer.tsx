import React, { useState, useEffect } from 'react';
import { notificationService, Toast } from '../services/notificationService';

const ToastContainer: React.FC = () => {
  const [toasts, setToasts] = useState<Toast[]>([]);

  useEffect(() => {
    const unsubscribe = notificationService.subscribe(setToasts);
    return unsubscribe;
  }, []);

  if (toasts.length === 0) return null;

  return (
    <div className="fixed top-4 right-4 z-50 space-y-2 max-w-sm">
      {toasts.map(toast => (
        <ToastItem
          key={toast.id}
          toast={toast}
          onClose={() => notificationService.removeToast(toast.id)}
        />
      ))}
    </div>
  );
};

const ToastItem: React.FC<{
  toast: Toast;
  onClose: () => void;
}> = ({ toast, onClose }) => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Trigger animation after mount
    const timer = setTimeout(() => setIsVisible(true), 10);
    return () => clearTimeout(timer);
  }, []);

  const handleClose = () => {
    setIsVisible(false);
    // Wait for animation to complete
    setTimeout(onClose, 200);
  };

  const getToastStyles = () => {
    const baseStyles = 'border shadow-lg backdrop-blur-sm transition-all duration-200 ease-out';

    switch (toast.type) {
      case 'success':
        return `${baseStyles} bg-green-500/10 border-green-500/30 text-green-400`;
      case 'error':
        return `${baseStyles} bg-red-500/10 border-red-500/30 text-red-400`;
      case 'warning':
        return `${baseStyles} bg-yellow-500/10 border-yellow-500/30 text-yellow-400`;
      case 'info':
      default:
        return `${baseStyles} bg-blue-500/10 border-blue-500/30 text-blue-400`;
    }
  };

  const getIcon = () => {
    switch (toast.type) {
      case 'success':
        return '✓';
      case 'error':
        return '✕';
      case 'warning':
        return '⚠';
      case 'info':
      default:
        return 'ℹ';
    }
  };

  return (
    <div
      className={`
        ${getToastStyles()}
        rounded-lg p-4 min-w-[300px] max-w-[400px]
        transform transition-all duration-200 ease-out
        ${isVisible ? 'translate-x-0 opacity-100 scale-100' : 'translate-x-full opacity-0 scale-95'}
      `}
    >
      <div className="flex items-start justify-between">
        <div className="flex items-start space-x-3">
          <div className="flex-shrink-0 text-lg">{getIcon()}</div>
          <div className="flex-1 min-w-0">
            <div className="font-medium text-sm">{toast.title}</div>
            {toast.message && <div className="text-xs opacity-90 mt-1">{toast.message}</div>}
          </div>
        </div>

        {!toast.persistent && (
          <button
            onClick={handleClose}
            className="flex-shrink-0 ml-2 text-xs opacity-70 hover:opacity-100 transition-opacity"
          >
            ✕
          </button>
        )}
      </div>

      {/* Progress bar for non-persistent toasts */}
      {!toast.persistent && toast.duration && (
        <div className="mt-2 h-0.5 bg-current opacity-20 rounded-full overflow-hidden">
          <div
            className="h-full bg-current opacity-60 rounded-full animate-shrink"
            style={{ animationDuration: `${toast.duration}ms` }}
          />
        </div>
      )}
    </div>
  );
};

export default ToastContainer;
