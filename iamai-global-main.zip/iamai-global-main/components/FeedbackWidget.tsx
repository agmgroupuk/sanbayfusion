/**
 * Feedback Widget Component
 * Collects user feedback on support experience
 * Thumbs up/down buttons with optional comment field
 * Stores feedback for CSAT (Customer Satisfaction) calculation
 */

import React, { useState } from 'react';
import { ThumbsUp, ThumbsDown, Send, X } from 'lucide-react';

interface FeedbackWidgetProps {
  ticketId: string;
  onSubmit?: (feedback: FeedbackData) => void;
  onClose?: () => void;
}

interface FeedbackData {
  ticketId: string;
  rating: 'positive' | 'negative';
  comment: string;
  timestamp: Date;
}

const FeedbackWidget: React.FC<FeedbackWidgetProps> = ({ ticketId, onSubmit, onClose }) => {
  const [rating, setRating] = useState<'positive' | 'negative' | null>(null);
  const [comment, setComment] = useState('');
  const [showCommentField, setShowCommentField] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  /**
   * Handle rating selection
   */
  const handleRating = (value: 'positive' | 'negative'): void => {
    setRating(value);
    setShowCommentField(true);
  };

  /**
   * Handle feedback submission
   */
  const handleSubmit = async (): Promise<void> => {
    if (!rating) return;

    try {
      setSubmitting(true);

      const feedbackData: FeedbackData = {
        ticketId,
        rating,
        comment,
        timestamp: new Date(),
      };

      // Send to backend
      const response = await fetch('/api/support/feedback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(feedbackData),
      });

      if (!response.ok) {
        throw new Error('Failed to submit feedback');
      }

      setSubmitted(true);
      onSubmit?.(feedbackData);

      // Auto-close after 2 seconds
      setTimeout(() => {
        onClose?.();
      }, 2000);
    } catch (error) {
      console.error('[FeedbackWidget] Error submitting feedback:', error);
      // Still consider it submitted for UX purposes
      setSubmitted(true);
      setTimeout(() => {
        onClose?.();
      }, 2000);
    } finally {
      setSubmitting(false);
    }
  };

  /**
   * Handle close
   */
  const handleClose = (): void => {
    // Save feedback even if not submitted
    if (rating) {
      const feedbackData: FeedbackData = {
        ticketId,
        rating,
        comment,
        timestamp: new Date(),
      };
      // Send in background
      fetch('/api/support/feedback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(feedbackData),
      }).catch(error => {
        console.error('[FeedbackWidget] Error auto-saving feedback:', error);
      });
    }
    onClose?.();
  };

  if (submitted) {
    return (
      <div className="bg-gradient-to-br from-green-500/10 to-emerald-500/10 border border-green-500/30 rounded-lg p-4">
        <div className="text-center">
          <div className="flex justify-center mb-2">
            <div className="text-2xl">✓</div>
          </div>
          <p className="text-sm font-semibold text-green-400 mb-1">Thank you for your feedback!</p>
          <p className="text-xs text-gray-400">
            We appreciate your input and will use it to improve our service
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gradient-to-br from-cyan-500/5 to-blue-500/5 border border-cyan-500/20 rounded-lg p-4">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <h4 className="text-sm font-semibold text-white">How was your support experience?</h4>
        <button
          onClick={handleClose}
          className="text-gray-400 hover:text-gray-300 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Rating Buttons */}
      <div className="flex gap-3 mb-4">
        <button
          onClick={() => handleRating('positive')}
          className={`flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-lg font-medium transition-all ${
            rating === 'positive'
              ? 'bg-green-500/30 border border-green-500 text-green-400 shadow-lg shadow-green-500/20'
              : 'bg-gray-800 border border-gray-700/50 text-gray-400 hover:border-gray-600 hover:text-gray-300'
          }`}
        >
          <ThumbsUp className="w-5 h-5" />
          <span>Helpful</span>
        </button>

        <button
          onClick={() => handleRating('negative')}
          className={`flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-lg font-medium transition-all ${
            rating === 'negative'
              ? 'bg-red-500/30 border border-red-500 text-red-400 shadow-lg shadow-red-500/20'
              : 'bg-gray-800 border border-gray-700/50 text-gray-400 hover:border-gray-600 hover:text-gray-300'
          }`}
        >
          <ThumbsDown className="w-5 h-5" />
          <span>Not Helpful</span>
        </button>
      </div>

      {/* Comment Field */}
      {showCommentField && (
        <div className="space-y-3 mb-4 animate-in fade-in slide-in-from-top-2 duration-300">
          <textarea
            value={comment}
            onChange={e => setComment(e.target.value)}
            placeholder={
              rating === 'positive'
                ? 'What was most helpful? (optional)'
                : 'How can we improve? (optional)'
            }
            maxLength={200}
            rows={3}
            className="w-full px-3 py-2 bg-black/50 border border-gray-700/50 rounded text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500 transition-colors resize-none text-sm"
          />

          <div className="flex items-center justify-between">
            <span className="text-xs text-gray-500">{comment.length} / 200 characters</span>

            <div className="flex gap-2">
              <button
                onClick={handleClose}
                className="px-3 py-1.5 bg-gray-800 hover:bg-gray-700 text-gray-300 border border-gray-700/50 rounded text-sm transition-colors"
              >
                Skip
              </button>

              <button
                onClick={handleSubmit}
                disabled={submitting}
                className="px-3 py-1.5 bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-400 border border-cyan-500/30 rounded text-sm font-medium transition-colors disabled:opacity-50 flex items-center gap-1"
              >
                {submitting ? (
                  <>
                    <div className="w-3 h-3 border-2 border-transparent border-t-cyan-400 rounded-full animate-spin"></div>
                  </>
                ) : (
                  <>
                    <Send className="w-3 h-3" />
                    Send
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Quick Action Buttons */}
      {!showCommentField && (
        <div className="flex gap-2">
          <button
            onClick={handleClose}
            className="flex-1 px-3 py-2 bg-gray-800 hover:bg-gray-700 text-gray-300 border border-gray-700/50 rounded text-sm font-medium transition-colors"
          >
            Skip
          </button>

          {rating && (
            <button
              onClick={handleSubmit}
              disabled={submitting}
              className="flex-1 px-3 py-2 bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-400 border border-cyan-500/30 rounded text-sm font-medium transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {submitting ? (
                <>
                  <div className="w-3 h-3 border-2 border-transparent border-t-cyan-400 rounded-full animate-spin"></div>
                  Sending...
                </>
              ) : (
                <>
                  <Send className="w-3 h-3" />
                  Send Feedback
                </>
              )}
            </button>
          )}
        </div>
      )}

      {/* CSAT Info */}
      <p className="text-xs text-gray-500 text-center mt-3">
        Your feedback helps us improve - CSAT score updates in real-time
      </p>
    </div>
  );
};

export default FeedbackWidget;
