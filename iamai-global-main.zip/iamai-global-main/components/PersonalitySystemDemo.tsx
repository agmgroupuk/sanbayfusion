/**
 * Personality System Test Component
 *
 * This component demonstrates how to use the enhanced personality system
 * to create consistent agent responses in different scenarios.
 */

import React, { useState } from 'react';
import { usePersonalityGuidedResponse } from '../agents/usePersonalityGuidedResponse';
import { AGENT_PERSONALITIES } from '../agents/personalityConfig';
import { AGENT_FALLBACKS } from '../agents/personalityFallbacks';

/**
 * Personality System Demo component
 * Shows how different agents respond to the same questions
 */
export const PersonalitySystemDemo: React.FC = () => {
  const [selectedAgent, setSelectedAgent] = useState('PDFMind');
  const [selectedScenario, setSelectedScenario] = useState('greeting');
  const [customQuestion, setCustomQuestion] = useState('');
  const [customResponse, setCustomResponse] = useState('');

  // Get the personality-guided response hook for the selected agent
  const personalityResponses = usePersonalityGuidedResponse(selectedAgent);

  // Get available agents
  const availableAgents = Object.keys(AGENT_PERSONALITIES);

  // Define demo scenarios
  const scenarios = [
    { id: 'greeting', name: 'Greeting', response: personalityResponses.generateGreeting() },
    {
      id: 'confusion',
      name: "Doesn't Understand",
      response: personalityResponses.generateConfusionResponse(),
    },
    {
      id: 'needInfo',
      name: 'Needs More Info',
      response: personalityResponses.generateNeedMoreInfoResponse(),
    },
    {
      id: 'cannotHelp',
      name: 'Cannot Help',
      response: personalityResponses.generateCannotHelpResponse(),
    },
    {
      id: 'error',
      name: 'Technical Error',
      response: personalityResponses.generateErrorResponse('technical'),
    },
    {
      id: 'filtered',
      name: 'Content Filtered',
      response: personalityResponses.generateErrorResponse('content'),
    },
    {
      id: 'alternative',
      name: 'Suggests Alternative',
      response: personalityResponses.generateAlternativeResponse('a different approach'),
    },
    { id: 'farewell', name: 'Saying Goodbye', response: personalityResponses.generateFarewell() },
  ];

  // Handle custom question response
  const handleCustomQuestionChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setCustomQuestion(e.target.value);
  };

  const generateCustomResponse = () => {
    // This would normally call an AI API with the system prompt for this agent
    // For demo purposes, we'll just filter a generic response
    const genericResponse = `I understand your question about "${customQuestion}". Here's what I know about this topic: This is an interesting subject that has several aspects to consider. First, we should look at the main concepts. Then, we can explore how they relate to your specific situation.`;

    setCustomResponse(personalityResponses.generateResponse(genericResponse));
  };

  return (
    <div className="personality-demo">
      <h1>Agent Personality System Demo</h1>

      <div className="agent-selector">
        <h2>Select an Agent</h2>
        <select value={selectedAgent} onChange={e => setSelectedAgent(e.target.value)}>
          {availableAgents.map(agentId => (
            <option key={agentId} value={agentId}>
              {AGENT_PERSONALITIES[agentId].name}
            </option>
          ))}
        </select>

        <div className="agent-info">
          <h3>
            {AGENT_PERSONALITIES[selectedAgent].name} - {AGENT_PERSONALITIES[selectedAgent].role}
          </h3>
          <p>
            <strong>Personality:</strong> {AGENT_PERSONALITIES[selectedAgent].personality}
          </p>
          <p>
            <strong>Speech Pattern:</strong> {AGENT_PERSONALITIES[selectedAgent].speechPattern}
          </p>
        </div>
      </div>

      <div className="scenario-demo">
        <h2>Standard Response Scenarios</h2>
        <select value={selectedScenario} onChange={e => setSelectedScenario(e.target.value)}>
          {scenarios.map(scenario => (
            <option key={scenario.id} value={scenario.id}>
              {scenario.name}
            </option>
          ))}
        </select>

        <div className="response-display">
          <h3>{scenarios.find(s => s.id === selectedScenario)?.name} Response:</h3>
          <div className="response-bubble">
            <p>{scenarios.find(s => s.id === selectedScenario)?.response}</p>
          </div>
        </div>
      </div>

      <div className="custom-question">
        <h2>Test a Custom Question</h2>
        <textarea
          value={customQuestion}
          onChange={handleCustomQuestionChange}
          placeholder="Enter a question to test how this agent would respond..."
          rows={4}
        />
        <button onClick={generateCustomResponse}>Generate Response</button>

        {customResponse && (
          <div className="response-display">
            <h3>Custom Response:</h3>
            <div className="response-bubble">
              <p>{customResponse}</p>
            </div>
          </div>
        )}
      </div>

      <div className="personality-traits">
        <h2>Agent Personality Details</h2>
        <h3>Catchphrases</h3>
        <ul>
          {AGENT_PERSONALITIES[selectedAgent].catchphrases.map((phrase, index) => (
            <li key={index}>
              {typeof phrase === 'string' ? phrase : phrase?.text || 'Catchphrase'}
            </li>
          ))}
        </ul>

        <h3>Never Says</h3>
        <ul>
          {AGENT_PERSONALITIES[selectedAgent].neverSay.map((phrase, index) => (
            <li key={index}>"{typeof phrase === 'string' ? phrase : phrase?.text || 'Phrase'}"</li>
          ))}
        </ul>

        <h3>Always Says</h3>
        <ul>
          {AGENT_PERSONALITIES[selectedAgent].alwaysSay.map((phrase, index) => (
            <li key={index}>"{typeof phrase === 'string' ? phrase : phrase?.text || 'Phrase'}"</li>
          ))}
        </ul>

        <h3>Favorite Emojis</h3>
        <p>
          {Array.isArray(AGENT_PERSONALITIES[selectedAgent].emojis)
            ? AGENT_PERSONALITIES[selectedAgent].emojis.join(' ')
            : 'No emojis available'}
        </p>
      </div>
    </div>
  );
};

export default PersonalitySystemDemo;
