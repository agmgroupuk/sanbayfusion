
import React from 'react';
import { SOLUTIONS, Solution } from '../constants';

const SolutionCard: React.FC<{ solution: Solution }> = ({ solution }) => (
    <div className="bg-gray-900/50 p-6 rounded-lg text-center border border-transparent hover:border-cyan-500/30 transition-colors duration-300">
        <i className={`${solution.icon} text-3xl text-cyan-400`}></i>
        <h3 className="mt-4 font-semibold text-white">{solution.name}</h3>
        <p className="mt-2 text-sm text-gray-400">{solution.description}</p>
    </div>
);

const SolutionsSection: React.FC = () => {
  return (
    <section id="solutions" className="py-20 md:py-28 bg-[#0a0a0a]">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-white">AI Solutions for Any Industry</h2>
          <p className="max-w-2xl mx-auto mt-4 text-gray-400">
            Leverage our specialized agents to build powerful, industry-specific solutions.
          </p>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
          {SOLUTIONS.map((solution) => (
            <SolutionCard key={solution.name} solution={solution} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default SolutionsSection;
