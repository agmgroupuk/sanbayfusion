export interface SystemMetrics {
  totalUsers: number;
  activeUsers: number;
  totalMessages: number;
  messagesLast24h: number;
  apiCalls: number;
  errorRate: number;
  responseTime: number;
  uptime: number;
  memoryUsage: number;
  cpuUsage: number;
}

export interface UserActivity {
  userId: string;
  username: string;
  lastActive: Date;
  messageCount: number;
  apiUsage: number;
  subscription: 'free' | 'premium' | 'enterprise';
  status: 'active' | 'inactive' | 'suspended';
}

export interface SystemAlert {
  id: string;
  type: 'error' | 'warning' | 'info';
  title: string;
  message: string;
  timestamp: Date;
  acknowledged: boolean;
  source: string;
}

export interface AgentPerformance {
  agentName: string;
  totalMessages: number;
  averageResponseTime: number;
  successRate: number;
  errorCount: number;
  lastActive: Date;
  popularityScore: number;
}

export interface AdminDashboardState {
  metrics: SystemMetrics;
  userActivity: UserActivity[];
  alerts: SystemAlert[];
  agentPerformance: AgentPerformance[];
  isLoading: boolean;
  selectedTimeRange: '1h' | '24h' | '7d' | '30d';
  refreshInterval: number;
  lastUpdated: Date;
  viewMode: 'overview' | 'users' | 'agents' | 'system' | 'alerts';
}

export class AdminDashboardService {
  private listeners: Set<(state: AdminDashboardState) => void> = new Set();
  private state: AdminDashboardState;
  private refreshTimer?: NodeJS.Timeout;

  constructor() {
    this.state = {
      metrics: this.getDefaultMetrics(),
      userActivity: [],
      alerts: [],
      agentPerformance: [],
      isLoading: false,
      selectedTimeRange: '24h',
      refreshInterval: 30000, // 30 seconds
      lastUpdated: new Date(),
      viewMode: 'overview',
    };

    this.startAutoRefresh();
    this.loadInitialData();
  }

  private getDefaultMetrics(): SystemMetrics {
    return {
      totalUsers: 0,
      activeUsers: 0,
      totalMessages: 0,
      messagesLast24h: 0,
      apiCalls: 0,
      errorRate: 0,
      responseTime: 0,
      uptime: 99.9,
      memoryUsage: 0,
      cpuUsage: 0,
    };
  }

  private async loadInitialData(): Promise<void> {
    this.updateState({ ...this.state, isLoading: true });

    try {
      await Promise.all([
        this.loadSystemMetrics(),
        this.loadUserActivity(),
        this.loadAlerts(),
        this.loadAgentPerformance(),
      ]);
    } catch (error) {
      console.error('Failed to load admin dashboard data:', error);
      this.createAlert('error', 'Data Load Failed', 'Failed to load dashboard data');
    } finally {
      this.updateState({
        ...this.state,
        isLoading: false,
        lastUpdated: new Date(),
      });
    }
  }

  private async loadSystemMetrics(): Promise<void> {
    try {
      // In a real app, this would be an API call
      const metrics: SystemMetrics = {
        totalUsers: Math.floor(Math.random() * 10000) + 5000,
        activeUsers: Math.floor(Math.random() * 1000) + 500,
        totalMessages: Math.floor(Math.random() * 100000) + 50000,
        messagesLast24h: Math.floor(Math.random() * 5000) + 2000,
        apiCalls: Math.floor(Math.random() * 50000) + 25000,
        errorRate: Math.random() * 2,
        responseTime: Math.random() * 500 + 100,
        uptime: 99.5 + Math.random() * 0.5,
        memoryUsage: Math.random() * 80 + 10,
        cpuUsage: Math.random() * 60 + 10,
      };

      this.updateState({ ...this.state, metrics });
    } catch (error) {
      console.error('Failed to load system metrics:', error);
    }
  }

  private async loadUserActivity(): Promise<void> {
    try {
      const users: UserActivity[] = Array.from({ length: 50 }, (_, i) => {
        const subscriptions: UserActivity['subscription'][] = ['free', 'premium', 'enterprise'];
        const statuses: UserActivity['status'][] = ['active', 'inactive', 'suspended'];

        return {
          userId: `user_${i + 1}`,
          username: `user${i + 1}@example.com`,
          lastActive: new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000),
          messageCount: Math.floor(Math.random() * 1000),
          apiUsage: Math.floor(Math.random() * 5000),
          subscription: subscriptions[Math.floor(Math.random() * subscriptions.length)],
          status: statuses[Math.floor(Math.random() * statuses.length)],
        };
      });

      this.updateState({ ...this.state, userActivity: users });
    } catch (error) {
      console.error('Failed to load user activity:', error);
    }
  }

  private async loadAlerts(): Promise<void> {
    try {
      const alerts: SystemAlert[] = [
        {
          id: 'alert_1',
          type: 'warning',
          title: 'High Memory Usage',
          message: 'System memory usage is above 85%',
          timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
          acknowledged: false,
          source: 'system',
        },
        {
          id: 'alert_2',
          type: 'info',
          title: 'New Agent Deployed',
          message: 'AgentX v2.1 has been successfully deployed',
          timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000),
          acknowledged: true,
          source: 'deployment',
        },
        {
          id: 'alert_3',
          type: 'error',
          title: 'Database Connection Issues',
          message: 'Intermittent connection issues with primary database',
          timestamp: new Date(Date.now() - 30 * 60 * 1000),
          acknowledged: false,
          source: 'database',
        },
      ];

      this.updateState({ ...this.state, alerts });
    } catch (error) {
      console.error('Failed to load alerts:', error);
    }
  }

  private async loadAgentPerformance(): Promise<void> {
    try {
      const agents = [
        'AgentX',
        'AIGirlfriend',
        'AutoChat',
        'ChatRevive',
        'ComedyChad',
        'CoolKyle',
        'CVSmash',
        'EmoAI',
        'FlirtyFiona',
        'GamerGary',
        'LazyLarry',
        'NerdyNeil',
        'PDFMind',
        'SassySarah',
        'TokBoost',
        'YouGen',
        'ZenMasterZara',
      ];

      const performance: AgentPerformance[] = agents.map(agentName => {
        const totalMessages = Math.floor(Math.random() * 10000) + 1000;
        const errorCount = Math.floor(Math.random() * 100);

        return {
          agentName,
          totalMessages,
          averageResponseTime: Math.random() * 2000 + 500,
          successRate: ((totalMessages - errorCount) / totalMessages) * 100,
          errorCount,
          lastActive: new Date(Date.now() - Math.random() * 24 * 60 * 60 * 1000),
          popularityScore: Math.random() * 100,
        };
      });

      this.updateState({ ...this.state, agentPerformance: performance });
    } catch (error) {
      console.error('Failed to load agent performance:', error);
    }
  }

  private startAutoRefresh(): void {
    this.refreshTimer = setInterval(() => {
      if (this.state.viewMode === 'overview') {
        this.loadSystemMetrics();
      }
    }, this.state.refreshInterval);
  }

  setTimeRange(timeRange: AdminDashboardState['selectedTimeRange']): void {
    this.updateState({ ...this.state, selectedTimeRange: timeRange });
    this.loadInitialData(); // Reload data for new time range
  }

  setViewMode(viewMode: AdminDashboardState['viewMode']): void {
    this.updateState({ ...this.state, viewMode });
  }

  setRefreshInterval(interval: number): void {
    this.updateState({ ...this.state, refreshInterval: interval });

    if (this.refreshTimer) {
      clearInterval(this.refreshTimer);
    }
    this.startAutoRefresh();
  }

  acknowledgeAlert(alertId: string): void {
    const alerts = this.state.alerts.map(alert =>
      alert.id === alertId ? { ...alert, acknowledged: true } : alert
    );

    this.updateState({ ...this.state, alerts });
  }

  dismissAlert(alertId: string): void {
    const alerts = this.state.alerts.filter(alert => alert.id !== alertId);
    this.updateState({ ...this.state, alerts });
  }

  createAlert(type: SystemAlert['type'], title: string, message: string): void {
    const alert: SystemAlert = {
      id: `alert_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      type,
      title,
      message,
      timestamp: new Date(),
      acknowledged: false,
      source: 'system',
    };

    const alerts = [alert, ...this.state.alerts];
    this.updateState({ ...this.state, alerts });
  }

  suspendUser(userId: string, reason: string): void {
    const userActivity = this.state.userActivity.map(user =>
      user.userId === userId ? { ...user, status: 'suspended' as const } : user
    );

    this.updateState({ ...this.state, userActivity });
    this.createAlert('info', 'User Suspended', `User ${userId} has been suspended: ${reason}`);
  }

  reactivateUser(userId: string): void {
    const userActivity = this.state.userActivity.map(user =>
      user.userId === userId ? { ...user, status: 'active' as const } : user
    );

    this.updateState({ ...this.state, userActivity });
    this.createAlert('info', 'User Reactivated', `User ${userId} has been reactivated`);
  }

  exportMetrics(): string {
    const exportData = {
      metrics: this.state.metrics,
      userStats: {
        total: this.state.userActivity.length,
        active: this.state.userActivity.filter(u => u.status === 'active').length,
        premium: this.state.userActivity.filter(u => u.subscription === 'premium').length,
        enterprise: this.state.userActivity.filter(u => u.subscription === 'enterprise').length,
      },
      agentStats: this.state.agentPerformance.map(agent => ({
        name: agent.agentName,
        messages: agent.totalMessages,
        successRate: agent.successRate,
        popularityScore: agent.popularityScore,
      })),
      exportedAt: new Date().toISOString(),
      timeRange: this.state.selectedTimeRange,
    };

    return JSON.stringify(exportData, null, 2);
  }

  getTopPerformingAgents(limit: number = 5): AgentPerformance[] {
    return [...this.state.agentPerformance]
      .sort((a, b) => b.popularityScore - a.popularityScore)
      .slice(0, limit);
  }

  getActiveUsersCount(): number {
    return this.state.userActivity.filter(u => u.status === 'active').length;
  }

  getUnacknowledgedAlertsCount(): number {
    return this.state.alerts.filter(a => !a.acknowledged).length;
  }

  getCriticalAlertsCount(): number {
    return this.state.alerts.filter(a => a.type === 'error' && !a.acknowledged).length;
  }

  getSystemHealthScore(): number {
    const { metrics } = this.state;
    let score = 100;

    // Deduct points for high error rate
    if (metrics.errorRate > 5) score -= 20;
    else if (metrics.errorRate > 2) score -= 10;

    // Deduct points for high response time
    if (metrics.responseTime > 1000) score -= 15;
    else if (metrics.responseTime > 500) score -= 8;

    // Deduct points for high resource usage
    if (metrics.memoryUsage > 90) score -= 15;
    else if (metrics.memoryUsage > 80) score -= 8;

    if (metrics.cpuUsage > 80) score -= 10;
    else if (metrics.cpuUsage > 60) score -= 5;

    // Deduct points for low uptime
    if (metrics.uptime < 99) score -= 20;
    else if (metrics.uptime < 99.5) score -= 10;

    return Math.max(0, score);
  }

  refresh(): void {
    this.loadInitialData();
  }

  getState(): AdminDashboardState {
    return { ...this.state };
  }

  subscribe(listener: (state: AdminDashboardState) => void): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private updateState(newState: AdminDashboardState): void {
    this.state = newState;
    this.listeners.forEach(listener => listener(this.state));
  }

  destroy(): void {
    if (this.refreshTimer) {
      clearInterval(this.refreshTimer);
    }
    this.listeners.clear();
  }
}
