export interface FileItem {
  id: string;
  name: string;
  type: 'file' | 'folder';
  size: number;
  mimeType?: string;
  createdAt: Date;
  modifiedAt: Date;
  parentId?: string;
  path: string;
  downloadUrl?: string;
  thumbnailUrl?: string;
  isShared: boolean;
  tags: string[];
  metadata?: Record<string, any>;
}

export interface FileUploadProgress {
  fileId: string;
  fileName: string;
  progress: number;
  status: 'uploading' | 'processing' | 'completed' | 'failed';
  error?: string;
}

export interface FileManagerState {
  files: FileItem[];
  currentFolder: string | null;
  selectedFiles: string[];
  uploadProgress: FileUploadProgress[];
  isLoading: boolean;
  viewMode: 'grid' | 'list';
  sortBy: 'name' | 'size' | 'created' | 'modified';
  sortOrder: 'asc' | 'desc';
  searchQuery: string;
  showHidden: boolean;
  totalStorage: number;
  usedStorage: number;
}

export interface FileFilter {
  type?: 'image' | 'document' | 'video' | 'audio' | 'archive';
  size?: { min?: number; max?: number };
  dateRange?: { start?: Date; end?: Date };
  tags?: string[];
}

export class FileManagerService {
  private listeners: Set<(state: FileManagerState) => void> = new Set();
  private state: FileManagerState;
  private maxFileSize = 100 * 1024 * 1024; // 100MB
  private allowedTypes = [
    'image/jpeg',
    'image/png',
    'image/gif',
    'image/webp',
    'application/pdf',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'text/plain',
    'text/csv',
    'application/json',
    'video/mp4',
    'video/avi',
    'video/mov',
    'audio/mp3',
    'audio/wav',
    'audio/ogg',
  ];

  constructor() {
    this.state = {
      files: [],
      currentFolder: null,
      selectedFiles: [],
      uploadProgress: [],
      isLoading: false,
      viewMode: 'grid',
      sortBy: 'name',
      sortOrder: 'asc',
      searchQuery: '',
      showHidden: false,
      totalStorage: 10 * 1024 * 1024 * 1024, // 10GB
      usedStorage: 0,
    };

    this.loadFiles();
    this.loadUserPreferences();
  }

  private async loadFiles(): Promise<void> {
    this.updateState({ ...this.state, isLoading: true });

    try {
      // In a real app, this would be an API call
      const sampleFiles: FileItem[] = [
        {
          id: 'folder_1',
          name: 'Documents',
          type: 'folder',
          size: 0,
          createdAt: new Date('2024-01-15'),
          modifiedAt: new Date('2024-12-01'),
          path: '/Documents',
          isShared: false,
          tags: ['work'],
        },
        {
          id: 'folder_2',
          name: 'Images',
          type: 'folder',
          size: 0,
          createdAt: new Date('2024-02-10'),
          modifiedAt: new Date('2024-11-28'),
          path: '/Images',
          isShared: true,
          tags: ['media'],
        },
        {
          id: 'file_1',
          name: 'resume.pdf',
          type: 'file',
          size: 245760, // 240KB
          mimeType: 'application/pdf',
          createdAt: new Date('2024-11-15'),
          modifiedAt: new Date('2024-11-15'),
          path: '/Documents/resume.pdf',
          parentId: 'folder_1',
          downloadUrl: '/api/files/file_1/download',
          isShared: false,
          tags: ['career', 'important'],
        },
        {
          id: 'file_2',
          name: 'profile-photo.jpg',
          type: 'file',
          size: 512000, // 500KB
          mimeType: 'image/jpeg',
          createdAt: new Date('2024-10-20'),
          modifiedAt: new Date('2024-10-20'),
          path: '/Images/profile-photo.jpg',
          parentId: 'folder_2',
          downloadUrl: '/api/files/file_2/download',
          thumbnailUrl: '/api/files/file_2/thumbnail',
          isShared: true,
          tags: ['profile', 'photo'],
        },
        {
          id: 'file_3',
          name: 'project-proposal.docx',
          type: 'file',
          size: 1024000, // 1MB
          mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
          createdAt: new Date('2024-12-05'),
          modifiedAt: new Date('2024-12-07'),
          path: '/Documents/project-proposal.docx',
          parentId: 'folder_1',
          downloadUrl: '/api/files/file_3/download',
          isShared: false,
          tags: ['work', 'proposal'],
        },
      ];

      const usedStorage = sampleFiles
        .filter(f => f.type === 'file')
        .reduce((total, file) => total + file.size, 0);

      this.updateState({
        ...this.state,
        files: sampleFiles,
        usedStorage,
        isLoading: false,
      });
    } catch (error) {
      console.error('Failed to load files:', error);
      this.updateState({ ...this.state, isLoading: false });
    }
  }

  private loadUserPreferences(): void {
    try {
      const stored = localStorage.getItem('file_manager_preferences');
      if (stored) {
        const prefs = JSON.parse(stored);
        this.updateState({
          ...this.state,
          viewMode: prefs.viewMode || this.state.viewMode,
          sortBy: prefs.sortBy || this.state.sortBy,
          sortOrder: prefs.sortOrder || this.state.sortOrder,
          showHidden: prefs.showHidden || this.state.showHidden,
        });
      }
    } catch (error) {
      console.error('Failed to load user preferences:', error);
    }
  }

  private saveUserPreferences(): void {
    try {
      const prefs = {
        viewMode: this.state.viewMode,
        sortBy: this.state.sortBy,
        sortOrder: this.state.sortOrder,
        showHidden: this.state.showHidden,
      };
      localStorage.setItem('file_manager_preferences', JSON.stringify(prefs));
    } catch (error) {
      console.error('Failed to save user preferences:', error);
    }
  }

  navigateToFolder(folderId: string | null): void {
    this.updateState({
      ...this.state,
      currentFolder: folderId,
      selectedFiles: [],
    });
  }

  selectFile(fileId: string, multiSelect: boolean = false): void {
    let selectedFiles: string[];

    if (multiSelect) {
      selectedFiles = this.state.selectedFiles.includes(fileId)
        ? this.state.selectedFiles.filter(id => id !== fileId)
        : [...this.state.selectedFiles, fileId];
    } else {
      selectedFiles = [fileId];
    }

    this.updateState({ ...this.state, selectedFiles });
  }

  selectAllFiles(): void {
    const visibleFiles = this.getFilteredFiles().map(f => f.id);
    this.updateState({ ...this.state, selectedFiles: visibleFiles });
  }

  clearSelection(): void {
    this.updateState({ ...this.state, selectedFiles: [] });
  }

  setViewMode(viewMode: FileManagerState['viewMode']): void {
    this.updateState({ ...this.state, viewMode });
    this.saveUserPreferences();
  }

  setSorting(sortBy: FileManagerState['sortBy'], sortOrder?: FileManagerState['sortOrder']): void {
    const newSortOrder =
      sortOrder ||
      (this.state.sortBy === sortBy && this.state.sortOrder === 'asc' ? 'desc' : 'asc');
    this.updateState({
      ...this.state,
      sortBy,
      sortOrder: newSortOrder,
    });
    this.saveUserPreferences();
  }

  search(query: string): void {
    this.updateState({ ...this.state, searchQuery: query });
  }

  toggleShowHidden(): void {
    const showHidden = !this.state.showHidden;
    this.updateState({ ...this.state, showHidden });
    this.saveUserPreferences();
  }

  async uploadFiles(files: File[]): Promise<void> {
    const validFiles = files.filter(file => this.validateFile(file));

    if (validFiles.length === 0) {
      throw new Error('No valid files to upload');
    }

    const uploadProgress: FileUploadProgress[] = validFiles.map(file => ({
      fileId: `upload_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      fileName: file.name,
      progress: 0,
      status: 'uploading',
    }));

    this.updateState({
      ...this.state,
      uploadProgress: [...this.state.uploadProgress, ...uploadProgress],
    });

    // Simulate file uploads
    const uploadPromises = validFiles.map((file, index) =>
      this.simulateFileUpload(file, uploadProgress[index])
    );

    try {
      await Promise.all(uploadPromises);
    } catch (error) {
      console.error('Upload failed:', error);
    }
  }

  private validateFile(file: File): boolean {
    if (file.size > this.maxFileSize) {
      console.error(`File ${file.name} is too large (max ${this.maxFileSize / 1024 / 1024}MB)`);
      return false;
    }

    if (!this.allowedTypes.includes(file.type)) {
      console.error(`File type ${file.type} is not allowed`);
      return false;
    }

    return true;
  }

  private async simulateFileUpload(file: File, progressInfo: FileUploadProgress): Promise<void> {
    return new Promise((resolve, reject) => {
      let progress = 0;
      const interval = setInterval(() => {
        progress += Math.random() * 20;

        if (progress >= 100) {
          progress = 100;
          clearInterval(interval);

          // Create file item
          const fileItem: FileItem = {
            id: progressInfo.fileId,
            name: file.name,
            type: 'file',
            size: file.size,
            mimeType: file.type,
            createdAt: new Date(),
            modifiedAt: new Date(),
            path: `/${file.name}`,
            parentId: this.state.currentFolder || undefined,
            downloadUrl: `/api/files/${progressInfo.fileId}/download`,
            isShared: false,
            tags: [],
          };

          // Add thumbnail for images
          if (file.type.startsWith('image/')) {
            fileItem.thumbnailUrl = `/api/files/${progressInfo.fileId}/thumbnail`;
          }

          // Update state
          const files = [...this.state.files, fileItem];
          const usedStorage = this.state.usedStorage + file.size;
          const uploadProgress = this.state.uploadProgress.filter(
            up => up.fileId !== progressInfo.fileId
          );

          this.updateState({
            ...this.state,
            files,
            usedStorage,
            uploadProgress,
          });

          resolve();
        } else {
          // Update progress
          const uploadProgress = this.state.uploadProgress.map(up =>
            up.fileId === progressInfo.fileId ? { ...up, progress } : up
          );

          this.updateState({ ...this.state, uploadProgress });
        }
      }, 100);

      // Simulate occasional failures
      if (Math.random() < 0.1) {
        setTimeout(() => {
          clearInterval(interval);
          const uploadProgress = this.state.uploadProgress.map(up =>
            up.fileId === progressInfo.fileId
              ? { ...up, status: 'failed' as const, error: 'Upload failed' }
              : up
          );
          this.updateState({ ...this.state, uploadProgress });
          reject(new Error('Upload failed'));
        }, 2000);
      }
    });
  }

  createFolder(name: string): void {
    const folder: FileItem = {
      id: `folder_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      name,
      type: 'folder',
      size: 0,
      createdAt: new Date(),
      modifiedAt: new Date(),
      path: this.state.currentFolder ? `${this.getCurrentFolderPath()}/${name}` : `/${name}`,
      parentId: this.state.currentFolder || undefined,
      isShared: false,
      tags: [],
    };

    const files = [...this.state.files, folder];
    this.updateState({ ...this.state, files });
  }

  deleteFiles(fileIds: string[]): void {
    const filesToDelete = this.state.files.filter(f => fileIds.includes(f.id));
    const deletedSize = filesToDelete
      .filter(f => f.type === 'file')
      .reduce((total, file) => total + file.size, 0);

    const files = this.state.files.filter(f => !fileIds.includes(f.id));
    const usedStorage = this.state.usedStorage - deletedSize;
    const selectedFiles = this.state.selectedFiles.filter(id => !fileIds.includes(id));

    this.updateState({
      ...this.state,
      files,
      usedStorage,
      selectedFiles,
    });
  }

  renameFile(fileId: string, newName: string): void {
    const files = this.state.files.map(file => {
      if (file.id === fileId) {
        const pathParts = file.path.split('/');
        pathParts[pathParts.length - 1] = newName;
        return {
          ...file,
          name: newName,
          path: pathParts.join('/'),
          modifiedAt: new Date(),
        };
      }
      return file;
    });

    this.updateState({ ...this.state, files });
  }

  moveFiles(fileIds: string[], targetFolderId: string | null): void {
    const targetFolder = targetFolderId
      ? this.state.files.find(f => f.id === targetFolderId)
      : null;

    const files = this.state.files.map(file => {
      if (fileIds.includes(file.id)) {
        const fileName = file.name;
        const newPath = targetFolder ? `${targetFolder.path}/${fileName}` : `/${fileName}`;

        return {
          ...file,
          parentId: targetFolderId || undefined,
          path: newPath,
          modifiedAt: new Date(),
        };
      }
      return file;
    });

    this.updateState({ ...this.state, files });
  }

  shareFiles(fileIds: string[], isShared: boolean): void {
    const files = this.state.files.map(file =>
      fileIds.includes(file.id) ? { ...file, isShared, modifiedAt: new Date() } : file
    );

    this.updateState({ ...this.state, files });
  }

  addTags(fileIds: string[], tags: string[]): void {
    const files = this.state.files.map(file => {
      if (fileIds.includes(file.id)) {
        const newTags = [...new Set([...file.tags, ...tags])];
        return { ...file, tags: newTags, modifiedAt: new Date() };
      }
      return file;
    });

    this.updateState({ ...this.state, files });
  }

  removeTags(fileIds: string[], tags: string[]): void {
    const files = this.state.files.map(file => {
      if (fileIds.includes(file.id)) {
        const newTags = file.tags.filter(tag => !tags.includes(tag));
        return { ...file, tags: newTags, modifiedAt: new Date() };
      }
      return file;
    });

    this.updateState({ ...this.state, files });
  }

  getFilteredFiles(filter?: FileFilter): FileItem[] {
    let files = this.state.files.filter(file => {
      // Filter by current folder
      if (this.state.currentFolder) {
        return file.parentId === this.state.currentFolder;
      } else {
        return !file.parentId;
      }
    });

    // Apply search filter
    if (this.state.searchQuery) {
      const query = this.state.searchQuery.toLowerCase();
      files = files.filter(
        file =>
          file.name.toLowerCase().includes(query) ||
          file.tags.some(tag => tag.toLowerCase().includes(query))
      );
    }

    // Apply additional filters
    if (filter) {
      if (filter.type) {
        files = files.filter(file => {
          if (file.type === 'folder') return false;
          if (!file.mimeType) return false;

          switch (filter.type) {
            case 'image':
              return file.mimeType.startsWith('image/');
            case 'document':
              return [
                'application/pdf',
                'application/msword',
                'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                'text/plain',
              ].includes(file.mimeType);
            case 'video':
              return file.mimeType.startsWith('video/');
            case 'audio':
              return file.mimeType.startsWith('audio/');
            default:
              return true;
          }
        });
      }

      if (filter.size) {
        files = files.filter(file => {
          if (filter.size!.min && file.size < filter.size!.min) return false;
          if (filter.size!.max && file.size > filter.size!.max) return false;
          return true;
        });
      }

      if (filter.tags && filter.tags.length > 0) {
        files = files.filter(file => filter.tags!.some(tag => file.tags.includes(tag)));
      }
    }

    // Sort files
    files.sort((a, b) => {
      let comparison = 0;

      // Folders first
      if (a.type === 'folder' && b.type === 'file') return -1;
      if (a.type === 'file' && b.type === 'folder') return 1;

      switch (this.state.sortBy) {
        case 'name':
          comparison = a.name.localeCompare(b.name);
          break;
        case 'size':
          comparison = a.size - b.size;
          break;
        case 'created':
          comparison = a.createdAt.getTime() - b.createdAt.getTime();
          break;
        case 'modified':
          comparison = a.modifiedAt.getTime() - b.modifiedAt.getTime();
          break;
      }

      return this.state.sortOrder === 'desc' ? -comparison : comparison;
    });

    return files;
  }

  getCurrentFolderPath(): string {
    if (!this.state.currentFolder) return '/';

    const folder = this.state.files.find(f => f.id === this.state.currentFolder);
    return folder ? folder.path : '/';
  }

  getBreadcrumbs(): Array<{ id: string | null; name: string }> {
    const breadcrumbs = [{ id: null, name: 'Root' }];

    if (this.state.currentFolder) {
      const folder = this.state.files.find(f => f.id === this.state.currentFolder);
      if (folder) {
        const pathParts = folder.path.split('/').filter(Boolean);
        pathParts.forEach((part, index) => {
          // Find folder by path
          const folderPath = '/' + pathParts.slice(0, index + 1).join('/');
          const folderItem = this.state.files.find(
            f => f.path === folderPath && f.type === 'folder'
          );
          breadcrumbs.push({
            id: folderItem?.id || null,
            name: part,
          });
        });
      }
    }

    return breadcrumbs;
  }

  getStorageUsagePercentage(): number {
    return (this.state.usedStorage / this.state.totalStorage) * 100;
  }

  formatFileSize(bytes: number): string {
    if (bytes === 0) return '0 Bytes';

    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));

    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }

  getAllTags(): string[] {
    const tags = new Set<string>();
    this.state.files.forEach(file => {
      file.tags.forEach(tag => tags.add(tag));
    });
    return Array.from(tags).sort();
  }

  getFilesByType(): Record<string, number> {
    const counts = {
      folders: 0,
      images: 0,
      documents: 0,
      videos: 0,
      audio: 0,
      other: 0,
    };

    this.state.files.forEach(file => {
      if (file.type === 'folder') {
        counts.folders++;
      } else if (file.mimeType) {
        if (file.mimeType.startsWith('image/')) counts.images++;
        else if (file.mimeType.startsWith('video/')) counts.videos++;
        else if (file.mimeType.startsWith('audio/')) counts.audio++;
        else if (
          ['application/pdf', 'application/msword', 'text/plain'].some(type =>
            file.mimeType!.includes(type)
          )
        ) {
          counts.documents++;
        } else {
          counts.other++;
        }
      }
    });

    return counts;
  }

  getState(): FileManagerState {
    return { ...this.state };
  }

  subscribe(listener: (state: FileManagerState) => void): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private updateState(newState: FileManagerState): void {
    this.state = newState;
    this.listeners.forEach(listener => listener(this.state));
  }

  destroy(): void {
    this.listeners.clear();
  }
}
