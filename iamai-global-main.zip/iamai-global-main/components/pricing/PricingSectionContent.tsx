import React from 'react';
import type { Page } from '../../App';
import { SubscriptionPlanSlug } from '../../constants';

export interface PricingSectionProps {
  onNavigate?: (page: Page) => void;
  onSelectPlan?: (plan: SubscriptionPlanSlug) => void;
}

const PricingSectionContent: React.FC<PricingSectionProps> = ({ onNavigate, onSelectPlan }) => {
  const handlePlanClick = (plan: SubscriptionPlanSlug) => {
    if (onSelectPlan) {
      onSelectPlan(plan);
    } else {
      onNavigate?.('agents');
    }
  };

  return (
    <section className="py-20 md:py-28 bg-black text-white" id="pricing">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">Simple Pricing, Maximum Value</h2>
          <p className="text-xl text-gray-400">Choose the perfect plan for your AI journey</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Daily Plan */}
          <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-8 flex flex-col hover:border-cyan-500/50 transition-colors">
            <h3 className="text-2xl font-bold mb-2">Daily Plan</h3>
            <p className="text-gray-400 mb-6">Pay as you go</p>
            <div className="mb-2">
              <span className="text-5xl font-bold">$1</span>
              <span className="text-xl text-gray-400">/day</span>
            </div>
            <p className="text-sm text-gray-500 mb-6">Per agent • Unlimited everything</p>
            <ul className="space-y-3 mb-8 flex-grow">
              <li className="flex items-center text-gray-300">
                <span className="text-cyan-400 mr-3">✓</span>
                Unlimited messages
              </li>
              <li className="flex items-center text-gray-300">
                <span className="text-cyan-400 mr-3">✓</span>
                Full agent access
              </li>
              <li className="flex items-center text-gray-300">
                <span className="text-cyan-400 mr-3">✓</span>
                All features included
              </li>
              <li className="flex items-center text-gray-300">
                <span className="text-cyan-400 mr-3">✓</span>
                Priority support
              </li>
            </ul>
            <button
              onClick={() => handlePlanClick('daily')}
              className="w-full bg-gray-800 hover:bg-gray-700 text-white py-3 rounded-lg transition-colors font-semibold"
            >
              Get Started
            </button>
          </div>

          {/* Weekly Plan */}
          <div className="bg-gradient-to-b from-cyan-500/10 to-purple-500/10 border border-cyan-500/50 rounded-2xl p-8 flex flex-col relative">
            <div className="absolute top-0 right-0 bg-cyan-500 text-black px-4 py-1 rounded-bl-xl text-sm font-bold">
              POPULAR
            </div>
            <h3 className="text-2xl font-bold mb-2">Weekly Plan</h3>
            <p className="text-gray-400 mb-6">Best value</p>
            <div className="mb-2">
              <span className="text-5xl font-bold">$5</span>
              <span className="text-xl text-gray-400">/week</span>
            </div>
            <p className="text-sm text-gray-500 mb-6">Per agent • Unlimited everything</p>
            <ul className="space-y-3 mb-8 flex-grow">
              <li className="flex items-center text-gray-300">
                <span className="text-cyan-400 mr-3">✓</span>
                Unlimited messages
              </li>
              <li className="flex items-center text-gray-300">
                <span className="text-cyan-400 mr-3">✓</span>
                Full agent access
              </li>
              <li className="flex items-center text-gray-300">
                <span className="text-cyan-400 mr-3">✓</span>
                All features included
              </li>
              <li className="flex items-center text-gray-300">
                <span className="text-cyan-400 mr-3">✓</span>
                Priority support
              </li>
            </ul>
            <button
              onClick={() => handlePlanClick('weekly')}
              className="w-full bg-cyan-500 hover:bg-cyan-600 text-black py-3 rounded-lg transition-colors font-semibold"
            >
              Get Started
            </button>
          </div>

          {/* Monthly Plan */}
          <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-8 flex flex-col hover:border-cyan-500/50 transition-colors">
            <h3 className="text-2xl font-bold mb-2">Monthly Plan</h3>
            <p className="text-gray-400 mb-6">Long-term commitment</p>
            <div className="mb-2">
              <span className="text-5xl font-bold">$19</span>
              <span className="text-xl text-gray-400">/month</span>
            </div>
            <p className="text-sm text-gray-500 mb-6">Per agent • Unlimited everything</p>
            <ul className="space-y-3 mb-8 flex-grow">
              <li className="flex items-center text-gray-300">
                <span className="text-cyan-400 mr-3">✓</span>
                Unlimited messages
              </li>
              <li className="flex items-center text-gray-300">
                <span className="text-cyan-400 mr-3">✓</span>
                Full agent access
              </li>
              <li className="flex items-center text-gray-300">
                <span className="text-cyan-400 mr-3">✓</span>
                All features included
              </li>
              <li className="flex items-center text-gray-300">
                <span className="text-cyan-400 mr-3">✓</span>
                Priority support
              </li>
            </ul>
            <button
              onClick={() => handlePlanClick('monthly')}
              className="w-full bg-gray-800 hover:bg-gray-700 text-white py-3 rounded-lg transition-colors font-semibold"
            >
              Get Started
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default PricingSectionContent;
