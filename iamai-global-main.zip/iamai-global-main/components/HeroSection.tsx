

import React from 'react';
import { Page } from '../App';

interface HeroSectionProps {
  onNavigate: (page: Page) => void;
}

const HeroSection: React.FC<HeroSectionProps> = ({ onNavigate }) => {
  return (
    <section className="relative overflow-hidden bg-black text-white py-20 md:py-32">
        <div className="absolute inset-0 bg-grid-gray-900 [mask-image:linear-gradient(to_bottom,white,transparent)]"></div>
         <div 
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] md:w-[800px] md:h-[800px] bg-cyan-500/20 rounded-full blur-3xl"
         ></div>
      <div className="container mx-auto px-6 text-center relative z-10">
        <h1 className="text-4xl md:text-6xl lg:text-7xl font-extrabold tracking-tight mb-4 bg-clip-text text-transparent bg-gradient-to-b from-white to-gray-400">
          Meet Your Specialized AI Agents
        </h1>
        <p className="max-w-3xl mx-auto text-lg md:text-xl text-gray-400 mb-8">
          Beyond generic assistants. IA M AI provides a platform of character-driven agents, each an expert in their role, ready to revolutionize your workflow.
        </p>
        <div className="flex justify-center space-x-4">
          <a
            href="#agents"
            title="Scroll down to see the list of available agents"
            className="bg-cyan-500 text-black font-semibold px-8 py-3 rounded-full hover:bg-cyan-400 transition-all duration-300 transform hover:scale-105"
          >
            Explore Agents
          </a>
          <button
            onClick={() => onNavigate('documentation')}
            title="View our developer documentation"
            className="bg-gray-800/50 text-white font-semibold px-8 py-3 rounded-full border border-gray-700 hover:bg-gray-700 transition-all duration-300 transform hover:scale-105"
          >
            Read the Docs
          </button>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;