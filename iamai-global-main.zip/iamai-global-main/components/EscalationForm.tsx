/**
 * Escalation Form Component
 * Collects additional information, auto-summarizes problems, generates ticket IDs
 * Integrates with email system to send to support@
 * Sets 48-hour response expectation
 */

import React, { useState } from 'react';
import { Send, AlertCircle, CheckCircle, Clock, FileText, Mail } from 'lucide-react';

interface EscalationFormProps {
  ticketId: string;
  category: string;
  severity: 'high' | 'medium' | 'low';
  userMessage: string;
  userEmail: string;
  onSubmit: (escalationData: EscalationData) => void;
  onCancel: () => void;
}

interface EscalationData {
  ticketId: string;
  category: string;
  severity: 'high' | 'medium' | 'low';
  subject: string;
  description: string;
  additionalInfo: string;
  attachments: File[];
  priority: 'urgent' | 'high' | 'normal';
  expectedResolution: string;
}

const EscalationForm: React.FC<EscalationFormProps> = ({
  ticketId,
  category,
  severity,
  userMessage,
  userEmail,
  onSubmit,
  onCancel,
}) => {
  const [formData, setFormData] = useState({
    subject: '',
    description: userMessage,
    additionalInfo: '',
    attachments: [] as File[],
    priority: severity === 'high' ? ('urgent' as const) : ('normal' as const),
  });

  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  /**
   * Validate form data
   */
  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!formData.subject.trim()) {
      newErrors.subject = 'Subject is required';
    }

    if (!formData.description.trim()) {
      newErrors.description = 'Description is required';
    }

    if (formData.subject.length < 5) {
      newErrors.subject = 'Subject must be at least 5 characters';
    }

    if (formData.description.length < 20) {
      newErrors.description = 'Description must be at least 20 characters';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  /**
   * Handle form submission
   */
  const handleSubmit = async (e: React.FormEvent): Promise<void> => {
    e.preventDefault();

    if (!validateForm()) return;

    try {
      setSubmitting(true);

      const escalationData: EscalationData = {
        ticketId,
        category,
        severity,
        subject: formData.subject,
        description: formData.description,
        additionalInfo: formData.additionalInfo,
        attachments: formData.attachments,
        priority: formData.priority,
        expectedResolution: getExpectedResolutionTime(),
      };

      // Submit to backend
      const response = await fetch('/api/support/escalate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          ...escalationData,
          userEmail,
          attachmentCount: formData.attachments.length,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to escalate ticket');
      }

      setSubmitted(true);
      setTimeout(() => {
        onSubmit(escalationData);
      }, 2000);
    } catch (error) {
      console.error('[EscalationForm] Error submitting:', error);
      setErrors({ submit: 'Failed to submit ticket. Please try again.' });
    } finally {
      setSubmitting(false);
    }
  };

  /**
   * Get expected resolution time based on severity
   */
  const getExpectedResolutionTime = (): string => {
    const times = {
      urgent: '2-4 hours',
      high: '4-8 hours',
      normal: '24-48 hours',
    };
    return times[formData.priority];
  };

  /**
   * Handle input change
   */
  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ): void => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value,
    }));
    // Clear error for this field
    if (errors[name]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[name];
        return newErrors;
      });
    }
  };

  /**
   * Handle file upload
   */
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>): void => {
    const files = e.currentTarget.files;
    if (files) {
      setFormData(prev => ({
        ...prev,
        attachments: [...prev.attachments, ...Array.from(files)],
      }));
    }
  };

  /**
   * Remove attachment
   */
  const removeAttachment = (index: number): void => {
    setFormData(prev => ({
      ...prev,
      attachments: prev.attachments.filter((_, i) => i !== index),
    }));
  };

  if (submitted) {
    return (
      <div className="bg-gradient-to-br from-green-500/10 to-emerald-500/10 border border-green-500/30 rounded-lg p-6">
        <div className="text-center">
          <div className="flex justify-center mb-4">
            <div className="p-3 bg-green-500/20 rounded-lg">
              <CheckCircle className="w-8 h-8 text-green-400" />
            </div>
          </div>

          <h3 className="text-xl font-bold text-white mb-2">Ticket Submitted!</h3>

          <div className="bg-black/50 border border-green-500/20 rounded-lg p-4 mb-4">
            <p className="text-sm text-gray-300 mb-2">Your ticket ID:</p>
            <p className="font-mono text-lg text-cyan-400 font-semibold">{ticketId}</p>
            <p className="text-xs text-gray-400 mt-2">Save this ID to track your support request</p>
          </div>

          <div className="space-y-3 mb-4">
            <div className="flex items-center gap-3 text-sm text-gray-300">
              <Mail className="w-4 h-4 text-cyan-400" />
              <span>Confirmation email sent to {userEmail}</span>
            </div>

            <div className="flex items-center gap-3 text-sm text-gray-300">
              <Clock className="w-4 h-4 text-cyan-400" />
              <span>Expected response within 48 hours</span>
            </div>

            <div className="flex items-center gap-3 text-sm text-gray-300">
              <AlertCircle className="w-4 h-4 text-cyan-400" />
              <span>Severity: {severity.toUpperCase()}</span>
            </div>
          </div>

          <p className="text-xs text-gray-400 mb-4">
            Our support team will review your issue and get back to you as soon as possible.
          </p>

          <button
            onClick={onCancel}
            className="w-full px-4 py-2 bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-400 border border-cyan-500/30 rounded font-medium transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    );
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="bg-gray-900/50 border border-gray-700/50 rounded-lg p-5 space-y-4"
    >
      {/* Ticket Info */}
      <div className="bg-black/50 border border-cyan-500/20 rounded-lg p-3">
        <div className="grid grid-cols-2 gap-3 text-xs">
          <div>
            <p className="text-gray-400">Ticket ID</p>
            <p className="font-mono text-cyan-400 font-semibold text-sm">{ticketId}</p>
          </div>
          <div>
            <p className="text-gray-400">Priority</p>
            <p className="text-sm">
              {severity === 'high' ? (
                <span className="text-red-400 font-semibold">🔴 Urgent</span>
              ) : severity === 'medium' ? (
                <span className="text-yellow-400 font-semibold">🟡 High</span>
              ) : (
                <span className="text-green-400 font-semibold">🟢 Normal</span>
              )}
            </p>
          </div>
          <div className="col-span-2">
            <p className="text-gray-400">Expected Response</p>
            <p className="text-sm text-cyan-400">{getExpectedResolutionTime()}</p>
          </div>
        </div>
      </div>

      {/* Subject */}
      <div>
        <label className="block text-sm font-medium text-white mb-2">
          Subject <span className="text-red-500">*</span>
        </label>
        <input
          type="text"
          name="subject"
          value={formData.subject}
          onChange={handleInputChange}
          placeholder="Brief description of your issue"
          className={`w-full px-3 py-2 bg-black/50 border rounded font-medium text-white placeholder-gray-500 focus:outline-none transition-colors ${
            errors.subject
              ? 'border-red-500/50 focus:border-red-500'
              : 'border-gray-700/50 focus:border-cyan-500'
          }`}
        />
        {errors.subject && <p className="text-xs text-red-400 mt-1">{errors.subject}</p>}
      </div>

      {/* Description */}
      <div>
        <label className="block text-sm font-medium text-white mb-2">
          Detailed Description <span className="text-red-500">*</span>
        </label>
        <textarea
          name="description"
          value={formData.description}
          onChange={handleInputChange}
          placeholder="Provide detailed information about your issue..."
          rows={4}
          className={`w-full px-3 py-2 bg-black/50 border rounded text-white placeholder-gray-500 focus:outline-none transition-colors resize-none ${
            errors.description
              ? 'border-red-500/50 focus:border-red-500'
              : 'border-gray-700/50 focus:border-cyan-500'
          }`}
        />
        {errors.description && <p className="text-xs text-red-400 mt-1">{errors.description}</p>}
        <p className="text-xs text-gray-400 mt-1">
          {formData.description.length} / 2000 characters
        </p>
      </div>

      {/* Additional Info */}
      <div>
        <label className="block text-sm font-medium text-white mb-2">Additional Information</label>
        <textarea
          name="additionalInfo"
          value={formData.additionalInfo}
          onChange={handleInputChange}
          placeholder="Error messages, screenshots, steps to reproduce, etc."
          rows={3}
          className="w-full px-3 py-2 bg-black/50 border border-gray-700/50 rounded text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500 transition-colors resize-none"
        />
      </div>

      {/* File Upload */}
      <div>
        <label className="block text-sm font-medium text-white mb-2">Attachments (Optional)</label>
        <div className="border-2 border-dashed border-gray-700/50 rounded-lg p-4 hover:border-gray-600 transition-colors">
          <input
            type="file"
            multiple
            onChange={handleFileUpload}
            className="hidden"
            id="file-upload"
            accept=".txt,.png,.jpg,.jpeg,.pdf,.doc,.docx"
          />
          <label
            htmlFor="file-upload"
            className="flex items-center justify-center cursor-pointer gap-2 text-gray-400 hover:text-gray-300 transition-colors"
          >
            <FileText className="w-4 h-4" />
            <span className="text-sm">Click to upload or drag files</span>
          </label>
          <p className="text-xs text-gray-500 text-center mt-2">
            Max 5MB per file (images, docs, logs)
          </p>
        </div>

        {/* Attached Files */}
        {formData.attachments.length > 0 && (
          <div className="mt-3 space-y-2">
            {formData.attachments.map((file, index) => (
              <div
                key={index}
                className="flex items-center justify-between bg-black/50 border border-gray-700/50 rounded p-2"
              >
                <div className="flex items-center gap-2">
                  <FileText className="w-4 h-4 text-cyan-400" />
                  <span className="text-sm text-gray-300">{file.name}</span>
                  <span className="text-xs text-gray-500">
                    ({(file.size / 1024).toFixed(1)} KB)
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => removeAttachment(index)}
                  className="text-gray-500 hover:text-red-400 transition-colors"
                >
                  ×
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Priority */}
      <div>
        <label className="block text-sm font-medium text-white mb-2">Priority</label>
        <select
          name="priority"
          value={formData.priority}
          onChange={handleInputChange}
          className="w-full px-3 py-2 bg-black/50 border border-gray-700/50 rounded text-white focus:outline-none focus:border-cyan-500 transition-colors"
        >
          <option value="normal">🟢 Normal (24-48 hours)</option>
          <option value="high">🟡 High (4-8 hours)</option>
          <option value="urgent">🔴 Urgent (2-4 hours)</option>
        </select>
      </div>

      {/* Error Message */}
      {errors.submit && (
        <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-3">
          <p className="text-sm text-red-400 flex items-center gap-2">
            <AlertCircle className="w-4 h-4" />
            {errors.submit}
          </p>
        </div>
      )}

      {/* Actions */}
      <div className="flex gap-3 pt-4">
        <button
          type="submit"
          disabled={submitting}
          className="flex-1 px-4 py-2 bg-cyan-500 hover:bg-cyan-600 text-black font-semibold rounded transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
        >
          {submitting ? (
            <>
              <div className="w-4 h-4 border-2 border-transparent border-t-black rounded-full animate-spin"></div>
              Submitting...
            </>
          ) : (
            <>
              <Send className="w-4 h-4" />
              Submit Ticket
            </>
          )}
        </button>
        <button
          type="button"
          onClick={onCancel}
          disabled={submitting}
          className="px-4 py-2 bg-gray-800 hover:bg-gray-700 text-white font-semibold rounded transition-colors disabled:opacity-50"
        >
          Cancel
        </button>
      </div>

      <p className="text-xs text-gray-400 text-center pt-2">
        A confirmation email will be sent to {userEmail}
      </p>
    </form>
  );
};

export default EscalationForm;
