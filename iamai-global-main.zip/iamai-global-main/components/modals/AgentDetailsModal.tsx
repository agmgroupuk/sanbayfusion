import React, { useEffect } from 'react';
import { X } from 'lucide-react';

export interface AgentDetailsData {
  name: string;
  role: string;
  description: string;
  icon?: string;
  category?: string;
  overview: string;
  capabilities: string[];
  features: string[];
  howItWorks: string[];
  benefits: string[];
  useCases?: string[];
  keyStrengths?: string[];
  bestFor?: string;
}

interface AgentDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  agent: AgentDetailsData | null;
}

const AgentDetailsModal: React.FC<AgentDetailsModalProps> = ({ isOpen, onClose, agent }) => {
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }

    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  if (!isOpen || !agent) return null;

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 transition-opacity"
        onClick={onClose}
      />

      {/* Modal */}
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-y-auto">
        <div className="bg-gray-900 border border-gray-800 rounded-2xl shadow-2xl w-full max-w-2xl my-8">
          {/* Header with Close Button */}
          <div className="sticky top-0 bg-gradient-to-r from-gray-900 to-gray-800 border-b border-gray-800 px-8 py-6 flex items-center justify-between rounded-t-2xl">
            <div className="flex items-center gap-4">
              {agent.icon && agent.icon.startsWith('fa-') ? (
                <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-cyan-500/20 to-blue-500/20 border border-cyan-500/30 flex items-center justify-center">
                  <i className={`${agent.icon} text-cyan-400 text-2xl`}></i>
                </div>
              ) : agent.icon && agent.icon.startsWith('data:image') ? (
                <img
                  src={agent.icon}
                  alt={agent.name}
                  className="w-12 h-12 rounded-lg object-cover border border-cyan-500/30"
                />
              ) : (
                <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-cyan-500/20 to-blue-500/20 border border-cyan-500/30 flex items-center justify-center">
                  <i className="fa-solid fa-robot text-cyan-400 text-2xl"></i>
                </div>
              )}
              <div>
                <h2 className="text-2xl font-bold text-white">{agent.name}</h2>
                <p className="text-sm text-cyan-400 font-medium">{agent.role}</p>
              </div>
            </div>
            <button
              onClick={onClose}
              title="Close modal"
              className="p-2 hover:bg-gray-700/50 rounded-lg transition-colors text-gray-400 hover:text-white"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Scrollable Content */}
          <div className="overflow-y-auto max-h-[calc(100vh-300px)] px-8 py-6 space-y-6">
            {/* Category Badge */}
            {agent.category && (
              <div className="flex items-center gap-2">
                <span className="inline-flex items-center gap-2 px-3 py-1 bg-cyan-500/10 text-cyan-400 text-xs font-semibold rounded-full border border-cyan-500/20">
                  <i className="fa-solid fa-tag"></i>
                  {agent.category}
                </span>
              </div>
            )}

            {/* Overview Section */}
            <div className="bg-gray-800/30 border border-gray-700 rounded-xl p-4">
              <h3 className="text-lg font-bold text-white mb-3">Overview</h3>
              <p className="text-gray-300 leading-relaxed">{agent.overview || agent.description}</p>
            </div>

            {/* Best For Section */}
            {agent.bestFor && (
              <div className="bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border border-cyan-500/20 rounded-xl p-4">
                <h3 className="text-lg font-bold text-white mb-2">Best For</h3>
                <p className="text-cyan-300">{agent.bestFor}</p>
              </div>
            )}

            {/* Key Capabilities Section */}
            {agent.capabilities && agent.capabilities.length > 0 && (
              <div>
                <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                  <i className="fa-solid fa-star text-yellow-400"></i>
                  Key Capabilities
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {agent.capabilities.map((capability, idx) => (
                    <div key={idx} className="flex items-start gap-3 bg-gray-800/30 rounded-lg p-3 border border-gray-700">
                      <span className="flex-shrink-0 w-6 h-6 rounded-full bg-cyan-500/20 flex items-center justify-center mt-0.5">
                        <span className="w-2 h-2 rounded-full bg-cyan-400"></span>
                      </span>
                      <span className="text-gray-300">{capability}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Features Section */}
            {agent.features && agent.features.length > 0 && (
              <div>
                <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                  <i className="fa-solid fa-rocket text-green-400"></i>
                  Features
                </h3>
                <ul className="space-y-2">
                  {agent.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-3 text-gray-300">
                      <span className="flex-shrink-0 w-5 h-5 rounded-full bg-green-500/20 flex items-center justify-center mt-0.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-green-400"></span>
                      </span>
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* How It Works Section */}
            {agent.howItWorks && agent.howItWorks.length > 0 && (
              <div>
                <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                  <i className="fa-solid fa-gears text-blue-400"></i>
                  How It Works
                </h3>
                <div className="space-y-3">
                  {agent.howItWorks.map((step, idx) => (
                    <div key={idx} className="flex gap-4">
                      <div className="flex-shrink-0">
                        <div className="flex items-center justify-center w-8 h-8 rounded-full bg-blue-500/20 border border-blue-500/50 text-blue-400 font-semibold text-sm">
                          {idx + 1}
                        </div>
                      </div>
                      <div className="flex-1 pt-1">
                        <p className="text-gray-300">{step}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Key Strengths Section */}
            {agent.keyStrengths && agent.keyStrengths.length > 0 && (
              <div>
                <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                  <i className="fa-solid fa-fire text-orange-400"></i>
                  Key Strengths
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  {agent.keyStrengths.map((strength, idx) => (
                    <div
                      key={idx}
                      className="px-4 py-2 bg-orange-500/10 border border-orange-500/30 rounded-lg text-orange-300 text-sm font-medium"
                    >
                      ✓ {strength}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Use Cases Section */}
            {agent.useCases && agent.useCases.length > 0 && (
              <div>
                <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                  <i className="fa-solid fa-lightbulb text-yellow-400"></i>
                  Use Cases
                </h3>
                <ul className="space-y-2">
                  {agent.useCases.map((useCase, idx) => (
                    <li key={idx} className="flex items-start gap-3 text-gray-300">
                      <span className="flex-shrink-0 mt-1">
                        <i className="fa-solid fa-check text-yellow-400"></i>
                      </span>
                      <span>{useCase}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Benefits Section */}
            {agent.benefits && agent.benefits.length > 0 && (
              <div>
                <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                  <i className="fa-solid fa-award text-purple-400"></i>
                  Benefits
                </h3>
                <div className="space-y-2">
                  {agent.benefits.map((benefit, idx) => (
                    <div key={idx} className="flex items-start gap-3 bg-purple-500/10 rounded-lg p-3 border border-purple-500/20">
                      <span className="flex-shrink-0 mt-1">
                        <i className="fa-solid fa-circle-check text-purple-400"></i>
                      </span>
                      <span className="text-gray-300">{benefit}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Footer with Close Button */}
          <div className="sticky bottom-0 bg-gradient-to-r from-gray-900 to-gray-800 border-t border-gray-800 px-8 py-4 flex justify-between items-center rounded-b-2xl">
            <p className="text-sm text-gray-400">
              Ready to get started? Access this agent to begin your journey.
            </p>
            <button
              onClick={onClose}
              title="Close modal"
              className="px-6 py-2 bg-cyan-500 hover:bg-cyan-600 text-black font-semibold rounded-lg transition-all duration-300 flex items-center gap-2"
            >
              <span>Close</span>
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </>
  );
};

export default AgentDetailsModal;
