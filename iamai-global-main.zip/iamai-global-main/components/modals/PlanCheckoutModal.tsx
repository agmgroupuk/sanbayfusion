import React, { useEffect, useMemo, useState } from 'react';
import { Agent, SubscriptionPlanSlug } from '../../constants';
import { ALL_AGENTS } from '../../agents';

interface PlanCheckoutModalProps {
  isOpen: boolean;
  plan: {
    id: SubscriptionPlanSlug;
    name: string;
    price: string;
    cadence: string;
    description: string;
  } | null;
  onClose: () => void;
  onConfirm: (agent: Agent) => void;
}

const PlanCheckoutModal: React.FC<PlanCheckoutModalProps> = ({
  isOpen,
  plan,
  onClose,
  onConfirm,
}) => {
  const [selectedAgentId, setSelectedAgentId] = useState<string>('');
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    if (isOpen && ALL_AGENTS.length > 0) {
      setSelectedAgentId(prev => prev || ALL_AGENTS[0].id);
    }
    if (!isOpen) {
      setSearchTerm('');
    }
  }, [isOpen]);

  const filteredAgents = useMemo(() => {
    if (!searchTerm.trim()) return ALL_AGENTS;
    const term = searchTerm.toLowerCase();
    return ALL_AGENTS.filter(
      agent => agent.name.toLowerCase().includes(term) || agent.role.toLowerCase().includes(term)
    );
  }, [searchTerm]);

  if (!isOpen || !plan) return null;

  const handleConfirm = () => {
    const agent = ALL_AGENTS.find(a => a.id === selectedAgentId);
    if (agent) {
      onConfirm(agent);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 px-4 py-10 backdrop-blur-sm">
      <div className="w-full max-w-4xl bg-gray-950 border border-gray-800 rounded-3xl shadow-2xl shadow-cyan-500/10 overflow-hidden">
        <div className="flex flex-col md:flex-row">
          <div className="md:w-5/12 bg-gradient-to-b from-gray-900 to-gray-950 p-8 border-b md:border-b-0 md:border-r border-gray-800">
            <p className="text-sm uppercase tracking-[0.3em] text-cyan-400 mb-3">Selected Plan</p>
            <h2 className="text-3xl font-bold text-white mb-4">{plan.name}</h2>
            <p className="text-gray-400 mb-6">{plan.description}</p>
            <div className="flex items-end gap-2">
              <span className="text-5xl font-extrabold text-white">{plan.price}</span>
              <span className="text-gray-400 text-xl">{plan.cadence}</span>
            </div>
            <p className="mt-6 text-sm text-gray-500">
              Choose your favorite agent to continue to Stripe checkout. Each agent subscription is
              billed separately.
            </p>
          </div>

          <div className="md:w-7/12 p-8">
            <div className="flex flex-col gap-4 mb-6 sm:flex-row sm:items-center">
              <div className="flex-1 text-left">
                <h3 className="text-lg font-semibold text-white">Select an Agent</h3>
                <p className="text-sm text-gray-500">
                  Switch anytime – each agent has unique skills.
                </p>
              </div>
              <div className="flex-1">
                <input
                  type="search"
                  value={searchTerm}
                  onChange={event => setSearchTerm(event.target.value)}
                  placeholder="Search agents"
                  className="w-full rounded-xl bg-gray-900 border border-gray-800 px-4 py-2 text-sm text-white placeholder:text-gray-500 focus:border-cyan-500 focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-h-80 overflow-y-auto pr-2">
              {filteredAgents.map(agent => {
                const isSelected = agent.id === selectedAgentId;
                return (
                  <button
                    key={agent.id}
                    onClick={() => setSelectedAgentId(agent.id)}
                    className={`flex items-start gap-4 rounded-2xl border p-4 text-left transition-all ${
                      isSelected
                        ? 'border-cyan-500/80 bg-cyan-500/5 shadow-lg shadow-cyan-500/20'
                        : 'border-gray-800 bg-gray-900/40 hover:border-cyan-500/40'
                    }`}
                  >
                    <div className="w-12 h-12 flex items-center justify-center rounded-xl bg-gray-900 text-cyan-400">
                      {agent.icon && agent.icon.startsWith('data:image') ? (
                        <img
                          src={agent.icon}
                          alt={`${agent.name} avatar`}
                          className="w-full h-full rounded-xl object-cover"
                        />
                      ) : (
                        <i className={`${agent.icon} text-2xl`}></i>
                      )}
                    </div>
                    <div className="flex-1">
                      <p className="text-white font-semibold">
                        {agent.name}
                        {isSelected && <span className="ml-2 text-xs text-cyan-400">Selected</span>}
                      </p>
                      <p className="text-sm text-cyan-300">{agent.role}</p>
                      <p className="text-xs text-gray-500 mt-1 line-clamp-2">{agent.description}</p>
                    </div>
                  </button>
                );
              })}
            </div>

            <div className="flex flex-col sm:flex-row gap-3 mt-8">
              <button
                onClick={onClose}
                className="sm:flex-1 px-4 py-3 rounded-xl border border-gray-800 text-gray-400 hover:text-white hover:border-gray-600 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirm}
                disabled={!selectedAgentId}
                className={`sm:flex-1 px-4 py-3 rounded-xl font-semibold transition-colors ${
                  selectedAgentId
                    ? 'bg-cyan-500 text-black hover:bg-cyan-400'
                    : 'bg-gray-700 text-gray-500 cursor-not-allowed'
                }`}
              >
                Continue to Checkout
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PlanCheckoutModal;
