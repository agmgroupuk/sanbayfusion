
import React from 'react';
import { FEATURES, Feature } from '../constants';

const FeatureCard: React.FC<{ feature: Feature }> = ({ feature }) => (
  <div className="bg-transparent p-6 flex items-start space-x-4">
    <div className="flex-shrink-0 text-cyan-400 text-2xl">
      <i className={feature.icon}></i>
    </div>
    <div>
      <h3 className="text-lg font-semibold text-white">{feature.name}</h3>
      <p className="mt-1 text-gray-400">{feature.description}</p>
    </div>
  </div>
);

const FeaturesSection: React.FC = () => {
  return (
    <section id="features" className="py-20 md:py-28 bg-black">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-white">Built for Enterprise & Developers</h2>
          <p className="max-w-2xl mx-auto mt-4 text-gray-400">
            A production-ready platform designed for scalability, security, and extensibility.
          </p>
        </div>
        <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-10">
          {FEATURES.map((feature) => (
            <FeatureCard key={feature.name} feature={feature} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;
