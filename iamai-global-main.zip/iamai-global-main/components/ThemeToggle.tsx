
import React from 'react';
import type { Theme } from '../App';

interface ThemeToggleProps {
  theme: Theme;
  toggleTheme: () => void;
}

const ThemeToggle: React.FC<ThemeToggleProps> = ({ theme, toggleTheme }) => {
  return (
    <button
      onClick={toggleTheme}
      className="w-10 h-10 rounded-full flex items-center justify-center text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800/50 transition-colors duration-300"
      aria-label={theme === 'light' ? 'Switch to dark mode' : 'Switch to light mode'}
      title={theme === 'light' ? 'Switch to dark mode' : 'Switch to light mode'}
    >
      <div className="relative w-6 h-6">
        <i
          className={`fa-solid fa-sun absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-xl text-yellow-500 transition-all duration-300 ${
            theme === 'light' ? 'opacity-100 rotate-0' : 'opacity-0 -rotate-90'
          }`}
        ></i>
        <i
          className={`fa-solid fa-moon absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-xl text-cyan-400 transition-all duration-300 ${
            theme === 'dark' ? 'opacity-100 rotate-0' : 'opacity-0 rotate-90'
          }`}
        ></i>
      </div>
    </button>
  );
};

export default ThemeToggle;
