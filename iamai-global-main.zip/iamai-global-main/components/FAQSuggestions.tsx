/**
 * FAQ Suggestions Component
 * Displays relevant FAQ articles before escalation
 * Includes "Did this fix it?" prompt with yes/no flow
 */

import React, { useState, useEffect } from 'react';
import { ChevronDown, ChevronUp, ThumbsUp, ThumbsDown, MessageCircle } from 'lucide-react';

interface FAQArticle {
  id: string;
  title: string;
  category: string;
  content: string;
  relevance: number; // 0-100
  helpfulCount: number;
  unhelpfulCount: number;
  viewCount: number;
}

interface FAQSuggestionsProps {
  category: string;
  severity: 'high' | 'medium' | 'low';
  userMessage: string;
  onResolvedYes: () => void;
  onResolvedNo: () => void;
}

const FAQSuggestions: React.FC<FAQSuggestionsProps> = ({
  category,
  severity,
  userMessage,
  onResolvedYes,
  onResolvedNo,
}) => {
  const [expandedArticles, setExpandedArticles] = useState<Set<string>>(new Set());
  const [faqArticles, setFaqArticles] = useState<FAQArticle[]>([]);
  const [loading, setLoading] = useState(true);
  const [userVotes, setUserVotes] = useState<Record<string, boolean>>({});
  const [showResolutionPrompt, setShowResolutionPrompt] = useState(false);

  // Fetch relevant FAQ articles
  useEffect(() => {
    fetchFAQArticles();
  }, [category, userMessage]);

  /**
   * Fetch FAQ articles relevant to the category and user message
   */
  const fetchFAQArticles = async (): Promise<void> => {
    try {
      setLoading(true);

      const response = await fetch('/api/faq/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          query: userMessage,
          category,
          limit: 3,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to fetch FAQ articles');
      }

      const data = await response.json();
      setFaqArticles(data.articles || []);
    } catch (error) {
      console.error('[FAQSuggestions] Error fetching articles:', error);
      setFaqArticles([]);
    } finally {
      setLoading(false);
    }
  };

  /**
   * Toggle article expansion
   */
  const toggleArticle = (articleId: string): void => {
    const newExpanded = new Set(expandedArticles);
    if (newExpanded.has(articleId)) {
      newExpanded.delete(articleId);
    } else {
      newExpanded.add(articleId);
    }
    setExpandedArticles(newExpanded);
  };

  /**
   * Handle helpful vote
   */
  const handleHelpful = async (articleId: string): Promise<void> => {
    try {
      const response = await fetch(`/api/faq/${articleId}/helpful`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ helpful: true }),
      });

      if (!response.ok) {
        throw new Error('Failed to record vote');
      }

      setUserVotes(prev => ({ ...prev, [articleId]: true }));

      // Show resolution prompt if they found it helpful
      setTimeout(() => {
        setShowResolutionPrompt(true);
      }, 500);
    } catch (error) {
      console.error('[FAQSuggestions] Error recording helpful vote:', error);
    }
  };

  /**
   * Handle unhelpful vote
   */
  const handleUnhelpful = async (articleId: string): Promise<void> => {
    try {
      const response = await fetch(`/api/faq/${articleId}/helpful`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ helpful: false }),
      });

      if (!response.ok) {
        throw new Error('Failed to record vote');
      }

      setUserVotes(prev => ({ ...prev, [articleId]: false }));
    } catch (error) {
      console.error('[FAQSuggestions] Error recording unhelpful vote:', error);
    }
  };

  /**
   * Handle "Did this fix it?" yes
   */
  const handleYes = (): void => {
    setShowResolutionPrompt(false);
    onResolvedYes();
  };

  /**
   * Handle "Did this fix it?" no
   */
  const handleNo = (): void => {
    setShowResolutionPrompt(false);
    onResolvedNo();
  };

  if (loading) {
    return (
      <div className="bg-gray-900/50 border border-gray-700/50 rounded-lg p-4 mb-4">
        <div className="flex items-center justify-center gap-2 text-gray-400">
          <div className="w-2 h-2 bg-cyan-500 rounded-full animate-pulse"></div>
          <span className="text-sm">Loading FAQ suggestions...</span>
        </div>
      </div>
    );
  }

  if (faqArticles.length === 0) {
    return null;
  }

  return (
    <div className="space-y-3 mb-4">
      {/* FAQ Header */}
      <div className="bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border border-cyan-500/30 rounded-lg p-3">
        <div className="flex items-center gap-2 mb-2">
          <MessageCircle className="w-4 h-4 text-cyan-400" />
          <span className="text-sm font-semibold text-white">Related FAQ Articles</span>
        </div>
        <p className="text-xs text-gray-400">
          Check these articles - they might help resolve your issue
        </p>
      </div>

      {/* FAQ Articles */}
      {faqArticles.map(article => (
        <div
          key={article.id}
          className="bg-gray-900/50 border border-gray-700/50 rounded-lg overflow-hidden hover:border-gray-600/50 transition-colors"
        >
          {/* Article Header */}
          <button
            onClick={() => toggleArticle(article.id)}
            className="w-full px-4 py-3 flex items-center justify-between hover:bg-gray-800/50 transition-colors text-left"
          >
            <div className="flex-1">
              <h4 className="text-sm font-medium text-white mb-1">{article.title}</h4>
              <div className="flex items-center gap-2">
                <span className="text-xs bg-cyan-500/20 text-cyan-300 px-2 py-0.5 rounded">
                  {article.category}
                </span>
                <span className="text-xs text-gray-500">
                  {Math.round(article.relevance)}% relevant
                </span>
              </div>
            </div>
            {expandedArticles.has(article.id) ? (
              <ChevronUp className="w-4 h-4 text-gray-400 ml-2" />
            ) : (
              <ChevronDown className="w-4 h-4 text-gray-400 ml-2" />
            )}
          </button>

          {/* Article Content */}
          {expandedArticles.has(article.id) && (
            <div className="border-t border-gray-700/50 px-4 py-3 bg-gray-900/30">
              <p className="text-sm text-gray-300 mb-4 line-clamp-4">{article.content}</p>

              {/* Voting Buttons */}
              <div className="flex items-center gap-3">
                <span className="text-xs text-gray-500">Was this helpful?</span>
                <div className="flex gap-2">
                  <button
                    onClick={() => handleHelpful(article.id)}
                    disabled={userVotes[article.id] !== undefined}
                    className={`flex items-center gap-1 px-3 py-1.5 rounded text-xs font-medium transition-colors ${
                      userVotes[article.id] === true
                        ? 'bg-green-500/20 text-green-400 border border-green-500/30'
                        : 'bg-gray-800 text-gray-400 hover:bg-gray-700 border border-gray-700/50'
                    } disabled:opacity-50`}
                  >
                    <ThumbsUp className="w-3 h-3" />
                    Yes
                  </button>
                  <button
                    onClick={() => handleUnhelpful(article.id)}
                    disabled={userVotes[article.id] !== undefined}
                    className={`flex items-center gap-1 px-3 py-1.5 rounded text-xs font-medium transition-colors ${
                      userVotes[article.id] === false
                        ? 'bg-red-500/20 text-red-400 border border-red-500/30'
                        : 'bg-gray-800 text-gray-400 hover:bg-gray-700 border border-gray-700/50'
                    } disabled:opacity-50`}
                  >
                    <ThumbsDown className="w-3 h-3" />
                    No
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      ))}

      {/* Resolution Prompt */}
      {showResolutionPrompt && (
        <div className="bg-gradient-to-r from-green-500/10 to-emerald-500/10 border border-green-500/30 rounded-lg p-4">
          <div className="mb-3">
            <p className="text-sm font-semibold text-white mb-1">
              ✨ Great! Did this resolve your issue?
            </p>
            <p className="text-xs text-gray-400">Your feedback helps us improve our support</p>
          </div>

          <div className="flex gap-2">
            <button
              onClick={handleYes}
              className="flex-1 px-3 py-2 bg-green-500/20 hover:bg-green-500/30 text-green-400 border border-green-500/30 rounded font-medium text-sm transition-colors"
            >
              Yes, Issue Resolved ✓
            </button>
            <button
              onClick={handleNo}
              className="flex-1 px-3 py-2 bg-gray-800 hover:bg-gray-700 text-gray-300 border border-gray-700/50 rounded font-medium text-sm transition-colors"
            >
              No, Need More Help
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default FAQSuggestions;
