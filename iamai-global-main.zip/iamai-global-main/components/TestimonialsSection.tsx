
import React from 'react';
import { TESTIMONIALS, Testimonial } from '../constants';

const TestimonialCard: React.FC<{ testimonial: Testimonial }> = ({ testimonial }) => (
    <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-8 flex flex-col h-full">
        <div className="flex-grow mb-6">
            <i className="fa-solid fa-quote-left text-cyan-400 text-2xl"></i>
            <p className="mt-4 text-gray-300 italic">{testimonial.quote}</p>
        </div>
        <div className="flex items-center">
            <img src={testimonial.avatar} alt={testimonial.name} className="w-12 h-12 rounded-full mr-4" />
            <div>
                <p className="font-semibold text-white">{testimonial.name}</p>
                <p className="text-sm text-gray-400">{testimonial.title}</p>
            </div>
        </div>
    </div>
);


const TestimonialsSection: React.FC = () => {
  return (
    <section id="testimonials" className="py-20 md:py-28 bg-[#0a0a0a]">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-white">Trusted by Innovators</h2>
          <p className="max-w-2xl mx-auto mt-4 text-gray-400">
            See how developers and companies are leveraging IA M AI to build the next generation of applications.
          </p>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {TESTIMONIALS.map((testimonial) => (
            <TestimonialCard key={testimonial.name} testimonial={testimonial} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;