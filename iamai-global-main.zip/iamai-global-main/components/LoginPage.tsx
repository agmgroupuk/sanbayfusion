import React, { useState } from 'react';
import { getApiUrl } from '../config/api';
import { authService } from '../services/authService';

interface LoginPageProps {
  onNavigate: (page: 'home' | 'login' | 'signup' | 'forgot-password' | 'dashboard') => void;
  onLogin: () => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ onNavigate, onLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const handlePasswordLogin = async () => {
    if (!email.trim()) {
      setError('Please enter your email');
      return;
    }
    if (!password) {
      setError('Please enter your password');
      return;
    }

    setLoading(true);
    setError('');
    setMessage('');

    try {
      // Use production API URL with cookie support
      const response = await fetch(getApiUrl('/auth/signin'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include', // Include HttpOnly cookies
        body: JSON.stringify({
          email,
          password,
          authMethod: 'password',
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Login failed');
      }

      const data = await response.json();
      setMessage('✓ Login successful! Redirecting...');

      // 🛡️ SECURITY UPGRADE: Authentication now uses HttpOnly cookies
      // No need to store tokens in localStorage - cookies are handled automatically
      if (data.user) {
        // Only store non-sensitive user data for UI purposes
        localStorage.setItem(
          'iamai_user',
          JSON.stringify({
            id: data.user.id,
            email: data.user.email,
            name: data.user.name,
            tier: data.user.tier,
          })
        );
        console.log('[LOGIN] 🛡️ Secure authentication via HttpOnly cookies');
      }

      setTimeout(() => {
        onLogin();
        onNavigate('dashboard');
      }, 1000);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Login failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handlePasswordLogin();
  };

  return (
    <section className="py-20 md:py-32 bg-black flex items-center justify-center min-h-screen">
      <div className="container mx-auto px-6">
        <div className="max-w-md mx-auto bg-gray-900/50 border border-gray-800 rounded-2xl p-8">
          {/* Logo */}
          <div className="text-center mb-8">
            <img
              src="/assets/iamai-logo.png"
              alt="IA M AI Logo"
              className="h-12 w-auto mx-auto mb-4"
              onError={e => {
                e.currentTarget.style.display = 'none';
              }}
            />
          </div>

          {/* Header */}
          <div className="text-center mb-6">
            <h2 className="text-3xl font-bold text-white mb-2">Welcome Back</h2>
            <p className="text-gray-400 text-sm">Sign in to your IA M AI account</p>
          </div>

          {/* Messages */}
          {error && (
            <div className="mb-4 p-3 bg-red-500/20 border border-red-500/50 rounded-lg text-red-400 text-sm">
              {error}
            </div>
          )}

          {message && (
            <div className="mb-4 p-3 bg-green-500/20 border border-green-500/50 rounded-lg text-green-400 text-sm">
              {message}
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Email Address</label>
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500 transition-colors"
                disabled={loading}
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="block text-sm font-medium text-gray-300">Password</label>
                <button
                  type="button"
                  onClick={() => onNavigate('forgot-password')}
                  className="text-xs text-cyan-400 hover:text-cyan-300 transition-colors"
                  title="Reset your password"
                >
                  Forgot?
                </button>
              </div>
              <input
                type="password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="Your password"
                className="w-full px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500 transition-colors"
                disabled={loading}
              />
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={loading}
              className="w-full px-5 py-3 bg-cyan-500 text-black font-semibold rounded-lg hover:bg-cyan-400 transition-colors duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <span className="inline-block w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin"></span>
                  Signing in...
                </>
              ) : (
                'Sign In'
              )}
            </button>
          </form>

          {/* Divider */}
          <div className="relative my-6">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-gray-700"></div>
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-2 bg-gray-900/50 text-gray-400">or</span>
            </div>
          </div>

          {/* Footer */}
          <div className="text-center space-y-3">
            <p className="text-gray-400 text-sm">
              Don't have an account?{' '}
              <button
                onClick={() => onNavigate('signup')}
                title="Go to signup page"
                className="font-semibold text-cyan-400 hover:text-cyan-300 transition-colors"
              >
                Sign Up
              </button>
            </p>

            <button
              onClick={() => onNavigate('home')}
              title="Return to homepage"
              className="text-gray-500 hover:text-gray-400 text-sm transition-colors"
            >
              ← Back to Home
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default LoginPage;
