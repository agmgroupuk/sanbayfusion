import React, { useState } from 'react';
import { getApiUrl } from '../config/api';

interface SignupPageProps {
  onNavigate: (page: 'home' | 'login' | 'signup' | 'forgot-password' | 'dashboard') => void;
  onLogin: () => void;
}

interface PasswordRequirement {
  label: string;
  met: boolean;
  regex?: RegExp;
  minLength?: number;
}

const SignupPage: React.FC<SignupPageProps> = ({ onNavigate, onLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [name, setName] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // Password strength state
  const [passwordStrength, setPasswordStrength] = useState(0);
  const [passwordRequirements, setPasswordRequirements] = useState<PasswordRequirement[]>([
    { label: 'At least 8 characters', met: false, minLength: 8 },
    { label: 'At least 12 characters (recommended)', met: false, minLength: 12 },
    { label: 'Contains lowercase letter (a-z)', met: false, regex: /[a-z]/ },
    { label: 'Contains uppercase letter (A-Z)', met: false, regex: /[A-Z]/ },
    { label: 'Contains number (0-9)', met: false, regex: /\d/ },
    {
      label: 'Contains special character (!@#$%^&*)',
      met: false,
      regex: /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/,
    },
  ]);

  const calculatePasswordStrength = (pwd: string): number => {
    let strength = 0;
    if (pwd.length >= 8) strength++;
    if (pwd.length >= 12) strength++;
    if (/[a-z]/.test(pwd) && /[A-Z]/.test(pwd)) strength++;
    if (/\d/.test(pwd)) strength++;
    if (/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(pwd)) strength++;
    return Math.min(strength, 5);
  };

  const getPasswordStrengthText = (strength: number): string => {
    const labels = ['Very Weak', 'Weak', 'Fair', 'Good', 'Strong', 'Very Strong'];
    return labels[strength] || 'Weak';
  };

  const handlePasswordChange = (pwd: string) => {
    setPassword(pwd);
    setPasswordStrength(calculatePasswordStrength(pwd));

    // Update requirements
    setPasswordRequirements([
      { label: 'At least 8 characters', met: pwd.length >= 8, minLength: 8 },
      { label: 'At least 12 characters (recommended)', met: pwd.length >= 12, minLength: 12 },
      { label: 'Contains lowercase letter (a-z)', met: /[a-z]/.test(pwd), regex: /[a-z]/ },
      { label: 'Contains uppercase letter (A-Z)', met: /[A-Z]/.test(pwd), regex: /[A-Z]/ },
      { label: 'Contains number (0-9)', met: /\d/.test(pwd), regex: /\d/ },
      {
        label: 'Contains special character (!@#$%^&*)',
        met: /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(pwd),
        regex: /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/,
      },
    ]);
  };

  const handlePasswordSignup = async () => {
    if (!email.trim()) {
      setError('Please enter your email');
      return;
    }
    if (!name.trim()) {
      setError('Please enter your name');
      return;
    }
    if (!password || password.length < 8) {
      setError('Password must be at least 8 characters');
      return;
    }
    if (password !== confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    setLoading(true);
    setError('');
    setMessage('');

    try {
      // Split name into firstName and lastName
      const nameParts = name.trim().split(' ');
      const firstName = nameParts[0] || '';
      const lastName = nameParts.slice(1).join(' ') || '';

      // Use production API URL
      const response = await fetch(getApiUrl('/auth/signup'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email,
          password,
          name: `${firstName} ${lastName}`.trim(),
          firstName,
          lastName,
          authMethod: 'password',
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Signup failed');
      }

      const data = await response.json();
      setMessage('✓ Account created successfully! Redirecting to login...');

      // No localStorage - just redirect to login after successful signup
      setTimeout(() => {
        setMessage('✓ Account created successfully! Please log in with your credentials.');
        setTimeout(() => {
          onNavigate('login');
        }, 1500);
      }, 1000);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Signup failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handlePasswordSignup();
  };

  return (
    <section className="py-20 md:py-32 bg-black flex items-center justify-center min-h-screen">
      <div className="container mx-auto px-6">
        <div className="max-w-md mx-auto bg-gray-900/50 border border-gray-800 rounded-2xl p-8">
          {/* Logo */}
          <div className="text-center mb-8">
            <img
              src="/assets/iamai-logo.png"
              alt="IA M AI Logo"
              className="h-12 w-auto mx-auto mb-4"
              onError={e => {
                e.currentTarget.style.display = 'none';
              }}
            />
          </div>

          {/* Header */}
          <div className="text-center mb-6">
            <h2 className="text-3xl font-bold text-white mb-2">Create Account</h2>
            <p className="text-gray-400 text-sm">Join IA M AI and start building with AI agents</p>
          </div>

          {/* Messages */}
          {error && (
            <div className="mb-4 p-3 bg-red-500/20 border border-red-500/50 rounded-lg text-red-400 text-sm">
              {error}
            </div>
          )}

          {message && (
            <div className="mb-4 p-3 bg-green-500/20 border border-green-500/50 rounded-lg text-green-400 text-sm">
              {message}
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">First Name</label>
                <input
                  type="text"
                  value={name.split(' ')[0] || ''}
                  onChange={e => {
                    const lastName = name.split(' ').slice(1).join(' ');
                    setName(lastName ? `${e.target.value} ${lastName}` : e.target.value);
                  }}
                  placeholder="John"
                  className="w-full px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500 transition-colors"
                  disabled={loading}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Last Name</label>
                <input
                  type="text"
                  value={name.split(' ').slice(1).join(' ') || ''}
                  onChange={e => {
                    const firstName = name.split(' ')[0] || '';
                    setName(`${firstName} ${e.target.value}`.trim());
                  }}
                  placeholder="Doe"
                  className="w-full px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500 transition-colors"
                  disabled={loading}
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Email Address</label>
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500 transition-colors"
                disabled={loading}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Password</label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={e => handlePasswordChange(e.target.value)}
                  placeholder="At least 8 characters"
                  className="w-full px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500 transition-colors pr-10"
                  disabled={loading}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-300"
                  disabled={loading}
                >
                  {showPassword ? (
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21"
                      />
                    </svg>
                  ) : (
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
                      />
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"
                      />
                    </svg>
                  )}
                </button>
              </div>

              {/* Advanced Password Strength Indicator */}
              {password && (
                <div className="mt-3 space-y-3">
                  {/* Strength Bar */}
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <svg
                        className={`w-4 h-4 ${
                          passwordStrength >= 4
                            ? 'text-green-400'
                            : passwordStrength >= 3
                              ? 'text-blue-400'
                              : passwordStrength >= 2
                                ? 'text-yellow-400'
                                : 'text-red-400'
                        }`}
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"
                        />
                      </svg>
                      <span
                        className={`text-sm font-medium ${
                          passwordStrength >= 4
                            ? 'text-green-400'
                            : passwordStrength >= 3
                              ? 'text-blue-400'
                              : passwordStrength >= 2
                                ? 'text-yellow-400'
                                : 'text-red-400'
                        }`}
                      >
                        {getPasswordStrengthText(passwordStrength)}
                      </span>
                    </div>
                    <div className="flex gap-1">
                      {[0, 1, 2, 3, 4, 5].map(level => (
                        <div
                          key={level}
                          className={`h-1.5 flex-1 rounded-full transition-all duration-300 ${
                            level <= passwordStrength
                              ? passwordStrength >= 4
                                ? 'bg-green-500'
                                : passwordStrength >= 3
                                  ? 'bg-blue-500'
                                  : passwordStrength >= 2
                                    ? 'bg-yellow-500'
                                    : 'bg-red-500'
                              : 'bg-gray-700'
                          }`}
                        />
                      ))}
                    </div>
                  </div>

                  {/* Requirements Checklist */}
                  <div className="bg-gray-800/50 rounded-lg p-3 border border-gray-700">
                    <p className="text-xs font-medium text-gray-300 mb-2">Password Requirements:</p>
                    <div className="space-y-1.5">
                      {passwordRequirements.map((req, index) => (
                        <div key={index} className="flex items-center gap-2">
                          {req.met ? (
                            <svg
                              className="w-3.5 h-3.5 text-green-400 flex-shrink-0"
                              fill="none"
                              stroke="currentColor"
                              viewBox="0 0 24 24"
                            >
                              <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                strokeWidth={2}
                                d="M5 13l4 4L19 7"
                              />
                            </svg>
                          ) : (
                            <svg
                              className="w-3.5 h-3.5 text-gray-500 flex-shrink-0"
                              fill="none"
                              stroke="currentColor"
                              viewBox="0 0 24 24"
                            >
                              <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                strokeWidth={2}
                                d="M6 18L18 6M6 6l12 12"
                              />
                            </svg>
                          )}
                          <span
                            className={`text-xs ${req.met ? 'text-green-400' : 'text-gray-400'}`}
                          >
                            {req.label}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Confirm Password
              </label>
              <input
                type="password"
                value={confirmPassword}
                onChange={e => setConfirmPassword(e.target.value)}
                placeholder="Confirm your password"
                className="w-full px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500 transition-colors"
                disabled={loading}
              />
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={loading}
              className="w-full px-5 py-3 bg-cyan-500 text-black font-semibold rounded-lg hover:bg-cyan-400 transition-colors duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <span className="inline-block w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin"></span>
                  Creating account...
                </>
              ) : (
                'Sign Up'
              )}
            </button>
          </form>

          {/* Divider */}
          <div className="relative my-6">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-gray-700"></div>
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-2 bg-gray-900/50 text-gray-400">or</span>
            </div>
          </div>

          {/* Footer */}
          <div className="text-center space-y-3">
            <p className="text-gray-400 text-sm">
              Already have an account?{' '}
              <button
                onClick={() => onNavigate('login')}
                title="Go to login page"
                className="font-semibold text-cyan-400 hover:text-cyan-300 transition-colors"
              >
                Log In
              </button>
            </p>

            <button
              onClick={() => onNavigate('home')}
              title="Return to homepage"
              className="text-gray-500 hover:text-gray-400 text-sm transition-colors"
            >
              ← Back to Home
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SignupPage;
