import { Agent } from '../../constants';

export interface AgentCardState {
  agent: Agent;
  isHovered: boolean;
  isActive: boolean;
  stats: AgentStats;
  theme: any;
}

export interface AgentStats {
  totalChats: number;
  averageRating: number;
  responseTime: number;
  lastUsed: Date | null;
  popularityScore: number;
}

export interface AgentCardOptions {
  showStats: boolean;
  showActions: boolean;
  compact: boolean;
  interactive: boolean;
}

export class AgentCardService {
  private listeners: Set<(state: AgentCardState) => void> = new Set();
  private state: AgentCardState;
  private options: AgentCardOptions;

  constructor(agent: Agent, theme: any, options: AgentCardOptions) {
    this.options = options;
    this.state = {
      agent,
      isHovered: false,
      isActive: false,
      stats: this.loadAgentStats(agent.name),
      theme,
    };
  }

  private loadAgentStats(agentName: string): AgentStats {
    try {
      const stored = localStorage.getItem(`agent_stats_${agentName}`);
      if (stored) {
        const stats = JSON.parse(stored);
        return {
          ...stats,
          lastUsed: stats.lastUsed ? new Date(stats.lastUsed) : null,
        };
      }
    } catch (error) {
      console.error('Failed to load agent stats:', error);
    }

    return {
      totalChats: 0,
      averageRating: 0,
      responseTime: 0,
      lastUsed: null,
      popularityScore: 0,
    };
  }

  private saveAgentStats(): void {
    try {
      localStorage.setItem(
        `agent_stats_${this.state.agent.name}`,
        JSON.stringify(this.state.stats)
      );
    } catch (error) {
      console.error('Failed to save agent stats:', error);
    }
  }

  setHovered(isHovered: boolean): void {
    if (this.options.interactive) {
      this.updateState({ ...this.state, isHovered });
    }
  }

  setActive(isActive: boolean): void {
    this.updateState({ ...this.state, isActive });
  }

  incrementChatCount(): void {
    const newStats = {
      ...this.state.stats,
      totalChats: this.state.stats.totalChats + 1,
      lastUsed: new Date(),
      popularityScore: this.calculatePopularityScore(
        this.state.stats.totalChats + 1,
        this.state.stats.averageRating
      ),
    };

    this.updateState({ ...this.state, stats: newStats });
    this.saveAgentStats();
  }

  updateRating(rating: number): void {
    const currentTotal = this.state.stats.averageRating * this.state.stats.totalChats;
    const newAverage =
      this.state.stats.totalChats > 0
        ? (currentTotal + rating) / (this.state.stats.totalChats + 1)
        : rating;

    const newStats = {
      ...this.state.stats,
      averageRating: Math.round(newAverage * 10) / 10, // Round to 1 decimal
      popularityScore: this.calculatePopularityScore(this.state.stats.totalChats, newAverage),
    };

    this.updateState({ ...this.state, stats: newStats });
    this.saveAgentStats();
  }

  updateResponseTime(timeMs: number): void {
    // Calculate running average of response times
    const currentAvg = this.state.stats.responseTime;
    const count = Math.max(1, this.state.stats.totalChats);
    const newAvg = (currentAvg * (count - 1) + timeMs) / count;

    const newStats = {
      ...this.state.stats,
      responseTime: Math.round(newAvg),
    };

    this.updateState({ ...this.state, stats: newStats });
    this.saveAgentStats();
  }

  private calculatePopularityScore(totalChats: number, avgRating: number): number {
    // Simple popularity algorithm: weight chats and rating
    const chatScore = Math.min(totalChats * 2, 100); // Max 100 from chats
    const ratingScore = (avgRating / 5) * 100; // Convert 5-star to 100 scale
    return Math.round(chatScore * 0.6 + ratingScore * 0.4);
  }

  getFormattedStats(): {
    totalChats: string;
    averageRating: string;
    responseTime: string;
    lastUsed: string;
    popularityScore: string;
  } {
    const stats = this.state.stats;
    return {
      totalChats: this.formatNumber(stats.totalChats),
      averageRating: stats.averageRating > 0 ? stats.averageRating.toFixed(1) : 'N/A',
      responseTime: stats.responseTime > 0 ? `${(stats.responseTime / 1000).toFixed(1)}s` : 'N/A',
      lastUsed: stats.lastUsed ? this.formatRelativeTime(stats.lastUsed) : 'Never',
      popularityScore: `${stats.popularityScore}%`,
    };
  }

  private formatNumber(num: number): string {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toString();
  }

  private formatRelativeTime(date: Date): string {
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / (1000 * 60));
    const diffHours = Math.floor(diffMins / 60);
    const diffDays = Math.floor(diffHours / 24);

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays < 7) return `${diffDays}d ago`;

    return date.toLocaleDateString();
  }

  getCardClasses(): string {
    const baseClasses = ['agent-card', 'transition-all', 'duration-200', 'cursor-pointer'];

    if (this.options.compact) {
      baseClasses.push('compact');
    }

    if (this.state.isHovered && this.options.interactive) {
      baseClasses.push('hovered', 'scale-105', 'shadow-lg');
    }

    if (this.state.isActive) {
      baseClasses.push('active', 'ring-2', 'ring-blue-500');
    }

    return baseClasses.join(' ');
  }

  getStatusBadge(): { text: string; color: string } | null {
    const stats = this.state.stats;

    if (stats.totalChats === 0) {
      return { text: 'New', color: 'bg-blue-500' };
    }

    if (stats.popularityScore >= 80) {
      return { text: 'Popular', color: 'bg-green-500' };
    }

    if (stats.averageRating >= 4.5) {
      return { text: 'Top Rated', color: 'bg-yellow-500' };
    }

    return null;
  }

  updateAgent(agent: Agent): void {
    this.updateState({ ...this.state, agent });
  }

  updateTheme(theme: any): void {
    this.updateState({ ...this.state, theme });
  }

  getState(): AgentCardState {
    return { ...this.state };
  }

  subscribe(listener: (state: AgentCardState) => void): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private updateState(newState: AgentCardState): void {
    this.state = newState;
    this.listeners.forEach(listener => listener(this.state));
  }

  destroy(): void {
    this.listeners.clear();
  }
}
