import React from 'react';

interface CircleGaugeProps {
  value: number; // 0-100
  size?: number; // px
  thickness?: number; // px
  colorFrom?: string; // tailwind class or css color
  colorTo?: string; // css color for gradient end
  label?: string;
  valueText?: string;
}

export default function CircleGauge({
  value,
  size = 120,
  thickness = 12,
  colorFrom = '#22d3ee', // cyan-400
  colorTo = '#0ea5e9',   // sky-500
  label,
  valueText,
}: CircleGaugeProps) {
  const pct = Math.max(0, Math.min(100, value));
  const angle = (pct / 100) * 360;

  return (
    <div style={{ width: size, height: size }} className="relative inline-block">
      <div
        className="w-full h-full rounded-full"
        style={{
          background: `conic-gradient(${colorFrom} 0deg, ${colorTo} ${angle}deg, rgba(255,255,255,0.08) ${angle}deg 360deg)`,
        }}
      />
      <div
        className="absolute inset-0 rounded-full"
        style={{
          padding: thickness,
        }}
      >
        <div className="w-full h-full rounded-full bg-neural-900 flex items-center justify-center">
          <div className="text-center">
            <div className="text-xl font-bold">
              {valueText ?? `${pct.toFixed(1)}%`}
            </div>
            {label && <div className="text-xs text-neural-400">{label}</div>}
          </div>
        </div>
      </div>
    </div>
  );
}
