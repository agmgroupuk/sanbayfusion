import { Agent } from '../../constants';

export interface SearchResult {
  id: string;
  type: 'agent' | 'chat' | 'feature' | 'setting';
  title: string;
  description: string;
  path?: string;
  data?: any;
  relevance: number;
}

export interface SearchState {
  query: string;
  results: SearchResult[];
  isSearching: boolean;
  isOpen: boolean;
  selectedIndex: number;
  recentSearches: string[];
  filters: SearchFilter[];
  activeFilters: string[];
}

export interface SearchFilter {
  id: string;
  label: string;
  type: SearchResult['type'];
  active: boolean;
}

export interface SearchOptions {
  maxResults: number;
  showRecentSearches: boolean;
  enableFilters: boolean;
  debounceMs: number;
}

export class SearchBarService {
  private listeners: Set<(state: SearchState) => void> = new Set();
  private state: SearchState;
  private options: SearchOptions;
  private agents: Agent[];
  private searchTimeout?: NodeJS.Timeout;
  private searchIndex: SearchResult[] = [];

  constructor(agents: Agent[], options: SearchOptions) {
    this.agents = agents;
    this.options = options;

    this.state = {
      query: '',
      results: [],
      isSearching: false,
      isOpen: false,
      selectedIndex: -1,
      recentSearches: [],
      filters: this.createFilters(),
      activeFilters: [],
    };

    this.loadRecentSearches();
    this.buildSearchIndex();
  }

  private createFilters(): SearchFilter[] {
    return [
      { id: 'agent', label: 'AI Agents', type: 'agent', active: false },
      { id: 'chat', label: 'Chats', type: 'chat', active: false },
      { id: 'feature', label: 'Features', type: 'feature', active: false },
      { id: 'setting', label: 'Settings', type: 'setting', active: false },
    ];
  }

  private loadRecentSearches(): void {
    try {
      const stored = localStorage.getItem('recent_searches');
      if (stored) {
        const recentSearches = JSON.parse(stored).slice(0, 10);
        this.updateState({ ...this.state, recentSearches });
      }
    } catch (error) {
      console.error('Failed to load recent searches:', error);
    }
  }

  private saveRecentSearches(): void {
    try {
      localStorage.setItem('recent_searches', JSON.stringify(this.state.recentSearches));
    } catch (error) {
      console.error('Failed to save recent searches:', error);
    }
  }

  private buildSearchIndex(): void {
    this.searchIndex = [
      // Agents
      ...this.agents.map(agent => ({
        id: `agent_${agent.name}`,
        type: 'agent' as const,
        title: agent.name,
        description: agent.description,
        path: `/agents/${agent.name.toLowerCase()}`,
        data: agent,
        relevance: 0,
      })),

      // Features
      {
        id: 'feature_ai_lab',
        type: 'feature',
        title: 'AI Lab',
        description: 'Advanced AI model experimentation and testing',
        path: '/ai-lab',
        relevance: 0,
      },
      {
        id: 'feature_analytics',
        type: 'feature',
        title: 'Analytics Dashboard',
        description: 'View usage statistics and performance metrics',
        path: '/analytics',
        relevance: 0,
      },
      {
        id: 'feature_chat_history',
        type: 'feature',
        title: 'Chat History',
        description: 'Browse and search your chat conversations',
        path: '/chat-history',
        relevance: 0,
      },

      // Settings
      {
        id: 'setting_profile',
        type: 'setting',
        title: 'Profile Settings',
        description: 'Manage your account and preferences',
        path: '/settings/profile',
        relevance: 0,
      },
      {
        id: 'setting_theme',
        type: 'setting',
        title: 'Theme Settings',
        description: 'Customize appearance and theme',
        path: '/settings/theme',
        relevance: 0,
      },
      {
        id: 'setting_notifications',
        type: 'setting',
        title: 'Notifications',
        description: 'Configure notification preferences',
        path: '/settings/notifications',
        relevance: 0,
      },
    ];
  }

  setQuery(query: string): void {
    this.updateState({
      ...this.state,
      query,
      selectedIndex: -1,
    });

    if (this.searchTimeout) {
      clearTimeout(this.searchTimeout);
    }

    if (query.trim()) {
      this.searchTimeout = setTimeout(() => {
        this.performSearch(query);
      }, this.options.debounceMs);
    } else {
      this.updateState({
        ...this.state,
        results: [],
        isSearching: false,
      });
    }
  }

  private async performSearch(query: string): Promise<void> {
    this.updateState({ ...this.state, isSearching: true });

    try {
      const results = this.searchLocal(query);

      // Filter by active filters if any
      const filteredResults =
        this.state.activeFilters.length > 0
          ? results.filter(r => this.state.activeFilters.includes(r.type))
          : results;

      this.updateState({
        ...this.state,
        results: filteredResults.slice(0, this.options.maxResults),
        isSearching: false,
      });
    } catch (error) {
      console.error('Search failed:', error);
      this.updateState({
        ...this.state,
        results: [],
        isSearching: false,
      });
    }
  }

  private searchLocal(query: string): SearchResult[] {
    const searchTerm = query.toLowerCase().trim();

    return this.searchIndex
      .map(item => {
        const titleMatch = this.calculateRelevance(item.title, searchTerm);
        const descMatch = this.calculateRelevance(item.description, searchTerm);

        const relevance = Math.max(titleMatch * 2, descMatch); // Title matches worth more

        return { ...item, relevance };
      })
      .filter(item => item.relevance > 0)
      .sort((a, b) => b.relevance - a.relevance);
  }

  private calculateRelevance(text: string, searchTerm: string): number {
    const lowerText = text.toLowerCase();

    // Exact match
    if (lowerText === searchTerm) return 100;

    // Starts with search term
    if (lowerText.startsWith(searchTerm)) return 80;

    // Contains whole search term
    if (lowerText.includes(searchTerm)) return 60;

    // Fuzzy matching - check if all characters are present in order
    let searchIndex = 0;
    for (let i = 0; i < lowerText.length && searchIndex < searchTerm.length; i++) {
      if (lowerText[i] === searchTerm[searchIndex]) {
        searchIndex++;
      }
    }

    if (searchIndex === searchTerm.length) {
      return Math.max(20, 60 - searchTerm.length * 2); // Longer terms get lower fuzzy scores
    }

    return 0;
  }

  open(): void {
    this.updateState({ ...this.state, isOpen: true });
  }

  close(): void {
    this.updateState({
      ...this.state,
      isOpen: false,
      selectedIndex: -1,
    });
  }

  selectNext(): void {
    const maxIndex = this.state.results.length - 1;
    const newIndex = this.state.selectedIndex < maxIndex ? this.state.selectedIndex + 1 : 0;

    this.updateState({ ...this.state, selectedIndex: newIndex });
  }

  selectPrevious(): void {
    const maxIndex = this.state.results.length - 1;
    const newIndex = this.state.selectedIndex > 0 ? this.state.selectedIndex - 1 : maxIndex;

    this.updateState({ ...this.state, selectedIndex: newIndex });
  }

  selectResult(index: number): SearchResult | null {
    if (index >= 0 && index < this.state.results.length) {
      const result = this.state.results[index];
      this.addToRecentSearches(this.state.query);
      this.close();
      return result;
    }
    return null;
  }

  getSelectedResult(): SearchResult | null {
    return this.selectResult(this.state.selectedIndex);
  }

  toggleFilter(filterId: string): void {
    const activeFilters = this.state.activeFilters.includes(filterId)
      ? this.state.activeFilters.filter(f => f !== filterId)
      : [...this.state.activeFilters, filterId];

    this.updateState({ ...this.state, activeFilters });

    // Re-search with new filters
    if (this.state.query.trim()) {
      this.performSearch(this.state.query);
    }
  }

  clearFilters(): void {
    this.updateState({ ...this.state, activeFilters: [] });

    if (this.state.query.trim()) {
      this.performSearch(this.state.query);
    }
  }

  useRecentSearch(query: string): void {
    this.setQuery(query);
  }

  clearRecentSearches(): void {
    this.updateState({ ...this.state, recentSearches: [] });
    this.saveRecentSearches();
  }

  private addToRecentSearches(query: string): void {
    if (!query.trim()) return;

    const recentSearches = [query, ...this.state.recentSearches.filter(s => s !== query)].slice(
      0,
      10
    );

    this.updateState({ ...this.state, recentSearches });
    this.saveRecentSearches();
  }

  getState(): SearchState {
    return { ...this.state };
  }

  subscribe(listener: (state: SearchState) => void): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private updateState(newState: SearchState): void {
    this.state = newState;
    this.listeners.forEach(listener => listener(this.state));
  }

  destroy(): void {
    if (this.searchTimeout) {
      clearTimeout(this.searchTimeout);
    }
    this.listeners.clear();
  }
}
