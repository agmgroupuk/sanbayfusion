/**
 * 📁 Custom Hook for File Upload
 * Handle file uploads, progress tracking, and management
 */

import { useState, useCallback } from 'react';
import { apiRequest } from '../../services/api';

export interface FileUploadData {
  _id: string;
  userId: string;
  originalName: string;
  filename: string;
  mimeType: string;
  size: number;
  path: string;
  url?: string;
  category: string;
  isPublic: boolean;
  metadata: Record<string, any>;
  status: 'pending' | 'uploading' | 'completed' | 'failed';
  uploadedAt: Date;
  expiresAt?: Date;
}

export interface UploadProgress {
  id: string;
  file: File;
  progress: number;
  status: 'uploading' | 'completed' | 'failed';
  error?: string;
}

export interface UploadOptions {
  category?: string;
  isPublic?: boolean;
  metadata?: Record<string, any>;
  onProgress?: (progress: number) => void;
}

export const useFileUpload = () => {
  const [files, setFiles] = useState<FileUploadData[]>([]);
  const [uploads, setUploads] = useState<UploadProgress[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchFiles = useCallback(
    async (params?: { category?: string; isPublic?: boolean; limit?: number; offset?: number }) => {
      setLoading(true);
      setError(null);

      try {
        const queryParams = new URLSearchParams();
        if (params?.category) queryParams.append('category', params.category);
        if (params?.isPublic !== undefined)
          queryParams.append('isPublic', params.isPublic.toString());
        if (params?.limit) queryParams.append('limit', params.limit.toString());
        if (params?.offset) queryParams.append('offset', params.offset.toString());

        const response = await apiRequest(`/api/uploads/files?${queryParams}`);
        setFiles(response.data);
      } catch (err: any) {
        setError(err.message || 'Failed to fetch files');
      } finally {
        setLoading(false);
      }
    },
    []
  );

  const uploadFile = useCallback(async (file: File, options: UploadOptions = {}) => {
    const uploadId = Math.random().toString(36).substr(2, 9);

    // Add to uploads tracking
    setUploads(prev => [
      ...prev,
      {
        id: uploadId,
        file,
        progress: 0,
        status: 'uploading',
      },
    ]);

    try {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('category', options.category || 'document');
      formData.append('isPublic', (options.isPublic || false).toString());
      if (options.metadata) {
        formData.append('metadata', JSON.stringify(options.metadata));
      }

      const response = await fetch('/api/uploads/upload', {
        method: 'POST',
        body: formData,
        // Track upload progress
        ...(options.onProgress && {
          onUploadProgress: progressEvent => {
            const progress = Math.round((progressEvent.loaded * 100) / progressEvent.total);
            setUploads(prev =>
              prev.map(upload => (upload.id === uploadId ? { ...upload, progress } : upload))
            );
            options.onProgress?.(progress);
          },
        }),
      });

      if (!response.ok) {
        throw new Error('Upload failed');
      }

      const result = await response.json();

      // Update upload status
      setUploads(prev =>
        prev.map(upload =>
          upload.id === uploadId ? { ...upload, progress: 100, status: 'completed' } : upload
        )
      );

      // Add to files list
      setFiles(prev => [result.data, ...prev]);

      // Remove from uploads after delay
      setTimeout(() => {
        setUploads(prev => prev.filter(upload => upload.id !== uploadId));
      }, 2000);

      return result.data;
    } catch (err: any) {
      // Update upload status with error
      setUploads(prev =>
        prev.map(upload =>
          upload.id === uploadId ? { ...upload, status: 'failed', error: err.message } : upload
        )
      );

      throw new Error(err.message || 'Upload failed');
    }
  }, []);

  const deleteFile = useCallback(async (fileId: string) => {
    try {
      await apiRequest(`/api/uploads/files/${fileId}`, {
        method: 'DELETE',
      });

      setFiles(prev => prev.filter(file => file._id !== fileId));
    } catch (err: any) {
      throw new Error(err.message || 'Failed to delete file');
    }
  }, []);

  const downloadFile = useCallback(
    async (fileId: string) => {
      try {
        const response = await fetch(`/api/uploads/files/${fileId}/download`);

        if (!response.ok) {
          throw new Error('Download failed');
        }

        const blob = await response.blob();
        const file = files.find(f => f._id === fileId);

        if (file) {
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = file.originalName;
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          URL.revokeObjectURL(url);
        }
      } catch (err: any) {
        throw new Error(err.message || 'Failed to download file');
      }
    },
    [files]
  );

  const shareFile = useCallback(
    async (
      fileId: string,
      options?: {
        expiresIn?: string;
        password?: string;
      }
    ) => {
      try {
        const response = await apiRequest(`/api/uploads/files/${fileId}/share`, {
          method: 'POST',
          body: JSON.stringify(options),
        });

        return response.data.shareUrl;
      } catch (err: any) {
        throw new Error(err.message || 'Failed to share file');
      }
    },
    []
  );

  const abortUpload = useCallback((uploadId: string) => {
    setUploads(prev => prev.filter(upload => upload.id !== uploadId));
  }, []);

  const getFileUrl = useCallback(
    (fileId: string) => {
      const file = files.find(f => f._id === fileId);
      return file?.url || `/api/uploads/files/${fileId}/view`;
    },
    [files]
  );

  const updateFileMetadata = useCallback(async (fileId: string, metadata: Record<string, any>) => {
    try {
      const response = await apiRequest(`/api/uploads/files/${fileId}`, {
        method: 'PATCH',
        body: JSON.stringify({ metadata }),
      });

      setFiles(prev =>
        prev.map(file =>
          file._id === fileId ? { ...file, metadata: response.data.metadata } : file
        )
      );

      return response.data;
    } catch (err: any) {
      throw new Error(err.message || 'Failed to update file metadata');
    }
  }, []);

  const searchFiles = useCallback(
    async (
      query: string,
      filters?: {
        category?: string;
        mimeType?: string;
        dateFrom?: Date;
        dateTo?: Date;
      }
    ) => {
      try {
        const queryParams = new URLSearchParams();
        queryParams.append('q', query);
        if (filters?.category) queryParams.append('category', filters.category);
        if (filters?.mimeType) queryParams.append('mimeType', filters.mimeType);
        if (filters?.dateFrom) queryParams.append('dateFrom', filters.dateFrom.toISOString());
        if (filters?.dateTo) queryParams.append('dateTo', filters.dateTo.toISOString());

        const response = await apiRequest(`/api/uploads/search?${queryParams}`);
        return response.data;
      } catch (err: any) {
        throw new Error(err.message || 'Search failed');
      }
    },
    []
  );

  return {
    files,
    uploads,
    loading,
    error,
    fetchFiles,
    uploadFile,
    deleteFile,
    downloadFile,
    shareFile,
    abortUpload,
    getFileUrl,
    updateFileMetadata,
    searchFiles,
  };
};
