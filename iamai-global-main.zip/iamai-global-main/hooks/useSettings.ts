import { useState, useCallback, useEffect } from 'react';
import { STORAGE_KEYS } from '../types/Constants';
import type { UserPreferences, NotificationSettings, PrivacySettings } from '../types/User';

interface AppSettings {
  theme: 'light' | 'dark' | 'system';
  language: string;
  timezone: string;
  notifications: NotificationSettings;
  privacy: PrivacySettings;
  autoSave: boolean;
  soundEnabled: boolean;
}

interface SettingsState {
  settings: AppSettings;
  isLoading: boolean;
  error: string | null;
}

interface SettingsActions {
  updateSetting: <K extends keyof AppSettings>(key: K, value: AppSettings[K]) => void;
  updateNotificationSettings: (settings: Partial<NotificationSettings>) => void;
  updatePrivacySettings: (settings: Partial<PrivacySettings>) => void;
  resetToDefaults: () => void;
  saveSettings: () => Promise<boolean>;
  loadSettings: () => void;
  clearError: () => void;
}

const DEFAULT_SETTINGS: AppSettings = {
  theme: 'system',
  language: 'en',
  timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
  notifications: {
    email: true,
    push: true,
    inApp: true,
    marketing: false,
    agentUpdates: true,
    systemAlerts: true,
  },
  privacy: {
    profileVisibility: 'private',
    dataSharing: false,
    analyticsOptIn: true,
    cookieConsent: false,
  },
  autoSave: true,
  soundEnabled: true,
};

const loadStoredSettings = (): AppSettings => {
  try {
    const stored = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    if (stored) {
      const parsed = JSON.parse(stored);
      return { ...DEFAULT_SETTINGS, ...parsed };
    }
  } catch (error) {
    console.warn('Failed to load stored settings:', error);
  }
  return DEFAULT_SETTINGS;
};

const saveStoredSettings = (settings: AppSettings): void => {
  try {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  } catch (error) {
    console.error('Failed to save settings:', error);
  }
};

export const useSettings = (): SettingsState & SettingsActions => {
  const [state, setState] = useState<SettingsState>({
    settings: DEFAULT_SETTINGS,
    isLoading: true,
    error: null,
  });

  // Load settings on mount
  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = useCallback(() => {
    setState(prev => ({ ...prev, isLoading: true, error: null }));

    try {
      const settings = loadStoredSettings();
      setState(prev => ({
        ...prev,
        settings,
        isLoading: false,
      }));
    } catch (error) {
      setState(prev => ({
        ...prev,
        error: 'Failed to load settings',
        isLoading: false,
      }));
    }
  }, []);

  const updateSetting = useCallback(
    <K extends keyof AppSettings>(key: K, value: AppSettings[K]) => {
      setState(prev => {
        const newSettings = {
          ...prev.settings,
          [key]: value,
        };

        saveStoredSettings(newSettings);

        return {
          ...prev,
          settings: newSettings,
        };
      });
    },
    []
  );

  const updateNotificationSettings = useCallback((settings: Partial<NotificationSettings>) => {
    setState(prev => {
      const newSettings = {
        ...prev.settings,
        notifications: {
          ...prev.settings.notifications,
          ...settings,
        },
      };

      saveStoredSettings(newSettings);

      return {
        ...prev,
        settings: newSettings,
      };
    });
  }, []);

  const updatePrivacySettings = useCallback((settings: Partial<PrivacySettings>) => {
    setState(prev => {
      const newSettings = {
        ...prev.settings,
        privacy: {
          ...prev.settings.privacy,
          ...settings,
        },
      };

      saveStoredSettings(newSettings);

      return {
        ...prev,
        settings: newSettings,
      };
    });
  }, []);

  const resetToDefaults = useCallback(() => {
    setState(prev => ({
      ...prev,
      settings: DEFAULT_SETTINGS,
    }));

    saveStoredSettings(DEFAULT_SETTINGS);
  }, []);

  const saveSettings = useCallback(async (): Promise<boolean> => {
    setState(prev => ({ ...prev, isLoading: true, error: null }));

    try {
      // Here you would save to backend if needed
      // const response = await api.user.updatePreferences(state.settings);

      saveStoredSettings(state.settings);

      setState(prev => ({ ...prev, isLoading: false }));
      return true;
    } catch (error) {
      setState(prev => ({
        ...prev,
        error: 'Failed to save settings',
        isLoading: false,
      }));
      return false;
    }
  }, [state.settings]);

  const clearError = useCallback(() => {
    setState(prev => ({ ...prev, error: null }));
  }, []);

  return {
    ...state,
    updateSetting,
    updateNotificationSettings,
    updatePrivacySettings,
    resetToDefaults,
    saveSettings,
    loadSettings,
    clearError,
  };
};
