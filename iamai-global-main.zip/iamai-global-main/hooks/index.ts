// Export all custom hooks
export { useAuth } from './useAuth';
export { useChat } from './useChat';
export { useAgents } from './useAgents';
export { useTheme } from './useTheme';
export { useSettings } from './useSettings';

// Export hook types
export type { AuthState, AuthActions } from './useAuth';

export type { ChatState, ChatActions } from './useChat';

// Re-export commonly used hook combinations
import { useAuth } from './useAuth';
import { useTheme } from './useTheme';
import { useSettings } from './useSettings';

export const useAppState = () => {
  const auth = useAuth();
  const theme = useTheme();
  const settings = useSettings();

  return {
    auth,
    theme,
    settings,
  };
};
