/**
 * 🔔 Custom Hook for Notifications
 * Manage user notifications and real-time updates
 */

import { useState, useCallback, useEffect } from 'react';
import { apiRequest } from '../../services/api';

export interface Notification {
  _id: string;
  userId: string;
  type: 'system' | 'billing' | 'security' | 'feature';
  title: string;
  message: string;
  priority: 'low' | 'medium' | 'high';
  read: boolean;
  actionUrl?: string;
  metadata?: Record<string, any>;
  createdAt: Date;
  expiresAt?: Date;
}

export interface NotificationPreferences {
  [key: string]: {
    enabled: boolean;
    email: boolean;
    push: boolean;
  };
}

export const useNotifications = () => {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [preferences, setPreferences] = useState<NotificationPreferences>({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchNotifications = useCallback(async (offset = 0, limit = 20) => {
    setLoading(true);
    setError(null);

    try {
      const response = await apiRequest(`/api/notifications?offset=${offset}&limit=${limit}`);

      if (offset === 0) {
        setNotifications(response.data.notifications);
      } else {
        setNotifications(prev => [...prev, ...response.data.notifications]);
      }

      setUnreadCount(response.data.unreadCount);
    } catch (err: any) {
      setError(err.message || 'Failed to fetch notifications');
    } finally {
      setLoading(false);
    }
  }, []);

  const markAsRead = useCallback(async (notificationId: string) => {
    try {
      await apiRequest(`/api/notifications/${notificationId}/read`, {
        method: 'PATCH',
      });

      setNotifications(prev =>
        prev.map(notification =>
          notification._id === notificationId ? { ...notification, read: true } : notification
        )
      );

      setUnreadCount(prev => Math.max(0, prev - 1));
    } catch (err: any) {
      throw new Error(err.message || 'Failed to mark as read');
    }
  }, []);

  const markAllAsRead = useCallback(async () => {
    try {
      await apiRequest('/api/notifications/read-all', {
        method: 'PATCH',
      });

      setNotifications(prev => prev.map(notification => ({ ...notification, read: true })));
      setUnreadCount(0);
    } catch (err: any) {
      throw new Error(err.message || 'Failed to mark all as read');
    }
  }, []);

  const deleteNotification = useCallback(async (notificationId: string) => {
    try {
      await apiRequest(`/api/notifications/${notificationId}`, {
        method: 'DELETE',
      });

      setNotifications(prev => {
        const notification = prev.find(n => n._id === notificationId);
        const filtered = prev.filter(n => n._id !== notificationId);

        if (notification && !notification.read) {
          setUnreadCount(count => Math.max(0, count - 1));
        }

        return filtered;
      });
    } catch (err: any) {
      throw new Error(err.message || 'Failed to delete notification');
    }
  }, []);

  const fetchPreferences = useCallback(async () => {
    try {
      const response = await apiRequest('/api/notifications/preferences');
      setPreferences(response.data);
    } catch (err: any) {
      console.error('Failed to fetch preferences:', err);
    }
  }, []);

  const updatePreferences = useCallback(async (newPreferences: NotificationPreferences) => {
    try {
      await apiRequest('/api/notifications/preferences', {
        method: 'PUT',
        body: JSON.stringify(newPreferences),
      });

      setPreferences(newPreferences);
    } catch (err: any) {
      throw new Error(err.message || 'Failed to update preferences');
    }
  }, []);

  const createNotification = useCallback(async (notificationData: Partial<Notification>) => {
    try {
      const response = await apiRequest('/api/notifications', {
        method: 'POST',
        body: JSON.stringify(notificationData),
      });

      setNotifications(prev => [response.data, ...prev]);
      if (!response.data.read) {
        setUnreadCount(prev => prev + 1);
      }

      return response.data;
    } catch (err: any) {
      throw new Error(err.message || 'Failed to create notification');
    }
  }, []);

  const subscribeToNotifications = useCallback(() => {
    // Disable WebSocket notifications to prevent connection errors
    // TODO: Re-enable when WebSocket server is properly configured
    return () => {}; // Return empty cleanup function

    // Import Socket.IO client
    import('socket.io-client').then(({ io }) => {
      const socketUrl = process.env.NEXT_PUBLIC_WS_URL || (window.location.hostname === 'localhost' ? 'https://iamai.global' : 'https://iamai.global');
      const socket = io(socketUrl);

      socket.on('notification', (notification) => {
        try {
          setNotifications(prev => [notification, ...prev]);
          setUnreadCount(prev => prev + 1);
        } catch (error) {
          console.error('Failed to parse notification:', error);
        }
      });

      socket.on('error', (error) => {
        console.error('WebSocket error:', error);
      });

      return () => {
        socket.disconnect();
      };
    });
  }, []);

  const unsubscribeFromNotifications = useCallback(() => {
    // This would be handled by the WebSocket cleanup in subscribeToNotifications
    return () => {};
  }, []);

  // Load preferences on mount
  useEffect(() => {
    fetchPreferences();
  }, [fetchPreferences]);

  return {
    notifications,
    unreadCount,
    preferences,
    loading,
    error,
    fetchNotifications,
    markAsRead,
    markAllAsRead,
    deleteNotification,
    updatePreferences,
    createNotification,
    subscribeToNotifications,
    unsubscribeFromNotifications,
  };
};
