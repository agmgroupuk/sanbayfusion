import { useState, useEffect, useCallback } from 'react';
import { api } from '../services/api';
import { STORAGE_KEYS } from '../types/Constants';
import type { User } from '../types/User';
import type { AuthResponse } from '../types/APIResponses';

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
}

interface AuthActions {
  login: (email: string, password: string) => Promise<boolean>;
  register: (email: string, password: string, username?: string) => Promise<boolean>;
  logout: () => Promise<void>;
  refreshToken: () => Promise<boolean>;
  clearError: () => void;
  updateUser: (userData: Partial<User>) => void;
}

export const useAuth = (): AuthState & AuthActions => {
  const [state, setState] = useState<AuthState>({
    user: null,
    isAuthenticated: false,
    isLoading: true,
    error: null,
  });

  // Initialize auth state from storage
  useEffect(() => {
    const initAuth = () => {
      const token = localStorage.getItem(STORAGE_KEYS.ACCESS_TOKEN);
      const userData = localStorage.getItem(STORAGE_KEYS.USER_DATA);

      if (token && userData) {
        try {
          const user = JSON.parse(userData);
          setState(prev => ({
            ...prev,
            user,
            isAuthenticated: true,
            isLoading: false,
          }));
        } catch (error) {
          localStorage.removeItem(STORAGE_KEYS.ACCESS_TOKEN);
          localStorage.removeItem(STORAGE_KEYS.USER_DATA);
          setState(prev => ({ ...prev, isLoading: false }));
        }
      } else {
        setState(prev => ({ ...prev, isLoading: false }));
      }
    };

    initAuth();
  }, []);

  const setAuthData = (authResponse: AuthResponse) => {
    const { user, tokens } = authResponse;

    localStorage.setItem(STORAGE_KEYS.ACCESS_TOKEN, tokens.accessToken);
    localStorage.setItem(STORAGE_KEYS.REFRESH_TOKEN, tokens.refreshToken);
    localStorage.setItem(STORAGE_KEYS.USER_DATA, JSON.stringify(user));

    setState(prev => ({
      ...prev,
      user,
      isAuthenticated: true,
      error: null,
    }));
  };

  const clearAuthData = () => {
    localStorage.removeItem(STORAGE_KEYS.ACCESS_TOKEN);
    localStorage.removeItem(STORAGE_KEYS.REFRESH_TOKEN);
    localStorage.removeItem(STORAGE_KEYS.USER_DATA);

    setState(prev => ({
      ...prev,
      user: null,
      isAuthenticated: false,
      error: null,
    }));
  };

  const login = useCallback(async (email: string, password: string): Promise<boolean> => {
    setState(prev => ({ ...prev, isLoading: true, error: null }));

    try {
      const response = await api.auth.login(email, password);

      if (response.success && response.data) {
        setAuthData(response.data);
        return true;
      } else {
        setState(prev => ({
          ...prev,
          error: response.error?.message || 'Login failed',
          isLoading: false,
        }));
        return false;
      }
    } catch (error) {
      setState(prev => ({
        ...prev,
        error: 'Network error occurred',
        isLoading: false,
      }));
      return false;
    }
  }, []);

  const register = useCallback(
    async (email: string, password: string, username?: string): Promise<boolean> => {
      setState(prev => ({ ...prev, isLoading: true, error: null }));

      try {
        const response = await api.auth.register(email, password, username);

        if (response.success && response.data) {
          setAuthData(response.data);
          return true;
        } else {
          setState(prev => ({
            ...prev,
            error: response.error?.message || 'Registration failed',
            isLoading: false,
          }));
          return false;
        }
      } catch (error) {
        setState(prev => ({
          ...prev,
          error: 'Network error occurred',
          isLoading: false,
        }));
        return false;
      }
    },
    []
  );

  const logout = useCallback(async (): Promise<void> => {
    try {
      await api.auth.logout();
    } catch (error) {
      console.warn('Logout API call failed:', error);
    } finally {
      clearAuthData();
    }
  }, []);

  const refreshToken = useCallback(async (): Promise<boolean> => {
    try {
      const response = await api.auth.refreshToken();

      if (response.success && response.data) {
        setAuthData(response.data);
        return true;
      } else {
        clearAuthData();
        return false;
      }
    } catch (error) {
      clearAuthData();
      return false;
    }
  }, []);

  const clearError = useCallback(() => {
    setState(prev => ({ ...prev, error: null }));
  }, []);

  const updateUser = useCallback((userData: Partial<User>) => {
    setState(prev => {
      if (!prev.user) return prev;

      const updatedUser = { ...prev.user, ...userData };
      localStorage.setItem(STORAGE_KEYS.USER_DATA, JSON.stringify(updatedUser));

      return {
        ...prev,
        user: updatedUser,
      };
    });
  }, []);

  return {
    ...state,
    login,
    register,
    logout,
    refreshToken,
    clearError,
    updateUser,
  };
};
