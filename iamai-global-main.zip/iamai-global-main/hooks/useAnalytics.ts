/**
 * 🎯 Custom Hook for Analytics
 * Manage analytics data, sessions, and agent statistics
 */

import { useState, useCallback } from 'react';
import { apiRequest } from '../../services/api';

export interface AnalyticsEvent {
  _id: string;
  userId: string;
  eventType: string;
  eventData: Record<string, any>;
  metadata: Record<string, any>;
  timestamp: Date;
}

export interface SessionData {
  totalSessions: number;
  avgDuration: number;
  durationTrend: Array<{
    date: string;
    avgDuration: number;
  }>;
  pageViewsDistribution: Array<{
    range: string;
    sessions: number;
  }>;
}

export interface AgentData {
  _id: string;
  interactions: number;
  totalTokens: number;
  avgDuration: number;
  models: string[];
}

export interface AnalyticsData {
  events: Array<{
    name: string;
    count: number;
  }>;
  dailyActivity: Array<{
    date: string;
    events: number;
  }>;
}

export const useAnalytics = () => {
  const [analytics, setAnalytics] = useState<AnalyticsData | null>(null);
  const [sessions, setSessions] = useState<SessionData | null>(null);
  const [agents, setAgents] = useState<AgentData[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchAnalytics = useCallback(
    async (params?: { startDate?: Date; endDate?: Date; eventType?: string }) => {
      setLoading(true);
      setError(null);

      try {
        const queryParams = new URLSearchParams();
        if (params?.startDate) queryParams.append('startDate', params.startDate.toISOString());
        if (params?.endDate) queryParams.append('endDate', params.endDate.toISOString());
        if (params?.eventType) queryParams.append('eventType', params.eventType);

        const [analyticsResponse, sessionsResponse, agentsResponse] = await Promise.all([
          apiRequest(`/api/analytics/summary?${queryParams}`),
          apiRequest(`/api/analytics/sessions?${queryParams}`),
          apiRequest(`/api/analytics/agents?${queryParams}`),
        ]);

        setAnalytics(analyticsResponse.data);
        setSessions(sessionsResponse.data);
        setAgents(agentsResponse.data);
      } catch (err: any) {
        setError(err.message || 'Failed to fetch analytics');
      } finally {
        setLoading(false);
      }
    },
    []
  );

  const trackEvent = useCallback(
    async (eventType: string, eventData: Record<string, any>, metadata?: Record<string, any>) => {
      try {
        await apiRequest('/api/analytics/events', {
          method: 'POST',
          body: JSON.stringify({
            eventType,
            eventData,
            metadata,
          }),
        });
      } catch (err: any) {
        console.error('Failed to track event:', err);
      }
    },
    []
  );

  const exportData = useCallback(async (timeRange: string) => {
    try {
      const response = await apiRequest(`/api/analytics/export?timeRange=${timeRange}`, {
        method: 'GET',
      });

      // Create and download file
      const blob = new Blob([JSON.stringify(response.data, null, 2)], {
        type: 'application/json',
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `analytics-${timeRange}-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err: any) {
      throw new Error(err.message || 'Failed to export data');
    }
  }, []);

  const getRealtimeStats = useCallback(async () => {
    try {
      const response = await apiRequest('/api/analytics/realtime');
      return response.data;
    } catch (err: any) {
      console.error('Failed to get realtime stats:', err);
      return null;
    }
  }, []);

  return {
    analytics,
    sessions,
    agents,
    loading,
    error,
    fetchAnalytics,
    trackEvent,
    exportData,
    getRealtimeStats,
  };
};
