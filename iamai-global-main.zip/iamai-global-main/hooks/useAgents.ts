import { useState, useEffect, useCallback } from 'react';
import { api } from '../services/api';
import type { Agent, AgentCategory } from '../types/Agent';
import type { AgentListResponse } from '../types/APIResponses';

interface AgentsState {
  agents: Agent[];
  categories: AgentCategory[];
  selectedAgent: Agent | null;
  isLoading: boolean;
  error: string | null;
  filters: {
    category?: AgentCategory;
    search?: string;
  };
}

interface AgentsActions {
  loadAgents: (category?: AgentCategory) => Promise<void>;
  loadAgent: (agentId: string) => Promise<Agent | null>;
  selectAgent: (agent: Agent | null) => void;
  setFilter: (filters: Partial<AgentsState['filters']>) => void;
  clearFilters: () => void;
  clearError: () => void;
}

export const useAgents = (): AgentsState & AgentsActions => {
  const [state, setState] = useState<AgentsState>({
    agents: [],
    categories: [],
    selectedAgent: null,
    isLoading: false,
    error: null,
    filters: {},
  });

  const loadAgents = useCallback(async (category?: AgentCategory): Promise<void> => {
    setState(prev => ({ ...prev, isLoading: true, error: null }));

    try {
      const response = await api.agents.getAgents(category);

      if (response.success && response.data) {
        const { agents, categories: availableCategories } = response.data;

        setState(prev => ({
          ...prev,
          agents: agents || [],
          categories: availableCategories || [],
          isLoading: false,
        }));
      } else {
        setState(prev => ({
          ...prev,
          error: response.error?.message || 'Failed to load agents',
          isLoading: false,
        }));
      }
    } catch (error) {
      setState(prev => ({
        ...prev,
        error: 'Network error occurred',
        isLoading: false,
      }));
    }
  }, []);

  const loadAgent = useCallback(async (agentId: string): Promise<Agent | null> => {
    setState(prev => ({ ...prev, isLoading: true, error: null }));

    try {
      const response = await api.agents.getAgent(agentId);

      if (response.success && response.data) {
        const agent = response.data;

        setState(prev => ({
          ...prev,
          selectedAgent: agent,
          isLoading: false,
        }));

        return agent;
      } else {
        setState(prev => ({
          ...prev,
          error: response.error?.message || 'Failed to load agent',
          isLoading: false,
        }));
        return null;
      }
    } catch (error) {
      setState(prev => ({
        ...prev,
        error: 'Network error occurred',
        isLoading: false,
      }));
      return null;
    }
  }, []);

  const selectAgent = useCallback((agent: Agent | null) => {
    setState(prev => ({ ...prev, selectedAgent: agent }));
  }, []);

  const setFilter = useCallback((filters: Partial<AgentsState['filters']>) => {
    setState(prev => ({
      ...prev,
      filters: { ...prev.filters, ...filters },
    }));
  }, []);

  const clearFilters = useCallback(() => {
    setState(prev => ({
      ...prev,
      filters: {},
    }));
  }, []);

  const clearError = useCallback(() => {
    setState(prev => ({ ...prev, error: null }));
  }, []);

  // Filter agents based on current filters
  const filteredAgents = state.agents.filter(agent => {
    if (state.filters.category && agent.category !== state.filters.category) {
      return false;
    }

    if (state.filters.search) {
      const searchTerm = state.filters.search.toLowerCase();
      return (
        agent.name.toLowerCase().includes(searchTerm) ||
        agent.description.toLowerCase().includes(searchTerm)
      );
    }

    return true;
  });

  return {
    ...state,
    agents: filteredAgents,
    loadAgents,
    loadAgent,
    selectAgent,
    setFilter,
    clearFilters,
    clearError,
  };
};
