import { useState, useEffect, useCallback, useRef } from 'react';
import { api } from '../services/api';
import type { ChatSession, ChatMessage } from '../types/Chat';
import type { ChatResponse } from '../types/APIResponses';

interface ChatState {
  sessions: ChatSession[];
  currentSession: ChatSession | null;
  messages: ChatMessage[];
  isLoading: boolean;
  isSending: boolean;
  error: string | null;
}

interface ChatActions {
  loadSessions: () => Promise<void>;
  createSession: (agentId: string, title?: string) => Promise<ChatSession | null>;
  selectSession: (sessionId: string) => Promise<void>;
  sendMessage: (content: string, files?: File[]) => Promise<ChatMessage | null>;
  deleteSession: (sessionId: string) => Promise<boolean>;
  clearError: () => void;
  clearCurrentSession: () => void;
}

export const useChat = (): ChatState & ChatActions => {
  const [state, setState] = useState<ChatState>({
    sessions: [],
    currentSession: null,
    messages: [],
    isLoading: false,
    isSending: false,
    error: null,
  });

  const abortControllerRef = useRef<AbortController | null>(null);

  const loadSessions = useCallback(async (): Promise<void> => {
    setState(prev => ({ ...prev, isLoading: true, error: null }));

    try {
      const response = await api.chat.getSessions();

      if (response.success && response.data) {
        setState(prev => ({
          ...prev,
          sessions: response.data || [],
          isLoading: false,
        }));
      } else {
        setState(prev => ({
          ...prev,
          error: response.error?.message || 'Failed to load sessions',
          isLoading: false,
        }));
      }
    } catch (error) {
      setState(prev => ({
        ...prev,
        error: 'Network error occurred',
        isLoading: false,
      }));
    }
  }, []);

  const createSession = useCallback(
    async (agentId: string, title?: string): Promise<ChatSession | null> => {
      setState(prev => ({ ...prev, isLoading: true, error: null }));

      try {
        const response = await api.chat.createSession(agentId, title);

        if (response.success && response.data) {
          const newSession = response.data;

          setState(prev => ({
            ...prev,
            sessions: [newSession, ...prev.sessions],
            currentSession: newSession,
            messages: [],
            isLoading: false,
          }));

          return newSession;
        } else {
          setState(prev => ({
            ...prev,
            error: response.error?.message || 'Failed to create session',
            isLoading: false,
          }));
          return null;
        }
      } catch (error) {
        setState(prev => ({
          ...prev,
          error: 'Network error occurred',
          isLoading: false,
        }));
        return null;
      }
    },
    []
  );

  const selectSession = useCallback(
    async (sessionId: string): Promise<void> => {
      setState(prev => ({ ...prev, isLoading: true, error: null }));

      try {
        const session = state.sessions.find(s => s.id === sessionId);
        if (!session) {
          throw new Error('Session not found');
        }

        const response = await api.chat.getMessages(sessionId);

        if (response.success && response.data) {
          setState(prev => ({
            ...prev,
            currentSession: session,
            messages: response.data || [],
            isLoading: false,
          }));
        } else {
          setState(prev => ({
            ...prev,
            error: response.error?.message || 'Failed to load messages',
            isLoading: false,
          }));
        }
      } catch (error) {
        setState(prev => ({
          ...prev,
          error: error instanceof Error ? error.message : 'Network error occurred',
          isLoading: false,
        }));
      }
    },
    [state.sessions]
  );

  const sendMessage = useCallback(
    async (content: string, files?: File[]): Promise<ChatMessage | null> => {
      if (!state.currentSession) {
        setState(prev => ({ ...prev, error: 'No active session' }));
        return null;
      }

      setState(prev => ({ ...prev, isSending: true, error: null }));

      // Add user message optimistically
      const userMessage: ChatMessage = {
        id: `temp-${Date.now()}`,
        sessionId: state.currentSession.id,
        role: 'user',
        content,
        timestamp: new Date().toISOString(),
        metadata: {},
        attachments: files
          ? files.map(f => ({
              id: `temp-file-${Date.now()}`,
              name: f.name,
              type: f.type,
              size: f.size,
              url: '',
              uploadedAt: new Date().toISOString(),
            }))
          : undefined,
      };

      setState(prev => ({
        ...prev,
        messages: [...prev.messages, userMessage],
      }));

      try {
        // Abort previous request if still pending
        if (abortControllerRef.current) {
          abortControllerRef.current.abort();
        }

        abortControllerRef.current = new AbortController();

        const response = await api.chat.sendMessage(state.currentSession.id, content, files);

        if (response.success && response.data) {
          const { message: assistantMessage } = response.data;

          setState(prev => ({
            ...prev,
            messages: [
              ...prev.messages.filter(m => m.id !== userMessage.id),
              userMessage,
              assistantMessage,
            ],
            isSending: false,
          }));

          return assistantMessage;
        } else {
          setState(prev => ({
            ...prev,
            error: response.error?.message || 'Failed to send message',
            isSending: false,
            messages: prev.messages.filter(m => m.id !== userMessage.id),
          }));
          return null;
        }
      } catch (error) {
        setState(prev => ({
          ...prev,
          error: 'Network error occurred',
          isSending: false,
          messages: prev.messages.filter(m => m.id !== userMessage.id),
        }));
        return null;
      }
    },
    [state.currentSession]
  );

  const deleteSession = useCallback(async (sessionId: string): Promise<boolean> => {
    try {
      const response = await api.chat.deleteSession(sessionId);

      if (response.success) {
        setState(prev => ({
          ...prev,
          sessions: prev.sessions.filter(s => s.id !== sessionId),
          currentSession: prev.currentSession?.id === sessionId ? null : prev.currentSession,
          messages: prev.currentSession?.id === sessionId ? [] : prev.messages,
        }));
        return true;
      } else {
        setState(prev => ({
          ...prev,
          error: response.error?.message || 'Failed to delete session',
        }));
        return false;
      }
    } catch (error) {
      setState(prev => ({
        ...prev,
        error: 'Network error occurred',
      }));
      return false;
    }
  }, []);

  const clearError = useCallback(() => {
    setState(prev => ({ ...prev, error: null }));
  }, []);

  const clearCurrentSession = useCallback(() => {
    setState(prev => ({
      ...prev,
      currentSession: null,
      messages: [],
    }));
  }, []);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }
    };
  }, []);

  return {
    ...state,
    loadSessions,
    createSession,
    selectSession,
    sendMessage,
    deleteSession,
    clearError,
    clearCurrentSession,
  };
};
