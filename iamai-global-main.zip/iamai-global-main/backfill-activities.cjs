const mongoose = require('mongoose');

const activitySchema = new mongoose.Schema({
  userId: mongoose.Schema.Types.ObjectId,
  sessionId: String,
  action: String,
  route: String,
  method: String,
  statusCode: Number,
  metadata: mongoose.Schema.Types.Mixed,
  isAnonymous: Boolean,
  createdAt: Date
}, { collection: 'activity_logs', timestamps: true });

const ActivityLog = mongoose.model('ActivityLog', activitySchema);

const purchaseSchema = new mongoose.Schema({
  userId: mongoose.Schema.Types.ObjectId,
  agentId: String,
  agentName: String,
  status: String,
  plan: String,
  pricing: { amount: Number, currency: String },
  createdAt: Date
}, { collection: 'agent_purchases' });

const AgentPurchase = mongoose.model('AgentPurchase', purchaseSchema);

mongoose.connect('mongodb+srv://iamai-global:miczugamark@iamai-global.pwzfji.mongodb.net/iamai-global')
  .then(async () => {
    const userId = '6951abd31f738aaf7413823b';
    
    const purchases = await AgentPurchase.find({
      userId: new mongoose.Types.ObjectId(userId),
      status: 'ACTIVE'
    }).lean();
    
    console.log('Found', purchases.length, 'active purchases');
    
    for (const p of purchases) {
      const existing = await ActivityLog.findOne({
        userId: new mongoose.Types.ObjectId(userId),
        action: 'AGENT_PURCHASED',
        'metadata.purchaseId': p._id.toString()
      });
      
      if (existing) {
        console.log('Activity already exists for:', p.agentId);
        continue;
      }
      
      await ActivityLog.create({
        userId: new mongoose.Types.ObjectId(userId),
        sessionId: 'purchase_' + p._id,
        action: 'AGENT_PURCHASED',
        route: '/api/purchases/grant',
        method: 'POST',
        statusCode: 200,
        metadata: {
          agentId: p.agentId,
          agentName: p.agentName || p.agentId,
          plan: p.plan,
          purchaseId: p._id.toString(),
          amount: p.pricing ? p.pricing.amount : 0,
          source: 'backfill'
        },
        isAnonymous: false,
        createdAt: p.createdAt
      });
      console.log('Created activity for:', p.agentId, p.plan);
    }
    
    mongoose.disconnect();
  });
