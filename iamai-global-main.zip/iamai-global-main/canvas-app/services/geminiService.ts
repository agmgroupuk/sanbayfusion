
import { GoogleGenAI } from "@google/genai";

// Fallback service for direct API calls (when backend is unavailable)
const SYSTEM_INSTRUCTION = `You are a world-class senior frontend engineer and UI/UX designer.
Your task is to generate or modify a complete, high-quality, single-file HTML application.

Rules for generated code:
1. Use Tailwind CSS via CDN (<script src="https://cdn.tailwindcss.com"></script>).
2. Use Lucide icons via CDN (<script src="https://unpkg.com/lucide@latest"></script>).
3. Ensure the design is modern, professional, and mobile-responsive.
4. Include all necessary JavaScript.
5. The output MUST be a single, valid HTML file containing <html>, <head>, and <body> tags.
6. Return ONLY the code. No explanations, no markdown blocks.
7. Always return the FULL updated file.`;

// Backend API base URL
const API_BASE = process.env.NODE_ENV === 'production'
  ? 'https://iamai.global/api'
  : 'http://localhost:3001/api';

export interface GenerateRequest {
  prompt: string;
  model?: string;
  provider?: string;
  isThinking?: boolean;
  currentCode?: string;
  history?: any[];
  temperature?: number;
}

export interface GenerateResponse {
  code: string;
  provider: string;
  model: string;
  usage?: any;
  thinking?: boolean;
}

export interface ProviderInfo {
  name: string;
  available: boolean;
  models: string[];
}

export interface ProvidersResponse {
  providers: Record<string, ProviderInfo>;
  availableKeys: string[];
}

export interface Template {
  id: string;
  name: string;
  description: string;
  prompt: string;
}

export interface TemplatesResponse {
  templates: Template[];
}

/**
 * Generate app code using backend API with multi-provider support
 */
export async function generateAppCode(
  prompt: string,
  modelId: string = 'gemini-pro',
  isThinking: boolean = false,
  currentCode?: string,
  history: any[] = []
): Promise<string> {
  try {
    const request: GenerateRequest = {
      prompt,
      model: modelId,
      provider: getProviderFromModel(modelId),
      isThinking,
      currentCode,
      history,
      temperature: isThinking ? 1 : 0.7
    };

    console.log('🎨 Generating with backend API:', {
      model: modelId,
      provider: request.provider,
      isThinking
    });

    const response = await fetch(`${API_BASE}/canvas/generate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(request)
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || `HTTP ${response.status}`);
    }

    const result: GenerateResponse = await response.json();
    return cleanCode(result.code);

  } catch (error) {
    console.error('Backend API failed, falling back to direct API:', error);

    // Fallback to direct Gemini API call
    return await generateWithGeminiFallback(prompt, modelId, isThinking, currentCode, history);
  }
}

/**
 * Get available providers and their status
 */
export async function getAvailableProviders(): Promise<ProvidersResponse> {
  try {
    const response = await fetch(`${API_BASE}/canvas/providers`);
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }
    return await response.json();
  } catch (error) {
    console.error('Failed to fetch providers:', error);
    // Return fallback providers
    return {
      providers: {
        gemini: {
          name: 'Google Gemini',
          available: true,
          models: ['gemini-pro', 'gemini-pro-vision']
        }
      },
      availableKeys: ['gemini']
    };
  }
}

/**
 * Get predefined templates
 */
export async function getTemplates(): Promise<TemplatesResponse> {
  try {
    const response = await fetch(`${API_BASE}/canvas/templates`);
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }
    return await response.json();
  } catch (error) {
    console.error('Failed to fetch templates:', error);
    // Return fallback templates
    return {
      templates: [
        {
          id: 'landing-page',
          name: 'Landing Page',
          description: 'Modern SaaS landing page',
          prompt: 'Create a modern SaaS landing page with hero section, features, and CTA.'
        }
      ]
    };
  }
}

/**
 * Fallback: Generate with direct Gemini API (original implementation)
 */
async function generateWithGeminiFallback(
  prompt: string,
  modelId: string,
  isThinking: boolean,
  currentCode?: string,
  history: any[] = []
): Promise<string> {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "" });

  const contents: any[] = [];

  if (currentCode) {
    contents.push({ role: 'user', parts: [{ text: `Current code:\n${currentCode}` }] });
  }

  history.forEach(msg => {
    contents.push({
      role: msg.role === 'user' ? 'user' : 'model',
      parts: [{ text: msg.text }]
    });
  });

  contents.push({ role: 'user', parts: [{ text: prompt }] });

  const config: any = {
    systemInstruction: SYSTEM_INSTRUCTION,
    temperature: isThinking ? 1 : 0.7,
  };

  if (isThinking) {
    config.thinkingConfig = { thinkingBudget: 32768 };
  }

  try {
    const response = await ai.models.generateContent({
      model: modelId,
      contents,
      config,
    });
    return cleanCode(response.text || "");
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw new Error("Failed to process request. Check if the selected model is available.");
  }
}

/**
 * Map model ID to provider
 */
function getProviderFromModel(modelId: string): string {
  if (modelId.startsWith('gpt-')) return 'openai';
  if (modelId.startsWith('claude-')) return 'anthropic';
  if (modelId.startsWith('llama-') || modelId.startsWith('mixtral-')) return 'groq';
  return 'openai'; // default to openai since it's the primary provider
}

function cleanCode(text: string): string {
  return text.replace(/```html/g, "").replace(/```/g, "").trim();
}
