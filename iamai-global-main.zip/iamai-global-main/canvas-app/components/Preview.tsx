import React, { useEffect, useRef } from 'react';

interface PreviewProps {
  code: string;
}

const Preview: React.FC<PreviewProps> = ({ code }) => {
  const iframeRef = useRef<HTMLIFrameElement>(null);

  useEffect(() => {
    if (iframeRef.current && code) {
      const doc = iframeRef.current.contentWindow?.document;
      if (doc) {
        doc.open();
        doc.write(code);
        doc.close();
      }
    }
  }, [code]);

  if (!code) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-gray-200 bg-[#0f1018]">
        <div className="w-16 h-16 rounded-2xl border border-[#1c1e2b] flex items-center justify-center bg-[#11121a] text-cyan-300 mb-4">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="h-8 w-8"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={1.6}
              d="M5 5l2 6-6 2 6 2 2 6 2-6 6-2-6-2-2-6z"
            />
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={1.6}
              d="M14 4l.5 2m3.5 3.5l2 .5m-7 7l.5 2m-7.5-7l2-.5m3-3 1-1m2 2 1-1"
            />
          </svg>
        </div>
        <p className="text-xl font-semibold text-cyan-300">Ready to Create</p>
        <p className="text-sm text-gray-400 mt-1">Select a template or describe what you want.</p>
        <p className="text-sm text-fuchsia-300 mt-1">Preview will appear here!</p>
      </div>
    );
  }

  return (
    <div className="w-full h-full bg-[#0f1018] shadow-sm overflow-hidden flex flex-col border border-[#161825] rounded-xl">
      <div className="flex items-center gap-2 px-4 py-2 bg-[#11121a] border-b border-[#161825] text-xs text-gray-400">
        <div className="flex gap-1.5">
          <div className="w-3 h-3 rounded-full bg-red-500"></div>
          <div className="w-3 h-3 rounded-full bg-yellow-400"></div>
          <div className="w-3 h-3 rounded-full bg-green-500"></div>
        </div>
        <div className="flex-1 text-center font-mono opacity-60 truncate text-gray-400">
          localhost:3000/generated-app
        </div>
      </div>
      <iframe
        ref={iframeRef}
        title="App Preview"
        className="w-full h-full border-none"
        sandbox="allow-scripts allow-forms allow-popups allow-modals allow-downloads allow-same-origin"
      />
    </div>
  );
};

export default Preview;
