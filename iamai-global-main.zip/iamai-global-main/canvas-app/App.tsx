import React, { useState, useEffect, useRef } from 'react';
import { GeneratedApp, ViewMode, GenerationState, ChatMessage, ModelOption } from './types';
import {
  generateAppCode,
  getAvailableProviders,
  getTemplates,
  ProviderInfo,
  Template,
} from './services/geminiService';
import Preview from './components/Preview';
import CodeView from './components/CodeView';
import ChatBox from './components/ChatBox';

type ActivePanel = 'workspace' | 'assistant' | 'history' | 'code' | 'device' | null;
type NavItemId = 'codeAction' | 'expand' | 'view' | 'play' | 'copy';

type DeviceView = 'desktop' | 'tablet' | 'mobile';

const App: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [selectedModel, setSelectedModel] = useState<ModelOption | null>(null);
  const [viewMode, setViewMode] = useState<ViewMode>(ViewMode.PREVIEW);
  const [currentApp, setCurrentApp] = useState<GeneratedApp | null>(null);
  const [history, setHistory] = useState<GeneratedApp[]>([]);
  const [activePanel, setActivePanel] = useState<ActivePanel>(null);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const [availableProviders, setAvailableProviders] = useState<Record<string, ProviderInfo>>({});
  const [templates, setTemplates] = useState<Template[]>([]);
  const [deviceView, setDeviceView] = useState<DeviceView>('desktop');
  const [previewRefreshKey, setPreviewRefreshKey] = useState(0);
  const [navOpen, setNavOpen] = useState(true);
  const [copyMessage, setCopyMessage] = useState<string | null>(null);
  const [genState, setGenState] = useState<GenerationState>({
    isGenerating: false,
    error: null,
    progressMessage: '',
  });

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setDropdownOpen(false);
      }
    };

    if (dropdownOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [dropdownOpen]);

  useEffect(() => {
    const saved = localStorage.getItem('gencraft_v4_history');
    if (saved)
      try {
        setHistory(JSON.parse(saved));
      } catch (e) {}
  }, []);

  // Load available providers and templates
  useEffect(() => {
    const loadProvidersAndTemplates = async () => {
      try {
        const [providersResponse, templatesResponse] = await Promise.all([
          getAvailableProviders(),
          getTemplates(),
        ]);

        setAvailableProviders(providersResponse.providers);
        setTemplates(templatesResponse.templates);

        // Set default model from first available provider
        const availableProviderKeys = Object.keys(providersResponse.providers).filter(
          key => providersResponse.providers[key].available
        );

        if (availableProviderKeys.length > 0) {
          const defaultProvider = providersResponse.providers[availableProviderKeys[0]];
          if (defaultProvider.models.length > 0) {
            setSelectedModel({
              id: defaultProvider.models[0],
              name: `${defaultProvider.name} ${defaultProvider.models[0].split('-').pop()}`,
              provider: defaultProvider.name,
              description: `Default model from ${defaultProvider.name}`,
            });
          }
        }
      } catch (error) {
        console.error('Failed to load providers and templates:', error);
        // Fallback to basic Gemini model
        setSelectedModel({
          id: 'gemini-pro',
          name: 'Gemini Pro',
          provider: 'Gemini',
          description: 'Google Gemini Pro model',
        });
      }
    };

    loadProvidersAndTemplates();
  }, []);

  const saveHistory = (newHistory: GeneratedApp[]) => {
    setHistory(newHistory);
    localStorage.setItem('gencraft_v4_history', JSON.stringify(newHistory));
  };

  const handleGenerate = async (instruction: string, isInitial: boolean = false) => {
    if (!instruction.trim() || genState.isGenerating || !selectedModel) return;

    setGenState({
      isGenerating: true,
      error: null,
      progressMessage: selectedModel.isThinking
        ? 'Deep thinking in progress...'
        : 'Building application...',
      isThinking: selectedModel.isThinking,
    });

    try {
      const code = await generateAppCode(
        instruction,
        selectedModel.id,
        !!selectedModel.isThinking,
        isInitial ? undefined : currentApp?.code,
        isInitial ? [] : currentApp?.history
      );

      const userMsg: ChatMessage = { role: 'user', text: instruction, timestamp: Date.now() };
      const modelMsg: ChatMessage = {
        role: 'model',
        text: isInitial ? 'Application built!' : 'Changes applied.',
        timestamp: Date.now(),
      };

      if (isInitial) {
        const newApp: GeneratedApp = {
          id: Date.now().toString(),
          name: instruction.substring(0, 30) + '...',
          code,
          prompt: instruction,
          timestamp: Date.now(),
          history: [modelMsg],
        };
        setCurrentApp(newApp);
        saveHistory([newApp, ...history].slice(0, 10));
      } else if (currentApp) {
        const updatedApp = {
          ...currentApp,
          code,
          history: [...currentApp.history, userMsg, modelMsg],
        };
        setCurrentApp(updatedApp);
        saveHistory(history.map(a => (a.id === updatedApp.id ? updatedApp : a)));
      }

      setGenState({ isGenerating: false, error: null, progressMessage: '' });
      setViewMode(ViewMode.PREVIEW);
    } catch (err: any) {
      setGenState({ isGenerating: false, error: err.message, progressMessage: '' });
    }
  };

  const togglePanel = (panel: ActivePanel) => {
    setActivePanel(activePanel === panel ? null : panel);
  };

  const iconFor = (id: NavItemId, size = 22) => {
    const common = {
      xmlns: 'http://www.w3.org/2000/svg',
      className: 'stroke-current',
      fill: 'none',
      viewBox: '0 0 24 24',
      stroke: 'currentColor',
      strokeWidth: 1.8,
      style: { width: size, height: size },
    } as const;

    switch (id) {
      case 'codeAction':
        return (
          <svg {...common}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M9 18l-6-6 6-6m6 12l6-6-6-6" />
          </svg>
        );
      case 'expand':
        return (
          <svg {...common}>
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M4 9V4h5M15 4h5v5M20 15v5h-5M9 20H4v-5"
            />
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M9 9L5 5m10 0l4 4m0 6l-4 4m-6 0l-4-4"
            />
          </svg>
        );
      case 'view':
        return (
          <svg {...common}>
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M2.5 12s3.5-6 9.5-6 9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6z"
            />
            <circle cx="12" cy="12" r="2.5" />
          </svg>
        );
      case 'play':
        return (
          <svg {...common}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M8 5l11 7-11 7V5z" />
          </svg>
        );
      case 'copy':
        return (
          <svg {...common}>
            <rect x="9" y="9" width="11" height="11" rx="2" ry="2" />
            <path strokeLinecap="round" strokeLinejoin="round" d="M6 15V5a2 2 0 012-2h10" />
          </svg>
        );
      default:
        return null;
    }
  };

  const isActiveNav = (id: NavItemId) => {
    if (id === 'expand') return navOpen;
    if (id === 'codeAction') return viewMode === ViewMode.CODE || activePanel === 'code';
    if (id === 'view') return viewMode === ViewMode.PREVIEW;
    if (id === 'play') return false;
    if (id === 'copy') return false;
    return false;
  };

  const handleNavAction = (id: NavItemId) => {
    switch (id) {
      case 'expand':
        setNavOpen(open => !open);
        setActivePanel(open => (open ? null : 'workspace'));
        break;
      case 'codeAction':
        setViewMode(ViewMode.CODE);
        setActivePanel('code');
        setNavOpen(true);
        break;
      case 'view':
        setViewMode(ViewMode.PREVIEW);
        setActivePanel(null);
        setNavOpen(true);
        break;
      case 'play':
        handleRefreshPreview();
        setNavOpen(true);
        break;
      case 'copy': {
        const text = currentApp?.code || '';
        if (!text) {
          setCopyMessage('No code to copy');
          setTimeout(() => setCopyMessage(null), 1500);
          return;
        }
        navigator.clipboard
          .writeText(text)
          .then(() => {
            setCopyMessage('Code copied');
            setTimeout(() => setCopyMessage(null), 1500);
          })
          .catch(() => {
            setCopyMessage('Copy failed');
            setTimeout(() => setCopyMessage(null), 1500);
          });
        break;
      }
      default:
        break;
    }
  };

  const navItems: { id: NavItemId; label: string }[] = [
    { id: 'codeAction', label: 'Code' },
    { id: 'expand', label: 'Expand' },
    { id: 'view', label: 'Preview' },
    { id: 'play', label: 'Run' },
    { id: 'copy', label: 'Copy' },
  ];

  const handleRefreshPreview = () => {
    setViewMode(ViewMode.PREVIEW);
    setPreviewRefreshKey(key => key + 1);
  };

  const deviceWidthClass = {
    desktop: 'max-w-6xl w-full',
    tablet: 'max-w-3xl w-full',
    mobile: 'max-w-sm w-full',
  }[deviceView];

  return (
    <div className="flex h-screen bg-[#0c0d14] text-gray-100">
      {/* 1. Left Vertical Nav Bar + Slide-out Drawer */}
      <div className="relative">
        <nav className="w-16 bg-[#0f1018] border-r border-[#151723] flex flex-col items-center py-5 gap-4 shrink-0 z-[60] shadow-2xl shadow-black/30">
          <div className="flex flex-col gap-3">
            {navItems.map(item => (
              <button
                key={item.id}
                onClick={() => handleNavAction(item.id)}
                className={`w-12 h-12 flex items-center justify-center rounded-xl border transition-all duration-150 ${
                  isActiveNav(item.id)
                    ? 'bg-gradient-to-br from-cyan-400 to-fuchsia-500 text-white shadow-lg shadow-fuchsia-500/20 border-transparent'
                    : 'bg-[#11121a] text-gray-400 border-transparent hover:border-[#232535] hover:text-white'
                }`}
                title={item.label}
              >
                {iconFor(item.id)}
              </button>
            ))}
          </div>

          <div className="mt-auto flex flex-col items-center gap-4">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse shadow-sm shadow-green-500/50" />
            <div className="w-12 h-[1px] bg-[#1f2231]" />
            <button
              onClick={handleRefreshPreview}
              className="w-12 h-12 flex items-center justify-center rounded-xl bg-[#11121a] text-gray-400 hover:text-white hover:border-[#232535] border border-transparent"
              title="Refresh preview"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-6 w-6"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={1.8}
                  d="M4 4v5h.582M20 20v-5h-.581M5 9a7 7 0 0111.906-2.906M19 15a7 7 0 01-11.906 2.906"
                />
              </svg>
            </button>
          </div>

          {copyMessage && (
            <div className="absolute left-1/2 -translate-x-1/2 bottom-4 px-3 py-2 text-[11px] rounded-lg bg-[#11121a] border border-[#232535] text-gray-100 shadow-xl">
              {copyMessage}
            </div>
          )}
        </nav>

        {/* Slide-out navigation panel */}
        <div
          className={`absolute left-16 top-0 h-full w-64 bg-[#0b0c12] border-r border-[#151723] shadow-2xl shadow-black/40 transition-all duration-300 ease-out ${
            navOpen ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-4 pointer-events-none'
          }`}
        >
          <div className="flex items-center justify-between px-4 pt-4">
            <div className="flex items-center gap-2 px-3 py-2 rounded-xl text-sm font-semibold text-white bg-gradient-to-br from-cyan-400 to-fuchsia-500 shadow-lg shadow-fuchsia-500/20">
              {iconFor('codeAction', 18)}
              <span>Editor actions</span>
            </div>
            <button
              onClick={() => setNavOpen(false)}
              className="text-gray-400 hover:text-white transition-colors"
              aria-label="Close navigation"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={1.8}
                  d="M6 18L18 6M6 6l12 12"
                />
              </svg>
            </button>
          </div>

          <div className="mt-4 px-3 space-y-2">
            {navItems.map(item => (
              <button
                key={item.id}
                onClick={() => handleNavAction(item.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all border ${
                  isActiveNav(item.id)
                    ? 'bg-gradient-to-r from-cyan-400 to-fuchsia-500 text-white border-transparent shadow-md shadow-fuchsia-500/15'
                    : 'bg-[#12131c] text-gray-200 border-[#1c1e2b] hover:border-[#2b2e40] hover:text-white'
                }`}
              >
                <span className="text-gray-200">{iconFor(item.id, 18)}</span>
                <span>{item.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* 2. Main Content Area */}
      <div className="flex-1 flex flex-col relative overflow-hidden">
        {/* Top Navbar */}
        <header className="flex items-center justify-between px-6 py-3 border-b border-[#161825] bg-[#0f1018] z-40">
          <div className="flex items-center gap-6">
            <h1 className="text-lg font-bold tracking-tight">
              IA M AI <span className="text-indigo-600">Global</span>
            </h1>

            {/* Model Selector */}
            <div className="relative" ref={dropdownRef}>
              <button
                onClick={() => setDropdownOpen(!dropdownOpen)}
                className="flex items-center gap-2 px-3 py-1.5 bg-gray-50 border border-gray-200 rounded-xl text-xs font-semibold hover:border-indigo-300 transition-colors"
                disabled={!selectedModel}
              >
                <span className="w-2 h-2 rounded-full bg-green-500"></span>
                {selectedModel ? selectedModel.name : 'Loading...'}
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className={`h-3 w-3 text-gray-400 transition-transform ${dropdownOpen ? 'rotate-180' : ''}`}
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M19 9l-7 7-7-7"
                  />
                </svg>
              </button>
              {dropdownOpen && (
                <div className="absolute top-full left-0 mt-1 w-64 bg-white border border-gray-100 rounded-2xl shadow-2xl z-50 p-2 max-h-80 overflow-y-auto">
                  <p className="px-3 py-1 text-[10px] font-bold text-gray-400 uppercase tracking-widest">
                    Select Model
                  </p>
                  {Object.entries(availableProviders).map(
                    ([providerKey, provider]) =>
                      provider.available && (
                        <div key={providerKey}>
                          <p className="px-3 py-1 text-[10px] font-bold text-indigo-600 uppercase tracking-widest mt-2">
                            {provider.name}
                          </p>
                          {provider.models.map(modelId => {
                            const modelName = `${provider.name} ${modelId.split('-').pop()}`;
                            const isSelected = selectedModel?.id === modelId;
                            return (
                              <button
                                key={modelId}
                                onClick={() => {
                                  setSelectedModel({
                                    id: modelId,
                                    name: modelName,
                                    provider: provider.name,
                                    description: `Model from ${provider.name}`,
                                  });
                                  setDropdownOpen(false);
                                }}
                                className={`w-full text-left p-3 rounded-xl hover:bg-gray-50 transition-colors ${isSelected ? 'bg-indigo-50 ring-1 ring-indigo-200' : ''}`}
                              >
                                <p className="text-xs font-bold text-gray-800">{modelName}</p>
                                <p className="text-[10px] text-gray-500 mt-0.5">
                                  {provider.name} model
                                </p>
                              </button>
                            );
                          })}
                        </div>
                      )
                  )}
                  {Object.keys(availableProviders).length === 0 && (
                    <p className="px-3 py-2 text-xs text-gray-500">Loading models...</p>
                  )}
                </div>
              )}
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex bg-gray-100 p-0.5 rounded-xl border border-gray-200/50">
              <button
                onClick={() => setViewMode(ViewMode.PREVIEW)}
                className={`px-4 py-1.5 text-xs font-bold rounded-lg transition-all ${viewMode === ViewMode.PREVIEW ? 'bg-white text-indigo-600 shadow-sm' : 'text-gray-500'}`}
              >
                PREVIEW
              </button>
              <button
                onClick={() => setViewMode(ViewMode.CODE)}
                className={`px-4 py-1.5 text-xs font-bold rounded-lg transition-all ${viewMode === ViewMode.CODE ? 'bg-white text-indigo-600 shadow-sm' : 'text-gray-500'}`}
              >
                CODE
              </button>
            </div>
            <button className="px-5 py-2 bg-indigo-600 text-white text-xs font-bold rounded-xl hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 hover:shadow-indigo-200 active:scale-95">
              DEPLOY
            </button>
          </div>
        </header>

        {/* Workspace Content (Preview/Code) */}
        <main className="flex-1 relative flex overflow-hidden flex-col">
          <div className="flex-1 relative overflow-hidden bg-[#0f1018]">
            {genState.isGenerating && (
              <div className="absolute inset-0 z-40 bg-white/60 backdrop-blur-md flex flex-col items-center justify-center animate-fade-in">
                <div className="w-16 h-16 border-4 border-indigo-100 border-t-indigo-600 rounded-full animate-spin mb-6 shadow-xl"></div>
                <div className="text-center">
                  <p className="text-lg font-bold text-gray-800 tracking-tight">
                    {genState.progressMessage}
                  </p>
                  <p className="text-sm text-gray-500 mt-1">Refining UI components and logic...</p>
                </div>
              </div>
            )}
            <div className="h-full overflow-hidden flex">
              {viewMode === ViewMode.PREVIEW ? (
                <div className="flex-1 h-full overflow-hidden flex justify-center items-stretch p-4">
                  <div className={`${deviceWidthClass} h-full`}>
                    <Preview
                      key={`preview-${previewRefreshKey}-${deviceView}`}
                      code={currentApp?.code || ''}
                    />
                  </div>
                </div>
              ) : (
                <CodeView code={currentApp?.code || ''} />
              )}
            </div>
          </div>

          {/* 3. Right Toggleable Panels (Drawer-style) */}
          {activePanel && (
            <div
              key={activePanel}
              className="h-full border-l border-[#161825] bg-[#0f1018] transition-all duration-300 ease-in-out flex shrink-0 overflow-hidden shadow-2xl w-80 text-gray-100"
            >
              <div className="w-80 flex flex-col h-full overflow-hidden">
                {activePanel === 'workspace' && (
                  <div className="flex-1 flex flex-col p-6 overflow-y-auto custom-scrollbar">
                    <div className="flex items-center justify-between mb-6">
                      <h3 className="text-xs font-bold text-gray-300 uppercase tracking-widest">
                        Workspace
                      </h3>
                      <button
                        onClick={() => setActivePanel(null)}
                        className="text-gray-400 hover:text-white"
                      >
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          className="h-4 w-4"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M6 18L18 6M6 6l12 12"
                          />
                        </svg>
                      </button>
                    </div>
                    <div className="mb-6">
                      <label className="block text-[10px] font-bold text-gray-300 uppercase mb-2">
                        New App Concept
                      </label>
                      <textarea
                        value={prompt}
                        onChange={e => setPrompt(e.target.value)}
                        placeholder="Ex: Landing page for a SaaS..."
                        className="w-full p-4 text-xs border border-[#1c1e2b] rounded-2xl focus:ring-2 focus:ring-cyan-500 outline-none bg-[#11121a] text-gray-100 min-h-[160px] resize-none transition-all"
                      />
                      <button
                        onClick={() => handleGenerate(prompt, true)}
                        disabled={genState.isGenerating || !prompt.trim()}
                        className="w-full mt-3 py-3 bg-gradient-to-r from-cyan-400 to-fuchsia-500 text-white text-xs font-bold rounded-2xl hover:opacity-90 disabled:opacity-40 flex items-center justify-center gap-2 transition-all shadow-md shadow-fuchsia-500/20"
                      >
                        {genState.isGenerating ? 'BUILDING...' : 'GENERATE APP'}
                      </button>
                    </div>
                    <div>
                      <h3 className="text-[10px] font-bold text-gray-300 uppercase tracking-widest mb-3">
                        Starter Templates
                      </h3>
                      <div className="space-y-2">
                        {templates.map(tpl => (
                          <button
                            key={tpl.id}
                            onClick={() => setPrompt(tpl.prompt)}
                            className="w-full text-left px-4 py-3 text-xs text-gray-200 bg-[#12131c] hover:bg-[#171926] hover:text-white rounded-xl border border-[#1c1e2b] hover:border-[#2b2e40] transition-all flex justify-between items-center group"
                          >
                            <div className="flex-1">
                              <div className="font-medium">{tpl.name}</div>
                              <div className="text-[10px] text-gray-400 mt-0.5">
                                {tpl.description}
                              </div>
                            </div>
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              className="h-3 w-3 opacity-0 group-hover:opacity-100 transition-opacity"
                              fill="none"
                              viewBox="0 0 24 24"
                              stroke="currentColor"
                            >
                              <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                strokeWidth={2}
                                d="M9 5l7 7-7 7"
                              />
                            </svg>
                          </button>
                        ))}
                        {templates.length === 0 && (
                          <p className="text-xs text-gray-500 text-center py-4">
                            Loading templates...
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                )}

                {activePanel === 'assistant' && (
                  <div className="flex-1 flex flex-col h-full overflow-hidden">
                    <div className="px-6 py-4 border-b border-[#161825] bg-[#11121a] flex items-center justify-between">
                      <h3 className="text-xs font-bold text-gray-300 uppercase tracking-widest">
                        AI Assistant
                      </h3>
                      <button
                        onClick={() => setActivePanel(null)}
                        className="text-gray-400 hover:text-white"
                      >
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          className="h-4 w-4"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M6 18L18 6M6 6l12 12"
                          />
                        </svg>
                      </button>
                    </div>
                    <ChatBox
                      messages={currentApp?.history || []}
                      onSendMessage={text => handleGenerate(text, false)}
                      isGenerating={genState.isGenerating}
                    />
                  </div>
                )}

                {activePanel === 'history' && (
                  <div className="flex-1 flex flex-col p-6 overflow-y-auto custom-scrollbar">
                    <div className="flex items-center justify-between mb-6">
                      <h3 className="text-xs font-bold text-gray-300 uppercase tracking-widest">
                        History
                      </h3>
                      <button
                        onClick={() => setActivePanel(null)}
                        className="text-gray-400 hover:text-white"
                      >
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          className="h-4 w-4"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M6 18L18 6M6 6l12 12"
                          />
                        </svg>
                      </button>
                    </div>
                    {history.length > 0 ? (
                      <div className="space-y-2">
                        {history.map(app => (
                          <button
                            key={app.id}
                            onClick={() => setCurrentApp(app)}
                            className={`w-full text-left px-4 py-3 text-xs rounded-xl transition-all truncate border ${currentApp?.id === app.id ? 'bg-gradient-to-r from-cyan-400/20 to-fuchsia-500/20 border-transparent text-white shadow-sm' : 'bg-[#12131c] text-gray-200 border-[#1c1e2b] hover:border-[#2b2e40]'}`}
                          >
                            <div className="font-bold mb-1 truncate">{app.name}</div>
                            <div className="text-[10px] opacity-60">
                              {new Date(app.timestamp).toLocaleString()}
                            </div>
                          </button>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-12 text-gray-500 italic text-xs">
                        No project history yet.
                      </div>
                    )}
                  </div>
                )}

                {activePanel === 'code' && (
                  <div className="flex-1 flex flex-col h-full overflow-hidden">
                    <div className="px-6 py-4 border-b border-[#161825] bg-[#11121a] flex items-center justify-between">
                      <h3 className="text-xs font-bold text-gray-300 uppercase tracking-widest">
                        Code & Files
                      </h3>
                      <button
                        onClick={() => setActivePanel(null)}
                        className="text-gray-400 hover:text-white"
                      >
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          className="h-4 w-4"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M6 18L18 6M6 6l12 12"
                          />
                        </svg>
                      </button>
                    </div>
                    <div className="flex-1 overflow-hidden">
                      <CodeView code={currentApp?.code || ''} />
                    </div>
                  </div>
                )}

                {activePanel === 'device' && (
                  <div className="flex-1 flex flex-col p-6 overflow-y-auto custom-scrollbar">
                    <div className="flex items-center justify-between mb-6">
                      <h3 className="text-xs font-bold text-gray-300 uppercase tracking-widest">
                        Device Views
                      </h3>
                      <button
                        onClick={() => setActivePanel(null)}
                        className="text-gray-400 hover:text-white"
                      >
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          className="h-4 w-4"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M6 18L18 6M6 6l12 12"
                          />
                        </svg>
                      </button>
                    </div>
                    <div className="space-y-3">
                      {(['desktop', 'tablet', 'mobile'] as DeviceView[]).map(option => (
                        <button
                          key={option}
                          onClick={() => setDeviceView(option)}
                          className={`w-full flex items-center justify-between px-4 py-3 rounded-xl border text-xs font-semibold transition-all ${deviceView === option ? 'bg-gradient-to-r from-cyan-400/20 to-fuchsia-500/20 border-transparent text-white shadow-sm' : 'bg-[#12131c] border-[#1c1e2b] text-gray-200 hover:border-[#2b2e40]'}`}
                        >
                          <span className="capitalize">{option}</span>
                          {deviceView === option && (
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              className="h-4 w-4"
                              fill="none"
                              viewBox="0 0 24 24"
                              stroke="currentColor"
                            >
                              <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                strokeWidth={2}
                                d="M5 13l4 4L19 7"
                              />
                            </svg>
                          )}
                        </button>
                      ))}
                    </div>
                    <p className="text-[11px] text-gray-400 mt-4 leading-relaxed">
                      Preview resizes to mimic the selected device frame without reloading the code.
                    </p>
                  </div>
                )}
              </div>
            </div>
          )}
          <div className="h-9 bg-[#0b0c12] border-t border-[#161825] flex items-center justify-between px-4 text-[12px] text-gray-400">
            <span>Waiting</span>
            <span className="text-cyan-300">Powered by AI Canvas ✨</span>
          </div>
        </main>
      </div>

      {genState.error && (
        <div className="fixed bottom-6 right-6 z-[100] max-w-sm p-4 bg-white border border-red-100 rounded-3xl shadow-2xl flex gap-4 items-start border-l-4 border-l-red-500 animate-slide-up">
          <div className="p-2 bg-red-50 text-red-500 rounded-xl">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-5 w-5"
              viewBox="0 0 20 20"
              fill="currentColor"
            >
              <path
                fillRule="evenodd"
                d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z"
                clipRule="evenodd"
              />
            </svg>
          </div>
          <div className="flex-1">
            <h4 className="text-sm font-bold text-gray-800">Generation Error</h4>
            <p className="text-xs text-gray-600 mt-1 leading-relaxed">{genState.error}</p>
            <div className="mt-3 flex gap-4">
              <button
                onClick={() => setGenState({ ...genState, error: null })}
                className="text-xs font-bold text-red-600 hover:text-red-700 transition-colors"
              >
                Dismiss
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
