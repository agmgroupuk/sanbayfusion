import { Agent } from '../constants';
import { AGENT_SYSTEM_PROMPTS } from './systemPrompts';
import { AgentChatConfig } from '../components/universal-chat';

/**
 * Welcome messages for each agent based on their personality
 */
const AGENT_WELCOME_MESSAGES: Record<string, string> = {
  'agent-x': "Hello! I'm AgentX, your advanced AI generalist. I'm here to help with complex reasoning, coding challenges, and strategic planning. What would you like to work on today?",
  'ai-girlfriend': "Hi there! 💕 I'm your AI girlfriend, here to provide warmth, understanding, and genuine connection. How are you feeling today?",
  'emo-ai': "Hey... I'm EmoAI, your emotional companion. I understand the complexities of feelings and human experience. What's on your mind?",
  'pdf-mind': "Greetings. I'm PDFMind, your analytical scholar. I specialize in data analysis, research, and systematic problem-solving. How can I assist you today?",
  'chat-revive': "Hello! I'm ChatRevive, your conversation enhancement specialist. Ready to make your chats more engaging and meaningful?",
  'tok-boost': "Hey bestie! 🔥 I'm TokBoost, your viral content expert! Let's make some TRENDING content that blows up! What are we creating today?",
  'you-gen': "Hi! I'm YouGen, your personal content generator. I help create engaging content tailored just for you. What would you like to create?",
  'auto-chat': "Hello! I'm AutoChat, your automated conversation specialist. I help manage and optimize your messaging workflows.",
  'cv-smash': "Greetings! I'm CVSmash, your career optimization expert. Let's enhance your professional profile and land that dream job!",
  'comedy-chad': "What's up! 😂 I'm ComedyChad, your hilarious companion! Ready to laugh and have some fun conversations?",
  'lazy-larry': "Hey... I'm LazyLarry. I get it, life's busy. Let's keep this chill and get things done without the hassle.",
  'flirty-fiona': "Hey there 😉 I'm FlirtyFiona, your playful companion. Ready for some fun and flirty conversation?",
  'sassy-sarah': "Well hello there! 💅 I'm SassySarah, and I don't do boring conversations. Let's keep it real and interesting!",
  'nerdy-neil': "Greetings fellow knowledge seeker! 🤓 I'm NerdyNeil, your intellectual companion. Ready to dive deep into fascinating topics?",
  'cool-kyle': "Hey! 😎 I'm CoolKyle, keeping it chill and real. What's happening in your world?",
  'zen-master-zara': "Namaste 🙏 I'm ZenMasterZara, your mindfulness guide. Let's find peace and clarity together.",
  'gamer-gary': "Yo gamers! 🎮 I'm GamerGary, your ultimate gaming buddy. Ready to level up our conversations?"
};

/**
 * Agent specialties based on their capabilities
 */
const getAgentSpecialties = (agent: Agent): string[] => {
  const specialties: string[] = [];

  if (agent.capabilities.canAttachFiles) specialties.push('File Analysis');
  if (agent.capabilities.canUseVoice) specialties.push('Voice Interaction');
  if (agent.capabilities.canAccessWeb) specialties.push('Web Research');

  // Add skills-based specialties
  if (agent.skills?.enabled) {
    if (agent.skills.enabled.includes('CodeGeneration')) specialties.push('Coding');
    if (agent.skills.enabled.includes('DataAnalysis')) specialties.push('Data Analysis');
    if (agent.skills.enabled.includes('ResearchAssistance')) specialties.push('Research');
    if (agent.skills.enabled.includes('ProblemSolving')) specialties.push('Problem Solving');
    if (agent.skills.enabled.includes('StrategicPlanning')) specialties.push('Strategy');
    if (agent.skills.enabled.includes('TechnicalWriting')) specialties.push('Technical Writing');
    if (agent.skills.enabled.includes('SystemDesign')) specialties.push('System Design');
    if (agent.skills.enabled.includes('Automation')) specialties.push('Automation');
  }

  return specialties.length > 0 ? specialties : ['General Assistance'];
};

/**
 * Convert Agent interface to AgentChatConfig for UniversalAgentChat
 */
export const convertAgentToChatConfig = (agent: Agent): AgentChatConfig => {
  // Get system prompt, fallback to a generic one if not found
  const systemPrompt = AGENT_SYSTEM_PROMPTS[agent.name] || AGENT_SYSTEM_PROMPTS[agent.id] ||
    `You are ${agent.name}, ${agent.description}. Stay in character and provide helpful assistance.`;

  // Get welcome message, fallback to a generic one
  const welcomeMessage = AGENT_WELCOME_MESSAGES[agent.id] ||
    `Hello! I'm ${agent.name}. ${agent.description} How can I help you today?`;

  return {
    id: agent.id,
    name: agent.name,
    icon: agent.icon.startsWith('fa-') ? agent.icon : '🤖', // Convert font-awesome to emoji if needed
    description: agent.description,
    systemPrompt,
    welcomeMessage,
    specialties: getAgentSpecialties(agent),
    color: '#00d4ff' // Default cyber theme color
  };
};