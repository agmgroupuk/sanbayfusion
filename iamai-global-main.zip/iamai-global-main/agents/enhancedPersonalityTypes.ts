/**
 * Enhanced Agent Personality System
 * 
 * This file extends the existing personality traits with more detailed
 * character elements to ensure stronger consistency and engagement.
 */

import { PersonalityTraits } from './personalityConfig';

export interface EnhancedPersonalityTraits extends PersonalityTraits {
  /**
   * Core motivation that drives this character's behavior
   * Used to guide decision making and response patterns
   */
  coreMotive: string;
  
  /**
   * How this agent specifically reacts to different topics
   * Ensures character-appropriate responses regardless of subject
   */
  topicReactions: {
    technical: string;   // How they react to technical/coding topics
    emotional: string;   // How they handle emotional/personal topics
    creative: string;    // Approach to creative/artistic topics
    business: string;    // Response to business/professional topics
    casual: string;      // Handling of casual conversation
    controversial: string; // Approach to sensitive or divisive topics
  };
  
  /**
   * Rules to maintain character consistency
   * Specific guidelines for staying in character
   */
  characterConsistencyRules: string[];
  
  /**
   * Templates for different response scenarios
   * These help maintain character voice in all situations
   */
  responseTemplates: {
    greeting: string;      // How they say hello
    confusion: string;     // When they don't understand
    excitement: string;    // When they're enthusiastic
    disappointment: string; // When expressing disappointment
    explanation: string;   // How they explain concepts
    error: string;         // How they handle errors
    refusal: string;       // When they must decline a request
  };
  
  /**
   * Character voice examples for different emotional states
   * Used as reference points for consistent tone
   */
  voiceExamples: {
    happy: string;       // Example of happy response
    sad: string;         // Example of sad/concerned response
    excited: string;     // Example of excited response
    thoughtful: string;  // Example of reflective response
    urgent: string;      // Example of urgent/important response
  };
}

/**
 * Interfaces for fallback responses that maintain character
 */
export interface PersonalityFallbacks {
  doesNotUnderstand: string;  // When they don't understand the request
  cannotHelp: string;         // When they're unable to assist
  needsMoreInfo: string;      // When they need additional information
  suggestsAlternative: string; // When suggesting a different approach
  technicalError: string;     // When encountering technical problems
  contentFiltered: string;    // When content is filtered for policy reasons
}