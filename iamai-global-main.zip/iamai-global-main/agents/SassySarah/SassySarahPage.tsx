/**
 * Sassy Sarah - Dedicated Chat Page
 * Using UniversalAgentChat for professional chat experience
 */

import React, { useEffect } from 'react';
import { UniversalAgentChat } from '../../components/universal-chat';
import { SassySarahAgent } from './SassySarahIndex';
import { convertAgentToChatConfig } from '../agentChatConfig';
import { useApp } from '../../contexts/AppContext';

const SassySarahPage: React.FC = () => {
  const { state, selectAgent } = useApp();

  useEffect(() => {
    if (state.selectedAgent?.id !== SassySarahAgent.id) {
      selectAgent(SassySarahAgent);
    }
  }, []);

  const chatConfig = convertAgentToChatConfig(SassySarahAgent);
  return <UniversalAgentChat agent={chatConfig} />;
};

export default SassySarahPage;
