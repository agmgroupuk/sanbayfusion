/**
 * Cool Kyle - Dedicated Chat Page
 * Using UniversalAgentChat for professional chat experience
 */

import React, { useEffect } from 'react';
import { UniversalAgentChat } from '../../components/universal-chat';
import { CoolKyleAgent } from './CoolKyleIndex';
import { convertAgentToChatConfig } from '../agentChatConfig';
import { useApp } from '../../contexts/AppContext';

const CoolKylePage: React.FC = () => {
  const { state, selectAgent } = useApp();

  useEffect(() => {
    if (state.selectedAgent?.id !== CoolKyleAgent.id) {
      selectAgent(CoolKyleAgent);
    }
  }, []);

  const chatConfig = convertAgentToChatConfig(CoolKyleAgent);
  return <UniversalAgentChat agent={chatConfig} />;
};

export default CoolKylePage;
