/**
 * TokBoost - Dedicated Chat Page
 * Standalone page for TokBoost chat interface
 * Using UniversalAgentChat for professional chat experience
 */

import React, { useEffect } from 'react';
import { UniversalAgentChat } from '../../components/universal-chat';
import { TokBoostAgent } from './TokBoostIndex';
import { convertAgentToChatConfig } from '../agentChatConfig';
import { useApp } from '../../contexts/AppContext';

const TokBoostPage: React.FC = () => {
  const { state, selectAgent } = useApp();

  // Auto-select this agent when the page loads
  useEffect(() => {
    if (state.selectedAgent?.id !== TokBoostAgent.id) {
      selectAgent(TokBoostAgent);
    }
  }, []);

  // ✨ Using UniversalAgentChat for professional interface
  const chatConfig = convertAgentToChatConfig(TokBoostAgent);
  return <UniversalAgentChat agent={chatConfig} />;
};

export default TokBoostPage;
