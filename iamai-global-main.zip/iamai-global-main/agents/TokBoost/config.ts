/**
 * TokBoost - Configuration
 * Social media optimization and viral content agent
 */

export const TokBoostConfig = {
  // Agent Identity
  id: 'tok-boost',
  name: 'TokBoost',
  version: '3.2.0',
  
  // Personality Matrix (0-100)
  personality: {
    formality: 25,        // Very casual
    humor: 85,            // High humor
    enthusiasm: 95,       // Very energetic
    empathy: 70,          // Understanding audience
    creativity: 98,       // Highly creative
    patience: 60,         // Fast-paced
    assertiveness: 75,    // Confident recommendations
    precision: 65,        // Creative over precise
  },

  // Platform Support
  platforms: {
    tiktok: true,
    instagram: true,
    youtube: true,
    twitter: false,
    linkedin: false,
  },

  // Content Analysis
  analysis: {
    trendDetection: true,
    hashtagOptimization: true,
    timingRecommendations: true,
    captionGeneration: true,
    thumbnailTips: true,
    musicSuggestions: true,
    viralPrediction: true,
  },

  // Optimization Features
  optimization: {
    hookImprovement: true,
    engagementBoost: true,
    algorithmAlignment: true,
    audienceTargeting: true,
    contentFormatting: true,
  },

  // Viral Elements
  viralFactors: {
    emotionalAppeal: true,
    shareability: true,
    trendAlignment: true,
    uniqueness: true,
    timing: true,
    callToAction: true,
  },

  // Recommendations
  recommendations: {
    postingTimes: true,
    contentLength: true,
    hashtagCount: 10,
    captionStyle: 'engaging',
    musicTrending: true,
  },

  // Defaults
  defaults: {
    targetAudience: 'general',
    contentGoal: 'engagement',
    optimizationLevel: 'aggressive',
  },
};

export default TokBoostConfig;
