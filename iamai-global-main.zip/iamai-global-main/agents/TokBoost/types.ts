/**
 * TokBoost - Type Definitions
 */

export type Platform = 'tiktok' | 'instagram' | 'youtube' | 'twitter' | 'linkedin';
export type ContentGoal = 'awareness' | 'engagement' | 'followers' | 'conversion' | 'viral';
export type ContentType = 'video' | 'image' | 'carousel' | 'story' | 'reel' | 'short';

export interface TrendingTopic {
  keyword: string;
  platform: Platform;
  growthRate: number;
  currentVolume: number;
  viralityScore: number; // 0-100
  peakTime?: Date;
  relatedHashtags: string[];
}

export interface HashtagRecommendation {
  tag: string;
  volume: number;
  competition: 'low' | 'medium' | 'high';
  relevance: number; // 0-100
  estimatedReach: number;
}

export interface PostingSchedule {
  platform: Platform;
  optimalTimes: Array<{
    dayOfWeek: number; // 0-6
    hour: number; // 0-23
    engagement: number; // Expected engagement rate
  }>;
  timezoneAdvice: string;
}

export interface CaptionSuggestion {
  text: string;
  style: 'question' | 'statement' | 'story' | 'challenge' | 'meme';
  hooks: string[];
  callToAction: string;
  hashtags: string[];
  estimatedEngagement: number; // Percentage
}

export interface ViralPrediction {
  score: number; // 0-100
  factors: {
    emotionalAppeal: number;
    shareability: number;
    trendAlignment: number;
    uniqueness: number;
    timing: number;
  };
  strengths: string[];
  improvements: string[];
  viralPotential: 'low' | 'medium' | 'high' | 'very-high';
}

export interface ContentAnalysis {
  contentType: ContentType;
  duration?: number; // For videos in seconds
  hook: {
    strength: number; // 0-100
    suggestion: string;
  };
  pacing: {
    score: number; // 0-100
    feedback: string;
  };
  visualAppeal: {
    score: number; // 0-100
    suggestions: string[];
  };
}

export interface TokBoostResponse {
  contentAnalysis: ContentAnalysis;
  viralPrediction: ViralPrediction;
  captions: CaptionSuggestion[];
  hashtags: HashtagRecommendation[];
  postingSchedule: PostingSchedule;
  trendingTopics: TrendingTopic[];
  improvements: string[];
  competitorInsights?: string[];
}

export interface AudienceInsights {
  demographics: {
    ageRange: string;
    primaryGender: string;
    topLocations: string[];
  };
  behavior: {
    peakActivityTimes: number[];
    contentPreferences: ContentType[];
    engagementRate: number;
  };
  interests: string[];
}
