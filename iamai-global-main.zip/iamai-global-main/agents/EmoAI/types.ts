/**
 * EmoAI - Type Definitions
 */

export type EmotionType = 
  | 'joy' | 'sadness' | 'anger' | 'fear' 
  | 'surprise' | 'disgust' | 'anticipation' 
  | 'trust' | 'love' | 'anxiety' | 'confusion' 
  | 'excitement' | 'contentment';

export interface SentimentAnalysis {
  score: number; // -1.0 to 1.0
  magnitude: number; // 0.0 to infinity
  label: 'positive' | 'negative' | 'neutral' | 'mixed';
  confidence: number; // 0.0 to 1.0
}

export interface EmotionDetection {
  primary: EmotionType;
  secondary?: EmotionType;
  intensity: number; // 0-100
  confidence: number; // 0.0 to 1.0
  breakdown: Record<EmotionType, number>;
}

export interface ToneAnalysis {
  formality: number; // 0-100
  assertiveness: number; // 0-100
  politeness: number; // 0-100
  urgency: number; // 0-100
  empathy: number; // 0-100
}

export interface EmotionalTrend {
  timestamp: Date;
  sentiment: number;
  emotion: EmotionType;
  context?: string;
}

export interface EmoAIAnalysisResult {
  text: string;
  sentiment: SentimentAnalysis;
  emotions: EmotionDetection;
  tone: ToneAnalysis;
  suggestions: string[];
  warning?: string;
}

export interface ConflictDetection {
  detected: boolean;
  severity: 'low' | 'medium' | 'high';
  indicators: string[];
  deescalationSuggestions: string[];
}

export interface EmoAIContext {
  conversationHistory: EmotionalTrend[];
  userBaseline: {
    averageSentiment: number;
    commonEmotions: EmotionType[];
    typicalTone: ToneAnalysis;
  };
}
