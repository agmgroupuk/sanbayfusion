/**
 * EmoAI - Dedicated Chat Page
 * Standalone page for EmoAI chat interface
 * Using UniversalAgentChat for professional chat experience
 */

import React, { useEffect } from 'react';
import { UniversalAgentChat } from '../../components/universal-chat';
import { EmoAIAgent } from './EmoAIIndex';
import { convertAgentToChatConfig } from '../agentChatConfig';
import { useApp } from '../../contexts/AppContext';

const EmoAIPage: React.FC = () => {
  const { state, selectAgent } = useApp();

  useEffect(() => {
    if (state.selectedAgent?.id !== EmoAIAgent.id) {
      selectAgent(EmoAIAgent);
    }
  }, []);

  const chatConfig = convertAgentToChatConfig(EmoAIAgent);
  return <UniversalAgentChat agent={chatConfig} />;
};

export default EmoAIPage;
