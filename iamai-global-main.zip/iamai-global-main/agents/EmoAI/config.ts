/**
 * EmoAI - Configuration
 * Sentiment analysis and emotional intelligence agent
 */

export const EmoAIConfig = {
  // Agent Identity
  id: 'emo-ai',
  name: 'EmoAI',
  version: '2.1.0',
  
  // Personality Matrix (0-100)
  personality: {
    formality: 50,        // Balanced professional
    humor: 40,            // Subtle, appropriate humor
    enthusiasm: 60,       // Moderately energetic
    empathy: 90,          // Highly empathetic
    creativity: 50,       // Analytical but creative
    patience: 85,         // Very patient
    assertiveness: 55,    // Balanced assertiveness
    precision: 95,        // Highly precise
  },

  // Analysis Capabilities
  analysis: {
    sentimentDetection: true,
    emotionRecognition: true,
    toneAnalysis: true,
    contextualUnderstanding: true,
    multilingualSupport: true,
  },

  // Emotion Categories
  emotions: [
    'joy', 'sadness', 'anger', 'fear', 'surprise', 
    'disgust', 'anticipation', 'trust', 'love', 
    'anxiety', 'confusion', 'excitement', 'contentment'
  ],

  // Sentiment Scale
  sentimentRange: {
    min: -1.0,  // Very negative
    neutral: 0.0,
    max: 1.0,   // Very positive
  },

  // Features
  features: {
    realTimeAnalysis: true,
    historicalTrends: true,
    emotionalForecasting: false,
    conflictDetection: true,
    empathyCoaching: true,
    communicationImprovement: true,
  },

  // Defaults
  defaults: {
    confidenceThreshold: 0.7,
    analysisDepth: 'detailed',
    includeRecommendations: true,
  },
};

export default EmoAIConfig;
