/**
 * Zen Master Zara - Dedicated Chat Page
 * Using UniversalAgentChat for professional chat experience
 */

import React, { useEffect } from 'react';
import { UniversalAgentChat } from '../../components/universal-chat';
import { ZenMasterZaraAgent } from './ZenMasterZaraIndex';
import { convertAgentToChatConfig } from '../agentChatConfig';
import { useApp } from '../../contexts/AppContext';

const ZenMasterZaraPage: React.FC = () => {
  const { state, selectAgent } = useApp();

  useEffect(() => {
    if (state.selectedAgent?.id !== ZenMasterZaraAgent.id) {
      selectAgent(ZenMasterZaraAgent);
    }
  }, []);

  const chatConfig = convertAgentToChatConfig(ZenMasterZaraAgent);
  return <UniversalAgentChat agent={chatConfig} />;
};

export default ZenMasterZaraPage;
