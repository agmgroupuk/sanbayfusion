/**
 * ChatRevive - Dedicated Chat Page
 * Standalone page for ChatRevive chat interface
 * Using UniversalAgentChat for professional chat experience
 */

import React, { useEffect } from 'react';
import { UniversalAgentChat } from '../../components/universal-chat';
import { ChatReviveAgent } from './ChatReviveIndex';
import { convertAgentToChatConfig } from '../agentChatConfig';
import { useApp } from '../../contexts/AppContext';

const ChatRevivePage: React.FC = () => {
  const { state, selectAgent } = useApp();

  useEffect(() => {
    if (state.selectedAgent?.id !== ChatReviveAgent.id) {
      selectAgent(ChatReviveAgent);
    }
  }, []);

  const chatConfig = convertAgentToChatConfig(ChatReviveAgent);
  return <UniversalAgentChat agent={chatConfig} />;
};

export default ChatRevivePage;
