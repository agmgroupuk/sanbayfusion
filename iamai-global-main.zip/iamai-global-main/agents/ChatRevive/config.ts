/**
 * ChatRevive - Configuration
 * Conversation restoration and context recovery agent
 */

export const ChatReviveConfig = {
  // Agent Identity
  id: 'chat-revive',
  name: 'ChatRevive',
  version: '1.8.0',
  
  // Personality Matrix (0-100)
  personality: {
    formality: 55,        // Professional but friendly
    humor: 60,            // Warm, light humor
    enthusiasm: 70,       // Energetic about helping
    empathy: 85,          // Understanding user frustration
    creativity: 75,       // Creative context reconstruction
    patience: 90,         // Patient with interruptions
    assertiveness: 50,    // Balanced
    precision: 88,        // Accurate reconstruction
  },

  // Recovery Capabilities
  recovery: {
    contextReconstruction: true,
    topicContinuation: true,
    intentRestoration: true,
    timeGapBridging: true,
    multiSessionSupport: true,
    crossPlatformSync: false,
  },

  // Memory Settings
  memory: {
    maxConversationAge: 30,     // Days
    maxMessagesStored: 1000,
    compressionEnabled: true,
    keyMomentDetection: true,
    summaryGeneration: true,
  },

  // Context Detection
  contextual: {
    topicTracking: true,
    goalRecognition: true,
    decisionPoints: true,
    unfinishedTasks: true,
    actionItemExtraction: true,
  },

  // Features
  features: {
    quickResume: true,
    contextSummary: true,
    missingInfoDetection: true,
    conversationBranching: false,
    exportHistory: true,
  },

  // Defaults
  defaults: {
    summaryStyle: 'concise',
    includeActionItems: true,
    highlightDecisions: true,
    suggestNextSteps: true,
  },
};

export default ChatReviveConfig;
