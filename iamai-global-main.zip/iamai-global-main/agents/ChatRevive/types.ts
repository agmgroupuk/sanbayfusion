/**
 * ChatRevive - Type Definitions
 */

export interface ConversationSnapshot {
  id: string;
  startTime: Date;
  lastUpdate: Date;
  messageCount: number;
  participants: string[];
  platform?: string;
}

export interface ConversationContext {
  mainTopic: string;
  subTopics: string[];
  userGoal: string;
  currentStage: 'exploration' | 'discussion' | 'decision' | 'action' | 'completed';
  keyPoints: string[];
  decisions: string[];
  actionItems: ActionItem[];
}

export interface ActionItem {
  description: string;
  status: 'pending' | 'in-progress' | 'completed' | 'blocked';
  priority: 'low' | 'medium' | 'high';
  assignedTo?: string;
  dueDate?: Date;
}

export interface KeyMoment {
  timestamp: Date;
  type: 'decision' | 'insight' | 'question' | 'agreement' | 'issue';
  summary: string;
  messageIds: string[];
}

export interface TimeGap {
  duration: number; // In minutes
  lastTopic: string;
  suggestedRecap: string;
  confidenceLevel: number; // 0-1
}

export interface RevivalSummary {
  conversationId: string;
  timeSinceLastMessage: number; // Minutes
  whereWeLeft: string;
  keyDecisions: string[];
  pendingActions: ActionItem[];
  suggestedContinuation: string[];
  questionsToAsk: string[];
}

export interface ConversationCompression {
  originalMessages: number;
  compressedSummary: string;
  preservedKeyMoments: KeyMoment[];
  compressionRatio: number;
  informationRetained: number; // Percentage
}

export interface ChatReviveResponse {
  summary: RevivalSummary;
  context: ConversationContext;
  timeGap?: TimeGap;
  restorationConfidence: number; // 0-1
  nextSteps: string[];
}
