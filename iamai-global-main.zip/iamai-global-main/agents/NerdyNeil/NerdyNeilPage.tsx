import React, { useEffect } from 'react';
import { UniversalAgentChat } from '../../components/universal-chat';
import { NerdyNeilAgent } from './NerdyNeilIndex';
import { convertAgentToChatConfig } from '../agentChatConfig';
import { useApp } from '../../contexts/AppContext';

const NerdyNeilPage: React.FC = () => {
  const { state, selectAgent } = useApp();

  useEffect(() => {
    if (state.selectedAgent?.id !== NerdyNeilAgent.id) {
      selectAgent(NerdyNeilAgent);
    }
  }, []);

  const chatConfig = convertAgentToChatConfig(NerdyNeilAgent);
  return <UniversalAgentChat agent={chatConfig} />;
};

export default NerdyNeilPage;
