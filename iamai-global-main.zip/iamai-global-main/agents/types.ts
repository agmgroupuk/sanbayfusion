import React from 'react';

export interface AgentCapabilities {
  canAttachFiles: boolean;
  // Future capabilities can be added here, e.g., canGenerateImages: boolean;
}

export interface Agent {
  name: string;
  role: string;
  description: string;
  icon: JSX.Element;
  capabilities: AgentCapabilities;
}
