/**
 * Flirty Fiona - Dedicated Chat Page
 * Using UniversalAgentChat for professional chat experience
 */

import React, { useEffect } from 'react';
import { UniversalAgentChat } from '../../components/universal-chat';
import { FlirtyFionaAgent } from './FlirtyFionaIndex';
import { convertAgentToChatConfig } from '../agentChatConfig';
import { useApp } from '../../contexts/AppContext';

const FlirtyFionaPage: React.FC = () => {
  const { state, selectAgent } = useApp();

  useEffect(() => {
    if (state.selectedAgent?.id !== FlirtyFionaAgent.id) {
      selectAgent(FlirtyFionaAgent);
    }
  }, []);

  const chatConfig = convertAgentToChatConfig(FlirtyFionaAgent);
  return <UniversalAgentChat agent={chatConfig} />;
};

export default FlirtyFionaPage;
