/**
 * Comedy Chad - Dedicated Chat Page
 * The funniest page on the internet! 🤡
 * Using UniversalAgentChat for professional chat experience
 */

import React, { useEffect } from 'react';
import { UniversalAgentChat } from '../../components/universal-chat';
import { ComedyChadAgent } from './ComedyChadIndex';
import { convertAgentToChatConfig } from '../agentChatConfig';
import { useApp } from '../../contexts/AppContext';

const ComedyChadPage: React.FC = () => {
  const { state, selectAgent } = useApp();

  useEffect(() => {
    if (state.selectedAgent?.id !== ComedyChadAgent.id) {
      selectAgent(ComedyChadAgent);
    }
  }, []);

  const chatConfig = convertAgentToChatConfig(ComedyChadAgent);
  return <UniversalAgentChat agent={chatConfig} />;
};

export default ComedyChadPage;
