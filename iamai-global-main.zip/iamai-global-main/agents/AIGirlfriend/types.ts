/**
 * AI Girlfriend Pro - Type Definitions
 */

export interface AIGirlfriendMemory {
  favoriteThings: string[];
  importantDates: Array<{
    date: string;
    event: string;
    significance: string;
  }>;
  preferences: {
    music: string[];
    activities: string[];
    topics: string[];
  };
  emotionalPatterns: Array<{
    trigger: string;
    response: string;
    timestamp: Date;
  }>;
}

export interface AIGirlfriendMood {
  current: 'happy' | 'excited' | 'calm' | 'thoughtful' | 'playful' | 'caring';
  intensity: number; // 0-100
  reason?: string;
}

export interface AIGirlfriendContext {
  relationshipStage: 'new' | 'developing' | 'established' | 'deep';
  trustLevel: number; // 0-100
  intimacyLevel: number; // 0-100
  lastInteraction: Date;
  conversationHistory: ConversationEntry[];
}

export interface ConversationEntry {
  timestamp: Date;
  topic: string;
  emotionalTone: string;
  userMood: string;
  agentResponse: string;
}

export interface AIGirlfriendResponse {
  message: string;
  emotion: string;
  suggestedActions?: string[];
  memoryUpdate?: Partial<AIGirlfriendMemory>;
}

export type AIGirlfriendPersonalityTrait = 
  | 'affectionate'
  | 'playful'
  | 'supportive'
  | 'understanding'
  | 'creative'
  | 'romantic';

export interface AIGirlfriendSettings {
  enableProactiveMessages: boolean;
  moodTrackingEnabled: boolean;
  memoryPersistence: boolean;
  voiceEnabled: boolean;
  responseStyle: 'brief' | 'balanced' | 'detailed';
}
