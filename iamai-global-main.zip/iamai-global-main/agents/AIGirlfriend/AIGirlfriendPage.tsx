/**
 * AI Girlfriend Pro - Dedicated Chat Page
 * Standalone page for AI Girlfriend chat interface
 * Using UniversalAgentChat for professional chat experience
 */

import React, { useEffect } from 'react';
import { UniversalAgentChat } from '../../components/universal-chat';
import { AIGirlfriendAgent } from './AIGirlfriendIndex';
import { convertAgentToChatConfig } from '../agentChatConfig';
import { useApp } from '../../contexts/AppContext';

const AIGirlfriendPage: React.FC = () => {
  const { state, selectAgent } = useApp();

  // Auto-select this agent when the page loads
  useEffect(() => {
    if (state.selectedAgent?.id !== AIGirlfriendAgent.id) {
      selectAgent(AIGirlfriendAgent);
    }
  }, []);

  const chatConfig = convertAgentToChatConfig(AIGirlfriendAgent);
  return <UniversalAgentChat agent={chatConfig} />;
};

export default AIGirlfriendPage;
