/**
 * AgentX - Dedicated Chat Page
 * Standalone page for AgentX chat interface
 * Now using UniversalAgentChat for professional chat experience
 */

import React, { useEffect } from 'react';
import { UniversalAgentChat } from '../../components/universal-chat';
import { AgentXAgent } from './AgentXIndex';
import { convertAgentToChatConfig } from '../agentChatConfig';
import { useApp } from '../../contexts/AppContext';

const AgentXPage: React.FC = () => {
  const { state, selectAgent } = useApp();

  // Auto-select this agent when the page loads
  useEffect(() => {
    if (state.selectedAgent?.id !== AgentXAgent.id) {
      selectAgent(AgentXAgent);
    }
  }, []);

  // ✨ Use UniversalAgentChat for professional interface
  const chatConfig = convertAgentToChatConfig(AgentXAgent);
  return <UniversalAgentChat agent={chatConfig} />;
};

export default AgentXPage;
