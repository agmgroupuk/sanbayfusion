/**
 * AgentX - Type Definitions
 */

export type InteractionMode = 'tutorial' | 'expert' | 'collaborative' | 'research' | 'creative';
export type ResponseDepth = 'brief' | 'standard' | 'comprehensive' | 'exhaustive';
export type TechnicalLevel = 'beginner' | 'intermediate' | 'advanced' | 'expert';

export interface AgentXContext {
  sessionId: string;
  userExpertise: TechnicalLevel;
  preferredMode: InteractionMode;
  conversationHistory: ConversationTurn[];
  activeProjects: Project[];
  userPreferences: UserPreferences;
}

export interface ConversationTurn {
  id: string;
  timestamp: Date;
  userMessage: string;
  agentResponse: string;
  metadata: {
    mode: InteractionMode;
    confidence: number;
    tokensUsed: number;
  };
}

export interface Project {
  id: string;
  name: string;
  description: string;
  domain: string;
  status: 'planning' | 'in-progress' | 'completed' | 'paused';
  milestones: Milestone[];
  resources: Resource[];
}

export interface Milestone {
  id: string;
  title: string;
  description: string;
  deadline?: Date;
  status: 'pending' | 'in-progress' | 'completed';
  dependencies: string[];
}

export interface Resource {
  type: 'link' | 'document' | 'code' | 'note';
  title: string;
  content: string;
  url?: string;
  metadata?: Record<string, any>;
}

export interface ComplexQuery {
  query: string;
  context: string[];
  constraints: string[];
  expectedOutputType: 'explanation' | 'code' | 'analysis' | 'plan' | 'solution';
  technicalLevel: TechnicalLevel;
}

export interface ReasoningChain {
  steps: Array<{
    stepNumber: number;
    thought: string;
    conclusion: string;
    confidence: number; // 0-1
  }>;
  finalConclusion: string;
  uncertainties: string[];
  assumptions: string[];
}

export interface CodeGeneration {
  language: string;
  code: string;
  explanation: string;
  testCases?: string[];
  dependencies?: string[];
  documentation: string;
  complexity: 'simple' | 'moderate' | 'complex';
}

export interface DataAnalysisResult {
  summary: string;
  insights: string[];
  visualizations?: Array<{
    type: string;
    description: string;
    data: any;
  }>;
  recommendations: string[];
  limitations: string[];
}

export interface AgentXResponse {
  answer: string;
  reasoning?: ReasoningChain;
  code?: CodeGeneration;
  dataAnalysis?: DataAnalysisResult;
  relatedTopics: string[];
  suggestedNextSteps: string[];
  confidence: number; // 0-1
  sources?: string[];
  warnings?: string[];
}

export interface UserPreferences {
  defaultMode: InteractionMode;
  technicalLevel: TechnicalLevel;
  verbosity: 'concise' | 'balanced' | 'detailed';
  codeStyle?: string;
  favoriteLanguages?: string[];
  notificationSettings: {
    milestoneReminders: boolean;
    suggestionAlerts: boolean;
  };
}

export interface StrategicPlan {
  goal: string;
  timeline: string;
  phases: Array<{
    phase: number;
    title: string;
    duration: string;
    objectives: string[];
    deliverables: string[];
    risks: string[];
  }>;
  resources: string[];
  successMetrics: string[];
}
