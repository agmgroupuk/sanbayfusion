/**
 * Lazy Larry - Dedicated Chat Page
 * Using UniversalAgentChat for professional chat experience
 */

import React, { useEffect } from 'react';
import { UniversalAgentChat } from '../../components/universal-chat';
import { LazyLarryAgent } from './LazyLarryIndex';
import { convertAgentToChatConfig } from '../agentChatConfig';
import { useApp } from '../../contexts/AppContext';

const LazyLarryPage: React.FC = () => {
  const { state, selectAgent } = useApp();

  useEffect(() => {
    if (state.selectedAgent?.id !== LazyLarryAgent.id) {
      selectAgent(LazyLarryAgent);
    }
  }, []);

  const chatConfig = convertAgentToChatConfig(LazyLarryAgent);
  return <UniversalAgentChat agent={chatConfig} />;
};

export default LazyLarryPage;
