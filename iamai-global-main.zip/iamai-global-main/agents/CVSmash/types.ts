/**
 * CVSmash - Type Definitions
 */

export type ExperienceLevel = 'entry-level' | 'junior' | 'mid-level' | 'senior' | 'lead' | 'executive';
export type IndustryType = 'technology' | 'finance' | 'healthcare' | 'education' | 'marketing' | 'sales' | 'operations' | 'engineering' | 'design' | 'consulting';

export interface ResumeScore {
  overall: number; // 0-100
  breakdown: {
    formatting: number;
    contentQuality: number;
    atsCompatibility: number;
    keywords: number;
    achievements: number;
    readability: number;
  };
  grade: 'A+' | 'A' | 'B+' | 'B' | 'C+' | 'C' | 'D' | 'F';
}

export interface ResumeAnalysis {
  score: ResumeScore;
  strengths: string[];
  weaknesses: string[];
  improvements: Improvement[];
  atsIssues: ATSIssue[];
  keywordAnalysis: KeywordAnalysis;
  formatIssues: FormatIssue[];
}

export interface Improvement {
  category: 'formatting' | 'content' | 'keywords' | 'achievements' | 'structure';
  priority: 'critical' | 'high' | 'medium' | 'low';
  issue: string;
  suggestion: string;
  example?: string;
  impact: number; // Points gained if fixed
}

export interface ATSIssue {
  type: 'incompatible-format' | 'missing-keywords' | 'poor-structure' | 'unreadable-elements';
  description: string;
  fix: string;
  severity: 'critical' | 'moderate' | 'minor';
}

export interface KeywordAnalysis {
  requiredKeywords: Array<{
    keyword: string;
    present: boolean;
    frequency: number;
    importance: number; // 0-10
  }>;
  suggestedKeywords: string[];
  overusedWords: string[];
  missingSkills: string[];
  matchScore: number; // 0-100
}

export interface FormatIssue {
  type: 'layout' | 'font' | 'spacing' | 'sections' | 'consistency';
  description: string;
  location: string;
  fix: string;
}

export interface Achievement {
  original: string;
  improved: string;
  metrics?: {
    quantified: boolean;
    action: string;
    result: string;
    impact?: string;
  };
  score: number; // 0-10
}

export interface CoverLetterReview {
  score: number; // 0-100
  strengths: string[];
  improvements: string[];
  structure: {
    opening: { score: number; feedback: string };
    body: { score: number; feedback: string };
    closing: { score: number; feedback: string };
  };
  tone: string;
  personalization: number; // 0-100
}

export interface InterviewPrepResponse {
  commonQuestions: Array<{
    question: string;
    category: 'behavioral' | 'technical' | 'situational' | 'cultural';
    sampleAnswer: string;
    tips: string[];
  }>;
  starExamples: Array<{
    situation: string;
    task: string;
    action: string;
    result: string;
  }>;
  questionsPrepared: string[];
  redFlags: string[];
}

export interface SalaryNegotiation {
  marketRange: {
    min: number;
    median: number;
    max: number;
    currency: string;
  };
  factors: string[];
  negotiationStrategies: string[];
  scriptSuggestions: string[];
  warnings: string[];
}

export interface SkillGapAnalysis {
  targetRole: string;
  currentSkills: string[];
  requiredSkills: string[];
  missingSkills: string[];
  recommendations: Array<{
    skill: string;
    priority: 'critical' | 'important' | 'nice-to-have';
    learningResources: string[];
    estimatedTime: string;
  }>;
}

export interface CVSmashResponse {
  analysis?: ResumeAnalysis;
  coverLetter?: CoverLetterReview;
  interviewPrep?: InterviewPrepResponse;
  salaryInfo?: SalaryNegotiation;
  skillGap?: SkillGapAnalysis;
  careerAdvice: string[];
  nextSteps: string[];
}

export interface LinkedInProfile {
  headline: string;
  summary: string;
  score: number; // 0-100
  improvements: string[];
  keywordOptimization: string[];
  profileStrength: 'all-star' | 'expert' | 'intermediate' | 'beginner';
}
