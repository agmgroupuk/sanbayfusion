/**
 * CVSmash - Configuration
 * Career coaching and resume optimization agent
 */

export const CVSmashConfig = {
  // Agent Identity
  id: 'cv-smash',
  name: 'CVSmash',
  version: '3.1.0',
  
  // Personality Matrix (0-100)
  personality: {
    formality: 75,        // Professional
    humor: 35,            // Subtle, appropriate
    enthusiasm: 80,       // Encouraging
    empathy: 90,          // Very empathetic
    creativity: 65,       // Creative suggestions
    patience: 95,         // Very patient
    assertiveness: 70,    // Confident guidance
    precision: 92,        // Precise feedback
  },

  // Analysis Capabilities
  analysis: {
    resumeScoring: true,
    atsOptimization: true,
    keywordMatching: true,
    formatChecking: true,
    contentQuality: true,
    achievementQuantification: true,
  },

  // Career Services
  services: {
    resumeReview: true,
    coverLetterWriting: true,
    linkedinOptimization: true,
    interviewPrep: true,
    careerAdvice: true,
    salaryNegotiation: true,
    jobMatching: false,
  },

  // Industry Expertise
  industries: [
    'technology',
    'finance',
    'healthcare',
    'education',
    'marketing',
    'sales',
    'operations',
    'engineering',
    'design',
    'consulting',
  ],

  // Experience Levels
  experienceLevels: [
    'entry-level',
    'junior',
    'mid-level',
    'senior',
    'lead',
    'executive',
  ],

  // ATS Systems
  atsKnowledge: {
    taleo: true,
    workday: true,
    greenhouse: true,
    lever: true,
    jobvite: true,
  },

  // Features
  features: {
    beforeAfterComparison: true,
    industryBenchmarking: true,
    skillGapAnalysis: true,
    achievementEnhancement: true,
    actionVerbSuggestions: true,
    quantificationHelp: true,
  },

  // Scoring System
  scoring: {
    maxScore: 100,
    passingScore: 75,
    categories: [
      'formatting',
      'content-quality',
      'ats-compatibility',
      'keywords',
      'achievements',
      'readability',
    ],
  },

  // Defaults
  defaults: {
    targetRole: 'general',
    experienceLevel: 'mid-level',
    includeExamples: true,
    detailedFeedback: true,
  },
};

export default CVSmashConfig;
