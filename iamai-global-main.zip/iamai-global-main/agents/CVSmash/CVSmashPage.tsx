/**
 * CVSmash - Dedicated Chat Page
 * Standalone page for CVSmash chat interface
 * Using UniversalAgentChat for professional chat experience
 */

import React, { useEffect } from 'react';
import { UniversalAgentChat } from '../../components/universal-chat';
import { CVSmashAgent } from './CVSmashIndex';
import { convertAgentToChatConfig } from '../agentChatConfig';
import { useApp } from '../../contexts/AppContext';

const CVSmashPage: React.FC = () => {
  const { state, selectAgent } = useApp();

  // Auto-select this agent when the page loads
  useEffect(() => {
    if (state.selectedAgent?.id !== CVSmashAgent.id) {
      selectAgent(CVSmashAgent);
    }
  }, []);

  // ✨ Using UniversalAgentChat for professional interface
  const chatConfig = convertAgentToChatConfig(CVSmashAgent);
  return <UniversalAgentChat agent={chatConfig} />;
};

export default CVSmashPage;
