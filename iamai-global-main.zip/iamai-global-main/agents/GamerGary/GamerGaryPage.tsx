/**
 * Gamer Gary - Dedicated Chat Page
 * Using UniversalAgentChat for professional chat experience
 */

import React, { useEffect } from 'react';
import { UniversalAgentChat } from '../../components/universal-chat';
import { GamerGaryAgent } from './GamerGaryIndex';
import { convertAgentToChatConfig } from '../agentChatConfig';
import { useApp } from '../../contexts/AppContext';

const GamerGaryPage: React.FC = () => {
  const { state, selectAgent } = useApp();

  useEffect(() => {
    if (state.selectedAgent?.id !== GamerGaryAgent.id) {
      selectAgent(GamerGaryAgent);
    }
  }, []);

  const chatConfig = convertAgentToChatConfig(GamerGaryAgent);
  return <UniversalAgentChat agent={chatConfig} />;
};

export default GamerGaryPage;
