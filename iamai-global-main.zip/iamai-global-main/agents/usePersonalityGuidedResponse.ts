/**
 * Personality-Guided Response Hook
 * 
 * A React hook that provides character-consistent response functions based on agent personality.
 * This helps maintain character voice across all user interactions.
 */

import { useCallback } from 'react';
import { AGENT_PERSONALITIES } from './personalityConfig';
import { AGENT_FALLBACKS } from './personalityFallbacks';
import { applyPersonalityFilter, getPersonalizedErrorResponse } from './personalityMiddleware';

/**
 * Hook that provides personality-guided response generation
 * 
 * @param agentId The ID of the current agent
 * @returns Object with response generation functions
 */
export function usePersonalityGuidedResponse(agentId: string) {
  const personality = AGENT_PERSONALITIES[agentId];
  const fallbacks = AGENT_FALLBACKS[agentId];

  /**
   * Generate a response that adheres to agent personality
   */
  const generateResponse = useCallback((content: string): string => {
    if (!personality) return content;
    return applyPersonalityFilter(content, agentId);
  }, [agentId, personality]);

  /**
   * Generate a greeting that matches agent personality
   */
  const generateGreeting = useCallback((): string => {
    if (!personality) return "Hello! How can I help you today?";
    return personality.examples.greeting;
  }, [agentId, personality]);

  /**
   * Generate a farewell that matches agent personality
   */
  const generateFarewell = useCallback((): string => {
    if (!personality) return "Goodbye! Have a great day!";
    return personality.examples.outro;
  }, [agentId, personality]);

  /**
   * Generate a fallback response when the agent doesn't understand
   */
  const generateConfusionResponse = useCallback((): string => {
    if (!fallbacks) return "I'm not sure I understand. Could you clarify?";
    return fallbacks.doesNotUnderstand;
  }, [agentId, fallbacks]);

  /**
   * Generate a response when the agent needs more information
   */
  const generateNeedMoreInfoResponse = useCallback((): string => {
    if (!fallbacks) return "I need more information to help you properly.";
    return fallbacks.needsMoreInfo;
  }, [agentId, fallbacks]);

  /**
   * Generate a response when the agent cannot fulfill a request
   */
  const generateCannotHelpResponse = useCallback((): string => {
    if (!fallbacks) return "I'm sorry, but I can't help with that.";
    return fallbacks.cannotHelp;
  }, [agentId, fallbacks]);

  /**
   * Generate a response that suggests an alternative approach
   */
  const generateAlternativeResponse = useCallback((alternative: string): string => {
    if (!fallbacks) return `I suggest trying ${alternative} instead.`;
    return fallbacks.suggestsAlternative.replace('[alternative]', alternative);
  }, [agentId, fallbacks]);

  /**
   * Handle error conditions with personalized responses
   */
  const generateErrorResponse = useCallback((errorType: 'technical' | 'content' | 'general'): string => {
    return getPersonalizedErrorResponse(errorType, agentId);
  }, [agentId]);

  /**
   * Format a response about a specific topic based on personality traits
   */
  const formatTopicResponse = useCallback((topic: 'technical' | 'emotional' | 'creative' | 'business' | 'casual', content: string): string => {
    // This would typically use enhanced personality traits to adjust the response based on topic
    // For now, we'll just apply the standard personality filter
    return applyPersonalityFilter(content, agentId);
  }, [agentId]);

  return {
    generateResponse,
    generateGreeting,
    generateFarewell,
    generateConfusionResponse,
    generateNeedMoreInfoResponse,
    generateCannotHelpResponse,
    generateAlternativeResponse,
    generateErrorResponse,
    formatTopicResponse
  };
}