/**
 * AutoChat - Type Definitions
 */

export type TriggerType = 'time-based' | 'event-based' | 'condition-based' | 'manual' | 'webhook';
export type ActionType = 'send-message' | 'create-task' | 'update-data' | 'notification' | 'api-call' | 'data-processing';
export type WorkflowStatus = 'draft' | 'active' | 'paused' | 'completed' | 'failed';
export type ExecutionStatus = 'pending' | 'running' | 'completed' | 'failed' | 'cancelled';

export interface Workflow {
  id: string;
  name: string;
  description: string;
  status: WorkflowStatus;
  trigger: Trigger;
  actions: Action[];
  conditions?: Condition[];
  createdAt: Date;
  updatedAt: Date;
  lastExecuted?: Date;
  executionCount: number;
}

export interface Trigger {
  type: TriggerType;
  config: TimeBasedConfig | EventBasedConfig | ConditionBasedConfig | WebhookConfig;
}

export interface TimeBasedConfig {
  schedule: string; // Cron expression
  timezone: string;
  startDate?: Date;
  endDate?: Date;
}

export interface EventBasedConfig {
  eventType: string;
  source: string;
  filters?: Record<string, any>;
}

export interface ConditionBasedConfig {
  conditions: Condition[];
  checkInterval: number; // Minutes
}

export interface WebhookConfig {
  url: string;
  secret?: string;
  headers?: Record<string, string>;
}

export interface Action {
  id: string;
  type: ActionType;
  name: string;
  config: Record<string, any>;
  retryOnFailure: boolean;
  maxRetries: number;
  timeout?: number; // Seconds
  order: number;
}

export interface Condition {
  field: string;
  operator: 'equals' | 'not-equals' | 'greater-than' | 'less-than' | 'contains' | 'not-contains';
  value: any;
  logicalOperator?: 'AND' | 'OR';
}

export interface WorkflowExecution {
  id: string;
  workflowId: string;
  status: ExecutionStatus;
  startTime: Date;
  endTime?: Date;
  duration?: number; // Milliseconds
  triggeredBy: string;
  actionResults: ActionResult[];
  error?: ExecutionError;
}

export interface ActionResult {
  actionId: string;
  status: ExecutionStatus;
  startTime: Date;
  endTime: Date;
  output?: any;
  error?: string;
  retryCount: number;
}

export interface ExecutionError {
  code: string;
  message: string;
  actionId?: string;
  timestamp: Date;
  stack?: string;
}

export interface WorkflowTemplate {
  id: string;
  name: string;
  description: string;
  category: string;
  tags: string[];
  workflow: Omit<Workflow, 'id' | 'createdAt' | 'updatedAt' | 'executionCount'>;
  popularity: number;
}

export interface ExecutionLog {
  workflowId: string;
  executionId: string;
  timestamp: Date;
  level: 'debug' | 'info' | 'warning' | 'error';
  message: string;
  metadata?: Record<string, any>;
}

export interface PerformanceMetrics {
  workflowId: string;
  totalExecutions: number;
  successRate: number; // Percentage
  averageDuration: number; // Milliseconds
  failureRate: number; // Percentage
  lastExecution: Date;
  peakExecutionTime?: Date;
}

export interface AutoChatResponse {
  workflow?: Workflow;
  execution?: WorkflowExecution;
  templates?: WorkflowTemplate[];
  metrics?: PerformanceMetrics;
  suggestions: string[];
  warnings?: string[];
}

export interface NotificationSettings {
  onSuccess: boolean;
  onFailure: boolean;
  onWarning: boolean;
  channels: Array<'email' | 'sms' | 'push' | 'webhook'>;
  recipients: string[];
}
