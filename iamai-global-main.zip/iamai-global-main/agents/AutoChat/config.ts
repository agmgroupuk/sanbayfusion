/**
 * AutoChat - Configuration
 * Automation workflows and scheduled task agent
 */

export const AutoChatConfig = {
  // Agent Identity
  id: 'auto-chat',
  name: 'AutoChat',
  version: '2.3.0',
  
  // Personality Matrix (0-100)
  personality: {
    formality: 65,        // Professional automation
    humor: 45,            // Light humor
    enthusiasm: 70,       // Helpful energy
    empathy: 65,          // Understanding needs
    creativity: 70,       // Creative automation
    patience: 85,         // Patient setup
    assertiveness: 70,    // Confident recommendations
    precision: 95,        // Precise execution
  },

  // Automation Capabilities
  automation: {
    scheduling: true,
    workflows: true,
    triggers: true,
    conditions: true,
    actions: true,
    integrations: false,
  },

  // Workflow Features
  workflows: {
    sequential: true,
    parallel: true,
    conditional: true,
    loops: true,
    errorHandling: true,
    retryLogic: true,
  },

  // Trigger Types
  triggers: [
    'time-based',
    'event-based',
    'condition-based',
    'manual',
    'webhook',
  ],

  // Action Types
  actions: [
    'send-message',
    'create-task',
    'update-data',
    'notification',
    'api-call',
    'data-processing',
  ],

  // Scheduling
  scheduling: {
    oneTime: true,
    recurring: true,
    cron: true,
    timezone: true,
    businessHours: true,
  },

  // Features
  features: {
    templateLibrary: true,
    customWorkflows: true,
    workflowTesting: true,
    executionLogs: true,
    performanceMetrics: true,
    notifications: true,
  },

  // Limits
  limits: {
    maxWorkflowsPerUser: 50,
    maxActionsPerWorkflow: 20,
    maxExecutionsPerDay: 1000,
    retryAttempts: 3,
  },

  // Defaults
  defaults: {
    timezone: 'UTC',
    notifyOnError: true,
    notifyOnSuccess: false,
    logLevel: 'info',
  },
};

export default AutoChatConfig;
