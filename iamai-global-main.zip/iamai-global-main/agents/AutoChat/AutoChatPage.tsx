/**
 * AutoChat - Dedicated Chat Page
 * Standalone page for AutoChat chat interface
 * Using UniversalAgentChat for professional chat experience
 */

import React, { useEffect } from 'react';
import { UniversalAgentChat } from '../../components/universal-chat';
import { AutoChatAgent } from './AutoChatIndex';
import { convertAgentToChatConfig } from '../agentChatConfig';
import { useApp } from '../../contexts/AppContext';

const AutoChatPage: React.FC = () => {
  const { state, selectAgent } = useApp();

  // Auto-select this agent when the page loads
  useEffect(() => {
    if (state.selectedAgent?.id !== AutoChatAgent.id) {
      selectAgent(AutoChatAgent);
    }
  }, []);

  // ✨ Using UniversalAgentChat for professional interface
  const chatConfig = convertAgentToChatConfig(AutoChatAgent);
  return <UniversalAgentChat agent={chatConfig} />;
};

export default AutoChatPage;
