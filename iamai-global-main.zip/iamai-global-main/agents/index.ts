import { AIGirlfriendAgent } from './AIGirlfriend/AIGirlfriendIndex';
import { EmoAIAgent } from './EmoAI/EmoAIIndex';
import { PDFMindAgent } from './PDFMind/PDFMindIndex';
import { ChatReviveAgent } from './ChatRevive/ChatReviveIndex';
import { TokBoostAgent } from './TokBoost/TokBoostIndex';
import { YouGenAgent } from './YouGen/YouGenIndex';
import { AgentXAgent } from './AgentX/AgentXIndex';
import { AutoChatAgent } from './AutoChat/AutoChatIndex';
import { CVSmashAgent } from './CVSmash/CVSmashIndex';
// NEW PERSONALITY AGENTS (8 Total) 🎭
import { ComedyChadAgent } from './ComedyChad/ComedyChadIndex';
import { LazyLarryAgent } from './LazyLarry/LazyLarryIndex';
import { FlirtyFionaAgent } from './FlirtyFiona/FlirtyFionaIndex';
import { SassySarahAgent } from './SassySarah/SassySarahIndex';
import { NerdyNeilAgent } from './NerdyNeil/NerdyNeilIndex';
import { CoolKyleAgent } from './CoolKyle/CoolKyleIndex';
import { ZenMasterZaraAgent } from './ZenMasterZara/ZenMasterZaraIndex';
import { GamerGaryAgent } from './GamerGary/GamerGaryIndex';
import { Agent, AgentRole } from '../constants';

/**
 * ⚠️  LEGACY FALLBACK - DO NOT USE IN NEW CODE
 * 
 * This hardcoded array is kept ONLY as a fallback when the API is unavailable.
 * In production, agents should ALWAYS be fetched from the database via:
 * 
 *   - API: GET /api/agents
 *   - Hook: useAgents() from hooks/useAgents.ts
 *   - Service: agentsAPI from services/api.ts
 * 
 * The database is the single source of truth for all agent data.
 * Run `node backend/seed-agents.js` to populate the database.
 */
export const ALL_AGENTS: Agent[] = [
  // Original 9 Core Agents
  AIGirlfriendAgent,
  EmoAIAgent,
  PDFMindAgent,
  ChatReviveAgent,
  TokBoostAgent,
  YouGenAgent,
  AgentXAgent,
  AutoChatAgent,
  CVSmashAgent,
  // NEW 8 Personality Agents 🎭
  ComedyChadAgent,
  LazyLarryAgent,
  FlirtyFionaAgent,
  SassySarahAgent,
  NerdyNeilAgent,
  CoolKyleAgent,
  ZenMasterZaraAgent,
  GamerGaryAgent,
];

// Helper to get agent by ID from fallback
export function getAgentByIdFallback(agentId: string): Agent | undefined {
  return ALL_AGENTS.find(a => a.id === agentId);
}

export const ALL_AGENTS_ROLES: AgentRole[] = [
  {
    id: 'agent-x',
    name: 'AgentX',
    role: 'Advanced Generalist / Power-User Assistant',
    description: 'A versatile and customizable power-user agent for a wide range of tasks.',
    icon: 'fa-solid fa-robot',
    capabilities: {
      canAttachFiles: true,
    },
  },
  {
    id: 'pdf-mind',
    name: 'PDFMind',
    role: 'Data Extractor / Research Synthesizer',
    description:
      'Analytical, detail-oriented agent for data extraction and document comprehension.',
    icon: 'fa-solid fa-file-pdf',
    capabilities: {
      canAttachFiles: true,
    },
  },
  {
    id: 'cv-smash',
    name: 'CVSmash',
    role: 'Professional Development Coach / Resume Architect',
    description: 'Professional, career-focused agent for resume building and optimization.',
    icon: 'fa-solid fa-user-tie',
    capabilities: {
      canAttachFiles: false,
    },
  },
  {
    id: 'tok-boost',
    name: 'TokBoost',
    role: 'Viral Content Strategist / Trend Forecaster',
    description: 'Energetic, growth-focused influencer helper for social media engagement.',
    icon: 'fa-solid fa-arrow-trend-up',
    capabilities: {
      canAttachFiles: false,
    },
  },
  {
    id: 'you-gen',
    name: 'YouGen',
    role: 'Multimedia Production Assistant / Creative Engine',
    description: 'Creative multimedia agent for video, text, and other content generation.',
    icon: 'fa-solid fa-video',
    capabilities: {
      canAttachFiles: false,
    },
  },
];
