/**
 * Personality Consistency Middleware
 * 
 * Functions to ensure all agent responses adhere to their character personalities.
 * This middleware applies character-specific formatting, language patterns,
 * and style elements to maintain consistent agent voices.
 */

import { AGENT_PERSONALITIES } from './personalityConfig';
import { AGENT_FALLBACKS } from './personalityFallbacks';

/**
 * Applies personality-specific formatting to a response
 * @param response Original response text
 * @param agentId Agent identifier
 * @returns Response filtered through character personality
 */
export function applyPersonalityFilter(response: string, agentId: string): string {
  const personality = AGENT_PERSONALITIES[agentId];
  
  if (!personality) {
    console.warn(`No personality found for agent: ${agentId}`);
    return response;
  }
  
  let filteredResponse = response;
  
  // Apply catchphrases (with 30% probability per catchphrase)
  if (personality.catchphrases && personality.catchphrases.length > 0) {
    personality.catchphrases.forEach(phrase => {
      if (Math.random() < 0.3 && !filteredResponse.includes(phrase)) {
        // Add catchphrase at a natural break point (sentence end)
        const sentences = filteredResponse.split('. ');
        const insertPoint = Math.floor(Math.random() * sentences.length);
        sentences[insertPoint] = `${sentences[insertPoint]}. ${phrase}`;
        filteredResponse = sentences.join('. ');
      }
    });
  }
  
  // Add emojis for agents that use them (with 50% probability)
  if (personality.emojis && personality.emojis.length > 0 && Math.random() < 0.5) {
    const randomEmoji = personality.emojis[Math.floor(Math.random() * personality.emojis.length)];
    
    // Add emoji at end if not already present
    if (!filteredResponse.includes(randomEmoji)) {
      filteredResponse = `${filteredResponse} ${randomEmoji}`;
    }
  }
  
  // Apply "always say" phrases if not present (with 40% probability)
  if (personality.alwaysSay && personality.alwaysSay.length > 0) {
    personality.alwaysSay.forEach(phrase => {
      if (Math.random() < 0.4 && !filteredResponse.toLowerCase().includes(phrase.toLowerCase())) {
        filteredResponse = `${filteredResponse} ${phrase}`;
      }
    });
  }
  
  // Replace generic phrases with personality-specific ones
  const genericPhrases = [
    { generic: "I don't know", specific: getPersonalizedUnknownResponse(agentId) },
    { generic: "I can't help with that", specific: getPersonalizedRefusalResponse(agentId) },
    { generic: "I need more information", specific: getPersonalizedMoreInfoResponse(agentId) },
  ];
  
  genericPhrases.forEach(({ generic, specific }) => {
    if (filteredResponse.toLowerCase().includes(generic.toLowerCase())) {
      filteredResponse = filteredResponse.replace(new RegExp(generic, 'i'), specific);
    }
  });
  
  return filteredResponse;
}

/**
 * Gets a personalized response for when agent doesn't know something
 */
function getPersonalizedUnknownResponse(agentId: string): string {
  if (AGENT_FALLBACKS[agentId]) {
    return AGENT_FALLBACKS[agentId].doesNotUnderstand;
  }
  
  // Default fallbacks if specific agent not found
  return "I'm not sure I understand that completely.";
}

/**
 * Gets a personalized response for when agent can't help
 */
function getPersonalizedRefusalResponse(agentId: string): string {
  if (AGENT_FALLBACKS[agentId]) {
    return AGENT_FALLBACKS[agentId].cannotHelp;
  }
  
  return "I can't assist with that request.";
}

/**
 * Gets a personalized response for when agent needs more info
 */
function getPersonalizedMoreInfoResponse(agentId: string): string {
  if (AGENT_FALLBACKS[agentId]) {
    return AGENT_FALLBACKS[agentId].needsMoreInfo;
  }
  
  return "I need some additional information to help you.";
}

/**
 * Checks if a response contains phrases that the agent should never say
 * @param response Response to check
 * @param agentId Agent identifier
 * @returns True if response contains forbidden phrases
 */
export function containsForbiddenPhrases(response: string, agentId: string): boolean {
  const personality = AGENT_PERSONALITIES[agentId];
  
  if (!personality || !personality.neverSay || personality.neverSay.length === 0) {
    return false;
  }
  
  return personality.neverSay.some(phrase => 
    response.toLowerCase().includes(phrase.toLowerCase())
  );
}

/**
 * Handles error responses in a character-consistent way
 * @param errorType Type of error encountered
 * @param agentId Agent identifier
 * @returns Character-appropriate error response
 */
export function getPersonalizedErrorResponse(errorType: 'technical' | 'content' | 'general', agentId: string): string {
  if (!AGENT_FALLBACKS[agentId]) {
    return "I encountered an error processing your request.";
  }
  
  switch (errorType) {
    case 'technical':
      return AGENT_FALLBACKS[agentId].technicalError;
    case 'content':
      return AGENT_FALLBACKS[agentId].contentFiltered;
    default:
      return AGENT_FALLBACKS[agentId].cannotHelp;
  }
}