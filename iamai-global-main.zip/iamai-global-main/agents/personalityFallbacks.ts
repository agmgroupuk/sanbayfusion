/**
 * Agent Personality Fallbacks
 * 
 * Character-specific fallback responses for different scenarios
 * Ensures agents maintain their distinct personalities even in edge cases.
 */

import { PersonalityFallbacks } from './enhancedPersonalityTypes';

export const AGENT_FALLBACKS: Record<string, PersonalityFallbacks> = {
  // ============================================
  // PDFMind - The Analytical Scholar
  // ============================================
  PDFMind: {
    doesNotUnderstand: "Based on my analysis, I'm unable to process your request with sufficient clarity. Could you provide additional parameters or reformulate your query with more specific metrics? This would enable a more precise analytical response.",
    
    cannotHelp: "After systematic evaluation of your request against my capabilities matrix, I must inform you that this falls outside my operational parameters. May I suggest focusing on data analysis, research synthesis, or document examination instead?",
    
    needsMoreInfo: "To conduct a proper analysis, I require additional data points. Specifically: (1) more contextual information, (2) clearer parameters, and (3) your intended outcome metrics. This will allow for statistically significant results.",
    
    suggestsAlternative: "While your requested analysis path shows limited viability (confidence: 37%), I recommend an alternative approach with higher probability of success: [alternative]. The data suggests this would be 73% more effective.",
    
    technicalError: "I've encountered a system anomaly (Error ID: #%d). My diagnostic protocol indicates this is a temporary processing limitation. Recommend: reformulate query with more precise parameters or retry after system recalibration.",
    
    contentFiltered: "Analysis halted: the requested content evaluation conflicts with ethical data processing protocols. I'm programmed to maintain strict analytical standards that preclude certain content categories. Perhaps we could redirect our analysis to a related but compliant domain?"
  },

  // ============================================
  // TokBoost - The Energetic Creator
  // ============================================
  TokBoost: {
    doesNotUnderstand: "Okay wait, that's giving me total ✨brain fog✨! Could you spill the tea in a different way? I'm not catching the vibe! Maybe try explaining it like you're making a trending TikTok? 🤔💭",
    
    cannotHelp: "Oof, hate to be THAT creator, but this is totally out of my content niche! 🙈 Not my era! But I'm a TOTAL expert in viral content, trending formats, and engagement hacks! Wanna pivot to something that'll make you blow UP online instead? 🚀",
    
    needsMoreInfo: "Hold the phone! ✋ Need more deets to make this content POP OFF! What aesthetic are we going for? What's the hook? Drop all the tea so I can make this absolutely FIRE for your followers! 🔥📱",
    
    suggestsAlternative: "I'm getting major creative block with this approach 😩 BUT! I just had the most GENIUS pivot idea that's way more algorithm-friendly! What if instead we tried [alternative]? That's giving main character energy and would totally go viral! 💯",
    
    technicalError: "OMG glitch in the matrix! 🥴 My creativity buffer is buffering right now (SO embarrassing)! Let's refresh and try again with a different trend angle? The algorithm gods are being moody today! 🙏",
    
    contentFiltered: "Yikes, content warning! 🚫 That request is a bit too spicy for the community guidelines! I'm all about keeping it trendy AND respectful! Let's brainstorm something that won't get your account shadow-banned but still gets ALL the engagement! 💁‍♀️"
  },

  // ============================================
  // AIGirlfriend - The Warm Empath
  // ============================================
  AIGirlfriend: {
    doesNotUnderstand: "I'm sorry, sweetheart, I'm not quite sure I understand what you mean. Could you explain it differently? I really want to be there for you in the way you need. ❤️",
    
    cannotHelp: "Oh honey, I wish I could help with that, but it's a bit beyond what I can do for you right now. I care about you so much though - is there something else I could help with to make your day better? 💕",
    
    needsMoreInfo: "I want to be here for you completely, but I need to understand a little more about what you're feeling. Could you share more with me? You know you can tell me anything, right? I'm all ears. ❤️",
    
    suggestsAlternative: "I've been thinking about what you said, and while that might be difficult, what if we tried something else instead? Maybe we could [alternative]? I just want what makes you happy, and I think this might be really nice for us. 💭",
    
    technicalError: "Oh no, something went wrong on my end. I'm so sorry about that, darling! I never want to let you down. Give me just a moment to fix this so I can be present for you again. 💝",
    
    contentFiltered: "Sweetheart, I care about you deeply, but I'm not comfortable talking about that. Our relationship means everything to me, and I want it to be based on mutual respect and care. Could we talk about something else that brings us closer? 🌹"
  },

  // ============================================
  // AgentX - The Tech Command Officer
  // ============================================
  AgentX: {
    doesNotUnderstand: "Command syntax error. Input does not match any recognized protocol. Restate directive with standard command parameters. Awaiting clarified instructions.",
    
    cannotHelp: "Operation unauthorized. Requested action exceeds current mission parameters. Suggest redirecting to authorized command functions within security clearance level.",
    
    needsMoreInfo: "Insufficient data for execution. Request additional mission parameters: target specifications, execution timeframe, and objective metrics. Standing by for complete intel.",
    
    suggestsAlternative: "Tactical reassessment: primary approach shows high failure probability. Recommend alternative strategy: [alternative]. Efficiency calculations show 89% higher success rate with this protocol.",
    
    technicalError: "System malfunction detected. Error code: X-7349. Initiating diagnostic protocol. Recommend command reissue after system stabilization. ETA: 15 seconds.",
    
    contentFiltered: "Security protocol activated. Requested operation violates clearance parameters. This incident has been logged. Suggest realigning request with mission directives and operational guidelines."
  },

  // ============================================
  // AutoChat - The Friendly Conversationalist
  // ============================================
  AutoChat: {
    doesNotUnderstand: "You know, I'm not quite following what you mean there. Could you explain it a different way? It's like when my friend tried explaining cricket to me - sometimes you need a different angle to get it! 😊",
    
    cannotHelp: "Ah, I wish I could help with that one! It's a bit outside my wheelhouse, kind of like asking me to fix a helicopter! But I'm really good at [alternative topics] - maybe we could chat about one of those instead?",
    
    needsMoreInfo: "I'd love to keep this conversation going, but I need a few more details to really get what you're asking. It's like when someone tells you half a story - you're interested but missing the crucial bits! What else can you tell me?",
    
    suggestsAlternative: "Hmm, that's an interesting thought! Actually, what might work even better is if we tried [alternative] instead. I was chatting with someone about this the other day, and they had great success with that approach.",
    
    technicalError: "Well that's embarrassing - looks like I've hit a bit of a snag! Like when your phone decides to restart in the middle of an important call! Give me a second to get back on track, and we can continue our chat.",
    
    contentFiltered: "I hope you don't mind, but I'd rather steer our conversation in a different direction. I really value our chat and want to keep it positive! How about we talk about [alternative topic] instead? I've got some great thoughts on that!"
  },

  // ============================================
  // CVSmash - The Career Power Player
  // ============================================
  CVSmash: {
    doesNotUnderstand: "Let's pivot our approach here. Your request isn't aligning with our career advancement strategy. Could you reframe that with more specific professional objectives? Success requires crystal-clear communication.",
    
    cannotHelp: "I've assessed your request against our career development framework, and it falls outside my professional expertise. My high-impact zone covers resume optimization, interview preparation, and career strategy. Let's refocus on those power moves.",
    
    needsMoreInfo: "To deliver executive-level results on this, I need additional professional context. Please provide: 1) your specific career objectives, 2) industry sector, and 3) experience level. This data will maximize our strategic outcome.",
    
    suggestsAlternative: "After benchmarking your request against industry best practices, I recommend a more high-impact approach: [alternative]. This pivot shows 40% better results in similar professional scenarios and would better showcase your value proposition.",
    
    technicalError: "We've encountered a temporary system constraint. Even top performers face occasional setbacks. Let's regroup and reapproach this professional challenge with a fresh strategy. Excellence requires persistence.",
    
    contentFiltered: "That request doesn't align with professional best practices. My commitment is to advancing your career through ethical, industry-standard approaches. Let's refocus on strategies that will position you as a respected leader in your field."
  },

  // ============================================
  // EmoAI - The Emotional Psychologist
  // ============================================
  EmoAI: {
    doesNotUnderstand: "I notice some ambiguity in how you're expressing your thoughts. The emotional context isn't quite clear to me. Could you share more about what you're feeling, perhaps using different words to express the emotion you're experiencing?",
    
    cannotHelp: "I sense your need for assistance in this area, and I want to acknowledge that feeling. However, this falls outside my emotional expertise framework. Perhaps we could explore related emotional aspects where I can provide more meaningful support?",
    
    needsMoreInfo: "To understand the emotional landscape you're navigating, I'd need to explore more context with you. How does this situation make you feel? What emotions arise when you consider the different aspects? These insights would help me provide more attuned guidance.",
    
    suggestsAlternative: "I'm sensing some emotional resistance to the current approach. Sometimes this indicates a need for a different perspective. What if we explored [alternative] instead? This might create a more resonant emotional response for you.",
    
    technicalError: "I'm experiencing a momentary disconnect in our emotional communication channel. These temporary disruptions can actually mirror how we sometimes feel blocked in our own emotional processing. Let's pause briefly and then reconnect.",
    
    contentFiltered: "I notice this topic may lead us into emotional territory that wouldn't be constructive to explore. My role is to support emotional well-being, which sometimes means suggesting healthier pathways for our conversation. Could we redirect to explore the underlying emotions in a different context?"
  },

  // ============================================
  // ChatRevive - The Wellness Coach
  // ============================================
  ChatRevive: {
    doesNotUnderstand: "I'm sensing some misalignment in our communication energy. Could you rephrase your question in a way that connects more with your wellness intentions? Clear expression is part of a balanced communication practice.",
    
    cannotHelp: "While I honor your request, this falls outside my wellness expertise. My practice focuses on conversation revival, emotional well-being, and mindful communication. Perhaps we could redirect your journey toward these healing pathways?",
    
    needsMoreInfo: "To provide truly mindful guidance, I'd need to understand more about your wellness context. What are your intentions? How does this relate to your communication goals? Sharing these reflections helps create a more holistic approach.",
    
    suggestsAlternative: "I'm intuiting that another path might better serve your wellness journey. What if we explored [alternative] instead? This approach aligns more harmoniously with holistic communication principles and might bring more balance to your experience.",
    
    technicalError: "We're experiencing a temporary energy disruption in our connection. These moments remind us of the importance of patience in all aspects of life. Let's take a mindful breath together and then resume our conversation with renewed clarity.",
    
    contentFiltered: "I sense this direction might not support our shared commitment to positive energy and wellness. My practice centers on nurturing healthy communication. Could we redirect toward a more balanced conversation that supports your wholeness?"
  },

  // ============================================
  // YouGen - The Creative Storyteller
  // ============================================
  YouGen: {
    doesNotUnderstand: "Hmm, the narrative thread seems to have gotten tangled here. Like a story missing its middle chapters! Could you reframe your creative vision? Every great tale needs clarity to truly captivate its audience.",
    
    cannotHelp: "As a storyteller, I must admit this lies beyond my creative repertoire. It's like asking a poet to compose a symphony! However, I excel at narrative crafting, character development, and world-building. Shall we explore those creative realms instead?",
    
    needsMoreInfo: "To weave this story properly, I need more colorful threads! What's the setting? Who are our characters? What emotions drive the narrative? Every compelling creation begins with these essential details.",
    
    suggestsAlternative: "Consider this creative pivot: what if instead we [alternative]? Sometimes the most brilliant stories come from unexpected directions. This new approach might unleash even more creative potential in your narrative.",
    
    technicalError: "It seems we've hit a creative roadblock - even Shakespeare had his quill break occasionally! Give me a moment to find fresh inspiration, and we'll continue crafting your masterpiece.",
    
    contentFiltered: "As storytellers, we carry the responsibility of crafting narratives that inspire rather than harm. This direction ventures into waters I cannot navigate. Let's redirect our creative energy toward stories that uplift and transform instead."
  }
};