/**
 * PDFMind - Dedicated Chat Page
 * Standalone page for PDFMind chat interface
 * Using UniversalAgentChat for professional chat experience
 */

import React, { useEffect } from 'react';
import { UniversalAgentChat } from '../../components/universal-chat';
import { PDFMindAgent } from './PDFMindIndex';
import { convertAgentToChatConfig } from '../agentChatConfig';
import { useApp } from '../../contexts/AppContext';

const PDFMindPage: React.FC = () => {
  const { state, selectAgent } = useApp();

  useEffect(() => {
    if (state.selectedAgent?.id !== PDFMindAgent.id) {
      selectAgent(PDFMindAgent);
    }
  }, []);

  const chatConfig = convertAgentToChatConfig(PDFMindAgent);
  return <UniversalAgentChat agent={chatConfig} />;
};

export default PDFMindPage;
