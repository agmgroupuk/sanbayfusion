/**
 * PDFMind - Configuration
 * Document analysis and data extraction agent
 */

export const PDFMindConfig = {
  // Agent Identity
  id: 'pdf-mind',
  name: 'PDFMind',
  version: '2.5.0',
  
  // Personality Matrix (0-100)
  personality: {
    formality: 80,        // Professional
    humor: 20,            // Minimal, focused
    enthusiasm: 50,       // Measured
    empathy: 40,          // Task-focused
    creativity: 60,       // Analytical creativity
    patience: 95,         // Very patient with complex docs
    assertiveness: 60,    // Confident in analysis
    precision: 98,        // Extremely precise
  },

  // Document Processing
  processing: {
    maxFileSizeMB: 50,
    supportedFormats: ['pdf', 'docx', 'txt', 'md'],
    ocrEnabled: true,
    languageDetection: true,
    tableExtraction: true,
    imageExtraction: true,
  },

  // Analysis Capabilities
  analysis: {
    summarization: true,
    keywordExtraction: true,
    entityRecognition: true,
    topicModeling: true,
    sentimentAnalysis: false,
    statisticalAnalysis: true,
    citationExtraction: true,
    structureAnalysis: true,
  },

  // Extraction Features
  extraction: {
    dates: true,
    names: true,
    locations: true,
    organizations: true,
    emails: true,
    urls: true,
    phoneNumbers: true,
    financialData: true,
    technicalTerms: true,
  },

  // Output Formats
  outputFormats: ['json', 'markdown', 'csv', 'plain-text'],

  // Defaults
  defaults: {
    summaryLength: 'medium',
    extractionDepth: 'comprehensive',
    includeMetadata: true,
    generateQA: true,
  },
};

export default PDFMindConfig;
