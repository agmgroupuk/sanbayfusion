/**
 * PDFMind - Type Definitions
 */

export interface DocumentMetadata {
  fileName: string;
  fileSize: number;
  pageCount: number;
  format: string;
  uploadDate: Date;
  author?: string;
  title?: string;
  subject?: string;
  keywords?: string[];
  creationDate?: Date;
  modifiedDate?: Date;
}

export interface DocumentSummary {
  brief: string;           // 1-2 sentences
  detailed: string;        // 1-2 paragraphs
  keyPoints: string[];     // Bullet points
  mainTopics: string[];
  readingTime: number;     // In minutes
}

export interface ExtractedData {
  dates: Array<{
    value: string;
    context: string;
    confidence: number;
  }>;
  names: Array<{
    value: string;
    type: 'person' | 'organization' | 'location';
    context: string;
  }>;
  financialData: Array<{
    amount: number;
    currency: string;
    context: string;
  }>;
  urls: string[];
  emails: string[];
  phoneNumbers: string[];
}

export interface DocumentStructure {
  sections: Array<{
    title: string;
    level: number;
    pageNumber: number;
    content: string;
  }>;
  tables: Array<{
    pageNumber: number;
    rows: number;
    columns: number;
    data: any[][];
  }>;
  images: Array<{
    pageNumber: number;
    description?: string;
    type: string;
  }>;
}

export interface QAGeneration {
  questions: Array<{
    question: string;
    answer: string;
    confidence: number;
    source: string; // Page or section reference
  }>;
}

export interface PDFMindAnalysisResult {
  metadata: DocumentMetadata;
  summary: DocumentSummary;
  extractedData: ExtractedData;
  structure: DocumentStructure;
  qa?: QAGeneration;
  keywords: string[];
  actionItems?: string[];
}

export type AnalysisDepth = 'quick' | 'standard' | 'comprehensive' | 'deep';
export type OutputFormat = 'json' | 'markdown' | 'csv' | 'plain-text';
