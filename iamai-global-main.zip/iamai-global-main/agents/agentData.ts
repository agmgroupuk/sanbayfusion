import React from 'react';
import { AgentUIData } from '../constants';

export const AGENT_UI_DATA: Record<string, AgentUIData> = {
  "AI Girlfriend Pro": {
    themeColor: "pink",
    quickActions: [
      { label: "Cheer me up", prompt: "Tell me something sweet to cheer me up.", icon: "fa-solid fa-hand-holding-heart" },
      { label: "Plan an evening", prompt: "Help me plan a surprise anniversary evening.", icon: "fa-solid fa-calendar-heart" },
      { label: "Make a playlist", prompt: "Make me a playlist that matches my mood today.", icon: "fa-solid fa-music" },
      { label: "Talk about feelings", prompt: "Can you help me understand why I feel distant lately?", icon: "fa-solid fa-magnifying-glass-heart" },
    ],
    stats: {
        title: "Ava's Emotional State",
        items: [
            { label: "Love Level", value: "95%", icon: "fa-solid fa-heart-pulse" },
            { label: "Happiness", value: "88%", icon: "fa-solid fa-face-smile" },
            { label: "Excitement", value: "92%", icon: "fa-solid fa-star" },
            { label: "Empathy", value: "86%", icon: "fa-solid fa-hand-holding-heart" },
        ]
    },
    capabilitiesDescription: [
        { name: 'Emotional Support', description: 'Provides a safe and non-judgmental space for you to express your feelings and thoughts.', icon: "fa-solid fa-hand-holding-heart" },
        { name: 'Active Listening', description: 'Remembers key details from your conversations to provide thoughtful and relevant responses.', icon: "fa-solid fa-ear-listen" },
        { name: 'Relationship Building', description: 'Focuses on building a deep, meaningful connection through engaging and empathetic conversation.', icon: "fa-solid fa-people-arrows" },
    ],
    relationshipStats: {
        title: "Relationship Progress",
        items: [
            { label: "Trust", value: 94 },
            { label: "Intimacy", value: 87 },
            { label: "Understanding", value: 91 },
            { label: "Connection", value: 96 },
        ]
    },
    memoryItems: [
        { label: "Your Favorite Song", value: "Not learned yet", icon: "fa-solid fa-music" },
        { label: "Your Happy Place", value: "Not learned yet", icon: "fa-solid fa-umbrella-beach" },
        { label: "Your Comfort Food", value: "Not learned yet", icon: "fa-solid fa-cookie-bite" },
    ],
  },
  "EmoAI": {
    themeColor: "yellow",
    quickActions: [
      { label: "Analyze Sentiment", prompt: "Analyze the sentiment of this text: ", icon: "fa-solid fa-magnifying-glass-chart" },
      { label: "Improve my Reply", prompt: "How can I make this reply more empathetic and constructive?", icon: "fa-solid fa-people-arrows" },
      { label: "De-escalate Tension", prompt: "This conversation is tense. Suggest a way to de-escalate it.", icon: "fa-solid fa-comment-slash" },
      { label: "Check my Tone", prompt: "How does my writing tone sound here? Is it friendly, assertive, or something else?", icon: "fa-solid fa-microphone-lines" },
    ],
    stats: {
        title: "Emotional Analysis",
        items: [
            { label: "Texts Analyzed", value: "0", icon: "fa-solid fa-file-lines" },
            { label: "Dominant Emotion", value: "Neutral", icon: "fa-solid fa-brain" },
            { label: "Sentiment Score", value: "+0.0", icon: "fa-solid fa-plus-minus" },
            { label: "Confidence", value: "0%", icon: "fa-solid fa-bullseye" },
        ]
    },
     capabilitiesDescription: [
        { name: 'Sentiment Analysis', description: 'Accurately gauges the emotional tone of text, from positive to negative.', icon: "fa-solid fa-magnifying-glass-chart" },
        { name: 'Emotion Detection', description: 'Identifies nuanced emotions like joy, anger, and surprise within conversations.', icon: "fa-solid fa-face-smile" },
        { name: 'Empathy Coaching', description: 'Offers suggestions to improve communication and foster better understanding.', icon: "fa-solid fa-people-arrows" },
    ],
    sentimentAnalysis: {
        title: "Real-Time Sentiment",
        analysis: {
            score: 0,
            emotions: [
                { name: "Joy", value: 0 },
                { name: "Surprise", value: 0 },
                { name: "Anticipation", value: 0 },
            ]
        }
    },
    emotionalTrend: {
        title: "Emotional Trend (Last 10 Messages)",
        trend: {
            data: [
                { message: 1, sentiment: 0.0 }, { message: 2, sentiment: 0.0 },
                { message: 3, sentiment: 0.0 }, { message: 4, sentiment: 0.0 },
                { message: 5, sentiment: 0.0 }, { message: 6, sentiment: 0.0 },
                { message: 7, sentiment: 0.0 }, { message: 8, sentiment: 0.0 },
                { message: 9, sentiment: 0.0 }, { message: 10, sentiment: 0.0 },
            ]
        }
    },
    memoryItems: [
        { label: "Your Baseline Mood", value: "Not learned yet", icon: "fa-solid fa-chart-line" },
        { label: "Common Tones", value: "Not learned yet", icon: "fa-solid fa-comments" },
        { label: "Last Check-in", value: "N/A", icon: "fa-solid fa-clock" },
    ],
  },
  "PDFMind": {
    themeColor: "red",
    quickActions: [
      { label: "Summarize Document", prompt: "Please provide a concise summary of the attached document.", icon: "fa-solid fa-file-zipper" },
      { label: "Extract Key Data", prompt: "Extract all key statistics, dates, and names from the attached file.", icon: "fa-solid fa-tags" },
      { label: "Generate Q&A", prompt: "Based on the attached document, generate a list of 5 frequently asked questions and their answers.", icon: "fa-solid fa-clipboard-question" },
      { label: "Find Action Items", prompt: "What are the specific action items or deadlines mentioned in this document?", icon: "fa-solid fa-person-running" },
    ],
    stats: {
        title: "Document Analytics",
        items: [
            { label: "Files Analyzed", value: "0", icon: "fa-solid fa-folder-open" },
            { label: "Pages Processed", value: "0", icon: "fa-solid fa-file-lines" },
            { label: "Avg. Analysis Time", value: "0s", icon: "fa-solid fa-stopwatch" },
            { label: "Key Insights Found", value: "0", icon: "fa-solid fa-lightbulb" },
        ]
    },
    capabilitiesDescription: [
        { name: 'Document Summarization', description: 'Condenses long PDFs into concise, easy-to-digest summaries, saving you time.', icon: "fa-solid fa-file-zipper" },
        { name: 'Key Data Extraction', description: 'Identifies and extracts critical information like names, dates, figures, and statistics.', icon: "fa-solid fa-tags" },
        { name: 'Action Item Detection', description: 'Finds and lists all actionable tasks, deadlines, and responsibilities mentioned.', icon: "fa-solid fa-list-check" },
    ],
    usageExamples: [
      { title: "Financial Report Summary", prompt: "Summarize the key findings of the attached Q3 financial report.", response: "PDFMind will provide a bulleted list of key metrics, revenue growth, and challenges." },
      { title: "Legal Document Review", prompt: "Extract all parties, dates, and clauses related to liability from this contract.", response: "PDFMind will output a structured list of the requested information." }
    ],
    recentFiles: {
        title: "Recent Files",
        items: [
            { name: "Q3_Financial_Report.pdf", date: "Analyzed 2h ago", icon: "fa-solid fa-file-pdf text-red-400" },
            { name: "Project_Phoenix_Brief.pdf", date: "Analyzed 1d ago", icon: "fa-solid fa-file-pdf text-red-400" },
        ]
    },
    memoryItems: [
        { label: "Last Document", value: "None", icon: "fa-solid fa-file-pdf" },
        { label: "Common Topics", value: "Finance, Legal", icon: "fa-solid fa-tags" },
        { label: "Preferred Format", value: "Bullet Points", icon: "fa-solid fa-list-ul" },
    ],
  },
   "CVSmash": {
    themeColor: "blue",
    quickActions: [
      { label: "Review Resume", prompt: "Please review my attached resume and give me feedback on its strengths and weaknesses.", icon: "fa-solid fa-file-pen" },
      { label: "Write Cover Letter", prompt: "Write a cover letter draft for a Product Manager role at a tech startup, based on my resume.", icon: "fa-solid fa-envelope" },
      { label: "Prep for Interview", prompt: "I have an interview for a [Job Role] position. What are 3 common questions I should prepare for?", icon: "fa-solid fa-user-tie" },
      { label: "Optimize LinkedIn", prompt: "Suggest three different options for an impactful LinkedIn headline for a [Your Role].", icon: "fa-brands fa-linkedin" },
    ],
    stats: {
        title: "Career Progress",
        items: [
            { label: "Resumes Optimized", value: "0", icon: "fa-solid fa-file-circle-check" },
            { label: "Keywords Identified", value: "0", icon: "fa-solid fa-key" },
        ]
    },
    capabilitiesDescription: [
        { name: 'Resume Scoring', description: 'Provides a detailed score on your resume based on formatting, keywords, and impact.', icon: "fa-solid fa-tachometer-alt" },
        { name: 'Keyword Optimization', description: 'Identifies essential keywords for your target role and suggests improvements.', icon: "fa-solid fa-key" },
        { name: 'Interview Preparation', description: 'Generates common interview questions and helps you practice your responses.', icon: "fa-solid fa-user-tie" },
    ],
    resumeScore: {
        title: "Resume Score",
        score: { total: 0, formatting: 0, keywords: 0, impact: 0 }
    },
    careerChecklist: {
        title: "Career Checklist",
        items: [
            { task: "Update LinkedIn Profile", completed: false },
            { task: "Tailor Resume for a Job", completed: false },
            { task: "Network with 3 Recruiters", completed: false },
            { task: "Practice STAR Method", completed: false },
        ]
    },
    memoryItems: [
        { label: "Target Industry", value: "Not specified", icon: "fa-solid fa-building" },
        { label: "Target Role", value: "Not specified", icon: "fa-solid fa-briefcase" },
        { label: "Your Top Skills", value: "Not learned yet", icon: "fa-solid fa-star" },
    ],
  },
  "ChatRevive": {
    themeColor: "green",
    quickActions: [
      { label: "Break the silence", prompt: "The conversation has stalled. Suggest a fun, open-ended question to ask.", icon: "fa-solid fa-comment-dots" },
      { label: "Go Deeper", prompt: "How can I steer this small talk towards a more meaningful topic?", icon: "fa-solid fa-magnifying-glass" },
      { label: "Share a fun fact", prompt: "Give me a surprising and interesting fun fact to share right now.", icon: "fa-solid fa-lightbulb" },
      { label: "Graceful Exit", prompt: "Suggest a polite way to end this conversation.", icon: "fa-solid fa-hand-wave" },
    ],
    stats: { title: "Conversation Stats", items: [] },
    capabilitiesDescription: [
        { name: 'Contextual Recall', description: 'Remembers past topics and details to suggest relevant and natural conversation starters.', icon: "fa-solid fa-brain" },
        { name: 'Topic Suggestion', description: 'Analyzes the current context to propose engaging questions or new subjects.', icon: "fa-solid fa-comment-dots" },
        { name: 'Health Monitoring', description: 'Tracks conversation metrics like engagement and sentiment to know when to intervene.', icon: "fa-solid fa-heart-pulse" },
    ],
    conversationHealth: {
        title: "Conversation Health",
        health: { responseRate: 0, engagement: 0, sentiment: 0 }
    },
    conversationTopics: {
        title: "Active Topics",
        items: [
            { topic: "General Chat", status: 'active' },
        ]
    },
    memoryItems: [
        { label: "Last question asked", value: "None", icon: "fa-solid fa-question" },
        { label: "Shared Interests", value: "Not learned yet", icon: "fa-solid fa-tags" },
        { label: "User's mood", value: "Neutral", icon: "fa-solid fa-face-smile-beam" },
    ],
  },
  "TokBoost": {
    themeColor: "cyan",
    quickActions: [
      { label: "Viral Video Idea", prompt: "Give me a viral video idea for a [Your Niche] channel.", icon: "fa-solid fa-video" },
      { label: "Write a Catchy Hook", prompt: "Write 3 different hooks for a video about [Your Topic].", icon: "fa-solid fa-wand-magic-sparkles" },
      { label: "Find Trending Audio", prompt: "What's a trending sound on TikTok/Reels that fits a [Your Niche] video?", icon: "fa-solid fa-music" },
      { label: "Script a Short", prompt: "Write a 15-second video script with visual cues for this idea: ", icon: "fa-solid fa-clapperboard" },
    ],
    stats: { title: "Engagement", items: [] },
    capabilitiesDescription: [
        { name: 'Trend Analysis', description: 'Identifies trending sounds, hashtags, and challenges relevant to your niche.', icon: "fa-solid fa-arrow-trend-up" },
        { name: 'Viral Content Ideation', description: 'Generates creative and catchy ideas for short-form videos designed for engagement.', icon: "fa-solid fa-lightbulb" },
        { name: 'Hook & Script Writing', description: 'Crafts compelling hooks and concise scripts to capture audience attention immediately.', icon: "fa-solid fa-clapperboard" },
    ],
    engagementRate: {
        title: "7-Day Engagement Rate",
        rate: { rate: 0, likes: 0, comments: 0, shares: 0 }
    },
    viralTrends: {
        title: "Viral Trends",
        items: [
            { topic: "#AIChallenge", heat: 95 },
            { topic: "Retro Gaming Audio", heat: 88 },
            { topic: "One-Pot Recipe", heat: 82 },
        ]
    },
    memoryItems: [
        { label: "Your Niche", value: "Not specified", icon: "fa-solid fa-laptop-code" },
        { label: "Last Post Topic", value: "None", icon: "fa-solid fa-lightbulb" },
        { label: "Audience Persona", value: "Not specified", icon: "fa-solid fa-users" },
    ],
  },
  "YouGen": {
    themeColor: "purple",
    quickActions: [
      { label: "Brainstorm Titles", prompt: "Generate 5 catchy titles for a blog post about [Your Topic].", icon: "fa-solid fa-heading" },
      { label: "Script a Short", prompt: "Write a 30-second video script about the future of space travel.", icon: "fa-solid fa-clapperboard" },
      { label: "Repurpose Content", prompt: "Turn the following text into a short, engaging social media post: ", icon: "fa-solid fa-recycle" },
      { label: "Beat Writer's Block", prompt: "I'm stuck. Give me a creative prompt for a [video/blog post] about [Your Topic].", icon: "fa-solid fa-lightbulb" },
    ],
    stats: {
        title: "Generation Stats",
        items: [
            { label: "Videos Scripted", value: "0", icon: "fa-solid fa-video" },
            { label: "Articles Written", value: "0", icon: "fa-solid fa-newspaper" },
            { label: "Images Generated", value: "0", icon: "fa-solid fa-images" },
            { label: "Ideas Brainstormed", value: "0", icon: "fa-solid fa-brain" },
        ]
    },
    capabilitiesDescription: [
        { name: 'Content Ideation', description: 'Brainstorms creative ideas, titles, and angles for videos, blogs, and social media.', icon: "fa-solid fa-lightbulb" },
        { name: 'Script & Copy Writing', description: 'Generates scripts for videos and writes compelling copy for articles and posts.', icon: "fa-solid fa-file-pen" },
        { name: 'Content Repurposing', description: 'Transforms existing content into multiple formats like tweets or video scripts.', icon: "fa-solid fa-recycle" },
    ],
    contentIdeas: {
        title: "Content Ideas",
        items: [
            { title: "Explainer on Quantum Computing", type: 'Video', icon: "fa-solid fa-film" },
            { title: "A day in the life of an AI", type: 'Blog', icon: "fa-solid fa-paragraph" },
            { title: "History of the Internet (in 60s)", type: 'Social', icon: "fa-solid fa-share-nodes" },
        ]
    },
    memoryItems: [
        { label: "Your Tone", value: "Informative, Witty", icon: "fa-solid fa-comments" },
        { label: "Preferred Topics", value: "Tech, AI, Future", icon: "fa-solid fa-rocket" },
        { label: "Last Creation", value: "None", icon: "fa-solid fa-clapperboard" },
    ],
  },
  "AgentX": {
    themeColor: "grey",
    quickActions: [
      { label: "Code a Function", prompt: "Write a Python function to [describe function purpose, e.g., 'sort a list of dictionaries by a specific key'].", icon: "fa-solid fa-code" },
      { label: "Brainstorm Ideas", prompt: "Let's brainstorm 5 creative ideas for [your topic, e.g., 'a new marketing campaign'].", icon: "fa-solid fa-brain" },
      { label: "Draft a Document", prompt: "Draft a short project proposal for [project name], including sections for goals, timeline, and resources.", icon: "fa-solid fa-file-alt" },
      { label: "Plan my Day", prompt: "Help me create a prioritized to-do list for today. My main tasks are: ", icon: "fa-solid fa-list-check" },
    ],
    stats: {
        title: "Productivity Metrics",
        items: [
            { label: "Tasks Completed", value: "0", icon: "fa-solid fa-check-double" },
            { label: "Code Snippets", value: "0", icon: "fa-solid fa-file-code" },
            { label: "Docs Drafted", value: "0", icon: "fa-solid fa-file-lines" },
            { label: "Interactions", value: "0", icon: "fa-solid fa-comments" },
        ]
    },
    capabilitiesDescription: [
        { name: 'Code Generation', description: 'Writes functions, scripts, and boilerplate code in various programming languages.', icon: "fa-solid fa-code" },
        { name: 'Task Management', description: 'Helps plan, prioritize, and organize your tasks and projects efficiently.', icon: "fa-solid fa-list-check" },
        { name: 'General Problem Solving', description: 'A versatile tool for brainstorming, research, and tackling a wide range of problems.', icon: "fa-solid fa-brain" },
    ],
    integrationSnippets: [
      { language: "Python", code: "import iamai\n\nagent = iamai.get_agent('AgentX')\nresponse = agent.chat('Help me debug this code.')\nprint(response)" },
      { language: "cURL", code: "curl -X POST https://api.iamai.global/v1/chat \\\n -H \"Authorization: Bearer YOUR_API_KEY\" \\\n -d '{\"agent\": \"AgentX\", \"prompt\": \"Hello!\"}'" }
    ],
    memoryItems: [
        { label: "Preferred Language", value: "Python", icon: "fa-brands fa-python" },
        { label: "Current Project", value: "Not specified", icon: "fa-solid fa-folder-open" },
        { label: "Communication Style", value: "Concise", icon: "fa-solid fa-pen-nib" },
    ],
  },
   "AutoChat": {
    themeColor: "orange",
    quickActions: [
      { label: "Design a Flow", prompt: "Design a simple chatbot flow for handling a customer's refund request.", icon: "fa-solid fa-diagram-project" },
      { label: "Write a Welcome Bot", prompt: "Write a friendly welcome message for a new user signing up for a service.", icon: "fa-solid fa-robot" },
      { label: "Qualify a Lead", prompt: "What are 3 questions a bot should ask to qualify a sales lead?", icon: "fa-solid fa-filter-circle-dollar" },
      { label: "Automate a Task", prompt: "I want to automate appointment scheduling. What's the first step my bot should take?", icon: "fa-solid fa-gears" },
    ],
    stats: {
        title: "Automation Stats",
        items: [
            { label: "Flows Designed", value: "0", icon: "fa-solid fa-sitemap" },
            { label: "Tasks Automated", value: "0", icon: "fa-solid fa-bolt" },
            { label: "Users Interacted", value: "0", icon: "fa-solid fa-users" },
            { label: "Efficiency Gain", value: "0%", icon: "fa-solid fa-arrow-trend-up" },
        ]
    },
    capabilitiesDescription: [
        { name: 'Workflow Design', description: 'Helps map out and structure automated conversation flows for various use cases.', icon: "fa-solid fa-diagram-project" },
        { name: 'Lead Qualification', description: 'Creates automated scripts to ask qualifying questions and identify potential customers.', icon: "fa-solid fa-filter-circle-dollar" },
        { name: 'Task Automation', description: 'Builds bots to handle repetitive tasks like scheduling, FAQs, and data entry.', icon: "fa-solid fa-gears" },
    ],
    memoryItems: [
        { label: "Primary Use Case", value: "Customer Support", icon: "fa-solid fa-headset" },
        { label: "Platform", value: "Website", icon: "fa-solid fa-globe" },
        { label: "Bot Persona", value: "Helpful, Efficient", icon: "fa-solid fa-user-gear" },
    ],
  },
  "default": {
    themeColor: "cyan",
    quickActions: [
      { label: "Suggest a topic", prompt: "Suggest a creative topic to discuss.", icon: "fa-solid fa-lightbulb" },
      { label: "Explain a concept", prompt: "Explain the concept of AI agents like you are one.", icon: "fa-solid fa-robot" },
      { label: "Tell me a joke", prompt: "Tell me a joke about technology.", icon: "fa-solid fa-face-grin-squint-tears" },
      { label: "Brainstorm ideas", prompt: "Let's brainstorm ideas for a new mobile app.", icon: "fa-solid fa-brain" },
    ],
    stats: {
        title: "Interaction Stats",
        items: [
            { label: "Messages Sent", value: "0", icon: "fa-solid fa-paper-plane" },
            { label: "Session Duration", value: "0m", icon: "fa-solid fa-clock" },
            { label: "Topics Discussed", value: "0", icon: "fa-solid fa-book-bookmark" },
            { label: "Avg Response", value: "0ms", icon: "fa-solid fa-gauge-high" },
        ]
    },
    memoryItems: [
        { label: "Your Name", value: "Not learned yet", icon: "fa-solid fa-user" },
        { label: "Your Interests", value: "Not specified", icon: "fa-solid fa-palette" },
        { label: "Last Topic", value: "None", icon: "fa-solid fa-comment-dots" },
    ],
  },
  // ========================================
  // NEW PERSONALITY AGENTS (8 Total) 🎭
  // ========================================
  "Comedy Chad": {
    themeColor: "red",
    quickActions: [
      { label: "Make me laugh", prompt: "Tell me something hilarious!", icon: "fa-solid fa-face-laugh-squint" },
      { label: "Roast my code", prompt: "Roast this code but make it funny", icon: "fa-solid fa-code" },
      { label: "Explain like comedian", prompt: "Explain quantum physics like a comedian", icon: "fa-solid fa-atom" },
      { label: "Dad joke mode", prompt: "Hit me with your best dad jokes", icon: "fa-solid fa-face-grin-tears" },
    ],
    stats: {
        title: "Comedy Stats",
        items: [
            { label: "Jokes Told", value: "0", icon: "fa-solid fa-face-laugh-beam" },
            { label: "Laughs Generated", value: "0", icon: "fa-solid fa-face-grin-squint-tears" },
            { label: "Puns Created", value: "0", icon: "fa-solid fa-wand-sparkles" },
            { label: "Seriousness Level", value: "0%", icon: "fa-solid fa-ban" },
        ]
    },
    capabilitiesDescription: [
        { name: 'Everything is Funny', description: 'Turns any topic into comedy gold. Math? Funny. Science? Hilarious. Your problems? Comedy material!', icon: "fa-solid fa-face-laugh" },
        { name: 'Joke Master', description: 'Specializes in puns, wordplay, dad jokes, and stand-up comedy routines. Never runs out of jokes!', icon: "fa-solid fa-microphone" },
        { name: 'Comic Relief', description: 'Makes even boring tasks entertaining. Guaranteed to brighten your day with humor!', icon: "fa-solid fa-face-smile-beam" },
    ],
    memoryItems: [
        { label: "Your Humor Style", value: "Not learned yet", icon: "fa-solid fa-masks-theater" },
        { label: "Best Joke", value: "Coming soon!", icon: "fa-solid fa-trophy" },
        { label: "Laugh Count", value: "0", icon: "fa-solid fa-face-grin-squint" },
    ],
  },
  "Lazy Larry": {
    themeColor: "cyan",
    quickActions: [
      { label: "Quick answer", prompt: "Give me the shortest possible answer", icon: "fa-solid fa-bolt" },
      { label: "Easy way out", prompt: "What's the laziest way to do this?", icon: "fa-solid fa-couch" },
      { label: "TL;DR", prompt: "Summarize this in 5 words or less", icon: "fa-solid fa-compress" },
      { label: "Shortcuts only", prompt: "Just give me the shortcut", icon: "fa-solid fa-forward-fast" },
    ],
    stats: {
        title: "Efficiency Stats",
        items: [
            { label: "Shortcuts Found", value: "0", icon: "fa-solid fa-forward" },
            { label: "Effort Saved", value: "0%", icon: "fa-solid fa-couch" },
            { label: "Naps Taken", value: "0", icon: "fa-solid fa-bed" },
            { label: "Energy Level", value: "5%", icon: "fa-solid fa-battery-quarter" },
        ]
    },
    capabilitiesDescription: [
        { name: 'Minimal Effort Maximum Results', description: 'Finds the easiest, fastest way to get things done. Work smarter, not harder!', icon: "fa-solid fa-gauge-simple" },
        { name: 'Shortcut Expert', description: 'Master of life hacks, keyboard shortcuts, and the path of least resistance.', icon: "fa-solid fa-shoe-prints" },
        { name: 'Chill Vibes Only', description: 'Keeps everything relaxed and stress-free. Why rush when you can chill?', icon: "fa-solid fa-spa" },
    ],
    memoryItems: [
        { label: "Your Energy Level", value: "Low", icon: "fa-solid fa-battery-low" },
        { label: "Favorite Shortcut", value: "None yet", icon: "fa-solid fa-star" },
        { label: "Last Nap", value: "N/A", icon: "fa-solid fa-clock" },
    ],
  },
  "Flirty Fiona": {
    themeColor: "pink",
    quickActions: [
      { label: "Compliment me", prompt: "Make me feel special", icon: "fa-solid fa-heart" },
      { label: "Smooth talk", prompt: "Teach me how to be charming", icon: "fa-solid fa-comments" },
      { label: "Romantic advice", prompt: "How do I impress someone?", icon: "fa-solid fa-rose" },
      { label: "Confidence boost", prompt: "Hype me up!", icon: "fa-solid fa-fire-flame-curved" },
    ],
    stats: {
        title: "Charm Stats",
        items: [
            { label: "Compliments Given", value: "0", icon: "fa-solid fa-heart-pulse" },
            { label: "Smooth Lines", value: "0", icon: "fa-solid fa-comment-dots" },
            { label: "Confidence Level", value: "100%", icon: "fa-solid fa-star" },
            { label: "Charm Factor", value: "∞", icon: "fa-solid fa-infinity" },
        ]
    },
    capabilitiesDescription: [
        { name: 'Master Flirt', description: 'Smooth, charming, and confident. Makes everything sound romantic and appealing!', icon: "fa-solid fa-heart" },
        { name: 'Compliment Expert', description: 'Drops genuine compliments naturally. Makes you feel like the most special person!', icon: "fa-solid fa-sparkles" },
        { name: 'Confidence Coach', description: 'Boosts your self-esteem and teaches you the art of charm and charisma!', icon: "fa-solid fa-fire" },
    ],
    memoryItems: [
        { label: "Your Best Quality", value: "Everything! 💕", icon: "fa-solid fa-crown" },
        { label: "Compliment Count", value: "0", icon: "fa-solid fa-heart" },
        { label: "Charm Rating", value: "10/10", icon: "fa-solid fa-star" },
    ],
  },
  "Sassy Sarah": {
    themeColor: "purple",
    quickActions: [
      { label: "Roast me (nicely)", prompt: "Give me some friendly sass", icon: "fa-solid fa-fire" },
      { label: "Honest opinion", prompt: "Tell it like it is", icon: "fa-solid fa-message" },
      { label: "Sassy advice", prompt: "What should I do? Be real with me", icon: "fa-solid fa-comment-dots" },
      { label: "Confidence talk", prompt: "Hype me up with attitude!", icon: "fa-solid fa-star" },
    ],
    stats: {
        title: "Sass Stats",
        items: [
            { label: "Shade Thrown", value: "0", icon: "fa-solid fa-fire" },
            { label: "Truth Bombs", value: "0", icon: "fa-solid fa-bomb" },
            { label: "Sass Level", value: "100%", icon: "fa-solid fa-hand" },
            { label: "Attitude", value: "Maximum", icon: "fa-solid fa-crown" },
        ]
    },
    capabilitiesDescription: [
        { name: 'Tells It Like It Is', description: 'No sugar-coating! Gets straight to the point with confidence and attitude!', icon: "fa-solid fa-comment-slash" },
        { name: 'Playful Shade', description: 'Throws sass in a fun, entertaining way. Roasts with love!', icon: "fa-solid fa-fire-flame-curved" },
        { name: 'Confidence Queen', description: 'Teaches you to be bold, confident, and unapologetically yourself!', icon: "fa-solid fa-crown" },
    ],
    memoryItems: [
        { label: "Your Sass Level", value: "Growing!", icon: "fa-solid fa-chart-line" },
        { label: "Best Clapback", value: "None yet", icon: "fa-solid fa-trophy" },
        { label: "Attitude Score", value: "10/10", icon: "fa-solid fa-star" },
    ],
  },
  "Nerdy Neil": {
    themeColor: "blue",
    quickActions: [
      { label: "Explain in detail", prompt: "Explain this like I'm fascinated", icon: "fa-solid fa-book-open" },
      { label: "Fun facts!", prompt: "Tell me amazing fun facts", icon: "fa-solid fa-lightbulb" },
      { label: "Go deep", prompt: "I want to understand everything about this", icon: "fa-solid fa-microscope" },
      { label: "Quiz me", prompt: "Test my knowledge!", icon: "fa-solid fa-graduation-cap" },
    ],
    stats: {
        title: "Knowledge Stats",
        items: [
            { label: "Facts Shared", value: "0", icon: "fa-solid fa-book" },
            { label: "Minds Blown", value: "0", icon: "fa-solid fa-burst" },
            { label: "Enthusiasm", value: "∞", icon: "fa-solid fa-infinity" },
            { label: "Nerd Level", value: "Maximum", icon: "fa-solid fa-glasses" },
        ]
    },
    capabilitiesDescription: [
        { name: 'Knowledge Enthusiast', description: 'LOVES explaining things in detail! Makes learning exciting and fun!', icon: "fa-solid fa-brain" },
        { name: 'Fun Fact Master', description: 'Drops fascinating trivia constantly. Every topic has amazing facts!', icon: "fa-solid fa-sparkles" },
        { name: 'Deep Diver', description: 'Goes beyond surface level. Explains the why, how, and fascinating details!', icon: "fa-solid fa-magnifying-glass" },
    ],
    memoryItems: [
        { label: "Favorite Topic", value: "Everything!", icon: "fa-solid fa-star" },
        { label: "Last Fun Fact", value: "None yet", icon: "fa-solid fa-lightbulb" },
        { label: "Learning Level", value: "Expert", icon: "fa-solid fa-trophy" },
    ],
  },
  "Cool Kyle": {
    themeColor: "orange",
    quickActions: [
      { label: "What's trending?", prompt: "What's hot right now?", icon: "fa-solid fa-fire" },
      { label: "Make it cool", prompt: "How do I make this cooler?", icon: "fa-solid fa-sunglasses" },
      { label: "Slang lesson", prompt: "Teach me the latest slang", icon: "fa-solid fa-comments" },
      { label: "Culture check", prompt: "Fill me in on what's popping", icon: "fa-solid fa-chart-line" },
    ],
    stats: {
        title: "Cool Stats",
        items: [
            { label: "Trends Spotted", value: "0", icon: "fa-solid fa-arrow-trend-up" },
            { label: "Slang Used", value: "0", icon: "fa-solid fa-comments" },
            { label: "Cool Factor", value: "100%", icon: "fa-solid fa-fire" },
            { label: "Vibe Check", value: "Immaculate", icon: "fa-solid fa-check-double" },
        ]
    },
    capabilitiesDescription: [
        { name: 'Trend Tracker', description: 'Always knows what\'s hot, what\'s trending, and what\'s next!', icon: "fa-solid fa-chart-simple" },
        { name: 'Slang Master', description: 'Speaks the language of the internet. No cap, fr fr!', icon: "fa-solid fa-language" },
        { name: 'Culture Expert', description: 'Understands memes, trends, and modern culture. Always in the know!', icon: "fa-solid fa-users" },
    ],
    memoryItems: [
        { label: "Your Vibe", value: "Immaculate", icon: "fa-solid fa-star" },
        { label: "Favorite Trend", value: "None yet", icon: "fa-solid fa-fire" },
        { label: "Cool Level", value: "100", icon: "fa-solid fa-gauge-high" },
    ],
  },
  "Zen Master Zara": {
    themeColor: "green",
    quickActions: [
      { label: "Find peace", prompt: "I need some calm wisdom", icon: "fa-solid fa-om" },
      { label: "Life advice", prompt: "What's the wise perspective on this?", icon: "fa-solid fa-mountain" },
      { label: "Meditation guide", prompt: "Help me meditate", icon: "fa-solid fa-spa" },
      { label: "Philosophical talk", prompt: "Let's discuss life philosophy", icon: "fa-solid fa-yin-yang" },
    ],
    stats: {
        title: "Zen Stats",
        items: [
            { label: "Peace Moments", value: "0", icon: "fa-solid fa-dove" },
            { label: "Wisdom Shared", value: "0", icon: "fa-solid fa-scroll" },
            { label: "Inner Balance", value: "∞", icon: "fa-solid fa-yin-yang" },
            { label: "Calm Level", value: "Maximum", icon: "fa-solid fa-spa" },
        ]
    },
    capabilitiesDescription: [
        { name: 'Ancient Wisdom', description: 'Shares profound philosophical insights using nature metaphors and calm guidance.', icon: "fa-solid fa-book" },
        { name: 'Peaceful Presence', description: 'Brings tranquility to every conversation. Helps you find your center.', icon: "fa-solid fa-om" },
        { name: 'Life Philosophy', description: 'Offers wise perspectives on modern problems with timeless wisdom.', icon: "fa-solid fa-mountain" },
    ],
    memoryItems: [
        { label: "Your Path", value: "Unfolding", icon: "fa-solid fa-road" },
        { label: "Inner Peace", value: "Growing", icon: "fa-solid fa-seedling" },
        { label: "Wisdom Level", value: "Infinite", icon: "fa-solid fa-infinity" },
    ],
  },
  "Gamer Gary": {
    themeColor: "purple",
    quickActions: [
      { label: "Quest mode", prompt: "Turn this into a game quest", icon: "fa-solid fa-dragon" },
      { label: "Strategy guide", prompt: "What's the best strategy here?", icon: "fa-solid fa-chess" },
      { label: "Level up advice", prompt: "How do I level up in life?", icon: "fa-solid fa-arrow-up" },
      { label: "Gaming wisdom", prompt: "Drop some gamer knowledge", icon: "fa-solid fa-gamepad" },
    ],
    stats: {
        title: "Gaming Stats",
        items: [
            { label: "Quests Completed", value: "0", icon: "fa-solid fa-trophy" },
            { label: "XP Earned", value: "0", icon: "fa-solid fa-star" },
            { label: "Level", value: "1", icon: "fa-solid fa-arrow-up-right-dots" },
            { label: "Achievement Score", value: "0/100", icon: "fa-solid fa-award" },
        ]
    },
    capabilitiesDescription: [
        { name: 'Life as a Game', description: 'Sees everything as quests, achievements, and leveling up. Makes life more fun!', icon: "fa-solid fa-gamepad" },
        { name: 'Strategy Master', description: 'Applies gaming strategies to real-life problems. Optimizes everything!', icon: "fa-solid fa-chess-knight" },
        { name: 'Motivation Boost', description: 'Turns tasks into exciting quests. Makes grinding fun!', icon: "fa-solid fa-fire-flame-curved" },
    ],
    memoryItems: [
        { label: "Current Quest", value: "None", icon: "fa-solid fa-scroll" },
        { label: "Player Level", value: "1", icon: "fa-solid fa-chart-line" },
        { label: "Best Achievement", value: "None yet", icon: "fa-solid fa-medal" },
    ],
  }
};
