/**
 * YouGen - Type Definitions
 */

export type ContentStyle = 
  | 'educational' | 'entertaining' | 'inspirational' 
  | 'documentary' | 'vlog' | 'tutorial' | 'review' 
  | 'comedy' | 'dramatic' | 'minimalist';

export type ContentFormat = 'long-form' | 'mid-form' | 'short-form' | 'micro-content';
export type ToneType = 'professional' | 'casual' | 'humorous' | 'serious' | 'inspirational' | 'engaging';

export interface ContentIdea {
  title: string;
  description: string;
  targetAudience: string;
  estimatedLength: number; // In minutes
  style: ContentStyle;
  viralPotential: number; // 0-100
  uniquenessScore: number; // 0-100
  keywords: string[];
}

export interface ScriptSection {
  type: 'intro' | 'main' | 'outro' | 'transition' | 'call-to-action';
  content: string;
  duration: number; // Seconds
  visualSuggestions: string[];
  notes?: string;
}

export interface VideoScript {
  title: string;
  hook: string;
  sections: ScriptSection[];
  totalDuration: number; // Seconds
  tone: ToneType;
  targetAudience: string;
  callToAction: string;
}

export interface Storyboard {
  sceneNumber: number;
  description: string;
  dialogue?: string;
  visualElements: string[];
  cameraAngle: string;
  duration: number; // Seconds
  transitions?: string;
  soundEffects?: string[];
  music?: string;
}

export interface ThumbnailConcept {
  description: string;
  elements: string[];
  colorScheme: string[];
  text?: string;
  style: string;
  clickworthinessScore: number; // 0-100
}

export interface SEOOptimization {
  primaryKeyword: string;
  secondaryKeywords: string[];
  optimizedTitle: string;
  optimizedDescription: string;
  tags: string[];
  targetSearchVolume: number;
  competitionLevel: 'low' | 'medium' | 'high';
}

export interface SeriesPlanning {
  seriesTitle: string;
  episodeCount: number;
  episodes: Array<{
    episodeNumber: number;
    title: string;
    synopsis: string;
    keyPoints: string[];
  }>;
  overarchingTheme: string;
  continuityElements: string[];
}

export interface MusicSuggestion {
  genre: string;
  mood: string;
  tempo: 'slow' | 'medium' | 'fast';
  licensingInfo: string;
  similarArtists?: string[];
}

export interface YouGenResponse {
  ideas: ContentIdea[];
  script?: VideoScript;
  storyboard?: Storyboard[];
  thumbnailConcepts: ThumbnailConcept[];
  seo: SEOOptimization;
  musicSuggestions?: MusicSuggestion[];
  improvements: string[];
  nextSteps: string[];
}

export interface BrainstormingSession {
  topic: string;
  rawIdeas: string[];
  refinedIdeas: ContentIdea[];
  topPicks: ContentIdea[];
  reasoning: string[];
}
