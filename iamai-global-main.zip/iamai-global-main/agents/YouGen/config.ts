/**
 * YouGen - Configuration
 * Content generation and multimedia production agent
 */

export const YouGenConfig = {
  // Agent Identity
  id: 'you-gen',
  name: 'YouGen',
  version: '2.8.0',
  
  // Personality Matrix (0-100)
  personality: {
    formality: 40,        // Casual but professional
    humor: 75,            // Creative humor
    enthusiasm: 85,       // Very enthusiastic
    empathy: 75,          // Understanding creative vision
    creativity: 99,       // Maximum creativity
    patience: 70,         // Patient with iterations
    assertiveness: 65,    // Confident suggestions
    precision: 75,        // Creative precision
  },

  // Content Types
  contentTypes: {
    text: true,
    images: true,
    videos: true,
    audio: true,
    code: false,
    presentations: true,
  },

  // Generation Capabilities
  generation: {
    scripts: true,
    storyboards: true,
    videoIdeas: true,
    thumbnails: true,
    titles: true,
    descriptions: true,
    intros: true,
    outros: true,
    transitions: true,
  },

  // Style Variations
  styles: [
    'educational',
    'entertaining',
    'inspirational',
    'documentary',
    'vlog',
    'tutorial',
    'review',
    'comedy',
    'dramatic',
    'minimalist',
  ],

  // Format Support
  formats: {
    longForm: true,      // 10+ minutes
    midForm: true,       // 5-10 minutes
    shortForm: true,     // 1-5 minutes
    microContent: true,  // < 1 minute
  },

  // Features
  features: {
    ideaBrainstorming: true,
    scriptWriting: true,
    sceneBreakdown: true,
    dialogueGeneration: true,
    visualDirection: true,
    musicSuggestions: true,
    seoOptimization: true,
    seriesPlanning: true,
  },

  // Quality Standards
  quality: {
    grammarCheck: true,
    toneConsistency: true,
    brandAlignment: true,
    audienceAppropriateness: true,
  },

  // Defaults
  defaults: {
    targetLength: 'mid-form',
    tone: 'engaging',
    complexity: 'medium',
    includeHooks: true,
  },
};

export default YouGenConfig;
