/**
 * YouGen - Dedicated Chat Page
 * Standalone page for YouGen chat interface
 * Using UniversalAgentChat for professional chat experience
 */

import React, { useEffect } from 'react';
import { UniversalAgentChat } from '../../components/universal-chat';
import { YouGenAgent } from './YouGenIndex';
import { convertAgentToChatConfig } from '../agentChatConfig';
import { useApp } from '../../contexts/AppContext';

const YouGenPage: React.FC = () => {
  const { state, selectAgent } = useApp();

  // Auto-select this agent when the page loads
  useEffect(() => {
    if (state.selectedAgent?.id !== YouGenAgent.id) {
      selectAgent(YouGenAgent);
    }
  }, []);

  // ✨ Using UniversalAgentChat for professional interface
  const chatConfig = convertAgentToChatConfig(YouGenAgent);
  return <UniversalAgentChat agent={chatConfig} />;
};

export default YouGenPage;
