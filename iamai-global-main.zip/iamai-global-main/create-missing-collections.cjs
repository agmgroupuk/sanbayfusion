const mongoose = require('./backend/node_modules/mongoose');
require('dotenv').config({ path: './backend/.env' });

// Import all model definitions
const models = require('./backend/models.cjs');
const contentModels = require('./backend/content-models.js');

async function createMissingCollections() {
  try {
    await mongoose.connect(process.env.MONGODB_URI);
    const db = mongoose.connection.db;

    console.log('🔍 Checking existing collections...');
    const existingCollections = await db.listCollections().toArray();
    const existingNames = existingCollections.map(col => col.name);

    console.log(`Found ${existingCollections.length} existing collections`);

    // Define all models that should have collections
    const allModels = {
      // From models.cjs
      ...models,
      // From content-models.js
      ...contentModels
    };

    const modelsToCreate = [];
    const modelsAlreadyExist = [];

    // Check each model
    for (const [modelName, model] of Object.entries(allModels)) {
      if (typeof model === 'function' && model.modelName) {
        const collectionName = model.collection.name || model.collection.collectionName;

        if (existingNames.includes(collectionName)) {
          modelsAlreadyExist.push(`${modelName} (${collectionName})`);
        } else {
          modelsToCreate.push({ name: modelName, model, collectionName });
        }
      }
    }

    console.log(`\n✅ Collections that already exist (${modelsAlreadyExist.length}):`);
    modelsAlreadyExist.forEach(name => console.log(`  - ${name}`));

    console.log(`\n⚠️  Collections to create (${modelsToCreate.length}):`);
    modelsToCreate.forEach(({ name, collectionName }) => console.log(`  - ${name} (${collectionName})`));

    // Create missing collections
    if (modelsToCreate.length > 0) {
      console.log('\n🔨 Creating missing collections...');

      for (const { name, model, collectionName } of modelsToCreate) {
        try {
          // Create collection by inserting a dummy document and removing it
          // This ensures the collection is created with proper schema validation
          const tempDoc = new model({});
          await tempDoc.validate(); // Validate against schema

          // Actually create the collection by ensuring indexes
          await model.createCollection();

          console.log(`  ✅ Created collection: ${collectionName} for model: ${name}`);
        } catch (error) {
          console.log(`  ❌ Failed to create ${collectionName}: ${error.message}`);
        }
      }
    }

    // Verify final state
    console.log('\n🔍 Final collection verification:');
    const finalCollections = await db.listCollections().toArray();
    console.log(`Total collections: ${finalCollections.length}`);

    finalCollections.forEach(col => {
      console.log(`  - ${col.name}`);
    });

    await mongoose.disconnect();
    console.log('\n✅ Collection creation process complete!');

  } catch (error) {
    console.error('❌ Error:', error.message);
    process.exit(1);
  }
}

createMissingCollections();