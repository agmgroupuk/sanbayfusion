import React, { useState, useEffect, lazy, Suspense, useCallback } from 'react';
import HomePage from './components/HomePage.tsx';
import LoginPage from './components/LoginPage';
import SignupPage from './components/SignupPage';
import { Dashboard } from './components/user';
import SubscriptionPage from './components/SubscriptionPage';
import SplashScreen from './components/SplashScreen';
import SettingsModal from './components/user/dashboard/SettingsModal';
import FooterSubscription from './components/FooterSubscription';
import { ALL_AGENTS } from './agents';
import { convertAgentToChatConfig } from './agents/agentChatConfig';
import { Agent, BlogPost, SubscriptionPlanSlug } from './constants';
import { AppProvider, useApp } from './contexts/AppContext';
import { DashboardProvider } from './contexts/DashboardContext';
import { ThemeProvider } from './contexts/ThemeContext.tsx';
import { initSessionTracking } from './utils/sessionTracking';
// import StorageMigrationUtil from './utils/storageMigration';
import appStorage from './services/appStorage';
import { authService } from './services/authService';
import { useAuth } from './contexts/AuthContext';
import ToastContainer from './components/ToastContainer';
import { notificationService } from './services/notificationService';
import { getApiUrl } from './config/api';

// ============ CODE SPLITTING - LAZY LOAD COMPONENTS ============
// Agent Pages - Lazy loaded for better performance
const AIGirlfriendPage = lazy(() => import('./agents/AIGirlfriend/AIGirlfriendPage'));
const AgentXPage = lazy(() => import('./agents/AgentX/AgentXPage'));
const AutoChatPage = lazy(() => import('./agents/AutoChat/AutoChatPage'));
const CVSmashPage = lazy(() => import('./agents/CVSmash/CVSmashPage'));
const EmoAIPage = lazy(() => import('./agents/EmoAI/EmoAIPage'));
const ChatRevivePage = lazy(() => import('./agents/ChatRevive/ChatRevivePage'));
const PDFMindPage = lazy(() => import('./agents/PDFMind/PDFMindPage'));
const TokBoostPage = lazy(() => import('./agents/TokBoost/TokBoostPage'));
const YouGenPage = lazy(() => import('./agents/YouGen/YouGenPage'));
const ComedyChadPage = lazy(() => import('./agents/ComedyChad/ComedyChadPage'));
const LazyLarryPage = lazy(() => import('./agents/LazyLarry/LazyLarryPage'));
const FlirtyFionaPage = lazy(() => import('./agents/FlirtyFiona/FlirtyFionaPage'));
const SassySarahPage = lazy(() => import('./agents/SassySarah/SassySarahPage'));
const NerdyNeilPage = lazy(() => import('./agents/NerdyNeil/NerdyNeilPage'));
const CoolKylePage = lazy(() => import('./agents/CoolKyle/CoolKylePage'));
const ZenMasterZaraPage = lazy(() => import('./agents/ZenMasterZara/ZenMasterZaraPage'));
const GamerGaryPage = lazy(() => import('./agents/GamerGary/GamerGaryPage'));

// UniversalChat System - New professional chatbox
const UniversalAgentChat = lazy(() =>
  import('./components/universal-chat').then(m => ({ default: m.UniversalAgentChat }))
);

// Pages - Lazy loaded
const AboutPage = lazy(() => import('./components/pages/AboutPage'));
const FeaturesPage = lazy(() => import('./components/pages/FeaturesPage'));
const PricingPage = lazy(() => import('./components/pages/PricingPage'));
const BlogPage = lazy(() => import('./components/pages/BlogPage'));
const BlogPostViewer = lazy(() => import('./components/pages/BlogPostViewer'));
const FAQPage = lazy(() => import('./components/pages/FAQPage'));
const DocumentationPage = lazy(() => import('./components/pages/DocumentationPage'));
const ContactUsPage = lazy(() => import('./components/pages/ContactUsPage'));
const CareersPage = lazy(() => import('./components/pages/CareersPage'));
const CareerApplicationPage = lazy(() => import('./components/pages/CareerApplicationPage'));
const CommunityPage = lazy(() => import('./components/pages/CommunityPage'));
const ForumsPage = lazy(() => import('./components/pages/ForumsPage'));
const DevelopersPage = lazy(() => import('./components/pages/DevelopersPage'));
const BusinessPage = lazy(() => import('./components/pages/BusinessPage'));
const EducationPage = lazy(() => import('./components/pages/EducationPage'));
const AIStudioPage = lazy(() => import('./components/pages/AIStudioPage'));
const TemplatesPage = lazy(() => import('./components/pages/TemplatesPage'));
const TemplateDetailPage = lazy(() => import('./components/pages/TemplateDetailPage'));
const SolutionsPage = lazy(() => import('./components/pages/SolutionsPage'));
const SecurityPage = lazy(() => import('./components/pages/SecurityPage'));
const PrivacyPolicyPage = lazy(() => import('./components/pages/PrivacyPolicyPage'));
const TermsConditionsPage = lazy(() => import('./components/pages/TermsConditionsPage'));
const CinematicPage = lazy(() => import('./components/pages/CinematicPage'));
const CreatorToolsPage = lazy(() => import('./components/pages/CreatorToolsPage'));
const DataDashboardPage = lazy(() => import('./components/pages/DataDashboardPage'));
const APIAnalyticsDashboard = lazy(() => import('./components/pages/APIAnalyticsDashboard'));
const ReportsPage = lazy(() => import('./components/pages/ReportsPage'));
const SearchPage = lazy(() => import('./components/pages/SearchPage'));
const SupportPage = lazy(() => import('./components/pages/SupportPage'));
const LiveSupportPage = lazy(() => import('./components/pages/LiveSupportPage'));
const ToolboxPage = lazy(() => import('./components/pages/ToolboxPage'));
const RealtimeToolboxPage = lazy(() => import('./components/pages/RealtimeToolboxPage'));
const NewsPage = lazy(() => import('./components/pages/NewsPage'));
const UpdatesPage = lazy(() => import('./components/pages/UpdatesPage'));
const UpcomingModulesPage = lazy(() => import('./components/pages/UpcomingModulesPage'));
const TaskManagerPage = lazy(() => import('./components/pages/TaskManagerPage'));
const TutorialsPage = lazy(() => import('./components/pages/TutorialsPage'));
const IPInfoPage = lazy(() => import('./components/pages/IPInfoPage'));
const APITesterPage = lazy(() => import('./components/pages/APITesterPage'));
const DNSLookupPage = lazy(() => import('./components/pages/DNSLookupPage'));
const WhoisLookupPage = lazy(() => import('./components/pages/WhoisLookupPage'));
const PingTestPage = lazy(() => import('./components/pages/PingTestPage'));
const PortScannerPage = lazy(() => import('./components/pages/PortScannerPage'));
const SSLCheckerPage = lazy(() => import('./components/pages/SSLCheckerPage'));
const URLEncoderPage = lazy(() => import('./components/pages/URLEncoderPage'));
const HeaderCheckerPage = lazy(() => import('./components/pages/HeaderCheckerPage'));
const UptimeMonitorPage = lazy(() => import('./components/pages/UptimeMonitorPage'));
const StatusPage = lazy(() => import('./components/pages/StatusPage'));
const AnalyticsPage = lazy(() => import('./components/pages/AnalyticsPage'));
const APIStatusPage = lazy(() => import('./components/pages/APIStatusPage'));
const ForgotPasswordPage = lazy(() => import('./components/pages/ForgotPasswordPage'));
const SetNewPasswordPage = lazy(() => import('./components/pages/SetNewPasswordPage'));
const PartnersPage = lazy(() => import('./components/pages/PartnersPage'));
const SuggestionsPage = lazy(() => import('./components/pages/SuggestionsPage'));
const SupportTicketPage = lazy(() => import('./components/pages/SupportTicketPage'));
const AgentsPage = lazy(() => import('./components/pages/AgentsPage'));
const GDPRPage = lazy(() => import('./components/pages/GDPRPage'));
const CookiesPage = lazy(() => import('./components/pages/CookiesPage'));
const PaymentRefundPage = lazy(() => import('./components/pages/PaymentRefundPage'));
const DomainResearchSuitePage = lazy(() => import('./components/pages/DomainResearchSuitePage'));
const ScreenshotAPIPage = lazy(() => import('./components/pages/ScreenshotAPIPage'));
const EmailVerificationPage = lazy(() => import('./components/pages/EmailVerificationPage'));
const IPNetblocksPage = lazy(() => import('./components/pages/IPNetblocksPage'));
const DomainReputationPage = lazy(() => import('./components/pages/DomainReputationPage'));
const WebsiteCategorizationPage = lazy(
  () => import('./components/pages/WebsiteCategorizationPage')
);
const DomainAvailabilityPage = lazy(() => import('./components/pages/DomainAvailabilityPage'));
const MACAddressPage = lazy(() => import('./components/pages/MACAddressPage'));
const ThreatIntelligencePage = lazy(() => import('./components/pages/ThreatIntelligencePage'));
const RewardCenterPage = lazy(() => import('./components/pages/RewardCenterPage'));
const SubscribePage = lazy(() => import('./components/pages/SubscribePage'));
const ThankYouPage = lazy(() => import('./components/pages/ThankYouPage'));
const DatabasePopulatePage = lazy(() => import('./components/pages/DatabasePopulatePage'));

// AI Lab Pages - Lazy loaded
import {
  AILabHubPage,
  AILabPlaygroundPage,
  AILabPromptPage,
  AILabBattlePage,
  AILabTransformersPage,
  AILabCodePlaygroundPage,
  AILabSentimentAnalyzerPage,
  AILabCostCalculatorPage,
  AILabLatencyPage,
  AILabHistoryPage,
  AILabResearchPage,
  AILabSettingsPage,
  AILabTemplatesPage,
} from './components/lab';

// Canvas App Page - Lazy loaded
const CanvasAppPage = lazy(() => import('./canvas-app').then(m => ({ default: m.default })));

// Loading component for lazy-loaded routes
const PageLoader = () => (
  <div className="flex items-center justify-center min-h-screen">
    <div className="flex flex-col items-center gap-4">
      <div className="w-12 h-12 border-4 border-cyan-500 border-t-transparent rounded-full animate-spin"></div>
      <p className="text-gray-400">Loading...</p>
    </div>
  </div>
);

export type Page =
  | 'home'
  | 'login'
  | 'signup'
  | 'auth-verify'
  | 'dashboard'
  | 'subscription'
  | 'subscribe'
  | 'thank-you'
  | 'about'
  | 'features'
  | 'pricing'
  | 'blog'
  | 'blogPost'
  | 'faq'
  | 'documentation'
  | 'contact'
  | 'careers'
  | 'career-application'
  | 'community'
  | 'forums'
  | 'developers'
  | 'business'
  | 'education'
  | 'canvas-app'
  | 'ai-lab'
  | 'ai-lab-playground'
  | 'ai-lab-prompt'
  | 'ai-lab-battle'
  | 'ai-lab-transformers'
  | 'ai-lab-code'
  | 'ai-lab-sentiment'
  | 'ai-lab-cost'
  | 'ai-lab-latency'
  | 'ai-lab-benchmark'
  | 'ai-lab-history'
  | 'ai-lab-research'
  | 'ai-lab-settings'
  | 'ai-lab-templates'
  | 'ai-studio'
  | 'reward-center'
  | 'templates'
  | 'template-customer-support-bot'
  | 'template-onboarding-assistant'
  | 'template-sales-development-rep'
  | 'template-content-summarizer'
  | 'template-llama-3-local'
  | 'template-mistral-local'
  | 'template-phi-3-local'
  | 'template-gemma-local'
  | 'template-codellama-local'
  | 'template-neural-chat-local'
  | 'template-vicuna-local'
  | 'template-orca-mini-local'
  | 'solutions'
  | 'security'
  | 'privacy'
  | 'terms'
  | 'cinematic'
  | 'creator-tools'
  | 'data-dashboard'
  | 'api-analytics'
  | 'reports'
  | 'search'
  | 'support'
  | 'live-support'
  | 'toolbox'
  | 'news'
  | 'updates'
  | 'upcoming-modules'
  | 'reset-password'
  | 'forgot-password'
  | 'set-new-password'
  | 'task-manager'
  | 'tutorials'
  | 'ip-info'
  | 'dns-lookup'
  | 'whois'
  | 'ping-test'
  | 'port-scanner'
  | 'ssl-checker'
  | 'url-encoder'
  | 'header-checker'
  | 'uptime-monitor'
  | 'api-tester'
  | 'domain-research-suite'
  | 'screenshot-api'
  | 'email-verification'
  | 'ip-netblocks'
  | 'domain-reputation'
  | 'website-categorization'
  | 'domain-availability'
  | 'mac-address'
  | 'threat-intelligence'
  | 'status'
  | 'status-analytics'
  | 'status-api-status'
  | 'analytics'
  | 'api-status'
  | 'partners'
  | 'suggestions'
  | 'support-ticket'
  | 'my-account'
  | 'agent-chat'
  | 'agents'
  | 'ai-girlfriend'
  | 'emo-ai'
  | 'pdf-mind'
  | 'chat-revive'
  | 'tok-boost'
  | 'you-gen'
  | 'agent-x'
  | 'auto-chat'
  | 'cv-smash'
  | 'comedian'
  | 'lazy'
  | 'flirt'
  | 'sassy'
  | 'nerd'
  | 'cool'
  | 'zen'
  | 'gamer'
  | 'gdpr'
  | 'cookies'
  | 'payment-refund'
  | 'database-populate';

// Shared list of agent chat page slugs (kebab-case ids)
const AGENT_PAGES: Page[] = [
  'ai-girlfriend',
  'emo-ai',
  'pdf-mind',
  'chat-revive',
  'tok-boost',
  'you-gen',
  'agent-x',
  'auto-chat',
  'cv-smash',
  'comedian',
  'lazy',
  'flirt',
  'sassy',
  'nerd',
  'cool',
  'zen',
  'gamer',
];

export type Theme = 'light' | 'dark';

export interface AgentSubscriptionRecord {
  id: string;
  agentId: string;
  plan: string;
  status: string;
  pricing?: {
    amount?: number;
    interval?: string;
  };
  usage?: {
    current?: number;
    limit?: number;
    messagesCount?: number;
    conversationCount?: number;
  };
  billing?: {
    startDate?: string;
    currentPeriodStart?: string;
    currentPeriodEnd?: string;
    nextBillingDate?: string;
    totalPaid?: number;
  };
  preferences?: {
    autoRenew?: boolean;
    notifications?: boolean;
    dataRetention?: string;
  };
  agentInfo?: {
    agentName?: string;
    agentDisplayName?: string;
    agentCategory?: string;
    subscribedAt?: string;
  };
  subscribedAt?: string;
}

export interface AppState {
  currentPage: Page;
  isLoggedIn: boolean;
  selectedAgent: Agent | null;
  agentForSubscription: Agent | null;
  pendingSubscriptionPlan: SubscriptionPlanSlug | null;
  theme: Theme;
  apiKeys: {
    gemini: string;
    openai: string;
    anthropic: string;
  };
  subscriptions: Record<string, string>;
  agents: Agent[];
  selectedBlogPost: BlogPost | null;
  isSettingsOpen: boolean;
  agentSubscriptions: AgentSubscriptionRecord[];
  agentSubscriptionsById: Record<string, AgentSubscriptionRecord>;
  currentUser: any | null;
}

// Utility function for converting Page keys back to URL paths
const pageToUrl = (page: Page): string => {
  if (page === 'home') return '';

  // Handle special page mappings
  if (page === 'subscription') return 'subscribe';
  if (page === 'subscribe') return 'subscribe';
  if (page === 'dashboard') return 'dashboard';
  if (page === 'login') return 'login';

  // Handle nested status routes
  if (page === 'status-analytics') return 'status/analytics';
  if (page === 'status-api-status') return 'status/api-status';

  // Handle nested AI Lab routes
  const aiLabPages = [
    'ai-lab-playground',
    'ai-lab-prompt',
    'ai-lab-battle',
    'ai-lab-transformers',
    'ai-lab-code',
    'ai-lab-sentiment',
    'ai-lab-cost',
    'ai-lab-latency',
    'ai-lab-benchmark',
    'ai-lab-history',
    'ai-lab-research',
    'ai-lab-settings',
    'ai-lab-templates',
  ] as Page[];

  if (aiLabPages.includes(page)) {
    return `ai-lab/${page}`;
  }

  // Handle nested toolbox routes
  const toolboxTools = [
    'dns-lookup',
    'whois',
    'ping-test',
    'port-scanner',
    'ssl-checker',
    'url-encoder',
    'header-checker',
    'uptime-monitor',
    'api-tester',
    'domain-research-suite',
    'screenshot-api',
    'email-verification',
    'ip-netblocks',
    'domain-reputation',
    'website-categorization',
    'domain-availability',
    'mac-address',
    'threat-intelligence',
    'ip-info',
  ] as Page[];

  if (toolboxTools.includes(page)) {
    return `toolbox/${page}`;
  }

  // Handle nested agent routes
  if (AGENT_PAGES.includes(page)) {
    return `agents/${page}/chat`;
  }

  // Default: convert camelCase Page keys to kebab-case URL segments
  return page.replace(/([a-z])([A-Z])/g, '$1-$2').toLowerCase();
};

const urlToPage = (url: string): Page => {
  if (!url || url === '/' || url === '/home') {
    return 'home';
  }

  const path = url.replace(/^\//, '');

  // Subscription and auth
  if (path === 'subscribe') {
    return 'subscribe';
  }

  if (path === 'login') {
    return 'login';
  }

  // Dashboard (including nested dashboard routes)
  if (path === 'dashboard' || path.startsWith('dashboard/')) {
    return 'dashboard';
  }

  // Status sub-routes
  if (path === 'status/analytics') {
    return 'status-analytics';
  }

  if (path === 'status/api-status') {
    return 'status-api-status';
  }

  // ✨ SPECIAL CASE: Handle nested AI Lab routes
  if (path.startsWith('ai-lab/')) {
    const labPath = path.replace('ai-lab/', '');
    const aiLabPages = [
      'ai-lab-playground',
      'ai-lab-prompt',
      'ai-lab-battle',
      'ai-lab-transformers',
      'ai-lab-code',
      'ai-lab-sentiment',
      'ai-lab-cost',
      'ai-lab-latency',
      'ai-lab-benchmark',
      'ai-lab-history',
      'ai-lab-research',
      'ai-lab-settings',
      'ai-lab-templates',
    ];
    if (aiLabPages.includes(labPath)) {
      return labPath as Page;
    }
  }

  // ✨ SPECIAL CASE: Handle nested toolbox routes
  if (path.startsWith('toolbox/')) {
    const toolPath = path.replace('toolbox/', '');
    const toolboxTools = [
      'dns-lookup',
      'whois',
      'ping-test',
      'port-scanner',
      'ssl-checker',
      'url-encoder',
      'header-checker',
      'uptime-monitor',
      'api-tester',
      'domain-research-suite',
      'screenshot-api',
      'email-verification',
      'ip-netblocks',
      'domain-reputation',
      'website-categorization',
      'domain-availability',
      'mac-address',
      'threat-intelligence',
      'ip-info',
    ];
    if (toolboxTools.includes(toolPath)) {
      return toolPath as Page;
    }
  }

  // ✨ SPECIAL CASE: Agent IDs are already in kebab-case in Page type
  if (AGENT_PAGES.includes(path as Page)) {
    return path as Page;
  }

  // ✨ SPECIAL CASE: Handle nested agent routes
  if (path.startsWith('agents/') && path.endsWith('/chat')) {
    const agentId = path.split('/')[2];
    return agentId as Page;
  }

  // ✨ SPECIAL CASE: Policy and info pages that should remain as-is (not converted to camelCase)
  const policyRoutes = [
    'gdpr',
    'cookies',
    'payment-refund',
    'thank-you',
    'partners',
    'privacy',
    'terms',
    'contact',
    'about',
    'careers',
    'community',
    'forums',
    'developers',
    'business',
    'education',
    'canvas-app',
    'templates',
    'solutions',
    'security',
    'cinematic',
    'reports',
    'search',
    'support',
    'toolbox',
    'news',
    'updates',
    'tutorials',
    'analytics',
    'suggestions',
    'agents',
    'pricing',
    'features',
    'blog',
    'faq',
    'documentation',
    'status',
    'ai-lab',
  ];

  // Gracefully handle deep links (e.g., /blog/my-post) by using the first segment instead of falling back to home
  if (path.includes('/')) {
    const [firstSegment] = path.split('/').filter(Boolean);
    if (firstSegment && firstSegment !== path) {
      return urlToPage(`/${firstSegment}`);
    }
  }

  if (policyRoutes.includes(path)) {
    return path as Page;
  }

  // For other single-segment paths, convert kebab-case to camelCase
  const page = path.split('-').reduce((acc, part, index) => {
    if (index === 0) return part;
    return acc + part.charAt(0).toUpperCase() + part.slice(1);
  }, '');

  return page as Page;
};

const App: React.FC = () => {
  const [loading, setLoading] = useState(true);
  const [authLoading, setAuthLoading] = useState(true);
  const { isAuthenticated, isLoading: authIsLoading } = useAuth();

  // App initialization with settings migration
  useEffect(() => {
    const initApp = async () => {
      // Initialize session tracking
      initSessionTracking();

      // Validate session on app mount to prevent logout on hard refresh
      try {
        await authService.refreshAuth();
        console.log('[APP] ✅ Session validated on mount');
      } catch (error) {
        console.error('[APP] ❌ Session validation failed:', error);
      }

      // 🔧 Auto-migrate localStorage settings to API-backed system
      // await StorageMigrationUtil.autoMigrateOnAppStart();

      // Keep splash screen for minimum time
      await new Promise(resolve => setTimeout(resolve, 3000));

      setLoading(false);
    };

    initApp();
  }, []);

  // Get initial page from URL
  const getInitialPage = (): Page => {
    const path = window.location.pathname;
    const page = urlToPage(path);
    const validPages = [
      'home',
      'login',
      'signup',
      'dashboard',
      'subscription',
      'subscribe',
      'about',
      'features',
      'pricing',
      'blog',
      'blogPost',
      'faq',
      'documentation',
      'contact',
      'live-support',
      'toolbox',
      'careers',
      'career-application',
      'community',
      'developers',
      'business',
      'education',
      'canvas-app',
      'ai-lab',
      'ai-lab-playground',
      'ai-lab-prompt',
      'ai-lab-battle',
      'ai-lab-transformers',
      'ai-lab-code',
      'ai-lab-sentiment',
      'ai-lab-cost',
      'ai-lab-benchmark',
      'ai-lab-history',
      'ai-lab-research',
      'ai-lab-settings',
      'ai-lab-templates',
      'ai-studio',
      'templates',
      'solutions',
      'security',
      'privacy',
      'terms',
      'cinematic',
      'creator-tools',
      'data-dashboard',
      'api-analytics',
      'reports',
      'search',
      'support',
      'news',
      'updates',
      'upcoming-modules',
      'reset-password',
      'forgot-password',
      'set-new-password',
      'task-manager',
      'tutorials',
      'ip-info',
      'api-tester',
      'status',
      'analytics',
      'api-status',
      'agent-chat',
      'ai-girlfriend',
      'emo-ai',
      'pdf-mind',
      'chat-revive',
      'tok-boost',
      'you-gen',
      'agent-x',
      'auto-chat',
      'cv-smash',
      'agents',
      'comedian',
      'lazy',
      'flirt',
      'sassy',
      'nerd',
      'cool',
      'zen',
      'gamer',
      'gdpr',
      'cookies',
      'payment-refund',
      'database-populate',
      'partners',
      'suggestions',
      'support-ticket',
      'my-account',
      'reward-center',
      'forums',
      'auth-verify',
      'thank-you',
    ];
    return validPages.includes(page) ? page : 'home';
  };

  // Load theme from localStorage immediately to prevent flashing
  const initialTheme = (localStorage.getItem('iamai_theme') as Theme) || 'dark';

  const [state, setState] = useState<AppState>({
    currentPage: getInitialPage(),
    isLoggedIn: false,
    selectedAgent: null,
    agentForSubscription: null,
    pendingSubscriptionPlan: null,
    theme: initialTheme,
    apiKeys: {
      gemini: '',
      openai: '',
      anthropic: '',
    },
    subscriptions: {},
    agents: ALL_AGENTS,
    selectedBlogPost: null,
    isSettingsOpen: false,
    agentSubscriptions: [],
    agentSubscriptionsById: {},
    currentUser: null,
  });

  // Set initial selectedAgent if page is agent-chat or agent page
  useEffect(() => {
    const initialPage = getInitialPage();
    if (initialPage === 'agent-chat') {
      const pathMatch = window.location.pathname.match(/^\/agents\/([^\/]+)\/chat$/);
      if (pathMatch) {
        const agentId = pathMatch[1];
        const agent = ALL_AGENTS.find(a => a.id === agentId);
        if (agent) {
          setState(prev => ({ ...prev, selectedAgent: agent }));
        }
      }
    } else if (AGENT_PAGES.includes(initialPage)) {
      const agent = ALL_AGENTS.find(a => a.id === initialPage);
      if (agent) {
        setState(prev => ({ ...prev, selectedAgent: agent }));
      }
    }
  }, []);

  const fetchAgentSubscriptions = useCallback(async (userId?: string | null) => {
    if (!userId) return;

    try {
      // Build headers with optional auth token fallback
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
      };

      // Add Authorization header as fallback for when cookies aren't available
      // (e.g., after Stripe redirect)
      const authToken =
        localStorage.getItem('iamai_auth_token') || localStorage.getItem('authToken');
      if (authToken) {
        headers['Authorization'] = `Bearer ${authToken}`;
      }

      const response = await fetch(getApiUrl('purchases/active'), {
        method: 'GET',
        headers,
        credentials: 'include',
      });

      if (!response.ok) {
        console.warn('[APP] ⚠️ Unable to load agent purchases:', response.status);
        return;
      }

      const data = await response.json();
      const subscriptions: AgentSubscriptionRecord[] = data.purchases || [];

      setState(prev => {
        const subscriptionLookup: Record<string, AgentSubscriptionRecord> = {};
        const derivedDisplayMap: Record<string, string> = {};

        subscriptions.forEach(sub => {
          subscriptionLookup[sub.agentId] = sub;
          const displayName =
            sub.agentInfo?.agentDisplayName || sub.agentInfo?.agentName || sub.agentId;
          if (displayName) {
            const normalizedPlan = typeof sub.plan === 'string' ? sub.plan.toLowerCase() : 'active';
            derivedDisplayMap[displayName] = normalizedPlan;
          }
        });

        return {
          ...prev,
          subscriptions: derivedDisplayMap,
          agentSubscriptions: subscriptions,
          agentSubscriptionsById: subscriptionLookup,
        };
      });
    } catch (error) {
      console.error('[APP] ❌ Failed to fetch agent subscriptions:', error);
    }
  }, []);

  const loadAppData = useCallback(async () => {
    // Only attempt to load app data if user is authenticated
    if (!isAuthenticated) {
      console.log('[APP] ⚠️ Skipping app data load - user not authenticated');
      return;
    }

    try {
      // Always attempt to load app data - authentication is handled by HttpOnly cookies
      // No need to check for token client-side as it's in HttpOnly cookie

      // Fetch user data using HttpOnly cookies (sent automatically)
      const response = await fetch(getApiUrl('users/app-data'), {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include', // Include HttpOnly cookies
      });

      if (response.ok) {
        const appData = await response.json();

        const viteApiKey =
          typeof import.meta !== 'undefined' && import.meta.env?.VITE_GEMINI_API_KEY;

        // Handle API keys with Vite fallback
        let initialApiKeys = { gemini: '', openai: '', anthropic: '' };
        if (appData.apiKeys) {
          initialApiKeys = appData.apiKeys;
        } else if (viteApiKey) {
          initialApiKeys.gemini = viteApiKey;
        }

        const agentSubscriptionsFromApi: AgentSubscriptionRecord[] = Array.isArray(
          appData.agentSubscriptions
        )
          ? appData.agentSubscriptions
          : [];

        const subscriptionLookupFromApi: Record<string, AgentSubscriptionRecord> =
          appData.agentSubscriptionsById &&
          typeof appData.agentSubscriptionsById === 'object' &&
          !Array.isArray(appData.agentSubscriptionsById)
            ? appData.agentSubscriptionsById
            : agentSubscriptionsFromApi.reduce(
                (acc, sub) => {
                  if (sub?.agentId) {
                    acc[sub.agentId] = sub;
                  }
                  return acc;
                },
                {} as Record<string, AgentSubscriptionRecord>
              );

        const subscriptionsDisplayMap: Record<string, string> = {
          ...(appData.subscriptions || {}),
        };

        if (agentSubscriptionsFromApi.length > 0) {
          agentSubscriptionsFromApi.forEach(sub => {
            const displayName =
              sub.agentInfo?.agentDisplayName || sub.agentInfo?.agentName || sub.agentId;
            if (displayName) {
              const normalizedPlan =
                typeof sub.plan === 'string' ? sub.plan.toLowerCase() : 'active';
              subscriptionsDisplayMap[displayName] = normalizedPlan;
            }
          });
        }

        // User is authenticated (HttpOnly cookie valid)
        const agents = appData.agents && appData.agents.length > 0 ? appData.agents : ALL_AGENTS;
        const selectedAgent = appData.selectedAgent || agents[0];

        setState(prev => ({
          ...prev,
          isLoggedIn: true,
          theme: (appData.theme as Theme) || 'dark',
          apiKeys: initialApiKeys,
          subscriptions: subscriptionsDisplayMap,
          agents,
          selectedAgent,
          agentSubscriptions: agentSubscriptionsFromApi,
          agentSubscriptionsById: subscriptionLookupFromApi,
          currentUser: appData.auth?.user || prev.currentUser,
        }));

        const derivedUserId = appData.auth?.user?.id || appData.auth?.user?._id;
        const shouldRefetchSubscriptions =
          agentSubscriptionsFromApi.length === 0 ||
          Object.keys(subscriptionLookupFromApi).length === 0;

        if (derivedUserId && shouldRefetchSubscriptions) {
          fetchAgentSubscriptions(derivedUserId);
        }
      } else {
        // Handle different error codes
        if (response.status === 401 || response.status === 403) {
          // Only treat explicit auth failures as logout scenarios
          setState(prev => ({
            ...prev,
            isLoggedIn: false,
            theme: 'dark',
            apiKeys: { gemini: '', openai: '', anthropic: '' },
            subscriptions: {},
            agents: ALL_AGENTS,
            selectedAgent: null,
            agentSubscriptions: [],
            agentSubscriptionsById: {},
            currentUser: null,
          }));
        } else if (response.status === 429) {
          // Rate limited: keep existing state and avoid logging the user out
          console.warn('[APP] ⚠️ App data request rate-limited (429), keeping existing state');
        } else {
          // Other server errors: log and keep current in-memory state
          console.warn('[APP] ⚠️ App data request failed with status', response.status);
        }
      }
    } catch (error) {
      console.error('[APP] ❌ Error loading user data:', error);
      // Network or unexpected error: keep current state instead of forcing logout
    }
  }, [fetchAgentSubscriptions]);

  // Load user data from MongoDB via API (HttpOnly cookie authentication)
  useEffect(() => {
    // Only load app data when authentication is complete and user is authenticated
    if (authIsLoading || !isAuthenticated) {
      if (!authIsLoading) {
        setAuthLoading(false);
      }
      return;
    }

    let isMounted = true;
    (async () => {
      await loadAppData();
      if (isMounted) {
        setAuthLoading(false);
      }
    })();

    return () => {
      isMounted = false;
    };
  }, [loadAppData, isAuthenticated, authIsLoading]);

  const refreshAppData = useCallback(async () => {
    // Only refresh if user is authenticated
    if (!isAuthenticated) {
      console.log('[APP] ⚠️ Skipping app data refresh - user not authenticated');
      return;
    }

    // Refresh agent subscriptions data using the current authenticated user
    const currentUser = state.currentUser as any | null;
    const userIdentifier =
      currentUser?.id || currentUser?._id || currentUser?.userId || currentUser?.email || null;

    if (userIdentifier) {
      await fetchAgentSubscriptions(userIdentifier.toString());
    }

    await loadAppData();
  }, [loadAppData, fetchAgentSubscriptions, state.currentUser, isAuthenticated]);

  // Apply theme to DOM and persist to localStorage whenever theme changes
  useEffect(() => {
    // Apply theme class to document root
    document.documentElement.classList.toggle('light', state.theme === 'light');

    // Save to localStorage immediately (sync)
    localStorage.setItem('iamai_theme', state.theme);

    // Debounced save to API (async, non-blocking)
    const timeoutId = setTimeout(() => {
      appStorage.saveTheme(state.theme);
    }, 1000); // Wait 1 second before saving to API

    return () => clearTimeout(timeoutId);
  }, [state.theme]);

  // Initialize session tracking on app load
  useEffect(() => {
    initSessionTracking();
  }, []);

  // Save auth state to API-backed storage
  useEffect(() => {
    if (state.isLoggedIn) {
      // Get existing auth data from authService for compatibility
      const existingAuthData = authService.getUser();
      let authData = { isLoggedIn: true, timestamp: Date.now() };

      if (existingAuthData) {
        // Preserve user and token data from authService
        authData = { ...existingAuthData, ...authData };
      }

      appStorage.saveAuth(authData);
    } else {
      // Clear auth data on logout
      appStorage.saveAuth(null);
    }
  }, [state.isLoggedIn]);

  // Save API keys to API-backed storage (debounced)
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      appStorage.saveApiKeys(state.apiKeys);
    }, 1000);

    return () => clearTimeout(timeoutId);
  }, [state.apiKeys]);

  // Save subscriptions to API-backed storage (debounced)
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      appStorage.saveSubscriptions(state.subscriptions);
    }, 1000);

    return () => clearTimeout(timeoutId);
  }, [state.subscriptions]);

  // Save custom agents to API-backed storage (debounced)
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      appStorage.saveAgents(state.agents);
    }, 1000);

    return () => clearTimeout(timeoutId);
  }, [state.agents]);

  // Save selected agent to API-backed storage (debounced)
  useEffect(() => {
    if (state.selectedAgent) {
      const timeoutId = setTimeout(() => {
        appStorage.saveSelectedAgent(state.selectedAgent);
      }, 1000);

      return () => clearTimeout(timeoutId);
    }
  }, [state.selectedAgent]);

  // Listen for browser back/forward buttons
  useEffect(() => {
    const handlePopState = (event: PopStateEvent) => {
      const page = event.state?.page || urlToPage(window.location.pathname);
      const agentId = event.state?.agentId;
      setState(prev => {
        const newState = { ...prev, currentPage: page };
        if (agentId) {
          const agent = ALL_AGENTS.find(a => a.id === agentId);
          if (agent) {
            newState.selectedAgent = agent;
          }
        } else if (page === 'agent-chat') {
          // Extract agentId from URL path for nested routes
          const pathMatch = window.location.pathname.match(/^\/agents\/([^\/]+)\/chat$/);
          if (pathMatch) {
            const extractedAgentId = pathMatch[1];
            const agent = ALL_AGENTS.find(a => a.id === extractedAgentId);
            if (agent) {
              newState.selectedAgent = agent;
            }
          }
        } else if (AGENT_PAGES.includes(page)) {
          const agent = ALL_AGENTS.find(a => a.id === page);
          if (agent) {
            newState.selectedAgent = agent;
          }
        }
        return newState;
      });
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  // Scroll to top whenever page changes
  useEffect(() => {
    // Multiple scroll methods to ensure it works
    const scrollToTop = () => {
      // Method 1: Direct window scroll
      window.scrollTo(0, 0);

      // Method 2: Set scroll properties directly
      document.documentElement.scrollTop = 0;
      document.body.scrollTop = 0;

      // Method 3: Scroll main content into view
      const mainContent = document.getElementById('main-content');
      if (mainContent) {
        mainContent.scrollIntoView({ block: 'start' });
      }
    };

    // Execute immediately
    scrollToTop();

    // Also execute after a small delay to ensure DOM is updated
    const timer = setTimeout(scrollToTop, 10);

    return () => clearTimeout(timer);
  }, [state.currentPage]);

  const handleNavigate = (page: Page, agentId?: string) => {
    let actualPage = page;
    if (page === 'agent-chat' && agentId) {
      actualPage = agentId as Page;
    }
    setState(prev => ({ ...prev, currentPage: actualPage }));
    // Update URL when navigating
    let path: string;
    if (actualPage === 'home') {
      // For logged-in users, use /home, for logged-out users use /
      path = state.isLoggedIn ? '/home' : '/';
    } else {
      path = `/${pageToUrl(actualPage)}`;
    }
    window.history.pushState({ page: actualPage, agentId }, '', path);
  };

  const handleLogin = async () => {
    setState(prev => {
      const newState = {
        ...prev,
        isLoggedIn: true,
        selectedAgent: prev.selectedAgent || prev.agents[0] || null,
      };

      // If user was trying to subscribe to an agent, redirect to subscription page
      if (prev.agentForSubscription) {
        newState.currentPage = 'subscribe';
        const searchParams = new URLSearchParams({ agent: prev.agentForSubscription.id });
        if (prev.pendingSubscriptionPlan) {
          searchParams.set('plan', prev.pendingSubscriptionPlan);
        }
        window.history.pushState(
          { page: 'subscribe' },
          '',
          `/subscribe?${searchParams.toString()}`
        );
      } else {
        // After login, redirect to home page with updated URL
        newState.currentPage = 'home';
        // Update URL to home page
        window.history.pushState({ page: 'home' }, '', '/home');
      }

      return newState;
    });

    // Store auth state in API-backed storage - preserve existing user data if available
    const existingAuthData = authService.getUser();
    let authData = { isLoggedIn: true, timestamp: Date.now() };

    if (existingAuthData) {
      // Preserve user and token data from authService
      authData = { ...existingAuthData, ...authData };
    } else {
    }

    appStorage.saveAuth(authData);

    // Sync user data from database after successful login
    try {
      // Load fresh user data from database
      const response = await fetch(getApiUrl('users/app-data'), {
        method: 'GET',
        credentials: 'include',
      });

      if (response.ok) {
        const userData = await response.json();

        // Update state with database values
        setState(prev => ({
          ...prev,
          theme: (userData.theme as Theme) || prev.theme,
          apiKeys: userData.apiKeys || prev.apiKeys,
          subscriptions: userData.subscriptions || prev.subscriptions,
          selectedAgent: userData.selectedAgent || prev.selectedAgent,
          currentUser: userData.auth?.user || prev.currentUser,
        }));

        const refreshedUserId = userData.auth?.user?.id || userData.auth?.user?._id;
        if (refreshedUserId) {
          fetchAgentSubscriptions(refreshedUserId);
        }

        // Sync theme from database if available
        if (typeof window.syncThemeFromBackend === 'function') {
          await window.syncThemeFromBackend();
        }
      }
    } catch (error) {
      console.error('[APP] Error syncing user data after login:', error);
    }
  };

  const handleLogout = async () => {
    // Clear session on server
    try {
      await fetch(getApiUrl('auth/signout'), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
      });
    } catch (error) {
      console.error('[APP] Error during logout:', error);
    }

    // Clear local state and auth data
    authService.logout(); // This clears localStorage and cache
    setState(prev => ({
      ...prev,
      isLoggedIn: false,
      currentPage: 'home',
      selectedAgent: null,
      agentForSubscription: null,
      pendingSubscriptionPlan: null,
      agentSubscriptions: [],
      agentSubscriptionsById: {},
      currentUser: null,
    }));

    // Update URL to root path after logout
    window.history.pushState({ page: 'home' }, '', '/');
  };

  const handleSelectAgent = (agent: Agent) => {
    setState(prev => ({ ...prev, selectedAgent: agent }));
    handleNavigate('agent-chat', agent.id);
  };

  const goToDashboardSubscriptions = useCallback(() => {
    window.history.pushState({ page: 'dashboard' }, '', '/dashboard/subscriptions');
    setState(prev => ({
      ...prev,
      currentPage: 'dashboard',
    }));
  }, []);

  const handleSelectAgentForSubscription = (agent: Agent, plan?: SubscriptionPlanSlug) => {
    const planSlug: SubscriptionPlanSlug | null = plan ?? null;

    if (state.isLoggedIn) {
      const existingSubscription = state.agentSubscriptionsById?.[agent.id];
      const hasActiveSubscription = existingSubscription?.status === 'active';

      if (hasActiveSubscription) {
        notificationService.info(
          `${agent.name} is already active`,
          'Manage this subscription from your dashboard.'
        );
        goToDashboardSubscriptions();
        return;
      }

      const params = new URLSearchParams({ agent: agent.id });
      if (planSlug) {
        params.set('plan', planSlug);
      }
      window.history.pushState({ page: 'pricing' }, '', `/pricing?${params.toString()}`);
      setState(prev => ({
        ...prev,
        agentForSubscription: agent,
        pendingSubscriptionPlan: planSlug,
        currentPage: 'pricing',
      }));
    } else {
      setState(prev => ({
        ...prev,
        agentForSubscription: agent,
        pendingSubscriptionPlan: planSlug,
        currentPage: 'login',
      }));
      window.history.pushState({ page: 'login' }, '', '/login');
    }
  };

  // Unified subscription entry: Create Stripe checkout session directly
  const handleSubscribe = async (agent: Agent, plan?: SubscriptionPlanSlug | null) => {
    const planSlug: SubscriptionPlanSlug | null = plan ?? state.pendingSubscriptionPlan ?? null;

    if (!planSlug) {
      notificationService.error('No plan selected', 'Please select a plan first');
      return;
    }

    // Show loading notification
    notificationService.info('Redirecting to checkout...', `${agent.name} - ${planSlug} plan`);

    try {
      const response = await fetch(getApiUrl(`agents/${agent.id}/purchase`), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({
          planType: planSlug,
        }),
      });

      if (!response.ok) {
        const errorData = await response
          .json()
          .catch(() => ({ error: 'Failed to create checkout' }));
        throw new Error(errorData.error || 'Failed to create checkout session');
      }

      const { url } = await response.json();

      // Redirect to Stripe Checkout
      window.location.href = url;
    } catch (error: any) {
      console.error('Checkout error:', error);
      notificationService.error('Checkout Failed', error.message || 'Please try again');
    }
  };

  const handleSelectBlogPost = (post: BlogPost) => {
    setState(prev => ({
      ...prev,
      selectedBlogPost: post,
      currentPage: 'blogPost',
    }));
  };

  const handleOpenSettings = () => {
    setState(prev => ({ ...prev, isSettingsOpen: true }));
  };

  const handleCloseSettings = () => {
    setState(prev => ({ ...prev, isSettingsOpen: false }));
  };

  const handleApiKeyChange = (provider: 'gemini' | 'openai' | 'anthropic') => (key: string) => {
    setState(prev => ({
      ...prev,
      apiKeys: {
        ...prev.apiKeys,
        [provider]: key,
      },
    }));
  };

  const setAgents = (agents: Agent[] | ((prev: Agent[]) => Agent[])) => {
    setState(prev => ({
      ...prev,
      agents: typeof agents === 'function' ? agents(prev.agents) : agents,
    }));
  };

  const appContextValue = {
    state,
    setState,
    navigate: handleNavigate,
    login: handleLogin,
    logout: handleLogout,
    selectAgent: handleSelectAgent,
    selectAgentForSubscription: handleSelectAgentForSubscription,
    subscribe: handleSubscribe,
    selectBlogPost: handleSelectBlogPost,
    openSettings: handleOpenSettings,
    closeSettings: handleCloseSettings,
    setApiKey: handleApiKeyChange,
    setAgents,
    authLoading,
    refreshAppData,
  };

  return (
    <>
      {loading && <SplashScreen onFinished={() => setLoading(false)} />}
      <ThemeProvider>
        <AppProvider value={appContextValue}>
          <div
            className={`min-h-screen bg-black text-white ${state.theme}`}
            style={{ display: loading ? 'none' : 'block' }}
          >
            <AppContent />
            <ToastContainer />
          </div>
        </AppProvider>
      </ThemeProvider>
    </>
  );
};

const AppContent: React.FC = () => {
  const {
    state,
    navigate,
    login,
    logout,
    selectAgent,
    selectAgentForSubscription,
    subscribe,
    selectBlogPost,
    openSettings,
    closeSettings,
    setApiKey,
    setAgents,
    authLoading,
    refreshAppData,
  } = useApp();

  // Mobile menu state
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Close mobile menu when page changes (async to satisfy lint rule)
  useEffect(() => {
    if (!isMobileMenuOpen) {
      return;
    }

    const timeoutId = window.setTimeout(() => {
      setIsMobileMenuOpen(false);
    }, 0);

    return () => window.clearTimeout(timeoutId);
  }, [state.currentPage, isMobileMenuOpen]);

  // Close mobile menu on escape key
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setIsMobileMenuOpen(false);
      }
    };

    if (isMobileMenuOpen) {
      document.addEventListener('keydown', handleEscape);
      // Prevent body scroll when menu is open
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }

    return () => {
      document.removeEventListener('keydown', handleEscape);
      document.body.style.overflow = '';
    };
  }, [isMobileMenuOpen]);

  const {
    currentPage,
    selectedAgent,
    agentForSubscription,
    selectedBlogPost,
    isSettingsOpen,
    agents,
    subscriptions,
    apiKeys,
  } = state;

  const renderPage = () => {
    // Show loading screen while checking authentication
    if (authLoading) {
      return (
        <div className="min-h-screen bg-black flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
            <p className="text-gray-400">Loading your profile...</p>
          </div>
        </div>
      );
    }

    // Redirect logged-in users away from login/signup pages
    if (state.isLoggedIn && (currentPage === 'login' || currentPage === 'signup')) {
      setTimeout(() => navigate('dashboard'), 0);
      return (
        <div className="min-h-screen bg-black flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-cyan-500 mx-auto mb-4"></div>
            <p className="text-gray-400">Already logged in, redirecting to dashboard...</p>
          </div>
        </div>
      );
    }

    // Pages accessible to EVERYONE (both logged in and logged out)
    // These should be checked BEFORE authentication checks
    switch (currentPage) {
      case 'gdpr':
        return <GDPRPage onNavigate={navigate} />;
      case 'cookies':
        return <CookiesPage onNavigate={navigate} />;
      case 'payment-refund':
        return <PaymentRefundPage onNavigate={navigate} />;
      case 'database-populate':
        return <DatabasePopulatePage onNavigate={navigate} />;
      case 'thank-you':
        return (
          <ThankYouPage
            onNavigate={navigate}
            onSelectAgent={selectAgent}
            onRefreshAppData={refreshAppData}
          />
        );
      case 'partners':
        return <PartnersPage onNavigate={navigate} />;
      case 'status':
        return <StatusPage onNavigate={navigate} />;
      case 'privacy':
        return <PrivacyPolicyPage onNavigate={navigate} />;
      case 'terms':
        return <TermsConditionsPage onNavigate={navigate} />;
      case 'reward-center':
        return <RewardCenterPage onNavigate={navigate} />;
    }

    // Public pages (accessible by anyone) - logged in users can also visit these
    if (!state.isLoggedIn) {
      switch (currentPage) {
        case 'dashboard':
          // Redirect to login if trying to access dashboard while not logged in
          setTimeout(() => navigate('login'), 0);
          return <LoginPage onNavigate={navigate} onLogin={login} />;
        case 'login':
          return <LoginPage onNavigate={navigate} onLogin={login} />;
        case 'signup':
          return <SignupPage onNavigate={navigate} onLogin={login} />;
        case 'about':
          return <AboutPage onNavigate={navigate} />;
        case 'agents':
          return <AgentsPage onSelectAgent={selectAgentForSubscription} onNavigate={navigate} />;
        case 'features':
          return <FeaturesPage onNavigate={navigate} />;
        case 'pricing':
          try {
            return <PricingPage onNavigate={navigate} />;
          } catch (error) {
            console.error('Error rendering PricingPage:', error);
            return <div className="text-red-500 p-4">Error loading pricing page</div>;
          }
        case 'blog':
          return <BlogPage onNavigate={navigate} onSelectBlogPost={selectBlogPost} />;
        case 'blogPost':
          return selectedBlogPost ? (
            <BlogPostViewer post={selectedBlogPost} onNavigate={navigate} />
          ) : (
            <BlogPage onNavigate={navigate} onSelectBlogPost={selectBlogPost} />
          );
        case 'faq':
          return <FAQPage onNavigate={navigate} />;
        case 'documentation':
          return <DocumentationPage onNavigate={navigate} />;
        case 'contact':
          return <ContactUsPage onNavigate={navigate} />;
        case 'careers':
          return <CareersPage onNavigate={navigate} />;
        case 'career-application':
          return <CareerApplicationPage onNavigate={navigate} />;
        case 'community':
          return <CommunityPage onNavigate={navigate} />;
        case 'forums':
          return <ForumsPage onNavigate={navigate} />;
        case 'developers':
          return <DevelopersPage onNavigate={navigate} />;
        case 'business':
          return <BusinessPage onNavigate={navigate} />;
        case 'education':
          return <EducationPage onNavigate={navigate} />;
        case 'canvas-app':
          return <CanvasAppPage />;
        case 'ai-lab':
          return <AILabHubPage onNavigate={navigate} />;
        case 'ai-lab-playground':
          return <AILabPlaygroundPage onNavigate={navigate} />;
        case 'ai-lab-prompt':
          return <AILabPromptPage onNavigate={navigate} />;
        case 'ai-lab-battle':
          return <AILabBattlePage onNavigate={navigate} />;
        case 'ai-lab-transformers':
          return <AILabTransformersPage onNavigate={navigate} />;
        case 'ai-lab-code':
          return <AILabCodePlaygroundPage onNavigate={navigate} />;
        case 'ai-lab-sentiment':
          return <AILabSentimentAnalyzerPage onNavigate={navigate} />;
        case 'ai-lab-cost':
          return <AILabCostCalculatorPage onNavigate={navigate} />;
        case 'ai-lab-latency':
          return <AILabLatencyPage onNavigate={navigate} />;
        case 'ai-lab-history':
          return <AILabHistoryPage onNavigate={navigate} />;
        case 'ai-lab-research':
          return <AILabResearchPage onNavigate={navigate} />;
        case 'ai-lab-settings':
          return <AILabSettingsPage onNavigate={navigate} />;
        case 'ai-lab-templates':
          return <AILabTemplatesPage onNavigate={navigate} />;
        case 'ai-studio':
          return <AIStudioPage onNavigate={navigate} />;
        case 'templates':
          return <TemplatesPage onNavigate={navigate} />;
        case 'template-customer-support-bot':
          return <TemplateDetailPage templateId="customer-support-bot" onNavigate={navigate} />;
        case 'template-onboarding-assistant':
          return <TemplateDetailPage templateId="onboarding-assistant" onNavigate={navigate} />;
        case 'template-sales-development-rep':
          return <TemplateDetailPage templateId="sales-development-rep" onNavigate={navigate} />;
        case 'template-content-summarizer':
          return <TemplateDetailPage templateId="content-summarizer" onNavigate={navigate} />;
        case 'template-llama-3-local':
          return <TemplateDetailPage templateId="llama-3-local" onNavigate={navigate} />;
        case 'template-mistral-local':
          return <TemplateDetailPage templateId="mistral-local" onNavigate={navigate} />;
        case 'template-phi-3-local':
          return <TemplateDetailPage templateId="phi-3-local" onNavigate={navigate} />;
        case 'template-gemma-local':
          return <TemplateDetailPage templateId="gemma-local" onNavigate={navigate} />;
        case 'template-codellama-local':
          return <TemplateDetailPage templateId="codellama-local" onNavigate={navigate} />;
        case 'template-neural-chat-local':
          return <TemplateDetailPage templateId="neural-chat-local" onNavigate={navigate} />;
        case 'template-vicuna-local':
          return <TemplateDetailPage templateId="vicuna-local" onNavigate={navigate} />;
        case 'template-orca-mini-local':
          return <TemplateDetailPage templateId="orca-mini-local" onNavigate={navigate} />;
        case 'solutions':
          return <SolutionsPage onNavigate={navigate} />;
        case 'security':
          return <SecurityPage onNavigate={navigate} />;
        case 'cinematic':
          return <CinematicPage onNavigate={navigate} />;
        case 'creator-tools':
          return <CreatorToolsPage onNavigate={navigate} />;
        case 'data-dashboard':
          return <DataDashboardPage onNavigate={navigate} />;
        case 'api-analytics':
          return <APIAnalyticsDashboard onNavigate={navigate} />;
        case 'reports':
          return <ReportsPage />;
        case 'search':
          return <SearchPage onNavigate={navigate} />;
        case 'support':
          return <SupportPage onNavigate={navigate} />;
        case 'live-support':
          return <LiveSupportPage onNavigate={navigate} isLoggedIn={state.isLoggedIn} />;
        case 'toolbox':
          return <ToolboxPage onNavigate={navigate} />;
        case 'realtime-toolbox':
          return <RealtimeToolboxPage />;
        case 'news':
          return <NewsPage onNavigate={navigate} onSelectAgent={selectAgent} />;
        case 'updates':
          return <UpdatesPage onNavigate={navigate} />;
        case 'upcoming-modules':
          return <UpcomingModulesPage onNavigate={navigate} />;
        case 'reset-password':
          return <SetNewPasswordPage onNavigate={navigate} />;
        case 'forgot-password':
          return <ForgotPasswordPage onNavigate={navigate} />;
        case 'set-new-password':
          return <SetNewPasswordPage onNavigate={navigate} />;
        case 'task-manager':
          return <TaskManagerPage onNavigate={navigate} />;
        case 'tutorials':
          return <TutorialsPage onNavigate={navigate} />;
        case 'ip-info':
          return <IPInfoPage onNavigate={navigate} />;
        case 'dns-lookup':
          return <DNSLookupPage onNavigate={navigate} />;
        case 'whois':
          return <WhoisLookupPage onNavigate={navigate} />;
        case 'ping-test':
          return <PingTestPage onNavigate={navigate} />;
        case 'port-scanner':
          return <PortScannerPage onNavigate={navigate} />;
        case 'ssl-checker':
          return <SSLCheckerPage onNavigate={navigate} />;
        case 'url-encoder':
          return <URLEncoderPage onNavigate={navigate} />;
        case 'header-checker':
          return <HeaderCheckerPage onNavigate={navigate} />;
        case 'uptime-monitor':
          return <UptimeMonitorPage onNavigate={navigate} />;
        case 'domain-research-suite':
          return <DomainResearchSuitePage />;
        case 'screenshot-api':
          return <ScreenshotAPIPage />;
        case 'email-verification':
          return <EmailVerificationPage />;
        case 'ip-netblocks':
          return <IPNetblocksPage />;
        case 'domain-reputation':
          return <DomainReputationPage />;
        case 'website-categorization':
          return <WebsiteCategorizationPage />;
        case 'domain-availability':
          return <DomainAvailabilityPage />;
        case 'mac-address':
          return <MACAddressPage />;
        case 'threat-intelligence':
          return <ThreatIntelligencePage />;
        case 'api-tester':
          return <APITesterPage onNavigate={navigate} />;
        case 'status-analytics':
          return <AnalyticsPage onNavigate={navigate} />;
        case 'status-api-status':
          return <APIStatusPage onNavigate={navigate} />;
        case 'analytics':
          return <AnalyticsPage onNavigate={navigate} />;
        case 'api-status':
          return <APIStatusPage onNavigate={navigate} />;
        // ✨ Agent pages - accessible to everyone (logged in or not)
        case 'ai-girlfriend':
          return <AIGirlfriendPage />;
        case 'agent-x':
          return <AgentXPage />;
        case 'auto-chat':
          return <AutoChatPage />;
        case 'cv-smash':
          return <CVSmashPage />;
        case 'emo-ai':
          return <EmoAIPage />;
        case 'chat-revive':
          return <ChatRevivePage />;
        case 'pdf-mind':
          return <PDFMindPage />;
        case 'tok-boost':
          return <TokBoostPage />;
        case 'you-gen':
          return <YouGenPage />;
        case 'comedian':
          return <ComedyChadPage />;
        case 'lazy':
          return <LazyLarryPage />;
        case 'flirt':
          return <FlirtyFionaPage />;
        case 'sassy':
          return <SassySarahPage />;
        case 'nerd':
          return <NerdyNeilPage />;
        case 'cool':
          return <CoolKylePage />;
        case 'zen':
          return <ZenMasterZaraPage />;
        case 'gamer':
          return <GamerGaryPage />;
        case 'suggestions':
          return <SuggestionsPage onNavigate={navigate} />;
        case 'support-ticket':
          return <SupportTicketPage onNavigate={navigate} />;

        case 'home':
        default:
          return (
            <HomePage
              onSelectAgentForSubscription={selectAgentForSubscription}
              onNavigate={navigate}
              onSelectBlogPost={selectBlogPost}
              isLoggedIn={state.isLoggedIn}
            />
          );
      }
    }

    // Authenticated pages
    switch (currentPage) {
      case 'dashboard':
        return (
          <DashboardProvider token={state.isLoggedIn ? 'authenticated-user' : null}>
            <Dashboard
              agents={agents}
              setAgents={setAgents}
              selectedAgent={selectedAgent || agents[0] || null}
              onSelectAgent={selectAgent}
              onLogout={logout}
              onOpenSettings={openSettings}
              geminiApiKey={apiKeys.gemini}
              subscriptions={subscriptions}
              onSubscribe={subscribe}
            />
          </DashboardProvider>
        );
      case 'subscription': {
        // Check for agent parameter in URL
        const urlParams = new URLSearchParams(window.location.search);
        const agentIdFromUrl = urlParams.get('agent');
        const targetAgent = agentIdFromUrl
          ? agents.find(a => a.id === agentIdFromUrl)
          : agentForSubscription;

        return targetAgent ? (
          <SubscriptionPage
            agent={targetAgent}
            onNavigate={() => navigate('dashboard')}
            onSubscribe={(agentName: string, planName: string) => {
              // The actual subscription will be handled by Stripe
              // After payment success, user will return to dashboard
              notificationService.info('Preparing Subscription', `${agentName} - ${planName}`);
            }}
          />
        ) : (
          <div className="min-h-screen bg-black flex items-center justify-center">
            <div className="text-center">
              <h2 className="text-2xl font-bold text-white mb-4">Subscription Page</h2>
              <p className="text-gray-400 mb-6">No agent selected for subscription.</p>
              <button
                onClick={() => navigate('agents')}
                className="px-6 py-3 bg-cyan-600 hover:bg-cyan-700 text-white font-semibold rounded-lg transition-colors mr-4"
              >
                Browse Agents
              </button>
              <button
                onClick={() => navigate('dashboard')}
                className="px-6 py-3 bg-gray-600 hover:bg-gray-700 text-white font-semibold rounded-lg transition-colors"
              >
                Back to Dashboard
              </button>
            </div>
          </div>
        );
      }

      case 'subscribe':
        return (
          <Suspense fallback={<PageLoader />}>
            <SubscribePage onNavigate={navigate} />
          </Suspense>
        );

      case 'thank-you':
        return <ThankYouPage onNavigate={navigate} onSelectAgent={selectAgent} />;

      case 'agent-chat': {
        // If no agent is selected, try to get from URL
        let agent = selectedAgent;
        if (!agent) {
          const pathMatch = window.location.pathname.match(/^\/agents\/([^\/]+)\/chat$/);
          if (pathMatch) {
            const agentId = pathMatch[1];
            agent = ALL_AGENTS.find(a => a.id === agentId);
            if (agent) {
              // Set the selected agent
              setState(prev => ({ ...prev, selectedAgent: agent }));
            }
          }
        }

        // If still no agent, redirect to agents page
        if (!agent) {
          setTimeout(() => navigate('agents'), 0);
          return (
            <div className="min-h-screen bg-[var(--color-bg-primary)] flex items-center justify-center">
              <div className="text-center">
                <div className="animate-spin w-8 h-8 border-2 border-cyan-500 border-t-transparent rounded-full mx-auto mb-4"></div>
                <p className="text-[var(--color-text-secondary)]">Redirecting to agents...</p>
              </div>
            </div>
          );
        }

        // Convert agent to chat config and use the new UniversalAgentChat
        const chatConfig = convertAgentToChatConfig(agent);
        return <UniversalAgentChat agent={chatConfig} />;
      }

      // Agent pages - require subscription or redirect to subscription page
      case 'ai-girlfriend':
      case 'agent-x':
      case 'auto-chat':
      case 'cv-smash':
      case 'emo-ai':
      case 'chat-revive':
      case 'pdf-mind':
      case 'tok-boost':
      case 'you-gen':
      case 'comedian':
      case 'lazy':
      case 'flirt':
      case 'sassy':
      case 'nerd':
      case 'cool':
      case 'zen':
      case 'gamer': {
        // Allow direct access to agent pages - subscription check happens within agent components
        // No forced redirects - let users see agent pages and decide to subscribe

        // Has subscription - render the agent page
        switch (currentPage) {
          case 'ai-girlfriend':
            return <AIGirlfriendPage />;
          case 'agent-x':
            return <AgentXPage />;
          case 'auto-chat':
            return <AutoChatPage />;
          case 'cv-smash':
            return <CVSmashPage />;
          case 'emo-ai':
            return <EmoAIPage />;
          case 'chat-revive':
            return <ChatRevivePage />;
          case 'pdf-mind':
            return <PDFMindPage />;
          case 'tok-boost':
            return <TokBoostPage />;
          case 'you-gen':
            return <YouGenPage />;
          case 'comedian':
            return <ComedyChadPage />;
          case 'lazy':
            return <LazyLarryPage />;
          case 'flirt':
            return <FlirtyFionaPage />;
          case 'sassy':
            return <SassySarahPage />;
          case 'nerd':
            return <NerdyNeilPage />;
          case 'cool':
            return <CoolKylePage />;
          case 'zen':
            return <ZenMasterZaraPage />;
          case 'gamer':
            return <GamerGaryPage />;
          default:
            return null;
        }
      }

      case 'agents':
        return <AgentsPage onSelectAgent={selectAgentForSubscription} onNavigate={navigate} />;

      default:
        // This allows accessing public pages even when logged in
        // Fall through to try rendering as a public page
        switch (currentPage) {
          case 'home':
            return (
              <HomePage
                onSelectAgentForSubscription={selectAgentForSubscription}
                onNavigate={navigate}
                onSelectBlogPost={selectBlogPost}
              />
            );
          case 'about':
            return <AboutPage onNavigate={navigate} />;
          case 'features':
            return <FeaturesPage onNavigate={navigate} />;
          case 'pricing':
            return <PricingPage onNavigate={navigate} />;
          case 'blog':
            return <BlogPage onNavigate={navigate} onSelectBlogPost={selectBlogPost} />;
          case 'blogPost':
            return selectedBlogPost ? (
              <BlogPostViewer post={selectedBlogPost} onNavigate={navigate} />
            ) : (
              <BlogPage onNavigate={navigate} onSelectBlogPost={selectBlogPost} />
            );
          case 'faq':
            return <FAQPage onNavigate={navigate} />;
          case 'documentation':
            return <DocumentationPage onNavigate={navigate} />;
          case 'contact':
            return <ContactUsPage onNavigate={navigate} />;
          case 'careers':
            return <CareersPage onNavigate={navigate} />;
          case 'career-application':
            return <CareerApplicationPage onNavigate={navigate} />;
          case 'community':
            return <CommunityPage onNavigate={navigate} />;
          case 'forums':
            return <ForumsPage onNavigate={navigate} />;
          case 'developers':
            return <DevelopersPage onNavigate={navigate} />;
          case 'business':
            return <BusinessPage onNavigate={navigate} />;
          case 'education':
            return <EducationPage onNavigate={navigate} />;
          case 'ai-lab':
            return <AILabHubPage onNavigate={navigate} />;
          case 'ai-lab-playground':
            return <AILabPlaygroundPage onNavigate={navigate} />;
          case 'ai-lab-prompt':
            return <AILabPromptPage onNavigate={navigate} />;
          case 'ai-lab-battle':
            return <AILabBattlePage onNavigate={navigate} />;
          case 'ai-lab-transformers':
            return <AILabTransformersPage onNavigate={navigate} />;
          case 'ai-lab-code':
            return <AILabCodePlaygroundPage onNavigate={navigate} />;
          case 'ai-lab-sentiment':
            return <AILabSentimentAnalyzerPage onNavigate={navigate} />;
          case 'ai-lab-cost':
            return <AILabCostCalculatorPage onNavigate={navigate} />;
          case 'ai-lab-research':
            return <AILabResearchPage onNavigate={navigate} />;
          case 'ai-lab-settings':
            return <AILabSettingsPage onNavigate={navigate} />;
          case 'ai-lab-templates':
            return <AILabTemplatesPage onNavigate={navigate} />;
          case 'ai-studio':
            return <AIStudioPage onNavigate={navigate} />;
          case 'templates':
            return <TemplatesPage onNavigate={navigate} />;
          case 'solutions':
            return <SolutionsPage onNavigate={navigate} />;
          case 'security':
            return <SecurityPage onNavigate={navigate} />;
          case 'cinematic':
            return <CinematicPage onNavigate={navigate} />;
          case 'creator-tools':
            return <CreatorToolsPage onNavigate={navigate} />;
          case 'data-dashboard':
            return <DataDashboardPage onNavigate={navigate} />;
          case 'api-analytics':
            return <APIAnalyticsDashboard onNavigate={navigate} />;
          case 'reports':
            return <ReportsPage />;
          case 'search':
            return <SearchPage onNavigate={navigate} />;
          case 'support':
            return <SupportPage onNavigate={navigate} />;
          case 'live-support':
            return <LiveSupportPage onNavigate={navigate} isLoggedIn={state.isLoggedIn} />;
          case 'toolbox':
            return <ToolboxPage onNavigate={navigate} />;
          case 'realtime-toolbox':
            return <RealtimeToolboxPage />;
          case 'news':
            return <NewsPage onNavigate={navigate} onSelectAgent={selectAgent} />;
          case 'updates':
            return <UpdatesPage onNavigate={navigate} />;
          case 'upcoming-modules':
            return <UpcomingModulesPage onNavigate={navigate} />;
          case 'reset-password':
            return <SetNewPasswordPage onNavigate={navigate} />;
          case 'forgot-password':
            return <ForgotPasswordPage onNavigate={navigate} />;
          case 'set-new-password':
            return <SetNewPasswordPage onNavigate={navigate} />;
          case 'task-manager':
            return <TaskManagerPage onNavigate={navigate} />;
          case 'tutorials':
            return <TutorialsPage onNavigate={navigate} />;
          case 'ip-info':
            return <IPInfoPage onNavigate={navigate} />;
          case 'dns-lookup':
            return <DNSLookupPage onNavigate={navigate} />;
          case 'whois':
            return <WhoisLookupPage onNavigate={navigate} />;
          case 'ping-test':
            return <PingTestPage onNavigate={navigate} />;
          case 'port-scanner':
            return <PortScannerPage onNavigate={navigate} />;
          case 'ssl-checker':
            return <SSLCheckerPage onNavigate={navigate} />;
          case 'url-encoder':
            return <URLEncoderPage onNavigate={navigate} />;
          case 'header-checker':
            return <HeaderCheckerPage onNavigate={navigate} />;
          case 'uptime-monitor':
            return <UptimeMonitorPage onNavigate={navigate} />;
          case 'domain-research-suite':
            return <DomainResearchSuitePage />;
          case 'screenshot-api':
            return <ScreenshotAPIPage />;
          case 'email-verification':
            return <EmailVerificationPage />;
          case 'ip-netblocks':
            return <IPNetblocksPage />;
          case 'domain-reputation':
            return <DomainReputationPage />;
          case 'website-categorization':
            return <WebsiteCategorizationPage />;
          case 'domain-availability':
            return <DomainAvailabilityPage />;
          case 'mac-address':
            return <MACAddressPage />;
          case 'threat-intelligence':
            return <ThreatIntelligencePage />;

          default:
            // Default fallback: show dashboard
            return (
              <DashboardProvider token={state.isLoggedIn ? 'authenticated-user' : null}>
                <Dashboard
                  agents={agents}
                  setAgents={setAgents}
                  selectedAgent={selectedAgent || agents[0] || null}
                  onSelectAgent={selectAgent}
                  onLogout={logout}
                  onOpenSettings={openSettings}
                  geminiApiKey={apiKeys.gemini}
                  subscriptions={subscriptions}
                  onSubscribe={subscribe}
                />
              </DashboardProvider>
            );
        }
    }
  };

  // Pages that should hide the main site navigation (all agent chat routes)
  const hideNavPages: Page[] = ['agent-chat', ...AGENT_PAGES];
  const shouldShowNav = !hideNavPages.includes(currentPage);

  return (
    <Suspense fallback={<PageLoader />}>
      <div className="w-full">
        {/* Navigation Bar - Hide on certain pages like agent-chat */}
        {shouldShowNav && (
          <nav className="fixed top-0 left-0 right-0 z-50 bg-black/95 backdrop-blur-sm border-b border-cyan-500/40 transition-all duration-300 ease-in-out">
            <div className="container mx-auto px-4 sm:px-6 py-4 max-w-full">
              <div className="flex items-center justify-between flex-wrap">
                {/* Logo - Always Visible on Left */}
                <button
                  onClick={() => {
                    window.location.href = '/';
                  }}
                  className="hover:opacity-80 transition-opacity flex-shrink-0 z-50"
                  title="Go to homepage"
                >
                  <img
                    src="/assets/iamai-logo.png"
                    alt="IA M AI Logo"
                    className="h-10 sm:h-12 w-auto"
                    onError={e => {
                      e.currentTarget.style.display = 'none';
                    }}
                  />
                </button>

                {/* Desktop Navigation - Hidden on Mobile */}
                <div className="hidden md:flex items-center space-x-6">
                  {!state.isLoggedIn ? (
                    <>
                      <button
                        onClick={() => navigate('agents')}
                        className="text-gray-300 hover:text-white transition-colors"
                      >
                        Agents
                      </button>
                      <button
                        onClick={() => navigate('features')}
                        className="text-gray-300 hover:text-white transition-colors"
                      >
                        Features
                      </button>
                      <button
                        onClick={() => navigate('pricing')}
                        className="text-gray-300 hover:text-white transition-colors"
                      >
                        Pricing
                      </button>
                      <button
                        onClick={() => navigate('documentation')}
                        className="text-gray-300 hover:text-white transition-colors"
                      >
                        Docs
                      </button>
                      <button
                        onClick={() => navigate('support')}
                        className="text-gray-300 hover:text-white transition-colors"
                      >
                        Support
                      </button>
                      <button
                        onClick={() => navigate('toolbox')}
                        className="text-gray-300 hover:text-white transition-colors"
                      >
                        Toolbox
                      </button>
                      <button
                        onClick={() => navigate('status')}
                        className="text-gray-300 hover:text-white transition-colors"
                      >
                        Status
                      </button>
                      <button
                        onClick={() => navigate('signup')}
                        className="px-4 py-2 bg-cyan-500 text-black font-semibold rounded-lg hover:bg-cyan-400 transition-colors"
                      >
                        Sign Up
                      </button>
                    </>
                  ) : (
                    <>
                      <button
                        onClick={() => navigate('dashboard')}
                        className="px-4 py-2 bg-cyan-500 text-black font-semibold rounded-lg hover:bg-cyan-400 transition-colors"
                      >
                        Dashboard
                      </button>
                      <button
                        onClick={logout}
                        className="px-4 py-2 bg-red-500 text-white font-semibold rounded-lg hover:bg-red-400 transition-colors"
                        title="Log out of your account"
                      >
                        Log Out
                      </button>
                    </>
                  )}
                </div>

                {/* Hamburger Menu Button - Visible on Mobile Only */}
                <button
                  onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                  className="md:hidden z-50 text-white p-2 hover:bg-cyan-500/20 rounded-lg transition-colors"
                  aria-label="Toggle menu"
                >
                  <svg
                    className="w-6 h-6"
                    fill="none"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    {isMobileMenuOpen ? (
                      <path d="M6 18L18 6M6 6l12 12" />
                    ) : (
                      <path d="M4 6h16M4 12h16M4 18h16" />
                    )}
                  </svg>
                </button>
              </div>

              {/* Mobile Dropdown Menu */}
              {isMobileMenuOpen && (
                <div className="md:hidden absolute top-full left-0 right-0 bg-gradient-to-br from-gray-900 via-cyan-950/95 to-purple-950/95 backdrop-blur-xl border-b border-cyan-500/60 shadow-2xl shadow-cyan-500/20">
                  <div className="container mx-auto px-4 py-4 space-y-3">
                    {!state.isLoggedIn ? (
                      <>
                        <button
                          onClick={() => {
                            navigate('agents');
                            setIsMobileMenuOpen(false);
                          }}
                          className="block w-full text-left px-4 py-3 text-gray-300 hover:text-white hover:bg-cyan-500/10 rounded-lg transition-colors"
                        >
                          Agents
                        </button>
                        <button
                          onClick={() => {
                            navigate('features');
                            setIsMobileMenuOpen(false);
                          }}
                          className="block w-full text-left px-4 py-3 text-gray-300 hover:text-white hover:bg-cyan-500/10 rounded-lg transition-colors"
                        >
                          Features
                        </button>
                        <button
                          onClick={() => {
                            navigate('pricing');
                            setIsMobileMenuOpen(false);
                          }}
                          className="block w-full text-left px-4 py-3 text-gray-300 hover:text-white hover:bg-cyan-500/10 rounded-lg transition-colors"
                        >
                          Pricing
                        </button>
                        <button
                          onClick={() => {
                            navigate('documentation');
                            setIsMobileMenuOpen(false);
                          }}
                          className="block w-full text-left px-4 py-3 text-gray-300 hover:text-white hover:bg-cyan-500/10 rounded-lg transition-colors"
                        >
                          Docs
                        </button>
                        <button
                          onClick={() => {
                            navigate('support');
                            setIsMobileMenuOpen(false);
                          }}
                          className="block w-full text-left px-4 py-3 text-gray-300 hover:text-white hover:bg-cyan-500/10 rounded-lg transition-colors"
                        >
                          Support
                        </button>
                        <button
                          onClick={() => {
                            navigate('toolbox');
                            setIsMobileMenuOpen(false);
                          }}
                          className="block w-full text-left px-4 py-3 text-gray-300 hover:text-white hover:bg-cyan-500/10 rounded-lg transition-colors"
                        >
                          Toolbox
                        </button>
                        <button
                          onClick={() => {
                            navigate('status');
                            setIsMobileMenuOpen(false);
                          }}
                          className="block w-full text-left px-4 py-3 text-gray-300 hover:text-white hover:bg-cyan-500/10 rounded-lg transition-colors"
                        >
                          Status
                        </button>
                        <button
                          onClick={() => {
                            navigate('signup');
                            setIsMobileMenuOpen(false);
                          }}
                          className="block w-full text-left px-4 py-3 bg-cyan-500 text-black font-semibold rounded-lg hover:bg-cyan-400 transition-colors"
                        >
                          Sign Up
                        </button>
                      </>
                    ) : (
                      <>
                        <button
                          onClick={() => {
                            navigate('dashboard');
                            setIsMobileMenuOpen(false);
                          }}
                          className="block w-full text-left px-4 py-3 bg-cyan-500 text-black font-semibold rounded-lg hover:bg-cyan-400 transition-colors"
                        >
                          Dashboard
                        </button>
                        <button
                          onClick={() => {
                            logout();
                            setIsMobileMenuOpen(false);
                          }}
                          className="block w-full text-left px-4 py-3 text-gray-300 hover:text-white hover:bg-cyan-500/10 rounded-lg transition-colors"
                        >
                          Logout
                        </button>
                      </>
                    )}
                  </div>
                </div>
              )}
            </div>
          </nav>
        )}

        {/* Main Content */}
        <main id="main-content" className={shouldShowNav ? 'pt-20' : ''}>
          {renderPage()}
        </main>

        {/* Footer - Hide on agent chat pages, dashboard, and auth pages */}
        {![
          'dashboard',
          'login',
          'signup',
          'forgot-password',
          'reset-password',
          'set-new-password',
          'canvas-app',
          // All agent chat pages (ensure all are excluded)
          'ai-girlfriend',
          'agent-x',
          'auto-chat',
          'cv-smash',
          'emo-ai',
          'chat-revive',
          'pdf-mind',
          'tok-boost',
          'you-gen',
          'comedian',
          'lazy',
          'flirt',
          'sassy',
          'nerd',
          'cool',
          'zen',
          'gamer',
          // Additional agent chat page keys if any
          'agent-chat',
          // If there are any new agent chat pages, add them here
        ].includes(currentPage) && (
          <footer className="relative overflow-hidden bg-black border-t border-gray-800">
            {/* Grid Background */}
            <div className="absolute inset-0 bg-grid-gray-900 [mask-image:linear-gradient(to_bottom,white,transparent)]"></div>

            {/* Accent Glow */}
            <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[600px] h-[300px] bg-cyan-500/10 rounded-full blur-3xl"></div>

            <div className="container mx-auto px-6 py-2 relative z-10">
              {/* Row 1: Brand Section - 2 Columns */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-6 pb-4 border-b border-gray-800">
                {/* Left Column: Brand with Left Border */}
                <div className="flex items-center justify-center md:justify-start pl-0 md:pl-6 border-l-0 md:border-l-4 border-cyan-500">
                  <div>
                    <div className="mb-4">
                      <button
                        onClick={() => navigate('home')}
                        className="hover:opacity-80 transition-opacity cursor-pointer"
                        title="Go to homepage"
                      >
                        <img
                          src="/assets/iamai-logo.png"
                          alt="IA M AI Logo"
                          className="h-10 w-auto mb-4"
                          loading="lazy"
                          onError={e => {
                            e.currentTarget.style.display = 'none';
                          }}
                        />
                      </button>
                    </div>
                    <p className="text-gray-400 text-sm leading-relaxed">
                      Next-generation multi-agent AI platform for enterprises and creators.
                    </p>
                  </div>
                </div>

                {/* Right Column: Social Icons in One Row */}
                <div className="flex items-center justify-center md:justify-end space-x-3 sm:space-x-4 px-4 md:px-0">
                  <a
                    href="https://facebook.com/onelastai"
                    target="_blank"
                    rel="noopener noreferrer"
                    title="Follow us on Facebook"
                    className="text-gray-400 hover:text-blue-500 transition-colors text-2xl"
                  >
                    <i className="fab fa-facebook"></i>
                  </a>
                  <a
                    href="https://instagram.com/onelastai"
                    target="_blank"
                    rel="noopener noreferrer"
                    title="Follow us on Instagram"
                    className="text-gray-400 hover:text-pink-500 transition-colors text-2xl"
                  >
                    <i className="fab fa-instagram"></i>
                  </a>
                  <a
                    href="https://tiktok.com/@onelastai"
                    target="_blank"
                    rel="noopener noreferrer"
                    title="Follow us on TikTok"
                    className="text-gray-400 hover:text-white transition-colors text-2xl"
                  >
                    <i className="fab fa-tiktok"></i>
                  </a>
                  <a
                    href="https://t.me/onelastai"
                    target="_blank"
                    rel="noopener noreferrer"
                    title="Follow us on Telegram"
                    className="text-gray-400 hover:text-blue-400 transition-colors text-2xl"
                  >
                    <i className="fab fa-telegram"></i>
                  </a>
                  <a
                    href="https://line.me/ti/p/onelastai"
                    target="_blank"
                    rel="noopener noreferrer"
                    title="Follow us on Line"
                    className="text-gray-400 hover:text-green-500 transition-colors text-2xl"
                  >
                    <i className="fab fa-line"></i>
                  </a>
                  <a
                    href="https://x.com/onelastai"
                    target="_blank"
                    rel="noopener noreferrer"
                    title="Follow us on X"
                    className="text-gray-400 hover:text-white transition-colors text-2xl"
                  >
                    <i className="fab fa-x-twitter"></i>
                  </a>
                  <a
                    href="https://github.com/1-manarmy"
                    target="_blank"
                    rel="noopener noreferrer"
                    title="Follow us on GitHub"
                    className="text-gray-400 hover:text-gray-300 transition-colors text-2xl"
                  >
                    <i className="fab fa-github"></i>
                  </a>
                  <a
                    href="https://discord.gg/onelastai"
                    target="_blank"
                    rel="noopener noreferrer"
                    title="Join us on Discord"
                    className="text-gray-400 hover:text-indigo-500 transition-colors text-2xl"
                  >
                    <i className="fab fa-discord"></i>
                  </a>
                </div>
              </div>

              {/* Row 2: 5 Menu Columns in Single Row */}
              {/* Row 2: Menu Grid - 5 Columns */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 mb-4">
                {/* Product Column */}
                <div className="text-center md:text-left">
                  <h4 className="font-semibold text-white mb-4 flex items-center justify-center md:justify-start space-x-2">
                    <span>Product</span>
                  </h4>
                  <div className="space-y-3">
                    <button
                      onClick={() => navigate('agents')}
                      className="block w-full md:w-auto text-center md:text-left text-gray-400 hover:text-cyan-400 transition-colors text-sm font-medium"
                    >
                      → Agents
                    </button>
                    <button
                      onClick={() => navigate('features')}
                      className="block w-full md:w-auto text-center md:text-left text-gray-400 hover:text-cyan-400 transition-colors text-sm font-medium"
                    >
                      → Features
                    </button>
                    <button
                      onClick={() => navigate('pricing')}
                      className="block w-full md:w-auto text-center md:text-left text-gray-400 hover:text-cyan-400 transition-colors text-sm font-medium"
                    >
                      → Pricing
                    </button>
                    <button
                      onClick={() => navigate('templates')}
                      className="block w-full md:w-auto text-center md:text-left text-gray-400 hover:text-cyan-400 transition-colors text-sm font-medium"
                    >
                      → Templates
                    </button>
                    <button
                      onClick={() => navigate('solutions')}
                      className="block w-full md:w-auto text-center md:text-left text-gray-400 hover:text-cyan-400 transition-colors text-sm font-medium"
                    >
                      → Solutions
                    </button>
                    <button
                      onClick={() => navigate('ai-lab')}
                      className="block w-full md:w-auto text-center md:text-left text-gray-400 hover:text-cyan-400 transition-colors text-sm font-medium"
                    >
                      → AI Lab
                    </button>
                    <button
                      onClick={() => navigate('ai-studio')}
                      className="block w-full md:w-auto text-center md:text-left text-gray-400 hover:text-cyan-400 transition-colors text-sm font-medium"
                    >
                      → AI Studio
                    </button>
                    <button
                      onClick={() => navigate('reward-center')}
                      className="block w-full md:w-auto text-center md:text-left text-yellow-400 hover:text-yellow-300 transition-colors text-sm font-bold"
                    >
                      → Reward Center 🏆
                    </button>
                    <button
                      onClick={() => navigate('toolbox')}
                      className="block w-full md:w-auto text-center md:text-left text-gray-400 hover:text-cyan-400 transition-colors text-sm font-medium"
                    >
                      → Toolbox
                    </button>
                  </div>
                </div>

                {/* Resources Column */}
                <div className="text-center md:text-left">
                  <h4 className="font-semibold text-white mb-4 flex items-center justify-center md:justify-start space-x-2">
                    <span>Resources</span>
                  </h4>
                  <div className="space-y-3">
                    <button
                      onClick={() => navigate('documentation')}
                      className="block w-full md:w-auto text-center md:text-left text-gray-400 hover:text-cyan-400 transition-colors text-sm font-medium"
                    >
                      → Documentation
                    </button>
                    <button
                      onClick={() => navigate('tutorials')}
                      className="block w-full md:w-auto text-center md:text-left text-gray-400 hover:text-cyan-400 transition-colors text-sm font-medium"
                    >
                      → Tutorials
                    </button>
                    <button
                      onClick={() => navigate('blog')}
                      className="block w-full md:w-auto text-center md:text-left text-gray-400 hover:text-cyan-400 transition-colors text-sm font-medium"
                    >
                      → Blog
                    </button>
                    <button
                      onClick={() => navigate('faq')}
                      className="block w-full md:w-auto text-center md:text-left text-gray-400 hover:text-cyan-400 transition-colors text-sm font-medium"
                    >
                      → FAQ
                    </button>
                    <button
                      onClick={() => navigate('support')}
                      className="block w-full md:w-auto text-center md:text-left text-gray-400 hover:text-cyan-400 transition-colors text-sm font-medium"
                    >
                      → Support
                    </button>
                    <button
                      onClick={() => navigate('status')}
                      className="block w-full md:w-auto text-center md:text-left text-gray-400 hover:text-cyan-400 transition-colors text-sm font-medium"
                    >
                      → Status
                    </button>
                    <button
                      onClick={() => navigate('live-support')}
                      className="block w-full md:w-auto text-center md:text-left text-gray-400 hover:text-cyan-400 transition-colors text-sm font-medium"
                    >
                      → Live Chat
                    </button>
                  </div>
                </div>

                {/* Company Column */}
                <div className="text-center md:text-left">
                  <h4 className="font-semibold text-white mb-4 flex items-center justify-center md:justify-start space-x-2">
                    <span>Company</span>
                  </h4>
                  <div className="space-y-3">
                    <button
                      onClick={() => navigate('about')}
                      className="block w-full md:w-auto text-center md:text-left text-gray-400 hover:text-cyan-400 transition-colors text-sm font-medium"
                    >
                      → About
                    </button>
                    <button
                      onClick={() => navigate('careers')}
                      className="block w-full md:w-auto text-center md:text-left text-gray-400 hover:text-cyan-400 transition-colors text-sm font-medium"
                    >
                      → Careers
                    </button>
                    <button
                      onClick={() => navigate('community')}
                      className="block w-full md:w-auto text-center md:text-left text-gray-400 hover:text-cyan-400 transition-colors text-sm font-medium"
                    >
                      → Community
                    </button>
                    <button
                      onClick={() => navigate('contact')}
                      className="block w-full md:w-auto text-center md:text-left text-gray-400 hover:text-cyan-400 transition-colors text-sm font-medium"
                    >
                      → Contact
                    </button>
                    <button
                      onClick={() => navigate('partners')}
                      className="block w-full md:w-auto text-center md:text-left text-gray-400 hover:text-cyan-400 transition-colors text-sm font-medium"
                    >
                      → Partners
                    </button>
                    <button
                      onClick={() => navigate('business')}
                      className="block w-full md:w-auto text-center md:text-left text-gray-400 hover:text-cyan-400 transition-colors text-sm font-medium"
                    >
                      → For Business
                    </button>
                  </div>
                </div>

                {/* Learn & Grow Column */}
                <div className="text-center md:text-left">
                  <h4 className="font-semibold text-white mb-4 flex items-center justify-center md:justify-start space-x-2">
                    <span>Learn & Grow</span>
                  </h4>
                  <div className="space-y-3">
                    <button
                      onClick={() => navigate('education')}
                      className="block w-full md:w-auto text-center md:text-left text-gray-400 hover:text-cyan-400 transition-colors text-sm font-medium"
                    >
                      → For Education
                    </button>
                    <button
                      onClick={() => navigate('developers')}
                      className="block w-full md:w-auto text-center md:text-left text-gray-400 hover:text-cyan-400 transition-colors text-sm font-medium"
                    >
                      → Developers
                    </button>
                    <button
                      onClick={() => navigate('creator-tools')}
                      className="block w-full md:w-auto text-center md:text-left text-gray-400 hover:text-cyan-400 transition-colors text-sm font-medium"
                    >
                      → Creator Tools
                    </button>
                    <button
                      onClick={() => navigate('security')}
                      className="block w-full md:w-auto text-center md:text-left text-gray-400 hover:text-cyan-400 transition-colors text-sm font-medium"
                    >
                      → Security
                    </button>
                    <button
                      onClick={() => navigate('news')}
                      className="block w-full md:w-auto text-center md:text-left text-gray-400 hover:text-cyan-400 transition-colors text-sm font-medium"
                    >
                      → News
                    </button>
                  </div>
                </div>

                {/* Legal & Info Column */}
                <div className="text-center md:text-left">
                  <h4 className="font-semibold text-white mb-4 flex items-center justify-center md:justify-start space-x-2">
                    <span>Legal & Info</span>
                  </h4>
                  <div className="space-y-3">
                    <button
                      onClick={() => navigate('privacy')}
                      className="block w-full md:w-auto text-center md:text-left text-gray-400 hover:text-cyan-400 transition-colors text-sm font-medium"
                    >
                      → Privacy Policy
                    </button>
                    <button
                      onClick={() => navigate('terms')}
                      className="block w-full md:w-auto text-center md:text-left text-gray-400 hover:text-cyan-400 transition-colors text-sm font-medium"
                    >
                      → Terms of Service
                    </button>
                    <button
                      onClick={() => navigate('gdpr')}
                      className="block w-full md:w-auto text-center md:text-left text-gray-400 hover:text-cyan-400 transition-colors text-sm font-medium"
                    >
                      → GDPR Policy
                    </button>
                    <button
                      onClick={() => navigate('cookies')}
                      className="block w-full md:w-auto text-center md:text-left text-gray-400 hover:text-cyan-400 transition-colors text-sm font-medium"
                    >
                      → Cookies Policy
                    </button>
                    <button
                      onClick={() => navigate('payment-refund')}
                      className="block w-full md:w-auto text-center md:text-left text-gray-400 hover:text-cyan-400 transition-colors text-sm font-medium"
                    >
                      → Payment & Refund
                    </button>
                    <button
                      onClick={() => navigate('cinematic')}
                      className="block w-full md:w-auto text-center md:text-left text-gray-400 hover:text-cyan-400 transition-colors text-sm font-medium"
                    >
                      → Cinematic
                    </button>
                    <button
                      onClick={() => navigate('reports')}
                      className="block w-full md:w-auto text-center md:text-left text-gray-400 hover:text-cyan-400 transition-colors text-sm font-medium"
                    >
                      → Reports
                    </button>
                  </div>
                </div>
              </div>

              {/* Divider */}
              <div className="h-px bg-gradient-to-r from-transparent via-cyan-500/30 to-transparent mb-12"></div>

              {/* Email Subscription Section */}
              <div className="mb-2">
                <div className="max-w-2xl mx-auto">
                  <div className="relative bg-gray-900/50 border border-cyan-500/30 rounded-2xl p-8 backdrop-blur-sm hover:border-cyan-500/50 transition-colors">
                    {/* Subscription glow effect */}
                    <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/5 to-transparent rounded-2xl pointer-events-none"></div>

                    <div className="relative z-10">
                      <h3 className="text-2xl font-bold text-white mb-2 text-center">
                        ✨ Stay Updated
                      </h3>
                      <p className="text-gray-400 text-center mb-6 text-sm">
                        Get early access to new features and exclusive updates delivered to your
                        inbox.
                      </p>
                      <FooterSubscription />
                    </div>
                  </div>
                </div>
              </div>

              {/* Divider */}
              <div className="h-px bg-gradient-to-r from-transparent via-cyan-500/30 to-transparent mb-8"></div>

              {/* Mobile App Download Section - Compact Modern Design */}
              <div className="mb-6">
                <div className="max-w-3xl mx-auto">
                  <div className="text-center mb-4">
                    <h3 className="text-lg font-semibold text-white mb-1">
                      📱 Mobile App Coming Soon
                    </h3>
                    <p className="text-gray-400 text-xs">Available on iOS and Android</p>
                  </div>

                  {/* Compact App Store Badges */}
                  <div className="flex flex-col-reverse sm:flex-row gap-3 justify-center items-center">
                    {/* App Store Badge - Compact */}
                    <div className="group relative cursor-not-allowed">
                      <div className="flex items-center gap-2 bg-gray-900/50 border border-gray-700/50 rounded-lg px-4 py-2 hover:border-cyan-500/30 transition-all duration-300">
                        <div className="w-6 h-6 rounded-md bg-gray-800 flex items-center justify-center">
                          <i className="fab fa-apple text-sm text-white"></i>
                        </div>
                        <div className="text-left">
                          <p className="text-white text-xs font-medium leading-tight">App Store</p>
                          <p className="text-gray-500 text-[10px] leading-tight">iOS</p>
                        </div>
                        <span className="text-[9px] px-1.5 py-0.5 bg-cyan-500/20 text-cyan-400 rounded-full font-medium ml-1">
                          Soon
                        </span>
                      </div>
                    </div>

                    {/* Play Store Badge - Compact */}
                    <div className="group relative cursor-not-allowed">
                      <div className="flex items-center gap-2 bg-gray-900/50 border border-gray-700/50 rounded-lg px-4 py-2 hover:border-purple-500/30 transition-all duration-300">
                        <div className="w-6 h-6 rounded-md bg-gray-800 flex items-center justify-center">
                          <i className="fab fa-google-play text-sm text-white"></i>
                        </div>
                        <div className="text-left">
                          <p className="text-white text-xs font-medium leading-tight">Play Store</p>
                          <p className="text-gray-500 text-[10px] leading-tight">Android</p>
                        </div>
                        <span className="text-[9px] px-1.5 py-0.5 bg-purple-500/20 text-purple-400 rounded-full font-medium ml-1">
                          Soon
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Coming Soon Text */}
                  <p className="text-center text-gray-500 text-xs mt-3 italic">
                    Be the first to know when we launch! Subscribe above to get notified.
                  </p>
                </div>
              </div>

              {/* Divider */}
              <div className="h-px bg-gradient-to-r from-transparent via-cyan-500/30 to-transparent mb-2"></div>

              {/* Copyright Line */}
              <div className="flex items-center justify-center pl-6 border-l-4 border-cyan-500">
                <div className="text-gray-500 text-xs text-center">
                  <span>
                    © {new Date().getFullYear()} AI Digital Friend Zone. All rights reserved.
                  </span>
                </div>
              </div>
            </div>
          </footer>
        )}

        {/* Settings Modal */}
        {isSettingsOpen && (
          <SettingsModal
            isOpen={isSettingsOpen}
            onClose={closeSettings}
            apiKeys={apiKeys}
            onApiKeysChange={{
              gemini: setApiKey('gemini'),
              openai: setApiKey('openai'),
              anthropic: setApiKey('anthropic'),
            }}
          />
        )}
      </div>
    </Suspense>
  );
};

export default App;
