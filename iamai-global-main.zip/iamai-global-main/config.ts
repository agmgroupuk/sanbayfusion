import { z } from 'zod';

// Environment variable schema
const envSchema = z.object({
  // API Keys
  VITE_GEMINI_API_KEY: z.string().optional(),
  VITE_OPENAI_API_KEY: z.string().optional(),
  VITE_ANTHROPIC_API_KEY: z.string().optional(),
  VITE_GOOGLE_MAPS_API_KEY: z.string().optional(),
  VITE_IPINFO_TOKEN: z.string().optional(),
  
  // Backend
  VITE_API_URL: z.string().url().default('https://iamai.global/api'),
  
  // Environment
  VITE_APP_ENV: z.enum(['development', 'staging', 'production']).default('production'),
  
  // Feature Flags
  VITE_ENABLE_VOICE_CHAT: z.string().transform(val => val === 'true').default('true'),
  VITE_ENABLE_FILE_UPLOAD: z.string().transform(val => val === 'true').default('true'),
  VITE_ENABLE_ANALYTICS: z.string().transform(val => val === 'true').default('true'),
  
  // Authentication (Auth.js)
  VITE_NEXTAUTH_URL: z.string().url().optional(),
  
  // Payments
  VITE_STRIPE_PUBLIC_KEY: z.string().optional(),
  
  // Monitoring
  VITE_SENTRY_DSN: z.string().optional(),
  VITE_GA_TRACKING_ID: z.string().optional(),
  VITE_MIXPANEL_TOKEN: z.string().optional(),
});

type EnvConfig = z.infer<typeof envSchema>;

// Parse and validate environment variables
function loadConfig(): EnvConfig {
  try {
    const config = envSchema.parse(import.meta.env);
    return config;
  } catch (error) {
    console.error('❌ Invalid environment configuration:', error);
    // Return defaults in case of error
    return {
      VITE_API_URL: 'https://iamai.global/api',
      VITE_APP_ENV: 'production',
      VITE_ENABLE_VOICE_CHAT: true,
      VITE_ENABLE_FILE_UPLOAD: true,
      VITE_ENABLE_ANALYTICS: true,
    } as EnvConfig;
  }
}

export const config = loadConfig();

// Feature flags
export const features = {
  voiceChat: config.VITE_ENABLE_VOICE_CHAT,
  fileUpload: config.VITE_ENABLE_FILE_UPLOAD,
  analytics: config.VITE_ENABLE_ANALYTICS,
};

// API configuration
export const api = {
  baseUrl: config.VITE_API_URL,
  timeout: 30000,
};

// Google Maps API Key
export const GOOGLE_MAPS_API_KEY = config.VITE_GOOGLE_MAPS_API_KEY || 'AIzaSyDgGOPz-qmalKxSLF_G0D9XQto8VAAMzms';

// IPinfo.io API Token
export const IPINFO_TOKEN = config.VITE_IPINFO_TOKEN || '';

// Check if we're in production
export const isProd = config.VITE_APP_ENV === 'production';
export const isDev = config.VITE_APP_ENV === 'development';

// Log configuration in development
if (isDev) {
  console.log('🔧 App Configuration:', {
    env: config.VITE_APP_ENV,
    apiUrl: config.VITE_API_URL,
    features,
  });
}

export default config;
