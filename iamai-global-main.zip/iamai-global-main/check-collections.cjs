const mongoose = require('./backend/node_modules/mongoose');
require('dotenv').config({ path: './backend/.env' });

async function checkAllCollections() {
  try {
    await mongoose.connect(process.env.MONGODB_URI);
    const db = mongoose.connection.db;

    const collections = await db.listCollections().toArray();

    console.log('ALL COLLECTIONS IN DATABASE:');
    console.log('==============================');

    for (const col of collections) {
      const count = await db.collection(col.name).countDocuments();
      console.log(col.name + ': ' + count + ' documents');
    }

    const expectedCollections = [
      'users', 'agents', 'agent_purchases', 'chats', 'messages', 'conversations',
      'subscriptions', 'payments', 'webhooks', 'notifications', 'files', 'uploads',
      'analytics', 'activity_logs', 'visitors', 'system_settings', 'agentregistries',
      'canvas_projects', 'canvas_templates', 'support_tickets', 'faq', 'feedback',
      'reports', 'api_keys', 'rate_limits', 'sessions', 'user_sessions'
    ];

    console.log('\nMISSING COLLECTIONS (expected but not found):');
    console.log('===============================================');

    const existingNames = collections.map(c => c.name);
    const missing = expectedCollections.filter(name => !existingNames.includes(name));

    missing.forEach(name => console.log('- ' + name));

    await mongoose.disconnect();
  } catch (error) {
    console.error('Error:', error.message);
  }
}

checkAllCollections();