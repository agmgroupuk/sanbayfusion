const mongoose = require('./backend/node_modules/mongoose');
require('dotenv').config({ path: './backend/.env' });

async function comprehensiveCollectionAudit() {
  try {
    await mongoose.connect(process.env.MONGODB_URI);
    const db = mongoose.connection.db;

    console.log('🔍 COMPREHENSIVE DATABASE AUDIT - PROJECT REQUIREMENTS VERIFICATION');
    console.log('==================================================================\n');

    const collections = await db.listCollections().toArray();

    // Define project requirements for each collection
    const projectRequirements = {
      // Core User System
      users: {
        shouldPopulate: true,
        minDocuments: 1,
        requiredFields: ['email', 'password', 'tier', 'preferences', 'security', 'isActive'],
        fieldTypes: {
          email: 'string',
          password: 'string',
          tier: 'string',
          preferences: 'object',
          security: 'object',
          isActive: 'boolean'
        }
      },

      // Agent System
      agents: {
        shouldPopulate: true,
        minDocuments: 10,
        requiredFields: ['name', 'category', 'capabilities', 'personalityMatrix', 'pricing'],
        fieldTypes: {
          name: 'string',
          category: 'string',
          capabilities: 'object',
          personalityMatrix: 'object',
          pricing: 'object'
        }
      },

      // Chat System
      chats: {
        shouldPopulate: false,
        minDocuments: 0,
        requiredFields: ['userId', 'agentId', 'messages', 'title'],
        fieldTypes: {
          userId: 'object',
          agentId: 'string',
          messages: 'array',
          title: 'string'
        }
      },

      messages: {
        shouldPopulate: false,
        minDocuments: 0,
        requiredFields: ['chatId', 'userId', 'content', 'role'],
        fieldTypes: {
          chatId: 'object',
          userId: 'object',
          content: 'string',
          role: 'string'
        }
      },

      // Purchase System
      agent_purchases: {
        shouldPopulate: true,
        minDocuments: 5,
        requiredFields: ['userId', 'agentId', 'purchaseType', 'status', 'expiresAt'],
        fieldTypes: {
          userId: 'object',
          agentId: 'string',
          purchaseType: 'string',
          status: 'string',
          expiresAt: 'date'
        }
      },

      // Analytics System
      activity_logs: {
        shouldPopulate: true,
        minDocuments: 100,
        requiredFields: ['userId', 'action', 'route', 'ipAddress', 'sessionId'],
        fieldTypes: {
          userId: 'object',
          action: 'string',
          route: 'string',
          ipAddress: 'string',
          sessionId: 'string'
        }
      },

      visitors: {
        shouldPopulate: true,
        minDocuments: 10,
        requiredFields: ['sessionId', 'ipAddress', 'pages', 'location'],
        fieldTypes: {
          sessionId: 'string',
          ipAddress: 'string',
          pages: 'array',
          location: 'object'
        }
      },

      // System Configuration
      system_settings: {
        shouldPopulate: true,
        minDocuments: 5,
        requiredFields: ['key', 'value', 'category'],
        fieldTypes: {
          key: 'string',
          value: 'mixed',
          category: 'string'
        }
      },

      // Content Management (should have some default content)
      blog_posts: {
        shouldPopulate: true,
        minDocuments: 3,
        requiredFields: ['title', 'content', 'author', 'status', 'category'],
        fieldTypes: {
          title: 'string',
          content: 'string',
          author: 'string',
          status: 'string',
          category: 'string'
        }
      },

      faqs: {
        shouldPopulate: true,
        minDocuments: 5,
        requiredFields: ['question', 'answer', 'category', 'isPublished'],
        fieldTypes: {
          question: 'string',
          answer: 'string',
          category: 'string',
          isPublished: 'boolean'
        }
      },

      // Canvas App
      canvas_projects: {
        shouldPopulate: false,
        minDocuments: 0,
        requiredFields: ['userId', 'projectId', 'name', 'code', 'provider'],
        fieldTypes: {
          userId: 'object',
          projectId: 'string',
          name: 'string',
          code: 'string',
          provider: 'string'
        }
      },

      canvas_templates: {
        shouldPopulate: true,
        minDocuments: 6,
        requiredFields: ['templateId', 'name', 'description', 'category', 'prompt'],
        fieldTypes: {
          templateId: 'string',
          name: 'string',
          description: 'string',
          category: 'string',
          prompt: 'string'
        }
      }
    };

    let totalIssues = 0;
    let collectionsNeedingPopulation = [];
    let collectionsWithStructuralIssues = [];

    for (const collection of collections) {
      const collectionName = collection.name;
      const requirements = projectRequirements[collectionName];

      console.log(`📋 COLLECTION: ${collectionName}`);
      console.log('-'.repeat(50));

      // Get document count
      const count = await db.collection(collectionName).countDocuments();
      console.log(`Documents: ${count}`);

      if (requirements) {
        console.log(`Should Populate: ${requirements.shouldPopulate ? 'YES' : 'NO'}`);
        console.log(`Min Required: ${requirements.minDocuments}`);

        // Check population requirements
        if (requirements.shouldPopulate && count < requirements.minDocuments) {
          console.log(`❌ ISSUE: Collection should be populated but has ${count} < ${requirements.minDocuments} documents`);
          collectionsNeedingPopulation.push(collectionName);
          totalIssues++;
        } else if (!requirements.shouldPopulate && count > 0) {
          console.log(`⚠️  NOTE: Collection should not be populated but has ${count} documents`);
        } else {
          console.log(`✅ Population requirement met`);
        }

        // Check document structure if documents exist
        if (count > 0) {
          const sampleDoc = await db.collection(collectionName).findOne({});

          console.log(`\n🔍 STRUCTURE VERIFICATION:`);

          let structuralIssues = 0;
          for (const [field, expectedType] of Object.entries(requirements.fieldTypes)) {
            if (!(field in sampleDoc)) {
              console.log(`❌ MISSING FIELD: ${field} (expected: ${expectedType})`);
              structuralIssues++;
              totalIssues++;
            } else {
              const actualType = getFieldType(sampleDoc[field]);
              let typeMatches = actualType === expectedType;

              // Special cases
              if (collectionName === 'activity_logs' && field === 'userId' && actualType === 'null') {
                typeMatches = true; // null is allowed for anonymous users
              }
              if (collectionName === 'system_settings' && field === 'value' && (actualType === 'string' || actualType === 'object' || actualType === 'number' || actualType === 'boolean')) {
                typeMatches = true; // mixed types are allowed
              }

              if (!typeMatches) {
                console.log(`❌ TYPE MISMATCH: ${field} is ${actualType}, expected ${expectedType}`);
                structuralIssues++;
                totalIssues++;
              } else {
                console.log(`✅ ${field}: ${expectedType}`);
              }
            }
          }

          if (structuralIssues > 0) {
            collectionsWithStructuralIssues.push(collectionName);
          }
        }

      } else {
        console.log(`No specific project requirements defined`);
      }

      console.log(`\n`);
    }

    // Summary
    console.log(`📊 AUDIT SUMMARY`);
    console.log(`================`);
    console.log(`Total Collections: ${collections.length}`);
    console.log(`Collections Needing Population: ${collectionsNeedingPopulation.length}`);
    console.log(`Collections With Structural Issues: ${collectionsWithStructuralIssues.length}`);
    console.log(`Total Issues Found: ${totalIssues}`);

    if (collectionsNeedingPopulation.length > 0) {
      console.log(`\n🚨 COLLECTIONS NEEDING POPULATION:`);
      collectionsNeedingPopulation.forEach(name => console.log(`- ${name}`));
    }

    if (collectionsWithStructuralIssues.length > 0) {
      console.log(`\n🔧 COLLECTIONS WITH STRUCTURAL ISSUES:`);
      collectionsWithStructuralIssues.forEach(name => console.log(`- ${name}`));
    }

    await mongoose.disconnect();

  } catch (error) {
    console.error('❌ Audit error:', error.message);
  }
}

function getFieldType(value) {
  if (value === null || value === undefined) return 'null';
  if (Array.isArray(value)) return 'array';
  if (value instanceof Date) return 'date';
  if (typeof value === 'object' && value.constructor.name === 'ObjectId') return 'object';
  return typeof value;
}

comprehensiveCollectionAudit();