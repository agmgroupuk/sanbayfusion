/**
 * 🤖 AI Provider Configuration
 * Configuration for all AI service providers
 */

export const AI_CONFIG = {
  // Default Provider
  DEFAULT_PROVIDER: 'google',
  DEFAULT_MODEL: 'gemini-2.5-flash',

  // Provider Configurations
  PROVIDERS: {
    OPENAI: {
      BASE_URL: 'https://api.openai.com/v1',
      API_KEY: import.meta.env.VITE_OPENAI_API_KEY,
      MODELS: {
        'gpt-4': {
          name: 'GPT-4',
          contextWindow: 8192,
          maxTokens: 4096,
          costPer1kTokens: 0.03,
        },
        'gpt-3.5-turbo': {
          name: 'GPT-3.5 Turbo',
          contextWindow: 4096,
          maxTokens: 4096,
          costPer1kTokens: 0.002,
        },
      },
      RATE_LIMITS: {
        requestsPerMinute: 60,
        tokensPerMinute: 10000,
      },
    },

    ANTHROPIC: {
      BASE_URL: 'https://api.anthropic.com',
      API_KEY: import.meta.env.VITE_ANTHROPIC_API_KEY,
      MODELS: {
        'claude-3-opus': {
          name: 'Claude 3 Opus',
          contextWindow: 200000,
          maxTokens: 4096,
          costPer1kTokens: 0.015,
        },
        'claude-3-sonnet': {
          name: 'Claude 3 Sonnet',
          contextWindow: 200000,
          maxTokens: 4096,
          costPer1kTokens: 0.003,
        },
      },
      RATE_LIMITS: {
        requestsPerMinute: 50,
        tokensPerMinute: 40000,
      },
    },

    GOOGLE: {
      BASE_URL: 'https://generativelanguage.googleapis.com/v1beta',
      API_KEY: import.meta.env.VITE_GOOGLE_AI_API_KEY,
      MODELS: {
        'gemini-2.5-flash': {
          name: 'Gemini 2.5 Flash',
          contextWindow: 1000000,
          maxTokens: 8192,
          costPer1kTokens: 0.00015,
        },
        'gemini-pro': {
          name: 'Gemini Pro',
          contextWindow: 30720,
          maxTokens: 2048,
          costPer1kTokens: 0.0005,
        },
      },
      RATE_LIMITS: {
        requestsPerMinute: 60,
        tokensPerMinute: 32000,
      },
    },

    MISTRAL: {
      BASE_URL: 'https://api.mistral.ai/v1',
      API_KEY: import.meta.env.VITE_MISTRAL_API_KEY,
      MODELS: {
        'mistral-large': {
          name: 'Mistral Large',
          contextWindow: 32768,
          maxTokens: 8192,
          costPer1kTokens: 0.008,
        },
        'mistral-medium': {
          name: 'Mistral Medium',
          contextWindow: 32768,
          maxTokens: 8192,
          costPer1kTokens: 0.0025,
        },
      },
      RATE_LIMITS: {
        requestsPerMinute: 100,
        tokensPerMinute: 200000,
      },
    },

    OLLAMA: {
      BASE_URL: import.meta.env.VITE_OLLAMA_URL || 'http://localhost:11434',
      MODELS: {
        llama2: {
          name: 'Llama 2',
          contextWindow: 4096,
          maxTokens: 2048,
          costPer1kTokens: 0, // Local model
        },
        mistral: {
          name: 'Mistral 7B',
          contextWindow: 8192,
          maxTokens: 4096,
          costPer1kTokens: 0, // Local model
        },
      },
    },
  },

  // Global Settings
  GLOBAL: {
    MAX_RETRIES: 3,
    RETRY_DELAY: 1000, // ms
    TIMEOUT: 30000, // 30 seconds
    STREAMING: true,
    TEMPERATURE: 0.7,
    TOP_P: 0.9,
  },

  // Usage Tracking
  USAGE: {
    TRACK_TOKENS: true,
    TRACK_COSTS: true,
    TRACK_LATENCY: true,
    LOG_REQUESTS: import.meta.env.NODE_ENV === 'development',
  },
};

export default AI_CONFIG;
