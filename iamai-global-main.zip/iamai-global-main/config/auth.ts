/**
 * 🔐 Authentication Configuration
 * JWT, session, and security settings
 */

export const AUTH_CONFIG = {
  // JWT Configuration
  JWT: {
    SECRET: import.meta.env.VITE_JWT_SECRET || 'dev-secret-change-in-production',
    EXPIRES_IN: '7d',
    REFRESH_EXPIRES_IN: '30d',
    ALGORITHM: 'HS256',
    ISSUER: 'iamai.global',
    AUDIENCE: 'iamai-users',
  },

  // Session Configuration
  SESSION: {
    SECRET: import.meta.env.VITE_SESSION_SECRET || 'dev-session-secret',
    COOKIE_MAX_AGE: 24 * 60 * 60 * 1000, // 24 hours
    SECURE: import.meta.env.NODE_ENV === 'production',
    HTTP_ONLY: true,
    SAME_SITE: 'strict',
  },

  // Password Requirements
  PASSWORD: {
    MIN_LENGTH: 8,
    REQUIRE_UPPERCASE: true,
    REQUIRE_LOWERCASE: true,
    REQUIRE_NUMBERS: true,
    REQUIRE_SPECIAL_CHARS: true,
    BCRYPT_ROUNDS: 12,
  },

  // Rate Limiting
  RATE_LIMIT: {
    LOGIN_ATTEMPTS: {
      MAX_ATTEMPTS: 5,
      WINDOW_MS: 15 * 60 * 1000, // 15 minutes
      LOCKOUT_DURATION: 30 * 60 * 1000, // 30 minutes
    },
    API_REQUESTS: {
      MAX_REQUESTS: 100,
      WINDOW_MS: 60 * 1000, // 1 minute
    },
  },

  // Security Headers
  SECURITY: {
    HELMET_CONFIG: {
      contentSecurityPolicy: {
        directives: {
          defaultSrc: ["'self'"],
          scriptSrc: ["'self'", "'unsafe-inline'", 'https://js.stripe.com'],
          styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
          fontSrc: ["'self'", 'https://fonts.gstatic.com'],
          imgSrc: ["'self'", 'data:', 'https:'],
          connectSrc: ["'self'", 'https://api.stripe.com'],
        },
      },
    },
  },

  // OAuth Providers
  OAUTH: {
    GOOGLE: {
      CLIENT_ID: import.meta.env.VITE_GOOGLE_CLIENT_ID,
      CLIENT_SECRET: import.meta.env.VITE_GOOGLE_CLIENT_SECRET,
      REDIRECT_URI: `${import.meta.env.VITE_APP_URL}/auth/google/callback`,
    },
    GITHUB: {
      CLIENT_ID: import.meta.env.VITE_GITHUB_CLIENT_ID,
      CLIENT_SECRET: import.meta.env.VITE_GITHUB_CLIENT_SECRET,
      REDIRECT_URI: `${import.meta.env.VITE_APP_URL}/auth/github/callback`,
    },
  },
};

export default AUTH_CONFIG;
