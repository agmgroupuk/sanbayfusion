/**
 * 🔧 Configuration Index
 * Centralized configuration management
 */

// Core Configurations
export { default as api } from './api';
export { default as database } from './database';
export { default as auth } from './auth';
export { default as ai } from './ai';
export { default as env, isDevelopment, isProduction, isStaging, isTest } from './environment';

// Types
export type { ApiConfig } from './api';
export type { DatabaseConfig } from './database';
export type { AuthConfig } from './auth';
export type { AIConfig } from './ai';
export type { EnvironmentConfig } from './environment';

// Configuration Manager
class ConfigManager {
  private static instance: ConfigManager;
  private initialized = false;

  constructor() {
    this.initialize();
  }

  static getInstance(): ConfigManager {
    if (!ConfigManager.instance) {
      ConfigManager.instance = new ConfigManager();
    }
    return ConfigManager.instance;
  }

  private initialize(): void {
    if (this.initialized) return;

    try {
      // Initialize all configurations
      console.log('🔧 Initializing configurations...');

      // Validate environment
      if (env.isProduction() && !env.get('MONGODB_URI')) {
        throw new Error('Production environment requires MONGODB_URI');
      }

      // Log configuration status
      if (env.isDevelopment()) {
        console.log('📊 Configuration Status:');
        console.log(`- Environment: ${env.get('NODE_ENV')}`);
        console.log(`- API URL: ${env.get('API_URL')}`);
        console.log(`- Database: ${database.isConnected() ? '✅ Connected' : '❌ Disconnected'}`);
        console.log(`- Auth: ${auth.isConfigured() ? '✅ Configured' : '❌ Not configured'}`);
        console.log(`- AI Providers: ${ai.getAvailableProviders().length} available`);
      }

      this.initialized = true;
      console.log('✅ Configuration initialized successfully');
    } catch (error) {
      console.error('❌ Configuration initialization failed:', error);
      throw error;
    }
  }

  isInitialized(): boolean {
    return this.initialized;
  }

  // Health check for all configurations
  async healthCheck(): Promise<{
    status: 'healthy' | 'degraded' | 'unhealthy';
    checks: Record<string, boolean>;
    errors: string[];
  }> {
    const checks: Record<string, boolean> = {};
    const errors: string[] = [];

    try {
      // Check environment
      checks.environment = env.get('NODE_ENV') !== undefined;

      // Check database
      checks.database = await database.testConnection();
      if (!checks.database) {
        errors.push('Database connection failed');
      }

      // Check auth configuration
      checks.auth = auth.isConfigured();
      if (!checks.auth) {
        errors.push('Auth configuration incomplete');
      }

      // Check AI providers
      const availableProviders = ai.getAvailableProviders();
      checks.ai = availableProviders.length > 0;
      if (!checks.ai) {
        errors.push('No AI providers available');
      }

      // Determine overall status
      const healthyChecks = Object.values(checks).filter(Boolean).length;
      const totalChecks = Object.keys(checks).length;

      let status: 'healthy' | 'degraded' | 'unhealthy';
      if (healthyChecks === totalChecks) {
        status = 'healthy';
      } else if (healthyChecks > totalChecks / 2) {
        status = 'degraded';
      } else {
        status = 'unhealthy';
      }

      return { status, checks, errors };
    } catch (error) {
      return {
        status: 'unhealthy',
        checks,
        errors: [...errors, `Health check failed: ${error.message}`],
      };
    }
  }

  // Get configuration summary
  getSummary(): {
    environment: string;
    features: Record<string, boolean>;
    providers: {
      ai: string[];
      auth: string[];
      storage: string[];
    };
  } {
    return {
      environment: env.get('NODE_ENV') || 'unknown',
      features: {
        analytics: env.isFeatureEnabled('analytics'),
        websockets: env.isFeatureEnabled('websockets'),
        rateLimiting: env.isFeatureEnabled('rate_limiting'),
        caching: env.isFeatureEnabled('caching'),
      },
      providers: {
        ai: ai.getAvailableProviders(),
        auth: auth.getAvailableProviders(),
        storage: [], // TODO: Add storage providers
      },
    };
  }
}

// Export singleton instance
export const config = ConfigManager.getInstance();

// Export configuration validation
export const validateConfiguration = async (): Promise<boolean> => {
  try {
    const health = await config.healthCheck();

    if (health.status === 'unhealthy') {
      console.error('Configuration validation failed:', health.errors);
      return false;
    }

    if (health.status === 'degraded') {
      console.warn('Configuration has issues:', health.errors);
    }

    return true;
  } catch (error) {
    console.error('Configuration validation error:', error);
    return false;
  }
};

// Export initialization helper
export const initializeConfiguration = async (): Promise<void> => {
  if (!config.isInitialized()) {
    throw new Error('Configuration not initialized');
  }

  const isValid = await validateConfiguration();
  if (!isValid && env.isProduction()) {
    throw new Error('Invalid configuration in production environment');
  }
};

export default config;
