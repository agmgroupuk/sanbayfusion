/**
 * 🔧 Database Configuration
 * MongoDB connection and configuration settings
 */

export const DB_CONFIG = {
  // MongoDB Atlas Configuration
  MONGODB_URI: import.meta.env.VITE_MONGODB_URI || 'mongodb://localhost:27017/iamai-local',
  DB_NAME: import.meta.env.VITE_DB_NAME || 'iamai-global',

  // Connection Options
  CONNECTION_OPTIONS: {
    maxPoolSize: 10,
    serverSelectionTimeoutMS: 5000,
    socketTimeoutMS: 45000,
    bufferMaxEntries: 0,
    bufferCommands: false,
  },

  // Collections
  COLLECTIONS: {
    USERS: 'users',
    AGENTS: 'agents',
    CHATS: 'chats',
    SUBSCRIPTIONS: 'subscriptions',
    ANALYTICS: 'analytics',
    SESSIONS: 'sessions',
    TRANSACTIONS: 'transactions',
    SUPPORT_TICKETS: 'supportTickets',
    ACTIVITY_LOGS: 'activityLogs',
    USER_PROFILES: 'userProfiles',
    USAGE_ANALYTICS: 'usageAnalytics',
  },

  // Indexes for Performance
  INDEXES: {
    USERS: [{ email: 1 }, { stripeCustomerId: 1 }, { 'security.activeSessions.sessionId': 1 }],
    CHATS: [{ userId: 1, agentId: 1 }, { createdAt: -1 }],
    ANALYTICS: [
      { userId: 1, date: -1 },
      { agentId: 1, date: -1 },
    ],
  },
};

export default DB_CONFIG;
