/**
 * API Configuration
 * Centralized API URL management for all environments
 */

// Get API base URL from environment variables
// In production (.env.production): VITE_API_URL=/api (relative path through Nginx proxy)
// In development (.env.development): VITE_API_URL=http://localhost:5000
export const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000';

// Get WebSocket URL from environment variables
export const WS_BASE_URL = import.meta.env.VITE_WS_URL || API_BASE_URL;

/**
 * Helper function to build full API URLs
 * @param endpoint - API endpoint path (e.g., '/auth/login')
 * @returns Full API URL
 */
export const getApiUrl = (endpoint: string): string => {
  // Remove leading slash from endpoint to avoid double slashes
  const cleanEndpoint = endpoint.startsWith('/') ? endpoint.slice(1) : endpoint;
  // Remove trailing slash from base URL
  const base = API_BASE_URL.replace(/\/$/, '');
  return `${base}/${cleanEndpoint}`;
};

/**
 * Helper function for making API requests with HttpOnly cookie authentication
 * @param endpoint - API endpoint path
 * @param options - Fetch options
 * @returns Fetch response
 */
export const apiRequest = async (endpoint: string, options?: RequestInit) => {
  const url = getApiUrl(endpoint);
  const defaultHeaders = {
    'Content-Type': 'application/json',
  };

  return fetch(url, {
    ...options,
    credentials: 'include', // Include HttpOnly cookies automatically
    headers: {
      ...defaultHeaders,
      ...options?.headers,
    },
  });
};

export default {
  API_BASE_URL,
  WS_BASE_URL,
  getApiUrl,
  apiRequest,
};
