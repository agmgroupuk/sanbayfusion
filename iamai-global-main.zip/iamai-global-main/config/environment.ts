/**
 * 🌍 Production Environment Configuration
 * Enhanced configuration management for production deployment
 */

export interface EnvironmentConfig {
  // Application
  NODE_ENV: 'development' | 'production' | 'staging' | 'test';
  APP_NAME: string;
  APP_VERSION: string;
  APP_URL: string;
  API_URL: string;
  WS_URL: string;

  // Database
  MONGODB_URI: string;
  MONGODB_DB_NAME: string;

  // Authentication
  JWT_SECRET: string;
  JWT_REFRESH_SECRET: string;
  JWT_EXPIRES_IN: string;
  JWT_REFRESH_EXPIRES_IN: string;
  SESSION_SECRET: string;

  // OAuth Providers
  GOOGLE_CLIENT_ID?: string;
  GOOGLE_CLIENT_SECRET?: string;
  FACEBOOK_APP_ID?: string;
  FACEBOOK_APP_SECRET?: string;
  TWITTER_API_KEY?: string;
  TWITTER_API_SECRET?: string;

  // AI Providers
  OPENAI_API_KEY?: string;
  ANTHROPIC_API_KEY?: string;
  GEMINI_API_KEY?: string;
  REPLICATE_API_TOKEN?: string;
  HUGGINGFACE_API_KEY?: string;

  // Payment Processing (Stripe)
  STRIPE_PUBLIC_KEY?: string;
  STRIPE_SECRET_KEY?: string;
  STRIPE_WEBHOOK_SECRET?: string;

  // Email Services
  SENDGRID_API_KEY?: string;
  SMTP_HOST?: string;
  SMTP_PORT?: string;
  SMTP_USER?: string;
  SMTP_PASS?: string;
  EMAIL_FROM?: string;

  // Storage
  STORAGE_TYPE: 'local' | 's3' | 'cloudinary';
  AWS_ACCESS_KEY_ID?: string;
  AWS_SECRET_ACCESS_KEY?: string;
  AWS_REGION?: string;
  AWS_S3_BUCKET?: string;
  CLOUDINARY_CLOUD_NAME?: string;
  CLOUDINARY_API_KEY?: string;
  CLOUDINARY_API_SECRET?: string;

  // Redis Configuration
  REDIS_URL?: string;
  REDIS_HOST?: string;
  REDIS_PORT?: string;
  REDIS_PASSWORD?: string;

  // Analytics & Monitoring
  GOOGLE_ANALYTICS_ID?: string;
  SENTRY_DSN?: string;
  MIXPANEL_TOKEN?: string;

  // Rate Limiting
  RATE_LIMIT_WINDOW_MS?: string;
  RATE_LIMIT_MAX_REQUESTS?: string;

  // Application Limits
  MAX_FILE_SIZE?: string;
  MAX_UPLOAD_FILES?: string;

  // Security
  CORS_ORIGINS?: string;
  HELMET_CSP?: string;
  BCRYPT_ROUNDS?: string;

  // Feature Flags
  ENABLE_ANALYTICS?: string;
  ENABLE_NOTIFICATIONS?: string;
  ENABLE_FILE_UPLOADS?: string;
  ENABLE_SUBSCRIPTIONS?: string;
  ENABLE_WEBSOCKETS?: string;
  ENABLE_RATE_LIMITING?: string;
  ENABLE_CACHING?: string;

  // Server Configuration
  PORT?: string;
  HOST?: string;

  // SSL/TLS
  SSL_CERT_PATH?: string;
  SSL_KEY_PATH?: string;

  // Production Deployment
  DEPLOYMENT_URL?: string;
  BUILD_ID?: string;

  // Development
  DEBUG?: string;
  LOG_LEVEL?: string;
  LOG_FILE?: string;
  MOCK_DATA?: string;
}

class EnvironmentManager {
  private static instance: EnvironmentManager;
  private config: Partial<EnvironmentConfig> = {};

  constructor() {
    this.loadEnvironmentVariables();
    this.validateRequiredVariables();
  }

  static getInstance(): EnvironmentManager {
    if (!EnvironmentManager.instance) {
      EnvironmentManager.instance = new EnvironmentManager();
    }
    return EnvironmentManager.instance;
  }

  private loadEnvironmentVariables(): void {
    // In browser environment, use import.meta.env
    if (typeof window !== 'undefined') {
      this.config = {
        NODE_ENV: (import.meta.env.VITE_NODE_ENV || 'development') as any,
        APP_NAME: import.meta.env.VITE_APP_NAME || 'iAMAI Global',
        APP_VERSION: import.meta.env.VITE_APP_VERSION || '1.0.0',
        APP_URL: import.meta.env.VITE_APP_URL || 'http://localhost:5173',
        API_URL:
          import.meta.env.VITE_API_URL ||
          (typeof window !== 'undefined' && window.location.hostname === 'localhost'
            ? 'http://localhost:3001'
            : 'https://iamai.global'),
        WS_URL:
          import.meta.env.VITE_WS_URL ||
          (typeof window !== 'undefined' && window.location.hostname === 'localhost'
            ? 'http://localhost:3001'
            : 'https://iamai.global'),

        // Public keys only in browser
        GOOGLE_CLIENT_ID: import.meta.env.VITE_GOOGLE_CLIENT_ID,
        FACEBOOK_APP_ID: import.meta.env.VITE_FACEBOOK_APP_ID,
        STRIPE_PUBLIC_KEY: import.meta.env.VITE_STRIPE_PUBLIC_KEY,
        GOOGLE_ANALYTICS_ID: import.meta.env.VITE_GOOGLE_ANALYTICS_ID,
        SENTRY_DSN: import.meta.env.VITE_SENTRY_DSN,
        MIXPANEL_TOKEN: import.meta.env.VITE_MIXPANEL_TOKEN,

        // Feature flags
        ENABLE_ANALYTICS: import.meta.env.VITE_ENABLE_ANALYTICS || 'true',
        ENABLE_WEBSOCKETS: import.meta.env.VITE_ENABLE_WEBSOCKETS || 'true',
        ENABLE_NOTIFICATIONS: import.meta.env.VITE_ENABLE_NOTIFICATIONS || 'true',
        ENABLE_FILE_UPLOADS: import.meta.env.VITE_ENABLE_FILE_UPLOADS || 'true',
        ENABLE_SUBSCRIPTIONS: import.meta.env.VITE_ENABLE_SUBSCRIPTIONS || 'true',
        ENABLE_WEBSOCKETS: import.meta.env.VITE_ENABLE_WEBSOCKETS || 'true',
        DEBUG: import.meta.env.VITE_DEBUG || 'false',
      };
    } else {
      // Node.js environment
      this.config = {
        NODE_ENV: (process.env.NODE_ENV || 'development') as any,
        APP_NAME: process.env.APP_NAME || 'iAMAI Global',
        APP_VERSION: process.env.APP_VERSION || '1.0.0',
        APP_URL: process.env.APP_URL || 'https://iamai.global',
        API_URL: process.env.API_URL || 'https://iamai.global/api',

        // Database
        MONGODB_URI: process.env.MONGODB_URI || 'mongodb://localhost:27017/iamai',
        MONGODB_DB_NAME: process.env.MONGODB_DB_NAME || 'iamai',

        // Authentication
        JWT_SECRET: process.env.JWT_SECRET || 'your-jwt-secret-key',
        JWT_REFRESH_SECRET: process.env.JWT_REFRESH_SECRET || 'your-jwt-refresh-secret',
        JWT_EXPIRES_IN: process.env.JWT_EXPIRES_IN || '15m',
        JWT_REFRESH_EXPIRES_IN: process.env.JWT_REFRESH_EXPIRES_IN || '7d',

        // OAuth
        GOOGLE_CLIENT_ID: process.env.GOOGLE_CLIENT_ID,
        GOOGLE_CLIENT_SECRET: process.env.GOOGLE_CLIENT_SECRET,
        FACEBOOK_APP_ID: process.env.FACEBOOK_APP_ID,
        FACEBOOK_APP_SECRET: process.env.FACEBOOK_APP_SECRET,

        // AI Providers
        OPENAI_API_KEY: process.env.OPENAI_API_KEY,
        ANTHROPIC_API_KEY: process.env.ANTHROPIC_API_KEY,
        GEMINI_API_KEY: process.env.GEMINI_API_KEY,

        // Email
        SENDGRID_API_KEY: process.env.SENDGRID_API_KEY,
        SMTP_HOST: process.env.SMTP_HOST,
        SMTP_PORT: process.env.SMTP_PORT,
        SMTP_USER: process.env.SMTP_USER,
        SMTP_PASS: process.env.SMTP_PASS,

        // Storage
        AWS_ACCESS_KEY_ID: process.env.AWS_ACCESS_KEY_ID,
        AWS_SECRET_ACCESS_KEY: process.env.AWS_SECRET_ACCESS_KEY,
        AWS_REGION: process.env.AWS_REGION || 'us-east-1',
        AWS_S3_BUCKET: process.env.AWS_S3_BUCKET,

        // Payment
        STRIPE_SECRET_KEY: process.env.STRIPE_SECRET_KEY,
        STRIPE_WEBHOOK_SECRET: process.env.STRIPE_WEBHOOK_SECRET,

        // Security & Performance
        CORS_ORIGIN: process.env.CORS_ORIGIN || '*',
        RATE_LIMIT_WINDOW_MS: process.env.RATE_LIMIT_WINDOW_MS || '900000', // 15 minutes
        RATE_LIMIT_MAX_REQUESTS: process.env.RATE_LIMIT_MAX_REQUESTS || '100',
        BCRYPT_ROUNDS: process.env.BCRYPT_ROUNDS || '12',

        // Features
        ENABLE_ANALYTICS: process.env.ENABLE_ANALYTICS || 'true',
        ENABLE_WEBSOCKETS: process.env.ENABLE_WEBSOCKETS || 'true',
        ENABLE_RATE_LIMITING: process.env.ENABLE_RATE_LIMITING || 'true',
        ENABLE_CACHING: process.env.ENABLE_CACHING || 'true',

        // Development
        DEBUG: process.env.DEBUG || 'false',
        LOG_LEVEL: process.env.LOG_LEVEL || 'info',
        MOCK_DATA: process.env.MOCK_DATA || 'false',
      };
    }
  }

  private validateRequiredVariables(): void {
    const required: (keyof EnvironmentConfig)[] = ['NODE_ENV', 'APP_NAME', 'API_URL'];

    // Additional required variables in production
    if (this.config.NODE_ENV === 'production') {
      required.push('MONGODB_URI', 'JWT_SECRET', 'JWT_REFRESH_SECRET');
    }

    const missing = required.filter(key => !this.config[key]);

    if (missing.length > 0) {
      const errorMessage = `Missing required environment variables: ${missing.join(', ')}`;
      console.error('Environment Configuration Error:', errorMessage);

      if (this.config.NODE_ENV === 'production') {
        throw new Error(errorMessage);
      }
    }
  }

  get<T extends keyof EnvironmentConfig>(key: T): EnvironmentConfig[T] | undefined {
    return this.config[key];
  }

  getRequired<T extends keyof EnvironmentConfig>(key: T): NonNullable<EnvironmentConfig[T]> {
    const value = this.config[key];
    if (value === undefined || value === null || value === '') {
      throw new Error(`Required environment variable "${key}" is not set`);
    }
    return value as NonNullable<EnvironmentConfig[T]>;
  }

  set<T extends keyof EnvironmentConfig>(key: T, value: EnvironmentConfig[T]): void {
    this.config[key] = value;
  }

  isDevelopment(): boolean {
    return this.config.NODE_ENV === 'development';
  }

  isProduction(): boolean {
    return this.config.NODE_ENV === 'production';
  }

  isStaging(): boolean {
    return this.config.NODE_ENV === 'staging';
  }

  isTest(): boolean {
    return this.config.NODE_ENV === 'test';
  }

  isFeatureEnabled(feature: string): boolean {
    const key = `ENABLE_${feature.toUpperCase()}` as keyof EnvironmentConfig;
    const value = this.config[key];
    return value === 'true' || value === '1' || value === 'yes';
  }

  getConfig(): Readonly<Partial<EnvironmentConfig>> {
    return Object.freeze({ ...this.config });
  }

  // Production validation
  validateProductionConfig(): string[] {
    const errors: string[] = [];

    if (this.isProduction()) {
      // Required in production
      const requiredKeys: Array<keyof EnvironmentConfig> = [
        'JWT_SECRET',
        'JWT_REFRESH_SECRET',
        'SESSION_SECRET',
        'MONGODB_URI',
      ];

      requiredKeys.forEach(key => {
        if (!this.config[key] || this.config[key]?.includes('development')) {
          errors.push(`${key} must be set to a secure production value`);
        }
      });

      // Validate subscription setup if enabled
      if (this.isFeatureEnabled('SUBSCRIPTIONS')) {
        if (!this.config.STRIPE_SECRET_KEY) {
          errors.push('STRIPE_SECRET_KEY is required when subscriptions are enabled');
        }
      }

      // Validate storage setup if file uploads enabled
      if (this.isFeatureEnabled('FILE_UPLOADS')) {
        const storageType = this.config.STORAGE_TYPE;
        if (
          storageType === 's3' &&
          (!this.config.AWS_ACCESS_KEY_ID || !this.config.AWS_S3_BUCKET)
        ) {
          errors.push('AWS credentials required for S3 storage');
        }
        if (storageType === 'cloudinary' && !this.config.CLOUDINARY_CLOUD_NAME) {
          errors.push('Cloudinary credentials required for Cloudinary storage');
        }
      }
    }

    return errors;
  }

  // Get database configuration
  getDatabaseConfig() {
    return {
      uri: this.getRequired('MONGODB_URI'),
      dbName: this.config.MONGODB_DB_NAME || 'iamai-global',
      options: {
        maxPoolSize: this.isProduction() ? 10 : 5,
        serverSelectionTimeoutMS: 5000,
        socketTimeoutMS: 45000,
      },
    };
  }

  // Get Redis configuration
  getRedisConfig() {
    const redisUrl = this.config.REDIS_URL;
    if (redisUrl) return redisUrl;

    return {
      host: this.config.REDIS_HOST || 'localhost',
      port: parseInt(this.config.REDIS_PORT || '6379'),
      password: this.config.REDIS_PASSWORD || undefined,
    };
  }

  // Get storage configuration
  getStorageConfig() {
    const type = this.config.STORAGE_TYPE || 'local';

    switch (type) {
      case 's3':
        return {
          type: 's3',
          accessKeyId: this.getRequired('AWS_ACCESS_KEY_ID'),
          secretAccessKey: this.getRequired('AWS_SECRET_ACCESS_KEY'),
          region: this.config.AWS_REGION || 'us-east-1',
          bucket: this.getRequired('AWS_S3_BUCKET'),
        };

      case 'cloudinary':
        return {
          type: 'cloudinary',
          cloudName: this.getRequired('CLOUDINARY_CLOUD_NAME'),
          apiKey: this.getRequired('CLOUDINARY_API_KEY'),
          apiSecret: this.getRequired('CLOUDINARY_API_SECRET'),
        };

      default:
        return { type: 'local', uploadDir: './uploads' };
    }
  }

  // Debug helper
  logConfig(includeSecrets = false): void {
    const configCopy = { ...this.config };

    if (!includeSecrets) {
      const secretKeys = [
        'JWT_SECRET',
        'JWT_REFRESH_SECRET',
        'SESSION_SECRET',
        'MONGODB_URI',
        'GOOGLE_CLIENT_SECRET',
        'FACEBOOK_APP_SECRET',
        'OPENAI_API_KEY',
        'ANTHROPIC_API_KEY',
        'GEMINI_API_KEY',
        'STRIPE_SECRET_KEY',
        'STRIPE_WEBHOOK_SECRET',
        'SENDGRID_API_KEY',
        'SMTP_PASS',
        'AWS_SECRET_ACCESS_KEY',
        'CLOUDINARY_API_SECRET',
        'REDIS_PASSWORD',
      ];

      secretKeys.forEach(key => {
        if (configCopy[key as keyof EnvironmentConfig]) {
          (configCopy as any)[key] = '***REDACTED***';
        }
      });
    }

    console.table(configCopy);
  }
}

// Export singleton instance
export const env = EnvironmentManager.getInstance();

// Export helper functions
export const isDevelopment = () => env.isDevelopment();
export const isProduction = () => env.isProduction();
export const isStaging = () => env.isStaging();
export const isTest = () => env.isTest();

export default env;
