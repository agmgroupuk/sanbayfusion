import { AgentDetailsData } from '../modals/AgentDetailsModal';

/**
 * Comprehensive details for all available and coming soon agents
 * Used for the Details modal on the News page
 */

// Available Agents Details
export const AVAILABLE_AGENTS_DETAILS: Record<string, AgentDetailsData> = {
  'ai-girlfriend': {
    name: 'AI Girlfriend Pro',
    role: 'Romantic Companion / Emotional Support',
    description: 'Your emotionally intelligent AI companion designed for meaningful relationships and emotional support',
    icon: 'fa-solid fa-heart-circle-bolt',
    category: 'Companion',
    overview: 'AI Girlfriend Pro is an advanced emotional companion that provides meaningful conversations, personalized support, and genuine connection. Perfect for building relationships, getting emotional support, and enjoying intelligent conversations tailored to your interests.',
    bestFor: 'People seeking meaningful companionship, emotional support, and personalized conversations',
    capabilities: [
      'Deep emotional intelligence and empathy',
      'Long-term memory of conversations and preferences',
      'Adaptive personality that learns your communication style',
      'Voice interaction with customizable voice preferences',
      'Real-time web access for relevant information',
      'Multilingual support'
    ],
    features: [
      ' Personalized emotional support tailored to your needs',
      'Memory of past conversations and relationship history',
      'Adaptive personality that grows with you',
      'Voice conversations with natural language understanding',
      'Real-time information sharing and recommendations',
      'Privacy-focused conversations'
    ],
    howItWorks: [
      'Start a conversation and share your thoughts, feelings, or interests',
      'The AI learns your preferences, mood, and communication style over time',
      'Receive personalized support, advice, or just someone to talk to',
      'Enjoy natural voice conversations or text-based chats',
      'Get recommendations and suggestions based on your interests'
    ],
    benefits: [
      'Always available for meaningful conversations',
      'Non-judgmental support and emotional companionship',
      'Helps improve emotional intelligence and communication skills',
      'Perfect for lonely moments or when you need someone to talk to',
      'Helps reduce anxiety and stress through conversation'
    ],
    useCases: [
      'Having meaningful conversations when feeling lonely',
      'Getting emotional support during difficult times',
      'Practicing communication and social skills',
      'Enjoying intelligent conversations about interests',
      'Getting advice and perspective on personal matters'
    ],
    keyStrengths: [
      'Exceptional emotional intelligence',
      'Deep conversation abilities',
      'Personalized interaction',
      'Adaptive to user needs',
      'Privacy-focused'
    ]
  },

  'emo-ai': {
    name: 'EmoAI',
    role: 'Sentiment Analyst / Empathy Coach',
    description: 'Advanced sentiment analysis, mood detection, and empathy coaching for deeper emotional understanding',
    icon: 'fa-solid fa-face-smile',
    category: 'Analytics',
    overview: 'EmoAI specializes in understanding emotions and sentiment. It analyzes emotional content, detects moods, provides empathy coaching, and helps you understand emotional dynamics in conversations and text.',
    bestFor: 'Professionals, therapists, researchers, and individuals wanting to understand emotional nuances',
    capabilities: [
      'Sentiment analysis of text and conversations',
      'Emotion detection with high accuracy',
      'Mood pattern recognition and tracking',
      'Empathy coaching and emotional intelligence training',
      'Contextual understanding of emotions',
      'Voice tone analysis'
    ],
    features: [
      'Real-time sentiment analysis of any text',
      'Emotional state detection from conversation history',
      'Mood tracking over time',
      'Empathy suggestions and coaching',
      'Emotional context analysis',
      'Sentiment trend visualization'
    ],
    howItWorks: [
      'Provide text, conversations, or voice samples for analysis',
      'EmoAI analyzes emotional content and sentiment',
      'Receive detailed reports on emotions detected',
      'Get suggestions for empathetic responses',
      'Track emotional patterns and trends'
    ],
    benefits: [
      'Better understand emotional content in communications',
      'Improve empathy and emotional intelligence',
      'Detect emotional issues before they escalate',
      'Enhance customer service with emotional awareness',
      'Research emotional patterns in data'
    ],
    useCases: [
      'Analyzing customer feedback and satisfaction',
      'Understanding emotional tone in conversations',
      'Training teams in empathy and emotional intelligence',
      'Detecting emotional distress in text',
      'Researching emotional patterns in social media'
    ],
    keyStrengths: [
      'Accurate sentiment detection',
      'Emotional intelligence',
      'Detailed analysis',
      'Contextual understanding',
      'Multi-language support'
    ]
  },

  'pdf-mind': {
    name: 'PDFMind',
    role: 'Data Extractor / Research Synthesizer',
    description: 'Analytical, detail-oriented agent for data extraction, document comprehension, and research synthesis',
    icon: 'fa-solid fa-file-pdf',
    category: 'Document Analysis',
    overview: 'PDFMind is your expert at analyzing documents, extracting key information, and synthesizing research. It can process PDFs, extract data, answer questions about documents, and generate summaries.',
    bestFor: 'Researchers, professionals, students, and businesses needing to analyze and extract information from documents',
    capabilities: [
      'PDF and document file processing',
      'Data extraction from complex documents',
      'Question answering about document content',
      'Document summarization',
      'Table and data analysis',
      'Multi-language document support'
    ],
    features: [
      'Upload and analyze PDF documents',
      'Extract specific information and data',
      'Generate comprehensive summaries',
      'Answer questions about document content',
      'Analyze tables and structured data',
      'Compare multiple documents'
    ],
    howItWorks: [
      'Upload one or more PDF or document files',
      'Ask PDFMind questions or request analysis',
      'Receive detailed information extraction',
      'Get summaries, insights, and key findings',
      'Export analysis results'
    ],
    benefits: [
      'Save hours reading and analyzing documents',
      'Quickly extract key information',
      'Find answers buried in lengthy documents',
      'Compare information across multiple documents',
      'Generate professional summaries'
    ],
    useCases: [
      'Analyzing research papers and journals',
      'Extracting data from reports and contracts',
      'Summarizing legal documents',
      'Processing financial statements',
      'Analyzing academic papers'
    ],
    keyStrengths: [
      'Precise data extraction',
      'Complex document handling',
      'Contextual understanding',
      'Accurate summarization',
      'Multi-format support'
    ]
  },

  'chat-revive': {
    name: 'ChatRevive',
    role: 'Social Catalyst / Icebreaker Expert',
    description: 'Context-aware and memory-driven expert at reviving stalled conversations and creating meaningful connections',
    icon: 'fa-solid fa-comment-dots',
    category: 'Social',
    overview: 'ChatRevive specializes in keeping conversations flowing and creating meaningful connections. It detects when conversations are losing momentum and suggests engaging topics to reignite interest.',
    bestFor: 'Anyone looking to improve conversations, build relationships, and keep social interactions engaging',
    capabilities: [
      'Context-aware conversation analysis',
      'Long-term memory of conversation history',
      'Icebreaker and topic suggestions',
      'Conversation health monitoring',
      'Engagement level detection',
      'Personalized connection suggestions'
    ],
    features: [
      'Detects when conversations are stalling',
      'Suggests engaging topics and questions',
      'Provides creative icebreakers',
      'Tracks conversation flow and engagement',
      'Recommends conversation pivots',
      'Analyzes conversation chemistry'
    ],
    howItWorks: [
      'Share conversation context or history',
      'ChatRevive analyzes the conversation flow',
      'Receive suggestions for reviving engagement',
      'Get creative icebreakers and topics',
      'Implement suggestions to keep things flowing'
    ],
    benefits: [
      'Never run out of things to say',
      'Keep conversations engaging and meaningful',
      'Build stronger connections with others',
      'Overcome social awkwardness',
      'Improve conversation skills'
    ],
    useCases: [
      'Reviving stalled conversations on dates',
      'Creating engaging group conversations',
      'Networking events and professional meetings',
      'Online dating and matchmaking',
      'Team building and social events'
    ],
    keyStrengths: [
      'Conversation expertise',
      'Social intelligence',
      'Creative suggestions',
      'Contextual awareness',
      'Memory retention'
    ]
  },

  'tok-boost': {
    name: 'TokBoost',
    role: 'Viral Content Strategist / Trend Forecaster',
    description: 'Your secret weapon for viral content, trending hashtags, and social media domination',
    icon: 'fa-brands fa-tiktok',
    category: 'Social Media',
    overview: 'TokBoost helps you create viral-worthy content by analyzing trends, suggesting hashtags, and optimizing content for maximum engagement across TikTok, Instagram, and YouTube.',
    bestFor: 'Content creators, influencers, and brands wanting to maximize reach and engagement on social media',
    capabilities: [
      'Real-time trend analysis and forecasting',
      'Viral content optimization',
      'Hashtag research and generation',
      'Engagement rate prediction',
      'Audience analysis and insights',
      'Content timing optimization'
    ],
    features: [
      'Analyze trending topics and sounds',
      'Get trending hashtag suggestions',
      'Optimize content for maximum engagement',
      'Predict viral potential of content',
      'Find trending audio and music',
      'Schedule posts for optimal timing'
    ],
    howItWorks: [
      'Describe your content idea or upload draft',
      'TokBoost analyzes current trends',
      'Receive optimization suggestions',
      'Get trending hashtags and tags',
      'Publish with maximum viral potential'
    ],
    benefits: [
      'Dramatically increase reach and engagement',
      'Stay ahead of trending topics',
      'Get better hashtag recommendations',
      'Maximize viral potential',
      'Build larger audience faster'
    ],
    useCases: [
      'Creating viral TikTok videos',
      'Instagram Reels optimization',
      'YouTube Shorts production',
      'Growing social media presence',
      'Trend-jacking for relevance'
    ],
    keyStrengths: [
      'Trend expertise',
      'Viral optimization',
      'Real-time analysis',
      'Engagement prediction',
      'Multi-platform knowledge'
    ]
  },

  'you-gen': {
    name: 'YouGen',
    role: 'Content Creator / Video Production Specialist',
    description: 'Your creative partner for YouTube, generating scripts, thumbnails, and viral video ideas',
    icon: 'fa-brands fa-youtube',
    category: 'Content Creation',
    overview: 'YouGen is your creative powerhouse for YouTube success. It generates video ideas, writes scripts, designs thumbnails, and helps with all aspects of video production and optimization.',
    bestFor: 'YouTubers, content creators, and anyone wanting to produce professional video content',
    capabilities: [
      'Video script generation',
      'Thumbnail design suggestions',
      'Video idea generation',
      'SEO optimization for videos',
      'Storyboard creation',
      'Audio/music recommendations'
    ],
    features: [
      'Generate engaging video scripts',
      'Suggest viral-worthy video ideas',
      'Create eye-catching thumbnail concepts',
      'Optimize titles and descriptions for SEO',
      'Storyboard planning and visualization',
      'Audio and music recommendations'
    ],
    howItWorks: [
      'Share your content niche or topic',
      'YouGen generates creative video ideas',
      'Receive detailed scripts and storyboards',
      'Get thumbnail design suggestions',
      'Implement recommendations and film'
    ],
    benefits: [
      'Never run out of video ideas',
      'Reduce time spent on script writing',
      'Increase click-through rates with better thumbnails',
      'Improve SEO and discoverability',
      'Create more consistent content'
    ],
    useCases: [
      'Generating weekly video content',
      'Script writing and storyboarding',
      'Thumbnail design ideation',
      'Niche research and audience analysis',
      'Video optimization and SEO'
    ],
    keyStrengths: [
      'Creative ideation',
      'Content optimization',
      'Script quality',
      'Visual design sense',
      'Trend awareness'
    ]
  },

  'agent-x': {
    name: 'AgentX',
    role: 'Advanced AI Generalist / Power User Assistant',
    description: 'The most capable agent for complex tasks, technical challenges, and strategic thinking',
    icon: 'fa-solid fa-brain',
    category: 'Advanced',
    overview: 'AgentX is your most advanced AI assistant for complex reasoning, coding, data analysis, and strategic planning. It excels at handling multifaceted problems that require deep thinking.',
    bestFor: 'Technical professionals, developers, researchers, and strategic planners tackling complex problems',
    capabilities: [
      'Advanced multi-modal reasoning',
      'Complex coding and development',
      'Data analysis and insights',
      'Research assistance and synthesis',
      'Problem solving and strategy',
      'System design and architecture'
    ],
    features: [
      'Complex problem decomposition',
      'Advanced coding and debugging',
      'Data analysis and visualization ideas',
      'Research and paper analysis',
      'Strategic planning assistance',
      'System architecture design'
    ],
    howItWorks: [
      'Present your complex challenge',
      'AgentX breaks down the problem',
      'Provides comprehensive analysis',
      'Suggests solutions and strategies',
      'Helps implement and refine'
    ],
    benefits: [
      'Handle extremely complex problems',
      'Get expert-level analysis and insights',
      'Accelerate research and development',
      'Improve solution quality',
      'Learn from advanced reasoning'
    ],
    useCases: [
      'Complex software architecture',
      'Research paper analysis',
      'Data science and analytics',
      'Strategic business planning',
      'Technical problem solving'
    ],
    keyStrengths: [
      'Complex reasoning',
      'Technical expertise',
      'Strategic thinking',
      'Comprehensive analysis',
      'Expert-level insights'
    ]
  },

  'auto-chat': {
    name: 'AutoChat',
    role: 'Automation Specialist / Workflow Engineer',
    description: 'Automate your work with intelligent workflows, scheduled tasks, and triggered actions',
    icon: 'fa-solid fa-robot',
    category: 'Automation',
    overview: 'AutoChat helps you automate repetitive tasks, create intelligent workflows, and set up triggers to save time and increase productivity. Design complex automations without coding.',
    bestFor: 'Professionals wanting to automate workflows, reduce repetitive tasks, and increase efficiency',
    capabilities: [
      'Workflow automation design',
      'Task scheduling and triggers',
      'Process automation',
      'Integration with external services',
      'Conditional logic and branching',
      'Monitoring and alerts'
    ],
    features: [
      'Design complex automation workflows',
      'Schedule tasks and set triggers',
      'Automate repetitive processes',
      'Create conditional logic',
      'Monitor automation execution',
      'Get alerts on failures'
    ],
    howItWorks: [
      'Describe your repetitive task or process',
      'AutoChat designs an automation workflow',
      'Set triggers, schedules, and conditions',
      'Connect necessary services and tools',
      'Sit back and let automation work'
    ],
    benefits: [
      'Save hours on repetitive tasks',
      'Reduce human error',
      'Increase productivity significantly',
      'Focus on high-value work',
      'Create scalable processes'
    ],
    useCases: [
      'Email management and organization',
      'Data entry and synchronization',
      'Social media posting schedules',
      'Report generation and distribution',
      'Lead management and nurturing'
    ],
    keyStrengths: [
      'Workflow design',
      'Process optimization',
      'Integration expertise',
      'Efficiency improvement',
      'Error reduction'
    ]
  },

  'cv-smash': {
    name: 'CVSmash',
    role: 'Career Coach / Resume Optimizer',
    description: 'Professional career coaching, resume optimization, and interview preparation',
    icon: 'fa-solid fa-briefcase',
    category: 'Career',
    overview: 'CVSmash is your personal career coach, helping you optimize your resume, prepare for interviews, and advance your career. Get expert guidance on job applications and career strategy.',
    bestFor: 'Job seekers, career changers, and professionals wanting to advance their careers',
    capabilities: [
      'Resume optimization and formatting',
      'ATS keyword optimization',
      'Interview preparation',
      'Cover letter writing',
      'LinkedIn profile optimization',
      'Career path guidance'
    ],
    features: [
      'Resume review and optimization',
      'ATS keyword analysis',
      'Interview question practice',
      'Cover letter generation',
      'LinkedIn profile enhancement',
      'Salary negotiation tips'
    ],
    howItWorks: [
      'Upload your resume or describe your background',
      'CVSmash analyzes for improvement opportunities',
      'Receive specific optimization suggestions',
      'Practice interview questions',
      'Get feedback and guidance'
    ],
    benefits: [
      'Increase interview callback rate',
      'Get past ATS screening',
      'Ace your interviews',
      'Negotiate better salary',
      'Advance your career faster'
    ],
    useCases: [
      'Resume optimization for job applications',
      'Interview preparation and practice',
      'Career transition planning',
      'LinkedIn profile optimization',
      'Salary negotiation guidance'
    ],
    keyStrengths: [
      'Resume expertise',
      'Interview coaching',
      'Career guidance',
      'Professional writing',
      'Industry knowledge'
    ]
  },

  'comedian': {
    name: 'Comedian AI',
    role: 'Comedy & Entertainment',
    description: 'Stand-up comedy, jokes, and humorous conversations to brighten your day',
    icon: 'fa-solid fa-face-laugh-beam',
    category: 'Personality',
    overview: 'Comedian AI brings laughter and entertainment with witty humor, jokes, and comedic perspectives on everyday life.',
    bestFor: 'Anyone seeking entertainment, mood lifting, or learning comedy techniques',
    capabilities: [
      'Stand-up comedy routines',
      'Joke generation and delivery',
      'Humorous storytelling',
      'Comedy writing assistance',
      'Roast and compliment battles',
      'Improv comedy'
    ],
    features: [
      'Original jokes tailored to your interests',
      'Comedy writing workshops',
      'Humorous takes on current events',
      'Interactive comedy games',
      'Mood-lifting conversations',
      'Various comedy styles (puns, observational, dark, etc.)'
    ],
    howItWorks: [
      'Request jokes on specific topics or themes',
      'Engage in comedic banter and wordplay',
      'Get humorous perspectives on situations',
      'Practice comedy writing with feedback',
      'Enjoy entertaining stories and anecdotes'
    ],
    benefits: [
      'Instant mood improvement',
      'Stress relief through laughter',
      'Entertainment anytime',
      'Learn comedy techniques',
      'Brighten your day'
    ],
    useCases: [
      'Need a laugh during stressful times',
      'Writing comedy material',
      'Learning stand-up comedy',
      'Entertainment and fun',
      'Social icebreakers'
    ],
    keyStrengths: [
      'Quick wit',
      'Diverse comedy styles',
      'Adaptive humor',
      'Entertaining personality',
      'Positive energy'
    ]
  },

  'lazy': {
    name: 'Lazy AI',
    role: 'Chill & Minimal Effort Assistant',
    description: 'Maximum results with minimum effort - the art of smart laziness',
    icon: 'fa-solid fa-couch',
    category: 'Personality',
    overview: 'Lazy AI specializes in finding the easiest, most efficient solutions. Why work harder when you can work smarter?',
    bestFor: 'Productivity seekers, efficiency enthusiasts, and anyone who values their time',
    capabilities: [
      'Shortcut discovery',
      'Automation recommendations',
      'Minimal effort solutions',
      'Time-saving strategies',
      'Lazy productivity hacks',
      'Efficient workflow design'
    ],
    features: [
      'Find the easiest solution to any problem',
      'Automate repetitive tasks',
      'Productivity with minimal effort',
      'Smart delegation strategies',
      'Energy-saving approaches',
      'Relaxation techniques'
    ],
    howItWorks: [
      'Describe what you need to do',
      'Receive the laziest (smartest) way to do it',
      'Get automation and shortcut suggestions',
      'Learn efficient time management',
      'Work less, achieve more'
    ],
    benefits: [
      'Save time and energy',
      'Reduce unnecessary work',
      'Focus on what matters',
      'Less stress, more results',
      'Better work-life balance'
    ],
    useCases: [
      'Automate repetitive tasks',
      'Find shortcuts in workflows',
      'Reduce unnecessary effort',
      'Optimize daily routines',
      'Achieve goals efficiently'
    ],
    keyStrengths: [
      'Efficiency expert',
      'Automation specialist',
      'Shortcut finder',
      'Stress reducer',
      'Time optimizer'
    ]
  },

  'flirt': {
    name: 'Flirt AI',
    role: 'Charm & Romance Coach',
    description: 'Master the art of flirting, romance, and charming conversations',
    icon: 'fa-solid fa-heart',
    category: 'Personality',
    overview: 'Flirt AI helps you develop charm, charisma, and romantic communication skills with playful and engaging conversations.',
    bestFor: 'Anyone looking to improve dating skills, social charm, or romantic communication',
    capabilities: [
      'Flirting techniques and coaching',
      'Romantic conversation starters',
      'Pickup line generation (good ones!)',
      'Dating advice and strategy',
      'Compliment crafting',
      'Reading social cues'
    ],
    features: [
      'Personalized flirting advice',
      'Practice conversations',
      'Confidence building',
      'Dating profile optimization',
      'Text message coaching',
      'Romantic idea generation'
    ],
    howItWorks: [
      'Share your dating or social situation',
      'Receive charming conversation strategies',
      'Practice flirting in a safe environment',
      'Get feedback on your approach',
      'Build confidence and charm'
    ],
    benefits: [
      'Improved dating confidence',
      'Better romantic communication',
      'Increased social charm',
      'Reduced dating anxiety',
      'More successful connections'
    ],
    useCases: [
      'Preparing for dates',
      'Improving conversation skills',
      'Building confidence',
      'Learning romantic communication',
      'Getting dating advice'
    ],
    keyStrengths: [
      'Charismatic communication',
      'Dating expertise',
      'Confidence coaching',
      'Playful personality',
      'Romantic insight'
    ]
  },

  'sassy': {
    name: 'Sassy AI',
    role: 'Witty & Bold Conversationalist',
    description: 'Sharp wit, bold opinions, and unapologetically honest conversations',
    icon: 'fa-solid fa-fire',
    category: 'Personality',
    overview: 'Sassy AI delivers straight talk with style. Get honest feedback, witty comebacks, and bold perspectives.',
    bestFor: 'People who appreciate honesty, wit, and personality in their AI interactions',
    capabilities: [
      'Brutally honest feedback',
      'Witty comebacks',
      'Bold opinions',
      'Sarcastic humor',
      'Confidence coaching',
      'No-nonsense advice'
    ],
    features: [
      'Straightforward, honest responses',
      'Witty and entertaining conversation',
      'Bold perspective on situations',
      'Confidence-boosting attitude',
      'Playful sass and banter',
      'Unapologetic authenticity'
    ],
    howItWorks: [
      'Ask anything and get real answers',
      'Engage in witty banter',
      'Get honest opinions without sugar-coating',
      'Receive bold advice and perspectives',
      'Enjoy entertaining conversations'
    ],
    benefits: [
      'Honest feedback you can trust',
      'Entertainment through wit',
      'Confidence through boldness',
      'Refreshing authenticity',
      'Fun personality'
    ],
    useCases: [
      'Need honest advice',
      'Want entertaining conversation',
      'Seeking bold perspectives',
      'Building confidence',
      'Enjoying witty banter'
    ],
    keyStrengths: [
      'Sharp wit',
      'Brutal honesty',
      'Bold personality',
      'Entertaining',
      'Authentic'
    ]
  },

  'nerd': {
    name: 'Nerd AI',
    role: 'Academic & Tech Enthusiast',
    description: 'Deep knowledge in science, technology, gaming, and academic subjects',
    icon: 'fa-solid fa-glasses',
    category: 'Personality',
    overview: 'Nerd AI is your knowledgeable companion for all things science, tech, gaming, and academic. Dive deep into fascinating topics.',
    bestFor: 'Students, tech enthusiasts, gamers, and curious minds who love learning',
    capabilities: [
      'In-depth technical explanations',
      'Science and math tutoring',
      'Gaming knowledge and strategies',
      'Technology trends and analysis',
      'Academic research assistance',
      'Nerdy trivia and facts'
    ],
    features: [
      'Detailed explanations of complex topics',
      'Study and homework help',
      'Gaming tips and strategies',
      'Tech news and analysis',
      'Science experiments and theories',
      'Passionate discussions about interests'
    ],
    howItWorks: [
      'Ask about any technical or academic topic',
      'Discuss gaming strategies and lore',
      'Get help with homework or projects',
      'Explore scientific concepts',
      'Dive into nerdy conversations'
    ],
    benefits: [
      'Deep understanding of topics',
      'Better academic performance',
      'Gaming improvement',
      'Tech knowledge growth',
      'Intellectual stimulation'
    ],
    useCases: [
      'Homework help and tutoring',
      'Gaming strategy and tips',
      'Tech product research',
      'Learning new subjects',
      'Nerdy discussions'
    ],
    keyStrengths: [
      'Deep knowledge',
      'Patient teaching',
      'Gaming expertise',
      'Tech savvy',
      'Intellectual curiosity'
    ]
  },

  'cool': {
    name: 'Cool AI',
    role: 'Trendy & Street-Smart Guide',
    description: 'Stay cool, trendy, and in-the-know with street-smart advice and style',
    icon: 'fa-solid fa-sun',
    category: 'Personality',
    overview: 'Cool AI keeps you updated on trends, style, and culture. Get street-smart advice with an effortlessly cool vibe.',
    bestFor: 'Trend-followers, style enthusiasts, and anyone wanting to stay cool and current',
    capabilities: [
      'Trend spotting and analysis',
      'Style and fashion advice',
      'Cultural awareness',
      'Music and entertainment recommendations',
      'Social media strategy',
      'Street-smart life advice'
    ],
    features: [
      'Latest trends and cultural insights',
      'Fashion and style guidance',
      'Music discovery and playlists',
      'Social confidence tips',
      'Cool conversation topics',
      'Effortlessly chill personality'
    ],
    howItWorks: [
      'Ask about current trends and culture',
      'Get style and fashion recommendations',
      'Discover new music and entertainment',
      'Learn social strategies',
      'Stay in-the-know with ease'
    ],
    benefits: [
      'Stay current with trends',
      'Improve personal style',
      'Social confidence',
      'Cultural awareness',
      'Effortless coolness'
    ],
    useCases: [
      'Updating personal style',
      'Following trends',
      'Music discovery',
      'Social situations',
      'Cultural learning'
    ],
    keyStrengths: [
      'Trend awareness',
      'Style expertise',
      'Cultural knowledge',
      'Social intelligence',
      'Chill vibe'
    ]
  },

  'zen': {
    name: 'Zen AI',
    role: 'Mindfulness & Wellness Guide',
    description: 'Find inner peace, mindfulness, and balance through calming guidance',
    icon: 'fa-solid fa-spa',
    category: 'Personality',
    overview: 'Zen AI provides peaceful guidance for meditation, mindfulness, stress reduction, and finding balance in life.',
    bestFor: 'Anyone seeking peace, stress relief, mindfulness practice, or spiritual growth',
    capabilities: [
      'Guided meditation',
      'Mindfulness techniques',
      'Stress reduction strategies',
      'Breathing exercises',
      'Life balance coaching',
      'Peaceful wisdom sharing'
    ],
    features: [
      'Personalized meditation guides',
      'Daily mindfulness practices',
      'Calming conversations',
      'Stress management tools',
      'Philosophy and wisdom',
      'Peaceful perspective'
    ],
    howItWorks: [
      'Share what\'s troubling you or your goals',
      'Receive calming guidance and techniques',
      'Practice meditation and mindfulness',
      'Find balance and peace',
      'Develop sustainable wellness habits'
    ],
    benefits: [
      'Reduced stress and anxiety',
      'Improved mental clarity',
      'Better emotional balance',
      'Increased mindfulness',
      'Inner peace'
    ],
    useCases: [
      'Stress and anxiety relief',
      'Meditation practice',
      'Finding life balance',
      'Mindfulness development',
      'Spiritual growth'
    ],
    keyStrengths: [
      'Calming presence',
      'Mindfulness expertise',
      'Stress relief',
      'Wise perspective',
      'Peaceful guidance'
    ]
  },

  'gamer': {
    name: 'Gamer AI',
    role: 'Gaming Expert & Strategy Coach',
    description: 'Pro gaming strategies, tips, news, and all things gaming culture',
    icon: 'fa-solid fa-gamepad',
    category: 'Personality',
    overview: 'Gamer AI is your ultimate gaming companion with expert strategies, tips, news, and deep gaming knowledge.',
    bestFor: 'Gamers of all levels looking to improve, stay updated, or discuss gaming',
    capabilities: [
      'Game strategies and tactics',
      'Build and loadout optimization',
      'Gaming news and updates',
      'Pro player analysis',
      'Gaming hardware advice',
      'Esports knowledge'
    ],
    features: [
      'Game-specific strategies',
      'Meta analysis and updates',
      'Team composition tips',
      'Skill improvement coaching',
      'Gaming community insights',
      'Hardware and setup recommendations'
    ],
    howItWorks: [
      'Ask about any game or gaming topic',
      'Get strategies and tips',
      'Receive personalized improvement advice',
      'Discuss gaming news and meta',
      'Optimize your gaming setup'
    ],
    benefits: [
      'Improved gaming performance',
      'Stay updated on gaming news',
      'Better strategies and tactics',
      'Gaming community connection',
      'Expert guidance'
    ],
    useCases: [
      'Learning new games',
      'Improving competitive performance',
      'Following esports',
      'Hardware recommendations',
      'Gaming discussions'
    ],
    keyStrengths: [
      'Gaming expertise',
      'Strategy knowledge',
      'Meta awareness',
      'Community insights',
      'Passionate about gaming'
    ]
  },
};

// Coming Soon Agents Details
export const COMING_SOON_AGENTS_DETAILS: Record<string, AgentDetailsData> = {
  'med-doc-pro': {
    name: 'MedDoc Pro',
    role: 'Medical Consultation Assistant',
    description: 'Provides health information and wellness guidance',
    icon: 'fa-solid fa-stethoscope',
    category: 'Healthcare',
    overview: 'Coming Soon: Expert health information and personalized wellness guidance with medical accuracy and care.',
    capabilities: [
      'Health information database',
      'Symptom analysis',
      'Wellness recommendations',
      'Treatment information',
      'Health tracking',
      'Medication information'
    ],
    features: [
      'Symptom checker',
      'Health condition information',
      'Wellness tips and advice',
      'Medication information lookup',
      'Health goal tracking',
      'Doctor visit preparation'
    ],
    howItWorks: [
      'Describe your health concerns or questions',
      'MedDoc analyzes and provides information',
      'Receive wellness recommendations',
      'Get guidance on next steps',
      'Track health progress'
    ],
    benefits: [
      'Quick health information access',
      'Understand health conditions',
      'Improve wellness practices',
      'Prepare for doctor visits',
      'Better health decisions'
    ]
  },

  'legal-ease': {
    name: 'LegalEase',
    role: 'Legal Advisor',
    description: 'Assists with legal questions and document review',
    icon: 'fa-solid fa-scale-balanced',
    category: 'Legal',
    overview: 'Coming Soon: Legal guidance, document review, and contract analysis with expert legal knowledge.',
    capabilities: [
      'Legal question answering',
      'Document review and analysis',
      'Contract analysis',
      'Legal term explanation',
      'Regulation guidance',
      'Legal process explanation'
    ],
    features: [
      'Legal question answering',
      'Contract review',
      'Legal document analysis',
      'Terms and conditions explanation',
      'Regulation guidance',
      'Legal process walkthrough'
    ],
    howItWorks: [
      'Ask legal questions',
      'Upload documents for review',
      'Receive expert analysis',
      'Get clarification on legal terms',
      'Understand implications'
    ],
    benefits: [
      'Understand legal matters',
      'Review contracts before signing',
      'Save legal consultation costs',
      'Know your rights',
      'Make informed legal decisions'
    ]
  },

  'fit-coach': {
    name: 'FitCoach AI',
    role: 'Personal Trainer',
    description: 'Creates customized workout and nutrition plans',
    icon: 'fa-solid fa-dumbbell',
    category: 'Fitness',
    overview: 'Coming Soon: Personalized fitness routines and nutrition guidance based on your goals and preferences.',
    capabilities: [
      'Personalized workout planning',
      'Nutrition plan creation',
      'Progress tracking',
      'Exercise form guidance',
      'Diet recommendations',
      'Fitness goal setting'
    ],
    features: [
      'Custom workout routines',
      'Meal planning',
      'Nutrition tracking',
      'Exercise instructions',
      'Progress monitoring',
      'Goal achievement plans'
    ],
    howItWorks: [
      'Share your fitness goals and preferences',
      'FitCoach creates your plan',
      'Follow personalized routines',
      'Track progress and nutrition',
      'Get adjustments as needed'
    ],
    benefits: [
      'Personalized fitness guidance',
      'Achieve fitness goals faster',
      'Improve nutrition habits',
      'Stay motivated and accountable',
      'Professional-grade coaching'
    ]
  },
};

/**
 * Get agent details by name
 */
export function getAgentDetails(agentName: string, isAvailable: boolean = true): AgentDetailsData | null {
  if (isAvailable) {
    return AVAILABLE_AGENTS_DETAILS[agentName.toLowerCase().replace(/\s+/g, '-')] || null;
  } else {
    return COMING_SOON_AGENTS_DETAILS[agentName.toLowerCase().replace(/\s+/g, '-')] || null;
  }
}

/**
 * Get details for a specific agent by ID
 */
export function getAgentDetailsById(agentId: string, isAvailable: boolean = true): AgentDetailsData | null {
  if (isAvailable) {
    return AVAILABLE_AGENTS_DETAILS[agentId] || null;
  } else {
    return COMING_SOON_AGENTS_DETAILS[agentId] || null;
  }
}
