// Blog posts data - extracted from BlogPage.tsx to reduce file size
export interface BlogPost {
  id: number;
  year: number;
  title: string;
  excerpt: string;
  content: string;
  tags: string[];
}

export interface BlogEra {
  name: string;
  color: string;
  icon: string;
  years: number[];
}

export const blogEras: BlogEra[] = [
  { name: 'Foundations', color: 'bg-purple-500', icon: '🧮', years: [1936, 1955] },
  { name: 'Birth of AI', color: 'bg-blue-500', icon: '🧠', years: [1956, 1969] },
  { name: 'Expert Systems', color: 'bg-green-500', icon: '💡', years: [1970, 1979] },
  { name: 'AI Winter', color: 'bg-gray-500', icon: '❄️', years: [1980, 1989] },
  { name: 'Revival', color: 'bg-orange-500', icon: '🔥', years: [1990, 1999] },
  { name: 'Data Era', color: 'bg-cyan-500', icon: '📊', years: [2000, 2009] },
  { name: 'Deep Learning', color: 'bg-indigo-500', icon: '🚀', years: [2010, 2019] },
  { name: 'Transformers', color: 'bg-pink-500', icon: '✨', years: [2020, 2025] },
];

export const getEra = (year: number): BlogEra => {
  const era = blogEras.find(era => year >= era.years[0] && year <= era.years[1]);
  return era || { name: 'Modern', color: 'bg-teal-500', icon: '🤖', years: [2026, 2030] };
};

// This would contain all the blog post data
// For now, creating a placeholder to show the structure
export const blogPostsData: { [key: number]: BlogPost } = {
  // Data should be loaded from a separate JSON file or API
  // This approach reduces the component file size significantly
};

// Utility function to load blog posts dynamically
export const loadBlogPosts = async (): Promise<{ [key: number]: BlogPost }> => {
  // In a real implementation, this would fetch from an API or load from a JSON file
  // For now, return empty object to prevent the massive inline data
  return {};
};

export const yearRange = Array.from({ length: 90 }, (_, i) => 1936 + i); // 1936 to 2025
