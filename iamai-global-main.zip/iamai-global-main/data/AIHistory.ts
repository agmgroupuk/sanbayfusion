// AI History Data - 89 Years of Artificial Intelligence (1936-2025)
// This file contains the complete timeline of AI development
// Used by BlogPage to display AI history entries

export interface AIHistoryEntry {
  year: number;
  title: string;
  excerpt: string;
  content: string;
  category: string;
  date: string;
  tags: string[];
  references?: string[];
  author?: string;
}

// This is a placeholder structure - the actual data will be populated from BlogPage.tsx
// The data includes 89 entries (1936-2025) with full historical content
export const AI_HISTORY_ENTRIES: AIHistoryEntry[] = [];

// Helper function to get era info
export const getAIHistoryEra = (year: number) => {
  if (year >= 1936 && year <= 1955) return { name: 'Foundations', color: 'bg-purple-500', icon: '🧮' };
  if (year >= 1956 && year <= 1969) return { name: 'Birth of AI', color: 'bg-blue-500', icon: '🧠' };
  if (year >= 1970 && year <= 1979) return { name: 'Expert Systems', color: 'bg-green-500', icon: '💡' };
  if (year >= 1980 && year <= 1989) return { name: 'AI Winter', color: 'bg-gray-500', icon: '❄️' };
  if (year >= 1990 && year <= 1999) return { name: 'Revival', color: 'bg-orange-500', icon: '🔥' };
  if (year >= 2000 && year <= 2009) return { name: 'Data Era', color: 'bg-cyan-500', icon: '📊' };
  if (year >= 2010 && year <= 2019) return { name: 'Deep Learning', color: 'bg-indigo-500', icon: '🚀' };
  if (year >= 2020 && year <= 2025) return { name: 'Transformers', color: 'bg-pink-500', icon: '✨' };
  return { name: 'Modern', color: 'bg-teal-500', icon: '🤖' };
};
