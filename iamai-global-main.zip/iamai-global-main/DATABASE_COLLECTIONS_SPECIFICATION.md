# Database Collections Specification Document

## Overview

This document outlines all required MongoDB collections based on the comprehensive analysis of the components/ directory structure. Each collection includes detailed specifications for Documents, Aggregations, Schema, Indexes, and Validation.

## Collections by Category

### 1. User Management Collections

#### Users Collection

**Purpose**: Core user account data, authentication, and profile information.

**Documents**:

- User registration and login data
- Profile information (name, email, avatar)
- Account settings and preferences
- Authentication tokens and sessions
- Account status and verification

**Aggregations**:

- User activity summary (total chats, agents used, etc.)
- User engagement metrics
- Account health score calculation

**Schema**:

```javascript
{
  _id: ObjectId,
  email: { type: String, required: true, unique: true },
  username: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  firstName: String,
  lastName: String,
  avatar: String,
  bio: String,
  preferences: {
    theme: { type: String, enum: ['light', 'dark'], default: 'light' },
    language: { type: String, default: 'en' },
    notifications: {
      email: { type: Boolean, default: true },
      push: { type: Boolean, default: true }
    }
  },
  accountStatus: {
    type: String,
    enum: ['active', 'suspended', 'pending'],
    default: 'pending'
  },
  emailVerified: { type: Boolean, default: false },
  verificationToken: String,
  resetPasswordToken: String,
  resetPasswordExpires: Date,
  lastLogin: Date,
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
}
```

**Indexes**:

- `{ email: 1 }` (unique)
- `{ username: 1 }` (unique)
- `{ accountStatus: 1 }`
- `{ createdAt: 1 }`

**Validation**:

- Email format validation
- Password strength requirements
- Required fields for active accounts

#### UserSettings Collection

**Purpose**: Detailed user preferences and configuration settings.

**Documents**:

- UI customization settings
- Privacy settings
- Feature preferences
- API keys and integrations

**Aggregations**:

- Settings usage statistics
- Popular setting combinations

**Schema**:

```javascript
{
  _id: ObjectId,
  userId: { type: ObjectId, ref: 'Users', required: true },
  category: {
    type: String,
    enum: ['ui', 'privacy', 'features', 'integrations'],
    required: true
  },
  settings: Map,
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
}
```

**Indexes**:

- `{ userId: 1, category: 1 }` (unique)
- `{ updatedAt: 1 }`

#### UserActivity Collection

**Purpose**: Track all user actions and engagement metrics.

**Documents**:

- Login/logout events
- Feature usage events
- Page visits and interactions
- Error events and debugging info

**Aggregations**:

- Daily/weekly/monthly activity summaries
- Feature usage analytics
- User engagement scoring

**Schema**:

```javascript
{
  _id: ObjectId,
  userId: { type: ObjectId, ref: 'Users', required: true },
  action: { type: String, required: true },
  category: {
    type: String,
    enum: ['auth', 'chat', 'agent', 'file', 'settings'],
    required: true
  },
  metadata: Map,
  ipAddress: String,
  userAgent: String,
  timestamp: { type: Date, default: Date.now }
}
```

**Indexes**:

- `{ userId: 1, timestamp: -1 }`
- `{ category: 1, timestamp: -1 }`
- `{ action: 1 }`

### 2. Agent Management Collections

#### Agents Collection

**Purpose**: AI agent configurations, personalities, and metadata.

**Documents**:

- Agent definitions and personalities
- Configuration settings
- Usage statistics
- User associations

**Aggregations**:

- Agent popularity rankings
- Usage statistics by agent type
- Performance metrics

**Schema**:

```javascript
{
  _id: ObjectId,
  name: { type: String, required: true },
  personality: { type: String, required: true },
  description: String,
  avatar: String,
  systemPrompt: String,
  configuration: {
    temperature: { type: Number, min: 0, max: 2, default: 0.7 },
    maxTokens: { type: Number, default: 1000 },
    model: { type: String, default: 'gpt-3.5-turbo' }
  },
  creatorId: { type: ObjectId, ref: 'Users' },
  isPublic: { type: Boolean, default: false },
  usageCount: { type: Number, default: 0 },
  rating: { type: Number, min: 0, max: 5 },
  tags: [String],
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
}
```

**Indexes**:

- `{ name: 1 }`
- `{ personality: 1 }`
- `{ creatorId: 1 }`
- `{ isPublic: 1, usageCount: -1 }`

#### AgentPurchases Collection

**Purpose**: Track agent purchases and subscriptions.

**Documents**:

- Purchase transactions
- Subscription status
- Payment information
- Access permissions

**Aggregations**:

- Revenue analytics
- Popular agent purchases
- Subscription churn analysis

**Schema**:

```javascript
{
  _id: ObjectId,
  userId: { type: ObjectId, ref: 'Users', required: true },
  agentId: { type: ObjectId, ref: 'Agents', required: true },
  purchaseType: {
    type: String,
    enum: ['one-time', 'subscription'],
    required: true
  },
  amount: { type: Number, required: true },
  currency: { type: String, default: 'USD' },
  status: {
    type: String,
    enum: ['pending', 'completed', 'failed', 'refunded'],
    default: 'pending'
  },
  stripePaymentId: String,
  subscriptionId: String,
  expiresAt: Date,
  purchasedAt: { type: Date, default: Date.now }
}
```

**Indexes**:

- `{ userId: 1, agentId: 1 }`
- `{ status: 1 }`
- `{ expiresAt: 1 }`

### 3. Chat and Communication Collections

#### ChatSessions Collection

**Purpose**: Store chat conversations and message threads.

**Documents**:

- Chat session metadata
- Embedded message arrays
- Participant information
- Session settings

**Aggregations**:

- Session duration analytics
- Message volume statistics
- User chat patterns

**Schema**:

```javascript
{
  _id: ObjectId,
  userId: { type: ObjectId, ref: 'Users', required: true },
  agentId: { type: ObjectId, ref: 'Agents' },
  title: String,
  messages: [{
    _id: { type: ObjectId, default: new ObjectId() },
    role: { type: String, enum: ['user', 'assistant'], required: true },
    content: { type: String, required: true },
    timestamp: { type: Date, default: Date.now },
    metadata: Map
  }],
  status: {
    type: String,
    enum: ['active', 'completed', 'archived'],
    default: 'active'
  },
  settings: {
    model: String,
    temperature: Number,
    maxTokens: Number
  },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
  lastActivity: { type: Date, default: Date.now }
}
```

**Indexes**:

- `{ userId: 1, createdAt: -1 }`
- `{ agentId: 1 }`
- `{ status: 1 }`
- `{ lastActivity: -1 }`

#### MessageReactions Collection

**Purpose**: Store reactions to individual messages.

**Documents**:

- Message reaction data
- User associations
- Reaction types and timestamps

**Aggregations**:

- Popular reactions analytics
- User reaction patterns
- Message engagement metrics

**Schema**:

```javascript
{
  _id: ObjectId,
  sessionId: { type: ObjectId, ref: 'ChatSessions', required: true },
  messageId: { type: ObjectId, required: true },
  userId: { type: ObjectId, ref: 'Users', required: true },
  reaction: {
    type: String,
    enum: ['like', 'dislike', 'laugh', 'surprised', 'angry'],
    required: true
  },
  timestamp: { type: Date, default: Date.now }
}
```

**Indexes**:

- `{ sessionId: 1, messageId: 1 }`
- `{ userId: 1 }`
- `{ reaction: 1 }`

#### ConversationAnalytics Collection

**Purpose**: Store analytics data for conversations.

**Documents**:

- Conversation metrics
- Sentiment analysis
- Topic modeling data
- Performance metrics

**Aggregations**:

- Conversation quality metrics
- Topic trend analysis
- Sentiment over time

**Schema**:

```javascript
{
  _id: ObjectId,
  sessionId: { type: ObjectId, ref: 'ChatSessions', required: true },
  userId: { type: ObjectId, ref: 'Users', required: true },
  metrics: {
    messageCount: Number,
    avgResponseTime: Number,
    sentimentScore: Number,
    topics: [String],
    engagementScore: Number
  },
  analysis: {
    sentiment: String,
    topics: [{
      topic: String,
      confidence: Number
    }],
    keywords: [String]
  },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
}
```

**Indexes**:

- `{ sessionId: 1 }` (unique)
- `{ userId: 1, createdAt: -1 }`

### 4. Content and Media Collections

#### Files Collection

**Purpose**: Manage file uploads and storage.

**Documents**:

- File metadata
- Upload information
- Access permissions
- Storage details

**Aggregations**:

- Storage usage analytics
- File type distribution
- Upload activity trends

**Schema**:

```javascript
{
  _id: ObjectId,
  userId: { type: ObjectId, ref: 'Users', required: true },
  filename: { type: String, required: true },
  originalName: { type: String, required: true },
  mimeType: { type: String, required: true },
  size: { type: Number, required: true },
  path: { type: String, required: true },
  url: { type: String, required: true },
  thumbnail: String,
  metadata: Map,
  permissions: {
    type: String,
    enum: ['private', 'shared', 'public'],
    default: 'private'
  },
  uploadedAt: { type: Date, default: Date.now }
}
```

**Indexes**:

- `{ userId: 1, uploadedAt: -1 }`
- `{ mimeType: 1 }`
- `{ permissions: 1 }`

#### BlogPosts Collection

**Purpose**: Store blog content and articles.

**Documents**:

- Blog post content
- Author information
- Publication metadata
- SEO data

**Aggregations**:

- Popular posts analytics
- Author statistics
- Content category analysis

**Schema**:

```javascript
{
  _id: ObjectId,
  title: { type: String, required: true },
  slug: { type: String, required: true, unique: true },
  content: { type: String, required: true },
  excerpt: String,
  authorId: { type: ObjectId, ref: 'Users', required: true },
  category: String,
  tags: [String],
  status: {
    type: String,
    enum: ['draft', 'published', 'archived'],
    default: 'draft'
  },
  seo: {
    metaTitle: String,
    metaDescription: String,
    keywords: [String]
  },
  publishedAt: Date,
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
}
```

**Indexes**:

- `{ slug: 1 }` (unique)
- `{ authorId: 1 }`
- `{ status: 1, publishedAt: -1 }`
- `{ category: 1 }`

#### Templates Collection

**Purpose**: Store reusable templates for various features.

**Documents**:

- Template definitions
- Usage tracking
- Category organization

**Aggregations**:

- Template usage statistics
- Popular templates ranking

**Schema**:

```javascript
{
  _id: ObjectId,
  name: { type: String, required: true },
  description: String,
  category: { type: String, required: true },
  type: {
    type: String,
    enum: ['chat', 'agent', 'prompt', 'canvas'],
    required: true
  },
  content: { type: String, required: true },
  creatorId: { type: ObjectId, ref: 'Users' },
  isPublic: { type: Boolean, default: false },
  usageCount: { type: Number, default: 0 },
  tags: [String],
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
}
```

**Indexes**:

- `{ category: 1, type: 1 }`
- `{ creatorId: 1 }`
- `{ isPublic: 1, usageCount: -1 }`

### 5. Analytics and Metrics Collections

#### UsageAnalytics Collection

**Purpose**: Track user feature usage and engagement.

**Documents**:

- Feature usage events
- Time spent metrics
- Performance data

**Aggregations**:

- Feature adoption rates
- User engagement scores
- Performance monitoring

**Schema**:

```javascript
{
  _id: ObjectId,
  userId: { type: ObjectId, ref: 'Users', required: true },
  feature: { type: String, required: true },
  action: { type: String, required: true },
  duration: Number, // in milliseconds
  metadata: Map,
  timestamp: { type: Date, default: Date.now }
}
```

**Indexes**:

- `{ userId: 1, timestamp: -1 }`
- `{ feature: 1, timestamp: -1 }`

#### Achievements Collection

**Purpose**: Track user achievements and milestones.

**Documents**:

- Achievement definitions
- User progress tracking
- Unlocked achievements

**Aggregations**:

- Achievement completion rates
- User progress analytics

**Schema**:

```javascript
{
  _id: ObjectId,
  name: { type: String, required: true },
  description: String,
  icon: String,
  category: String,
  criteria: Map,
  points: { type: Number, default: 0 },
  rarity: {
    type: String,
    enum: ['common', 'rare', 'epic', 'legendary'],
    default: 'common'
  },
  createdAt: { type: Date, default: Date.now }
}
```

**Indexes**:

- `{ category: 1 }`
- `{ rarity: 1 }`

#### UserAchievements Collection

**Purpose**: Track which achievements users have unlocked.

**Documents**:

- User achievement associations
- Unlock timestamps
- Progress tracking

**Schema**:

```javascript
{
  _id: ObjectId,
  userId: { type: ObjectId, ref: 'Users', required: true },
  achievementId: { type: ObjectId, ref: 'Achievements', required: true },
  unlockedAt: { type: Date, default: Date.now },
  progress: Number // for partial achievements
}
```

**Indexes**:

- `{ userId: 1, achievementId: 1 }` (unique)
- `{ unlockedAt: -1 }`

### 6. Business and Administrative Collections

#### BillingHistory Collection

**Purpose**: Track all billing and payment transactions.

**Documents**:

- Payment records
- Invoice information
- Refund tracking

**Aggregations**:

- Revenue analytics
- Payment method preferences
- Churn analysis

**Schema**:

```javascript
{
  _id: ObjectId,
  userId: { type: ObjectId, ref: 'Users', required: true },
  type: {
    type: String,
    enum: ['subscription', 'one-time', 'refund'],
    required: true
  },
  amount: { type: Number, required: true },
  currency: { type: String, default: 'USD' },
  status: {
    type: String,
    enum: ['pending', 'completed', 'failed', 'refunded'],
    default: 'pending'
  },
  paymentMethod: String,
  stripePaymentId: String,
  invoiceId: String,
  description: String,
  processedAt: Date,
  createdAt: { type: Date, default: Date.now }
}
```

**Indexes**:

- `{ userId: 1, createdAt: -1 }`
- `{ status: 1 }`
- `{ type: 1 }`

#### Subscriptions Collection

**Purpose**: Manage user subscription plans and status.

**Documents**:

- Subscription details
- Plan information
- Billing cycles
- Status tracking

**Aggregations**:

- Subscription analytics
- Plan popularity
- Renewal predictions

**Schema**:

```javascript
{
  _id: ObjectId,
  userId: { type: ObjectId, ref: 'Users', required: true },
  planId: { type: String, required: true },
  planName: String,
  status: {
    type: String,
    enum: ['active', 'canceled', 'past_due', 'unpaid'],
    default: 'active'
  },
  currentPeriodStart: { type: Date, required: true },
  currentPeriodEnd: { type: Date, required: true },
  cancelAtPeriodEnd: { type: Boolean, default: false },
  stripeSubscriptionId: String,
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
}
```

**Indexes**:

- `{ userId: 1 }` (unique)
- `{ status: 1 }`
- `{ currentPeriodEnd: 1 }`

#### SupportTickets Collection

**Purpose**: Manage customer support interactions.

**Documents**:

- Support ticket data
- Conversation threads
- Resolution tracking

**Aggregations**:

- Support metrics
- Resolution time analytics
- Common issue tracking

**Schema**:

```javascript
{
  _id: ObjectId,
  userId: { type: ObjectId, ref: 'Users', required: true },
  subject: { type: String, required: true },
  description: { type: String, required: true },
  category: String,
  priority: {
    type: String,
    enum: ['low', 'medium', 'high', 'urgent'],
    default: 'medium'
  },
  status: {
    type: String,
    enum: ['open', 'in_progress', 'resolved', 'closed'],
    default: 'open'
  },
  assignedTo: { type: ObjectId, ref: 'Users' },
  messages: [{
    _id: { type: ObjectId, default: new ObjectId() },
    senderId: { type: ObjectId, ref: 'Users', required: true },
    content: { type: String, required: true },
    timestamp: { type: Date, default: Date.now },
    isInternal: { type: Boolean, default: false }
  }],
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
  resolvedAt: Date
}
```

**Indexes**:

- `{ userId: 1, createdAt: -1 }`
- `{ status: 1 }`
- `{ priority: 1 }`
- `{ assignedTo: 1 }`

#### Notifications Collection

**Purpose**: Store user notifications and alerts.

**Documents**:

- Notification content
- Delivery status
- User preferences

**Aggregations**:

- Notification delivery rates
- User engagement with notifications

**Schema**:

```javascript
{
  _id: ObjectId,
  userId: { type: ObjectId, ref: 'Users', required: true },
  type: {
    type: String,
    enum: ['info', 'warning', 'success', 'error'],
    required: true
  },
  title: { type: String, required: true },
  message: { type: String, required: true },
  actionUrl: String,
  isRead: { type: Boolean, default: false },
  readAt: Date,
  expiresAt: Date,
  createdAt: { type: Date, default: Date.now }
}
```

**Indexes**:

- `{ userId: 1, createdAt: -1 }`
- `{ isRead: 1 }`
- `{ expiresAt: 1 }`

### 7. AI Lab and Research Collections

#### AIExperiments Collection

**Purpose**: Store AI experiment configurations and results.

**Documents**:

- Experiment setups
- Parameter configurations
- Result data
- Performance metrics

**Aggregations**:

- Experiment success rates
- Parameter optimization analysis

**Schema**:

```javascript
{
  _id: ObjectId,
  userId: { type: ObjectId, ref: 'Users', required: true },
  name: { type: String, required: true },
  description: String,
  type: {
    type: String,
    enum: ['prompt', 'model', 'parameter', 'comparison'],
    required: true
  },
  configuration: Map,
  results: Map,
  metrics: {
    accuracy: Number,
    latency: Number,
    cost: Number,
    quality: Number
  },
  status: {
    type: String,
    enum: ['running', 'completed', 'failed'],
    default: 'running'
  },
  createdAt: { type: Date, default: Date.now },
  completedAt: Date
}
```

**Indexes**:

- `{ userId: 1, createdAt: -1 }`
- `{ type: 1 }`
- `{ status: 1 }`

#### Prompts Collection

**Purpose**: Store reusable AI prompts and templates.

**Documents**:

- Prompt templates
- Usage tracking
- Performance data

**Aggregations**:

- Prompt effectiveness analysis
- Popular prompts ranking

**Schema**:

```javascript
{
  _id: ObjectId,
  userId: { type: ObjectId, ref: 'Users', required: true },
  title: { type: String, required: true },
  content: { type: String, required: true },
  category: String,
  tags: [String],
  usageCount: { type: Number, default: 0 },
  successRate: Number,
  averageRating: Number,
  isPublic: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
}
```

**Indexes**:

- `{ userId: 1, createdAt: -1 }`
- `{ category: 1 }`
- `{ isPublic: 1, usageCount: -1 }`

#### Research Collection

**Purpose**: Store AI research data and findings.

**Documents**:

- Research projects
- Data sets
- Analysis results
- Publications

**Aggregations**:

- Research impact metrics
- Collaboration networks

**Schema**:

```javascript
{
  _id: ObjectId,
  userId: { type: ObjectId, ref: 'Users', required: true },
  title: { type: String, required: true },
  abstract: String,
  methodology: String,
  findings: String,
  data: Map,
  collaborators: [{ type: ObjectId, ref: 'Users' }],
  status: {
    type: String,
    enum: ['draft', 'in_progress', 'completed', 'published'],
    default: 'draft'
  },
  tags: [String],
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
}
```

**Indexes**:

- `{ userId: 1, createdAt: -1 }`
- `{ status: 1 }`
- `{ collaborators: 1 }`

### 8. Administrative Collections

#### AdminData Collection

**Purpose**: Store administrative dashboard data and metrics.

**Documents**:

- System metrics
- User statistics
- Performance data
- Administrative logs

**Aggregations**:

- System health monitoring
- User growth analytics
- Performance trend analysis

**Schema**:

```javascript
{
  _id: ObjectId,
  metric: { type: String, required: true },
  value: Map,
  category: {
    type: String,
    enum: ['users', 'system', 'performance', 'revenue'],
    required: true
  },
  timestamp: { type: Date, default: Date.now }
}
```

**Indexes**:

- `{ metric: 1, timestamp: -1 }`
- `{ category: 1, timestamp: -1 }`

#### PricingPlans Collection

**Purpose**: Store pricing plan configurations.

**Documents**:

- Plan definitions
- Feature sets
- Pricing tiers

**Schema**:

```javascript
{
  _id: ObjectId,
  name: { type: String, required: true },
  description: String,
  price: { type: Number, required: true },
  currency: { type: String, default: 'USD' },
  interval: {
    type: String,
    enum: ['month', 'year'],
    required: true
  },
  features: [String],
  limits: Map,
  stripePriceId: String,
  isActive: { type: Boolean, default: true },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
}
```

**Indexes**:

- `{ isActive: 1 }`
- `{ price: 1 }`

## Implementation Notes

### Schema Design Principles

1. **ObjectId References**: All user-related documents use ObjectId references to Users collection
2. **Embedded vs Referenced**: Frequently accessed data is embedded, less frequent data is referenced
3. **Indexing Strategy**: Compound indexes for common query patterns
4. **Validation**: Comprehensive validation rules for data integrity

### Aggregation Pipeline Patterns

1. **Time-based Analytics**: Use $group with $dateTrunc for time-series data
2. **User Metrics**: $lookup operations for joining user data with activity
3. **Ranking Queries**: $sort and $limit for top-N queries
4. **Statistical Analysis**: $group with accumulator operators

### Performance Considerations

1. **Index Coverage**: Ensure all query patterns have appropriate indexes
2. **Data Archiving**: Implement archiving strategies for old data
3. **Caching**: Consider caching frequently accessed data
4. **Sharding**: Plan for horizontal scaling with sharding keys

### Security Considerations

1. **Data Validation**: Strict validation on all user inputs
2. **Access Control**: Implement field-level security where needed
3. **Audit Logging**: Track all data modifications
4. **Encryption**: Encrypt sensitive data at rest

This specification provides a comprehensive foundation for the database architecture supporting all identified components and features.</content>
<parameter name="filePath">/Users/onelastai/Downloads/iamai-global/DATABASE_COLLECTIONS_SPECIFICATION.md
